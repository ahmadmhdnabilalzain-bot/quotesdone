# Category 46 QA Report — Aviation, Maritime & Offshore

**Build date:** 2026-07-31  
**Version:** 2026.07.31  
**Status:** research-complete production draft; **not SME approved**.

## Coverage

| Metric | Count |
|---|---:|
| Subcategories | 12 |
| Atomic records | 2,784 |
| Qualification questions | 348 |
| Decision rules | 300 |
| Validation rules | 120 |
| Scenario tests | 84 |
| Source records | 9 |
| Master characters | 2,929,396 |
| Master words | 272,696 |

## Automated checks

- JSON Schema validation: PASS for every atomic record.
- Duplicate record IDs: PASS.
- Source reference integrity: PASS.
- Every subcategory has industry, product/service, technical, supplier, quotation, document, regulation, inquiry, decision, validation, scenario and glossary records.
- Paid standards are referenced rather than reproduced.

## Module counts

```json
{
  "industry": 48,
  "products_services": 180,
  "technical": 204,
  "brands_manufacturers": 72,
  "supplier_ecosystem": 96,
  "supplier_eligibility": 96,
  "quotation": 120,
  "documents": 168,
  "uae_regulations": 96,
  "inquiry_qualification": 648,
  "validation": 120,
  "commercial_pricing": 120,
  "customer_tradeoffs": 120,
  "risk": 120,
  "best_practices": 72,
  "troubleshooting": 96,
  "scenario_test": 84,
  "glossary": 324
}
```

## Validation status

```json
{
  "source_verified": 588,
  "reviewed": 2124,
  "draft": 72
}
```

## Certification blockers

The open gaps in `20_gap_register.csv` remain mandatory. This package supports routing, qualification and retrieval; it is not a substitute for professional design, legal/tax/medical advice, certification, valuation or authority approval.
