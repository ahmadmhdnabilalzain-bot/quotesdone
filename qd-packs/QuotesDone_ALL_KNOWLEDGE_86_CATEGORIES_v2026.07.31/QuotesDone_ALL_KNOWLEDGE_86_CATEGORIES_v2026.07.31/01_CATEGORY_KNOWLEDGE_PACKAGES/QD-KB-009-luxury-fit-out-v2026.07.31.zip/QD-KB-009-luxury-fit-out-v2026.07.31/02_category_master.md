# QuotesDone Knowledge Corpus — Category 09

## Luxury Fit-Out

**Arabic working title:** التجهيزات الداخلية الفاخرة
**Version:** 2026.07.31
**Status:** research-complete production draft; not SME approved
**Subcategories:** 4

## Runtime purpose

This corpus supports customer-language routing, adaptive qualification, supplier eligibility, document extraction, UAE source retrieval, comparable RFQ generation, risk control and escalation for Luxury Fit-Out. The large master file is for human audit. Runtime systems should use the atomic JSONL records, deterministic questions/rules and internal retrieval rather than placing this entire file in a model prompt.


# 1. Luxury villas

**Arabic draft:** متطلبات Luxury villas
**Slug:** `luxury-villas`
**Aliases:** Luxury villas

## Industry

### Industry scope — Luxury villas

Luxury villas is treated as a distinct procurement route within Luxury Fit-Out. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers physical products, building systems, finishes, installation and project handover. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-009-luxury-villas-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS

```json
{
  "category": "Luxury Fit-Out",
  "subcategory": "Luxury villas",
  "profile": "building",
  "aliases": [
    "Luxury villas"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Luxury villas

A normal UAE sourcing workflow for Luxury villas moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-009-luxury-villas-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS, UAE-MOIAT

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Luxury villas

Customers may describe Luxury villas through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-009-luxury-villas-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Luxury villas

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-009-luxury-villas-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Luxury villas product or service

The primary deliverable requested within Luxury villas; exact type, quantity, performance, scope and acceptance must be normalized. For Luxury villas, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-villas-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Luxury villas",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Luxury villas

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Luxury villas, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-villas-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Luxury villas",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Luxury villas

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Luxury villas, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-villas-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Luxury villas",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Luxury villas

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Luxury villas, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-villas-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Luxury villas",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Luxury villas

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Luxury villas, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-villas-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Luxury villas",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Luxury villas

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Luxury villas, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-villas-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Luxury villas",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Luxury villas

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Luxury villas, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-villas-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Luxury villas",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Luxury villas

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Luxury villas, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-villas-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Luxury villas",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Premium Material Provenance scope component

Premium Material Provenance is a recurring scope component for Luxury villas. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-villas-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "premium material provenance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Bespoke Detailing scope component

Bespoke Detailing is a recurring scope component for Luxury villas. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-villas-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "bespoke detailing",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Mock-Up Quality scope component

Mock-Up Quality is a recurring scope component for Luxury villas. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-villas-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "mock-up quality",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Specialist Craftsmanship scope component

Specialist Craftsmanship is a recurring scope component for Luxury villas. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-villas-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "specialist craftsmanship",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Brand/Design Intent scope component

Brand/Design Intent is a recurring scope component for Luxury villas. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-villas-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "brand/design intent",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Long-Lead Procurement scope component

Long-Lead Procurement is a recurring scope component for Luxury villas. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-villas-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "long-lead procurement",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Defect-Free Handover scope component

Defect-Free Handover is a recurring scope component for Luxury villas. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-villas-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "defect-free handover",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: material or system type

For Luxury villas, material or system type must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "material or system type",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: dimensions and quantity basis

For Luxury villas, dimensions and quantity basis must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "dimensions and quantity basis",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: performance rating

For Luxury villas, performance rating must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "performance rating",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: finish and visual requirement

For Luxury villas, finish and visual requirement must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "finish and visual requirement",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: substrate or supporting structure

For Luxury villas, substrate or supporting structure must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "substrate or supporting structure",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces with adjacent systems

For Luxury villas, interfaces with adjacent systems must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces with adjacent systems",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation method and access

For Luxury villas, installation method and access must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation method and access",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environmental exposure

For Luxury villas, environmental exposure must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environmental exposure",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: testing and acceptance

For Luxury villas, testing and acceptance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "testing and acceptance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: warranty and maintenance

For Luxury villas, warranty and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "warranty and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: premium material provenance

For Luxury villas, premium material provenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "premium material provenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: bespoke detailing

For Luxury villas, bespoke detailing must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "bespoke detailing",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: mock-up quality

For Luxury villas, mock-up quality must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "mock-up quality",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: specialist craftsmanship

For Luxury villas, specialist craftsmanship must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "specialist craftsmanship",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: brand/design intent

For Luxury villas, brand/design intent must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "brand/design intent",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: long-lead procurement

For Luxury villas, long-lead procurement must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "long-lead procurement",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: defect-free handover

For Luxury villas, defect-free handover must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-villas-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "defect-free handover",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer

A manufacturer may be relevant to Luxury villas depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-villas-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Luxury villas depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-villas-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: specialist installer

A specialist installer may be relevant to Luxury villas depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-villas-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "specialist installer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fit-out contractor

A fit-out contractor may be relevant to Luxury villas depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-villas-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fit-out contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator or workshop

A fabricator or workshop may be relevant to Luxury villas depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-villas-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator or workshop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: design-and-build contractor

A design-and-build contractor may be relevant to Luxury villas depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-villas-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "design-and-build contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer

This supplier type can participate in Luxury villas only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-villas-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Luxury villas only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-villas-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — specialist installer

This supplier type can participate in Luxury villas only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-villas-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "specialist installer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fit-out contractor

This supplier type can participate in Luxury villas only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-villas-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fit-out contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator or workshop

This supplier type can participate in Luxury villas only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-villas-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator or workshop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — design-and-build contractor

This supplier type can participate in Luxury villas only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-villas-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "design-and-build contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — testing/commissioning provider

This supplier type can participate in Luxury villas only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-villas-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "testing/commissioning provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance provider

This supplier type can participate in Luxury villas only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-villas-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer

Before routing a Luxury villas inquiry to a manufacturer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-villas-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "manufacturer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Luxury villas inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-villas-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — specialist installer

Before routing a Luxury villas inquiry to a specialist installer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-villas-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "specialist installer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fit-out contractor

Before routing a Luxury villas inquiry to a fit-out contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-villas-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "fit-out contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator or workshop

Before routing a Luxury villas inquiry to a fabricator or workshop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-villas-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "fabricator or workshop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — design-and-build contractor

Before routing a Luxury villas inquiry to a design-and-build contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-villas-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "design-and-build contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — testing/commissioning provider

Before routing a Luxury villas inquiry to a testing/commissioning provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-villas-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "testing/commissioning provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance provider

Before routing a Luxury villas inquiry to a maintenance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-villas-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "maintenance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Luxury villas should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-villas-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Luxury villas should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-villas-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Luxury villas should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-villas-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Luxury villas should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-villas-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Luxury villas should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-villas-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Luxury villas should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-villas-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Luxury villas should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-villas-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Luxury villas should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-villas-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Luxury villas should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-villas-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Luxury villas should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-villas-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Boq

Boq may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "boq",
  "document_name": "boq",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Architectural Drawings

Architectural Drawings may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "architectural-drawings",
  "document_name": "architectural drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Finish Schedule

Finish Schedule may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "finish-schedule",
  "document_name": "finish schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Shop Drawings

Shop Drawings may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "shop-drawings",
  "document_name": "shop drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Submittal

Material Submittal may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-submittal",
  "document_name": "material submittal",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Sample Or Mock-Up Approval

Sample Or Mock-Up Approval may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "sample-or-mock-up-approval",
  "document_name": "sample or mock-up approval",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement

Method Statement may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement",
  "document_name": "method statement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Plan

Inspection/Test Plan may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-plan",
  "document_name": "inspection/test plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Authority Or Developer Approval

Authority Or Developer Approval may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "authority-or-developer-approval",
  "document_name": "authority or developer approval",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### As-Built Drawings

As-Built Drawings may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "as-built-drawings",
  "document_name": "as-built drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Warranty

Warranty may provide or verify information needed for Luxury villas. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-villas-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "warranty",
  "document_name": "warranty",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Dubai Building Code 2021

For Luxury villas, consult Dubai Building Code 2021 when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-villas-uae_regulations-source_activation-0082`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-DBC-2021

```json
{
  "source_id": "UAE-DM-DBC-2021",
  "publisher": "Dubai Municipality",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Al Sa’fat – Dubai Green Building System

For Luxury villas, consult Al Sa’fat – Dubai Green Building System when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-villas-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-ALSAFAT

```json
{
  "source_id": "UAE-DM-ALSAFAT",
  "publisher": "Dubai Municipality",
  "source_type": "government_sustainability_system",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Fire and Life Safety Code of Practice

For Luxury villas, consult UAE Fire and Life Safety Code of Practice when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-villas-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DCD-FLS

```json
{
  "source_id": "UAE-DCD-FLS",
  "publisher": "Dubai Civil Defence",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Industrial, Standards, Conformity and Quality Services

For Luxury villas, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-villas-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Luxury villas, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-villas-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For Luxury villas, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-villas-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Luxury villas. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-villas-commercial_pricing-cost_driver-0088`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Luxury villas. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-villas-commercial_pricing-cost_driver-0090`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Luxury villas. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-villas-commercial_pricing-cost_driver-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Luxury villas. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-villas-commercial_pricing-cost_driver-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Luxury villas. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-villas-commercial_pricing-cost_driver-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Luxury villas. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-villas-commercial_pricing-cost_driver-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Luxury villas. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-villas-commercial_pricing-cost_driver-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Luxury villas. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-villas-commercial_pricing-cost_driver-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Luxury villas. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-villas-commercial_pricing-cost_driver-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Luxury villas. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-villas-commercial_pricing-cost_driver-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-villas-customer_tradeoffs-tradeoff-0089`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-villas-customer_tradeoffs-tradeoff-0091`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-villas-customer_tradeoffs-tradeoff-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-villas-customer_tradeoffs-tradeoff-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-villas-customer_tradeoffs-tradeoff-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-villas-customer_tradeoffs-tradeoff-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-villas-customer_tradeoffs-tradeoff-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-villas-customer_tradeoffs-tradeoff-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-villas-customer_tradeoffs-tradeoff-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-villas-customer_tradeoffs-tradeoff-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Luxury villas, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-villas-risk-risk_control-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Luxury villas, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-villas-risk-risk_control-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Luxury villas, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-villas-risk-risk_control-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Luxury villas, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-villas-risk-risk_control-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Luxury villas, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-villas-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Luxury villas, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-villas-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Luxury villas, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-villas-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Luxury villas, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-villas-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Luxury villas, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-villas-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Luxury villas, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-villas-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Luxury villas, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-villas-best_practices-qualification_best_practice-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Luxury villas, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-villas-best_practices-qualification_best_practice-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Luxury villas, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-villas-best_practices-qualification_best_practice-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Luxury villas, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-villas-best_practices-qualification_best_practice-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Luxury villas, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-villas-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Luxury villas, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-villas-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Luxury villas; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-villas-troubleshooting-recovery_guidance-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Luxury villas; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-villas-troubleshooting-recovery_guidance-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Luxury villas; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-villas-troubleshooting-recovery_guidance-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Luxury villas; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-villas-troubleshooting-recovery_guidance-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Luxury villas; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-villas-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Luxury villas; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-villas-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Luxury villas; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-villas-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Luxury villas; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-villas-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What area, dimensions, quantities or item schedule applies?

Ask in plain language: What area, dimensions, quantities or item schedule applies? Arabic draft: ما المساحة أو الأبعاد أو الكميات أو جدول العناصر المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-area-dimensions",
  "question_en": "What area, dimensions, quantities or item schedule applies?",
  "question_ar": "ما المساحة أو الأبعاد أو الكميات أو جدول العناصر المطلوب؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "area-dimensions",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What area, dimensions, quantities or item schedule applies? is missing

When the normalized field area-dimensions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-area-dimensions",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "area-dimensions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-area-dimensions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What material, finish, colour, texture or appearance is required?

Ask in plain language: What material, finish, colour, texture or appearance is required? Arabic draft: ما المادة أو التشطيب أو اللون أو الملمس أو المظهر المطلوب؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-material-finish",
  "question_en": "What material, finish, colour, texture or appearance is required?",
  "question_ar": "ما المادة أو التشطيب أو اللون أو الملمس أو المظهر المطلوب؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "material-finish",
  "order": 140,
  "confidence_contribution": 0.012
}
```

### What fire, acoustic, thermal, structural, slip, water or durability performance is required?

Ask in plain language: What fire, acoustic, thermal, structural, slip, water or durability performance is required? Arabic draft: ما متطلبات الحريق أو الصوت أو الحرارة أو الإنشاء أو الانزلاق أو الماء أو المتانة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-performance-rating",
  "question_en": "What fire, acoustic, thermal, structural, slip, water or durability performance is required?",
  "question_ar": "ما متطلبات الحريق أو الصوت أو الحرارة أو الإنشاء أو الانزلاق أو الماء أو المتانة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "performance-rating",
  "order": 150,
  "confidence_contribution": 0.012
}
```

### What substrate, supports, openings and adjacent-system interfaces exist?

Ask in plain language: What substrate, supports, openings and adjacent-system interfaces exist? Arabic draft: ما الأسطح أو الدعامات أو الفتحات أو الواجهات مع الأنظمة المجاورة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-substrate-interfaces",
  "question_en": "What substrate, supports, openings and adjacent-system interfaces exist?",
  "question_ar": "ما الأسطح أو الدعامات أو الفتحات أو الواجهات مع الأنظمة المجاورة؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "substrate-interfaces",
  "order": 160,
  "confidence_contribution": 0.03
}
```

### Ask when What substrate, supports, openings and adjacent-system interfaces exist? is missing

When the normalized field substrate-interfaces is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-substrate-interfaces",
  "priority": 984,
  "when": {
    "all": [
      {
        "field": "substrate-interfaces",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-substrate-interfaces"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site access, work hours, lifting, storage, protection and shutdown constraints apply?

Ask in plain language: What site access, work hours, lifting, storage, protection and shutdown constraints apply? Arabic draft: ما قيود الوصول وساعات العمل والرفع والتخزين والحماية والإيقاف؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-installation-access",
  "question_en": "What site access, work hours, lifting, storage, protection and shutdown constraints apply?",
  "question_ar": "ما قيود الوصول وساعات العمل والرفع والتخزين والحماية والإيقاف؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-access",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What site access, work hours, lifting, storage, protection and shutdown constraints apply? is missing

When the normalized field installation-access is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-installation-access",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "installation-access",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-installation-access"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are samples, mock-ups, shop drawings or material approvals required?

Ask in plain language: Are samples, mock-ups, shop drawings or material approvals required? Arabic draft: هل يلزم عينات أو نموذج تجريبي أو مخططات ورشة أو اعتماد مواد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-samples-mockup",
  "question_en": "Are samples, mock-ups, shop drawings or material approvals required?",
  "question_ar": "هل يلزم عينات أو نموذج تجريبي أو مخططات ورشة أو اعتماد مواد؟",
  "expected_answer_type": "multi_select",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "samples-mockup",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What testing, cleaning, protection, handover and warranty scope is required?

Ask in plain language: What testing, cleaning, protection, handover and warranty scope is required? Arabic draft: ما نطاق الاختبار والتنظيف والحماية والتسليم والضمان المطلوب؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-handover-warranty",
  "question_en": "What testing, cleaning, protection, handover and warranty scope is required?",
  "question_ar": "ما نطاق الاختبار والتنظيف والحماية والتسليم والضمان المطلوب؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "handover-warranty",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### Please clarify the premium material provenance requirements for Luxury villas.

Ask in plain language: Please clarify the premium material provenance requirements for Luxury villas. Arabic draft: يرجى توضيح متطلبات premium material provenance الخاصة بـ Luxury villas. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-facet-01",
  "question_en": "Please clarify the premium material provenance requirements for Luxury villas.",
  "question_ar": "يرجى توضيح متطلبات premium material provenance الخاصة بـ Luxury villas.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the premium material provenance requirements for Luxury villas. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-facet-01",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the bespoke detailing requirements for Luxury villas.

Ask in plain language: Please clarify the bespoke detailing requirements for Luxury villas. Arabic draft: يرجى توضيح متطلبات bespoke detailing الخاصة بـ Luxury villas. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-facet-02",
  "question_en": "Please clarify the bespoke detailing requirements for Luxury villas.",
  "question_ar": "يرجى توضيح متطلبات bespoke detailing الخاصة بـ Luxury villas.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the bespoke detailing requirements for Luxury villas. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-facet-02",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the mock-up quality requirements for Luxury villas.

Ask in plain language: Please clarify the mock-up quality requirements for Luxury villas. Arabic draft: يرجى توضيح متطلبات mock-up quality الخاصة بـ Luxury villas. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-facet-03",
  "question_en": "Please clarify the mock-up quality requirements for Luxury villas.",
  "question_ar": "يرجى توضيح متطلبات mock-up quality الخاصة بـ Luxury villas.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the mock-up quality requirements for Luxury villas. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-facet-03",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the specialist craftsmanship requirements for Luxury villas.

Ask in plain language: Please clarify the specialist craftsmanship requirements for Luxury villas. Arabic draft: يرجى توضيح متطلبات specialist craftsmanship الخاصة بـ Luxury villas. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-facet-04",
  "question_en": "Please clarify the specialist craftsmanship requirements for Luxury villas.",
  "question_ar": "يرجى توضيح متطلبات specialist craftsmanship الخاصة بـ Luxury villas.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 230,
  "confidence_contribution": 0.012
}
```

### Please clarify the brand/design intent requirements for Luxury villas.

Ask in plain language: Please clarify the brand/design intent requirements for Luxury villas. Arabic draft: يرجى توضيح متطلبات brand/design intent الخاصة بـ Luxury villas. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-facet-05",
  "question_en": "Please clarify the brand/design intent requirements for Luxury villas.",
  "question_ar": "يرجى توضيح متطلبات brand/design intent الخاصة بـ Luxury villas.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the long-lead procurement requirements for Luxury villas.

Ask in plain language: Please clarify the long-lead procurement requirements for Luxury villas. Arabic draft: يرجى توضيح متطلبات long-lead procurement الخاصة بـ Luxury villas. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-facet-06",
  "question_en": "Please clarify the long-lead procurement requirements for Luxury villas.",
  "question_ar": "يرجى توضيح متطلبات long-lead procurement الخاصة بـ Luxury villas.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the defect-free handover requirements for Luxury villas.

Ask in plain language: Please clarify the defect-free handover requirements for Luxury villas. Arabic draft: يرجى توضيح متطلبات defect-free handover الخاصة بـ Luxury villas. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-facet-07",
  "question_en": "Please clarify the defect-free handover requirements for Luxury villas.",
  "question_ar": "يرجى توضيح متطلبات defect-free handover الخاصة بـ Luxury villas.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Which exact Luxury villas product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Luxury villas product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Luxury villas التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-exact-subtype",
  "question_en": "Which exact Luxury villas product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Luxury villas التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 270,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Luxury villas product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-ask-exact-subtype",
  "priority": 973,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-villas-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Luxury villas are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Luxury villas are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Luxury villas التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-unknowns",
  "question_en": "Which details about Luxury villas are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Luxury villas التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 280,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Luxury villas?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Luxury villas? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Luxury villas؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-villas-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Luxury villas?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Luxury villas؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Luxury villas, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Luxury villas, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Luxury villas, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Luxury villas, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0179`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS, UAE-MOIAT, ISO-STANDARDS, ASTM-STANDARDS

```json
{
  "rule_id": "R-009-luxury-villas-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-DM-DBC-2021",
        "UAE-DM-ALSAFAT",
        "UAE-DCD-FLS",
        "UAE-MOIAT",
        "ISO-STANDARDS",
        "ASTM-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Luxury villas, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Luxury villas, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Luxury villas, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Luxury villas, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-villas-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-villas-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Luxury villas, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-villas-validation-validation_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-villas-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Luxury villas, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-villas-validation-validation_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-villas-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Luxury villas, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-villas-validation-validation_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-villas-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Luxury villas, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-villas-validation-validation_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-villas-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Luxury villas, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-villas-validation-validation_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-villas-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Luxury villas, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-villas-validation-validation_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-villas-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Luxury villas, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-villas-validation-validation_rule-0190`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "validation_id": "V-009-luxury-villas-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Luxury villas, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-villas-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-villas-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Luxury villas, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-villas-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-villas-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Luxury villas, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-villas-validation-validation_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-villas-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Luxury villas without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-villas-scenario_test-scenario-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-villas-001",
  "setup": "Customer asks informally for Luxury villas without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Luxury villas with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-villas-scenario_test-scenario-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-villas-002",
  "setup": "Customer requests price for Luxury villas with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Luxury villas. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-villas-scenario_test-scenario-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-villas-003",
  "setup": "Customer uploads a relevant schedule/specification for Luxury villas.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Luxury villas. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-villas-scenario_test-scenario-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-villas-004",
  "setup": "Customer message and uploaded document disagree on Luxury villas.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Luxury villas. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-villas-scenario_test-scenario-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-villas-005",
  "setup": "Supplier proposes a different product, provider or method for Luxury villas.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Luxury villas sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-villas-scenario_test-scenario-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-villas-006",
  "setup": "Customer needs Luxury villas sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Luxury villas needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-villas-scenario_test-scenario-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-villas-007",
  "setup": "The request for Luxury villas needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Luxury villas

English term: Luxury villas. Arabic operational draft: متطلبات Luxury villas. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Luxury villas",
  "term_ar": "متطلبات Luxury villas",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### premium material provenance

English term: premium material provenance. Arabic operational draft: متطلبات premium material provenance. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "premium material provenance",
  "term_ar": "متطلبات premium material provenance",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### bespoke detailing

English term: bespoke detailing. Arabic operational draft: متطلبات bespoke detailing. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "bespoke detailing",
  "term_ar": "متطلبات bespoke detailing",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### mock-up quality

English term: mock-up quality. Arabic operational draft: متطلبات mock-up quality. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mock-up quality",
  "term_ar": "متطلبات mock-up quality",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### specialist craftsmanship

English term: specialist craftsmanship. Arabic operational draft: متطلبات specialist craftsmanship. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "specialist craftsmanship",
  "term_ar": "متطلبات specialist craftsmanship",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### brand/design intent

English term: brand/design intent. Arabic operational draft: متطلبات brand/design intent. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "brand/design intent",
  "term_ar": "متطلبات brand/design intent",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### long-lead procurement

English term: long-lead procurement. Arabic operational draft: متطلبات long-lead procurement. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "long-lead procurement",
  "term_ar": "متطلبات long-lead procurement",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```

### defect-free handover

English term: defect-free handover. Arabic operational draft: متطلبات defect-free handover. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-villas-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "defect-free handover",
  "term_ar": "متطلبات defect-free handover",
  "canonical_subcategory": "luxury-villas",
  "normalization_only": true
}
```


# 2. Luxury retail

**Arabic draft:** متطلبات Luxury retail
**Slug:** `luxury-retail`
**Aliases:** Luxury retail

## Industry

### Industry scope — Luxury retail

Luxury retail is treated as a distinct procurement route within Luxury Fit-Out. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers physical products, building systems, finishes, installation and project handover. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-009-luxury-retail-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS

```json
{
  "category": "Luxury Fit-Out",
  "subcategory": "Luxury retail",
  "profile": "building",
  "aliases": [
    "Luxury retail"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Luxury retail

A normal UAE sourcing workflow for Luxury retail moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-009-luxury-retail-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS, UAE-MOIAT

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Luxury retail

Customers may describe Luxury retail through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-009-luxury-retail-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Luxury retail

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-009-luxury-retail-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Luxury retail product or service

The primary deliverable requested within Luxury retail; exact type, quantity, performance, scope and acceptance must be normalized. For Luxury retail, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-retail-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Luxury retail",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Luxury retail

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Luxury retail, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-retail-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Luxury retail",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Luxury retail

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Luxury retail, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-retail-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Luxury retail",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Luxury retail

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Luxury retail, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-retail-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Luxury retail",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Luxury retail

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Luxury retail, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-retail-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Luxury retail",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Luxury retail

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Luxury retail, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-retail-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Luxury retail",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Luxury retail

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Luxury retail, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-retail-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Luxury retail",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Luxury retail

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Luxury retail, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-retail-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Luxury retail",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Premium Material Provenance scope component

Premium Material Provenance is a recurring scope component for Luxury retail. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-retail-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "premium material provenance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Bespoke Detailing scope component

Bespoke Detailing is a recurring scope component for Luxury retail. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-retail-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "bespoke detailing",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Mock-Up Quality scope component

Mock-Up Quality is a recurring scope component for Luxury retail. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-retail-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "mock-up quality",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Specialist Craftsmanship scope component

Specialist Craftsmanship is a recurring scope component for Luxury retail. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-retail-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "specialist craftsmanship",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Brand/Design Intent scope component

Brand/Design Intent is a recurring scope component for Luxury retail. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-retail-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "brand/design intent",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Long-Lead Procurement scope component

Long-Lead Procurement is a recurring scope component for Luxury retail. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-retail-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "long-lead procurement",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Defect-Free Handover scope component

Defect-Free Handover is a recurring scope component for Luxury retail. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-retail-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "defect-free handover",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: material or system type

For Luxury retail, material or system type must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "material or system type",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: dimensions and quantity basis

For Luxury retail, dimensions and quantity basis must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "dimensions and quantity basis",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: performance rating

For Luxury retail, performance rating must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "performance rating",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: finish and visual requirement

For Luxury retail, finish and visual requirement must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "finish and visual requirement",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: substrate or supporting structure

For Luxury retail, substrate or supporting structure must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "substrate or supporting structure",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces with adjacent systems

For Luxury retail, interfaces with adjacent systems must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces with adjacent systems",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation method and access

For Luxury retail, installation method and access must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation method and access",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environmental exposure

For Luxury retail, environmental exposure must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environmental exposure",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: testing and acceptance

For Luxury retail, testing and acceptance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "testing and acceptance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: warranty and maintenance

For Luxury retail, warranty and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "warranty and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: premium material provenance

For Luxury retail, premium material provenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "premium material provenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: bespoke detailing

For Luxury retail, bespoke detailing must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "bespoke detailing",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: mock-up quality

For Luxury retail, mock-up quality must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "mock-up quality",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: specialist craftsmanship

For Luxury retail, specialist craftsmanship must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "specialist craftsmanship",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: brand/design intent

For Luxury retail, brand/design intent must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "brand/design intent",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: long-lead procurement

For Luxury retail, long-lead procurement must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "long-lead procurement",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: defect-free handover

For Luxury retail, defect-free handover must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-retail-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "defect-free handover",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer

A manufacturer may be relevant to Luxury retail depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-retail-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Luxury retail depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-retail-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: specialist installer

A specialist installer may be relevant to Luxury retail depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-retail-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "specialist installer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fit-out contractor

A fit-out contractor may be relevant to Luxury retail depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-retail-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fit-out contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator or workshop

A fabricator or workshop may be relevant to Luxury retail depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-retail-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator or workshop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: design-and-build contractor

A design-and-build contractor may be relevant to Luxury retail depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-retail-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "design-and-build contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer

This supplier type can participate in Luxury retail only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-retail-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Luxury retail only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-retail-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — specialist installer

This supplier type can participate in Luxury retail only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-retail-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "specialist installer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fit-out contractor

This supplier type can participate in Luxury retail only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-retail-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fit-out contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator or workshop

This supplier type can participate in Luxury retail only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-retail-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator or workshop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — design-and-build contractor

This supplier type can participate in Luxury retail only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-retail-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "design-and-build contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — testing/commissioning provider

This supplier type can participate in Luxury retail only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-retail-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "testing/commissioning provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance provider

This supplier type can participate in Luxury retail only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-retail-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer

Before routing a Luxury retail inquiry to a manufacturer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-retail-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "manufacturer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Luxury retail inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-retail-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — specialist installer

Before routing a Luxury retail inquiry to a specialist installer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-retail-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "specialist installer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fit-out contractor

Before routing a Luxury retail inquiry to a fit-out contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-retail-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "fit-out contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator or workshop

Before routing a Luxury retail inquiry to a fabricator or workshop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-retail-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "fabricator or workshop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — design-and-build contractor

Before routing a Luxury retail inquiry to a design-and-build contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-retail-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "design-and-build contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — testing/commissioning provider

Before routing a Luxury retail inquiry to a testing/commissioning provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-retail-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "testing/commissioning provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance provider

Before routing a Luxury retail inquiry to a maintenance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-retail-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "maintenance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Luxury retail should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-retail-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Luxury retail should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-retail-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Luxury retail should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-retail-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Luxury retail should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-retail-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Luxury retail should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-retail-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Luxury retail should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-retail-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Luxury retail should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-retail-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Luxury retail should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-retail-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Luxury retail should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-retail-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Luxury retail should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-retail-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Boq

Boq may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "boq",
  "document_name": "boq",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Architectural Drawings

Architectural Drawings may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "architectural-drawings",
  "document_name": "architectural drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Finish Schedule

Finish Schedule may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "finish-schedule",
  "document_name": "finish schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Shop Drawings

Shop Drawings may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "shop-drawings",
  "document_name": "shop drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Submittal

Material Submittal may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-submittal",
  "document_name": "material submittal",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Sample Or Mock-Up Approval

Sample Or Mock-Up Approval may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "sample-or-mock-up-approval",
  "document_name": "sample or mock-up approval",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement

Method Statement may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement",
  "document_name": "method statement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Plan

Inspection/Test Plan may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-plan",
  "document_name": "inspection/test plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Authority Or Developer Approval

Authority Or Developer Approval may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "authority-or-developer-approval",
  "document_name": "authority or developer approval",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### As-Built Drawings

As-Built Drawings may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "as-built-drawings",
  "document_name": "as-built drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Warranty

Warranty may provide or verify information needed for Luxury retail. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-retail-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "warranty",
  "document_name": "warranty",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Dubai Building Code 2021

For Luxury retail, consult Dubai Building Code 2021 when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-retail-uae_regulations-source_activation-0082`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-DBC-2021

```json
{
  "source_id": "UAE-DM-DBC-2021",
  "publisher": "Dubai Municipality",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Al Sa’fat – Dubai Green Building System

For Luxury retail, consult Al Sa’fat – Dubai Green Building System when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-retail-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-ALSAFAT

```json
{
  "source_id": "UAE-DM-ALSAFAT",
  "publisher": "Dubai Municipality",
  "source_type": "government_sustainability_system",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Fire and Life Safety Code of Practice

For Luxury retail, consult UAE Fire and Life Safety Code of Practice when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-retail-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DCD-FLS

```json
{
  "source_id": "UAE-DCD-FLS",
  "publisher": "Dubai Civil Defence",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Industrial, Standards, Conformity and Quality Services

For Luxury retail, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-retail-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Luxury retail, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-retail-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For Luxury retail, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-retail-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Luxury retail. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-retail-commercial_pricing-cost_driver-0088`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Luxury retail. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-retail-commercial_pricing-cost_driver-0090`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Luxury retail. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-retail-commercial_pricing-cost_driver-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Luxury retail. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-retail-commercial_pricing-cost_driver-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Luxury retail. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-retail-commercial_pricing-cost_driver-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Luxury retail. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-retail-commercial_pricing-cost_driver-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Luxury retail. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-retail-commercial_pricing-cost_driver-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Luxury retail. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-retail-commercial_pricing-cost_driver-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Luxury retail. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-retail-commercial_pricing-cost_driver-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Luxury retail. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-retail-commercial_pricing-cost_driver-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-retail-customer_tradeoffs-tradeoff-0089`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-retail-customer_tradeoffs-tradeoff-0091`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-retail-customer_tradeoffs-tradeoff-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-retail-customer_tradeoffs-tradeoff-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-retail-customer_tradeoffs-tradeoff-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-retail-customer_tradeoffs-tradeoff-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-retail-customer_tradeoffs-tradeoff-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-retail-customer_tradeoffs-tradeoff-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-retail-customer_tradeoffs-tradeoff-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-retail-customer_tradeoffs-tradeoff-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Luxury retail, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-retail-risk-risk_control-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Luxury retail, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-retail-risk-risk_control-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Luxury retail, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-retail-risk-risk_control-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Luxury retail, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-retail-risk-risk_control-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Luxury retail, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-retail-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Luxury retail, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-retail-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Luxury retail, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-retail-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Luxury retail, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-retail-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Luxury retail, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-retail-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Luxury retail, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-retail-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Luxury retail, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-retail-best_practices-qualification_best_practice-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Luxury retail, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-retail-best_practices-qualification_best_practice-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Luxury retail, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-retail-best_practices-qualification_best_practice-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Luxury retail, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-retail-best_practices-qualification_best_practice-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Luxury retail, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-retail-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Luxury retail, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-retail-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Luxury retail; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-retail-troubleshooting-recovery_guidance-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Luxury retail; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-retail-troubleshooting-recovery_guidance-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Luxury retail; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-retail-troubleshooting-recovery_guidance-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Luxury retail; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-retail-troubleshooting-recovery_guidance-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Luxury retail; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-retail-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Luxury retail; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-retail-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Luxury retail; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-retail-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Luxury retail; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-retail-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What area, dimensions, quantities or item schedule applies?

Ask in plain language: What area, dimensions, quantities or item schedule applies? Arabic draft: ما المساحة أو الأبعاد أو الكميات أو جدول العناصر المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-area-dimensions",
  "question_en": "What area, dimensions, quantities or item schedule applies?",
  "question_ar": "ما المساحة أو الأبعاد أو الكميات أو جدول العناصر المطلوب؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "area-dimensions",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What area, dimensions, quantities or item schedule applies? is missing

When the normalized field area-dimensions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-area-dimensions",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "area-dimensions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-area-dimensions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What material, finish, colour, texture or appearance is required?

Ask in plain language: What material, finish, colour, texture or appearance is required? Arabic draft: ما المادة أو التشطيب أو اللون أو الملمس أو المظهر المطلوب؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-material-finish",
  "question_en": "What material, finish, colour, texture or appearance is required?",
  "question_ar": "ما المادة أو التشطيب أو اللون أو الملمس أو المظهر المطلوب؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "material-finish",
  "order": 140,
  "confidence_contribution": 0.012
}
```

### What fire, acoustic, thermal, structural, slip, water or durability performance is required?

Ask in plain language: What fire, acoustic, thermal, structural, slip, water or durability performance is required? Arabic draft: ما متطلبات الحريق أو الصوت أو الحرارة أو الإنشاء أو الانزلاق أو الماء أو المتانة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-performance-rating",
  "question_en": "What fire, acoustic, thermal, structural, slip, water or durability performance is required?",
  "question_ar": "ما متطلبات الحريق أو الصوت أو الحرارة أو الإنشاء أو الانزلاق أو الماء أو المتانة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "performance-rating",
  "order": 150,
  "confidence_contribution": 0.012
}
```

### What substrate, supports, openings and adjacent-system interfaces exist?

Ask in plain language: What substrate, supports, openings and adjacent-system interfaces exist? Arabic draft: ما الأسطح أو الدعامات أو الفتحات أو الواجهات مع الأنظمة المجاورة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-substrate-interfaces",
  "question_en": "What substrate, supports, openings and adjacent-system interfaces exist?",
  "question_ar": "ما الأسطح أو الدعامات أو الفتحات أو الواجهات مع الأنظمة المجاورة؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "substrate-interfaces",
  "order": 160,
  "confidence_contribution": 0.03
}
```

### Ask when What substrate, supports, openings and adjacent-system interfaces exist? is missing

When the normalized field substrate-interfaces is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-substrate-interfaces",
  "priority": 984,
  "when": {
    "all": [
      {
        "field": "substrate-interfaces",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-substrate-interfaces"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site access, work hours, lifting, storage, protection and shutdown constraints apply?

Ask in plain language: What site access, work hours, lifting, storage, protection and shutdown constraints apply? Arabic draft: ما قيود الوصول وساعات العمل والرفع والتخزين والحماية والإيقاف؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-installation-access",
  "question_en": "What site access, work hours, lifting, storage, protection and shutdown constraints apply?",
  "question_ar": "ما قيود الوصول وساعات العمل والرفع والتخزين والحماية والإيقاف؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-access",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What site access, work hours, lifting, storage, protection and shutdown constraints apply? is missing

When the normalized field installation-access is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-installation-access",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "installation-access",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-installation-access"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are samples, mock-ups, shop drawings or material approvals required?

Ask in plain language: Are samples, mock-ups, shop drawings or material approvals required? Arabic draft: هل يلزم عينات أو نموذج تجريبي أو مخططات ورشة أو اعتماد مواد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-samples-mockup",
  "question_en": "Are samples, mock-ups, shop drawings or material approvals required?",
  "question_ar": "هل يلزم عينات أو نموذج تجريبي أو مخططات ورشة أو اعتماد مواد؟",
  "expected_answer_type": "multi_select",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "samples-mockup",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What testing, cleaning, protection, handover and warranty scope is required?

Ask in plain language: What testing, cleaning, protection, handover and warranty scope is required? Arabic draft: ما نطاق الاختبار والتنظيف والحماية والتسليم والضمان المطلوب؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-handover-warranty",
  "question_en": "What testing, cleaning, protection, handover and warranty scope is required?",
  "question_ar": "ما نطاق الاختبار والتنظيف والحماية والتسليم والضمان المطلوب؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "handover-warranty",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### Please clarify the premium material provenance requirements for Luxury retail.

Ask in plain language: Please clarify the premium material provenance requirements for Luxury retail. Arabic draft: يرجى توضيح متطلبات premium material provenance الخاصة بـ Luxury retail. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-facet-01",
  "question_en": "Please clarify the premium material provenance requirements for Luxury retail.",
  "question_ar": "يرجى توضيح متطلبات premium material provenance الخاصة بـ Luxury retail.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the premium material provenance requirements for Luxury retail. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-facet-01",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the bespoke detailing requirements for Luxury retail.

Ask in plain language: Please clarify the bespoke detailing requirements for Luxury retail. Arabic draft: يرجى توضيح متطلبات bespoke detailing الخاصة بـ Luxury retail. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-facet-02",
  "question_en": "Please clarify the bespoke detailing requirements for Luxury retail.",
  "question_ar": "يرجى توضيح متطلبات bespoke detailing الخاصة بـ Luxury retail.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the bespoke detailing requirements for Luxury retail. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-facet-02",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the mock-up quality requirements for Luxury retail.

Ask in plain language: Please clarify the mock-up quality requirements for Luxury retail. Arabic draft: يرجى توضيح متطلبات mock-up quality الخاصة بـ Luxury retail. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-facet-03",
  "question_en": "Please clarify the mock-up quality requirements for Luxury retail.",
  "question_ar": "يرجى توضيح متطلبات mock-up quality الخاصة بـ Luxury retail.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the mock-up quality requirements for Luxury retail. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-facet-03",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the specialist craftsmanship requirements for Luxury retail.

Ask in plain language: Please clarify the specialist craftsmanship requirements for Luxury retail. Arabic draft: يرجى توضيح متطلبات specialist craftsmanship الخاصة بـ Luxury retail. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-facet-04",
  "question_en": "Please clarify the specialist craftsmanship requirements for Luxury retail.",
  "question_ar": "يرجى توضيح متطلبات specialist craftsmanship الخاصة بـ Luxury retail.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 230,
  "confidence_contribution": 0.012
}
```

### Please clarify the brand/design intent requirements for Luxury retail.

Ask in plain language: Please clarify the brand/design intent requirements for Luxury retail. Arabic draft: يرجى توضيح متطلبات brand/design intent الخاصة بـ Luxury retail. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-facet-05",
  "question_en": "Please clarify the brand/design intent requirements for Luxury retail.",
  "question_ar": "يرجى توضيح متطلبات brand/design intent الخاصة بـ Luxury retail.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the long-lead procurement requirements for Luxury retail.

Ask in plain language: Please clarify the long-lead procurement requirements for Luxury retail. Arabic draft: يرجى توضيح متطلبات long-lead procurement الخاصة بـ Luxury retail. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-facet-06",
  "question_en": "Please clarify the long-lead procurement requirements for Luxury retail.",
  "question_ar": "يرجى توضيح متطلبات long-lead procurement الخاصة بـ Luxury retail.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the defect-free handover requirements for Luxury retail.

Ask in plain language: Please clarify the defect-free handover requirements for Luxury retail. Arabic draft: يرجى توضيح متطلبات defect-free handover الخاصة بـ Luxury retail. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-facet-07",
  "question_en": "Please clarify the defect-free handover requirements for Luxury retail.",
  "question_ar": "يرجى توضيح متطلبات defect-free handover الخاصة بـ Luxury retail.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Which exact Luxury retail product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Luxury retail product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Luxury retail التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-exact-subtype",
  "question_en": "Which exact Luxury retail product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Luxury retail التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 270,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Luxury retail product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-ask-exact-subtype",
  "priority": 973,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-retail-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Luxury retail are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Luxury retail are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Luxury retail التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-unknowns",
  "question_en": "Which details about Luxury retail are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Luxury retail التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 280,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Luxury retail?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Luxury retail? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Luxury retail؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-retail-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Luxury retail?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Luxury retail؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Luxury retail, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Luxury retail, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Luxury retail, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Luxury retail, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0179`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS, UAE-MOIAT, ISO-STANDARDS, ASTM-STANDARDS

```json
{
  "rule_id": "R-009-luxury-retail-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-DM-DBC-2021",
        "UAE-DM-ALSAFAT",
        "UAE-DCD-FLS",
        "UAE-MOIAT",
        "ISO-STANDARDS",
        "ASTM-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Luxury retail, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Luxury retail, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Luxury retail, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Luxury retail, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-retail-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-retail-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Luxury retail, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-retail-validation-validation_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-retail-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Luxury retail, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-retail-validation-validation_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-retail-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Luxury retail, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-retail-validation-validation_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-retail-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Luxury retail, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-retail-validation-validation_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-retail-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Luxury retail, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-retail-validation-validation_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-retail-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Luxury retail, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-retail-validation-validation_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-retail-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Luxury retail, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-retail-validation-validation_rule-0190`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "validation_id": "V-009-luxury-retail-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Luxury retail, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-retail-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-retail-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Luxury retail, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-retail-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-retail-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Luxury retail, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-retail-validation-validation_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-retail-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Luxury retail without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-retail-scenario_test-scenario-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-retail-001",
  "setup": "Customer asks informally for Luxury retail without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Luxury retail with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-retail-scenario_test-scenario-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-retail-002",
  "setup": "Customer requests price for Luxury retail with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Luxury retail. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-retail-scenario_test-scenario-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-retail-003",
  "setup": "Customer uploads a relevant schedule/specification for Luxury retail.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Luxury retail. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-retail-scenario_test-scenario-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-retail-004",
  "setup": "Customer message and uploaded document disagree on Luxury retail.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Luxury retail. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-retail-scenario_test-scenario-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-retail-005",
  "setup": "Supplier proposes a different product, provider or method for Luxury retail.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Luxury retail sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-retail-scenario_test-scenario-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-retail-006",
  "setup": "Customer needs Luxury retail sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Luxury retail needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-retail-scenario_test-scenario-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-retail-007",
  "setup": "The request for Luxury retail needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Luxury retail

English term: Luxury retail. Arabic operational draft: متطلبات Luxury retail. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Luxury retail",
  "term_ar": "متطلبات Luxury retail",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### premium material provenance

English term: premium material provenance. Arabic operational draft: متطلبات premium material provenance. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "premium material provenance",
  "term_ar": "متطلبات premium material provenance",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### bespoke detailing

English term: bespoke detailing. Arabic operational draft: متطلبات bespoke detailing. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "bespoke detailing",
  "term_ar": "متطلبات bespoke detailing",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### mock-up quality

English term: mock-up quality. Arabic operational draft: متطلبات mock-up quality. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mock-up quality",
  "term_ar": "متطلبات mock-up quality",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### specialist craftsmanship

English term: specialist craftsmanship. Arabic operational draft: متطلبات specialist craftsmanship. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "specialist craftsmanship",
  "term_ar": "متطلبات specialist craftsmanship",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### brand/design intent

English term: brand/design intent. Arabic operational draft: متطلبات brand/design intent. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "brand/design intent",
  "term_ar": "متطلبات brand/design intent",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### long-lead procurement

English term: long-lead procurement. Arabic operational draft: متطلبات long-lead procurement. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "long-lead procurement",
  "term_ar": "متطلبات long-lead procurement",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```

### defect-free handover

English term: defect-free handover. Arabic operational draft: متطلبات defect-free handover. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-retail-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "defect-free handover",
  "term_ar": "متطلبات defect-free handover",
  "canonical_subcategory": "luxury-retail",
  "normalization_only": true
}
```


# 3. Luxury hotels

**Arabic draft:** متطلبات Luxury hotels
**Slug:** `luxury-hotels`
**Aliases:** Luxury hotels

## Industry

### Industry scope — Luxury hotels

Luxury hotels is treated as a distinct procurement route within Luxury Fit-Out. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers physical products, building systems, finishes, installation and project handover. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-009-luxury-hotels-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS

```json
{
  "category": "Luxury Fit-Out",
  "subcategory": "Luxury hotels",
  "profile": "building",
  "aliases": [
    "Luxury hotels"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Luxury hotels

A normal UAE sourcing workflow for Luxury hotels moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-009-luxury-hotels-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS, UAE-MOIAT

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Luxury hotels

Customers may describe Luxury hotels through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-009-luxury-hotels-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Luxury hotels

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-009-luxury-hotels-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Luxury hotels product or service

The primary deliverable requested within Luxury hotels; exact type, quantity, performance, scope and acceptance must be normalized. For Luxury hotels, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-hotels-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Luxury hotels",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Luxury hotels

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Luxury hotels, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-hotels-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Luxury hotels",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Luxury hotels

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Luxury hotels, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-hotels-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Luxury hotels",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Luxury hotels

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Luxury hotels, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-hotels-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Luxury hotels",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Luxury hotels

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Luxury hotels, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-hotels-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Luxury hotels",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Luxury hotels

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Luxury hotels, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-hotels-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Luxury hotels",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Luxury hotels

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Luxury hotels, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-hotels-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Luxury hotels",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Luxury hotels

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Luxury hotels, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-luxury-hotels-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Luxury hotels",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Premium Material Provenance scope component

Premium Material Provenance is a recurring scope component for Luxury hotels. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-hotels-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "premium material provenance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Bespoke Detailing scope component

Bespoke Detailing is a recurring scope component for Luxury hotels. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-hotels-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "bespoke detailing",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Mock-Up Quality scope component

Mock-Up Quality is a recurring scope component for Luxury hotels. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-hotels-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "mock-up quality",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Specialist Craftsmanship scope component

Specialist Craftsmanship is a recurring scope component for Luxury hotels. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-hotels-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "specialist craftsmanship",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Brand/Design Intent scope component

Brand/Design Intent is a recurring scope component for Luxury hotels. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-hotels-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "brand/design intent",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Long-Lead Procurement scope component

Long-Lead Procurement is a recurring scope component for Luxury hotels. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-hotels-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "long-lead procurement",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Defect-Free Handover scope component

Defect-Free Handover is a recurring scope component for Luxury hotels. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-luxury-hotels-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "defect-free handover",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: material or system type

For Luxury hotels, material or system type must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "material or system type",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: dimensions and quantity basis

For Luxury hotels, dimensions and quantity basis must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "dimensions and quantity basis",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: performance rating

For Luxury hotels, performance rating must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "performance rating",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: finish and visual requirement

For Luxury hotels, finish and visual requirement must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "finish and visual requirement",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: substrate or supporting structure

For Luxury hotels, substrate or supporting structure must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "substrate or supporting structure",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces with adjacent systems

For Luxury hotels, interfaces with adjacent systems must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces with adjacent systems",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation method and access

For Luxury hotels, installation method and access must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation method and access",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environmental exposure

For Luxury hotels, environmental exposure must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environmental exposure",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: testing and acceptance

For Luxury hotels, testing and acceptance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "testing and acceptance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: warranty and maintenance

For Luxury hotels, warranty and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "warranty and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: premium material provenance

For Luxury hotels, premium material provenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "premium material provenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: bespoke detailing

For Luxury hotels, bespoke detailing must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "bespoke detailing",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: mock-up quality

For Luxury hotels, mock-up quality must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "mock-up quality",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: specialist craftsmanship

For Luxury hotels, specialist craftsmanship must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "specialist craftsmanship",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: brand/design intent

For Luxury hotels, brand/design intent must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "brand/design intent",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: long-lead procurement

For Luxury hotels, long-lead procurement must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "long-lead procurement",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: defect-free handover

For Luxury hotels, defect-free handover must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-luxury-hotels-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "defect-free handover",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer

A manufacturer may be relevant to Luxury hotels depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-hotels-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Luxury hotels depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-hotels-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: specialist installer

A specialist installer may be relevant to Luxury hotels depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-hotels-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "specialist installer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fit-out contractor

A fit-out contractor may be relevant to Luxury hotels depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-hotels-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fit-out contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator or workshop

A fabricator or workshop may be relevant to Luxury hotels depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-hotels-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator or workshop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: design-and-build contractor

A design-and-build contractor may be relevant to Luxury hotels depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-luxury-hotels-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "design-and-build contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer

This supplier type can participate in Luxury hotels only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-hotels-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Luxury hotels only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-hotels-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — specialist installer

This supplier type can participate in Luxury hotels only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-hotels-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "specialist installer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fit-out contractor

This supplier type can participate in Luxury hotels only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-hotels-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fit-out contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator or workshop

This supplier type can participate in Luxury hotels only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-hotels-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator or workshop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — design-and-build contractor

This supplier type can participate in Luxury hotels only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-hotels-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "design-and-build contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — testing/commissioning provider

This supplier type can participate in Luxury hotels only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-hotels-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "testing/commissioning provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance provider

This supplier type can participate in Luxury hotels only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-luxury-hotels-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer

Before routing a Luxury hotels inquiry to a manufacturer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-hotels-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "manufacturer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Luxury hotels inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-hotels-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — specialist installer

Before routing a Luxury hotels inquiry to a specialist installer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-hotels-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "specialist installer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fit-out contractor

Before routing a Luxury hotels inquiry to a fit-out contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-hotels-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "fit-out contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator or workshop

Before routing a Luxury hotels inquiry to a fabricator or workshop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-hotels-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "fabricator or workshop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — design-and-build contractor

Before routing a Luxury hotels inquiry to a design-and-build contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-hotels-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "design-and-build contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — testing/commissioning provider

Before routing a Luxury hotels inquiry to a testing/commissioning provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-hotels-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "testing/commissioning provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance provider

Before routing a Luxury hotels inquiry to a maintenance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-luxury-hotels-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "maintenance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Luxury hotels should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-hotels-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Luxury hotels should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-hotels-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Luxury hotels should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-hotels-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Luxury hotels should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-hotels-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Luxury hotels should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-hotels-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Luxury hotels should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-hotels-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Luxury hotels should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-hotels-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Luxury hotels should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-hotels-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Luxury hotels should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-hotels-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Luxury hotels should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-luxury-hotels-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Boq

Boq may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "boq",
  "document_name": "boq",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Architectural Drawings

Architectural Drawings may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "architectural-drawings",
  "document_name": "architectural drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Finish Schedule

Finish Schedule may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "finish-schedule",
  "document_name": "finish schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Shop Drawings

Shop Drawings may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "shop-drawings",
  "document_name": "shop drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Submittal

Material Submittal may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-submittal",
  "document_name": "material submittal",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Sample Or Mock-Up Approval

Sample Or Mock-Up Approval may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "sample-or-mock-up-approval",
  "document_name": "sample or mock-up approval",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement

Method Statement may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement",
  "document_name": "method statement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Plan

Inspection/Test Plan may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-plan",
  "document_name": "inspection/test plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Authority Or Developer Approval

Authority Or Developer Approval may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "authority-or-developer-approval",
  "document_name": "authority or developer approval",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### As-Built Drawings

As-Built Drawings may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "as-built-drawings",
  "document_name": "as-built drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Warranty

Warranty may provide or verify information needed for Luxury hotels. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-luxury-hotels-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "warranty",
  "document_name": "warranty",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Dubai Building Code 2021

For Luxury hotels, consult Dubai Building Code 2021 when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-hotels-uae_regulations-source_activation-0082`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-DBC-2021

```json
{
  "source_id": "UAE-DM-DBC-2021",
  "publisher": "Dubai Municipality",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Al Sa’fat – Dubai Green Building System

For Luxury hotels, consult Al Sa’fat – Dubai Green Building System when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-hotels-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-ALSAFAT

```json
{
  "source_id": "UAE-DM-ALSAFAT",
  "publisher": "Dubai Municipality",
  "source_type": "government_sustainability_system",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Fire and Life Safety Code of Practice

For Luxury hotels, consult UAE Fire and Life Safety Code of Practice when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-hotels-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DCD-FLS

```json
{
  "source_id": "UAE-DCD-FLS",
  "publisher": "Dubai Civil Defence",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Industrial, Standards, Conformity and Quality Services

For Luxury hotels, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-hotels-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Luxury hotels, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-hotels-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For Luxury hotels, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-luxury-hotels-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Luxury hotels. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-hotels-commercial_pricing-cost_driver-0088`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Luxury hotels. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-hotels-commercial_pricing-cost_driver-0090`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Luxury hotels. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-hotels-commercial_pricing-cost_driver-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Luxury hotels. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-hotels-commercial_pricing-cost_driver-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Luxury hotels. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-hotels-commercial_pricing-cost_driver-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Luxury hotels. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-hotels-commercial_pricing-cost_driver-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Luxury hotels. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-hotels-commercial_pricing-cost_driver-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Luxury hotels. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-hotels-commercial_pricing-cost_driver-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Luxury hotels. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-hotels-commercial_pricing-cost_driver-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Luxury hotels. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-luxury-hotels-commercial_pricing-cost_driver-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-hotels-customer_tradeoffs-tradeoff-0089`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-hotels-customer_tradeoffs-tradeoff-0091`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-hotels-customer_tradeoffs-tradeoff-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-hotels-customer_tradeoffs-tradeoff-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-hotels-customer_tradeoffs-tradeoff-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-hotels-customer_tradeoffs-tradeoff-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-hotels-customer_tradeoffs-tradeoff-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-hotels-customer_tradeoffs-tradeoff-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-hotels-customer_tradeoffs-tradeoff-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-luxury-hotels-customer_tradeoffs-tradeoff-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Luxury hotels, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-hotels-risk-risk_control-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Luxury hotels, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-hotels-risk-risk_control-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Luxury hotels, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-hotels-risk-risk_control-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Luxury hotels, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-hotels-risk-risk_control-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Luxury hotels, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-hotels-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Luxury hotels, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-hotels-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Luxury hotels, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-hotels-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Luxury hotels, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-hotels-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Luxury hotels, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-hotels-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Luxury hotels, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-luxury-hotels-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Luxury hotels, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-hotels-best_practices-qualification_best_practice-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Luxury hotels, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-hotels-best_practices-qualification_best_practice-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Luxury hotels, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-hotels-best_practices-qualification_best_practice-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Luxury hotels, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-hotels-best_practices-qualification_best_practice-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Luxury hotels, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-hotels-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Luxury hotels, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-luxury-hotels-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Luxury hotels; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-hotels-troubleshooting-recovery_guidance-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Luxury hotels; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-hotels-troubleshooting-recovery_guidance-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Luxury hotels; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-hotels-troubleshooting-recovery_guidance-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Luxury hotels; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-hotels-troubleshooting-recovery_guidance-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Luxury hotels; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-hotels-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Luxury hotels; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-hotels-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Luxury hotels; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-hotels-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Luxury hotels; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-luxury-hotels-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What area, dimensions, quantities or item schedule applies?

Ask in plain language: What area, dimensions, quantities or item schedule applies? Arabic draft: ما المساحة أو الأبعاد أو الكميات أو جدول العناصر المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-area-dimensions",
  "question_en": "What area, dimensions, quantities or item schedule applies?",
  "question_ar": "ما المساحة أو الأبعاد أو الكميات أو جدول العناصر المطلوب؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "area-dimensions",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What area, dimensions, quantities or item schedule applies? is missing

When the normalized field area-dimensions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-area-dimensions",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "area-dimensions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-area-dimensions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What material, finish, colour, texture or appearance is required?

Ask in plain language: What material, finish, colour, texture or appearance is required? Arabic draft: ما المادة أو التشطيب أو اللون أو الملمس أو المظهر المطلوب؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-material-finish",
  "question_en": "What material, finish, colour, texture or appearance is required?",
  "question_ar": "ما المادة أو التشطيب أو اللون أو الملمس أو المظهر المطلوب؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "material-finish",
  "order": 140,
  "confidence_contribution": 0.012
}
```

### What fire, acoustic, thermal, structural, slip, water or durability performance is required?

Ask in plain language: What fire, acoustic, thermal, structural, slip, water or durability performance is required? Arabic draft: ما متطلبات الحريق أو الصوت أو الحرارة أو الإنشاء أو الانزلاق أو الماء أو المتانة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-performance-rating",
  "question_en": "What fire, acoustic, thermal, structural, slip, water or durability performance is required?",
  "question_ar": "ما متطلبات الحريق أو الصوت أو الحرارة أو الإنشاء أو الانزلاق أو الماء أو المتانة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "performance-rating",
  "order": 150,
  "confidence_contribution": 0.012
}
```

### What substrate, supports, openings and adjacent-system interfaces exist?

Ask in plain language: What substrate, supports, openings and adjacent-system interfaces exist? Arabic draft: ما الأسطح أو الدعامات أو الفتحات أو الواجهات مع الأنظمة المجاورة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-substrate-interfaces",
  "question_en": "What substrate, supports, openings and adjacent-system interfaces exist?",
  "question_ar": "ما الأسطح أو الدعامات أو الفتحات أو الواجهات مع الأنظمة المجاورة؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "substrate-interfaces",
  "order": 160,
  "confidence_contribution": 0.03
}
```

### Ask when What substrate, supports, openings and adjacent-system interfaces exist? is missing

When the normalized field substrate-interfaces is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-substrate-interfaces",
  "priority": 984,
  "when": {
    "all": [
      {
        "field": "substrate-interfaces",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-substrate-interfaces"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site access, work hours, lifting, storage, protection and shutdown constraints apply?

Ask in plain language: What site access, work hours, lifting, storage, protection and shutdown constraints apply? Arabic draft: ما قيود الوصول وساعات العمل والرفع والتخزين والحماية والإيقاف؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-installation-access",
  "question_en": "What site access, work hours, lifting, storage, protection and shutdown constraints apply?",
  "question_ar": "ما قيود الوصول وساعات العمل والرفع والتخزين والحماية والإيقاف؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-access",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What site access, work hours, lifting, storage, protection and shutdown constraints apply? is missing

When the normalized field installation-access is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-installation-access",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "installation-access",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-installation-access"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are samples, mock-ups, shop drawings or material approvals required?

Ask in plain language: Are samples, mock-ups, shop drawings or material approvals required? Arabic draft: هل يلزم عينات أو نموذج تجريبي أو مخططات ورشة أو اعتماد مواد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-samples-mockup",
  "question_en": "Are samples, mock-ups, shop drawings or material approvals required?",
  "question_ar": "هل يلزم عينات أو نموذج تجريبي أو مخططات ورشة أو اعتماد مواد؟",
  "expected_answer_type": "multi_select",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "samples-mockup",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What testing, cleaning, protection, handover and warranty scope is required?

Ask in plain language: What testing, cleaning, protection, handover and warranty scope is required? Arabic draft: ما نطاق الاختبار والتنظيف والحماية والتسليم والضمان المطلوب؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-handover-warranty",
  "question_en": "What testing, cleaning, protection, handover and warranty scope is required?",
  "question_ar": "ما نطاق الاختبار والتنظيف والحماية والتسليم والضمان المطلوب؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "handover-warranty",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### Please clarify the premium material provenance requirements for Luxury hotels.

Ask in plain language: Please clarify the premium material provenance requirements for Luxury hotels. Arabic draft: يرجى توضيح متطلبات premium material provenance الخاصة بـ Luxury hotels. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-facet-01",
  "question_en": "Please clarify the premium material provenance requirements for Luxury hotels.",
  "question_ar": "يرجى توضيح متطلبات premium material provenance الخاصة بـ Luxury hotels.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the premium material provenance requirements for Luxury hotels. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-facet-01",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the bespoke detailing requirements for Luxury hotels.

Ask in plain language: Please clarify the bespoke detailing requirements for Luxury hotels. Arabic draft: يرجى توضيح متطلبات bespoke detailing الخاصة بـ Luxury hotels. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-facet-02",
  "question_en": "Please clarify the bespoke detailing requirements for Luxury hotels.",
  "question_ar": "يرجى توضيح متطلبات bespoke detailing الخاصة بـ Luxury hotels.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the bespoke detailing requirements for Luxury hotels. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-facet-02",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the mock-up quality requirements for Luxury hotels.

Ask in plain language: Please clarify the mock-up quality requirements for Luxury hotels. Arabic draft: يرجى توضيح متطلبات mock-up quality الخاصة بـ Luxury hotels. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-facet-03",
  "question_en": "Please clarify the mock-up quality requirements for Luxury hotels.",
  "question_ar": "يرجى توضيح متطلبات mock-up quality الخاصة بـ Luxury hotels.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the mock-up quality requirements for Luxury hotels. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-facet-03",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the specialist craftsmanship requirements for Luxury hotels.

Ask in plain language: Please clarify the specialist craftsmanship requirements for Luxury hotels. Arabic draft: يرجى توضيح متطلبات specialist craftsmanship الخاصة بـ Luxury hotels. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-facet-04",
  "question_en": "Please clarify the specialist craftsmanship requirements for Luxury hotels.",
  "question_ar": "يرجى توضيح متطلبات specialist craftsmanship الخاصة بـ Luxury hotels.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 230,
  "confidence_contribution": 0.012
}
```

### Please clarify the brand/design intent requirements for Luxury hotels.

Ask in plain language: Please clarify the brand/design intent requirements for Luxury hotels. Arabic draft: يرجى توضيح متطلبات brand/design intent الخاصة بـ Luxury hotels. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-facet-05",
  "question_en": "Please clarify the brand/design intent requirements for Luxury hotels.",
  "question_ar": "يرجى توضيح متطلبات brand/design intent الخاصة بـ Luxury hotels.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the long-lead procurement requirements for Luxury hotels.

Ask in plain language: Please clarify the long-lead procurement requirements for Luxury hotels. Arabic draft: يرجى توضيح متطلبات long-lead procurement الخاصة بـ Luxury hotels. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-facet-06",
  "question_en": "Please clarify the long-lead procurement requirements for Luxury hotels.",
  "question_ar": "يرجى توضيح متطلبات long-lead procurement الخاصة بـ Luxury hotels.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the defect-free handover requirements for Luxury hotels.

Ask in plain language: Please clarify the defect-free handover requirements for Luxury hotels. Arabic draft: يرجى توضيح متطلبات defect-free handover الخاصة بـ Luxury hotels. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-facet-07",
  "question_en": "Please clarify the defect-free handover requirements for Luxury hotels.",
  "question_ar": "يرجى توضيح متطلبات defect-free handover الخاصة بـ Luxury hotels.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Which exact Luxury hotels product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Luxury hotels product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Luxury hotels التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-exact-subtype",
  "question_en": "Which exact Luxury hotels product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Luxury hotels التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 270,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Luxury hotels product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-ask-exact-subtype",
  "priority": 973,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-luxury-hotels-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Luxury hotels are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Luxury hotels are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Luxury hotels التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-unknowns",
  "question_en": "Which details about Luxury hotels are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Luxury hotels التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 280,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Luxury hotels?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Luxury hotels? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Luxury hotels؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-luxury-hotels-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Luxury hotels?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Luxury hotels؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Luxury hotels, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Luxury hotels, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Luxury hotels, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Luxury hotels, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0179`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS, UAE-MOIAT, ISO-STANDARDS, ASTM-STANDARDS

```json
{
  "rule_id": "R-009-luxury-hotels-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-DM-DBC-2021",
        "UAE-DM-ALSAFAT",
        "UAE-DCD-FLS",
        "UAE-MOIAT",
        "ISO-STANDARDS",
        "ASTM-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Luxury hotels, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Luxury hotels, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Luxury hotels, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Luxury hotels, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-luxury-hotels-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-luxury-hotels-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Luxury hotels, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-hotels-validation-validation_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-hotels-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Luxury hotels, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-hotels-validation-validation_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-hotels-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Luxury hotels, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-hotels-validation-validation_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-hotels-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Luxury hotels, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-hotels-validation-validation_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-hotels-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Luxury hotels, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-hotels-validation-validation_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-hotels-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Luxury hotels, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-hotels-validation-validation_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-hotels-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Luxury hotels, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-hotels-validation-validation_rule-0190`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "validation_id": "V-009-luxury-hotels-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Luxury hotels, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-hotels-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-hotels-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Luxury hotels, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-hotels-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-hotels-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Luxury hotels, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-luxury-hotels-validation-validation_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-luxury-hotels-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Luxury hotels without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-hotels-scenario_test-scenario-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-hotels-001",
  "setup": "Customer asks informally for Luxury hotels without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Luxury hotels with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-hotels-scenario_test-scenario-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-hotels-002",
  "setup": "Customer requests price for Luxury hotels with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Luxury hotels. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-hotels-scenario_test-scenario-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-hotels-003",
  "setup": "Customer uploads a relevant schedule/specification for Luxury hotels.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Luxury hotels. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-hotels-scenario_test-scenario-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-hotels-004",
  "setup": "Customer message and uploaded document disagree on Luxury hotels.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Luxury hotels. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-hotels-scenario_test-scenario-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-hotels-005",
  "setup": "Supplier proposes a different product, provider or method for Luxury hotels.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Luxury hotels sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-hotels-scenario_test-scenario-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-hotels-006",
  "setup": "Customer needs Luxury hotels sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Luxury hotels needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-luxury-hotels-scenario_test-scenario-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-luxury-hotels-007",
  "setup": "The request for Luxury hotels needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Luxury hotels

English term: Luxury hotels. Arabic operational draft: متطلبات Luxury hotels. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Luxury hotels",
  "term_ar": "متطلبات Luxury hotels",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### premium material provenance

English term: premium material provenance. Arabic operational draft: متطلبات premium material provenance. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "premium material provenance",
  "term_ar": "متطلبات premium material provenance",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### bespoke detailing

English term: bespoke detailing. Arabic operational draft: متطلبات bespoke detailing. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "bespoke detailing",
  "term_ar": "متطلبات bespoke detailing",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### mock-up quality

English term: mock-up quality. Arabic operational draft: متطلبات mock-up quality. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mock-up quality",
  "term_ar": "متطلبات mock-up quality",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### specialist craftsmanship

English term: specialist craftsmanship. Arabic operational draft: متطلبات specialist craftsmanship. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "specialist craftsmanship",
  "term_ar": "متطلبات specialist craftsmanship",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### brand/design intent

English term: brand/design intent. Arabic operational draft: متطلبات brand/design intent. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "brand/design intent",
  "term_ar": "متطلبات brand/design intent",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### long-lead procurement

English term: long-lead procurement. Arabic operational draft: متطلبات long-lead procurement. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "long-lead procurement",
  "term_ar": "متطلبات long-lead procurement",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```

### defect-free handover

English term: defect-free handover. Arabic operational draft: متطلبات defect-free handover. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-luxury-hotels-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "defect-free handover",
  "term_ar": "متطلبات defect-free handover",
  "canonical_subcategory": "luxury-hotels",
  "normalization_only": true
}
```


# 4. Palaces

**Arabic draft:** متطلبات Palaces
**Slug:** `palaces`
**Aliases:** Palaces

## Industry

### Industry scope — Palaces

Palaces is treated as a distinct procurement route within Luxury Fit-Out. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers physical products, building systems, finishes, installation and project handover. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-009-palaces-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS

```json
{
  "category": "Luxury Fit-Out",
  "subcategory": "Palaces",
  "profile": "building",
  "aliases": [
    "Palaces"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Palaces

A normal UAE sourcing workflow for Palaces moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-009-palaces-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS, UAE-MOIAT

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Palaces

Customers may describe Palaces through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-009-palaces-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Palaces

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-009-palaces-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Palaces product or service

The primary deliverable requested within Palaces; exact type, quantity, performance, scope and acceptance must be normalized. For Palaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-palaces-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Palaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Palaces

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Palaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-palaces-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Palaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Palaces

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Palaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-palaces-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Palaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Palaces

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Palaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-palaces-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Palaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Palaces

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Palaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-palaces-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Palaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Palaces

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Palaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-palaces-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Palaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Palaces

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Palaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-palaces-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Palaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Palaces

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Palaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-009-palaces-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Palaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Premium Material Provenance scope component

Premium Material Provenance is a recurring scope component for Palaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-palaces-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "premium material provenance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Bespoke Detailing scope component

Bespoke Detailing is a recurring scope component for Palaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-palaces-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "bespoke detailing",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Mock-Up Quality scope component

Mock-Up Quality is a recurring scope component for Palaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-palaces-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "mock-up quality",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Specialist Craftsmanship scope component

Specialist Craftsmanship is a recurring scope component for Palaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-palaces-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "specialist craftsmanship",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Brand/Design Intent scope component

Brand/Design Intent is a recurring scope component for Palaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-palaces-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "brand/design intent",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Long-Lead Procurement scope component

Long-Lead Procurement is a recurring scope component for Palaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-palaces-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "long-lead procurement",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Defect-Free Handover scope component

Defect-Free Handover is a recurring scope component for Palaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-009-palaces-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "defect-free handover",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: material or system type

For Palaces, material or system type must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "material or system type",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: dimensions and quantity basis

For Palaces, dimensions and quantity basis must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "dimensions and quantity basis",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: performance rating

For Palaces, performance rating must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "performance rating",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: finish and visual requirement

For Palaces, finish and visual requirement must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "finish and visual requirement",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: substrate or supporting structure

For Palaces, substrate or supporting structure must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "substrate or supporting structure",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces with adjacent systems

For Palaces, interfaces with adjacent systems must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces with adjacent systems",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation method and access

For Palaces, installation method and access must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation method and access",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environmental exposure

For Palaces, environmental exposure must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environmental exposure",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: testing and acceptance

For Palaces, testing and acceptance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "testing and acceptance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: warranty and maintenance

For Palaces, warranty and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "warranty and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: premium material provenance

For Palaces, premium material provenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "premium material provenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: bespoke detailing

For Palaces, bespoke detailing must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "bespoke detailing",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: mock-up quality

For Palaces, mock-up quality must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "mock-up quality",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: specialist craftsmanship

For Palaces, specialist craftsmanship must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "specialist craftsmanship",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: brand/design intent

For Palaces, brand/design intent must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "brand/design intent",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: long-lead procurement

For Palaces, long-lead procurement must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "long-lead procurement",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: defect-free handover

For Palaces, defect-free handover must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-009-palaces-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "defect-free handover",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer

A manufacturer may be relevant to Palaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-palaces-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Palaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-palaces-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: specialist installer

A specialist installer may be relevant to Palaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-palaces-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "specialist installer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fit-out contractor

A fit-out contractor may be relevant to Palaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-palaces-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fit-out contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator or workshop

A fabricator or workshop may be relevant to Palaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-palaces-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator or workshop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: design-and-build contractor

A design-and-build contractor may be relevant to Palaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-009-palaces-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "design-and-build contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer

This supplier type can participate in Palaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-palaces-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Palaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-palaces-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — specialist installer

This supplier type can participate in Palaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-palaces-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "specialist installer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fit-out contractor

This supplier type can participate in Palaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-palaces-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fit-out contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator or workshop

This supplier type can participate in Palaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-palaces-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator or workshop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — design-and-build contractor

This supplier type can participate in Palaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-palaces-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "design-and-build contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — testing/commissioning provider

This supplier type can participate in Palaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-palaces-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "testing/commissioning provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance provider

This supplier type can participate in Palaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-009-palaces-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer

Before routing a Palaces inquiry to a manufacturer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-palaces-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "manufacturer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Palaces inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-palaces-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — specialist installer

Before routing a Palaces inquiry to a specialist installer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-palaces-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "specialist installer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fit-out contractor

Before routing a Palaces inquiry to a fit-out contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-palaces-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "fit-out contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator or workshop

Before routing a Palaces inquiry to a fabricator or workshop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-palaces-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "fabricator or workshop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — design-and-build contractor

Before routing a Palaces inquiry to a design-and-build contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-palaces-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "design-and-build contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — testing/commissioning provider

Before routing a Palaces inquiry to a testing/commissioning provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-palaces-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "testing/commissioning provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance provider

Before routing a Palaces inquiry to a maintenance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-009-palaces-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "supplier_type": "maintenance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Palaces should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-palaces-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Palaces should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-palaces-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Palaces should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-palaces-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Palaces should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-palaces-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Palaces should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-palaces-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Palaces should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-palaces-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Palaces should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-palaces-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Palaces should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-palaces-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Palaces should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-palaces-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Palaces should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-009-palaces-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Boq

Boq may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "boq",
  "document_name": "boq",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Architectural Drawings

Architectural Drawings may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "architectural-drawings",
  "document_name": "architectural drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Finish Schedule

Finish Schedule may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "finish-schedule",
  "document_name": "finish schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Shop Drawings

Shop Drawings may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "shop-drawings",
  "document_name": "shop drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Submittal

Material Submittal may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-submittal",
  "document_name": "material submittal",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Sample Or Mock-Up Approval

Sample Or Mock-Up Approval may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "sample-or-mock-up-approval",
  "document_name": "sample or mock-up approval",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement

Method Statement may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement",
  "document_name": "method statement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Plan

Inspection/Test Plan may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-plan",
  "document_name": "inspection/test plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Authority Or Developer Approval

Authority Or Developer Approval may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "authority-or-developer-approval",
  "document_name": "authority or developer approval",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### As-Built Drawings

As-Built Drawings may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "as-built-drawings",
  "document_name": "as-built drawings",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Warranty

Warranty may provide or verify information needed for Palaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-009-palaces-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "warranty",
  "document_name": "warranty",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Dubai Building Code 2021

For Palaces, consult Dubai Building Code 2021 when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-palaces-uae_regulations-source_activation-0082`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-DBC-2021

```json
{
  "source_id": "UAE-DM-DBC-2021",
  "publisher": "Dubai Municipality",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Al Sa’fat – Dubai Green Building System

For Palaces, consult Al Sa’fat – Dubai Green Building System when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-palaces-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-ALSAFAT

```json
{
  "source_id": "UAE-DM-ALSAFAT",
  "publisher": "Dubai Municipality",
  "source_type": "government_sustainability_system",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Fire and Life Safety Code of Practice

For Palaces, consult UAE Fire and Life Safety Code of Practice when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-palaces-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DCD-FLS

```json
{
  "source_id": "UAE-DCD-FLS",
  "publisher": "Dubai Civil Defence",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Industrial, Standards, Conformity and Quality Services

For Palaces, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-palaces-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Palaces, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-palaces-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For Palaces, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-009-palaces-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Palaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-palaces-commercial_pricing-cost_driver-0088`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Palaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-palaces-commercial_pricing-cost_driver-0090`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Palaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-palaces-commercial_pricing-cost_driver-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Palaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-palaces-commercial_pricing-cost_driver-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Palaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-palaces-commercial_pricing-cost_driver-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Palaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-palaces-commercial_pricing-cost_driver-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Palaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-palaces-commercial_pricing-cost_driver-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Palaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-palaces-commercial_pricing-cost_driver-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Palaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-palaces-commercial_pricing-cost_driver-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Palaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-009-palaces-commercial_pricing-cost_driver-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-palaces-customer_tradeoffs-tradeoff-0089`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-palaces-customer_tradeoffs-tradeoff-0091`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-palaces-customer_tradeoffs-tradeoff-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-palaces-customer_tradeoffs-tradeoff-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-palaces-customer_tradeoffs-tradeoff-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-palaces-customer_tradeoffs-tradeoff-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-palaces-customer_tradeoffs-tradeoff-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-palaces-customer_tradeoffs-tradeoff-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-palaces-customer_tradeoffs-tradeoff-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-009-palaces-customer_tradeoffs-tradeoff-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Palaces, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-palaces-risk-risk_control-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Palaces, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-palaces-risk-risk_control-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Palaces, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-palaces-risk-risk_control-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Palaces, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-palaces-risk-risk_control-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Palaces, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-palaces-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Palaces, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-palaces-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Palaces, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-palaces-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Palaces, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-palaces-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Palaces, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-palaces-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Palaces, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-009-palaces-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Palaces, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-palaces-best_practices-qualification_best_practice-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Palaces, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-palaces-best_practices-qualification_best_practice-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Palaces, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-palaces-best_practices-qualification_best_practice-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Palaces, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-palaces-best_practices-qualification_best_practice-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Palaces, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-palaces-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Palaces, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-009-palaces-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Palaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-palaces-troubleshooting-recovery_guidance-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Palaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-palaces-troubleshooting-recovery_guidance-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Palaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-palaces-troubleshooting-recovery_guidance-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Palaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-palaces-troubleshooting-recovery_guidance-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Palaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-palaces-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Palaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-palaces-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Palaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-palaces-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Palaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-009-palaces-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What area, dimensions, quantities or item schedule applies?

Ask in plain language: What area, dimensions, quantities or item schedule applies? Arabic draft: ما المساحة أو الأبعاد أو الكميات أو جدول العناصر المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-area-dimensions",
  "question_en": "What area, dimensions, quantities or item schedule applies?",
  "question_ar": "ما المساحة أو الأبعاد أو الكميات أو جدول العناصر المطلوب؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "area-dimensions",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What area, dimensions, quantities or item schedule applies? is missing

When the normalized field area-dimensions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-area-dimensions",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "area-dimensions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-area-dimensions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What material, finish, colour, texture or appearance is required?

Ask in plain language: What material, finish, colour, texture or appearance is required? Arabic draft: ما المادة أو التشطيب أو اللون أو الملمس أو المظهر المطلوب؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-material-finish",
  "question_en": "What material, finish, colour, texture or appearance is required?",
  "question_ar": "ما المادة أو التشطيب أو اللون أو الملمس أو المظهر المطلوب؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "material-finish",
  "order": 140,
  "confidence_contribution": 0.012
}
```

### What fire, acoustic, thermal, structural, slip, water or durability performance is required?

Ask in plain language: What fire, acoustic, thermal, structural, slip, water or durability performance is required? Arabic draft: ما متطلبات الحريق أو الصوت أو الحرارة أو الإنشاء أو الانزلاق أو الماء أو المتانة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-performance-rating",
  "question_en": "What fire, acoustic, thermal, structural, slip, water or durability performance is required?",
  "question_ar": "ما متطلبات الحريق أو الصوت أو الحرارة أو الإنشاء أو الانزلاق أو الماء أو المتانة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "performance-rating",
  "order": 150,
  "confidence_contribution": 0.012
}
```

### What substrate, supports, openings and adjacent-system interfaces exist?

Ask in plain language: What substrate, supports, openings and adjacent-system interfaces exist? Arabic draft: ما الأسطح أو الدعامات أو الفتحات أو الواجهات مع الأنظمة المجاورة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-substrate-interfaces",
  "question_en": "What substrate, supports, openings and adjacent-system interfaces exist?",
  "question_ar": "ما الأسطح أو الدعامات أو الفتحات أو الواجهات مع الأنظمة المجاورة؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "substrate-interfaces",
  "order": 160,
  "confidence_contribution": 0.03
}
```

### Ask when What substrate, supports, openings and adjacent-system interfaces exist? is missing

When the normalized field substrate-interfaces is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-substrate-interfaces",
  "priority": 984,
  "when": {
    "all": [
      {
        "field": "substrate-interfaces",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-substrate-interfaces"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site access, work hours, lifting, storage, protection and shutdown constraints apply?

Ask in plain language: What site access, work hours, lifting, storage, protection and shutdown constraints apply? Arabic draft: ما قيود الوصول وساعات العمل والرفع والتخزين والحماية والإيقاف؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-installation-access",
  "question_en": "What site access, work hours, lifting, storage, protection and shutdown constraints apply?",
  "question_ar": "ما قيود الوصول وساعات العمل والرفع والتخزين والحماية والإيقاف؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-access",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What site access, work hours, lifting, storage, protection and shutdown constraints apply? is missing

When the normalized field installation-access is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-installation-access",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "installation-access",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-installation-access"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are samples, mock-ups, shop drawings or material approvals required?

Ask in plain language: Are samples, mock-ups, shop drawings or material approvals required? Arabic draft: هل يلزم عينات أو نموذج تجريبي أو مخططات ورشة أو اعتماد مواد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-samples-mockup",
  "question_en": "Are samples, mock-ups, shop drawings or material approvals required?",
  "question_ar": "هل يلزم عينات أو نموذج تجريبي أو مخططات ورشة أو اعتماد مواد؟",
  "expected_answer_type": "multi_select",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "samples-mockup",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What testing, cleaning, protection, handover and warranty scope is required?

Ask in plain language: What testing, cleaning, protection, handover and warranty scope is required? Arabic draft: ما نطاق الاختبار والتنظيف والحماية والتسليم والضمان المطلوب؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-handover-warranty",
  "question_en": "What testing, cleaning, protection, handover and warranty scope is required?",
  "question_ar": "ما نطاق الاختبار والتنظيف والحماية والتسليم والضمان المطلوب؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "handover-warranty",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### Please clarify the premium material provenance requirements for Palaces.

Ask in plain language: Please clarify the premium material provenance requirements for Palaces. Arabic draft: يرجى توضيح متطلبات premium material provenance الخاصة بـ Palaces. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-facet-01",
  "question_en": "Please clarify the premium material provenance requirements for Palaces.",
  "question_ar": "يرجى توضيح متطلبات premium material provenance الخاصة بـ Palaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the premium material provenance requirements for Palaces. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-facet-01",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the bespoke detailing requirements for Palaces.

Ask in plain language: Please clarify the bespoke detailing requirements for Palaces. Arabic draft: يرجى توضيح متطلبات bespoke detailing الخاصة بـ Palaces. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-facet-02",
  "question_en": "Please clarify the bespoke detailing requirements for Palaces.",
  "question_ar": "يرجى توضيح متطلبات bespoke detailing الخاصة بـ Palaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the bespoke detailing requirements for Palaces. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-facet-02",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the mock-up quality requirements for Palaces.

Ask in plain language: Please clarify the mock-up quality requirements for Palaces. Arabic draft: يرجى توضيح متطلبات mock-up quality الخاصة بـ Palaces. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-facet-03",
  "question_en": "Please clarify the mock-up quality requirements for Palaces.",
  "question_ar": "يرجى توضيح متطلبات mock-up quality الخاصة بـ Palaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the mock-up quality requirements for Palaces. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-facet-03",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the specialist craftsmanship requirements for Palaces.

Ask in plain language: Please clarify the specialist craftsmanship requirements for Palaces. Arabic draft: يرجى توضيح متطلبات specialist craftsmanship الخاصة بـ Palaces. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-facet-04",
  "question_en": "Please clarify the specialist craftsmanship requirements for Palaces.",
  "question_ar": "يرجى توضيح متطلبات specialist craftsmanship الخاصة بـ Palaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 230,
  "confidence_contribution": 0.012
}
```

### Please clarify the brand/design intent requirements for Palaces.

Ask in plain language: Please clarify the brand/design intent requirements for Palaces. Arabic draft: يرجى توضيح متطلبات brand/design intent الخاصة بـ Palaces. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-facet-05",
  "question_en": "Please clarify the brand/design intent requirements for Palaces.",
  "question_ar": "يرجى توضيح متطلبات brand/design intent الخاصة بـ Palaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the long-lead procurement requirements for Palaces.

Ask in plain language: Please clarify the long-lead procurement requirements for Palaces. Arabic draft: يرجى توضيح متطلبات long-lead procurement الخاصة بـ Palaces. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-facet-06",
  "question_en": "Please clarify the long-lead procurement requirements for Palaces.",
  "question_ar": "يرجى توضيح متطلبات long-lead procurement الخاصة بـ Palaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the defect-free handover requirements for Palaces.

Ask in plain language: Please clarify the defect-free handover requirements for Palaces. Arabic draft: يرجى توضيح متطلبات defect-free handover الخاصة بـ Palaces. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-facet-07",
  "question_en": "Please clarify the defect-free handover requirements for Palaces.",
  "question_ar": "يرجى توضيح متطلبات defect-free handover الخاصة بـ Palaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Which exact Palaces product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Palaces product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Palaces التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-exact-subtype",
  "question_en": "Which exact Palaces product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Palaces التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 270,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Palaces product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-ask-exact-subtype",
  "priority": 973,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-009-palaces-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Palaces are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Palaces are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Palaces التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-unknowns",
  "question_en": "Which details about Palaces are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Palaces التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 280,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Palaces?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Palaces? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Palaces؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-009-palaces-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Palaces?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Palaces؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Palaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Palaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Palaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Palaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0179`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT, UAE-DCD-FLS, UAE-MOIAT, ISO-STANDARDS, ASTM-STANDARDS

```json
{
  "rule_id": "R-009-palaces-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-DM-DBC-2021",
        "UAE-DM-ALSAFAT",
        "UAE-DCD-FLS",
        "UAE-MOIAT",
        "ISO-STANDARDS",
        "ASTM-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Palaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Palaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Palaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Palaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-009-palaces-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-009-palaces-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Palaces, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-palaces-validation-validation_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-palaces-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Palaces, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-palaces-validation-validation_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-palaces-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Palaces, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-palaces-validation-validation_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-palaces-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Palaces, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-palaces-validation-validation_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-palaces-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Palaces, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-palaces-validation-validation_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-palaces-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Palaces, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-palaces-validation-validation_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-palaces-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Palaces, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-palaces-validation-validation_rule-0190`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-DBC-2021, UAE-DM-ALSAFAT

```json
{
  "validation_id": "V-009-palaces-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Palaces, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-palaces-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-palaces-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Palaces, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-palaces-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-palaces-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Palaces, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-009-palaces-validation-validation_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-009-palaces-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Palaces without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-palaces-scenario_test-scenario-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-palaces-001",
  "setup": "Customer asks informally for Palaces without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Palaces with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-palaces-scenario_test-scenario-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-palaces-002",
  "setup": "Customer requests price for Palaces with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Palaces. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-palaces-scenario_test-scenario-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-palaces-003",
  "setup": "Customer uploads a relevant schedule/specification for Palaces.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Palaces. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-palaces-scenario_test-scenario-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-palaces-004",
  "setup": "Customer message and uploaded document disagree on Palaces.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Palaces. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-palaces-scenario_test-scenario-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-palaces-005",
  "setup": "Supplier proposes a different product, provider or method for Palaces.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Palaces sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-palaces-scenario_test-scenario-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-palaces-006",
  "setup": "Customer needs Palaces sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Palaces needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-009-palaces-scenario_test-scenario-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-009-palaces-007",
  "setup": "The request for Palaces needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Palaces

English term: Palaces. Arabic operational draft: متطلبات Palaces. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Palaces",
  "term_ar": "متطلبات Palaces",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### premium material provenance

English term: premium material provenance. Arabic operational draft: متطلبات premium material provenance. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "premium material provenance",
  "term_ar": "متطلبات premium material provenance",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### bespoke detailing

English term: bespoke detailing. Arabic operational draft: متطلبات bespoke detailing. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "bespoke detailing",
  "term_ar": "متطلبات bespoke detailing",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### mock-up quality

English term: mock-up quality. Arabic operational draft: متطلبات mock-up quality. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mock-up quality",
  "term_ar": "متطلبات mock-up quality",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### specialist craftsmanship

English term: specialist craftsmanship. Arabic operational draft: متطلبات specialist craftsmanship. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "specialist craftsmanship",
  "term_ar": "متطلبات specialist craftsmanship",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### brand/design intent

English term: brand/design intent. Arabic operational draft: متطلبات brand/design intent. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "brand/design intent",
  "term_ar": "متطلبات brand/design intent",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### long-lead procurement

English term: long-lead procurement. Arabic operational draft: متطلبات long-lead procurement. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "long-lead procurement",
  "term_ar": "متطلبات long-lead procurement",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```

### defect-free handover

English term: defect-free handover. Arabic operational draft: متطلبات defect-free handover. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-009-palaces-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "defect-free handover",
  "term_ar": "متطلبات defect-free handover",
  "canonical_subcategory": "palaces",
  "normalization_only": true
}
```
