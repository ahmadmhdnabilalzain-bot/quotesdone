# Claude ingestion — QD-KB-086

Import into staging first. Resolve live catalogue category by `num = 86`, not by an assumed slug. Import taxonomy and sources, then stream JSONL modules. Store questions/rules/validations relationally; embed narrative modules only. Preserve source IDs, version, status and review dates. Run every scenario. Do not mark records approved until UAE vertical-transportation SME and compliance review.
