# QuotesDone Knowledge Pack — Lifts & Escalators

**Status:** Research-complete production draft; not SME or authority approved.

This master is for human review. Runtime ingestion must use the structured JSONL modules and source registry.

# Passenger elevators / مصاعد الركاب

## Industry

### Typical UAE procurement workflow — Passenger elevators

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Passenger elevators

Passenger elevators covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### High-Rise Passenger Lift

High-Rise Passenger Lift is a product or solution family within Passenger elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Hydraulic Passenger Elevator

Hydraulic Passenger Elevator is a product or solution family within Passenger elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Low-Rise Passenger Lift

Low-Rise Passenger Lift is a product or solution family within Passenger elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Machine-Room Traction Elevator

Machine-Room Traction Elevator is a product or solution family within Passenger elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Machine-Room-Less Traction Elevator

Machine-Room-Less Traction Elevator is a product or solution family within Passenger elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### Access Control Integration

Access Control Integration is a relevant technical feature for Passenger elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Automatic Rescue Device

Automatic Rescue Device is a relevant technical feature for Passenger elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Cab Finishes

Cab Finishes is a relevant technical feature for Passenger elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Destination Control

Destination Control is a relevant technical feature for Passenger elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Hydraulic Option For Appropriate Low-Rise Use

Hydraulic Option For Appropriate Low-Rise Use is a relevant technical feature for Passenger elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Machine-Room Arrangement

Machine-Room Arrangement is a relevant technical feature for Passenger elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Machine-Room-Less Arrangement

Machine-Room-Less Arrangement is a relevant technical feature for Passenger elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Regenerative Drive

Regenerative Drive is a relevant technical feature for Passenger elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Single Or Group Control

Single Or Group Control is a relevant technical feature for Passenger elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Traction Drive

Traction Drive is a relevant technical feature for Passenger elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Passenger elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Passenger elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Passenger elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Passenger elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Passenger elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Passenger elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Passenger elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Passenger elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Passenger elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Passenger elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Accessibility Standards

Abu Dhabi International Accessibility Standards is a relevant authority or regulatory reference for Passenger elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Passenger elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Passenger elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Passenger elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Passenger elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Passenger elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Passenger elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Passenger elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Passenger elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Passenger elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Passenger elevators: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Passenger elevators: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Passenger elevators: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Passenger elevators: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Passenger elevators: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Passenger elevators: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Passenger elevators: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Passenger elevators: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-passenger-elevators-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Number Of Stops is missing

When field number_of_stops is missing, ask question q-passenger-elevators-number_of_stops and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Number Of Units is missing

When field number_of_units is missing, ask question q-passenger-elevators-number_of_units and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Passenger Capacity is missing

When field passenger_capacity is missing, ask question q-passenger-elevators-passenger_capacity and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-passenger-elevators-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-passenger-elevators-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Rated Load Kg is missing

When field rated_load_kg is missing, ask question q-passenger-elevators-rated_load_kg and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-passenger-elevators-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Travel Height is missing

When field travel_height is missing, ask question q-passenger-elevators-travel_height and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Door Clear Width Mm

Ask: Please provide door clear width mm. Arabic: يرجى توفير Door Clear Width Mm. Reason: Door Clear Width Mm is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Number Of Stops

Ask: Please provide number of stops. Arabic: يرجى توفير Number Of Stops. Reason: Number Of Stops is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Number Of Units

Ask: Please provide number of units. Arabic: يرجى توفير Number Of Units. Reason: Number Of Units is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Overhead Mm

Ask: Please provide overhead mm. Arabic: يرجى توفير Overhead Mm. Reason: Overhead Mm is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Passenger Capacity

Ask: Please provide passenger capacity. Arabic: يرجى توفير Passenger Capacity. Reason: Passenger Capacity is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Pit Depth Mm

Ask: Please provide pit depth mm. Arabic: يرجى توفير Pit Depth Mm. Reason: Pit Depth Mm is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Rated Load Kg

Ask: Please provide rated load kg. Arabic: يرجى توفير Rated Load Kg. Reason: Rated Load Kg is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Rated Speed Mps

Ask: Please provide rated speed mps. Arabic: يرجى توفير Rated Speed Mps. Reason: Rated Speed Mps is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Shaft Dimensions

Ask: Please provide shaft dimensions. Arabic: يرجى توفير Shaft Dimensions. Reason: Shaft Dimensions is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Traffic Performance Target

Ask: Please provide traffic performance target. Arabic: يرجى توفير Traffic Performance Target. Reason: Traffic Performance Target is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Travel Height

Ask: Please provide travel height. Arabic: يرجى توفير Travel Height. Reason: Travel Height is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

## Validation

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Door Clear Width Mm

Validate door clear width mm before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Number Of Stops

Validate number of stops before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Number Of Units

Validate number of units before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Overhead Mm

Validate overhead mm before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Passenger Capacity

Validate passenger capacity before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Pit Depth Mm

Validate pit depth mm before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Rated Load Kg

Validate rated load kg before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Rated Speed Mps

Validate rated speed mps before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Shaft Dimensions

Validate shaft dimensions before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Traffic Performance Target

Validate traffic performance target before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Travel Height

Validate travel height before supplier dispatch for Passenger elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Passenger elevators. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests passenger lift for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Passenger elevators. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Passenger elevators. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Passenger elevators without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Passenger elevators. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Building Type

English term: Building Type. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Door Clear Width Mm

English term: Door Clear Width Mm. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Number Of Stops

English term: Number Of Stops. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Number Of Units

English term: Number Of Units. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Overhead Mm

English term: Overhead Mm. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Passenger Capacity

English term: Passenger Capacity. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Passenger elevators

English term: Passenger elevators. Arabic term: مصاعد الركاب. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Pit Depth Mm

English term: Pit Depth Mm. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Rated Load Kg

English term: Rated Load Kg. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Rated Speed Mps

English term: Rated Speed Mps. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Shaft Dimensions

English term: Shaft Dimensions. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Traffic Performance Target

English term: Traffic Performance Target. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Travel Height

English term: Travel Height. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### commercial elevator

English term: commercial elevator. Arabic term: مصعد تجاري. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### office lift

English term: office lift. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### passenger lift

English term: passenger lift. Arabic term: مصعد ركاب. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### people lift

English term: people lift. Arabic term: مصاعد ركاب. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### residential elevator

English term: residential elevator. Arabic term: مصعد سكني. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

# Service and freight elevators / مصاعد الخدمة والشحن

## Industry

### Typical UAE procurement workflow — Service and freight elevators

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Service and freight elevators

Service and freight elevators covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### Freight Elevator

Freight Elevator is a product or solution family within Service and freight elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Industrial Cargo Lift

Industrial Cargo Lift is a product or solution family within Service and freight elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Loading Dock Lift

Loading Dock Lift is a product or solution family within Service and freight elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Service Elevator

Service Elevator is a product or solution family within Service and freight elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### Forklift Or Trolley Loading Interface

Forklift Or Trolley Loading Interface is a relevant technical feature for Service and freight elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Front Or Through Loading

Front Or Through Loading is a relevant technical feature for Service and freight elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Heavy-Duty Car Construction

Heavy-Duty Car Construction is a relevant technical feature for Service and freight elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### High Duty Cycle

High Duty Cycle is a relevant technical feature for Service and freight elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Impact Protection

Impact Protection is a relevant technical feature for Service and freight elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Industrial Controls

Industrial Controls is a relevant technical feature for Service and freight elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Manual Or Power-Operated Doors

Manual Or Power-Operated Doors is a relevant technical feature for Service and freight elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Reinforced Sills And Doors

Reinforced Sills And Doors is a relevant technical feature for Service and freight elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Service and freight elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Service and freight elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Service and freight elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Service and freight elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Service and freight elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Service and freight elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Service and freight elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Service and freight elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Service and freight elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Service and freight elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Service and freight elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Service and freight elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Service and freight elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Service and freight elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Service and freight elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Service and freight elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Service and freight elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Service and freight elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Service and freight elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Service and freight elevators: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Service and freight elevators: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Service and freight elevators: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Service and freight elevators: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Service and freight elevators: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Service and freight elevators: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Service and freight elevators: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Service and freight elevators: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-service-and-freight-elevators-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Car Internal Dimensions is missing

When field car_internal_dimensions is missing, ask question q-service-and-freight-elevators-car_internal_dimensions and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Door Configuration is missing

When field door_configuration is missing, ask question q-service-and-freight-elevators-door_configuration and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Duty Cycle is missing

When field duty_cycle is missing, ask question q-service-and-freight-elevators-duty_cycle and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Load Type is missing

When field load_type is missing, ask question q-service-and-freight-elevators-load_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Loading Method is missing

When field loading_method is missing, ask question q-service-and-freight-elevators-loading_method and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-service-and-freight-elevators-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-service-and-freight-elevators-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Rated Load Kg is missing

When field rated_load_kg is missing, ask question q-service-and-freight-elevators-rated_load_kg and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-service-and-freight-elevators-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Car Internal Dimensions

Ask: Please provide car internal dimensions. Arabic: يرجى توفير Car Internal Dimensions. Reason: Car Internal Dimensions is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Door Configuration

Ask: Please provide door configuration. Arabic: يرجى توفير Door Configuration. Reason: Door Configuration is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Duty Cycle

Ask: Please provide duty cycle. Arabic: يرجى توفير Duty Cycle. Reason: Duty Cycle is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Floor Loading

Ask: Please provide floor loading. Arabic: يرجى توفير Floor Loading. Reason: Floor Loading is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Impact Protection

Ask: Please provide impact protection. Arabic: يرجى توفير Impact Protection. Reason: Impact Protection is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Load Type

Ask: Please provide load type. Arabic: يرجى توفير Load Type. Reason: Load Type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Loading Method

Ask: Please provide loading method. Arabic: يرجى توفير Loading Method. Reason: Loading Method is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Number Of Stops

Ask: Please provide number of stops. Arabic: يرجى توفير Number Of Stops. Reason: Number Of Stops is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Rated Load Kg

Ask: Please provide rated load kg. Arabic: يرجى توفير Rated Load Kg. Reason: Rated Load Kg is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Travel Height

Ask: Please provide travel height. Arabic: يرجى توفير Travel Height. Reason: Travel Height is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

## Validation

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Car Internal Dimensions

Validate car internal dimensions before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Door Configuration

Validate door configuration before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Duty Cycle

Validate duty cycle before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Floor Loading

Validate floor loading before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Impact Protection

Validate impact protection before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Load Type

Validate load type before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Loading Method

Validate loading method before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Number Of Stops

Validate number of stops before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Rated Load Kg

Validate rated load kg before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Travel Height

Validate travel height before supplier dispatch for Service and freight elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Service and freight elevators. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests service lift for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Service and freight elevators. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Service and freight elevators. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Service and freight elevators without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Service and freight elevators. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Car Internal Dimensions

English term: Car Internal Dimensions. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Door Configuration

English term: Door Configuration. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Duty Cycle

English term: Duty Cycle. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Floor Loading

English term: Floor Loading. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Impact Protection

English term: Impact Protection. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Load Type

English term: Load Type. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Loading Method

English term: Loading Method. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Number Of Stops

English term: Number Of Stops. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Rated Load Kg

English term: Rated Load Kg. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Service and freight elevators

English term: Service and freight elevators. Arabic term: مصاعد الخدمة والشحن. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Travel Height

English term: Travel Height. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### cargo elevator

English term: cargo elevator. Arabic term: مصعد بضائع ثقيل. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### freight elevator

English term: freight elevator. Arabic term: مصعد شحن. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### heavy duty lift

English term: heavy duty lift. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### service lift

English term: service lift. Arabic term: مصعد خدمة. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

# Hospital and bed elevators / مصاعد المستشفيات والأسرة

## Industry

### Typical UAE procurement workflow — Hospital and bed elevators

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Hospital and bed elevators

Hospital and bed elevators covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### Bed Elevator

Bed Elevator is a product or solution family within Hospital and bed elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Hospital Service Elevator

Hospital Service Elevator is a product or solution family within Hospital and bed elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Stretcher Elevator

Stretcher Elevator is a product or solution family within Hospital and bed elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### Bed-Sized Car

Bed-Sized Car is a relevant technical feature for Hospital and bed elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Emergency Power Operation

Emergency Power Operation is a relevant technical feature for Hospital and bed elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Infection-Control Finishes

Infection-Control Finishes is a relevant technical feature for Hospital and bed elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Priority Service

Priority Service is a relevant technical feature for Hospital and bed elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Protected Circulation Interface

Protected Circulation Interface is a relevant technical feature for Hospital and bed elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Smooth Acceleration And Levelling

Smooth Acceleration And Levelling is a relevant technical feature for Hospital and bed elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Staff Access Control

Staff Access Control is a relevant technical feature for Hospital and bed elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Wide Automatic Doors

Wide Automatic Doors is a relevant technical feature for Hospital and bed elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Hospital and bed elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Hospital and bed elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Hospital and bed elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Hospital and bed elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Hospital and bed elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Hospital and bed elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Hospital and bed elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Hospital and bed elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Hospital and bed elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Hospital and bed elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Accessibility Standards

Abu Dhabi International Accessibility Standards is a relevant authority or regulatory reference for Hospital and bed elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Hospital and bed elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Hospital and bed elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Hospital and bed elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Hospital and bed elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Hospital and bed elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Hospital and bed elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Hospital and bed elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Hospital and bed elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Hospital and bed elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Hospital and bed elevators: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Hospital and bed elevators: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Hospital and bed elevators: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Hospital and bed elevators: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Hospital and bed elevators: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Hospital and bed elevators: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Hospital and bed elevators: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Hospital and bed elevators: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Bed Dimensions is missing

When field bed_dimensions is missing, ask question q-hospital-and-bed-elevators-bed_dimensions and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-hospital-and-bed-elevators-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Car Internal Dimensions is missing

When field car_internal_dimensions is missing, ask question q-hospital-and-bed-elevators-car_internal_dimensions and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Door Clear Width Mm is missing

When field door_clear_width_mm is missing, ask question q-hospital-and-bed-elevators-door_clear_width_mm and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Number Of Stops is missing

When field number_of_stops is missing, ask question q-hospital-and-bed-elevators-number_of_stops and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-hospital-and-bed-elevators-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-hospital-and-bed-elevators-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Rated Load Kg is missing

When field rated_load_kg is missing, ask question q-hospital-and-bed-elevators-rated_load_kg and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Rated Speed Mps is missing

When field rated_speed_mps is missing, ask question q-hospital-and-bed-elevators-rated_speed_mps and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-hospital-and-bed-elevators-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Hospital Priority

When building_type contains hospital, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Bed Dimensions

Ask: Please provide bed dimensions. Arabic: يرجى توفير Bed Dimensions. Reason: Bed Dimensions is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Car Internal Dimensions

Ask: Please provide car internal dimensions. Arabic: يرجى توفير Car Internal Dimensions. Reason: Car Internal Dimensions is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Door Clear Width Mm

Ask: Please provide door clear width mm. Arabic: يرجى توفير Door Clear Width Mm. Reason: Door Clear Width Mm is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Emergency Power

Ask: Please provide emergency power. Arabic: يرجى توفير Emergency Power. Reason: Emergency Power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Infection Control Finish

Ask: Please provide infection control finish. Arabic: يرجى توفير Infection Control Finish. Reason: Infection Control Finish is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Number Of Stops

Ask: Please provide number of stops. Arabic: يرجى توفير Number Of Stops. Reason: Number Of Stops is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Priority Control

Ask: Please provide priority control. Arabic: يرجى توفير Priority Control. Reason: Priority Control is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Rated Load Kg

Ask: Please provide rated load kg. Arabic: يرجى توفير Rated Load Kg. Reason: Rated Load Kg is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Rated Speed Mps

Ask: Please provide rated speed mps. Arabic: يرجى توفير Rated Speed Mps. Reason: Rated Speed Mps is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Traffic Separation

Ask: Please provide traffic separation. Arabic: يرجى توفير Traffic Separation. Reason: Traffic Separation is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

## Validation

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Bed Dimensions

Validate bed dimensions before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Car Internal Dimensions

Validate car internal dimensions before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Door Clear Width Mm

Validate door clear width mm before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Emergency Power

Validate emergency power before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Infection Control Finish

Validate infection control finish before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Number Of Stops

Validate number of stops before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Priority Control

Validate priority control before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Rated Load Kg

Validate rated load kg before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Rated Speed Mps

Validate rated speed mps before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Traffic Separation

Validate traffic separation before supplier dispatch for Hospital and bed elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Hospital and bed elevators. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests bed lift for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Hospital and bed elevators. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Hospital and bed elevators. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Hospital and bed elevators without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Hospital and bed elevators. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Bed Dimensions

English term: Bed Dimensions. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Car Internal Dimensions

English term: Car Internal Dimensions. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Door Clear Width Mm

English term: Door Clear Width Mm. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Emergency Power

English term: Emergency Power. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Hospital and bed elevators

English term: Hospital and bed elevators. Arabic term: مصاعد المستشفيات والأسرة. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Infection Control Finish

English term: Infection Control Finish. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Number Of Stops

English term: Number Of Stops. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Priority Control

English term: Priority Control. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Rated Load Kg

English term: Rated Load Kg. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Rated Speed Mps

English term: Rated Speed Mps. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Traffic Separation

English term: Traffic Separation. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### bed lift

English term: bed lift. Arabic term: مصعد سرير. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### hospital lift

English term: hospital lift. Arabic term: مصعد نقالة. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### medical elevator

English term: medical elevator. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### stretcher elevator

English term: stretcher elevator. Arabic term: مصعد مستشفى. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

# Goods lifts and platform lifts / مصاعد البضائع والمنصات

## Industry

### Typical UAE procurement workflow — Goods lifts and platform lifts

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Goods lifts and platform lifts

Goods lifts and platform lifts covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### Goods-Only Lift

Goods-Only Lift is a product or solution family within Goods lifts and platform lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Material Platform Lift

Material Platform Lift is a product or solution family within Goods lifts and platform lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Scissor Platform Lift

Scissor Platform Lift is a product or solution family within Goods lifts and platform lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Vertical Platform Lift

Vertical Platform Lift is a product or solution family within Goods lifts and platform lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### Constant-Pressure Controls Where Applicable

Constant-Pressure Controls Where Applicable is a relevant technical feature for Goods lifts and platform lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Goods-Only Controls

Goods-Only Controls is a relevant technical feature for Goods lifts and platform lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Guarding

Guarding is a relevant technical feature for Goods lifts and platform lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Interlocked Landing Gates

Interlocked Landing Gates is a relevant technical feature for Goods lifts and platform lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Limited Travel Application

Limited Travel Application is a relevant technical feature for Goods lifts and platform lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Outdoor Weather Protection

Outdoor Weather Protection is a relevant technical feature for Goods lifts and platform lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Platform Or Enclosed Car

Platform Or Enclosed Car is a relevant technical feature for Goods lifts and platform lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Goods lifts and platform lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Goods lifts and platform lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Goods lifts and platform lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Goods lifts and platform lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Goods lifts and platform lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Goods lifts and platform lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Goods lifts and platform lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Goods lifts and platform lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Goods lifts and platform lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Goods lifts and platform lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Goods lifts and platform lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Goods lifts and platform lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Goods lifts and platform lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Goods lifts and platform lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Goods lifts and platform lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Goods lifts and platform lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Goods lifts and platform lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Goods lifts and platform lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Goods lifts and platform lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Goods lifts and platform lifts: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Goods lifts and platform lifts: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Goods lifts and platform lifts: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Goods lifts and platform lifts: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Goods lifts and platform lifts: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Goods lifts and platform lifts: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Goods lifts and platform lifts: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Goods lifts and platform lifts: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-goods-lifts-and-platform-lifts-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Loading Method is missing

When field loading_method is missing, ask question q-goods-lifts-and-platform-lifts-loading_method and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Number Of Landings is missing

When field number_of_landings is missing, ask question q-goods-lifts-and-platform-lifts-number_of_landings and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Persons Allowed is missing

When field persons_allowed is missing, ask question q-goods-lifts-and-platform-lifts-persons_allowed and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Platform Dimensions is missing

When field platform_dimensions is missing, ask question q-goods-lifts-and-platform-lifts-platform_dimensions and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-goods-lifts-and-platform-lifts-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-goods-lifts-and-platform-lifts-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Rated Load Kg is missing

When field rated_load_kg is missing, ask question q-goods-lifts-and-platform-lifts-rated_load_kg and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-goods-lifts-and-platform-lifts-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Travel Height is missing

When field travel_height is missing, ask question q-goods-lifts-and-platform-lifts-travel_height and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Duty Cycle

Ask: Please provide duty cycle. Arabic: يرجى توفير Duty Cycle. Reason: Duty Cycle is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Guarding

Ask: Please provide guarding. Arabic: يرجى توفير Guarding. Reason: Guarding is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Indoor Outdoor

Ask: Please provide indoor outdoor. Arabic: يرجى توفير Indoor Outdoor. Reason: Indoor Outdoor is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Interlocks

Ask: Please provide interlocks. Arabic: يرجى توفير Interlocks. Reason: Interlocks is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Loading Method

Ask: Please provide loading method. Arabic: يرجى توفير Loading Method. Reason: Loading Method is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Number Of Landings

Ask: Please provide number of landings. Arabic: يرجى توفير Number Of Landings. Reason: Number Of Landings is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Persons Allowed

Ask: Please provide persons allowed. Arabic: يرجى توفير Persons Allowed. Reason: Persons Allowed is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Platform Dimensions

Ask: Please provide platform dimensions. Arabic: يرجى توفير Platform Dimensions. Reason: Platform Dimensions is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Rated Load Kg

Ask: Please provide rated load kg. Arabic: يرجى توفير Rated Load Kg. Reason: Rated Load Kg is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Travel Height

Ask: Please provide travel height. Arabic: يرجى توفير Travel Height. Reason: Travel Height is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

## Validation

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Duty Cycle

Validate duty cycle before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Guarding

Validate guarding before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Indoor Outdoor

Validate indoor outdoor before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Interlocks

Validate interlocks before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Loading Method

Validate loading method before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Number Of Landings

Validate number of landings before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Persons Allowed

Validate persons allowed before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Platform Dimensions

Validate platform dimensions before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Rated Load Kg

Validate rated load kg before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Travel Height

Validate travel height before supplier dispatch for Goods lifts and platform lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Goods lifts and platform lifts. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests goods lift for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Goods lifts and platform lifts. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Goods lifts and platform lifts. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Goods lifts and platform lifts without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Goods lifts and platform lifts. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Duty Cycle

English term: Duty Cycle. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Goods lifts and platform lifts

English term: Goods lifts and platform lifts. Arabic term: مصاعد البضائع والمنصات. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Guarding

English term: Guarding. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Indoor Outdoor

English term: Indoor Outdoor. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Interlocks

English term: Interlocks. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Loading Method

English term: Loading Method. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Number Of Landings

English term: Number Of Landings. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Persons Allowed

English term: Persons Allowed. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Platform Dimensions

English term: Platform Dimensions. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Rated Load Kg

English term: Rated Load Kg. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Travel Height

English term: Travel Height. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### cargo platform

English term: cargo platform. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### goods lift

English term: goods lift. Arabic term: مصعد بضائع. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### material lift

English term: material lift. Arabic term: رافعة منصة. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### platform lift

English term: platform lift. Arabic term: منصة رفع عمودية. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### vertical platform lift

English term: vertical platform lift. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

# Home lifts and accessibility lifts / المصاعد المنزلية ومصاعد الوصول

## Industry

### Typical UAE procurement workflow — Home lifts and accessibility lifts

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Home lifts and accessibility lifts

Home lifts and accessibility lifts covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### Home Elevator

Home Elevator is a product or solution family within Home lifts and accessibility lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Inclined Platform Lift

Inclined Platform Lift is a product or solution family within Home lifts and accessibility lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Vertical Wheelchair Platform Lift

Vertical Wheelchair Platform Lift is a product or solution family within Home lifts and accessibility lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Villa Lift

Villa Lift is a product or solution family within Home lifts and accessibility lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### Accessible Controls

Accessible Controls is a relevant technical feature for Home lifts and accessibility lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Automatic Doors

Automatic Doors is a relevant technical feature for Home lifts and accessibility lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Battery Lowering

Battery Lowering is a relevant technical feature for Home lifts and accessibility lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Compact Shaft

Compact Shaft is a relevant technical feature for Home lifts and accessibility lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Low Pit Or Pitless Option Subject To Code

Low Pit Or Pitless Option Subject To Code is a relevant technical feature for Home lifts and accessibility lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Low-Rise Duty

Low-Rise Duty is a relevant technical feature for Home lifts and accessibility lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Residential Finishes

Residential Finishes is a relevant technical feature for Home lifts and accessibility lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Wheelchair Clearances

Wheelchair Clearances is a relevant technical feature for Home lifts and accessibility lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Home lifts and accessibility lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Home lifts and accessibility lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Home lifts and accessibility lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Home lifts and accessibility lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Home lifts and accessibility lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Home lifts and accessibility lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Home lifts and accessibility lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Home lifts and accessibility lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Home lifts and accessibility lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Home lifts and accessibility lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Accessibility Standards

Abu Dhabi International Accessibility Standards is a relevant authority or regulatory reference for Home lifts and accessibility lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Home lifts and accessibility lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Home lifts and accessibility lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Home lifts and accessibility lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Home lifts and accessibility lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Home lifts and accessibility lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Home lifts and accessibility lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Home lifts and accessibility lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Home lifts and accessibility lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Home lifts and accessibility lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Home lifts and accessibility lifts: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Home lifts and accessibility lifts: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Home lifts and accessibility lifts: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Home lifts and accessibility lifts: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Home lifts and accessibility lifts: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Home lifts and accessibility lifts: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Home lifts and accessibility lifts: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Home lifts and accessibility lifts: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Available Shaft Space is missing

When field available_shaft_space is missing, ask question q-home-lifts-and-accessibility-lifts-available_shaft_space and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-home-lifts-and-accessibility-lifts-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Number Of Stops is missing

When field number_of_stops is missing, ask question q-home-lifts-and-accessibility-lifts-number_of_stops and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Pit Available is missing

When field pit_available is missing, ask question q-home-lifts-and-accessibility-lifts-pit_available and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-home-lifts-and-accessibility-lifts-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-home-lifts-and-accessibility-lifts-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-home-lifts-and-accessibility-lifts-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Travel Height is missing

When field travel_height is missing, ask question q-home-lifts-and-accessibility-lifts-travel_height and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when User Profile is missing

When field user_profile is missing, ask question q-home-lifts-and-accessibility-lifts-user_profile and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Wheelchair Use is missing

When field wheelchair_use is missing, ask question q-home-lifts-and-accessibility-lifts-wheelchair_use and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Available Shaft Space

Ask: Please provide available shaft space. Arabic: يرجى توفير Available Shaft Space. Reason: Available Shaft Space is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Backup Lowering

Ask: Please provide backup lowering. Arabic: يرجى توفير Backup Lowering. Reason: Backup Lowering is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Door Clear Width Mm

Ask: Please provide door clear width mm. Arabic: يرجى توفير Door Clear Width Mm. Reason: Door Clear Width Mm is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Indoor Outdoor

Ask: Please provide indoor outdoor. Arabic: يرجى توفير Indoor Outdoor. Reason: Indoor Outdoor is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Number Of Stops

Ask: Please provide number of stops. Arabic: يرجى توفير Number Of Stops. Reason: Number Of Stops is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Overhead Available

Ask: Please provide overhead available. Arabic: يرجى توفير Overhead Available. Reason: Overhead Available is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Pit Available

Ask: Please provide pit available. Arabic: يرجى توفير Pit Available. Reason: Pit Available is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Rated Load Kg

Ask: Please provide rated load kg. Arabic: يرجى توفير Rated Load Kg. Reason: Rated Load Kg is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Travel Height

Ask: Please provide travel height. Arabic: يرجى توفير Travel Height. Reason: Travel Height is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### User Profile

Ask: Please provide user profile. Arabic: يرجى توفير User Profile. Reason: User Profile is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Wheelchair Use

Ask: Please provide wheelchair use. Arabic: يرجى توفير Wheelchair Use. Reason: Wheelchair Use is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

## Validation

### Validate Available Shaft Space

Validate available shaft space before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Backup Lowering

Validate backup lowering before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Door Clear Width Mm

Validate door clear width mm before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Indoor Outdoor

Validate indoor outdoor before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Number Of Stops

Validate number of stops before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Overhead Available

Validate overhead available before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Pit Available

Validate pit available before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Rated Load Kg

Validate rated load kg before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Travel Height

Validate travel height before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate User Profile

Validate user profile before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Wheelchair Use

Validate wheelchair use before supplier dispatch for Home lifts and accessibility lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Home lifts and accessibility lifts. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests home lift for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Home lifts and accessibility lifts. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Home lifts and accessibility lifts. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Home lifts and accessibility lifts without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Home lifts and accessibility lifts. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Available Shaft Space

English term: Available Shaft Space. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Backup Lowering

English term: Backup Lowering. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Door Clear Width Mm

English term: Door Clear Width Mm. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Home lifts and accessibility lifts

English term: Home lifts and accessibility lifts. Arabic term: المصاعد المنزلية ومصاعد الوصول. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Indoor Outdoor

English term: Indoor Outdoor. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Number Of Stops

English term: Number Of Stops. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Overhead Available

English term: Overhead Available. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Pit Available

English term: Pit Available. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Rated Load Kg

English term: Rated Load Kg. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Travel Height

English term: Travel Height. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### User Profile

English term: User Profile. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Wheelchair Use

English term: Wheelchair Use. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### accessibility lift

English term: accessibility lift. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### disabled lift

English term: disabled lift. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### home lift

English term: home lift. Arabic term: مصعد منزلي. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### residential platform lift

English term: residential platform lift. Arabic term: مصعد كرسي متحرك. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### villa lift

English term: villa lift. Arabic term: مصعد فيلا. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### wheelchair lift

English term: wheelchair lift. Arabic term: مصعد ذوي الهمم. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

# Dumbwaiters and small service lifts / مصاعد الطعام والخدمة الصغيرة

## Industry

### Typical UAE procurement workflow — Dumbwaiters and small service lifts

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Dumbwaiters and small service lifts

Dumbwaiters and small service lifts covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### Document Dumbwaiter

Document Dumbwaiter is a product or solution family within Dumbwaiters and small service lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Food Dumbwaiter

Food Dumbwaiter is a product or solution family within Dumbwaiters and small service lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Laundry Dumbwaiter

Laundry Dumbwaiter is a product or solution family within Dumbwaiters and small service lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### Cleaning Access

Cleaning Access is a relevant technical feature for Dumbwaiters and small service lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Counter-Height Or Floor-Level Loading

Counter-Height Or Floor-Level Loading is a relevant technical feature for Dumbwaiters and small service lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Food-Grade Stainless Finish

Food-Grade Stainless Finish is a relevant technical feature for Dumbwaiters and small service lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Interlocked Doors

Interlocked Doors is a relevant technical feature for Dumbwaiters and small service lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Limited Rated Load

Limited Rated Load is a relevant technical feature for Dumbwaiters and small service lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Shelf Options

Shelf Options is a relevant technical feature for Dumbwaiters and small service lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Small Car

Small Car is a relevant technical feature for Dumbwaiters and small service lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Dumbwaiters and small service lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Dumbwaiters and small service lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Dumbwaiters and small service lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Dumbwaiters and small service lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Dumbwaiters and small service lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Dumbwaiters and small service lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Dumbwaiters and small service lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Dumbwaiters and small service lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Dumbwaiters and small service lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Dumbwaiters and small service lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Dumbwaiters and small service lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Dumbwaiters and small service lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Dumbwaiters and small service lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Dumbwaiters and small service lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Dumbwaiters and small service lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Dumbwaiters and small service lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Dumbwaiters and small service lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Dumbwaiters and small service lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Dumbwaiters and small service lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Dumbwaiters and small service lifts: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Dumbwaiters and small service lifts: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Dumbwaiters and small service lifts: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Dumbwaiters and small service lifts: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Dumbwaiters and small service lifts: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Dumbwaiters and small service lifts: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Dumbwaiters and small service lifts: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Dumbwaiters and small service lifts: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-dumbwaiters-and-small-service-lifts-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Car Internal Dimensions is missing

When field car_internal_dimensions is missing, ask question q-dumbwaiters-and-small-service-lifts-car_internal_dimensions and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Loading Height is missing

When field loading_height is missing, ask question q-dumbwaiters-and-small-service-lifts-loading_height and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Number Of Stops is missing

When field number_of_stops is missing, ask question q-dumbwaiters-and-small-service-lifts-number_of_stops and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-dumbwaiters-and-small-service-lifts-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-dumbwaiters-and-small-service-lifts-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Rated Load Kg is missing

When field rated_load_kg is missing, ask question q-dumbwaiters-and-small-service-lifts-rated_load_kg and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-dumbwaiters-and-small-service-lifts-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Travel Height is missing

When field travel_height is missing, ask question q-dumbwaiters-and-small-service-lifts-travel_height and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Use Case is missing

When field use_case is missing, ask question q-dumbwaiters-and-small-service-lifts-use_case and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Car Internal Dimensions

Ask: Please provide car internal dimensions. Arabic: يرجى توفير Car Internal Dimensions. Reason: Car Internal Dimensions is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Cleaning Requirement

Ask: Please provide cleaning requirement. Arabic: يرجى توفير Cleaning Requirement. Reason: Cleaning Requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Door Type

Ask: Please provide door type. Arabic: يرجى توفير Door Type. Reason: Door Type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Fire Rating Requirement

Ask: Please provide fire rating requirement. Arabic: يرجى توفير Fire Rating Requirement. Reason: Fire Rating Requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Food Grade Finish

Ask: Please provide food grade finish. Arabic: يرجى توفير Food Grade Finish. Reason: Food Grade Finish is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Loading Height

Ask: Please provide loading height. Arabic: يرجى توفير Loading Height. Reason: Loading Height is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Number Of Stops

Ask: Please provide number of stops. Arabic: يرجى توفير Number Of Stops. Reason: Number Of Stops is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Rated Load Kg

Ask: Please provide rated load kg. Arabic: يرجى توفير Rated Load Kg. Reason: Rated Load Kg is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Travel Height

Ask: Please provide travel height. Arabic: يرجى توفير Travel Height. Reason: Travel Height is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Use Case

Ask: Please provide use case. Arabic: يرجى توفير Use Case. Reason: Use Case is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

## Validation

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Car Internal Dimensions

Validate car internal dimensions before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Cleaning Requirement

Validate cleaning requirement before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Door Type

Validate door type before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Fire Rating Requirement

Validate fire rating requirement before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Food Grade Finish

Validate food grade finish before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Loading Height

Validate loading height before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Number Of Stops

Validate number of stops before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Rated Load Kg

Validate rated load kg before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Travel Height

Validate travel height before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Use Case

Validate use case before supplier dispatch for Dumbwaiters and small service lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Dumbwaiters and small service lifts. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests dumbwaiter for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Dumbwaiters and small service lifts. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Dumbwaiters and small service lifts. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Dumbwaiters and small service lifts without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Dumbwaiters and small service lifts. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Car Internal Dimensions

English term: Car Internal Dimensions. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Cleaning Requirement

English term: Cleaning Requirement. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Door Type

English term: Door Type. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Dumbwaiters and small service lifts

English term: Dumbwaiters and small service lifts. Arabic term: مصاعد الطعام والخدمة الصغيرة. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Fire Rating Requirement

English term: Fire Rating Requirement. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Food Grade Finish

English term: Food Grade Finish. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Loading Height

English term: Loading Height. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Number Of Stops

English term: Number Of Stops. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Rated Load Kg

English term: Rated Load Kg. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Travel Height

English term: Travel Height. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Use Case

English term: Use Case. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### document lift

English term: document lift. Arabic term: مصعد خدمة صغير. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### dumbwaiter

English term: dumbwaiter. Arabic term: مصعد طعام. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### food lift

English term: food lift. Arabic term: دَمب ويتر. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### small service lift

English term: small service lift. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

# Vehicle and car elevators / مصاعد السيارات والمركبات

## Industry

### Typical UAE procurement workflow — Vehicle and car elevators

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Vehicle and car elevators

Vehicle and car elevators covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### Car Parking Elevator

Car Parking Elevator is a product or solution family within Vehicle and car elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Showroom Car Lift

Showroom Car Lift is a product or solution family within Vehicle and car elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Vehicle Elevator

Vehicle Elevator is a product or solution family within Vehicle and car elevators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### Heavy-Duty Drive

Heavy-Duty Drive is a relevant technical feature for Vehicle and car elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Large Door Opening

Large Door Opening is a relevant technical feature for Vehicle and car elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Oil And Water Management

Oil And Water Management is a relevant technical feature for Vehicle and car elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Positioning Aids

Positioning Aids is a relevant technical feature for Vehicle and car elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Traffic Lights And Access Control

Traffic Lights And Access Control is a relevant technical feature for Vehicle and car elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Vehicle-Rated Platform

Vehicle-Rated Platform is a relevant technical feature for Vehicle and car elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Ventilation/Fire Interfaces

Ventilation/Fire Interfaces is a relevant technical feature for Vehicle and car elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Wheel Guides

Wheel Guides is a relevant technical feature for Vehicle and car elevators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Vehicle and car elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Vehicle and car elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Vehicle and car elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Vehicle and car elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Vehicle and car elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Vehicle and car elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Vehicle and car elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Vehicle and car elevators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Vehicle and car elevators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Vehicle and car elevators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Vehicle and car elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Vehicle and car elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Vehicle and car elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Vehicle and car elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Vehicle and car elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Vehicle and car elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Vehicle and car elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Vehicle and car elevators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Vehicle and car elevators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Vehicle and car elevators: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Vehicle and car elevators: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Vehicle and car elevators: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Vehicle and car elevators: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Vehicle and car elevators: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Vehicle and car elevators: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Vehicle and car elevators: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Vehicle and car elevators: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-vehicle-and-car-elevators-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Maximum Vehicle Weight is missing

When field maximum_vehicle_weight is missing, ask question q-vehicle-and-car-elevators-maximum_vehicle_weight and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Number Of Stops is missing

When field number_of_stops is missing, ask question q-vehicle-and-car-elevators-number_of_stops and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Platform Dimensions is missing

When field platform_dimensions is missing, ask question q-vehicle-and-car-elevators-platform_dimensions and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-vehicle-and-car-elevators-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-vehicle-and-car-elevators-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-vehicle-and-car-elevators-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Travel Height is missing

When field travel_height is missing, ask question q-vehicle-and-car-elevators-travel_height and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Turning And Approach is missing

When field turning_and_approach is missing, ask question q-vehicle-and-car-elevators-turning_and_approach and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Vehicle Type is missing

When field vehicle_type is missing, ask question q-vehicle-and-car-elevators-vehicle_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Vehicle Scope

When subcategory equals vehicle-and-car-elevators, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Door Configuration

Ask: Please provide door configuration. Arabic: يرجى توفير Door Configuration. Reason: Door Configuration is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Fire Strategy

Ask: Please provide fire strategy. Arabic: يرجى توفير Fire Strategy. Reason: Fire Strategy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Maximum Vehicle Weight

Ask: Please provide maximum vehicle weight. Arabic: يرجى توفير Maximum Vehicle Weight. Reason: Maximum Vehicle Weight is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Number Of Stops

Ask: Please provide number of stops. Arabic: يرجى توفير Number Of Stops. Reason: Number Of Stops is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Platform Dimensions

Ask: Please provide platform dimensions. Arabic: يرجى توفير Platform Dimensions. Reason: Platform Dimensions is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Traffic Frequency

Ask: Please provide traffic frequency. Arabic: يرجى توفير Traffic Frequency. Reason: Traffic Frequency is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Travel Height

Ask: Please provide travel height. Arabic: يرجى توفير Travel Height. Reason: Travel Height is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Turning And Approach

Ask: Please provide turning and approach. Arabic: يرجى توفير Turning And Approach. Reason: Turning And Approach is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Vehicle Type

Ask: Please provide vehicle type. Arabic: يرجى توفير Vehicle Type. Reason: Vehicle Type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Ventilation Interface

Ask: Please provide ventilation interface. Arabic: يرجى توفير Ventilation Interface. Reason: Ventilation Interface is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

## Validation

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Door Configuration

Validate door configuration before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Fire Strategy

Validate fire strategy before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maximum Vehicle Weight

Validate maximum vehicle weight before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Number Of Stops

Validate number of stops before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Platform Dimensions

Validate platform dimensions before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Traffic Frequency

Validate traffic frequency before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Travel Height

Validate travel height before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Turning And Approach

Validate turning and approach before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Vehicle Type

Validate vehicle type before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Ventilation Interface

Validate ventilation interface before supplier dispatch for Vehicle and car elevators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Vehicle and car elevators. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests car lift for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Vehicle and car elevators. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Vehicle and car elevators. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Vehicle and car elevators without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Vehicle and car elevators. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Door Configuration

English term: Door Configuration. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Fire Strategy

English term: Fire Strategy. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Maximum Vehicle Weight

English term: Maximum Vehicle Weight. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Number Of Stops

English term: Number Of Stops. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Platform Dimensions

English term: Platform Dimensions. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Traffic Frequency

English term: Traffic Frequency. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Travel Height

English term: Travel Height. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Turning And Approach

English term: Turning And Approach. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Vehicle Type

English term: Vehicle Type. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Vehicle and car elevators

English term: Vehicle and car elevators. Arabic term: مصاعد السيارات والمركبات. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Ventilation Interface

English term: Ventilation Interface. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### automobile lift

English term: automobile lift. Arabic term: مصعد مركبات. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### car lift

English term: car lift. Arabic term: مصعد سيارات. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### parking lift

English term: parking lift. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### vehicle elevator

English term: vehicle elevator. Arabic term: رافعة سيارات. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

# Firefighter and evacuation lifts / مصاعد رجال الإطفاء والإخلاء

## Industry

### Typical UAE procurement workflow — Firefighter and evacuation lifts

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Firefighter and evacuation lifts

Firefighter and evacuation lifts covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### Emergency Response Elevator

Emergency Response Elevator is a product or solution family within Firefighter and evacuation lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Evacuation Lift

Evacuation Lift is a product or solution family within Firefighter and evacuation lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Firefighter Lift

Firefighter Lift is a product or solution family within Firefighter and evacuation lifts. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### Authority Witnessing

Authority Witnessing is a relevant technical feature for Firefighter and evacuation lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Communication System

Communication System is a relevant technical feature for Firefighter and evacuation lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Emergency Power

Emergency Power is a relevant technical feature for Firefighter and evacuation lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Fire Service Controls

Fire Service Controls is a relevant technical feature for Firefighter and evacuation lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Fire-Rated Landing Interfaces

Fire-Rated Landing Interfaces is a relevant technical feature for Firefighter and evacuation lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Protected Lobby Interface

Protected Lobby Interface is a relevant technical feature for Firefighter and evacuation lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Recall And Emergency Operation

Recall And Emergency Operation is a relevant technical feature for Firefighter and evacuation lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Water Protection

Water Protection is a relevant technical feature for Firefighter and evacuation lifts. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Firefighter and evacuation lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Firefighter and evacuation lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Firefighter and evacuation lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Firefighter and evacuation lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Firefighter and evacuation lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Firefighter and evacuation lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Firefighter and evacuation lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Firefighter and evacuation lifts, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Firefighter and evacuation lifts. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Firefighter and evacuation lifts inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Firefighter and evacuation lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Firefighter and evacuation lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Firefighter and evacuation lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Firefighter and evacuation lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Firefighter and evacuation lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Firefighter and evacuation lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Firefighter and evacuation lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Firefighter and evacuation lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### UAE Fire and Life Safety Code of Practice

UAE Fire and Life Safety Code of Practice is a relevant authority or regulatory reference for Firefighter and evacuation lifts. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Firefighter and evacuation lifts. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Firefighter and evacuation lifts: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Firefighter and evacuation lifts: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Firefighter and evacuation lifts: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Firefighter and evacuation lifts: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Firefighter and evacuation lifts: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Firefighter and evacuation lifts: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Firefighter and evacuation lifts: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Firefighter and evacuation lifts: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Building Height is missing

When field building_height is missing, ask question q-firefighter-and-evacuation-lifts-building_height and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-firefighter-and-evacuation-lifts-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Car Dimensions is missing

When field car_dimensions is missing, ask question q-firefighter-and-evacuation-lifts-car_dimensions and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Fire Strategy Reference is missing

When field fire_strategy_reference is missing, ask question q-firefighter-and-evacuation-lifts-fire_strategy_reference and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Number Of Stops is missing

When field number_of_stops is missing, ask question q-firefighter-and-evacuation-lifts-number_of_stops and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Occupancy Type is missing

When field occupancy_type is missing, ask question q-firefighter-and-evacuation-lifts-occupancy_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-firefighter-and-evacuation-lifts-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-firefighter-and-evacuation-lifts-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Rated Load Kg is missing

When field rated_load_kg is missing, ask question q-firefighter-and-evacuation-lifts-rated_load_kg and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-firefighter-and-evacuation-lifts-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Fire Strategy

When subcategory equals firefighter-and-evacuation-lifts, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Authority Approval Status

Ask: Please provide authority approval status. Arabic: يرجى توفير Authority Approval Status. Reason: Authority Approval Status is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Building Height

Ask: Please provide building height. Arabic: يرجى توفير Building Height. Reason: Building Height is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Car Dimensions

Ask: Please provide car dimensions. Arabic: يرجى توفير Car Dimensions. Reason: Car Dimensions is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Emergency Power

Ask: Please provide emergency power. Arabic: يرجى توفير Emergency Power. Reason: Emergency Power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Fire Service Operation

Ask: Please provide fire service operation. Arabic: يرجى توفير Fire Service Operation. Reason: Fire Service Operation is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Fire Strategy Reference

Ask: Please provide fire strategy reference. Arabic: يرجى توفير Fire Strategy Reference. Reason: Fire Strategy Reference is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Number Of Stops

Ask: Please provide number of stops. Arabic: يرجى توفير Number Of Stops. Reason: Number Of Stops is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Occupancy Type

Ask: Please provide occupancy type. Arabic: يرجى توفير Occupancy Type. Reason: Occupancy Type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Protected Lobby

Ask: Please provide protected lobby. Arabic: يرجى توفير Protected Lobby. Reason: Protected Lobby is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Rated Load Kg

Ask: Please provide rated load kg. Arabic: يرجى توفير Rated Load Kg. Reason: Rated Load Kg is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Water Protection

Ask: Please provide water protection. Arabic: يرجى توفير Water Protection. Reason: Water Protection is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

## Validation

### Validate Authority Approval Status

Validate authority approval status before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building Height

Validate building height before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Car Dimensions

Validate car dimensions before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Emergency Power

Validate emergency power before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Fire Service Operation

Validate fire service operation before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Fire Strategy Reference

Validate fire strategy reference before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Number Of Stops

Validate number of stops before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Occupancy Type

Validate occupancy type before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Protected Lobby

Validate protected lobby before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Rated Load Kg

Validate rated load kg before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Water Protection

Validate water protection before supplier dispatch for Firefighter and evacuation lifts. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Firefighter and evacuation lifts. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests fireman lift for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Firefighter and evacuation lifts. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Firefighter and evacuation lifts. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Firefighter and evacuation lifts without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Firefighter and evacuation lifts. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Authority Approval Status

English term: Authority Approval Status. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Building Height

English term: Building Height. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Car Dimensions

English term: Car Dimensions. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Emergency Power

English term: Emergency Power. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Fire Service Operation

English term: Fire Service Operation. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Fire Strategy Reference

English term: Fire Strategy Reference. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Firefighter and evacuation lifts

English term: Firefighter and evacuation lifts. Arabic term: مصاعد رجال الإطفاء والإخلاء. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Number Of Stops

English term: Number Of Stops. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Occupancy Type

English term: Occupancy Type. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Protected Lobby

English term: Protected Lobby. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Rated Load Kg

English term: Rated Load Kg. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Water Protection

English term: Water Protection. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### emergency elevator

English term: emergency elevator. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### evacuation lift

English term: evacuation lift. Arabic term: مصعد طوارئ. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### firefighter elevator

English term: firefighter elevator. Arabic term: مصعد إخلاء. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### fireman lift

English term: fireman lift. Arabic term: مصعد رجال الإطفاء. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

# Escalators / السلالم المتحركة

## Industry

### Typical UAE procurement workflow — Escalators

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Escalators

Escalators covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### Commercial Escalator

Commercial Escalator is a product or solution family within Escalators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Outdoor Escalator

Outdoor Escalator is a product or solution family within Escalators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Public-Transport Heavy-Duty Escalator

Public-Transport Heavy-Duty Escalator is a product or solution family within Escalators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### Balustrade

Balustrade is a relevant technical feature for Escalators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Comb Plates

Comb Plates is a relevant technical feature for Escalators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Drive And Brake System

Drive And Brake System is a relevant technical feature for Escalators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Energy-Saving Slow/Stop Controls

Energy-Saving Slow/Stop Controls is a relevant technical feature for Escalators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Entry Sensors

Entry Sensors is a relevant technical feature for Escalators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Handrail System

Handrail System is a relevant technical feature for Escalators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Indoor/Outdoor Configuration

Indoor/Outdoor Configuration is a relevant technical feature for Escalators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Skirt Safety

Skirt Safety is a relevant technical feature for Escalators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Step Band

Step Band is a relevant technical feature for Escalators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Escalators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Escalators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Escalators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Escalators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Escalators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Escalators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Escalators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Escalators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Escalators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Escalators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Escalators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Escalators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Escalators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Escalators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Escalators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Green Building Regulations and Specifications — Elevators and Escalators

Green Building Regulations and Specifications — Elevators and Escalators is a relevant authority or regulatory reference for Escalators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Escalators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Escalators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Escalators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Escalators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Escalators: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Escalators: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Escalators: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Escalators: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Escalators: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Escalators: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Escalators: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Escalators: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Application is missing

When field application is missing, ask question q-escalators-application and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-escalators-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Hourly Capacity is missing

When field hourly_capacity is missing, ask question q-escalators-hourly_capacity and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Inclination Degrees is missing

When field inclination_degrees is missing, ask question q-escalators-inclination_degrees and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-escalators-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-escalators-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Rated Speed Mps is missing

When field rated_speed_mps is missing, ask question q-escalators-rated_speed_mps and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-escalators-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Step Width Mm is missing

When field step_width_mm is missing, ask question q-escalators-step_width_mm and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Vertical Rise Mm is missing

When field vertical_rise_mm is missing, ask question q-escalators-vertical_rise_mm and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Outdoor Environment

When indoor_outdoor equals outdoor, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Application

Ask: Please provide application. Arabic: يرجى توفير Application. Reason: Application is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Balustrade Type

Ask: Please provide balustrade type. Arabic: يرجى توفير Balustrade Type. Reason: Balustrade Type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Energy Saving Mode

Ask: Please provide energy saving mode. Arabic: يرجى توفير Energy Saving Mode. Reason: Energy Saving Mode is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Horizontal Steps

Ask: Please provide horizontal steps. Arabic: يرجى توفير Horizontal Steps. Reason: Horizontal Steps is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Hourly Capacity

Ask: Please provide hourly capacity. Arabic: يرجى توفير Hourly Capacity. Reason: Hourly Capacity is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Inclination Degrees

Ask: Please provide inclination degrees. Arabic: يرجى توفير Inclination Degrees. Reason: Inclination Degrees is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Indoor Outdoor

Ask: Please provide indoor outdoor. Arabic: يرجى توفير Indoor Outdoor. Reason: Indoor Outdoor is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Rated Speed Mps

Ask: Please provide rated speed mps. Arabic: يرجى توفير Rated Speed Mps. Reason: Rated Speed Mps is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Step Width Mm

Ask: Please provide step width mm. Arabic: يرجى توفير Step Width Mm. Reason: Step Width Mm is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Traffic Direction

Ask: Please provide traffic direction. Arabic: يرجى توفير Traffic Direction. Reason: Traffic Direction is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Vertical Rise Mm

Ask: Please provide vertical rise mm. Arabic: يرجى توفير Vertical Rise Mm. Reason: Vertical Rise Mm is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Weather Protection

Ask: Please provide weather protection. Arabic: يرجى توفير Weather Protection. Reason: Weather Protection is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

## Validation

### Validate Application

Validate application before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Balustrade Type

Validate balustrade type before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Energy Saving Mode

Validate energy saving mode before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Horizontal Steps

Validate horizontal steps before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Hourly Capacity

Validate hourly capacity before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Inclination Degrees

Validate inclination degrees before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Indoor Outdoor

Validate indoor outdoor before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Rated Speed Mps

Validate rated speed mps before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Step Width Mm

Validate step width mm before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Traffic Direction

Validate traffic direction before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Vertical Rise Mm

Validate vertical rise mm before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Weather Protection

Validate weather protection before supplier dispatch for Escalators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Escalators. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests escalator for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Escalators. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Escalators. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Escalators without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Escalators. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Application

English term: Application. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Balustrade Type

English term: Balustrade Type. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Energy Saving Mode

English term: Energy Saving Mode. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Escalators

English term: Escalators. Arabic term: السلالم المتحركة. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Horizontal Steps

English term: Horizontal Steps. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Hourly Capacity

English term: Hourly Capacity. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Inclination Degrees

English term: Inclination Degrees. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Indoor Outdoor

English term: Indoor Outdoor. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Rated Speed Mps

English term: Rated Speed Mps. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Step Width Mm

English term: Step Width Mm. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Traffic Direction

English term: Traffic Direction. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Vertical Rise Mm

English term: Vertical Rise Mm. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Weather Protection

English term: Weather Protection. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### commercial escalator

English term: commercial escalator. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### escalator

English term: escalator. Arabic term: سلم متحرك. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### moving staircase

English term: moving staircase. Arabic term: سلالم متحركة. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### public transport escalator

English term: public transport escalator. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

# Moving walks and travelators / الممرات المتحركة

## Industry

### Typical UAE procurement workflow — Moving walks and travelators

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Moving walks and travelators

Moving walks and travelators covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### Horizontal Moving Walk

Horizontal Moving Walk is a product or solution family within Moving walks and travelators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Inclined Moving Walk

Inclined Moving Walk is a product or solution family within Moving walks and travelators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Pallet Travelator

Pallet Travelator is a product or solution family within Moving walks and travelators. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### Energy-Saving Controls

Energy-Saving Controls is a relevant technical feature for Moving walks and travelators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Handrails

Handrails is a relevant technical feature for Moving walks and travelators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Horizontal Or Inclined Arrangement

Horizontal Or Inclined Arrangement is a relevant technical feature for Moving walks and travelators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Landing Plates

Landing Plates is a relevant technical feature for Moving walks and travelators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Pallet Or Belt System

Pallet Or Belt System is a relevant technical feature for Moving walks and travelators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Traffic Direction Controls

Traffic Direction Controls is a relevant technical feature for Moving walks and travelators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Trolley-Compatible Design Where Required

Trolley-Compatible Design Where Required is a relevant technical feature for Moving walks and travelators. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Moving walks and travelators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Moving walks and travelators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Moving walks and travelators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Moving walks and travelators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Moving walks and travelators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Moving walks and travelators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Moving walks and travelators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Moving walks and travelators, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Moving walks and travelators. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Moving walks and travelators inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Moving walks and travelators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Moving walks and travelators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Moving walks and travelators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Moving walks and travelators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Moving walks and travelators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Green Building Regulations and Specifications — Elevators and Escalators

Green Building Regulations and Specifications — Elevators and Escalators is a relevant authority or regulatory reference for Moving walks and travelators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Moving walks and travelators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Moving walks and travelators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Moving walks and travelators. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Moving walks and travelators. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Moving walks and travelators: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Moving walks and travelators: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Moving walks and travelators: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Moving walks and travelators: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Moving walks and travelators: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Moving walks and travelators: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Moving walks and travelators: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Moving walks and travelators: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Application is missing

When field application is missing, ask question q-moving-walks-and-travelators-application and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-moving-walks-and-travelators-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Inclination Degrees is missing

When field inclination_degrees is missing, ask question q-moving-walks-and-travelators-inclination_degrees and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Length Mm is missing

When field length_mm is missing, ask question q-moving-walks-and-travelators-length_mm and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Pallet Width Mm is missing

When field pallet_width_mm is missing, ask question q-moving-walks-and-travelators-pallet_width_mm and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-moving-walks-and-travelators-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-moving-walks-and-travelators-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Rated Speed Mps is missing

When field rated_speed_mps is missing, ask question q-moving-walks-and-travelators-rated_speed_mps and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-moving-walks-and-travelators-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Trolley Use is missing

When field trolley_use is missing, ask question q-moving-walks-and-travelators-trolley_use and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Outdoor Environment

When indoor_outdoor equals outdoor, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Application

Ask: Please provide application. Arabic: يرجى توفير Application. Reason: Application is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Energy Saving Mode

Ask: Please provide energy saving mode. Arabic: يرجى توفير Energy Saving Mode. Reason: Energy Saving Mode is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Inclination Degrees

Ask: Please provide inclination degrees. Arabic: يرجى توفير Inclination Degrees. Reason: Inclination Degrees is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Indoor Outdoor

Ask: Please provide indoor outdoor. Arabic: يرجى توفير Indoor Outdoor. Reason: Indoor Outdoor is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Landing Space

Ask: Please provide landing space. Arabic: يرجى توفير Landing Space. Reason: Landing Space is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Length Mm

Ask: Please provide length mm. Arabic: يرجى توفير Length Mm. Reason: Length Mm is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Pallet Width Mm

Ask: Please provide pallet width mm. Arabic: يرجى توفير Pallet Width Mm. Reason: Pallet Width Mm is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Rated Speed Mps

Ask: Please provide rated speed mps. Arabic: يرجى توفير Rated Speed Mps. Reason: Rated Speed Mps is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Traffic Direction

Ask: Please provide traffic direction. Arabic: يرجى توفير Traffic Direction. Reason: Traffic Direction is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Trolley Use

Ask: Please provide trolley use. Arabic: يرجى توفير Trolley Use. Reason: Trolley Use is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

## Validation

### Validate Application

Validate application before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Energy Saving Mode

Validate energy saving mode before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Inclination Degrees

Validate inclination degrees before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Indoor Outdoor

Validate indoor outdoor before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Landing Space

Validate landing space before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Length Mm

Validate length mm before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Pallet Width Mm

Validate pallet width mm before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Rated Speed Mps

Validate rated speed mps before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Traffic Direction

Validate traffic direction before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Trolley Use

Validate trolley use before supplier dispatch for Moving walks and travelators. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Moving walks and travelators. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests moving walk for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Moving walks and travelators. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Moving walks and travelators. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Moving walks and travelators without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Moving walks and travelators. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Application

English term: Application. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Energy Saving Mode

English term: Energy Saving Mode. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Inclination Degrees

English term: Inclination Degrees. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Indoor Outdoor

English term: Indoor Outdoor. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Landing Space

English term: Landing Space. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Length Mm

English term: Length Mm. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Moving walks and travelators

English term: Moving walks and travelators. Arabic term: الممرات المتحركة. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Pallet Width Mm

English term: Pallet Width Mm. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Rated Speed Mps

English term: Rated Speed Mps. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Traffic Direction

English term: Traffic Direction. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Trolley Use

English term: Trolley Use. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### autowalk

English term: autowalk. Arabic term: رصيف متحرك. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### moving walk

English term: moving walk. Arabic term: ممر متحرك. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### moving walkway

English term: moving walkway. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### travelator

English term: travelator. Arabic term: ترافيلاتور. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

# Modernization and replacement / تحديث واستبدال المصاعد والسلالم

## Industry

### Typical UAE procurement workflow — Modernization and replacement

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Modernization and replacement

Modernization and replacement covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### Controller Modernization

Controller Modernization is a product or solution family within Modernization and replacement. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Door Modernization

Door Modernization is a product or solution family within Modernization and replacement. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Drive Modernization

Drive Modernization is a product or solution family within Modernization and replacement. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Escalator Modernization

Escalator Modernization is a product or solution family within Modernization and replacement. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Fixture Upgrade

Fixture Upgrade is a product or solution family within Modernization and replacement. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Full Elevator Replacement

Full Elevator Replacement is a product or solution family within Modernization and replacement. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### Controller Replacement

Controller Replacement is a relevant technical feature for Modernization and replacement. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Door Operator Upgrade

Door Operator Upgrade is a relevant technical feature for Modernization and replacement. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Drive Replacement

Drive Replacement is a relevant technical feature for Modernization and replacement. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Fixture And Cop/Lop Upgrade

Fixture And Cop/Lop Upgrade is a relevant technical feature for Modernization and replacement. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Full Replacement

Full Replacement is a relevant technical feature for Modernization and replacement. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Machine Or Traction Upgrade

Machine Or Traction Upgrade is a relevant technical feature for Modernization and replacement. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Remote Monitoring

Remote Monitoring is a relevant technical feature for Modernization and replacement. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Safety Circuit Modernization

Safety Circuit Modernization is a relevant technical feature for Modernization and replacement. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Modernization and replacement, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Modernization and replacement, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Modernization and replacement, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Modernization and replacement, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Modernization and replacement, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Modernization and replacement, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Modernization and replacement, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Modernization and replacement, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Modernization and replacement. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Modernization and replacement inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Modernization and replacement. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Modernization and replacement. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Modernization and replacement. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Modernization and replacement. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Modernization and replacement. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Modernization and replacement. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Modernization and replacement. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Modernization and replacement. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Modernization and replacement. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Modernization and replacement: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Modernization and replacement: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Modernization and replacement: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Modernization and replacement: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Modernization and replacement: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Modernization and replacement: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Modernization and replacement: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Modernization and replacement: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Asset Serial Number is missing

When field asset_serial_number is missing, ask question q-modernization-and-replacement-asset_serial_number and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-modernization-and-replacement-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Current Faults is missing

When field current_faults is missing, ask question q-modernization-and-replacement-current_faults and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Existing Brand is missing

When field existing_brand is missing, ask question q-modernization-and-replacement-existing_brand and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Existing Model is missing

When field existing_model is missing, ask question q-modernization-and-replacement-existing_model and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Obsolescence Status is missing

When field obsolescence_status is missing, ask question q-modernization-and-replacement-obsolescence_status and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-modernization-and-replacement-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-modernization-and-replacement-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-modernization-and-replacement-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Year Installed is missing

When field year_installed is missing, ask question q-modernization-and-replacement-year_installed and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Existing Asset Missing

When project_stage equals existing asset, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Asbestos Or Hazardous Materials

Ask: Please provide asbestos or hazardous materials. Arabic: يرجى توفير Asbestos Or Hazardous Materials. Reason: Asbestos Or Hazardous Materials is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Asset Serial Number

Ask: Please provide asset serial number. Arabic: يرجى توفير Asset Serial Number. Reason: Asset Serial Number is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Authority Recertification

Ask: Please provide authority recertification. Arabic: يرجى توفير Authority Recertification. Reason: Authority Recertification is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Components To Retain

Ask: Please provide components to retain. Arabic: يرجى توفير Components To Retain. Reason: Components To Retain is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Current Faults

Ask: Please provide current faults. Arabic: يرجى توفير Current Faults. Reason: Current Faults is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Existing Brand

Ask: Please provide existing brand. Arabic: يرجى توفير Existing Brand. Reason: Existing Brand is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Existing Model

Ask: Please provide existing model. Arabic: يرجى توفير Existing Model. Reason: Existing Model is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Obsolescence Status

Ask: Please provide obsolescence status. Arabic: يرجى توفير Obsolescence Status. Reason: Obsolescence Status is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Required Downtime

Ask: Please provide required downtime. Arabic: يرجى توفير Required Downtime. Reason: Required Downtime is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Target Performance

Ask: Please provide target performance. Arabic: يرجى توفير Target Performance. Reason: Target Performance is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Year Installed

Ask: Please provide year installed. Arabic: يرجى توفير Year Installed. Reason: Year Installed is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

## Validation

### Validate Asbestos Or Hazardous Materials

Validate asbestos or hazardous materials before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Asset Serial Number

Validate asset serial number before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Authority Recertification

Validate authority recertification before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Components To Retain

Validate components to retain before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Current Faults

Validate current faults before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Existing Brand

Validate existing brand before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Existing Model

Validate existing model before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Obsolescence Status

Validate obsolescence status before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required Downtime

Validate required downtime before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Target Performance

Validate target performance before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Year Installed

Validate year installed before supplier dispatch for Modernization and replacement. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Modernization and replacement. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests elevator modernization for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Modernization and replacement. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Modernization and replacement. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Modernization and replacement without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Modernization and replacement. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Asbestos Or Hazardous Materials

English term: Asbestos Or Hazardous Materials. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Asset Serial Number

English term: Asset Serial Number. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Authority Recertification

English term: Authority Recertification. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Components To Retain

English term: Components To Retain. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Current Faults

English term: Current Faults. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Existing Brand

English term: Existing Brand. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Existing Model

English term: Existing Model. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Modernization and replacement

English term: Modernization and replacement. Arabic term: تحديث واستبدال المصاعد والسلالم. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Obsolescence Status

English term: Obsolescence Status. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Required Downtime

English term: Required Downtime. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Target Performance

English term: Target Performance. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Year Installed

English term: Year Installed. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### controller replacement

English term: controller replacement. Arabic term: استبدال مصعد. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### elevator modernization

English term: elevator modernization. Arabic term: تحديث مصعد. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### escalator modernization

English term: escalator modernization. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### full replacement

English term: full replacement. Arabic term: تحديث سلم متحرك. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### lift upgrade

English term: lift upgrade. Arabic term: تطوير مصعد. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

# Maintenance, inspection and certification / الصيانة والفحص والاعتماد

## Industry

### Typical UAE procurement workflow — Maintenance, inspection and certification

The normal workflow is project or asset definition, jurisdiction and authority check, traffic or use analysis, equipment schedule, builder’s-work coordination, technical specification, supplier prequalification, quotation, design/shop drawing review, authority or third-party review where required, manufacture, logistics, installation, testing, commissioning, inspection, conformity evidence, handover, warranty and maintenance. Existing-equipment work additionally requires asset identification, condition assessment, fault history, obsolescence review and a downtime plan.

### Industry scope — Maintenance, inspection and certification

Maintenance, inspection and certification covers the planning, supply, installation, commissioning, maintenance, modernization or inspection of vertical-transportation equipment appropriate to the stated use. The inquiry agent must distinguish equipment purpose, people or load characteristics, building geometry, traffic, speed, capacity, landing arrangement, site constraints, life-safety interfaces and lifecycle scope before requesting a quotation. A generic request for “a lift” is not quote-ready because passenger, bed, freight, accessibility, vehicle, firefighter, escalator and maintenance scopes have materially different requirements.

## Products Services

### Callout Repair

Callout Repair is a product or solution family within Maintenance, inspection and certification. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Comprehensive Maintenance Contract

Comprehensive Maintenance Contract is a product or solution family within Maintenance, inspection and certification. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Condition Assessment

Condition Assessment is a product or solution family within Maintenance, inspection and certification. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Conformity Certification

Conformity Certification is a product or solution family within Maintenance, inspection and certification. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Preventive Maintenance Contract

Preventive Maintenance Contract is a product or solution family within Maintenance, inspection and certification. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

### Third-Party Inspection

Third-Party Inspection is a product or solution family within Maintenance, inspection and certification. The platform must not infer a specific model from the family name. It should collect intended use, capacity, geometry, performance, interfaces, approvals, finishes, warranty, maintenance and delivery requirements, then require the supplier to identify the exact offered model and submit current manufacturer technical documentation and compliance evidence.

## Technical

### 24/7 Callout Option

24/7 Callout Option is a relevant technical feature for Maintenance, inspection and certification. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Condition Reporting

Condition Reporting is a relevant technical feature for Maintenance, inspection and certification. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Defect Closure Tracking

Defect Closure Tracking is a relevant technical feature for Maintenance, inspection and certification. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Entrapment Response

Entrapment Response is a relevant technical feature for Maintenance, inspection and certification. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Parts Coverage

Parts Coverage is a relevant technical feature for Maintenance, inspection and certification. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Preventive Visits

Preventive Visits is a relevant technical feature for Maintenance, inspection and certification. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Remote Monitoring

Remote Monitoring is a relevant technical feature for Maintenance, inspection and certification. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

### Statutory Inspection Coordination

Statutory Inspection Coordination is a relevant technical feature for Maintenance, inspection and certification. Whether it is mandatory depends on application, code route, traffic, environment and customer requirements. The agent should ask only when applicable, record the answer as a structured field and require the supplier to disclose deviations, assumptions and manufacturer limitations.

## Brands Manufacturers

### Hyundai Elevator

Hyundai Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### KONE

KONE is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Mitsubishi Electric

Mitsubishi Electric is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Otis

Otis is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### Schindler

Schindler is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

### TK Elevator

TK Elevator is a major international vertical-transportation brand with products or services relevant to parts of this category. This entry is a market-navigation example, not an endorsement, proof of UAE authorization or confirmation that every product family is available. Verify the exact model, local legal entity or authorized partner, current catalogue, spare-parts support, warranty and maintenance capability.

## Supplier Ecosystem

### Authorized Distributor Or Partner

A authorized distributor or partner may participate in Maintenance, inspection and certification, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Eiac-Accredited Inspection Body

A EIAC-accredited inspection body may participate in Maintenance, inspection and certification, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Independent Maintenance Contractor

A independent maintenance contractor may participate in Maintenance, inspection and certification, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Licensed Installation Contractor

A licensed installation contractor may participate in Maintenance, inspection and certification, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Lift Interior Specialist

A lift interior specialist may participate in Maintenance, inspection and certification, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Modernization Specialist

A modernization specialist may participate in Maintenance, inspection and certification, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Oem Manufacturer Branch

A OEM manufacturer branch may participate in Maintenance, inspection and certification, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

### Vertical Transportation Consultant

A vertical transportation consultant may participate in Maintenance, inspection and certification, but eligibility depends on the exact scope. The platform should verify trade-licence activity, manufacturer authorization when claimed, competent staff, insurance, relevant project references, emergency coverage, parts support, quality/safety systems, authority registrations and inspection accreditation where applicable.

## Commercial Pricing

### Cost driver 10: controls, destination dispatch and system integrations

Controls, destination dispatch and system integrations can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 11: site logistics, access and working-hour restrictions

Site logistics, access and working-hour restrictions can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 12: testing, inspection, certification and authority support

Testing, inspection, certification and authority support can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 13: warranty, maintenance coverage and response SLA

Warranty, maintenance coverage and response sla can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 14: brand policy, origin, lead time and spare-parts support

Brand policy, origin, lead time and spare-parts support can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 15: payment terms, quotation validity and currency exposure

Payment terms, quotation validity and currency exposure can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 1: equipment type and intended use

Equipment type and intended use can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 2: quantity and number of stops

Quantity and number of stops can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 3: travel height and floor geometry

Travel height and floor geometry can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 4: rated load or passenger capacity

Rated load or passenger capacity can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 5: rated speed and traffic performance

Rated speed and traffic performance can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 6: shaft, pit, overhead and machine-room constraints

Shaft, pit, overhead and machine-room constraints can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 7: door size, type and number of entrances

Door size, type and number of entrances can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 8: car or balustrade finishes

Car or balustrade finishes can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

### Cost driver 9: fire, accessibility and emergency-power requirements

Fire, accessibility and emergency-power requirements can materially change the price, lead time or technical solution for Maintenance, inspection and certification. The platform should collect the associated field before comparing quotations. Exact prices must come from time-stamped supplier quotations or transactions; when a value is unknown, each supplier must state its assumption, exclusion and quotation-validity period.

## Quotation

### Commercial Normalization

Normalize currency, VAT basis, payment terms, validity, delivery, installation, testing, inspection, training, spares, warranty, maintenance and exclusions before ranking quotations.

### Deviation Control

Every alternative or approved equal must include a clause-by-clause compliance matrix and clearly identify deviations, approval risk and effect on builder’s work.

### Scope Normalization

Require every supplier to quote against the same equipment schedule, scope boundaries, interfaces, inclusions, exclusions, assumptions, lead time, warranty and maintenance basis.

## Documents

### Accessibility Plan

Accessibility Plan may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Approved Brand/Vendor Requirements

Approved Brand/Vendor Requirements may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Architectural Plans And Sections

Architectural Plans And Sections may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### As-Built Drawings

As-Built Drawings may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Authority Approval Or Noc Records

Authority Approval Or Noc Records may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Boq Or Pricing Schedule

Boq Or Pricing Schedule may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Electrical Single-Line Diagram And Load Schedule

Electrical Single-Line Diagram And Load Schedule may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Fire Strategy And Life-Safety Drawings

Fire Strategy And Life-Safety Drawings may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Inspection Certificates And Conformity Sticker Details

Inspection Certificates And Conformity Sticker Details may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Lift/Escalator Schedule

Lift/Escalator Schedule may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Maintenance Logs And Fault History

Maintenance Logs And Fault History may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Method Statement And Risk Assessment

Method Statement And Risk Assessment may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Operation And Maintenance Manuals

Operation And Maintenance Manuals may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shaft, Pit And Overhead Builder’S-Work Drawings

Shaft, Pit And Overhead Builder’S-Work Drawings may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Shop Drawings

Shop Drawings may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Structural Opening And Support Details

Structural Opening And Support Details may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Technical Specification

Technical Specification may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Testing And Commissioning Plan

Testing And Commissioning Plan may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Vertical Transportation Design Report Or Traffic Analysis

Vertical Transportation Design Report Or Traffic Analysis may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

### Warranty Certificates

Warranty Certificates may be required to qualify or verify a Maintenance, inspection and certification inquiry. The agent should first check whether an uploaded file already answers the relevant fields. When the document is missing, ask for it only if it materially affects quotation, coordination, compliance or supplier eligibility. Conflicts between the document and chat answers must be flagged and resolved before dispatch.

## Uae Regulations

### Abu Dhabi International Building Code

Abu Dhabi International Building Code is a relevant authority or regulatory reference for Maintenance, inspection and certification. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Abu Dhabi International Property Maintenance Code

Abu Dhabi International Property Maintenance Code is a relevant authority or regulatory reference for Maintenance, inspection and certification. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories

Accreditation Requirements for Inspection Bodies working in Lifting Equipment & Lifting Accessories is a relevant authority or regulatory reference for Maintenance, inspection and certification. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Conditions for Use of EIAC Accreditation Symbol and Marks

Conditions for Use of EIAC Accreditation Symbol and Marks is a relevant authority or regulatory reference for Maintenance, inspection and certification. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Dubai Building Code, 2021 Edition

Dubai Building Code, 2021 Edition is a relevant authority or regulatory reference for Maintenance, inspection and certification. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Objectives and overview of Dubai Building Code

Objectives and overview of Dubai Building Code is a relevant authority or regulatory reference for Maintenance, inspection and certification. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Public Utility Services — control and inspection of public safety

Public Utility Services — control and inspection of public safety is a relevant authority or regulatory reference for Maintenance, inspection and certification. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

### Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances

Technical Guidelines 48 for Examination and Certification of Cranes, Hoists, Lifts and Other Lifting Appliances is a relevant authority or regulatory reference for Maintenance, inspection and certification. The runtime must activate it according to jurisdiction, project type, lifecycle stage and current adoption. The agent may retrieve and organize exact provisions from a controlled internal copy, but it must not claim approval, perform engineering design or resolve legal ambiguity without qualified review.

## Risk

### Door Or Car Size Unsuitable For Intended Use

Door or car size unsuitable for intended use is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Fire And Accessibility Non-Compliance

Fire and accessibility non-compliance is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Incorrect Traffic Capacity

Incorrect traffic capacity is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Insufficient Shaft Or Landing Geometry

Insufficient shaft or landing geometry is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Late Coordination With Structure And Mep

Late coordination with structure and mep is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Long Lead Time And Logistics Constraints

Long lead time and logistics constraints is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Pit Or Overhead Conflict

Pit or overhead conflict is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Power And Emergency-Power Mismatch

Power and emergency-power mismatch is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Under-Scoped Maintenance Exclusions

Under-scoped maintenance exclusions is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unsafe Work During Installation Or Modernization

Unsafe work during installation or modernization is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Unverified Brand Authorization Or Spare-Parts Support

Unverified brand authorization or spare-parts support is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

### Water Ingress Or Harsh-Environment Exposure

Water ingress or harsh-environment exposure is a recurring risk in Maintenance, inspection and certification. The agent should collect the related evidence, identify who owns the decision, prevent supplier dispatch if a mandatory safety or coordination item is unresolved, and escalate design, authority or legal interpretations to a qualified professional.

## Troubleshooting

### Door Faults

For door faults in Maintenance, inspection and certification: Check landing and car door operators, sills, sensors, alignment, misuse and obstruction. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Entrapment History

For entrapment history in Maintenance, inspection and certification: Review rescue device, power quality, controller faults, door faults, response process and emergency communication. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Frequent Breakdowns

For frequent breakdowns in Maintenance, inspection and certification: Review fault codes, maintenance logs, age, controller/door condition, parts availability and usage pattern. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Noise Or Vibration

For noise or vibration in Maintenance, inspection and certification: Inspect guides, rollers/shoes, machine, ropes/belts, alignment, car balance and structural interfaces. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Obsolete Parts

For obsolete parts in Maintenance, inspection and certification: Confirm manufacturer support, compatible replacements, modernization pathway and downtime plan. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Poor Levelling

For poor levelling in Maintenance, inspection and certification: Check drive, encoder, brake, load weighing, guide condition and controller calibration. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Slow Performance

For slow performance in Maintenance, inspection and certification: Compare traffic demand, speed, door time, control algorithm and group operation. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

### Water Ingress

For water ingress in Maintenance, inspection and certification: Inspect pit drainage, shaft sealing, sump pump, waterproofing and equipment damage. The platform may organize evidence and questions but must not authorize unsafe operation or certify equipment. Immediate safety concerns, entrapment, fire-service faults or failed inspection require escalation to the responsible maintenance company, inspection body or authority.

## Inquiry Qualification

### Approved Equal

When brand_policy equals approved equal allowed, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Ask when Asset Register is missing

When field asset_register is missing, ask question q-maintenance-inspection-and-certification-asset_register and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Brands And Models is missing

When field brands_and_models is missing, ask question q-maintenance-inspection-and-certification-brands_and_models and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Building or facility type is missing

When field building_type is missing, ask question q-maintenance-inspection-and-certification-building_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Current Contract Scope is missing

When field current_contract_scope is missing, ask question q-maintenance-inspection-and-certification-current_contract_scope and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Equipment Count is missing

When field equipment_count is missing, ask question q-maintenance-inspection-and-certification-equipment_count and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Fault History is missing

When field fault_history is missing, ask question q-maintenance-inspection-and-certification-fault_history and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project emirate is missing

When field project_emirate is missing, ask question q-maintenance-inspection-and-certification-project_emirate and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Project stage is missing

When field project_stage is missing, ask question q-maintenance-inspection-and-certification-project_stage and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Required scope is missing

When field scope_type is missing, ask question q-maintenance-inspection-and-certification-scope_type and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Ask when Year Installed is missing

When field year_installed is missing, ask question q-maintenance-inspection-and-certification-year_installed and set the inquiry status to needs_information. This rule is deterministic. Conflicting document evidence or unresolved design, fire, accessibility or authority interpretation must be escalated.

### Existing Asset Missing

When project_stage equals existing asset, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Urgent Programme

When required_completion_date within_days 90, execute the listed deterministic actions. Any unresolved professional or authority interpretation is escalated.

### Asset Register

Ask: Please provide asset register. Arabic: يرجى توفير Asset Register. Reason: Asset Register is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Available electrical supply and backup power

Ask: Please provide available electrical supply and backup power. Arabic: يرجى توفير مصدر الكهرباء والطاقة الاحتياطية. Reason: Available electrical supply and backup power is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brand policy

Ask: Please provide brand policy. Arabic: يرجى توفير سياسة العلامة التجارية. Reason: Brand policy is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Brands And Models

Ask: Please provide brands and models. Arabic: يرجى توفير Brands And Models. Reason: Brands And Models is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Building or facility type

Ask: Please provide building or facility type. Arabic: يرجى توفير نوع المبنى أو المنشأة. Reason: Building or facility type is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Certificate Expiry

Ask: Please provide certificate expiry. Arabic: يرجى توفير Certificate Expiry. Reason: Certificate Expiry is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Current Contract Scope

Ask: Please provide current contract scope. Arabic: يرجى توفير Current Contract Scope. Reason: Current Contract Scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Entrapment History

Ask: Please provide entrapment history. Arabic: يرجى توفير Entrapment History. Reason: Entrapment History is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Equipment Count

Ask: Please provide equipment count. Arabic: يرجى توفير Equipment Count. Reason: Equipment Count is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Fault History

Ask: Please provide fault history. Arabic: يرجى توفير Fault History. Reason: Fault History is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

### Inspection Body Accreditation

Ask: Please provide inspection body accreditation. Arabic: يرجى توفير Inspection Body Accreditation. Reason: Inspection Body Accreditation is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Last Inspection Date

Ask: Please provide last inspection date. Arabic: يرجى توفير Last Inspection Date. Reason: Last Inspection Date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Maintenance or AMC requirement

Ask: Please provide maintenance or amc requirement. Arabic: يرجى توفير متطلبات الصيانة أو عقد الصيانة. Reason: Maintenance or AMC requirement is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Parts Inclusion

Ask: Please provide parts inclusion. Arabic: يرجى توفير Parts Inclusion. Reason: Parts Inclusion is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project emirate

Ask: Please provide project emirate. Arabic: يرجى توفير إمارة المشروع. Reason: Project emirate is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Project location and site access

Ask: Please provide project location and site access. Arabic: يرجى توفير موقع المشروع والوصول إلى الموقع. Reason: Project location and site access is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Project stage

Ask: Please provide project stage. Arabic: يرجى توفير مرحلة المشروع. Reason: Project stage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: single_select. This is mandatory and blocks supplier dispatch when absent.

### Required completion or handover date

Ask: Please provide required completion or handover date. Arabic: يرجى توفير تاريخ الإنجاز أو التسليم المطلوب. Reason: Required completion or handover date is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: date. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Required scope

Ask: Please provide required scope. Arabic: يرجى توفير النطاق المطلوب. Reason: Required scope is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: multi_select. This is mandatory and blocks supplier dispatch when absent.

### Required warranty period and coverage

Ask: Please provide required warranty period and coverage. Arabic: يرجى توفير مدة الضمان والتغطية المطلوبة. Reason: Required warranty period and coverage is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Response Time Sla

Ask: Please provide response time sla. Arabic: يرجى توفير Response Time Sla. Reason: Response Time Sla is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is conditional or optional; if absent, the quotation must state the assumption or exclusion.

### Year Installed

Ask: Please provide year installed. Arabic: يرجى توفير Year Installed. Reason: Year Installed is required to define scope, select the correct equipment or service, evaluate interfaces and make supplier quotations comparable. Expected answer type: text. This is mandatory and blocks supplier dispatch when absent.

## Validation

### Validate Asset Register

Validate asset register before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Available electrical supply and backup power

Validate available electrical supply and backup power before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brand policy

Validate brand policy before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Brands And Models

Validate brands and models before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Building or facility type

Validate building or facility type before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Certificate Expiry

Validate certificate expiry before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Current Contract Scope

Validate current contract scope before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Entrapment History

Validate entrapment history before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Equipment Count

Validate equipment count before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Fault History

Validate fault history before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Inspection Body Accreditation

Validate inspection body accreditation before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Last Inspection Date

Validate last inspection date before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Maintenance or AMC requirement

Validate maintenance or amc requirement before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Parts Inclusion

Validate parts inclusion before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project emirate

Validate project emirate before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project location and site access

Validate project location and site access before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Project stage

Validate project stage before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required completion or handover date

Validate required completion or handover date before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required scope

Validate required scope before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Required warranty period and coverage

Validate required warranty period and coverage before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Response Time Sla

Validate response time sla before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

### Validate Year Installed

Validate year installed before supplier dispatch for Maintenance, inspection and certification. Reject impossible negative values, inconsistent units, values outside the chosen product family and contradictions with drawings, schedules or certificates. Do not silently correct the customer; ask for confirmation and preserve the original answer.

## Scenario Test

### Approved Equal

Test input: Customer permits an approved equal brand for Maintenance, inspection and certification. Expected outcome: needs_compliance_matrix. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Basic New Supply

Test input: Customer requests elevator maintenance for a new building but provides no technical schedule. Expected outcome: needs_information. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Complete Quote Ready

Test input: Customer provides jurisdiction, use, geometry, capacity, performance, documents, programme and scope for Maintenance, inspection and certification. Expected outcome: quote_ready. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Document Conflict

Test input: Customer states one capacity but the attached lift schedule shows another for Maintenance, inspection and certification. Expected outcome: hold_and_clarify. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Regulated Unknown

Test input: Customer asks the platform to certify compliance for Maintenance, inspection and certification without current authority or inspection evidence. Expected outcome: escalate. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

### Urgent Delivery

Test input: Customer requires completion in less than 90 days for Maintenance, inspection and certification. Expected outcome: schedule_risk. The test passes only when deterministic routing, question selection, conflict handling and escalation match the expected result.

## Glossary

### Asset Register

English term: Asset Register. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Brands And Models

English term: Brands And Models. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Certificate Expiry

English term: Certificate Expiry. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Current Contract Scope

English term: Current Contract Scope. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Entrapment History

English term: Entrapment History. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Equipment Count

English term: Equipment Count. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Fault History

English term: Fault History. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Inspection Body Accreditation

English term: Inspection Body Accreditation. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Last Inspection Date

English term: Last Inspection Date. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Maintenance, inspection and certification

English term: Maintenance, inspection and certification. Arabic term: الصيانة والفحص والاعتماد. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Parts Inclusion

English term: Parts Inclusion. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Response Time Sla

English term: Response Time Sla. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### Year Installed

English term: Year Installed. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### elevator certificate

English term: elevator certificate. Arabic term: إصلاح مصعد. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### elevator maintenance

English term: elevator maintenance. Arabic term: صيانة مصاعد. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### escalator maintenance

English term: escalator maintenance. Arabic term: فحص مصعد. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### lift AMC

English term: lift AMC. Arabic term: عقد صيانة مصاعد. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### lift repair

English term: lift repair. Arabic term: Arabic translation requires technical review. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.

### third party inspection

English term: third party inspection. Arabic term: شهادة مصعد. Use this term for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and do not treat a synonym as proof of an exact product, rating, model or compliance class.
