# QD-KB-086 — Lifts & Escalators

Production knowledge supplement for operational catalogue category 86.

- Subcategories: 12
- Atomic records: 2047
- Master characters: 828,412
- Build date: 2026-07-31

Use structured JSONL files for ingestion. Do not send the master file to a language model at runtime. Preserve source lineage, validation status, review date and escalation rules.
