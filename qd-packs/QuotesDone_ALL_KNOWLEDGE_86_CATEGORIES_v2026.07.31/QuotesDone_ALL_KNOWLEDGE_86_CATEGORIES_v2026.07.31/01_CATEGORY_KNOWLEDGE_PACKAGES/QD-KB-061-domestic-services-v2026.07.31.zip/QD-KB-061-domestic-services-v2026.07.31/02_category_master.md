# Domestic Services — Complete Knowledge Master

**Package:** QD-KB-061-domestic-services-v2026.07.31  
**Arabic:** الخدمات المنزلية  
**Status:** production draft; not SME/regulatory approved  
**Subcategories:** 4

> This is the human-audit view. Runtime must use atomic JSONL records, deterministic questions/rules and selective retrieval rather than loading this entire file into a prompt.


# 01. Maid services / خدمات العمالة المنزلية

**Aliases:** Maid services, domestic worker services, housekeeping staff, home helper

## industry — Industry scope — Maid services

Maid services sits within Domestic Services and covers domestic-worker, babysitting, elderly-care and home-nursing services where licensed recruitment/employment, worker rights, safeguarding, care scope, clinical boundaries, privacy and continuity are critical. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-domestic-services-maid-services-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Maid services","aliases_en":["Maid services","domestic worker services","housekeeping staff","home helper"],"aliases_ar":["خدمات العمالة المنزلية"],"sequence":1}`

## industry — UAE procurement workflow — Maid services

A typical UAE procurement path for Maid services moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-domestic-services-maid-services-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Maid services","aliases_en":["Maid services","domestic worker services","housekeeping staff","home helper"],"aliases_ar":["خدمات العمالة المنزلية"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Maid services

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include licensed provider, recruitment center, employer/contracting entity, care coordinator, licensed nurse, trained caregiver. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-domestic-services-maid-services-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Maid services","aliases_en":["Maid services","domestic worker services","housekeeping staff","home helper"],"aliases_ar":["خدمات العمالة المنزلية"],"sequence":3}`

## industry — Scope boundaries and escalation — Maid services

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Maid services. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Maid services","aliases_en":["Maid services","domestic worker services","housekeeping staff","home helper"],"aliases_ar":["خدمات العمالة المنزلية"],"sequence":4}`

## products_services — maid placement

maid placement is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"maid placement","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — hourly cleaning/domestic help

hourly cleaning/domestic help is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"hourly cleaning/domestic help","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — live-in domestic worker

live-in domestic worker is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"live-in domestic worker","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — babysitting

babysitting is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"babysitting","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — childcare support

childcare support is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"childcare support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — elderly companion care

elderly companion care is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"elderly companion care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — personal care support

personal care support is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"personal care support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — home nursing visit

home nursing visit is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"home nursing visit","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — live-in nurse

live-in nurse is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"live-in nurse","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — post-operative home care

post-operative home care is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"post-operative home care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — medication support

medication support is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"medication support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — mobility assistance

mobility assistance is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"mobility assistance","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — respite care

respite care is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"respite care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — household service plan

household service plan is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"household service plan","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — replacement/continuity service

replacement/continuity service is a product or service family relevant to Maid services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-maid-services-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"replacement/continuity service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — service classification

Technical topic: service classification. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"service classification","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — licensed provider

Technical topic: licensed provider. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"licensed provider","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — worker employment status

Technical topic: worker employment status. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"worker employment status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — client/household profile

Technical topic: client/household profile. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"client/household profile","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — beneficiary age and condition

Technical topic: beneficiary age and condition. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"beneficiary age and condition","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — scope and exclusions

Technical topic: scope and exclusions. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"scope and exclusions","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — working hours/rest

Technical topic: working hours/rest. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"working hours/rest","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — accommodation/transport

Technical topic: accommodation/transport. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"accommodation/transport","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — language and competence

Technical topic: language and competence. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"language and competence","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — background/identity verification

Technical topic: background/identity verification. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"background/identity verification","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — safeguarding

Technical topic: safeguarding. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"safeguarding","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — clinical licence and care plan

Technical topic: clinical licence and care plan. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"clinical licence and care plan","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — medication and emergency protocol

Technical topic: medication and emergency protocol. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"medication and emergency protocol","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — privacy/consent

Technical topic: privacy/consent. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"privacy/consent","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — insurance/liability

Technical topic: insurance/liability. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"insurance/liability","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — continuity/replacement

Technical topic: continuity/replacement. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"continuity/replacement","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — complaint and escalation

Technical topic: complaint and escalation. For Maid services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-maid-services-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"complaint and escalation","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — licensed domestic-worker center

licensed domestic-worker center is a supplier-market role or example for Maid services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-maid-services-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed domestic-worker center","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed domestic-service company

licensed domestic-service company is a supplier-market role or example for Maid services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-maid-services-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed domestic-service company","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed childcare provider

licensed childcare provider is a supplier-market role or example for Maid services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-maid-services-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed childcare provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed home-healthcare provider

licensed home-healthcare provider is a supplier-market role or example for Maid services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-maid-services-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed home-healthcare provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed nursing facility

licensed nursing facility is a supplier-market role or example for Maid services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-maid-services-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed nursing facility","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — care-management provider

care-management provider is a supplier-market role or example for Maid services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-maid-services-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"care-management provider","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — licensed provider

Supplier type: licensed provider. In Maid services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"licensed provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — licensed provider

Eligibility gate 1 for a licensed provider responding to Maid services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"licensed provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — recruitment center

Supplier type: recruitment center. In Maid services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"recruitment center","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — recruitment center

Eligibility gate 2 for a recruitment center responding to Maid services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"recruitment center","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — employer/contracting entity

Supplier type: employer/contracting entity. In Maid services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"employer/contracting entity","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — employer/contracting entity

Eligibility gate 3 for a employer/contracting entity responding to Maid services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"employer/contracting entity","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — care coordinator

Supplier type: care coordinator. In Maid services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"care coordinator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — care coordinator

Eligibility gate 4 for a care coordinator responding to Maid services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"care coordinator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — licensed nurse

Supplier type: licensed nurse. In Maid services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"licensed nurse","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — licensed nurse

Eligibility gate 5 for a licensed nurse responding to Maid services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"licensed nurse","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — trained caregiver

Supplier type: trained caregiver. In Maid services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"trained caregiver","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — trained caregiver

Eligibility gate 6 for a trained caregiver responding to Maid services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"trained caregiver","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — background-check provider

Supplier type: background-check provider. In Maid services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"background-check provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — background-check provider

Eligibility gate 7 for a background-check provider responding to Maid services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"background-check provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — emergency support provider

Supplier type: emergency support provider. In Maid services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"emergency support provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — emergency support provider

Eligibility gate 8 for a emergency support provider responding to Maid services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-maid-services-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"emergency support provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — service and beneficiary

Quotation requirement: service and beneficiary. Every supplier response for Maid services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-maid-services-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"service_and_beneficiary","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — hours/live-in arrangement

Quotation requirement: hours/live-in arrangement. Every supplier response for Maid services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-maid-services-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"hours_live_in_arrangement","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — licence/employment model

Quotation requirement: licence/employment model. Every supplier response for Maid services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-maid-services-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"licence_employment_model","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — skills/language

Quotation requirement: skills/language. Every supplier response for Maid services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-maid-services-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"skills_language","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — care or task scope

Quotation requirement: care or task scope. Every supplier response for Maid services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-maid-services-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"care_or_task_scope","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — safeguarding/privacy

Quotation requirement: safeguarding/privacy. Every supplier response for Maid services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-maid-services-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"safeguarding_privacy","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — pricing and overtime

Quotation requirement: pricing and overtime. Every supplier response for Maid services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-maid-services-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"pricing_and_overtime","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — replacement/continuity

Quotation requirement: replacement/continuity. Every supplier response for Maid services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-maid-services-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"replacement_continuity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — insurance/liability

Quotation requirement: insurance/liability. Every supplier response for Maid services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-maid-services-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"insurance_liability","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — complaints/emergency

Quotation requirement: complaints/emergency. Every supplier response for Maid services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-maid-services-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"complaints_emergency","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — service request

Document: service request. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"service_request","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — provider licence

Document: provider licence. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"provider_licence","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — employment/service contract

Document: employment/service contract. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"employment_service_contract","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — worker identity/qualification

Document: worker identity/qualification. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"worker_identity_qualification","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — background/verification evidence

Document: background/verification evidence. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"background_verification_evidence","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — job description

Document: job description. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"job_description","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — care plan

Document: care plan. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"care_plan","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — clinical licence

Document: clinical licence. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"clinical_licence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — medication order

Document: medication order. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"medication_order","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — risk/safeguarding plan

Document: risk/safeguarding plan. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"risk_safeguarding_plan","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — consent/privacy form

Document: consent/privacy form. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"consent_privacy_form","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — schedule/roster

Document: schedule/roster. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"schedule_roster","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — insurance evidence

Document: insurance evidence. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"insurance_evidence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — complaint/emergency procedure

Document: complaint/emergency procedure. For Maid services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-maid-services-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"complaint_emergency_procedure","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — Labour and Domestic Worker Services and Regulations

Source activation for Maid services: Labour and Domestic Worker Services and Regulations (Ministry of Human Resources and Emiratisation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify licensed recruitment, work arrangement, contracts, rights and complaint procedures.

- Record ID: `qd-kb-domestic-services-maid-services-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE
- Structured data: `{"source_id":"UAE-MOHRE","publisher":"Ministry of Human Resources and Emiratisation","url":"https://www.mohre.gov.ae/en/home.aspx","source_type":"government_labour_portal","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 9 of 2022 on Domestic Workers

Source activation for Maid services: Federal Decree-Law No. 9 of 2022 on Domestic Workers (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use current consolidated law and implementing resolution; legal interpretation requires counsel.

- Record ID: `qd-kb-domestic-services-maid-services-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"source_id":"UAE-DOMESTIC-WORKERS-LAW","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1593/download","source_type":"federal_law","live_verification":true}`

## uae_regulations — Cabinet Resolution No. 106 of 2022 on Domestic Workers

Source activation for Maid services: Cabinet Resolution No. 106 of 2022 on Domestic Workers (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify amendments and current official implementation.

- Record ID: `qd-kb-domestic-services-maid-services-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DOMESTIC-WORKERS-EXEC
- Structured data: `{"source_id":"UAE-DOMESTIC-WORKERS-EXEC","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1620/download","source_type":"federal_executive_regulation","live_verification":true}`

## uae_regulations — Dubai Health Authority Policies and Regulations

Source activation for Maid services: Dubai Health Authority Policies and Regulations (Dubai Health Authority). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Clinical and home-healthcare services require licensed providers and current standards.

- Record ID: `qd-kb-domestic-services-maid-services-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DHA-POLICIES
- Structured data: `{"source_id":"UAE-DHA-POLICIES","publisher":"Dubai Health Authority","url":"https://www.dha.gov.ae/en/licensing-regulations-policies","source_type":"government_health_regulator","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Maid services: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-domestic-services-maid-services-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Maid services: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-domestic-services-maid-services-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Maid services: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-domestic-services-maid-services-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — Labour and Domestic Worker Services and Regulations

Source activation for Maid services: Labour and Domestic Worker Services and Regulations (Ministry of Human Resources and Emiratisation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify licensed recruitment, work arrangement, contracts, rights and complaint procedures.

- Record ID: `qd-kb-domestic-services-maid-services-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE
- Structured data: `{"source_id":"UAE-MOHRE","publisher":"Ministry of Human Resources and Emiratisation","url":"https://www.mohre.gov.ae/en/home.aspx","source_type":"government_labour_portal","live_verification":true}`

## inquiry_qualification — Service/Beneficiary

Ask: What domestic, childcare, elderly-care or home-nursing service is required? Arabic: يرجى توضيح service/beneficiary بالنسبة إلى خدمات العمالة المنزلية. Reason: service/beneficiary is required to make Maid services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-domain_1","question_en":"What domestic, childcare, elderly-care or home-nursing service is required?","question_ar":"يرجى توضيح service/beneficiary بالنسبة إلى خدمات العمالة المنزلية.","internal_label_en":"service/beneficiary","internal_label_ar":"متطلب خدمات العمالة المنزلية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Needs/Profile

Ask: Who is the beneficiary/household, and what age, health, mobility, language or cultural needs apply? Arabic: يرجى توضيح needs/profile بالنسبة إلى خدمات العمالة المنزلية. Reason: needs/profile is required to make Maid services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-domain_2","question_en":"Who is the beneficiary/household, and what age, health, mobility, language or cultural needs apply?","question_ar":"يرجى توضيح needs/profile بالنسبة إلى خدمات العمالة المنزلية.","internal_label_en":"needs/profile","internal_label_ar":"متطلب خدمات العمالة المنزلية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Schedule/Model

Ask: Is the service hourly, live-in, shift-based, temporary or long-term? Arabic: يرجى توضيح schedule/model بالنسبة إلى خدمات العمالة المنزلية. Reason: schedule/model is required to make Maid services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-domain_3","question_en":"Is the service hourly, live-in, shift-based, temporary or long-term?","question_ar":"يرجى توضيح schedule/model بالنسبة إلى خدمات العمالة المنزلية.","internal_label_en":"schedule/model","internal_label_ar":"متطلب خدمات العمالة المنزلية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Licensing/Qualification

Ask: Which licensed provider/employment model, worker qualification and verification are required? Arabic: يرجى توضيح licensing/qualification بالنسبة إلى خدمات العمالة المنزلية. Reason: licensing/qualification is required to make Maid services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-domain_4","question_en":"Which licensed provider/employment model, worker qualification and verification are required?","question_ar":"يرجى توضيح licensing/qualification بالنسبة إلى خدمات العمالة المنزلية.","internal_label_en":"licensing/qualification","internal_label_ar":"متطلب خدمات العمالة المنزلية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Scope/Boundaries

Ask: What tasks or care are included, excluded, clinically restricted or subject to a care plan? Arabic: يرجى توضيح scope/boundaries بالنسبة إلى خدمات العمالة المنزلية. Reason: scope/boundaries is required to make Maid services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-domain_5","question_en":"What tasks or care are included, excluded, clinically restricted or subject to a care plan?","question_ar":"يرجى توضيح scope/boundaries بالنسبة إلى خدمات العمالة المنزلية.","internal_label_en":"scope/boundaries","internal_label_ar":"متطلب خدمات العمالة المنزلية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Safeguarding/Clinical

Ask: What safeguarding, consent, privacy, medication, emergency and insurance controls apply? Arabic: يرجى توضيح safeguarding/clinical بالنسبة إلى خدمات العمالة المنزلية. Reason: safeguarding/clinical is required to make Maid services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-domain_6","question_en":"What safeguarding, consent, privacy, medication, emergency and insurance controls apply?","question_ar":"يرجى توضيح safeguarding/clinical بالنسبة إلى خدمات العمالة المنزلية.","internal_label_en":"safeguarding/clinical","internal_label_ar":"متطلب خدمات العمالة المنزلية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Commercial/Continuity

Ask: What pricing, overtime, replacement, continuity, complaint and termination terms apply? Arabic: يرجى توضيح commercial/continuity بالنسبة إلى خدمات العمالة المنزلية. Reason: commercial/continuity is required to make Maid services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-domain_7","question_en":"What pricing, overtime, replacement, continuity, complaint and termination terms apply?","question_ar":"يرجى توضيح commercial/continuity بالنسبة إلى خدمات العمالة المنزلية.","internal_label_en":"commercial/continuity","internal_label_ar":"متطلب خدمات العمالة المنزلية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Maid services quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Maid services quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Maid services quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Maid services quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Maid services quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Maid services quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Maid services quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Maid services quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Maid services quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Maid services quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Maid services quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Maid services quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Maid services quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Maid services quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Maid services quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Maid services quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Maid services quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Maid services quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Maid services quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Maid services quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Maid services quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Maid services quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-maid-services-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Maid services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-maid-services-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-maid-services-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Maid services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-maid-services-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Maid services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-maid-services-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Maid services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-maid-services-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Maid services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-maid-services-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Maid services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-maid-services-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-maid-services-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Maid services: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-maid-services-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-maid-services-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Maid services: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-maid-services-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-maid-services-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Maid services: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-maid-services-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-maid-services-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Maid services: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-maid-services-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-maid-services-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Maid services: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-maid-services-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-maid-services-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Maid services: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-maid-services-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-maid-services-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Maid services: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-maid-services-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-maid-services-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Maid services: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-maid-services-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-maid-services-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Maid services: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-maid-services-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-maid-services-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Maid services: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-maid-services-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-maid-services-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — hours/live-in model

Cost driver: hours/live-in model. This factor can materially change a Maid services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-maid-services-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"hours/live-in model","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — skills and language

Cost driver: skills and language. This factor can materially change a Maid services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-maid-services-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"skills and language","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — clinical level of care

Cost driver: clinical level of care. This factor can materially change a Maid services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-maid-services-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"clinical level of care","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — transport/accommodation

Cost driver: transport/accommodation. This factor can materially change a Maid services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-maid-services-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"transport/accommodation","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — replacement guarantee

Cost driver: replacement guarantee. This factor can materially change a Maid services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-maid-services-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"replacement guarantee","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — insurance and 24/7 support

Cost driver: insurance and 24/7 support. This factor can materially change a Maid services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-maid-services-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"insurance and 24/7 support","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Maid services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-maid-services-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Maid services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-maid-services-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Maid services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-maid-services-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Maid services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-maid-services-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Maid services: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-maid-services-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Maid services: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-maid-services-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Maid services: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-maid-services-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Maid services: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-maid-services-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Maid services: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-maid-services-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Maid services: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-maid-services-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Maid services: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-maid-services-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Maid services: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-maid-services-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Maid services: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-maid-services-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Maid services: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-maid-services-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — unlicensed placement

Risk: unlicensed placement. For Maid services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-maid-services-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"unlicensed placement","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — worker-rights violation

Risk: worker-rights violation. For Maid services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-maid-services-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"worker-rights violation","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — safeguarding failure

Risk: safeguarding failure. For Maid services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-maid-services-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"safeguarding failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — unlicensed clinical activity

Risk: unlicensed clinical activity. For Maid services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-maid-services-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"unlicensed clinical activity","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — medication error

Risk: medication error. For Maid services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-maid-services-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"medication error","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — privacy or continuity failure

Risk: privacy or continuity failure. For Maid services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-maid-services-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"privacy or continuity failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Maid services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-maid-services-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Maid services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-maid-services-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Maid services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-maid-services-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Maid services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-maid-services-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Maid services: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-maid-services-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Maid services: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-maid-services-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Maid services: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-maid-services-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Maid services: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-maid-services-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Maid services: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-maid-services-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Maid services: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-maid-services-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Maid services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-maid-services-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Maid services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-maid-services-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Maid services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-maid-services-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Maid services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-maid-services-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Maid services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-maid-services-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Maid services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-maid-services-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Maid services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-maid-services-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Maid services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-maid-services-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Maid services: vague public request. Input: I need help with Maid services but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-maid-services-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-maid-services-01","input":{"message":"I need help with Maid services but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Maid services: minimum quote-ready request. Input: Customer requests Maid services and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-maid-services-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-maid-services-02","input":{"message":"Customer requests Maid services and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Maid services: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-maid-services-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-maid-services-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Maid services: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-maid-services-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-maid-services-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Maid services: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-maid-services-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-maid-services-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Maid services: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-maid-services-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-maid-services-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Maid services: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-maid-services-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-maid-services-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — domestic worker

English term: domestic worker. Arabic operational label: مصطلح domestic worker ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"domestic worker","term_ar":"مصطلح domestic worker ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — recruitment center

English term: recruitment center. Arabic operational label: مصطلح recruitment center ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"recruitment center","term_ar":"مصطلح recruitment center ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — live-in

English term: live-in. Arabic operational label: مصطلح live-in ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"live-in","term_ar":"مصطلح live-in ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — hourly service

English term: hourly service. Arabic operational label: مصطلح hourly service ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"hourly service","term_ar":"مصطلح hourly service ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — babysitting

English term: babysitting. Arabic operational label: مصطلح babysitting ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"babysitting","term_ar":"مصطلح babysitting ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — safeguarding

English term: safeguarding. Arabic operational label: مصطلح safeguarding ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"safeguarding","term_ar":"مصطلح safeguarding ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — caregiver

English term: caregiver. Arabic operational label: مصطلح caregiver ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"caregiver","term_ar":"مصطلح caregiver ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — home nursing

English term: home nursing. Arabic operational label: مصطلح home nursing ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"home nursing","term_ar":"مصطلح home nursing ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — care plan

English term: care plan. Arabic operational label: مصطلح care plan ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"care plan","term_ar":"مصطلح care plan ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — clinical licence

English term: clinical licence. Arabic operational label: مصطلح clinical licence ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"clinical licence","term_ar":"مصطلح clinical licence ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — consent

English term: consent. Arabic operational label: مصطلح consent ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"consent","term_ar":"مصطلح consent ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — medication order

English term: medication order. Arabic operational label: مصطلح medication order ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"medication order","term_ar":"مصطلح medication order ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — respite care

English term: respite care. Arabic operational label: مصطلح respite care ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"respite care","term_ar":"مصطلح respite care ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — replacement

English term: replacement. Arabic operational label: مصطلح replacement ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"replacement","term_ar":"مصطلح replacement ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — continuity

English term: continuity. Arabic operational label: مصطلح continuity ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"continuity","term_ar":"مصطلح continuity ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — complaint escalation

English term: complaint escalation. Arabic operational label: مصطلح complaint escalation ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"complaint escalation","term_ar":"مصطلح complaint escalation ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن خدمات العمالة المنزلية. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن خدمات العمالة المنزلية","canonical_subcategory":"maid-services","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Maid services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-maid-services-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"maid-services","normalization_only":true}`


# 02. Babysitting / رعاية الأطفال

**Aliases:** Babysitting

## industry — Industry scope — Babysitting

Babysitting sits within Domestic Services and covers domestic-worker, babysitting, elderly-care and home-nursing services where licensed recruitment/employment, worker rights, safeguarding, care scope, clinical boundaries, privacy and continuity are critical. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-domestic-services-babysitting-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Babysitting","aliases_en":["Babysitting"],"aliases_ar":["رعاية الأطفال"],"sequence":1}`

## industry — UAE procurement workflow — Babysitting

A typical UAE procurement path for Babysitting moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-domestic-services-babysitting-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Babysitting","aliases_en":["Babysitting"],"aliases_ar":["رعاية الأطفال"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Babysitting

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include licensed provider, recruitment center, employer/contracting entity, care coordinator, licensed nurse, trained caregiver. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-domestic-services-babysitting-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Babysitting","aliases_en":["Babysitting"],"aliases_ar":["رعاية الأطفال"],"sequence":3}`

## industry — Scope boundaries and escalation — Babysitting

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Babysitting. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Babysitting","aliases_en":["Babysitting"],"aliases_ar":["رعاية الأطفال"],"sequence":4}`

## products_services — maid placement

maid placement is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"maid placement","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — hourly cleaning/domestic help

hourly cleaning/domestic help is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"hourly cleaning/domestic help","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — live-in domestic worker

live-in domestic worker is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"live-in domestic worker","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — babysitting

babysitting is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"babysitting","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — childcare support

childcare support is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"childcare support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — elderly companion care

elderly companion care is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"elderly companion care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — personal care support

personal care support is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"personal care support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — home nursing visit

home nursing visit is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"home nursing visit","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — live-in nurse

live-in nurse is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"live-in nurse","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — post-operative home care

post-operative home care is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"post-operative home care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — medication support

medication support is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"medication support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — mobility assistance

mobility assistance is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"mobility assistance","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — respite care

respite care is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"respite care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — household service plan

household service plan is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"household service plan","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — replacement/continuity service

replacement/continuity service is a product or service family relevant to Babysitting. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-babysitting-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"replacement/continuity service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — service classification

Technical topic: service classification. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"service classification","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — licensed provider

Technical topic: licensed provider. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"licensed provider","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — worker employment status

Technical topic: worker employment status. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"worker employment status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — client/household profile

Technical topic: client/household profile. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"client/household profile","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — beneficiary age and condition

Technical topic: beneficiary age and condition. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"beneficiary age and condition","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — scope and exclusions

Technical topic: scope and exclusions. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"scope and exclusions","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — working hours/rest

Technical topic: working hours/rest. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"working hours/rest","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — accommodation/transport

Technical topic: accommodation/transport. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"accommodation/transport","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — language and competence

Technical topic: language and competence. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"language and competence","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — background/identity verification

Technical topic: background/identity verification. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"background/identity verification","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — safeguarding

Technical topic: safeguarding. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"safeguarding","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — clinical licence and care plan

Technical topic: clinical licence and care plan. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"clinical licence and care plan","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — medication and emergency protocol

Technical topic: medication and emergency protocol. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"medication and emergency protocol","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — privacy/consent

Technical topic: privacy/consent. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"privacy/consent","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — insurance/liability

Technical topic: insurance/liability. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"insurance/liability","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — continuity/replacement

Technical topic: continuity/replacement. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"continuity/replacement","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — complaint and escalation

Technical topic: complaint and escalation. For Babysitting, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-babysitting-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"complaint and escalation","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — licensed domestic-worker center

licensed domestic-worker center is a supplier-market role or example for Babysitting; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-babysitting-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed domestic-worker center","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed domestic-service company

licensed domestic-service company is a supplier-market role or example for Babysitting; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-babysitting-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed domestic-service company","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed childcare provider

licensed childcare provider is a supplier-market role or example for Babysitting; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-babysitting-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed childcare provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed home-healthcare provider

licensed home-healthcare provider is a supplier-market role or example for Babysitting; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-babysitting-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed home-healthcare provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed nursing facility

licensed nursing facility is a supplier-market role or example for Babysitting; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-babysitting-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed nursing facility","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — care-management provider

care-management provider is a supplier-market role or example for Babysitting; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-babysitting-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"care-management provider","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — licensed provider

Supplier type: licensed provider. In Babysitting, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"licensed provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — licensed provider

Eligibility gate 1 for a licensed provider responding to Babysitting: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"licensed provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — recruitment center

Supplier type: recruitment center. In Babysitting, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"recruitment center","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — recruitment center

Eligibility gate 2 for a recruitment center responding to Babysitting: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"recruitment center","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — employer/contracting entity

Supplier type: employer/contracting entity. In Babysitting, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"employer/contracting entity","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — employer/contracting entity

Eligibility gate 3 for a employer/contracting entity responding to Babysitting: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"employer/contracting entity","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — care coordinator

Supplier type: care coordinator. In Babysitting, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"care coordinator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — care coordinator

Eligibility gate 4 for a care coordinator responding to Babysitting: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"care coordinator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — licensed nurse

Supplier type: licensed nurse. In Babysitting, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"licensed nurse","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — licensed nurse

Eligibility gate 5 for a licensed nurse responding to Babysitting: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"licensed nurse","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — trained caregiver

Supplier type: trained caregiver. In Babysitting, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"trained caregiver","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — trained caregiver

Eligibility gate 6 for a trained caregiver responding to Babysitting: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"trained caregiver","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — background-check provider

Supplier type: background-check provider. In Babysitting, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"background-check provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — background-check provider

Eligibility gate 7 for a background-check provider responding to Babysitting: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"background-check provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — emergency support provider

Supplier type: emergency support provider. In Babysitting, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"emergency support provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — emergency support provider

Eligibility gate 8 for a emergency support provider responding to Babysitting: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-babysitting-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"emergency support provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — service and beneficiary

Quotation requirement: service and beneficiary. Every supplier response for Babysitting should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-babysitting-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"service_and_beneficiary","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — hours/live-in arrangement

Quotation requirement: hours/live-in arrangement. Every supplier response for Babysitting should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-babysitting-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"hours_live_in_arrangement","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — licence/employment model

Quotation requirement: licence/employment model. Every supplier response for Babysitting should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-babysitting-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"licence_employment_model","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — skills/language

Quotation requirement: skills/language. Every supplier response for Babysitting should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-babysitting-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"skills_language","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — care or task scope

Quotation requirement: care or task scope. Every supplier response for Babysitting should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-babysitting-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"care_or_task_scope","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — safeguarding/privacy

Quotation requirement: safeguarding/privacy. Every supplier response for Babysitting should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-babysitting-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"safeguarding_privacy","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — pricing and overtime

Quotation requirement: pricing and overtime. Every supplier response for Babysitting should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-babysitting-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"pricing_and_overtime","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — replacement/continuity

Quotation requirement: replacement/continuity. Every supplier response for Babysitting should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-babysitting-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"replacement_continuity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — insurance/liability

Quotation requirement: insurance/liability. Every supplier response for Babysitting should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-babysitting-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"insurance_liability","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — complaints/emergency

Quotation requirement: complaints/emergency. Every supplier response for Babysitting should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-babysitting-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"complaints_emergency","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — service request

Document: service request. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"service_request","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — provider licence

Document: provider licence. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"provider_licence","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — employment/service contract

Document: employment/service contract. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"employment_service_contract","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — worker identity/qualification

Document: worker identity/qualification. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"worker_identity_qualification","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — background/verification evidence

Document: background/verification evidence. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"background_verification_evidence","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — job description

Document: job description. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"job_description","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — care plan

Document: care plan. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"care_plan","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — clinical licence

Document: clinical licence. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"clinical_licence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — medication order

Document: medication order. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"medication_order","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — risk/safeguarding plan

Document: risk/safeguarding plan. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"risk_safeguarding_plan","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — consent/privacy form

Document: consent/privacy form. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"consent_privacy_form","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — schedule/roster

Document: schedule/roster. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"schedule_roster","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — insurance evidence

Document: insurance evidence. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"insurance_evidence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — complaint/emergency procedure

Document: complaint/emergency procedure. For Babysitting, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-babysitting-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"complaint_emergency_procedure","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — Labour and Domestic Worker Services and Regulations

Source activation for Babysitting: Labour and Domestic Worker Services and Regulations (Ministry of Human Resources and Emiratisation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify licensed recruitment, work arrangement, contracts, rights and complaint procedures.

- Record ID: `qd-kb-domestic-services-babysitting-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE
- Structured data: `{"source_id":"UAE-MOHRE","publisher":"Ministry of Human Resources and Emiratisation","url":"https://www.mohre.gov.ae/en/home.aspx","source_type":"government_labour_portal","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 9 of 2022 on Domestic Workers

Source activation for Babysitting: Federal Decree-Law No. 9 of 2022 on Domestic Workers (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use current consolidated law and implementing resolution; legal interpretation requires counsel.

- Record ID: `qd-kb-domestic-services-babysitting-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"source_id":"UAE-DOMESTIC-WORKERS-LAW","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1593/download","source_type":"federal_law","live_verification":true}`

## uae_regulations — Cabinet Resolution No. 106 of 2022 on Domestic Workers

Source activation for Babysitting: Cabinet Resolution No. 106 of 2022 on Domestic Workers (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify amendments and current official implementation.

- Record ID: `qd-kb-domestic-services-babysitting-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DOMESTIC-WORKERS-EXEC
- Structured data: `{"source_id":"UAE-DOMESTIC-WORKERS-EXEC","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1620/download","source_type":"federal_executive_regulation","live_verification":true}`

## uae_regulations — Dubai Health Authority Policies and Regulations

Source activation for Babysitting: Dubai Health Authority Policies and Regulations (Dubai Health Authority). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Clinical and home-healthcare services require licensed providers and current standards.

- Record ID: `qd-kb-domestic-services-babysitting-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DHA-POLICIES
- Structured data: `{"source_id":"UAE-DHA-POLICIES","publisher":"Dubai Health Authority","url":"https://www.dha.gov.ae/en/licensing-regulations-policies","source_type":"government_health_regulator","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Babysitting: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-domestic-services-babysitting-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Babysitting: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-domestic-services-babysitting-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Babysitting: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-domestic-services-babysitting-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — Labour and Domestic Worker Services and Regulations

Source activation for Babysitting: Labour and Domestic Worker Services and Regulations (Ministry of Human Resources and Emiratisation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify licensed recruitment, work arrangement, contracts, rights and complaint procedures.

- Record ID: `qd-kb-domestic-services-babysitting-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE
- Structured data: `{"source_id":"UAE-MOHRE","publisher":"Ministry of Human Resources and Emiratisation","url":"https://www.mohre.gov.ae/en/home.aspx","source_type":"government_labour_portal","live_verification":true}`

## inquiry_qualification — Service/Beneficiary

Ask: What domestic, childcare, elderly-care or home-nursing service is required? Arabic: يرجى توضيح service/beneficiary بالنسبة إلى رعاية الأطفال. Reason: service/beneficiary is required to make Babysitting quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-domain_1","question_en":"What domestic, childcare, elderly-care or home-nursing service is required?","question_ar":"يرجى توضيح service/beneficiary بالنسبة إلى رعاية الأطفال.","internal_label_en":"service/beneficiary","internal_label_ar":"متطلب رعاية الأطفال","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Needs/Profile

Ask: Who is the beneficiary/household, and what age, health, mobility, language or cultural needs apply? Arabic: يرجى توضيح needs/profile بالنسبة إلى رعاية الأطفال. Reason: needs/profile is required to make Babysitting quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-domain_2","question_en":"Who is the beneficiary/household, and what age, health, mobility, language or cultural needs apply?","question_ar":"يرجى توضيح needs/profile بالنسبة إلى رعاية الأطفال.","internal_label_en":"needs/profile","internal_label_ar":"متطلب رعاية الأطفال","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Schedule/Model

Ask: Is the service hourly, live-in, shift-based, temporary or long-term? Arabic: يرجى توضيح schedule/model بالنسبة إلى رعاية الأطفال. Reason: schedule/model is required to make Babysitting quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-domain_3","question_en":"Is the service hourly, live-in, shift-based, temporary or long-term?","question_ar":"يرجى توضيح schedule/model بالنسبة إلى رعاية الأطفال.","internal_label_en":"schedule/model","internal_label_ar":"متطلب رعاية الأطفال","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Licensing/Qualification

Ask: Which licensed provider/employment model, worker qualification and verification are required? Arabic: يرجى توضيح licensing/qualification بالنسبة إلى رعاية الأطفال. Reason: licensing/qualification is required to make Babysitting quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-domain_4","question_en":"Which licensed provider/employment model, worker qualification and verification are required?","question_ar":"يرجى توضيح licensing/qualification بالنسبة إلى رعاية الأطفال.","internal_label_en":"licensing/qualification","internal_label_ar":"متطلب رعاية الأطفال","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Scope/Boundaries

Ask: What tasks or care are included, excluded, clinically restricted or subject to a care plan? Arabic: يرجى توضيح scope/boundaries بالنسبة إلى رعاية الأطفال. Reason: scope/boundaries is required to make Babysitting quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-domain_5","question_en":"What tasks or care are included, excluded, clinically restricted or subject to a care plan?","question_ar":"يرجى توضيح scope/boundaries بالنسبة إلى رعاية الأطفال.","internal_label_en":"scope/boundaries","internal_label_ar":"متطلب رعاية الأطفال","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Safeguarding/Clinical

Ask: What safeguarding, consent, privacy, medication, emergency and insurance controls apply? Arabic: يرجى توضيح safeguarding/clinical بالنسبة إلى رعاية الأطفال. Reason: safeguarding/clinical is required to make Babysitting quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-domain_6","question_en":"What safeguarding, consent, privacy, medication, emergency and insurance controls apply?","question_ar":"يرجى توضيح safeguarding/clinical بالنسبة إلى رعاية الأطفال.","internal_label_en":"safeguarding/clinical","internal_label_ar":"متطلب رعاية الأطفال","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Commercial/Continuity

Ask: What pricing, overtime, replacement, continuity, complaint and termination terms apply? Arabic: يرجى توضيح commercial/continuity بالنسبة إلى رعاية الأطفال. Reason: commercial/continuity is required to make Babysitting quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-domain_7","question_en":"What pricing, overtime, replacement, continuity, complaint and termination terms apply?","question_ar":"يرجى توضيح commercial/continuity بالنسبة إلى رعاية الأطفال.","internal_label_en":"commercial/continuity","internal_label_ar":"متطلب رعاية الأطفال","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Babysitting quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Babysitting quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Babysitting quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Babysitting quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Babysitting quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Babysitting quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Babysitting quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Babysitting quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Babysitting quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Babysitting quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Babysitting quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Babysitting quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Babysitting quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Babysitting quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Babysitting quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Babysitting quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Babysitting quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Babysitting quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Babysitting quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Babysitting quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Babysitting quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Babysitting quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-babysitting-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Babysitting, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-babysitting-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-babysitting-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Babysitting; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-babysitting-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Babysitting; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-babysitting-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Babysitting; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-babysitting-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Babysitting; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-babysitting-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Babysitting; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-babysitting-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-babysitting-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Babysitting: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-babysitting-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-babysitting-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Babysitting: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-babysitting-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-babysitting-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Babysitting: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-babysitting-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-babysitting-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Babysitting: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-babysitting-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-babysitting-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Babysitting: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-babysitting-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-babysitting-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Babysitting: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-babysitting-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-babysitting-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Babysitting: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-babysitting-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-babysitting-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Babysitting: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-babysitting-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-babysitting-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Babysitting: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-babysitting-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-babysitting-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Babysitting: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-babysitting-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-babysitting-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — hours/live-in model

Cost driver: hours/live-in model. This factor can materially change a Babysitting quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-babysitting-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"hours/live-in model","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — skills and language

Cost driver: skills and language. This factor can materially change a Babysitting quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-babysitting-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"skills and language","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — clinical level of care

Cost driver: clinical level of care. This factor can materially change a Babysitting quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-babysitting-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"clinical level of care","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — transport/accommodation

Cost driver: transport/accommodation. This factor can materially change a Babysitting quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-babysitting-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"transport/accommodation","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — replacement guarantee

Cost driver: replacement guarantee. This factor can materially change a Babysitting quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-babysitting-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"replacement guarantee","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — insurance and 24/7 support

Cost driver: insurance and 24/7 support. This factor can materially change a Babysitting quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-babysitting-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"insurance and 24/7 support","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Babysitting quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-babysitting-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Babysitting quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-babysitting-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Babysitting quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-babysitting-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Babysitting quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-babysitting-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Babysitting: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-babysitting-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Babysitting: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-babysitting-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Babysitting: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-babysitting-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Babysitting: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-babysitting-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Babysitting: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-babysitting-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Babysitting: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-babysitting-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Babysitting: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-babysitting-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Babysitting: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-babysitting-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Babysitting: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-babysitting-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Babysitting: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-babysitting-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — unlicensed placement

Risk: unlicensed placement. For Babysitting, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-babysitting-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"unlicensed placement","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — worker-rights violation

Risk: worker-rights violation. For Babysitting, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-babysitting-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"worker-rights violation","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — safeguarding failure

Risk: safeguarding failure. For Babysitting, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-babysitting-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"safeguarding failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — unlicensed clinical activity

Risk: unlicensed clinical activity. For Babysitting, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-babysitting-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"unlicensed clinical activity","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — medication error

Risk: medication error. For Babysitting, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-babysitting-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"medication error","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — privacy or continuity failure

Risk: privacy or continuity failure. For Babysitting, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-babysitting-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"privacy or continuity failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Babysitting, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-babysitting-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Babysitting, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-babysitting-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Babysitting, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-babysitting-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Babysitting, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-babysitting-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Babysitting: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-babysitting-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Babysitting: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-babysitting-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Babysitting: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-babysitting-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Babysitting: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-babysitting-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Babysitting: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-babysitting-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Babysitting: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-babysitting-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Babysitting, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-babysitting-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Babysitting, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-babysitting-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Babysitting, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-babysitting-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Babysitting, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-babysitting-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Babysitting, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-babysitting-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Babysitting, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-babysitting-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Babysitting, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-babysitting-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Babysitting, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-babysitting-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Babysitting: vague public request. Input: I need help with Babysitting but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-babysitting-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-babysitting-01","input":{"message":"I need help with Babysitting but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Babysitting: minimum quote-ready request. Input: Customer requests Babysitting and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-babysitting-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-babysitting-02","input":{"message":"Customer requests Babysitting and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Babysitting: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-babysitting-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-babysitting-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Babysitting: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-babysitting-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-babysitting-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Babysitting: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-babysitting-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-babysitting-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Babysitting: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-babysitting-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-babysitting-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Babysitting: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-babysitting-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-babysitting-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — domestic worker

English term: domestic worker. Arabic operational label: مصطلح domestic worker ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"domestic worker","term_ar":"مصطلح domestic worker ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — recruitment center

English term: recruitment center. Arabic operational label: مصطلح recruitment center ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"recruitment center","term_ar":"مصطلح recruitment center ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — live-in

English term: live-in. Arabic operational label: مصطلح live-in ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"live-in","term_ar":"مصطلح live-in ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — hourly service

English term: hourly service. Arabic operational label: مصطلح hourly service ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"hourly service","term_ar":"مصطلح hourly service ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — babysitting

English term: babysitting. Arabic operational label: مصطلح babysitting ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"babysitting","term_ar":"مصطلح babysitting ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — safeguarding

English term: safeguarding. Arabic operational label: مصطلح safeguarding ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"safeguarding","term_ar":"مصطلح safeguarding ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — caregiver

English term: caregiver. Arabic operational label: مصطلح caregiver ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"caregiver","term_ar":"مصطلح caregiver ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — home nursing

English term: home nursing. Arabic operational label: مصطلح home nursing ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"home nursing","term_ar":"مصطلح home nursing ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — care plan

English term: care plan. Arabic operational label: مصطلح care plan ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"care plan","term_ar":"مصطلح care plan ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — clinical licence

English term: clinical licence. Arabic operational label: مصطلح clinical licence ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"clinical licence","term_ar":"مصطلح clinical licence ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — consent

English term: consent. Arabic operational label: مصطلح consent ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"consent","term_ar":"مصطلح consent ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — medication order

English term: medication order. Arabic operational label: مصطلح medication order ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"medication order","term_ar":"مصطلح medication order ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — respite care

English term: respite care. Arabic operational label: مصطلح respite care ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"respite care","term_ar":"مصطلح respite care ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — replacement

English term: replacement. Arabic operational label: مصطلح replacement ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"replacement","term_ar":"مصطلح replacement ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — continuity

English term: continuity. Arabic operational label: مصطلح continuity ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"continuity","term_ar":"مصطلح continuity ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — complaint escalation

English term: complaint escalation. Arabic operational label: مصطلح complaint escalation ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"complaint escalation","term_ar":"مصطلح complaint escalation ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن رعاية الأطفال. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن رعاية الأطفال","canonical_subcategory":"babysitting","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Babysitting. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-babysitting-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"babysitting","normalization_only":true}`


# 03. Elderly care / رعاية كبار السن

**Aliases:** Elderly care

## industry — Industry scope — Elderly care

Elderly care sits within Domestic Services and covers domestic-worker, babysitting, elderly-care and home-nursing services where licensed recruitment/employment, worker rights, safeguarding, care scope, clinical boundaries, privacy and continuity are critical. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-domestic-services-elderly-care-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Elderly care","aliases_en":["Elderly care"],"aliases_ar":["رعاية كبار السن"],"sequence":1}`

## industry — UAE procurement workflow — Elderly care

A typical UAE procurement path for Elderly care moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-domestic-services-elderly-care-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Elderly care","aliases_en":["Elderly care"],"aliases_ar":["رعاية كبار السن"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Elderly care

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include licensed provider, recruitment center, employer/contracting entity, care coordinator, licensed nurse, trained caregiver. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-domestic-services-elderly-care-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Elderly care","aliases_en":["Elderly care"],"aliases_ar":["رعاية كبار السن"],"sequence":3}`

## industry — Scope boundaries and escalation — Elderly care

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Elderly care. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Elderly care","aliases_en":["Elderly care"],"aliases_ar":["رعاية كبار السن"],"sequence":4}`

## products_services — maid placement

maid placement is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"maid placement","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — hourly cleaning/domestic help

hourly cleaning/domestic help is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"hourly cleaning/domestic help","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — live-in domestic worker

live-in domestic worker is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"live-in domestic worker","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — babysitting

babysitting is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"babysitting","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — childcare support

childcare support is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"childcare support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — elderly companion care

elderly companion care is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"elderly companion care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — personal care support

personal care support is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"personal care support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — home nursing visit

home nursing visit is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"home nursing visit","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — live-in nurse

live-in nurse is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"live-in nurse","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — post-operative home care

post-operative home care is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"post-operative home care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — medication support

medication support is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"medication support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — mobility assistance

mobility assistance is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"mobility assistance","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — respite care

respite care is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"respite care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — household service plan

household service plan is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"household service plan","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — replacement/continuity service

replacement/continuity service is a product or service family relevant to Elderly care. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-elderly-care-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"replacement/continuity service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — service classification

Technical topic: service classification. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"service classification","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — licensed provider

Technical topic: licensed provider. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"licensed provider","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — worker employment status

Technical topic: worker employment status. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"worker employment status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — client/household profile

Technical topic: client/household profile. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"client/household profile","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — beneficiary age and condition

Technical topic: beneficiary age and condition. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"beneficiary age and condition","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — scope and exclusions

Technical topic: scope and exclusions. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"scope and exclusions","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — working hours/rest

Technical topic: working hours/rest. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"working hours/rest","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — accommodation/transport

Technical topic: accommodation/transport. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"accommodation/transport","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — language and competence

Technical topic: language and competence. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"language and competence","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — background/identity verification

Technical topic: background/identity verification. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"background/identity verification","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — safeguarding

Technical topic: safeguarding. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"safeguarding","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — clinical licence and care plan

Technical topic: clinical licence and care plan. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"clinical licence and care plan","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — medication and emergency protocol

Technical topic: medication and emergency protocol. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"medication and emergency protocol","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — privacy/consent

Technical topic: privacy/consent. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"privacy/consent","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — insurance/liability

Technical topic: insurance/liability. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"insurance/liability","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — continuity/replacement

Technical topic: continuity/replacement. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"continuity/replacement","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — complaint and escalation

Technical topic: complaint and escalation. For Elderly care, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-elderly-care-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"complaint and escalation","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — licensed domestic-worker center

licensed domestic-worker center is a supplier-market role or example for Elderly care; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-elderly-care-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed domestic-worker center","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed domestic-service company

licensed domestic-service company is a supplier-market role or example for Elderly care; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-elderly-care-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed domestic-service company","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed childcare provider

licensed childcare provider is a supplier-market role or example for Elderly care; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-elderly-care-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed childcare provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed home-healthcare provider

licensed home-healthcare provider is a supplier-market role or example for Elderly care; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-elderly-care-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed home-healthcare provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed nursing facility

licensed nursing facility is a supplier-market role or example for Elderly care; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-elderly-care-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed nursing facility","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — care-management provider

care-management provider is a supplier-market role or example for Elderly care; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-elderly-care-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"care-management provider","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — licensed provider

Supplier type: licensed provider. In Elderly care, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"licensed provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — licensed provider

Eligibility gate 1 for a licensed provider responding to Elderly care: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"licensed provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — recruitment center

Supplier type: recruitment center. In Elderly care, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"recruitment center","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — recruitment center

Eligibility gate 2 for a recruitment center responding to Elderly care: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"recruitment center","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — employer/contracting entity

Supplier type: employer/contracting entity. In Elderly care, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"employer/contracting entity","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — employer/contracting entity

Eligibility gate 3 for a employer/contracting entity responding to Elderly care: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"employer/contracting entity","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — care coordinator

Supplier type: care coordinator. In Elderly care, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"care coordinator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — care coordinator

Eligibility gate 4 for a care coordinator responding to Elderly care: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"care coordinator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — licensed nurse

Supplier type: licensed nurse. In Elderly care, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"licensed nurse","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — licensed nurse

Eligibility gate 5 for a licensed nurse responding to Elderly care: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"licensed nurse","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — trained caregiver

Supplier type: trained caregiver. In Elderly care, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"trained caregiver","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — trained caregiver

Eligibility gate 6 for a trained caregiver responding to Elderly care: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"trained caregiver","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — background-check provider

Supplier type: background-check provider. In Elderly care, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"background-check provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — background-check provider

Eligibility gate 7 for a background-check provider responding to Elderly care: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"background-check provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — emergency support provider

Supplier type: emergency support provider. In Elderly care, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"emergency support provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — emergency support provider

Eligibility gate 8 for a emergency support provider responding to Elderly care: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"emergency support provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — service and beneficiary

Quotation requirement: service and beneficiary. Every supplier response for Elderly care should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-elderly-care-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"service_and_beneficiary","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — hours/live-in arrangement

Quotation requirement: hours/live-in arrangement. Every supplier response for Elderly care should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-elderly-care-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"hours_live_in_arrangement","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — licence/employment model

Quotation requirement: licence/employment model. Every supplier response for Elderly care should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-elderly-care-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"licence_employment_model","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — skills/language

Quotation requirement: skills/language. Every supplier response for Elderly care should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-elderly-care-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"skills_language","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — care or task scope

Quotation requirement: care or task scope. Every supplier response for Elderly care should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-elderly-care-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"care_or_task_scope","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — safeguarding/privacy

Quotation requirement: safeguarding/privacy. Every supplier response for Elderly care should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-elderly-care-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"safeguarding_privacy","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — pricing and overtime

Quotation requirement: pricing and overtime. Every supplier response for Elderly care should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-elderly-care-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"pricing_and_overtime","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — replacement/continuity

Quotation requirement: replacement/continuity. Every supplier response for Elderly care should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-elderly-care-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"replacement_continuity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — insurance/liability

Quotation requirement: insurance/liability. Every supplier response for Elderly care should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-elderly-care-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"insurance_liability","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — complaints/emergency

Quotation requirement: complaints/emergency. Every supplier response for Elderly care should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-elderly-care-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"complaints_emergency","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — service request

Document: service request. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"service_request","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — provider licence

Document: provider licence. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"provider_licence","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — employment/service contract

Document: employment/service contract. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"employment_service_contract","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — worker identity/qualification

Document: worker identity/qualification. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"worker_identity_qualification","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — background/verification evidence

Document: background/verification evidence. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"background_verification_evidence","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — job description

Document: job description. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"job_description","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — care plan

Document: care plan. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"care_plan","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — clinical licence

Document: clinical licence. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"clinical_licence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — medication order

Document: medication order. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"medication_order","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — risk/safeguarding plan

Document: risk/safeguarding plan. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"risk_safeguarding_plan","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — consent/privacy form

Document: consent/privacy form. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"consent_privacy_form","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — schedule/roster

Document: schedule/roster. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"schedule_roster","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — insurance evidence

Document: insurance evidence. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"insurance_evidence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — complaint/emergency procedure

Document: complaint/emergency procedure. For Elderly care, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-elderly-care-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"complaint_emergency_procedure","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — Labour and Domestic Worker Services and Regulations

Source activation for Elderly care: Labour and Domestic Worker Services and Regulations (Ministry of Human Resources and Emiratisation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify licensed recruitment, work arrangement, contracts, rights and complaint procedures.

- Record ID: `qd-kb-domestic-services-elderly-care-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE
- Structured data: `{"source_id":"UAE-MOHRE","publisher":"Ministry of Human Resources and Emiratisation","url":"https://www.mohre.gov.ae/en/home.aspx","source_type":"government_labour_portal","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 9 of 2022 on Domestic Workers

Source activation for Elderly care: Federal Decree-Law No. 9 of 2022 on Domestic Workers (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use current consolidated law and implementing resolution; legal interpretation requires counsel.

- Record ID: `qd-kb-domestic-services-elderly-care-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"source_id":"UAE-DOMESTIC-WORKERS-LAW","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1593/download","source_type":"federal_law","live_verification":true}`

## uae_regulations — Cabinet Resolution No. 106 of 2022 on Domestic Workers

Source activation for Elderly care: Cabinet Resolution No. 106 of 2022 on Domestic Workers (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify amendments and current official implementation.

- Record ID: `qd-kb-domestic-services-elderly-care-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DOMESTIC-WORKERS-EXEC
- Structured data: `{"source_id":"UAE-DOMESTIC-WORKERS-EXEC","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1620/download","source_type":"federal_executive_regulation","live_verification":true}`

## uae_regulations — Dubai Health Authority Policies and Regulations

Source activation for Elderly care: Dubai Health Authority Policies and Regulations (Dubai Health Authority). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Clinical and home-healthcare services require licensed providers and current standards.

- Record ID: `qd-kb-domestic-services-elderly-care-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DHA-POLICIES
- Structured data: `{"source_id":"UAE-DHA-POLICIES","publisher":"Dubai Health Authority","url":"https://www.dha.gov.ae/en/licensing-regulations-policies","source_type":"government_health_regulator","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Elderly care: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-domestic-services-elderly-care-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Elderly care: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-domestic-services-elderly-care-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Elderly care: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-domestic-services-elderly-care-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — Labour and Domestic Worker Services and Regulations

Source activation for Elderly care: Labour and Domestic Worker Services and Regulations (Ministry of Human Resources and Emiratisation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify licensed recruitment, work arrangement, contracts, rights and complaint procedures.

- Record ID: `qd-kb-domestic-services-elderly-care-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE
- Structured data: `{"source_id":"UAE-MOHRE","publisher":"Ministry of Human Resources and Emiratisation","url":"https://www.mohre.gov.ae/en/home.aspx","source_type":"government_labour_portal","live_verification":true}`

## inquiry_qualification — Service/Beneficiary

Ask: What domestic, childcare, elderly-care or home-nursing service is required? Arabic: يرجى توضيح service/beneficiary بالنسبة إلى رعاية كبار السن. Reason: service/beneficiary is required to make Elderly care quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-domain_1","question_en":"What domestic, childcare, elderly-care or home-nursing service is required?","question_ar":"يرجى توضيح service/beneficiary بالنسبة إلى رعاية كبار السن.","internal_label_en":"service/beneficiary","internal_label_ar":"متطلب رعاية كبار السن","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Needs/Profile

Ask: Who is the beneficiary/household, and what age, health, mobility, language or cultural needs apply? Arabic: يرجى توضيح needs/profile بالنسبة إلى رعاية كبار السن. Reason: needs/profile is required to make Elderly care quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-domain_2","question_en":"Who is the beneficiary/household, and what age, health, mobility, language or cultural needs apply?","question_ar":"يرجى توضيح needs/profile بالنسبة إلى رعاية كبار السن.","internal_label_en":"needs/profile","internal_label_ar":"متطلب رعاية كبار السن","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Schedule/Model

Ask: Is the service hourly, live-in, shift-based, temporary or long-term? Arabic: يرجى توضيح schedule/model بالنسبة إلى رعاية كبار السن. Reason: schedule/model is required to make Elderly care quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-domain_3","question_en":"Is the service hourly, live-in, shift-based, temporary or long-term?","question_ar":"يرجى توضيح schedule/model بالنسبة إلى رعاية كبار السن.","internal_label_en":"schedule/model","internal_label_ar":"متطلب رعاية كبار السن","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Licensing/Qualification

Ask: Which licensed provider/employment model, worker qualification and verification are required? Arabic: يرجى توضيح licensing/qualification بالنسبة إلى رعاية كبار السن. Reason: licensing/qualification is required to make Elderly care quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-domain_4","question_en":"Which licensed provider/employment model, worker qualification and verification are required?","question_ar":"يرجى توضيح licensing/qualification بالنسبة إلى رعاية كبار السن.","internal_label_en":"licensing/qualification","internal_label_ar":"متطلب رعاية كبار السن","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Scope/Boundaries

Ask: What tasks or care are included, excluded, clinically restricted or subject to a care plan? Arabic: يرجى توضيح scope/boundaries بالنسبة إلى رعاية كبار السن. Reason: scope/boundaries is required to make Elderly care quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-domain_5","question_en":"What tasks or care are included, excluded, clinically restricted or subject to a care plan?","question_ar":"يرجى توضيح scope/boundaries بالنسبة إلى رعاية كبار السن.","internal_label_en":"scope/boundaries","internal_label_ar":"متطلب رعاية كبار السن","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Safeguarding/Clinical

Ask: What safeguarding, consent, privacy, medication, emergency and insurance controls apply? Arabic: يرجى توضيح safeguarding/clinical بالنسبة إلى رعاية كبار السن. Reason: safeguarding/clinical is required to make Elderly care quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-domain_6","question_en":"What safeguarding, consent, privacy, medication, emergency and insurance controls apply?","question_ar":"يرجى توضيح safeguarding/clinical بالنسبة إلى رعاية كبار السن.","internal_label_en":"safeguarding/clinical","internal_label_ar":"متطلب رعاية كبار السن","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Commercial/Continuity

Ask: What pricing, overtime, replacement, continuity, complaint and termination terms apply? Arabic: يرجى توضيح commercial/continuity بالنسبة إلى رعاية كبار السن. Reason: commercial/continuity is required to make Elderly care quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-domain_7","question_en":"What pricing, overtime, replacement, continuity, complaint and termination terms apply?","question_ar":"يرجى توضيح commercial/continuity بالنسبة إلى رعاية كبار السن.","internal_label_en":"commercial/continuity","internal_label_ar":"متطلب رعاية كبار السن","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Elderly care quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Elderly care quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Elderly care quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Elderly care quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Elderly care quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Elderly care quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Elderly care quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Elderly care quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Elderly care quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Elderly care quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Elderly care quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Elderly care quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Elderly care quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Elderly care quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Elderly care quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Elderly care quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Elderly care quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Elderly care quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Elderly care quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Elderly care quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Elderly care quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Elderly care quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-elderly-care-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Elderly care, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-elderly-care-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-elderly-care-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Elderly care; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-elderly-care-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Elderly care; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-elderly-care-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Elderly care; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-elderly-care-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Elderly care; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-elderly-care-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Elderly care; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-elderly-care-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-elderly-care-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Elderly care: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-elderly-care-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-elderly-care-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Elderly care: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-elderly-care-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-elderly-care-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Elderly care: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-elderly-care-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-elderly-care-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Elderly care: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-elderly-care-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-elderly-care-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Elderly care: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-elderly-care-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-elderly-care-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Elderly care: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-elderly-care-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-elderly-care-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Elderly care: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-elderly-care-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-elderly-care-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Elderly care: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-elderly-care-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-elderly-care-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Elderly care: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-elderly-care-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-elderly-care-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Elderly care: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-elderly-care-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-elderly-care-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — hours/live-in model

Cost driver: hours/live-in model. This factor can materially change a Elderly care quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-elderly-care-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"hours/live-in model","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — skills and language

Cost driver: skills and language. This factor can materially change a Elderly care quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-elderly-care-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"skills and language","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — clinical level of care

Cost driver: clinical level of care. This factor can materially change a Elderly care quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-elderly-care-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"clinical level of care","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — transport/accommodation

Cost driver: transport/accommodation. This factor can materially change a Elderly care quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-elderly-care-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"transport/accommodation","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — replacement guarantee

Cost driver: replacement guarantee. This factor can materially change a Elderly care quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-elderly-care-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"replacement guarantee","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — insurance and 24/7 support

Cost driver: insurance and 24/7 support. This factor can materially change a Elderly care quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-elderly-care-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"insurance and 24/7 support","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Elderly care quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-elderly-care-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Elderly care quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-elderly-care-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Elderly care quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-elderly-care-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Elderly care quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-elderly-care-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Elderly care: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-elderly-care-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Elderly care: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-elderly-care-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Elderly care: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-elderly-care-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Elderly care: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-elderly-care-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Elderly care: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-elderly-care-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Elderly care: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-elderly-care-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Elderly care: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-elderly-care-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Elderly care: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-elderly-care-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Elderly care: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-elderly-care-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Elderly care: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-elderly-care-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — unlicensed placement

Risk: unlicensed placement. For Elderly care, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-elderly-care-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"unlicensed placement","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — worker-rights violation

Risk: worker-rights violation. For Elderly care, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-elderly-care-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"worker-rights violation","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — safeguarding failure

Risk: safeguarding failure. For Elderly care, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-elderly-care-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"safeguarding failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — unlicensed clinical activity

Risk: unlicensed clinical activity. For Elderly care, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-elderly-care-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"unlicensed clinical activity","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — medication error

Risk: medication error. For Elderly care, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-elderly-care-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"medication error","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — privacy or continuity failure

Risk: privacy or continuity failure. For Elderly care, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-elderly-care-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"privacy or continuity failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Elderly care, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-elderly-care-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Elderly care, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-elderly-care-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Elderly care, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-elderly-care-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Elderly care, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-elderly-care-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Elderly care: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-elderly-care-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Elderly care: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-elderly-care-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Elderly care: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-elderly-care-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Elderly care: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-elderly-care-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Elderly care: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-elderly-care-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Elderly care: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-elderly-care-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Elderly care, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-elderly-care-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Elderly care, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-elderly-care-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Elderly care, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-elderly-care-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Elderly care, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-elderly-care-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Elderly care, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-elderly-care-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Elderly care, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-elderly-care-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Elderly care, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-elderly-care-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Elderly care, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-elderly-care-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Elderly care: vague public request. Input: I need help with Elderly care but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-elderly-care-01","input":{"message":"I need help with Elderly care but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Elderly care: minimum quote-ready request. Input: Customer requests Elderly care and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-elderly-care-02","input":{"message":"Customer requests Elderly care and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Elderly care: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-elderly-care-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Elderly care: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-elderly-care-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Elderly care: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-elderly-care-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Elderly care: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-elderly-care-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Elderly care: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-elderly-care-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-elderly-care-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — domestic worker

English term: domestic worker. Arabic operational label: مصطلح domestic worker ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"domestic worker","term_ar":"مصطلح domestic worker ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — recruitment center

English term: recruitment center. Arabic operational label: مصطلح recruitment center ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"recruitment center","term_ar":"مصطلح recruitment center ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — live-in

English term: live-in. Arabic operational label: مصطلح live-in ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"live-in","term_ar":"مصطلح live-in ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — hourly service

English term: hourly service. Arabic operational label: مصطلح hourly service ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"hourly service","term_ar":"مصطلح hourly service ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — babysitting

English term: babysitting. Arabic operational label: مصطلح babysitting ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"babysitting","term_ar":"مصطلح babysitting ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — safeguarding

English term: safeguarding. Arabic operational label: مصطلح safeguarding ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"safeguarding","term_ar":"مصطلح safeguarding ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — caregiver

English term: caregiver. Arabic operational label: مصطلح caregiver ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"caregiver","term_ar":"مصطلح caregiver ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — home nursing

English term: home nursing. Arabic operational label: مصطلح home nursing ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"home nursing","term_ar":"مصطلح home nursing ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — care plan

English term: care plan. Arabic operational label: مصطلح care plan ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"care plan","term_ar":"مصطلح care plan ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — clinical licence

English term: clinical licence. Arabic operational label: مصطلح clinical licence ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"clinical licence","term_ar":"مصطلح clinical licence ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — consent

English term: consent. Arabic operational label: مصطلح consent ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"consent","term_ar":"مصطلح consent ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — medication order

English term: medication order. Arabic operational label: مصطلح medication order ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"medication order","term_ar":"مصطلح medication order ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — respite care

English term: respite care. Arabic operational label: مصطلح respite care ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"respite care","term_ar":"مصطلح respite care ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — replacement

English term: replacement. Arabic operational label: مصطلح replacement ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"replacement","term_ar":"مصطلح replacement ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — continuity

English term: continuity. Arabic operational label: مصطلح continuity ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"continuity","term_ar":"مصطلح continuity ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — complaint escalation

English term: complaint escalation. Arabic operational label: مصطلح complaint escalation ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"complaint escalation","term_ar":"مصطلح complaint escalation ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن رعاية كبار السن. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن رعاية كبار السن","canonical_subcategory":"elderly-care","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Elderly care. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-elderly-care-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"elderly-care","normalization_only":true}`


# 04. Home nursing / التمريض المنزلي

**Aliases:** Home nursing, home healthcare, private nursing, domiciliary nursing

## industry — Industry scope — Home nursing

Home nursing sits within Domestic Services and covers domestic-worker, babysitting, elderly-care and home-nursing services where licensed recruitment/employment, worker rights, safeguarding, care scope, clinical boundaries, privacy and continuity are critical. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-domestic-services-home-nursing-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Home nursing","aliases_en":["Home nursing","home healthcare","private nursing","domiciliary nursing"],"aliases_ar":["التمريض المنزلي"],"sequence":1}`

## industry — UAE procurement workflow — Home nursing

A typical UAE procurement path for Home nursing moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-domestic-services-home-nursing-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Home nursing","aliases_en":["Home nursing","home healthcare","private nursing","domiciliary nursing"],"aliases_ar":["التمريض المنزلي"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Home nursing

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include licensed provider, recruitment center, employer/contracting entity, care coordinator, licensed nurse, trained caregiver. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-domestic-services-home-nursing-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Home nursing","aliases_en":["Home nursing","home healthcare","private nursing","domiciliary nursing"],"aliases_ar":["التمريض المنزلي"],"sequence":3}`

## industry — Scope boundaries and escalation — Home nursing

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Home nursing. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"subcategory":"Home nursing","aliases_en":["Home nursing","home healthcare","private nursing","domiciliary nursing"],"aliases_ar":["التمريض المنزلي"],"sequence":4}`

## products_services — maid placement

maid placement is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"maid placement","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — hourly cleaning/domestic help

hourly cleaning/domestic help is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"hourly cleaning/domestic help","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — live-in domestic worker

live-in domestic worker is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"live-in domestic worker","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — babysitting

babysitting is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"babysitting","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — childcare support

childcare support is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"childcare support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — elderly companion care

elderly companion care is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"elderly companion care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — personal care support

personal care support is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"personal care support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — home nursing visit

home nursing visit is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"home nursing visit","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — live-in nurse

live-in nurse is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"live-in nurse","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — post-operative home care

post-operative home care is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"post-operative home care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — medication support

medication support is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"medication support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — mobility assistance

mobility assistance is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"mobility assistance","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — respite care

respite care is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"respite care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — household service plan

household service plan is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"household service plan","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — replacement/continuity service

replacement/continuity service is a product or service family relevant to Home nursing. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-domestic-services-home-nursing-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"family":"replacement/continuity service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — service classification

Technical topic: service classification. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"service classification","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — licensed provider

Technical topic: licensed provider. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"licensed provider","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — worker employment status

Technical topic: worker employment status. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"worker employment status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — client/household profile

Technical topic: client/household profile. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"client/household profile","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — beneficiary age and condition

Technical topic: beneficiary age and condition. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"beneficiary age and condition","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — scope and exclusions

Technical topic: scope and exclusions. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"scope and exclusions","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — working hours/rest

Technical topic: working hours/rest. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"working hours/rest","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — accommodation/transport

Technical topic: accommodation/transport. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"accommodation/transport","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — language and competence

Technical topic: language and competence. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"language and competence","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — background/identity verification

Technical topic: background/identity verification. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"background/identity verification","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — safeguarding

Technical topic: safeguarding. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"safeguarding","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — clinical licence and care plan

Technical topic: clinical licence and care plan. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"clinical licence and care plan","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — medication and emergency protocol

Technical topic: medication and emergency protocol. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"medication and emergency protocol","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — privacy/consent

Technical topic: privacy/consent. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"privacy/consent","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — insurance/liability

Technical topic: insurance/liability. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"insurance/liability","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — continuity/replacement

Technical topic: continuity/replacement. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"continuity/replacement","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — complaint and escalation

Technical topic: complaint and escalation. For Home nursing, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-domestic-services-home-nursing-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"topic":"complaint and escalation","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — licensed domestic-worker center

licensed domestic-worker center is a supplier-market role or example for Home nursing; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-home-nursing-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed domestic-worker center","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed domestic-service company

licensed domestic-service company is a supplier-market role or example for Home nursing; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-home-nursing-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed domestic-service company","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed childcare provider

licensed childcare provider is a supplier-market role or example for Home nursing; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-home-nursing-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed childcare provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed home-healthcare provider

licensed home-healthcare provider is a supplier-market role or example for Home nursing; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-home-nursing-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed home-healthcare provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed nursing facility

licensed nursing facility is a supplier-market role or example for Home nursing; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-home-nursing-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed nursing facility","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — care-management provider

care-management provider is a supplier-market role or example for Home nursing; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-domestic-services-home-nursing-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"care-management provider","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — licensed provider

Supplier type: licensed provider. In Home nursing, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"licensed provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — licensed provider

Eligibility gate 1 for a licensed provider responding to Home nursing: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"licensed provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — recruitment center

Supplier type: recruitment center. In Home nursing, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"recruitment center","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — recruitment center

Eligibility gate 2 for a recruitment center responding to Home nursing: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"recruitment center","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — employer/contracting entity

Supplier type: employer/contracting entity. In Home nursing, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"employer/contracting entity","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — employer/contracting entity

Eligibility gate 3 for a employer/contracting entity responding to Home nursing: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"employer/contracting entity","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — care coordinator

Supplier type: care coordinator. In Home nursing, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"care coordinator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — care coordinator

Eligibility gate 4 for a care coordinator responding to Home nursing: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"care coordinator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — licensed nurse

Supplier type: licensed nurse. In Home nursing, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"licensed nurse","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — licensed nurse

Eligibility gate 5 for a licensed nurse responding to Home nursing: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"licensed nurse","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — trained caregiver

Supplier type: trained caregiver. In Home nursing, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"trained caregiver","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — trained caregiver

Eligibility gate 6 for a trained caregiver responding to Home nursing: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"trained caregiver","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — background-check provider

Supplier type: background-check provider. In Home nursing, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"background-check provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — background-check provider

Eligibility gate 7 for a background-check provider responding to Home nursing: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"background-check provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — emergency support provider

Supplier type: emergency support provider. In Home nursing, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"supplier_type":"emergency support provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — emergency support provider

Eligibility gate 8 for a emergency support provider responding to Home nursing: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"supplier_type":"emergency support provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — service and beneficiary

Quotation requirement: service and beneficiary. Every supplier response for Home nursing should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-home-nursing-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"service_and_beneficiary","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — hours/live-in arrangement

Quotation requirement: hours/live-in arrangement. Every supplier response for Home nursing should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-home-nursing-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"hours_live_in_arrangement","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — licence/employment model

Quotation requirement: licence/employment model. Every supplier response for Home nursing should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-home-nursing-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"licence_employment_model","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — skills/language

Quotation requirement: skills/language. Every supplier response for Home nursing should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-home-nursing-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"skills_language","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — care or task scope

Quotation requirement: care or task scope. Every supplier response for Home nursing should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-home-nursing-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"care_or_task_scope","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — safeguarding/privacy

Quotation requirement: safeguarding/privacy. Every supplier response for Home nursing should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-home-nursing-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"safeguarding_privacy","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — pricing and overtime

Quotation requirement: pricing and overtime. Every supplier response for Home nursing should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-home-nursing-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"pricing_and_overtime","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — replacement/continuity

Quotation requirement: replacement/continuity. Every supplier response for Home nursing should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-home-nursing-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"replacement_continuity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — insurance/liability

Quotation requirement: insurance/liability. Every supplier response for Home nursing should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-home-nursing-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"insurance_liability","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — complaints/emergency

Quotation requirement: complaints/emergency. Every supplier response for Home nursing should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-domestic-services-home-nursing-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"quotation_field":"complaints_emergency","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — service request

Document: service request. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"service_request","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — provider licence

Document: provider licence. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"provider_licence","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — employment/service contract

Document: employment/service contract. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"employment_service_contract","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — worker identity/qualification

Document: worker identity/qualification. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"worker_identity_qualification","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — background/verification evidence

Document: background/verification evidence. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"background_verification_evidence","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — job description

Document: job description. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"job_description","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — care plan

Document: care plan. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"care_plan","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — clinical licence

Document: clinical licence. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"clinical_licence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — medication order

Document: medication order. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"medication_order","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — risk/safeguarding plan

Document: risk/safeguarding plan. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"risk_safeguarding_plan","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — consent/privacy form

Document: consent/privacy form. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"consent_privacy_form","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — schedule/roster

Document: schedule/roster. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"schedule_roster","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — insurance evidence

Document: insurance evidence. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"insurance_evidence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — complaint/emergency procedure

Document: complaint/emergency procedure. For Home nursing, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-domestic-services-home-nursing-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"document_type":"complaint_emergency_procedure","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — Labour and Domestic Worker Services and Regulations

Source activation for Home nursing: Labour and Domestic Worker Services and Regulations (Ministry of Human Resources and Emiratisation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify licensed recruitment, work arrangement, contracts, rights and complaint procedures.

- Record ID: `qd-kb-domestic-services-home-nursing-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE
- Structured data: `{"source_id":"UAE-MOHRE","publisher":"Ministry of Human Resources and Emiratisation","url":"https://www.mohre.gov.ae/en/home.aspx","source_type":"government_labour_portal","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 9 of 2022 on Domestic Workers

Source activation for Home nursing: Federal Decree-Law No. 9 of 2022 on Domestic Workers (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use current consolidated law and implementing resolution; legal interpretation requires counsel.

- Record ID: `qd-kb-domestic-services-home-nursing-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"source_id":"UAE-DOMESTIC-WORKERS-LAW","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1593/download","source_type":"federal_law","live_verification":true}`

## uae_regulations — Cabinet Resolution No. 106 of 2022 on Domestic Workers

Source activation for Home nursing: Cabinet Resolution No. 106 of 2022 on Domestic Workers (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify amendments and current official implementation.

- Record ID: `qd-kb-domestic-services-home-nursing-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DOMESTIC-WORKERS-EXEC
- Structured data: `{"source_id":"UAE-DOMESTIC-WORKERS-EXEC","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1620/download","source_type":"federal_executive_regulation","live_verification":true}`

## uae_regulations — Dubai Health Authority Policies and Regulations

Source activation for Home nursing: Dubai Health Authority Policies and Regulations (Dubai Health Authority). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Clinical and home-healthcare services require licensed providers and current standards.

- Record ID: `qd-kb-domestic-services-home-nursing-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DHA-POLICIES
- Structured data: `{"source_id":"UAE-DHA-POLICIES","publisher":"Dubai Health Authority","url":"https://www.dha.gov.ae/en/licensing-regulations-policies","source_type":"government_health_regulator","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Home nursing: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-domestic-services-home-nursing-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Home nursing: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-domestic-services-home-nursing-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Home nursing: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-domestic-services-home-nursing-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — Labour and Domestic Worker Services and Regulations

Source activation for Home nursing: Labour and Domestic Worker Services and Regulations (Ministry of Human Resources and Emiratisation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify licensed recruitment, work arrangement, contracts, rights and complaint procedures.

- Record ID: `qd-kb-domestic-services-home-nursing-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE
- Structured data: `{"source_id":"UAE-MOHRE","publisher":"Ministry of Human Resources and Emiratisation","url":"https://www.mohre.gov.ae/en/home.aspx","source_type":"government_labour_portal","live_verification":true}`

## inquiry_qualification — Service/Beneficiary

Ask: What domestic, childcare, elderly-care or home-nursing service is required? Arabic: يرجى توضيح service/beneficiary بالنسبة إلى التمريض المنزلي. Reason: service/beneficiary is required to make Home nursing quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-domain_1","question_en":"What domestic, childcare, elderly-care or home-nursing service is required?","question_ar":"يرجى توضيح service/beneficiary بالنسبة إلى التمريض المنزلي.","internal_label_en":"service/beneficiary","internal_label_ar":"متطلب التمريض المنزلي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Needs/Profile

Ask: Who is the beneficiary/household, and what age, health, mobility, language or cultural needs apply? Arabic: يرجى توضيح needs/profile بالنسبة إلى التمريض المنزلي. Reason: needs/profile is required to make Home nursing quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-domain_2","question_en":"Who is the beneficiary/household, and what age, health, mobility, language or cultural needs apply?","question_ar":"يرجى توضيح needs/profile بالنسبة إلى التمريض المنزلي.","internal_label_en":"needs/profile","internal_label_ar":"متطلب التمريض المنزلي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Schedule/Model

Ask: Is the service hourly, live-in, shift-based, temporary or long-term? Arabic: يرجى توضيح schedule/model بالنسبة إلى التمريض المنزلي. Reason: schedule/model is required to make Home nursing quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-domain_3","question_en":"Is the service hourly, live-in, shift-based, temporary or long-term?","question_ar":"يرجى توضيح schedule/model بالنسبة إلى التمريض المنزلي.","internal_label_en":"schedule/model","internal_label_ar":"متطلب التمريض المنزلي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Licensing/Qualification

Ask: Which licensed provider/employment model, worker qualification and verification are required? Arabic: يرجى توضيح licensing/qualification بالنسبة إلى التمريض المنزلي. Reason: licensing/qualification is required to make Home nursing quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-domain_4","question_en":"Which licensed provider/employment model, worker qualification and verification are required?","question_ar":"يرجى توضيح licensing/qualification بالنسبة إلى التمريض المنزلي.","internal_label_en":"licensing/qualification","internal_label_ar":"متطلب التمريض المنزلي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Scope/Boundaries

Ask: What tasks or care are included, excluded, clinically restricted or subject to a care plan? Arabic: يرجى توضيح scope/boundaries بالنسبة إلى التمريض المنزلي. Reason: scope/boundaries is required to make Home nursing quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-domain_5","question_en":"What tasks or care are included, excluded, clinically restricted or subject to a care plan?","question_ar":"يرجى توضيح scope/boundaries بالنسبة إلى التمريض المنزلي.","internal_label_en":"scope/boundaries","internal_label_ar":"متطلب التمريض المنزلي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Safeguarding/Clinical

Ask: What safeguarding, consent, privacy, medication, emergency and insurance controls apply? Arabic: يرجى توضيح safeguarding/clinical بالنسبة إلى التمريض المنزلي. Reason: safeguarding/clinical is required to make Home nursing quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-domain_6","question_en":"What safeguarding, consent, privacy, medication, emergency and insurance controls apply?","question_ar":"يرجى توضيح safeguarding/clinical بالنسبة إلى التمريض المنزلي.","internal_label_en":"safeguarding/clinical","internal_label_ar":"متطلب التمريض المنزلي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Commercial/Continuity

Ask: What pricing, overtime, replacement, continuity, complaint and termination terms apply? Arabic: يرجى توضيح commercial/continuity بالنسبة إلى التمريض المنزلي. Reason: commercial/continuity is required to make Home nursing quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-domain_7","question_en":"What pricing, overtime, replacement, continuity, complaint and termination terms apply?","question_ar":"يرجى توضيح commercial/continuity بالنسبة إلى التمريض المنزلي.","internal_label_en":"commercial/continuity","internal_label_ar":"متطلب التمريض المنزلي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Home nursing quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Home nursing quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Home nursing quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Home nursing quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Home nursing quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Home nursing quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Home nursing quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Home nursing quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Home nursing quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Home nursing quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Home nursing quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Home nursing quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Home nursing quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Home nursing quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Home nursing quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Home nursing quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Home nursing quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Home nursing quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Home nursing quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Home nursing quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Home nursing quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Home nursing quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"question_id":"q-home-nursing-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["service request","provider licence","employment/service contract"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Home nursing, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"rule_id":"rule-home-nursing-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-home-nursing-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Home nursing; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-home-nursing-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Home nursing; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-home-nursing-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Home nursing; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-home-nursing-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Home nursing; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-home-nursing-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Home nursing; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-domestic-services-home-nursing-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"rule_id":"rule-home-nursing-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Home nursing: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-home-nursing-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-home-nursing-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Home nursing: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-home-nursing-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-home-nursing-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Home nursing: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-home-nursing-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-home-nursing-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Home nursing: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-home-nursing-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-home-nursing-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Home nursing: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-home-nursing-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-home-nursing-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Home nursing: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-home-nursing-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-home-nursing-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Home nursing: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-home-nursing-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-home-nursing-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Home nursing: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-home-nursing-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-home-nursing-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Home nursing: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-home-nursing-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-home-nursing-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Home nursing: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-domestic-services-home-nursing-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"validation_id":"validation-home-nursing-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — hours/live-in model

Cost driver: hours/live-in model. This factor can materially change a Home nursing quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-home-nursing-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"hours/live-in model","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — skills and language

Cost driver: skills and language. This factor can materially change a Home nursing quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-home-nursing-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"skills and language","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — clinical level of care

Cost driver: clinical level of care. This factor can materially change a Home nursing quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-home-nursing-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"clinical level of care","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — transport/accommodation

Cost driver: transport/accommodation. This factor can materially change a Home nursing quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-home-nursing-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"transport/accommodation","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — replacement guarantee

Cost driver: replacement guarantee. This factor can materially change a Home nursing quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-home-nursing-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"replacement guarantee","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — insurance and 24/7 support

Cost driver: insurance and 24/7 support. This factor can materially change a Home nursing quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-home-nursing-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"insurance and 24/7 support","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Home nursing quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-home-nursing-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Home nursing quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-home-nursing-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Home nursing quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-home-nursing-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Home nursing quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-domestic-services-home-nursing-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Home nursing: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-home-nursing-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Home nursing: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-home-nursing-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Home nursing: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-home-nursing-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Home nursing: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-home-nursing-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Home nursing: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-home-nursing-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Home nursing: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-home-nursing-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Home nursing: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-home-nursing-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Home nursing: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-home-nursing-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Home nursing: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-home-nursing-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Home nursing: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-domestic-services-home-nursing-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — unlicensed placement

Risk: unlicensed placement. For Home nursing, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-home-nursing-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"unlicensed placement","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — worker-rights violation

Risk: worker-rights violation. For Home nursing, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-home-nursing-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"worker-rights violation","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — safeguarding failure

Risk: safeguarding failure. For Home nursing, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-home-nursing-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"safeguarding failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — unlicensed clinical activity

Risk: unlicensed clinical activity. For Home nursing, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-home-nursing-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"unlicensed clinical activity","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — medication error

Risk: medication error. For Home nursing, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-home-nursing-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"medication error","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — privacy or continuity failure

Risk: privacy or continuity failure. For Home nursing, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-home-nursing-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"privacy or continuity failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Home nursing, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-home-nursing-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Home nursing, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-home-nursing-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Home nursing, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-home-nursing-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Home nursing, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-domestic-services-home-nursing-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Home nursing: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-home-nursing-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Home nursing: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-home-nursing-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Home nursing: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-home-nursing-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Home nursing: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-home-nursing-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Home nursing: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-home-nursing-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Home nursing: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-domestic-services-home-nursing-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Home nursing, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-home-nursing-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Home nursing, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-home-nursing-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Home nursing, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-home-nursing-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Home nursing, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-home-nursing-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Home nursing, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-home-nursing-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Home nursing, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-home-nursing-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Home nursing, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-home-nursing-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Home nursing, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-domestic-services-home-nursing-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Home nursing: vague public request. Input: I need help with Home nursing but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-home-nursing-01","input":{"message":"I need help with Home nursing but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Home nursing: minimum quote-ready request. Input: Customer requests Home nursing and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-home-nursing-02","input":{"message":"Customer requests Home nursing and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Home nursing: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-home-nursing-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Home nursing: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-home-nursing-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Home nursing: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-home-nursing-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Home nursing: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-home-nursing-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Home nursing: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-domestic-services-home-nursing-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOHRE, UAE-DOMESTIC-WORKERS-LAW, UAE-DOMESTIC-WORKERS-EXEC, UAE-DHA-POLICIES
- Structured data: `{"scenario_id":"scenario-home-nursing-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — domestic worker

English term: domestic worker. Arabic operational label: مصطلح domestic worker ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"domestic worker","term_ar":"مصطلح domestic worker ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — recruitment center

English term: recruitment center. Arabic operational label: مصطلح recruitment center ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"recruitment center","term_ar":"مصطلح recruitment center ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — live-in

English term: live-in. Arabic operational label: مصطلح live-in ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"live-in","term_ar":"مصطلح live-in ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — hourly service

English term: hourly service. Arabic operational label: مصطلح hourly service ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"hourly service","term_ar":"مصطلح hourly service ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — babysitting

English term: babysitting. Arabic operational label: مصطلح babysitting ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"babysitting","term_ar":"مصطلح babysitting ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — safeguarding

English term: safeguarding. Arabic operational label: مصطلح safeguarding ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"safeguarding","term_ar":"مصطلح safeguarding ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — caregiver

English term: caregiver. Arabic operational label: مصطلح caregiver ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"caregiver","term_ar":"مصطلح caregiver ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — home nursing

English term: home nursing. Arabic operational label: مصطلح home nursing ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"home nursing","term_ar":"مصطلح home nursing ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — care plan

English term: care plan. Arabic operational label: مصطلح care plan ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"care plan","term_ar":"مصطلح care plan ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — clinical licence

English term: clinical licence. Arabic operational label: مصطلح clinical licence ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"clinical licence","term_ar":"مصطلح clinical licence ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — consent

English term: consent. Arabic operational label: مصطلح consent ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"consent","term_ar":"مصطلح consent ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — medication order

English term: medication order. Arabic operational label: مصطلح medication order ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"medication order","term_ar":"مصطلح medication order ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — respite care

English term: respite care. Arabic operational label: مصطلح respite care ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"respite care","term_ar":"مصطلح respite care ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — replacement

English term: replacement. Arabic operational label: مصطلح replacement ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"replacement","term_ar":"مصطلح replacement ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — continuity

English term: continuity. Arabic operational label: مصطلح continuity ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"continuity","term_ar":"مصطلح continuity ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — complaint escalation

English term: complaint escalation. Arabic operational label: مصطلح complaint escalation ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"complaint escalation","term_ar":"مصطلح complaint escalation ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن التمريض المنزلي. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن التمريض المنزلي","canonical_subcategory":"home-nursing","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Home nursing. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-domestic-services-home-nursing-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"home-nursing","normalization_only":true}`

