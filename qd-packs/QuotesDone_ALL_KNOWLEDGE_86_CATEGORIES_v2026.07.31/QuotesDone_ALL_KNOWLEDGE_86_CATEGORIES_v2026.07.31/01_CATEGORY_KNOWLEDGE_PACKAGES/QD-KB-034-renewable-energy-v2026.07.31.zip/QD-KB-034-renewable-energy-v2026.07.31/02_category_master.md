# QuotesDone Knowledge Corpus — Category 34

## Renewable Energy

**Arabic working title:** الطاقة المتجددة
**Version:** 2026.07.31
**Status:** research-complete production draft; not SME approved
**Subcategories:** 4

## Runtime purpose

This corpus supports customer-language routing, adaptive qualification, supplier eligibility, document extraction, UAE source retrieval, comparable RFQ generation, risk control and escalation for Renewable Energy. The large master file is for human audit. Runtime systems should use the atomic JSONL records, deterministic questions/rules and internal retrieval rather than placing this entire file in a model prompt.


# 1. Solar EPC

**Arabic draft:** متطلبات Solar EPC
**Slug:** `solar-epc`
**Aliases:** Solar EPC

## Industry

### Industry scope — Solar EPC

Solar EPC is treated as a distinct procurement route within Renewable Energy. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers industrial products, machinery, process systems, fabrication, logistics, maintenance and safety. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-034-solar-epc-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD

```json
{
  "category": "Renewable Energy",
  "subcategory": "Solar EPC",
  "profile": "industrial",
  "aliases": [
    "Solar EPC"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Solar EPC

A normal UAE sourcing workflow for Solar EPC moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-034-solar-epc-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Solar EPC

Customers may describe Solar EPC through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-034-solar-epc-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Solar EPC

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-034-solar-epc-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Solar EPC product or service

The primary deliverable requested within Solar EPC; exact type, quantity, performance, scope and acceptance must be normalized. For Solar EPC, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-solar-epc-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Solar EPC",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Solar EPC

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Solar EPC, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-solar-epc-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Solar EPC",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Solar EPC

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Solar EPC, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-solar-epc-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Solar EPC",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Solar EPC

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Solar EPC, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-solar-epc-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Solar EPC",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Solar EPC

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Solar EPC, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-solar-epc-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Solar EPC",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Solar EPC

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Solar EPC, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-solar-epc-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Solar EPC",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Solar EPC

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Solar EPC, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-solar-epc-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Solar EPC",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Solar EPC

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Solar EPC, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-solar-epc-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Solar EPC",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Site And Energy Load scope component

Site And Energy Load is a recurring scope component for Solar EPC. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-solar-epc-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "site and energy load",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Technology/Capacity scope component

Technology/Capacity is a recurring scope component for Solar EPC. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-solar-epc-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "technology/capacity",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Grid/Connection scope component

Grid/Connection is a recurring scope component for Solar EPC. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-solar-epc-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "grid/connection",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Storage/Charging Profile scope component

Storage/Charging Profile is a recurring scope component for Solar EPC. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-solar-epc-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "storage/charging profile",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Yield/Performance scope component

Yield/Performance is a recurring scope component for Solar EPC. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-solar-epc-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "yield/performance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Permits scope component

Permits is a recurring scope component for Solar EPC. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-solar-epc-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "permits",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### O&M scope component

O&M is a recurring scope component for Solar EPC. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-solar-epc-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "O&M",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: process or duty

For Solar EPC, process or duty must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "process or duty",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: capacity and operating envelope

For Solar EPC, capacity and operating envelope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "capacity and operating envelope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: materials and compatibility

For Solar EPC, materials and compatibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "materials and compatibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environment and hazardous classification

For Solar EPC, environment and hazardous classification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environment and hazardous classification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/utilities

For Solar EPC, power/utilities must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/utilities",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces and controls

For Solar EPC, interfaces and controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces and controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: quality and certification

For Solar EPC, quality and certification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "quality and certification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation and commissioning

For Solar EPC, installation and commissioning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation and commissioning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: spares and maintenance

For Solar EPC, spares and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "spares and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: logistics and lifecycle

For Solar EPC, logistics and lifecycle must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "logistics and lifecycle",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: site and energy load

For Solar EPC, site and energy load must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "site and energy load",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: technology/capacity

For Solar EPC, technology/capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "technology/capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: grid/connection

For Solar EPC, grid/connection must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "grid/connection",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: storage/charging profile

For Solar EPC, storage/charging profile must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "storage/charging profile",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: yield/performance

For Solar EPC, yield/performance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "yield/performance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: permits

For Solar EPC, permits must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "permits",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: O&M

For Solar EPC, O&M must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-solar-epc-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "O&M",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer/OEM

A manufacturer/OEM may be relevant to Solar EPC depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-solar-epc-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer/OEM",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Solar EPC depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-solar-epc-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: industrial system integrator

A industrial system integrator may be relevant to Solar EPC depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-solar-epc-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "industrial system integrator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator/machine shop

A fabricator/machine shop may be relevant to Solar EPC depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-solar-epc-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator/machine shop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: EPC or specialist contractor

A EPC or specialist contractor may be relevant to Solar EPC depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-solar-epc-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "EPC or specialist contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: inspection/testing body

A inspection/testing body may be relevant to Solar EPC depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-solar-epc-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "inspection/testing body",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer/OEM

This supplier type can participate in Solar EPC only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-solar-epc-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer/OEM",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Solar EPC only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-solar-epc-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — industrial system integrator

This supplier type can participate in Solar EPC only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-solar-epc-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "industrial system integrator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator/machine shop

This supplier type can participate in Solar EPC only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-solar-epc-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator/machine shop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — EPC or specialist contractor

This supplier type can participate in Solar EPC only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-solar-epc-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "EPC or specialist contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — inspection/testing body

This supplier type can participate in Solar EPC only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-solar-epc-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "inspection/testing body",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — rental/service provider

This supplier type can participate in Solar EPC only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-solar-epc-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "rental/service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance and spare-parts provider

This supplier type can participate in Solar EPC only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-solar-epc-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer/OEM

Before routing a Solar EPC inquiry to a manufacturer/OEM, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-solar-epc-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "manufacturer/OEM",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Solar EPC inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-solar-epc-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — industrial system integrator

Before routing a Solar EPC inquiry to a industrial system integrator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-solar-epc-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "industrial system integrator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator/machine shop

Before routing a Solar EPC inquiry to a fabricator/machine shop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-solar-epc-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "fabricator/machine shop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — EPC or specialist contractor

Before routing a Solar EPC inquiry to a EPC or specialist contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-solar-epc-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "EPC or specialist contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — inspection/testing body

Before routing a Solar EPC inquiry to a inspection/testing body, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-solar-epc-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "inspection/testing body",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — rental/service provider

Before routing a Solar EPC inquiry to a rental/service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-solar-epc-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "rental/service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance and spare-parts provider

Before routing a Solar EPC inquiry to a maintenance and spare-parts provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-solar-epc-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Solar EPC should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-solar-epc-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Solar EPC should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-solar-epc-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Solar EPC should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-solar-epc-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Solar EPC should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-solar-epc-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Solar EPC should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-solar-epc-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Solar EPC should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-solar-epc-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Solar EPC should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-solar-epc-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Solar EPC should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-solar-epc-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Solar EPC should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-solar-epc-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Solar EPC should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-solar-epc-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Process/Duty Data Sheet

Process/Duty Data Sheet may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "process-duty-data-sheet",
  "document_name": "process/duty data sheet",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### P&Id Or Schematic

P&Id Or Schematic may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "p-and-id-or-schematic",
  "document_name": "P&ID or schematic",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Layout/General Arrangement

Layout/General Arrangement may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "layout-general-arrangement",
  "document_name": "layout/general arrangement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Hazardous Area Classification

Hazardous Area Classification may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "hazardous-area-classification",
  "document_name": "hazardous area classification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Single-Line/Control Diagram

Single-Line/Control Diagram may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "single-line-control-diagram",
  "document_name": "single-line/control diagram",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Interface List

Interface List may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "interface-list",
  "document_name": "interface list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quality Plan/Itp

Quality Plan/Itp may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quality-plan-itp",
  "document_name": "quality plan/ITP",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Certificates

Material Certificates may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-certificates",
  "document_name": "material certificates",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Reports

Inspection/Test Reports may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-reports",
  "document_name": "inspection/test reports",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement/Lifting Plan

Method Statement/Lifting Plan may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement-lifting-plan",
  "document_name": "method statement/lifting plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Commissioning Plan

Commissioning Plan may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "commissioning-plan",
  "document_name": "commissioning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Spares List

Spares List may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "spares-list",
  "document_name": "spares list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for Solar EPC. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-solar-epc-documents-document_requirement-0083`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Industrial, Standards, Conformity and Quality Services

For Solar EPC, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-solar-epc-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment, Climate and Agriculture Regulation

For Solar EPC, consult Environment, Climate and Agriculture Regulation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-solar-epc-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOCCAE

```json
{
  "source_id": "UAE-MOCCAE",
  "publisher": "Ministry of Climate Change and Environment",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment Agency Abu Dhabi Policies and Permits

For Solar EPC, consult Environment Agency Abu Dhabi Policies and Permits when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-solar-epc-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-EAD

```json
{
  "source_id": "UAE-EAD",
  "publisher": "Environment Agency Abu Dhabi",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ADNOC Supplier and In-Country Value Requirements

For Solar EPC, consult ADNOC Supplier and In-Country Value Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-solar-epc-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADNOC-SUPPLIER

```json
{
  "source_id": "UAE-ADNOC-SUPPLIER",
  "publisher": "ADNOC",
  "source_type": "state_enterprise_supplier_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Customs and Import/Export Guidance

For Solar EPC, consult UAE Customs and Import/Export Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-solar-epc-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CUSTOMS

```json
{
  "source_id": "UAE-CUSTOMS",
  "publisher": "Federal Authority for Identity, Citizenship, Customs and Port Security",
  "source_type": "government_customs_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Solar EPC, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-solar-epc-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### IEC Standards Catalogue

For Solar EPC, consult IEC Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-solar-epc-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: IEC-STANDARDS

```json
{
  "source_id": "IEC-STANDARDS",
  "publisher": "International Electrotechnical Commission",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For Solar EPC, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-solar-epc-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Shams Dubai Solar Connection Requirements

For Solar EPC, consult Shams Dubai Solar Connection Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-solar-epc-uae_regulations-source_activation-0092`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DEWA-SOLAR

```json
{
  "source_id": "UAE-DEWA-SOLAR",
  "publisher": "Dubai Electricity and Water Authority",
  "source_type": "utility_program",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### EV Green Charger and Charging Infrastructure Guidance

For Solar EPC, consult EV Green Charger and Charging Infrastructure Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-solar-epc-uae_regulations-source_activation-0093`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DEWA-EV

```json
{
  "source_id": "UAE-DEWA-EV",
  "publisher": "Dubai Electricity and Water Authority",
  "source_type": "utility_program",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Energy Strategy and Energy Infrastructure Guidance

For Solar EPC, consult UAE Energy Strategy and Energy Infrastructure Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-solar-epc-uae_regulations-source_activation-0094`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOEI-ENERGY

```json
{
  "source_id": "UAE-MOEI-ENERGY",
  "publisher": "Ministry of Energy and Infrastructure",
  "source_type": "government_energy_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Solar EPC. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-solar-epc-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Solar EPC. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-solar-epc-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Solar EPC. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-solar-epc-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Solar EPC. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-solar-epc-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Solar EPC. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-solar-epc-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Solar EPC. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-solar-epc-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Solar EPC. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-solar-epc-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Solar EPC. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-solar-epc-commercial_pricing-cost_driver-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Solar EPC. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-solar-epc-commercial_pricing-cost_driver-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Solar EPC. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-solar-epc-commercial_pricing-cost_driver-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-solar-epc-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-solar-epc-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-solar-epc-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-solar-epc-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-solar-epc-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-solar-epc-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-solar-epc-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-solar-epc-customer_tradeoffs-tradeoff-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-solar-epc-customer_tradeoffs-tradeoff-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-solar-epc-customer_tradeoffs-tradeoff-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Solar EPC, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-solar-epc-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Solar EPC, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-solar-epc-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Solar EPC, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-solar-epc-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Solar EPC, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-solar-epc-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Solar EPC, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-solar-epc-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Solar EPC, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-solar-epc-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Solar EPC, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-solar-epc-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Solar EPC, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-solar-epc-risk-risk_control-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Solar EPC, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-solar-epc-risk-risk_control-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Solar EPC, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-solar-epc-risk-risk_control-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Solar EPC, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-solar-epc-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Solar EPC, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-solar-epc-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Solar EPC, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-solar-epc-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Solar EPC, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-solar-epc-best_practices-qualification_best_practice-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Solar EPC, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-solar-epc-best_practices-qualification_best_practice-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Solar EPC, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-solar-epc-best_practices-qualification_best_practice-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Solar EPC; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-solar-epc-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Solar EPC; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-solar-epc-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Solar EPC; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-solar-epc-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Solar EPC; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-solar-epc-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Solar EPC; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-solar-epc-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Solar EPC; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-solar-epc-troubleshooting-recovery_guidance-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Solar EPC; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-solar-epc-troubleshooting-recovery_guidance-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Solar EPC; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-solar-epc-troubleshooting-recovery_guidance-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What process, duty, product, load, medium or operating objective applies?

Ask in plain language: What process, duty, product, load, medium or operating objective applies? Arabic draft: ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-process-duty",
  "question_en": "What process, duty, product, load, medium or operating objective applies?",
  "question_ar": "ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "process-duty",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What process, duty, product, load, medium or operating objective applies? is missing

When the normalized field process-duty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-process-duty",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "process-duty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-process-duty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What capacity, pressure, temperature, speed, load, accuracy or operating range is required?

Ask in plain language: What capacity, pressure, temperature, speed, load, accuracy or operating range is required? Arabic draft: ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-capacity-conditions",
  "question_en": "What capacity, pressure, temperature, speed, load, accuracy or operating range is required?",
  "question_ar": "ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟",
  "expected_answer_type": "structured_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-conditions",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What capacity, pressure, temperature, speed, load, accuracy or operating range is required? is missing

When the normalized field capacity-conditions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-capacity-conditions",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-conditions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-capacity-conditions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?

Ask in plain language: What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? Arabic draft: ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-materials-compatibility",
  "question_en": "What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?",
  "question_ar": "ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "materials-compatibility",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? is missing

When the normalized field materials-compatibility is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-materials-compatibility",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "materials-compatibility",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-materials-compatibility"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?

Ask in plain language: What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies? Arabic draft: ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-environment-hazard",
  "question_en": "What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?",
  "question_ar": "ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "environment-hazard",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?

Ask in plain language: What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? Arabic draft: ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-utilities-controls",
  "question_en": "What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?",
  "question_ar": "ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-controls",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? is missing

When the normalized field utilities-controls is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-utilities-controls",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-controls",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-utilities-controls"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What code, material certificate, test, inspection, traceability or third-party approval is required?

Ask in plain language: What code, material certificate, test, inspection, traceability or third-party approval is required? Arabic draft: ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-standards-certification",
  "question_en": "What code, material certificate, test, inspection, traceability or third-party approval is required?",
  "question_ar": "ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "standards-certification",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?

Ask in plain language: What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? Arabic draft: ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-installation-commissioning",
  "question_en": "What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?",
  "question_ar": "ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-commissioning",
  "order": 190,
  "confidence_contribution": 0.03
}
```

### Ask when What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? is missing

When the normalized field installation-commissioning is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-installation-commissioning",
  "priority": 981,
  "when": {
    "all": [
      {
        "field": "installation-commissioning",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-installation-commissioning"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What consumables, critical spares, maintenance interval, response time and lifecycle support are required?

Ask in plain language: What consumables, critical spares, maintenance interval, response time and lifecycle support are required? Arabic draft: ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-spares-service",
  "question_en": "What consumables, critical spares, maintenance interval, response time and lifecycle support are required?",
  "question_ar": "ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "spares-service",
  "order": 200,
  "confidence_contribution": 0.012
}
```

### Please clarify the site and energy load requirements for Solar EPC.

Ask in plain language: Please clarify the site and energy load requirements for Solar EPC. Arabic draft: يرجى توضيح متطلبات site and energy load الخاصة بـ Solar EPC. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-facet-01",
  "question_en": "Please clarify the site and energy load requirements for Solar EPC.",
  "question_ar": "يرجى توضيح متطلبات site and energy load الخاصة بـ Solar EPC.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the site and energy load requirements for Solar EPC. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the technology/capacity requirements for Solar EPC.

Ask in plain language: Please clarify the technology/capacity requirements for Solar EPC. Arabic draft: يرجى توضيح متطلبات technology/capacity الخاصة بـ Solar EPC. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-facet-02",
  "question_en": "Please clarify the technology/capacity requirements for Solar EPC.",
  "question_ar": "يرجى توضيح متطلبات technology/capacity الخاصة بـ Solar EPC.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the technology/capacity requirements for Solar EPC. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the grid/connection requirements for Solar EPC.

Ask in plain language: Please clarify the grid/connection requirements for Solar EPC. Arabic draft: يرجى توضيح متطلبات grid/connection الخاصة بـ Solar EPC. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-facet-03",
  "question_en": "Please clarify the grid/connection requirements for Solar EPC.",
  "question_ar": "يرجى توضيح متطلبات grid/connection الخاصة بـ Solar EPC.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the grid/connection requirements for Solar EPC. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the storage/charging profile requirements for Solar EPC.

Ask in plain language: Please clarify the storage/charging profile requirements for Solar EPC. Arabic draft: يرجى توضيح متطلبات storage/charging profile الخاصة بـ Solar EPC. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-facet-04",
  "question_en": "Please clarify the storage/charging profile requirements for Solar EPC.",
  "question_ar": "يرجى توضيح متطلبات storage/charging profile الخاصة بـ Solar EPC.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the yield/performance requirements for Solar EPC.

Ask in plain language: Please clarify the yield/performance requirements for Solar EPC. Arabic draft: يرجى توضيح متطلبات yield/performance الخاصة بـ Solar EPC. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-facet-05",
  "question_en": "Please clarify the yield/performance requirements for Solar EPC.",
  "question_ar": "يرجى توضيح متطلبات yield/performance الخاصة بـ Solar EPC.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the permits requirements for Solar EPC.

Ask in plain language: Please clarify the permits requirements for Solar EPC. Arabic draft: يرجى توضيح متطلبات permits الخاصة بـ Solar EPC. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-facet-06",
  "question_en": "Please clarify the permits requirements for Solar EPC.",
  "question_ar": "يرجى توضيح متطلبات permits الخاصة بـ Solar EPC.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the O&M requirements for Solar EPC.

Ask in plain language: Please clarify the O&M requirements for Solar EPC. Arabic draft: يرجى توضيح متطلبات O&M الخاصة بـ Solar EPC. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-facet-07",
  "question_en": "Please clarify the O&M requirements for Solar EPC.",
  "question_ar": "يرجى توضيح متطلبات O&M الخاصة بـ Solar EPC.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact Solar EPC product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Solar EPC product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Solar EPC التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-exact-subtype",
  "question_en": "Which exact Solar EPC product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Solar EPC التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Solar EPC product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-solar-epc-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Solar EPC are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Solar EPC are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Solar EPC التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-unknowns",
  "question_en": "Which details about Solar EPC are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Solar EPC التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Solar EPC?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Solar EPC? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Solar EPC؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-qualification_question-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-solar-epc-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Solar EPC?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Solar EPC؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Solar EPC, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Solar EPC, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Solar EPC, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Solar EPC, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0189`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER, UAE-CUSTOMS, ISO-STANDARDS, IEC-STANDARDS, ASTM-STANDARDS, UAE-DEWA-SOLAR, UAE-DEWA-EV, UAE-MOEI-ENERGY

```json
{
  "rule_id": "R-034-solar-epc-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-MOIAT",
        "UAE-MOCCAE",
        "UAE-EAD",
        "UAE-ADNOC-SUPPLIER",
        "UAE-CUSTOMS",
        "ISO-STANDARDS",
        "IEC-STANDARDS",
        "ASTM-STANDARDS",
        "UAE-DEWA-SOLAR",
        "UAE-DEWA-EV",
        "UAE-MOEI-ENERGY"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Solar EPC, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Solar EPC, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Solar EPC, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Solar EPC, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-solar-epc-inquiry_qualification-decision_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-solar-epc-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Solar EPC, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-solar-epc-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-solar-epc-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Solar EPC, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-solar-epc-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-solar-epc-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Solar EPC, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-solar-epc-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-solar-epc-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Solar EPC, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-solar-epc-validation-validation_rule-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-solar-epc-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Solar EPC, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-solar-epc-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-solar-epc-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Solar EPC, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-solar-epc-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-solar-epc-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Solar EPC, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-solar-epc-validation-validation_rule-0200`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "validation_id": "V-034-solar-epc-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Solar EPC, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-solar-epc-validation-validation_rule-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-solar-epc-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Solar EPC, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-solar-epc-validation-validation_rule-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-solar-epc-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Solar EPC, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-solar-epc-validation-validation_rule-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-solar-epc-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Solar EPC without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-solar-epc-scenario_test-scenario-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-solar-epc-001",
  "setup": "Customer asks informally for Solar EPC without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Solar EPC with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-solar-epc-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-solar-epc-002",
  "setup": "Customer requests price for Solar EPC with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Solar EPC. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-solar-epc-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-solar-epc-003",
  "setup": "Customer uploads a relevant schedule/specification for Solar EPC.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Solar EPC. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-solar-epc-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-solar-epc-004",
  "setup": "Customer message and uploaded document disagree on Solar EPC.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Solar EPC. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-solar-epc-scenario_test-scenario-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-solar-epc-005",
  "setup": "Supplier proposes a different product, provider or method for Solar EPC.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Solar EPC sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-solar-epc-scenario_test-scenario-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-solar-epc-006",
  "setup": "Customer needs Solar EPC sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Solar EPC needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-solar-epc-scenario_test-scenario-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-solar-epc-007",
  "setup": "The request for Solar EPC needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Solar EPC

English term: Solar EPC. Arabic operational draft: متطلبات Solar EPC. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Solar EPC",
  "term_ar": "متطلبات Solar EPC",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### site and energy load

English term: site and energy load. Arabic operational draft: متطلبات site and energy load. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "site and energy load",
  "term_ar": "متطلبات site and energy load",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### technology/capacity

English term: technology/capacity. Arabic operational draft: متطلبات technology/capacity. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technology/capacity",
  "term_ar": "متطلبات technology/capacity",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### grid/connection

English term: grid/connection. Arabic operational draft: متطلبات grid/connection. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "grid/connection",
  "term_ar": "متطلبات grid/connection",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### storage/charging profile

English term: storage/charging profile. Arabic operational draft: متطلبات storage/charging profile. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0234`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "storage/charging profile",
  "term_ar": "متطلبات storage/charging profile",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### yield/performance

English term: yield/performance. Arabic operational draft: متطلبات yield/performance. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0235`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "yield/performance",
  "term_ar": "متطلبات yield/performance",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### permits

English term: permits. Arabic operational draft: متطلبات permits. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0236`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "permits",
  "term_ar": "متطلبات permits",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```

### O&M

English term: O&M. Arabic operational draft: متطلبات O&M. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-solar-epc-glossary-bilingual_term-0237`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "O&M",
  "term_ar": "متطلبات O&M",
  "canonical_subcategory": "solar-epc",
  "normalization_only": true
}
```


# 2. EV charging

**Arabic draft:** متطلبات EV charging
**Slug:** `ev-charging`
**Aliases:** EV charging

## Industry

### Industry scope — EV charging

EV charging is treated as a distinct procurement route within Renewable Energy. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers industrial products, machinery, process systems, fabrication, logistics, maintenance and safety. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-034-ev-charging-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD

```json
{
  "category": "Renewable Energy",
  "subcategory": "EV charging",
  "profile": "industrial",
  "aliases": [
    "EV charging"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — EV charging

A normal UAE sourcing workflow for EV charging moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-034-ev-charging-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — EV charging

Customers may describe EV charging through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-034-ev-charging-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — EV charging

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-034-ev-charging-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core EV charging product or service

The primary deliverable requested within EV charging; exact type, quantity, performance, scope and acceptance must be normalized. For EV charging, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-ev-charging-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "EV charging",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for EV charging

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For EV charging, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-ev-charging-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "EV charging",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized EV charging

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For EV charging, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-ev-charging-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "EV charging",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for EV charging

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For EV charging, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-ev-charging-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "EV charging",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for EV charging

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For EV charging, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-ev-charging-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "EV charging",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for EV charging

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For EV charging, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-ev-charging-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "EV charging",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for EV charging

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For EV charging, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-ev-charging-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "EV charging",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for EV charging

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For EV charging, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-ev-charging-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "EV charging",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Site And Energy Load scope component

Site And Energy Load is a recurring scope component for EV charging. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-ev-charging-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "site and energy load",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Technology/Capacity scope component

Technology/Capacity is a recurring scope component for EV charging. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-ev-charging-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "technology/capacity",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Grid/Connection scope component

Grid/Connection is a recurring scope component for EV charging. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-ev-charging-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "grid/connection",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Storage/Charging Profile scope component

Storage/Charging Profile is a recurring scope component for EV charging. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-ev-charging-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "storage/charging profile",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Yield/Performance scope component

Yield/Performance is a recurring scope component for EV charging. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-ev-charging-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "yield/performance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Permits scope component

Permits is a recurring scope component for EV charging. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-ev-charging-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "permits",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### O&M scope component

O&M is a recurring scope component for EV charging. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-ev-charging-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "O&M",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: process or duty

For EV charging, process or duty must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "process or duty",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: capacity and operating envelope

For EV charging, capacity and operating envelope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "capacity and operating envelope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: materials and compatibility

For EV charging, materials and compatibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "materials and compatibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environment and hazardous classification

For EV charging, environment and hazardous classification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environment and hazardous classification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/utilities

For EV charging, power/utilities must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/utilities",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces and controls

For EV charging, interfaces and controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces and controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: quality and certification

For EV charging, quality and certification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "quality and certification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation and commissioning

For EV charging, installation and commissioning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation and commissioning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: spares and maintenance

For EV charging, spares and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "spares and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: logistics and lifecycle

For EV charging, logistics and lifecycle must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "logistics and lifecycle",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: site and energy load

For EV charging, site and energy load must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "site and energy load",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: technology/capacity

For EV charging, technology/capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "technology/capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: grid/connection

For EV charging, grid/connection must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "grid/connection",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: storage/charging profile

For EV charging, storage/charging profile must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "storage/charging profile",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: yield/performance

For EV charging, yield/performance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "yield/performance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: permits

For EV charging, permits must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "permits",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: O&M

For EV charging, O&M must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-ev-charging-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "O&M",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer/OEM

A manufacturer/OEM may be relevant to EV charging depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-ev-charging-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer/OEM",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to EV charging depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-ev-charging-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: industrial system integrator

A industrial system integrator may be relevant to EV charging depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-ev-charging-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "industrial system integrator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator/machine shop

A fabricator/machine shop may be relevant to EV charging depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-ev-charging-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator/machine shop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: EPC or specialist contractor

A EPC or specialist contractor may be relevant to EV charging depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-ev-charging-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "EPC or specialist contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: inspection/testing body

A inspection/testing body may be relevant to EV charging depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-ev-charging-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "inspection/testing body",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer/OEM

This supplier type can participate in EV charging only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-ev-charging-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer/OEM",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in EV charging only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-ev-charging-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — industrial system integrator

This supplier type can participate in EV charging only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-ev-charging-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "industrial system integrator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator/machine shop

This supplier type can participate in EV charging only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-ev-charging-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator/machine shop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — EPC or specialist contractor

This supplier type can participate in EV charging only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-ev-charging-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "EPC or specialist contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — inspection/testing body

This supplier type can participate in EV charging only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-ev-charging-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "inspection/testing body",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — rental/service provider

This supplier type can participate in EV charging only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-ev-charging-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "rental/service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance and spare-parts provider

This supplier type can participate in EV charging only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-ev-charging-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer/OEM

Before routing a EV charging inquiry to a manufacturer/OEM, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-ev-charging-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "manufacturer/OEM",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a EV charging inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-ev-charging-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — industrial system integrator

Before routing a EV charging inquiry to a industrial system integrator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-ev-charging-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "industrial system integrator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator/machine shop

Before routing a EV charging inquiry to a fabricator/machine shop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-ev-charging-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "fabricator/machine shop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — EPC or specialist contractor

Before routing a EV charging inquiry to a EPC or specialist contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-ev-charging-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "EPC or specialist contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — inspection/testing body

Before routing a EV charging inquiry to a inspection/testing body, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-ev-charging-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "inspection/testing body",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — rental/service provider

Before routing a EV charging inquiry to a rental/service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-ev-charging-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "rental/service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance and spare-parts provider

Before routing a EV charging inquiry to a maintenance and spare-parts provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-ev-charging-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for EV charging should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-ev-charging-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for EV charging should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-ev-charging-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for EV charging should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-ev-charging-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for EV charging should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-ev-charging-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for EV charging should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-ev-charging-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for EV charging should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-ev-charging-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for EV charging should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-ev-charging-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for EV charging should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-ev-charging-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for EV charging should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-ev-charging-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for EV charging should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-ev-charging-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Process/Duty Data Sheet

Process/Duty Data Sheet may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "process-duty-data-sheet",
  "document_name": "process/duty data sheet",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### P&Id Or Schematic

P&Id Or Schematic may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "p-and-id-or-schematic",
  "document_name": "P&ID or schematic",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Layout/General Arrangement

Layout/General Arrangement may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "layout-general-arrangement",
  "document_name": "layout/general arrangement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Hazardous Area Classification

Hazardous Area Classification may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "hazardous-area-classification",
  "document_name": "hazardous area classification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Single-Line/Control Diagram

Single-Line/Control Diagram may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "single-line-control-diagram",
  "document_name": "single-line/control diagram",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Interface List

Interface List may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "interface-list",
  "document_name": "interface list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quality Plan/Itp

Quality Plan/Itp may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quality-plan-itp",
  "document_name": "quality plan/ITP",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Certificates

Material Certificates may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-certificates",
  "document_name": "material certificates",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Reports

Inspection/Test Reports may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-reports",
  "document_name": "inspection/test reports",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement/Lifting Plan

Method Statement/Lifting Plan may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement-lifting-plan",
  "document_name": "method statement/lifting plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Commissioning Plan

Commissioning Plan may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "commissioning-plan",
  "document_name": "commissioning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Spares List

Spares List may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "spares-list",
  "document_name": "spares list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for EV charging. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-ev-charging-documents-document_requirement-0083`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Industrial, Standards, Conformity and Quality Services

For EV charging, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-ev-charging-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment, Climate and Agriculture Regulation

For EV charging, consult Environment, Climate and Agriculture Regulation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-ev-charging-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOCCAE

```json
{
  "source_id": "UAE-MOCCAE",
  "publisher": "Ministry of Climate Change and Environment",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment Agency Abu Dhabi Policies and Permits

For EV charging, consult Environment Agency Abu Dhabi Policies and Permits when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-ev-charging-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-EAD

```json
{
  "source_id": "UAE-EAD",
  "publisher": "Environment Agency Abu Dhabi",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ADNOC Supplier and In-Country Value Requirements

For EV charging, consult ADNOC Supplier and In-Country Value Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-ev-charging-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADNOC-SUPPLIER

```json
{
  "source_id": "UAE-ADNOC-SUPPLIER",
  "publisher": "ADNOC",
  "source_type": "state_enterprise_supplier_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Customs and Import/Export Guidance

For EV charging, consult UAE Customs and Import/Export Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-ev-charging-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CUSTOMS

```json
{
  "source_id": "UAE-CUSTOMS",
  "publisher": "Federal Authority for Identity, Citizenship, Customs and Port Security",
  "source_type": "government_customs_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For EV charging, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-ev-charging-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### IEC Standards Catalogue

For EV charging, consult IEC Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-ev-charging-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: IEC-STANDARDS

```json
{
  "source_id": "IEC-STANDARDS",
  "publisher": "International Electrotechnical Commission",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For EV charging, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-ev-charging-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Shams Dubai Solar Connection Requirements

For EV charging, consult Shams Dubai Solar Connection Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-ev-charging-uae_regulations-source_activation-0092`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DEWA-SOLAR

```json
{
  "source_id": "UAE-DEWA-SOLAR",
  "publisher": "Dubai Electricity and Water Authority",
  "source_type": "utility_program",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### EV Green Charger and Charging Infrastructure Guidance

For EV charging, consult EV Green Charger and Charging Infrastructure Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-ev-charging-uae_regulations-source_activation-0093`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DEWA-EV

```json
{
  "source_id": "UAE-DEWA-EV",
  "publisher": "Dubai Electricity and Water Authority",
  "source_type": "utility_program",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Energy Strategy and Energy Infrastructure Guidance

For EV charging, consult UAE Energy Strategy and Energy Infrastructure Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-ev-charging-uae_regulations-source_activation-0094`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOEI-ENERGY

```json
{
  "source_id": "UAE-MOEI-ENERGY",
  "publisher": "Ministry of Energy and Infrastructure",
  "source_type": "government_energy_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for EV charging. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-ev-charging-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for EV charging. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-ev-charging-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for EV charging. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-ev-charging-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for EV charging. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-ev-charging-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for EV charging. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-ev-charging-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for EV charging. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-ev-charging-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for EV charging. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-ev-charging-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for EV charging. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-ev-charging-commercial_pricing-cost_driver-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for EV charging. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-ev-charging-commercial_pricing-cost_driver-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for EV charging. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-ev-charging-commercial_pricing-cost_driver-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-ev-charging-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-ev-charging-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-ev-charging-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-ev-charging-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-ev-charging-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-ev-charging-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-ev-charging-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-ev-charging-customer_tradeoffs-tradeoff-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-ev-charging-customer_tradeoffs-tradeoff-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-ev-charging-customer_tradeoffs-tradeoff-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In EV charging, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-ev-charging-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In EV charging, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-ev-charging-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In EV charging, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-ev-charging-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In EV charging, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-ev-charging-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In EV charging, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-ev-charging-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In EV charging, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-ev-charging-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In EV charging, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-ev-charging-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In EV charging, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-ev-charging-risk-risk_control-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In EV charging, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-ev-charging-risk-risk_control-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In EV charging, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-ev-charging-risk-risk_control-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For EV charging, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-ev-charging-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For EV charging, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-ev-charging-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For EV charging, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-ev-charging-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For EV charging, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-ev-charging-best_practices-qualification_best_practice-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For EV charging, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-ev-charging-best_practices-qualification_best_practice-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For EV charging, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-ev-charging-best_practices-qualification_best_practice-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to EV charging; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-ev-charging-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to EV charging; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-ev-charging-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to EV charging; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-ev-charging-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to EV charging; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-ev-charging-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to EV charging; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-ev-charging-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to EV charging; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-ev-charging-troubleshooting-recovery_guidance-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to EV charging; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-ev-charging-troubleshooting-recovery_guidance-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to EV charging; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-ev-charging-troubleshooting-recovery_guidance-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What process, duty, product, load, medium or operating objective applies?

Ask in plain language: What process, duty, product, load, medium or operating objective applies? Arabic draft: ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-process-duty",
  "question_en": "What process, duty, product, load, medium or operating objective applies?",
  "question_ar": "ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "process-duty",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What process, duty, product, load, medium or operating objective applies? is missing

When the normalized field process-duty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-process-duty",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "process-duty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-process-duty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What capacity, pressure, temperature, speed, load, accuracy or operating range is required?

Ask in plain language: What capacity, pressure, temperature, speed, load, accuracy or operating range is required? Arabic draft: ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-capacity-conditions",
  "question_en": "What capacity, pressure, temperature, speed, load, accuracy or operating range is required?",
  "question_ar": "ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟",
  "expected_answer_type": "structured_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-conditions",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What capacity, pressure, temperature, speed, load, accuracy or operating range is required? is missing

When the normalized field capacity-conditions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-capacity-conditions",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-conditions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-capacity-conditions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?

Ask in plain language: What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? Arabic draft: ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-materials-compatibility",
  "question_en": "What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?",
  "question_ar": "ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "materials-compatibility",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? is missing

When the normalized field materials-compatibility is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-materials-compatibility",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "materials-compatibility",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-materials-compatibility"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?

Ask in plain language: What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies? Arabic draft: ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-environment-hazard",
  "question_en": "What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?",
  "question_ar": "ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "environment-hazard",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?

Ask in plain language: What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? Arabic draft: ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-utilities-controls",
  "question_en": "What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?",
  "question_ar": "ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-controls",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? is missing

When the normalized field utilities-controls is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-utilities-controls",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-controls",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-utilities-controls"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What code, material certificate, test, inspection, traceability or third-party approval is required?

Ask in plain language: What code, material certificate, test, inspection, traceability or third-party approval is required? Arabic draft: ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-standards-certification",
  "question_en": "What code, material certificate, test, inspection, traceability or third-party approval is required?",
  "question_ar": "ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "standards-certification",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?

Ask in plain language: What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? Arabic draft: ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-installation-commissioning",
  "question_en": "What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?",
  "question_ar": "ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-commissioning",
  "order": 190,
  "confidence_contribution": 0.03
}
```

### Ask when What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? is missing

When the normalized field installation-commissioning is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-installation-commissioning",
  "priority": 981,
  "when": {
    "all": [
      {
        "field": "installation-commissioning",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-installation-commissioning"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What consumables, critical spares, maintenance interval, response time and lifecycle support are required?

Ask in plain language: What consumables, critical spares, maintenance interval, response time and lifecycle support are required? Arabic draft: ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-spares-service",
  "question_en": "What consumables, critical spares, maintenance interval, response time and lifecycle support are required?",
  "question_ar": "ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "spares-service",
  "order": 200,
  "confidence_contribution": 0.012
}
```

### Please clarify the site and energy load requirements for EV charging.

Ask in plain language: Please clarify the site and energy load requirements for EV charging. Arabic draft: يرجى توضيح متطلبات site and energy load الخاصة بـ EV charging. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-facet-01",
  "question_en": "Please clarify the site and energy load requirements for EV charging.",
  "question_ar": "يرجى توضيح متطلبات site and energy load الخاصة بـ EV charging.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the site and energy load requirements for EV charging. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the technology/capacity requirements for EV charging.

Ask in plain language: Please clarify the technology/capacity requirements for EV charging. Arabic draft: يرجى توضيح متطلبات technology/capacity الخاصة بـ EV charging. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-facet-02",
  "question_en": "Please clarify the technology/capacity requirements for EV charging.",
  "question_ar": "يرجى توضيح متطلبات technology/capacity الخاصة بـ EV charging.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the technology/capacity requirements for EV charging. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the grid/connection requirements for EV charging.

Ask in plain language: Please clarify the grid/connection requirements for EV charging. Arabic draft: يرجى توضيح متطلبات grid/connection الخاصة بـ EV charging. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-facet-03",
  "question_en": "Please clarify the grid/connection requirements for EV charging.",
  "question_ar": "يرجى توضيح متطلبات grid/connection الخاصة بـ EV charging.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the grid/connection requirements for EV charging. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the storage/charging profile requirements for EV charging.

Ask in plain language: Please clarify the storage/charging profile requirements for EV charging. Arabic draft: يرجى توضيح متطلبات storage/charging profile الخاصة بـ EV charging. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-facet-04",
  "question_en": "Please clarify the storage/charging profile requirements for EV charging.",
  "question_ar": "يرجى توضيح متطلبات storage/charging profile الخاصة بـ EV charging.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the yield/performance requirements for EV charging.

Ask in plain language: Please clarify the yield/performance requirements for EV charging. Arabic draft: يرجى توضيح متطلبات yield/performance الخاصة بـ EV charging. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-facet-05",
  "question_en": "Please clarify the yield/performance requirements for EV charging.",
  "question_ar": "يرجى توضيح متطلبات yield/performance الخاصة بـ EV charging.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the permits requirements for EV charging.

Ask in plain language: Please clarify the permits requirements for EV charging. Arabic draft: يرجى توضيح متطلبات permits الخاصة بـ EV charging. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-facet-06",
  "question_en": "Please clarify the permits requirements for EV charging.",
  "question_ar": "يرجى توضيح متطلبات permits الخاصة بـ EV charging.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the O&M requirements for EV charging.

Ask in plain language: Please clarify the O&M requirements for EV charging. Arabic draft: يرجى توضيح متطلبات O&M الخاصة بـ EV charging. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-facet-07",
  "question_en": "Please clarify the O&M requirements for EV charging.",
  "question_ar": "يرجى توضيح متطلبات O&M الخاصة بـ EV charging.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact EV charging product, service, variant or outcome best matches your need?

Ask in plain language: Which exact EV charging product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن EV charging التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-exact-subtype",
  "question_en": "Which exact EV charging product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن EV charging التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact EV charging product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-ev-charging-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about EV charging are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about EV charging are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في EV charging التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-unknowns",
  "question_en": "Which details about EV charging are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في EV charging التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for EV charging?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for EV charging? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في EV charging؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-qualification_question-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-ev-charging-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for EV charging?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في EV charging؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to EV charging, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to EV charging, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to EV charging, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to EV charging, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0189`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER, UAE-CUSTOMS, ISO-STANDARDS, IEC-STANDARDS, ASTM-STANDARDS, UAE-DEWA-SOLAR, UAE-DEWA-EV, UAE-MOEI-ENERGY

```json
{
  "rule_id": "R-034-ev-charging-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-MOIAT",
        "UAE-MOCCAE",
        "UAE-EAD",
        "UAE-ADNOC-SUPPLIER",
        "UAE-CUSTOMS",
        "ISO-STANDARDS",
        "IEC-STANDARDS",
        "ASTM-STANDARDS",
        "UAE-DEWA-SOLAR",
        "UAE-DEWA-EV",
        "UAE-MOEI-ENERGY"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to EV charging, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to EV charging, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to EV charging, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to EV charging, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-ev-charging-inquiry_qualification-decision_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-ev-charging-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For EV charging, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-ev-charging-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-ev-charging-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For EV charging, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-ev-charging-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-ev-charging-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For EV charging, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-ev-charging-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-ev-charging-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For EV charging, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-ev-charging-validation-validation_rule-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-ev-charging-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For EV charging, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-ev-charging-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-ev-charging-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For EV charging, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-ev-charging-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-ev-charging-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For EV charging, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-ev-charging-validation-validation_rule-0200`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "validation_id": "V-034-ev-charging-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For EV charging, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-ev-charging-validation-validation_rule-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-ev-charging-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For EV charging, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-ev-charging-validation-validation_rule-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-ev-charging-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For EV charging, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-ev-charging-validation-validation_rule-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-ev-charging-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for EV charging without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-ev-charging-scenario_test-scenario-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-ev-charging-001",
  "setup": "Customer asks informally for EV charging without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for EV charging with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-ev-charging-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-ev-charging-002",
  "setup": "Customer requests price for EV charging with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for EV charging. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-ev-charging-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-ev-charging-003",
  "setup": "Customer uploads a relevant schedule/specification for EV charging.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on EV charging. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-ev-charging-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-ev-charging-004",
  "setup": "Customer message and uploaded document disagree on EV charging.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for EV charging. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-ev-charging-scenario_test-scenario-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-ev-charging-005",
  "setup": "Supplier proposes a different product, provider or method for EV charging.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs EV charging sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-ev-charging-scenario_test-scenario-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-ev-charging-006",
  "setup": "Customer needs EV charging sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for EV charging needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-ev-charging-scenario_test-scenario-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-ev-charging-007",
  "setup": "The request for EV charging needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### EV charging

English term: EV charging. Arabic operational draft: متطلبات EV charging. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "EV charging",
  "term_ar": "متطلبات EV charging",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### site and energy load

English term: site and energy load. Arabic operational draft: متطلبات site and energy load. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "site and energy load",
  "term_ar": "متطلبات site and energy load",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### technology/capacity

English term: technology/capacity. Arabic operational draft: متطلبات technology/capacity. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technology/capacity",
  "term_ar": "متطلبات technology/capacity",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### grid/connection

English term: grid/connection. Arabic operational draft: متطلبات grid/connection. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "grid/connection",
  "term_ar": "متطلبات grid/connection",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### storage/charging profile

English term: storage/charging profile. Arabic operational draft: متطلبات storage/charging profile. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0234`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "storage/charging profile",
  "term_ar": "متطلبات storage/charging profile",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### yield/performance

English term: yield/performance. Arabic operational draft: متطلبات yield/performance. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0235`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "yield/performance",
  "term_ar": "متطلبات yield/performance",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### permits

English term: permits. Arabic operational draft: متطلبات permits. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0236`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "permits",
  "term_ar": "متطلبات permits",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```

### O&M

English term: O&M. Arabic operational draft: متطلبات O&M. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-ev-charging-glossary-bilingual_term-0237`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "O&M",
  "term_ar": "متطلبات O&M",
  "canonical_subcategory": "ev-charging",
  "normalization_only": true
}
```


# 3. Battery storage

**Arabic draft:** متطلبات Battery storage
**Slug:** `battery-storage`
**Aliases:** Battery storage

## Industry

### Industry scope — Battery storage

Battery storage is treated as a distinct procurement route within Renewable Energy. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers industrial products, machinery, process systems, fabrication, logistics, maintenance and safety. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-034-battery-storage-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD

```json
{
  "category": "Renewable Energy",
  "subcategory": "Battery storage",
  "profile": "industrial",
  "aliases": [
    "Battery storage"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Battery storage

A normal UAE sourcing workflow for Battery storage moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-034-battery-storage-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Battery storage

Customers may describe Battery storage through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-034-battery-storage-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Battery storage

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-034-battery-storage-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Battery storage product or service

The primary deliverable requested within Battery storage; exact type, quantity, performance, scope and acceptance must be normalized. For Battery storage, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-battery-storage-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Battery storage",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Battery storage

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Battery storage, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-battery-storage-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Battery storage",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Battery storage

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Battery storage, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-battery-storage-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Battery storage",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Battery storage

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Battery storage, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-battery-storage-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Battery storage",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Battery storage

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Battery storage, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-battery-storage-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Battery storage",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Battery storage

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Battery storage, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-battery-storage-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Battery storage",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Battery storage

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Battery storage, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-battery-storage-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Battery storage",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Battery storage

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Battery storage, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-battery-storage-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Battery storage",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Site And Energy Load scope component

Site And Energy Load is a recurring scope component for Battery storage. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-battery-storage-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "site and energy load",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Technology/Capacity scope component

Technology/Capacity is a recurring scope component for Battery storage. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-battery-storage-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "technology/capacity",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Grid/Connection scope component

Grid/Connection is a recurring scope component for Battery storage. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-battery-storage-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "grid/connection",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Storage/Charging Profile scope component

Storage/Charging Profile is a recurring scope component for Battery storage. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-battery-storage-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "storage/charging profile",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Yield/Performance scope component

Yield/Performance is a recurring scope component for Battery storage. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-battery-storage-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "yield/performance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Permits scope component

Permits is a recurring scope component for Battery storage. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-battery-storage-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "permits",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### O&M scope component

O&M is a recurring scope component for Battery storage. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-battery-storage-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "O&M",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: process or duty

For Battery storage, process or duty must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "process or duty",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: capacity and operating envelope

For Battery storage, capacity and operating envelope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "capacity and operating envelope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: materials and compatibility

For Battery storage, materials and compatibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "materials and compatibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environment and hazardous classification

For Battery storage, environment and hazardous classification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environment and hazardous classification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/utilities

For Battery storage, power/utilities must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/utilities",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces and controls

For Battery storage, interfaces and controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces and controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: quality and certification

For Battery storage, quality and certification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "quality and certification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation and commissioning

For Battery storage, installation and commissioning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation and commissioning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: spares and maintenance

For Battery storage, spares and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "spares and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: logistics and lifecycle

For Battery storage, logistics and lifecycle must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "logistics and lifecycle",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: site and energy load

For Battery storage, site and energy load must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "site and energy load",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: technology/capacity

For Battery storage, technology/capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "technology/capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: grid/connection

For Battery storage, grid/connection must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "grid/connection",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: storage/charging profile

For Battery storage, storage/charging profile must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "storage/charging profile",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: yield/performance

For Battery storage, yield/performance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "yield/performance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: permits

For Battery storage, permits must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "permits",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: O&M

For Battery storage, O&M must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-battery-storage-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "O&M",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer/OEM

A manufacturer/OEM may be relevant to Battery storage depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-battery-storage-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer/OEM",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Battery storage depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-battery-storage-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: industrial system integrator

A industrial system integrator may be relevant to Battery storage depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-battery-storage-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "industrial system integrator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator/machine shop

A fabricator/machine shop may be relevant to Battery storage depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-battery-storage-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator/machine shop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: EPC or specialist contractor

A EPC or specialist contractor may be relevant to Battery storage depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-battery-storage-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "EPC or specialist contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: inspection/testing body

A inspection/testing body may be relevant to Battery storage depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-battery-storage-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "inspection/testing body",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer/OEM

This supplier type can participate in Battery storage only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-battery-storage-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer/OEM",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Battery storage only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-battery-storage-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — industrial system integrator

This supplier type can participate in Battery storage only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-battery-storage-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "industrial system integrator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator/machine shop

This supplier type can participate in Battery storage only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-battery-storage-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator/machine shop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — EPC or specialist contractor

This supplier type can participate in Battery storage only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-battery-storage-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "EPC or specialist contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — inspection/testing body

This supplier type can participate in Battery storage only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-battery-storage-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "inspection/testing body",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — rental/service provider

This supplier type can participate in Battery storage only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-battery-storage-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "rental/service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance and spare-parts provider

This supplier type can participate in Battery storage only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-battery-storage-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer/OEM

Before routing a Battery storage inquiry to a manufacturer/OEM, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-battery-storage-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "manufacturer/OEM",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Battery storage inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-battery-storage-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — industrial system integrator

Before routing a Battery storage inquiry to a industrial system integrator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-battery-storage-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "industrial system integrator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator/machine shop

Before routing a Battery storage inquiry to a fabricator/machine shop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-battery-storage-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "fabricator/machine shop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — EPC or specialist contractor

Before routing a Battery storage inquiry to a EPC or specialist contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-battery-storage-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "EPC or specialist contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — inspection/testing body

Before routing a Battery storage inquiry to a inspection/testing body, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-battery-storage-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "inspection/testing body",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — rental/service provider

Before routing a Battery storage inquiry to a rental/service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-battery-storage-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "rental/service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance and spare-parts provider

Before routing a Battery storage inquiry to a maintenance and spare-parts provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-battery-storage-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Battery storage should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-battery-storage-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Battery storage should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-battery-storage-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Battery storage should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-battery-storage-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Battery storage should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-battery-storage-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Battery storage should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-battery-storage-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Battery storage should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-battery-storage-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Battery storage should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-battery-storage-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Battery storage should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-battery-storage-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Battery storage should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-battery-storage-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Battery storage should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-battery-storage-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Process/Duty Data Sheet

Process/Duty Data Sheet may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "process-duty-data-sheet",
  "document_name": "process/duty data sheet",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### P&Id Or Schematic

P&Id Or Schematic may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "p-and-id-or-schematic",
  "document_name": "P&ID or schematic",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Layout/General Arrangement

Layout/General Arrangement may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "layout-general-arrangement",
  "document_name": "layout/general arrangement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Hazardous Area Classification

Hazardous Area Classification may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "hazardous-area-classification",
  "document_name": "hazardous area classification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Single-Line/Control Diagram

Single-Line/Control Diagram may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "single-line-control-diagram",
  "document_name": "single-line/control diagram",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Interface List

Interface List may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "interface-list",
  "document_name": "interface list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quality Plan/Itp

Quality Plan/Itp may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quality-plan-itp",
  "document_name": "quality plan/ITP",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Certificates

Material Certificates may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-certificates",
  "document_name": "material certificates",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Reports

Inspection/Test Reports may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-reports",
  "document_name": "inspection/test reports",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement/Lifting Plan

Method Statement/Lifting Plan may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement-lifting-plan",
  "document_name": "method statement/lifting plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Commissioning Plan

Commissioning Plan may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "commissioning-plan",
  "document_name": "commissioning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Spares List

Spares List may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "spares-list",
  "document_name": "spares list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for Battery storage. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-battery-storage-documents-document_requirement-0083`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Industrial, Standards, Conformity and Quality Services

For Battery storage, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-battery-storage-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment, Climate and Agriculture Regulation

For Battery storage, consult Environment, Climate and Agriculture Regulation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-battery-storage-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOCCAE

```json
{
  "source_id": "UAE-MOCCAE",
  "publisher": "Ministry of Climate Change and Environment",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment Agency Abu Dhabi Policies and Permits

For Battery storage, consult Environment Agency Abu Dhabi Policies and Permits when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-battery-storage-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-EAD

```json
{
  "source_id": "UAE-EAD",
  "publisher": "Environment Agency Abu Dhabi",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ADNOC Supplier and In-Country Value Requirements

For Battery storage, consult ADNOC Supplier and In-Country Value Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-battery-storage-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADNOC-SUPPLIER

```json
{
  "source_id": "UAE-ADNOC-SUPPLIER",
  "publisher": "ADNOC",
  "source_type": "state_enterprise_supplier_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Customs and Import/Export Guidance

For Battery storage, consult UAE Customs and Import/Export Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-battery-storage-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CUSTOMS

```json
{
  "source_id": "UAE-CUSTOMS",
  "publisher": "Federal Authority for Identity, Citizenship, Customs and Port Security",
  "source_type": "government_customs_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Battery storage, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-battery-storage-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### IEC Standards Catalogue

For Battery storage, consult IEC Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-battery-storage-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: IEC-STANDARDS

```json
{
  "source_id": "IEC-STANDARDS",
  "publisher": "International Electrotechnical Commission",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For Battery storage, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-battery-storage-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Shams Dubai Solar Connection Requirements

For Battery storage, consult Shams Dubai Solar Connection Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-battery-storage-uae_regulations-source_activation-0092`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DEWA-SOLAR

```json
{
  "source_id": "UAE-DEWA-SOLAR",
  "publisher": "Dubai Electricity and Water Authority",
  "source_type": "utility_program",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### EV Green Charger and Charging Infrastructure Guidance

For Battery storage, consult EV Green Charger and Charging Infrastructure Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-battery-storage-uae_regulations-source_activation-0093`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DEWA-EV

```json
{
  "source_id": "UAE-DEWA-EV",
  "publisher": "Dubai Electricity and Water Authority",
  "source_type": "utility_program",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Energy Strategy and Energy Infrastructure Guidance

For Battery storage, consult UAE Energy Strategy and Energy Infrastructure Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-battery-storage-uae_regulations-source_activation-0094`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOEI-ENERGY

```json
{
  "source_id": "UAE-MOEI-ENERGY",
  "publisher": "Ministry of Energy and Infrastructure",
  "source_type": "government_energy_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Battery storage. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-battery-storage-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Battery storage. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-battery-storage-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Battery storage. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-battery-storage-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Battery storage. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-battery-storage-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Battery storage. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-battery-storage-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Battery storage. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-battery-storage-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Battery storage. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-battery-storage-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Battery storage. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-battery-storage-commercial_pricing-cost_driver-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Battery storage. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-battery-storage-commercial_pricing-cost_driver-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Battery storage. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-battery-storage-commercial_pricing-cost_driver-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-battery-storage-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-battery-storage-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-battery-storage-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-battery-storage-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-battery-storage-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-battery-storage-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-battery-storage-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-battery-storage-customer_tradeoffs-tradeoff-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-battery-storage-customer_tradeoffs-tradeoff-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-battery-storage-customer_tradeoffs-tradeoff-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Battery storage, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-battery-storage-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Battery storage, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-battery-storage-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Battery storage, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-battery-storage-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Battery storage, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-battery-storage-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Battery storage, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-battery-storage-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Battery storage, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-battery-storage-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Battery storage, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-battery-storage-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Battery storage, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-battery-storage-risk-risk_control-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Battery storage, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-battery-storage-risk-risk_control-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Battery storage, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-battery-storage-risk-risk_control-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Battery storage, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-battery-storage-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Battery storage, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-battery-storage-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Battery storage, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-battery-storage-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Battery storage, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-battery-storage-best_practices-qualification_best_practice-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Battery storage, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-battery-storage-best_practices-qualification_best_practice-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Battery storage, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-battery-storage-best_practices-qualification_best_practice-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Battery storage; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-battery-storage-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Battery storage; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-battery-storage-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Battery storage; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-battery-storage-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Battery storage; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-battery-storage-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Battery storage; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-battery-storage-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Battery storage; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-battery-storage-troubleshooting-recovery_guidance-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Battery storage; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-battery-storage-troubleshooting-recovery_guidance-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Battery storage; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-battery-storage-troubleshooting-recovery_guidance-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What process, duty, product, load, medium or operating objective applies?

Ask in plain language: What process, duty, product, load, medium or operating objective applies? Arabic draft: ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-process-duty",
  "question_en": "What process, duty, product, load, medium or operating objective applies?",
  "question_ar": "ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "process-duty",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What process, duty, product, load, medium or operating objective applies? is missing

When the normalized field process-duty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-process-duty",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "process-duty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-process-duty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What capacity, pressure, temperature, speed, load, accuracy or operating range is required?

Ask in plain language: What capacity, pressure, temperature, speed, load, accuracy or operating range is required? Arabic draft: ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-capacity-conditions",
  "question_en": "What capacity, pressure, temperature, speed, load, accuracy or operating range is required?",
  "question_ar": "ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟",
  "expected_answer_type": "structured_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-conditions",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What capacity, pressure, temperature, speed, load, accuracy or operating range is required? is missing

When the normalized field capacity-conditions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-capacity-conditions",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-conditions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-capacity-conditions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?

Ask in plain language: What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? Arabic draft: ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-materials-compatibility",
  "question_en": "What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?",
  "question_ar": "ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "materials-compatibility",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? is missing

When the normalized field materials-compatibility is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-materials-compatibility",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "materials-compatibility",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-materials-compatibility"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?

Ask in plain language: What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies? Arabic draft: ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-environment-hazard",
  "question_en": "What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?",
  "question_ar": "ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "environment-hazard",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?

Ask in plain language: What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? Arabic draft: ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-utilities-controls",
  "question_en": "What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?",
  "question_ar": "ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-controls",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? is missing

When the normalized field utilities-controls is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-utilities-controls",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-controls",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-utilities-controls"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What code, material certificate, test, inspection, traceability or third-party approval is required?

Ask in plain language: What code, material certificate, test, inspection, traceability or third-party approval is required? Arabic draft: ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-standards-certification",
  "question_en": "What code, material certificate, test, inspection, traceability or third-party approval is required?",
  "question_ar": "ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "standards-certification",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?

Ask in plain language: What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? Arabic draft: ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-installation-commissioning",
  "question_en": "What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?",
  "question_ar": "ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-commissioning",
  "order": 190,
  "confidence_contribution": 0.03
}
```

### Ask when What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? is missing

When the normalized field installation-commissioning is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-installation-commissioning",
  "priority": 981,
  "when": {
    "all": [
      {
        "field": "installation-commissioning",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-installation-commissioning"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What consumables, critical spares, maintenance interval, response time and lifecycle support are required?

Ask in plain language: What consumables, critical spares, maintenance interval, response time and lifecycle support are required? Arabic draft: ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-spares-service",
  "question_en": "What consumables, critical spares, maintenance interval, response time and lifecycle support are required?",
  "question_ar": "ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "spares-service",
  "order": 200,
  "confidence_contribution": 0.012
}
```

### Please clarify the site and energy load requirements for Battery storage.

Ask in plain language: Please clarify the site and energy load requirements for Battery storage. Arabic draft: يرجى توضيح متطلبات site and energy load الخاصة بـ Battery storage. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-facet-01",
  "question_en": "Please clarify the site and energy load requirements for Battery storage.",
  "question_ar": "يرجى توضيح متطلبات site and energy load الخاصة بـ Battery storage.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the site and energy load requirements for Battery storage. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the technology/capacity requirements for Battery storage.

Ask in plain language: Please clarify the technology/capacity requirements for Battery storage. Arabic draft: يرجى توضيح متطلبات technology/capacity الخاصة بـ Battery storage. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-facet-02",
  "question_en": "Please clarify the technology/capacity requirements for Battery storage.",
  "question_ar": "يرجى توضيح متطلبات technology/capacity الخاصة بـ Battery storage.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the technology/capacity requirements for Battery storage. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the grid/connection requirements for Battery storage.

Ask in plain language: Please clarify the grid/connection requirements for Battery storage. Arabic draft: يرجى توضيح متطلبات grid/connection الخاصة بـ Battery storage. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-facet-03",
  "question_en": "Please clarify the grid/connection requirements for Battery storage.",
  "question_ar": "يرجى توضيح متطلبات grid/connection الخاصة بـ Battery storage.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the grid/connection requirements for Battery storage. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the storage/charging profile requirements for Battery storage.

Ask in plain language: Please clarify the storage/charging profile requirements for Battery storage. Arabic draft: يرجى توضيح متطلبات storage/charging profile الخاصة بـ Battery storage. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-facet-04",
  "question_en": "Please clarify the storage/charging profile requirements for Battery storage.",
  "question_ar": "يرجى توضيح متطلبات storage/charging profile الخاصة بـ Battery storage.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the yield/performance requirements for Battery storage.

Ask in plain language: Please clarify the yield/performance requirements for Battery storage. Arabic draft: يرجى توضيح متطلبات yield/performance الخاصة بـ Battery storage. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-facet-05",
  "question_en": "Please clarify the yield/performance requirements for Battery storage.",
  "question_ar": "يرجى توضيح متطلبات yield/performance الخاصة بـ Battery storage.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the permits requirements for Battery storage.

Ask in plain language: Please clarify the permits requirements for Battery storage. Arabic draft: يرجى توضيح متطلبات permits الخاصة بـ Battery storage. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-facet-06",
  "question_en": "Please clarify the permits requirements for Battery storage.",
  "question_ar": "يرجى توضيح متطلبات permits الخاصة بـ Battery storage.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the O&M requirements for Battery storage.

Ask in plain language: Please clarify the O&M requirements for Battery storage. Arabic draft: يرجى توضيح متطلبات O&M الخاصة بـ Battery storage. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-facet-07",
  "question_en": "Please clarify the O&M requirements for Battery storage.",
  "question_ar": "يرجى توضيح متطلبات O&M الخاصة بـ Battery storage.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact Battery storage product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Battery storage product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Battery storage التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-exact-subtype",
  "question_en": "Which exact Battery storage product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Battery storage التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Battery storage product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-battery-storage-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Battery storage are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Battery storage are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Battery storage التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-unknowns",
  "question_en": "Which details about Battery storage are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Battery storage التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Battery storage?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Battery storage? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Battery storage؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-qualification_question-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-battery-storage-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Battery storage?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Battery storage؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Battery storage, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Battery storage, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Battery storage, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Battery storage, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0189`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER, UAE-CUSTOMS, ISO-STANDARDS, IEC-STANDARDS, ASTM-STANDARDS, UAE-DEWA-SOLAR, UAE-DEWA-EV, UAE-MOEI-ENERGY

```json
{
  "rule_id": "R-034-battery-storage-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-MOIAT",
        "UAE-MOCCAE",
        "UAE-EAD",
        "UAE-ADNOC-SUPPLIER",
        "UAE-CUSTOMS",
        "ISO-STANDARDS",
        "IEC-STANDARDS",
        "ASTM-STANDARDS",
        "UAE-DEWA-SOLAR",
        "UAE-DEWA-EV",
        "UAE-MOEI-ENERGY"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Battery storage, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Battery storage, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Battery storage, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Battery storage, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-battery-storage-inquiry_qualification-decision_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-battery-storage-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Battery storage, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-battery-storage-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-battery-storage-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Battery storage, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-battery-storage-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-battery-storage-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Battery storage, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-battery-storage-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-battery-storage-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Battery storage, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-battery-storage-validation-validation_rule-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-battery-storage-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Battery storage, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-battery-storage-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-battery-storage-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Battery storage, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-battery-storage-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-battery-storage-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Battery storage, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-battery-storage-validation-validation_rule-0200`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "validation_id": "V-034-battery-storage-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Battery storage, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-battery-storage-validation-validation_rule-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-battery-storage-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Battery storage, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-battery-storage-validation-validation_rule-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-battery-storage-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Battery storage, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-battery-storage-validation-validation_rule-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-battery-storage-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Battery storage without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-battery-storage-scenario_test-scenario-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-battery-storage-001",
  "setup": "Customer asks informally for Battery storage without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Battery storage with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-battery-storage-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-battery-storage-002",
  "setup": "Customer requests price for Battery storage with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Battery storage. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-battery-storage-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-battery-storage-003",
  "setup": "Customer uploads a relevant schedule/specification for Battery storage.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Battery storage. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-battery-storage-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-battery-storage-004",
  "setup": "Customer message and uploaded document disagree on Battery storage.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Battery storage. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-battery-storage-scenario_test-scenario-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-battery-storage-005",
  "setup": "Supplier proposes a different product, provider or method for Battery storage.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Battery storage sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-battery-storage-scenario_test-scenario-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-battery-storage-006",
  "setup": "Customer needs Battery storage sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Battery storage needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-battery-storage-scenario_test-scenario-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-battery-storage-007",
  "setup": "The request for Battery storage needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Battery storage

English term: Battery storage. Arabic operational draft: متطلبات Battery storage. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Battery storage",
  "term_ar": "متطلبات Battery storage",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### site and energy load

English term: site and energy load. Arabic operational draft: متطلبات site and energy load. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "site and energy load",
  "term_ar": "متطلبات site and energy load",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### technology/capacity

English term: technology/capacity. Arabic operational draft: متطلبات technology/capacity. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technology/capacity",
  "term_ar": "متطلبات technology/capacity",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### grid/connection

English term: grid/connection. Arabic operational draft: متطلبات grid/connection. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "grid/connection",
  "term_ar": "متطلبات grid/connection",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### storage/charging profile

English term: storage/charging profile. Arabic operational draft: متطلبات storage/charging profile. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0234`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "storage/charging profile",
  "term_ar": "متطلبات storage/charging profile",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### yield/performance

English term: yield/performance. Arabic operational draft: متطلبات yield/performance. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0235`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "yield/performance",
  "term_ar": "متطلبات yield/performance",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### permits

English term: permits. Arabic operational draft: متطلبات permits. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0236`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "permits",
  "term_ar": "متطلبات permits",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```

### O&M

English term: O&M. Arabic operational draft: متطلبات O&M. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-battery-storage-glossary-bilingual_term-0237`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "O&M",
  "term_ar": "متطلبات O&M",
  "canonical_subcategory": "battery-storage",
  "normalization_only": true
}
```


# 4. Energy audits

**Arabic draft:** متطلبات Energy audits
**Slug:** `energy-audits`
**Aliases:** Energy audits

## Industry

### Industry scope — Energy audits

Energy audits is treated as a distinct procurement route within Renewable Energy. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers industrial products, machinery, process systems, fabrication, logistics, maintenance and safety. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-034-energy-audits-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD

```json
{
  "category": "Renewable Energy",
  "subcategory": "Energy audits",
  "profile": "industrial",
  "aliases": [
    "Energy audits"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Energy audits

A normal UAE sourcing workflow for Energy audits moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-034-energy-audits-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Energy audits

Customers may describe Energy audits through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-034-energy-audits-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Energy audits

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-034-energy-audits-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Energy audits product or service

The primary deliverable requested within Energy audits; exact type, quantity, performance, scope and acceptance must be normalized. For Energy audits, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-energy-audits-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Energy audits",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Energy audits

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Energy audits, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-energy-audits-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Energy audits",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Energy audits

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Energy audits, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-energy-audits-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Energy audits",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Energy audits

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Energy audits, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-energy-audits-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Energy audits",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Energy audits

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Energy audits, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-energy-audits-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Energy audits",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Energy audits

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Energy audits, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-energy-audits-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Energy audits",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Energy audits

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Energy audits, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-energy-audits-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Energy audits",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Energy audits

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Energy audits, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-034-energy-audits-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Energy audits",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Site And Energy Load scope component

Site And Energy Load is a recurring scope component for Energy audits. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-energy-audits-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "site and energy load",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Technology/Capacity scope component

Technology/Capacity is a recurring scope component for Energy audits. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-energy-audits-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "technology/capacity",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Grid/Connection scope component

Grid/Connection is a recurring scope component for Energy audits. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-energy-audits-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "grid/connection",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Storage/Charging Profile scope component

Storage/Charging Profile is a recurring scope component for Energy audits. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-energy-audits-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "storage/charging profile",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Yield/Performance scope component

Yield/Performance is a recurring scope component for Energy audits. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-energy-audits-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "yield/performance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Permits scope component

Permits is a recurring scope component for Energy audits. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-energy-audits-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "permits",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### O&M scope component

O&M is a recurring scope component for Energy audits. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-034-energy-audits-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "O&M",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: process or duty

For Energy audits, process or duty must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "process or duty",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: capacity and operating envelope

For Energy audits, capacity and operating envelope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "capacity and operating envelope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: materials and compatibility

For Energy audits, materials and compatibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "materials and compatibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environment and hazardous classification

For Energy audits, environment and hazardous classification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environment and hazardous classification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/utilities

For Energy audits, power/utilities must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/utilities",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces and controls

For Energy audits, interfaces and controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces and controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: quality and certification

For Energy audits, quality and certification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "quality and certification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation and commissioning

For Energy audits, installation and commissioning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation and commissioning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: spares and maintenance

For Energy audits, spares and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "spares and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: logistics and lifecycle

For Energy audits, logistics and lifecycle must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "logistics and lifecycle",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: site and energy load

For Energy audits, site and energy load must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "site and energy load",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: technology/capacity

For Energy audits, technology/capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "technology/capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: grid/connection

For Energy audits, grid/connection must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "grid/connection",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: storage/charging profile

For Energy audits, storage/charging profile must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "storage/charging profile",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: yield/performance

For Energy audits, yield/performance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "yield/performance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: permits

For Energy audits, permits must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "permits",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: O&M

For Energy audits, O&M must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-034-energy-audits-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "O&M",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer/OEM

A manufacturer/OEM may be relevant to Energy audits depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-energy-audits-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer/OEM",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Energy audits depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-energy-audits-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: industrial system integrator

A industrial system integrator may be relevant to Energy audits depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-energy-audits-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "industrial system integrator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator/machine shop

A fabricator/machine shop may be relevant to Energy audits depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-energy-audits-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator/machine shop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: EPC or specialist contractor

A EPC or specialist contractor may be relevant to Energy audits depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-energy-audits-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "EPC or specialist contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: inspection/testing body

A inspection/testing body may be relevant to Energy audits depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-034-energy-audits-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "inspection/testing body",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer/OEM

This supplier type can participate in Energy audits only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-energy-audits-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer/OEM",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Energy audits only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-energy-audits-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — industrial system integrator

This supplier type can participate in Energy audits only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-energy-audits-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "industrial system integrator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator/machine shop

This supplier type can participate in Energy audits only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-energy-audits-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator/machine shop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — EPC or specialist contractor

This supplier type can participate in Energy audits only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-energy-audits-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "EPC or specialist contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — inspection/testing body

This supplier type can participate in Energy audits only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-energy-audits-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "inspection/testing body",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — rental/service provider

This supplier type can participate in Energy audits only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-energy-audits-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "rental/service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance and spare-parts provider

This supplier type can participate in Energy audits only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-034-energy-audits-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer/OEM

Before routing a Energy audits inquiry to a manufacturer/OEM, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-energy-audits-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "manufacturer/OEM",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Energy audits inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-energy-audits-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — industrial system integrator

Before routing a Energy audits inquiry to a industrial system integrator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-energy-audits-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "industrial system integrator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator/machine shop

Before routing a Energy audits inquiry to a fabricator/machine shop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-energy-audits-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "fabricator/machine shop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — EPC or specialist contractor

Before routing a Energy audits inquiry to a EPC or specialist contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-energy-audits-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "EPC or specialist contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — inspection/testing body

Before routing a Energy audits inquiry to a inspection/testing body, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-energy-audits-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "inspection/testing body",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — rental/service provider

Before routing a Energy audits inquiry to a rental/service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-energy-audits-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "rental/service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance and spare-parts provider

Before routing a Energy audits inquiry to a maintenance and spare-parts provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-034-energy-audits-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Energy audits should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-energy-audits-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Energy audits should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-energy-audits-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Energy audits should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-energy-audits-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Energy audits should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-energy-audits-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Energy audits should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-energy-audits-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Energy audits should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-energy-audits-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Energy audits should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-energy-audits-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Energy audits should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-energy-audits-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Energy audits should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-energy-audits-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Energy audits should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-034-energy-audits-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Process/Duty Data Sheet

Process/Duty Data Sheet may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "process-duty-data-sheet",
  "document_name": "process/duty data sheet",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### P&Id Or Schematic

P&Id Or Schematic may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "p-and-id-or-schematic",
  "document_name": "P&ID or schematic",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Layout/General Arrangement

Layout/General Arrangement may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "layout-general-arrangement",
  "document_name": "layout/general arrangement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Hazardous Area Classification

Hazardous Area Classification may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "hazardous-area-classification",
  "document_name": "hazardous area classification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Single-Line/Control Diagram

Single-Line/Control Diagram may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "single-line-control-diagram",
  "document_name": "single-line/control diagram",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Interface List

Interface List may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "interface-list",
  "document_name": "interface list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quality Plan/Itp

Quality Plan/Itp may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quality-plan-itp",
  "document_name": "quality plan/ITP",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Certificates

Material Certificates may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-certificates",
  "document_name": "material certificates",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Reports

Inspection/Test Reports may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-reports",
  "document_name": "inspection/test reports",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement/Lifting Plan

Method Statement/Lifting Plan may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement-lifting-plan",
  "document_name": "method statement/lifting plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Commissioning Plan

Commissioning Plan may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "commissioning-plan",
  "document_name": "commissioning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Spares List

Spares List may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "spares-list",
  "document_name": "spares list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for Energy audits. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-034-energy-audits-documents-document_requirement-0083`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Industrial, Standards, Conformity and Quality Services

For Energy audits, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-energy-audits-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment, Climate and Agriculture Regulation

For Energy audits, consult Environment, Climate and Agriculture Regulation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-energy-audits-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOCCAE

```json
{
  "source_id": "UAE-MOCCAE",
  "publisher": "Ministry of Climate Change and Environment",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment Agency Abu Dhabi Policies and Permits

For Energy audits, consult Environment Agency Abu Dhabi Policies and Permits when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-energy-audits-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-EAD

```json
{
  "source_id": "UAE-EAD",
  "publisher": "Environment Agency Abu Dhabi",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ADNOC Supplier and In-Country Value Requirements

For Energy audits, consult ADNOC Supplier and In-Country Value Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-energy-audits-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADNOC-SUPPLIER

```json
{
  "source_id": "UAE-ADNOC-SUPPLIER",
  "publisher": "ADNOC",
  "source_type": "state_enterprise_supplier_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Customs and Import/Export Guidance

For Energy audits, consult UAE Customs and Import/Export Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-energy-audits-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CUSTOMS

```json
{
  "source_id": "UAE-CUSTOMS",
  "publisher": "Federal Authority for Identity, Citizenship, Customs and Port Security",
  "source_type": "government_customs_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Energy audits, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-energy-audits-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### IEC Standards Catalogue

For Energy audits, consult IEC Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-energy-audits-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: IEC-STANDARDS

```json
{
  "source_id": "IEC-STANDARDS",
  "publisher": "International Electrotechnical Commission",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For Energy audits, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-energy-audits-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Shams Dubai Solar Connection Requirements

For Energy audits, consult Shams Dubai Solar Connection Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-energy-audits-uae_regulations-source_activation-0092`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DEWA-SOLAR

```json
{
  "source_id": "UAE-DEWA-SOLAR",
  "publisher": "Dubai Electricity and Water Authority",
  "source_type": "utility_program",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### EV Green Charger and Charging Infrastructure Guidance

For Energy audits, consult EV Green Charger and Charging Infrastructure Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-energy-audits-uae_regulations-source_activation-0093`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DEWA-EV

```json
{
  "source_id": "UAE-DEWA-EV",
  "publisher": "Dubai Electricity and Water Authority",
  "source_type": "utility_program",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Energy Strategy and Energy Infrastructure Guidance

For Energy audits, consult UAE Energy Strategy and Energy Infrastructure Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-034-energy-audits-uae_regulations-source_activation-0094`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOEI-ENERGY

```json
{
  "source_id": "UAE-MOEI-ENERGY",
  "publisher": "Ministry of Energy and Infrastructure",
  "source_type": "government_energy_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Energy audits. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-energy-audits-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Energy audits. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-energy-audits-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Energy audits. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-energy-audits-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Energy audits. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-energy-audits-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Energy audits. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-energy-audits-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Energy audits. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-energy-audits-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Energy audits. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-energy-audits-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Energy audits. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-energy-audits-commercial_pricing-cost_driver-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Energy audits. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-energy-audits-commercial_pricing-cost_driver-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Energy audits. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-034-energy-audits-commercial_pricing-cost_driver-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-energy-audits-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-energy-audits-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-energy-audits-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-energy-audits-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-energy-audits-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-energy-audits-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-energy-audits-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-energy-audits-customer_tradeoffs-tradeoff-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-energy-audits-customer_tradeoffs-tradeoff-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-034-energy-audits-customer_tradeoffs-tradeoff-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Energy audits, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-energy-audits-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Energy audits, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-energy-audits-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Energy audits, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-energy-audits-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Energy audits, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-energy-audits-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Energy audits, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-energy-audits-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Energy audits, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-energy-audits-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Energy audits, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-energy-audits-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Energy audits, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-energy-audits-risk-risk_control-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Energy audits, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-energy-audits-risk-risk_control-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Energy audits, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-034-energy-audits-risk-risk_control-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Energy audits, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-energy-audits-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Energy audits, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-energy-audits-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Energy audits, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-energy-audits-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Energy audits, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-energy-audits-best_practices-qualification_best_practice-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Energy audits, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-energy-audits-best_practices-qualification_best_practice-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Energy audits, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-034-energy-audits-best_practices-qualification_best_practice-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Energy audits; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-energy-audits-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Energy audits; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-energy-audits-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Energy audits; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-energy-audits-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Energy audits; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-energy-audits-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Energy audits; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-energy-audits-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Energy audits; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-energy-audits-troubleshooting-recovery_guidance-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Energy audits; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-energy-audits-troubleshooting-recovery_guidance-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Energy audits; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-034-energy-audits-troubleshooting-recovery_guidance-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What process, duty, product, load, medium or operating objective applies?

Ask in plain language: What process, duty, product, load, medium or operating objective applies? Arabic draft: ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-process-duty",
  "question_en": "What process, duty, product, load, medium or operating objective applies?",
  "question_ar": "ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "process-duty",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What process, duty, product, load, medium or operating objective applies? is missing

When the normalized field process-duty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-process-duty",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "process-duty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-process-duty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What capacity, pressure, temperature, speed, load, accuracy or operating range is required?

Ask in plain language: What capacity, pressure, temperature, speed, load, accuracy or operating range is required? Arabic draft: ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-capacity-conditions",
  "question_en": "What capacity, pressure, temperature, speed, load, accuracy or operating range is required?",
  "question_ar": "ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟",
  "expected_answer_type": "structured_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-conditions",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What capacity, pressure, temperature, speed, load, accuracy or operating range is required? is missing

When the normalized field capacity-conditions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-capacity-conditions",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-conditions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-capacity-conditions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?

Ask in plain language: What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? Arabic draft: ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-materials-compatibility",
  "question_en": "What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?",
  "question_ar": "ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "materials-compatibility",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? is missing

When the normalized field materials-compatibility is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-materials-compatibility",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "materials-compatibility",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-materials-compatibility"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?

Ask in plain language: What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies? Arabic draft: ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-environment-hazard",
  "question_en": "What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?",
  "question_ar": "ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "environment-hazard",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?

Ask in plain language: What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? Arabic draft: ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-utilities-controls",
  "question_en": "What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?",
  "question_ar": "ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-controls",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? is missing

When the normalized field utilities-controls is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-utilities-controls",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-controls",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-utilities-controls"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What code, material certificate, test, inspection, traceability or third-party approval is required?

Ask in plain language: What code, material certificate, test, inspection, traceability or third-party approval is required? Arabic draft: ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-standards-certification",
  "question_en": "What code, material certificate, test, inspection, traceability or third-party approval is required?",
  "question_ar": "ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "standards-certification",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?

Ask in plain language: What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? Arabic draft: ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-installation-commissioning",
  "question_en": "What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?",
  "question_ar": "ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-commissioning",
  "order": 190,
  "confidence_contribution": 0.03
}
```

### Ask when What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? is missing

When the normalized field installation-commissioning is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-installation-commissioning",
  "priority": 981,
  "when": {
    "all": [
      {
        "field": "installation-commissioning",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-installation-commissioning"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What consumables, critical spares, maintenance interval, response time and lifecycle support are required?

Ask in plain language: What consumables, critical spares, maintenance interval, response time and lifecycle support are required? Arabic draft: ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-spares-service",
  "question_en": "What consumables, critical spares, maintenance interval, response time and lifecycle support are required?",
  "question_ar": "ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "spares-service",
  "order": 200,
  "confidence_contribution": 0.012
}
```

### Please clarify the site and energy load requirements for Energy audits.

Ask in plain language: Please clarify the site and energy load requirements for Energy audits. Arabic draft: يرجى توضيح متطلبات site and energy load الخاصة بـ Energy audits. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-facet-01",
  "question_en": "Please clarify the site and energy load requirements for Energy audits.",
  "question_ar": "يرجى توضيح متطلبات site and energy load الخاصة بـ Energy audits.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the site and energy load requirements for Energy audits. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the technology/capacity requirements for Energy audits.

Ask in plain language: Please clarify the technology/capacity requirements for Energy audits. Arabic draft: يرجى توضيح متطلبات technology/capacity الخاصة بـ Energy audits. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-facet-02",
  "question_en": "Please clarify the technology/capacity requirements for Energy audits.",
  "question_ar": "يرجى توضيح متطلبات technology/capacity الخاصة بـ Energy audits.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the technology/capacity requirements for Energy audits. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the grid/connection requirements for Energy audits.

Ask in plain language: Please clarify the grid/connection requirements for Energy audits. Arabic draft: يرجى توضيح متطلبات grid/connection الخاصة بـ Energy audits. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-facet-03",
  "question_en": "Please clarify the grid/connection requirements for Energy audits.",
  "question_ar": "يرجى توضيح متطلبات grid/connection الخاصة بـ Energy audits.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the grid/connection requirements for Energy audits. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the storage/charging profile requirements for Energy audits.

Ask in plain language: Please clarify the storage/charging profile requirements for Energy audits. Arabic draft: يرجى توضيح متطلبات storage/charging profile الخاصة بـ Energy audits. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-facet-04",
  "question_en": "Please clarify the storage/charging profile requirements for Energy audits.",
  "question_ar": "يرجى توضيح متطلبات storage/charging profile الخاصة بـ Energy audits.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the yield/performance requirements for Energy audits.

Ask in plain language: Please clarify the yield/performance requirements for Energy audits. Arabic draft: يرجى توضيح متطلبات yield/performance الخاصة بـ Energy audits. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-facet-05",
  "question_en": "Please clarify the yield/performance requirements for Energy audits.",
  "question_ar": "يرجى توضيح متطلبات yield/performance الخاصة بـ Energy audits.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the permits requirements for Energy audits.

Ask in plain language: Please clarify the permits requirements for Energy audits. Arabic draft: يرجى توضيح متطلبات permits الخاصة بـ Energy audits. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-facet-06",
  "question_en": "Please clarify the permits requirements for Energy audits.",
  "question_ar": "يرجى توضيح متطلبات permits الخاصة بـ Energy audits.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the O&M requirements for Energy audits.

Ask in plain language: Please clarify the O&M requirements for Energy audits. Arabic draft: يرجى توضيح متطلبات O&M الخاصة بـ Energy audits. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-facet-07",
  "question_en": "Please clarify the O&M requirements for Energy audits.",
  "question_ar": "يرجى توضيح متطلبات O&M الخاصة بـ Energy audits.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact Energy audits product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Energy audits product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Energy audits التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-exact-subtype",
  "question_en": "Which exact Energy audits product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Energy audits التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Energy audits product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-034-energy-audits-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Energy audits are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Energy audits are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Energy audits التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-unknowns",
  "question_en": "Which details about Energy audits are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Energy audits التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Energy audits?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Energy audits? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Energy audits؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-qualification_question-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-034-energy-audits-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Energy audits?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Energy audits؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Energy audits, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Energy audits, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Energy audits, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Energy audits, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0189`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER, UAE-CUSTOMS, ISO-STANDARDS, IEC-STANDARDS, ASTM-STANDARDS, UAE-DEWA-SOLAR, UAE-DEWA-EV, UAE-MOEI-ENERGY

```json
{
  "rule_id": "R-034-energy-audits-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-MOIAT",
        "UAE-MOCCAE",
        "UAE-EAD",
        "UAE-ADNOC-SUPPLIER",
        "UAE-CUSTOMS",
        "ISO-STANDARDS",
        "IEC-STANDARDS",
        "ASTM-STANDARDS",
        "UAE-DEWA-SOLAR",
        "UAE-DEWA-EV",
        "UAE-MOEI-ENERGY"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Energy audits, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Energy audits, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Energy audits, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Energy audits, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-034-energy-audits-inquiry_qualification-decision_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-034-energy-audits-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Energy audits, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-energy-audits-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-energy-audits-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Energy audits, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-energy-audits-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-energy-audits-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Energy audits, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-energy-audits-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-energy-audits-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Energy audits, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-energy-audits-validation-validation_rule-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-energy-audits-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Energy audits, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-energy-audits-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-energy-audits-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Energy audits, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-energy-audits-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-energy-audits-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Energy audits, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-energy-audits-validation-validation_rule-0200`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "validation_id": "V-034-energy-audits-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Energy audits, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-energy-audits-validation-validation_rule-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-energy-audits-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Energy audits, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-energy-audits-validation-validation_rule-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-energy-audits-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Energy audits, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-034-energy-audits-validation-validation_rule-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-034-energy-audits-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Energy audits without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-energy-audits-scenario_test-scenario-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-energy-audits-001",
  "setup": "Customer asks informally for Energy audits without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Energy audits with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-energy-audits-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-energy-audits-002",
  "setup": "Customer requests price for Energy audits with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Energy audits. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-energy-audits-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-energy-audits-003",
  "setup": "Customer uploads a relevant schedule/specification for Energy audits.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Energy audits. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-energy-audits-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-energy-audits-004",
  "setup": "Customer message and uploaded document disagree on Energy audits.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Energy audits. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-energy-audits-scenario_test-scenario-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-energy-audits-005",
  "setup": "Supplier proposes a different product, provider or method for Energy audits.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Energy audits sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-energy-audits-scenario_test-scenario-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-energy-audits-006",
  "setup": "Customer needs Energy audits sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Energy audits needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-034-energy-audits-scenario_test-scenario-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-034-energy-audits-007",
  "setup": "The request for Energy audits needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Energy audits

English term: Energy audits. Arabic operational draft: متطلبات Energy audits. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Energy audits",
  "term_ar": "متطلبات Energy audits",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### site and energy load

English term: site and energy load. Arabic operational draft: متطلبات site and energy load. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "site and energy load",
  "term_ar": "متطلبات site and energy load",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### technology/capacity

English term: technology/capacity. Arabic operational draft: متطلبات technology/capacity. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technology/capacity",
  "term_ar": "متطلبات technology/capacity",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### grid/connection

English term: grid/connection. Arabic operational draft: متطلبات grid/connection. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "grid/connection",
  "term_ar": "متطلبات grid/connection",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### storage/charging profile

English term: storage/charging profile. Arabic operational draft: متطلبات storage/charging profile. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0234`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "storage/charging profile",
  "term_ar": "متطلبات storage/charging profile",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### yield/performance

English term: yield/performance. Arabic operational draft: متطلبات yield/performance. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0235`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "yield/performance",
  "term_ar": "متطلبات yield/performance",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### permits

English term: permits. Arabic operational draft: متطلبات permits. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0236`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "permits",
  "term_ar": "متطلبات permits",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```

### O&M

English term: O&M. Arabic operational draft: متطلبات O&M. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-034-energy-audits-glossary-bilingual_term-0237`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "O&M",
  "term_ar": "متطلبات O&M",
  "canonical_subcategory": "energy-audits",
  "normalization_only": true
}
```
