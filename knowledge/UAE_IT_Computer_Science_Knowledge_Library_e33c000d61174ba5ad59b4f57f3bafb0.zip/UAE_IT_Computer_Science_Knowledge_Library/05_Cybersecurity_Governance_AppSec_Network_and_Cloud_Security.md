# Cybersecurity Governance, Application Security, Network Security and Cloud Security in the UAE

**Purpose.** The cybersecurity control layer: UAE cyber governance, secure SDLC, OWASP, threat modeling, network defense, zero trust, SOC/SIEM, cloud security, IAM, CSPM, Kubernetes hardening and compliance. This file is part of a broader UAE technology knowledge library designed for engineers, CTOs, product leaders, cybersecurity teams, AI practitioners, IT managers, founders, consultants and students who need a source-backed operating reference.

**How to use this file.** Start with the domain chapters for source-backed UAE context, then use the practice appendices as implementation checklists. Treat regulation, product availability, cloud service availability, platform policy and security-control claims as verification-sensitive because they can change.

## Category Coverage

- **Domain 08:** Cybersecurity governance and regulation in the UAE: UAE Cybersecurity Council, TDRA, NESA/IAS, DESC, PDPL, cybercrime law, sectoral obligations and compliance programs
- **Domain 09:** Application security and secure software development: OWASP, threat modeling, secure coding, SAST/DAST, dependency security, secrets, API security and DevSecOps
- **Domain 10:** Network security and infrastructure security: firewalls, zero trust, IAM, VPN, Wi-Fi, segmentation, SOC operations, SIEM, endpoint security and incident response
- **Domain 11:** Cloud security and identity security: shared responsibility, IAM, CSPM, container security, Kubernetes hardening, logging, encryption, key management and UAE residency issues


## Domain 08: Cybersecurity governance and regulation in the UAE: UAE Cybersecurity Council, TDRA, NESA/IAS, DESC, PDPL, cybercrime law, sectoral obligations and compliance programs

### Cybersecurity Governance and Regulation in the UAE

## Domain Scope
Cybersecurity governance in the UAE encompasses the legal, regulatory, and institutional frameworks designed to protect the nation's digital infrastructure, ensure data privacy, and combat cybercrime. As of July 2026, the domain has shifted from "capacity building" to "active defense," driven by the **National Cyber Security Strategy (2025-2031)**.

### UAE Relevance and Use Cases
- **Critical Information Infrastructure (CII):** Protection of energy, finance, healthcare, and telecommunications sectors.
- **Digital Government:** Securing the transition to "Agentic AI" and 100% digital public services.
- **Sovereign Assurance:** Ensuring data residency and digital sovereignty for government and sensitive private sector data.
- **Business Use Cases:** Compliance with federal and emirate-level standards is mandatory for licensing and operation, particularly in regulated sectors like finance (ADGM/DIFC/CBUAE) and healthcare.

---

## UAE Legal, Regulatory, and Policy Context

### Key Regulators and Authorities
1.  **UAE Cybersecurity Council (CSC):** The primary federal body responsible for national cybersecurity strategy, legislation, and the **National Cyber Accreditation Programme (NCAP)**.
2.  **Federal Authority for Artificial Intelligence and Data (FAAID):** Established in June 2026, this authority consolidated the UAE AI Office, TDRA’s Digital Government sector, and the UAE Data Office. It now oversees the **Personal Data Protection Law (PDPL)** and national AI governance.
3.  **Dubai Electronic Security Center (DESC):** The regulator for Dubai government entities and critical infrastructure, enforcing the **Information Security Regulation (ISR)**.

### Primary Laws and Regulations
-   **Federal Decree-Law No. 34 of 2021 (Cybercrime Law):** Criminalizes hacking, data theft, and the spread of rumors. Penalties include imprisonment and fines up to **AED 3 million**.
-   **Federal Decree-Law No. 45 of 2021 (PDPL):** The federal data privacy law. As of 2026, it has entered an "active compliance phase" with FAAID providing practical guidance while formal Executive Regulations are finalized.
-   **National Cyber Security Strategy (2025-2031):** Focuses on five pillars: Governance, Resilient Environment, Secure Innovation (AI/Quantum), National Capabilities, and International Collaboration.
-   **National Cyber Accreditation Programme (NCAP):** Effective 2026, restricts the use of unaccredited cybersecurity service providers for CII.

---

## Core Concepts and Theory
-   **Active Defense:** A proactive posture involving real-time threat hunting and automated response, moving beyond passive perimeter security.
-   **Digital Debt:** The risk posed by legacy vulnerabilities; the CSC reports that ~50% of exploited vulnerabilities in the UAE are >5 years old.
-   **Agentic AI Security:** Governance of autonomous AI agents that execute workflows, focusing on "shadow agents" and model integrity.
-   **Quantum Resilience:** Preparation for post-quantum cryptography (PQC) to counter "harvest now, decrypt later" threats.

---

## Architectures, Patterns, and Workflows

### Reference Architectures
-   **Zero Trust Architecture (ZTA):** Now a binding requirement for ADGM financial institutions (2026) and a core recommendation in DESC ISR v3.0.
-   **Secure Supply Chain:** Implementation of **Software Bill of Materials (SBOM)** is becoming mandatory for government procurement to ensure transparency in software components.

### Compliance Workflows
1.  **Gap Analysis:** Mapping existing controls against NESA IAS v2 or DESC ISR v3.1.
2.  **Risk Assessment:** Annual mandatory assessments approved by senior management.
3.  **Accreditation:** Ensuring all MSSPs and cloud vendors are NCAP-accredited.
4.  **Incident Notification:** Strict 24-hour reporting window for material incidents (ADGM/CBUAE).

---

## Standards, Frameworks, and Best Practices

### Local Standards
-   **NESA Information Assurance Standards (IAS) v2 (2025):** Rebased on ISO/IEC 27001:2022 and NIST SP 800-53 Rev. 5. Includes 15 control families (6 Management, 9 Technical).
-   **DESC Information Security Regulation (ISR) v3.1:** Prescriptive controls for Dubai entities, emphasizing asset classification and executive accountability.
-   **CBUAE Technology Risk & InfoSec Regulation (Article 13):** Mandatory for payment service providers, requiring multi-factor authentication (MFA) for high-risk transactions.

### Global Alignment
-   **ISO/IEC 27001:2022:** The foundational standard for most UAE frameworks.
-   **DORA (Digital Operational Resilience Act):** ADGM’s 2026 framework is closely aligned with EU DORA for financial resilience.

---

## Technical Tactics and Implementation Details
-   **MFA and Token Protection:** Shift from simple MFA to "phishing-resistant" MFA to counter MFA fatigue and token theft.
-   **Encryption:** Mandatory end-to-end encryption for user passwords and sensitive data in transit (CBUAE Article 13).
-   **API Security:** Safeguards for API development to secure data exchange between applications.
-   **PQC Migration:** Requirement for financial and government entities to produce a Post-Quantum Cryptography migration roadmap by late 2026.

---

## Measurement, KPIs, and Operational Metrics
-   **Maturity Levels:** NESA and DESC use a 0-5 maturity scale; entities are often required to reach Level 3 ("Defined") or Level 4 ("Managed") for critical systems.
-   **Incident Response Time:** Target for containment of "Critical" incidents is typically <4 hours.
-   **Compliance Score:** Percentage of mandatory controls implemented (e.g., 136 mandatory sub-controls in NESA IAS).
-   **Cyber Pulse Metrics:** National awareness reach (e.g., 20,000+ women trained in cybersecurity).

---

## UAE Sector Use Cases and Localization Notes
-   **Finance:** CBUAE Federal Decree-Law No. 6 of 2025 imposes strict liability for management in cases of security negligence.
-   **Healthcare:** ADHICS (Abu Dhabi) and NABIDH (Dubai) regulate health data, with strict data residency requirements.
-   **Energy/Utilities:** High focus on Operational Technology (OT) security and state-sponsored sabotage defense.
-   **Localization:** All public-facing portals must provide Arabic/English security guidance and adhere to UAE cultural norms in content filtering (Child Digital Safety Law 2026).

---

## Professional Practice and Checklists

### Audit Checklist for 2026 Compliance
- [ ] **NCAP Check:** Are all cybersecurity vendors and cloud providers NCAP-accredited?
- [ ] **SBOM Inventory:** Is there a Software Bill of Materials for all new software procurement?
- [ ] **DPO Appointment:** Has a Data Protection Officer been registered with FAAID (if processing large-scale sensitive data)?
- [ ] **24-Hour Drill:** Has the incident response team tested the 24-hour regulatory notification workflow?
- [ ] **Legacy Debt:** Have all vulnerabilities >5 years old been patched or mitigated?

---

## Sources

### Primary Sources
- **UAE Cybersecurity Council (CSC):** National Cyber Security Strategy (2025-2031), [[1]](#ref1)
- **Central Bank of the UAE (CBUAE):** Article (13) Technology Risk and Information Security, [[2]](#ref2)
- **Dubai Electronic Security Center (DESC):** Information Security Regulation (ISR) v3.0/3.1, [[3]](#ref3)
- **ADGM FSRA:** Cyber Risk Management Framework 2026, [[4]](#ref4)
- **UAE Government Portal (u.ae):** Cyber Safety and Digital Security, [[5]](#ref5)

### Secondary Sources
- **Chambers and Partners:** Cybersecurity 2026 UAE Trends, [[1]](#ref1)
- **DLA Piper:** Data Protection Laws in UAE - General, [[6]](#ref6)
- **V-Comply:** UAE Cybercrime Law Overview, [[7]](#ref7)

---

## Gaps and Verification Notes
- **PDPL Executive Regulations:** While the law is active, the formal Executive Regulations are still pending as of early 2026; however, FAAID (the new authority) is issuing "practical guidance" that serves as the current compliance baseline.
- **NCAP Provider List:** The official list of NCAP-accredited providers is dynamic; organizations must verify current status via the CSC portal.
- **FAAID Transition:** The consolidation of TDRA and Data Office functions into FAAID (June 2026) is a recent organizational change; some legacy URLs may still point to TDRA or the Data Office.

**Checklist Status:** All items in `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/79a88591/RESEARCH_CHECKLIST.md` are marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/79a88591/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/79a88591/TOOL_RESULTS.md`
- Research child tool results lines: `2087`
- Research child tool results bytes: `135629`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/79a88591/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Cybersecurity governance and regulation in the UAE

#### 1. Architecture and scope questions
A senior UAE technology practitioner should begin every engagement by documenting the operating context before selecting tools. The working file should answer: which business or public-service outcome is being protected or improved, which data classifications are involved, which emirate or regulator matters, whether the system is federal, local-government, free-zone, private-sector or cross-border, which users require Arabic/English experience, which security controls are mandatory, and which operational owner will maintain the system after launch.

#### 2. UAE compliance and risk checklist
Use this checklist before approving any technology design, software release, cloud migration, AI deployment, data platform, cybersecurity control or outsourced IT service:

- Confirm the legal entity, regulator, sector, data classification and jurisdictional scope.
- Identify whether personal data, health data, financial data, government data, critical infrastructure information, payment data, virtual-asset data or AI training data is processed.
- Confirm data residency, cross-border transfer, encryption, retention, deletion and audit-log requirements.
- Confirm whether UAE PASS, national identity, Arabic localization, accessibility, government design systems or sector-specific APIs are required.
- Confirm the architecture owner, security owner, product owner, data owner and incident-response owner.
- Confirm that threat modeling, privacy impact review, secure coding, dependency review, infrastructure hardening and logging are complete.
- Confirm rollback, backup, disaster recovery, business continuity, support escalation and evidence-retention procedures.
- Confirm that vendor, open-source and cloud-provider dependencies are documented and reviewed for lock-in, security, licensing and resilience.

#### 3. Technical design template
A strong design document for Cybersecurity governance and regulation in the UAE should include: purpose, scope, users, regulatory context, data flow, trust boundaries, identity model, integration points, deployment model, infrastructure region, availability model, monitoring plan, security controls, test plan, incident plan, cost assumptions, support model, and known risks. The document should explicitly state which claims are sourced, which assumptions require verification and which decisions are reversible.

#### 4. Engineering quality model
Quality should be measured across reliability, security, maintainability, usability, accessibility, performance, interoperability, privacy, compliance and operational cost. For software systems, include defect escape rate, test coverage, deployment frequency, lead time for change, change failure rate, mean time to restore, vulnerability age, dependency freshness and user-task success rate. For infrastructure, include uptime, latency, capacity, backup success, recovery-point objective, recovery-time objective, patch compliance and privileged-access review status.

#### 5. Security-by-design workflow
For every meaningful release, create a lightweight but complete security record: architecture diagram, data-flow diagram, trust boundaries, STRIDE or equivalent threat model, authentication and authorization design, secrets management design, input-validation approach, logging and monitoring plan, penetration-test scope, vulnerability remediation log and incident escalation contacts. In UAE contexts, this record should also identify whether DESC, TDRA, UAE Cybersecurity Council, CBUAE, VARA, DIFC, ADGM, healthcare or government procurement obligations apply.

#### 6. Common failure modes
The most common failure modes are treating data residency as an afterthought, assuming cloud-provider compliance automatically satisfies customer obligations, translating Arabic UI without RTL and cultural QA, buying cybersecurity tools without operating processes, deploying AI without data governance, relying on screenshots instead of audit evidence, building APIs without lifecycle ownership, and measuring technology success only by delivery date rather than resilience, adoption and security posture.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no system should collect data without a data owner, no API should be published without an authentication and versioning model, no AI model should be deployed without risk controls, no cloud workload should run without logging and backup, no vendor should operate without a defined SLA and exit plan, and no cybersecurity report should be accepted unless it identifies owners, deadlines and evidence for remediation.

## Domain 09: Application security and secure software development: OWASP, threat modeling, secure coding, SAST/DAST, dependency security, secrets, API security and DevSecOps

### Application Security and Secure Software Development: UAE Technical Reference

This document provides a comprehensive technical reference for application security (AppSec) and secure software development within the United Arab Emirates (UAE) context. It aligns global best practices (OWASP, NIST, ISO) with specific UAE regulatory requirements from the Dubai Electronic Security Center (DESC), the Telecommunications and Digital Government Regulatory Authority (TDRA), and the UAE Cybersecurity Council.

---

### 1. Domain Scope
**Technical Definition:** Application security encompasses the processes, tools, and practices aimed at protecting software applications from external and internal threats throughout their entire lifecycle. In the UAE, this domain is critical for the "Digital UAE" strategy, ensuring that government smart services and private sector platforms (FinTech, E-commerce) are resilient against cyber-attacks.

**UAE Relevance:**
*   **Smart Government:** Secure development is mandatory for all Dubai Government entities under the **Dubai Electronic Security Center (DESC) Information Security Regulation (ISR)**.
*   **Critical Infrastructure:** Entities regulated by the **Telecommunications and Digital Government Regulatory Authority (TDRA)** under the **NESA Information Assurance Standards (IAS)** must implement secure SDLC controls.
*   **Digital Economy:** With the rise of the UAE as a global tech hub, secure coding and API security are foundational for the UAE's AI and Blockchain strategies.

**Boundaries:** This shard focuses on the software layer (code, APIs, dependencies, and development pipelines). It excludes network-level firewalls or physical data center security, except where they interface directly with application delivery (e.g., WAFs, API Gateways).

---

### 2. UAE Legal, Regulatory, and Policy Context
The UAE has a robust regulatory framework governing how software must be developed and secured, particularly for government and regulated sectors.

*   **DESC Information Security Regulation (ISR) v3.1:**
    *   **Domain 10 (System Acquisition, Development, and Maintenance):** Mandatory for Dubai government entities. It requires formal security requirements analysis, secure development policies, and strict change control.
    *   > "Entities shall ensure that information security is an integral part of information systems across the entire lifecycle." — DESC ISR v3.1, [[8]](#ref8)
*   **NESA Information Assurance Standards (IAS) / UAE IAS:**
    *   **Technical Control T7 (Information Systems Acquisition, Development and Maintenance):** Contains 188 controls, including P1 (Priority 1) requirements for secure coding and vulnerability management.
    *   > "An information systems acquisition, development and maintenance process shall be implemented to prevent unauthorized modification or misuse of information in applications." — UAE IA Regulation v1.1, [[9]](#ref9)
*   **UAE Federal Decree-Law No. 45 of 2021 (Personal Data Protection Law):**
    *   Mandates **Privacy by Design** and **Privacy by Default**. Developers must integrate data protection controls (encryption, anonymization) into the application architecture from the outset.
*   **TDRA API First Guidelines (2021):**
    *   Provides a framework for UAE government entities to adopt an API-centric architecture, emphasizing standardized authentication (OAuth2/OIDC) and secure gateway implementation.
    *   > "Robust mechanisms must be in place to ensure that only authorised users can access sensitive data. Authentication and encryption: Use of..." — UAE Government API First Guidelines, [[10]](#ref10)
*   **CBUAE Consumer Protection Regulation:**
    *   Requires Licensed Financial Institutions (LFIs) to implement "appropriate security and monitoring measures" for mobile and web banking applications to prevent fraud.

---

### 3. Core Concepts and Theory
Practitioners in the UAE must master the following theoretical foundations:

*   **Secure Software Development Lifecycle (S-SDLC):** The integration of security activities (threat modeling, code review, testing) into every phase of the SDLC (Requirements -> Design -> Code -> Test -> Deploy).
*   **Threat Modeling (STRIDE):** A systematic approach to identifying threats: **S**poofing, **T**ampering, **R**epudiation, **I**nformation Disclosure, **D**enial of Service, and **E**levation of Privilege.
*   **OWASP Top 10:** The industry-standard list of the most critical web application security risks (e.g., Broken Access Control, Cryptographic Failures, Injection).
*   **Shift-Left Security:** The principle of moving security testing and consideration to the earliest possible stage in the development process to reduce cost and risk.
*   **Zero Trust Architecture (ZTA) for Apps:** Assuming no implicit trust; every API call and user session must be authenticated, authorized, and encrypted.

---

### 4. Architectures, Patterns, and Workflows
**DevSecOps Pipeline Integration:**
The modern UAE enterprise workflow integrates security tools directly into the CI/CD pipeline:
1.  **Pre-Commit:** IDE plugins for real-time secure coding guidance.
2.  **Commit (SAST):** Static Analysis Security Testing scans source code for vulnerabilities (e.g., hardcoded secrets, SQL injection).
3.  **Build (SCA):** Software Composition Analysis checks third-party libraries and dependencies for known CVEs (Common Vulnerabilities and Exposures).
4.  **Test (DAST/IAST):** Dynamic/Interactive Analysis tests the running application for runtime flaws.
5.  **Deploy:** Container scanning and Infrastructure as Code (IaC) scanning.

**API Security Architecture:**
*   **API Gateway:** Centralized enforcement point for rate limiting, authentication, and logging.
*   **Mutual TLS (mTLS):** Required for high-security inter-service communication in UAE banking and government sectors.
*   **OAuth 2.0 / OpenID Connect:** The standard for delegated authorization and identity in UAE smart services.

---

### 5. Standards, Frameworks, and Best Practices
*   **NIST Secure Software Development Framework (SSDF) SP 800-218:** A core reference for UAE entities to align with global federal standards.
*   **ISO/IEC 27034:** International standard for application security, providing a framework for "Application Security Components" (ASCs).
*   **OWASP Application Security Verification Standard (ASVS):** Used by UAE auditors to define technical security requirements for designing, building, and testing applications.
*   **DESC Cloud Service Provider (CSP) Security Standard:**
    *   Mandatory for CSPs serving Dubai Government.
    *   > "This CSP Security Standard contains mandatory requirements and controls for information security of Cloud Service Providers (CSPs) DEVELOPMENT, AND MAINTENANCE." — DESC CSP Standard, [[11]](#ref11)).pdf

---

### 6. Technical Tactics and Implementation Details
**Secure Coding Tactics:**
*   **Input Validation:** Use "allow-lists" rather than "block-lists." Validate for type, length, format, and range.
*   **Parameterized Queries:** Mandatory to prevent SQL Injection. Never concatenate user input into SQL strings.
*   **Secrets Management:** Use centralized vaults (e.g., HashiCorp Vault, Azure Key Vault, AWS Secrets Manager). **Never** store API keys or DB credentials in source code or environment variables.
*   **Output Encoding:** Encode data before rendering in the browser to prevent Cross-Site Scripting (XSS).

**API Security Controls:**
*   **Rate Limiting:** Prevent DoS attacks by limiting requests per API key/IP.
*   **JWT Security:** Ensure JSON Web Tokens are signed (RS256) and have short expiration times. Validate the `iss` (issuer) and `aud` (audience) claims.

---

### 7. Measurement, KPIs, and Operational Metrics
UAE organizations track the following to measure AppSec maturity:
*   **Vulnerability Density:** Number of vulnerabilities per 1,000 lines of code (KLOC).
*   **Mean Time to Remediate (MTTR):** Average time taken to fix a security flaw after discovery (Critical < 24h, High < 7 days per UAE best practices).
*   **Build Failure Rate:** Percentage of CI/CD builds halted due to security policy violations (e.g., high-severity CVEs in dependencies).
*   **Flaw Sourcing:** Ratio of vulnerabilities found in internal code vs. third-party libraries.
*   **NESA Compliance Score:** Percentage of T7 controls fully implemented and evidenced.

---

### 8. UAE Sector Use Cases and Localization Notes
*   **Banking & FinTech:** Strict adherence to CBUAE and PCI DSS. Implementation of "3D Secure" for all transactions is now a mandatory requirement by 2026.
*   **Government (Digital Dubai):** Applications must integrate with **UAE PASS** for identity and follow the **Smart Service Delivery Excellence Model**.
*   **Healthcare:** Secure handling of patient data in compliance with UAE Health Data Law (Federal Law No. 2 of 2019).
*   **Arabic Localization:** Security controls must account for Right-to-Left (RTL) text processing, ensuring that input validation and encoding do not break Arabic character sets or introduce buffer overflows.

---

### 9. Professional Practice and Checklists
**Senior Practitioner Checklist for Architecture Review:**
*   [ ] Is there a documented Threat Model for the application?
*   [ ] Are all external inputs validated and sanitized?
*   [ ] Is sensitive data encrypted at rest and in transit (TLS 1.3)?
*   [ ] Are secrets managed via a secure vault, not in code?
*   [ ] Does the CI/CD pipeline include SAST, SCA, and DAST?
*   [ ] Is UAE PASS integrated for user authentication (if government-facing)?
*   [ ] Are API endpoints protected by a Gateway with rate limiting?

---

### 10. Sources
**Primary Sources:**
1.  **DESC ISR v3.1:** Dubai Electronic Security Center, [[8]](#ref8)
2.  **UAE Information Assurance Regulation v1.1:** TDRA, [[9]](#ref9)
3.  **DESC CSP Security Standard:** Digital Dubai, [[11]](#ref11)).pdf
4.  **UAE Government API First Guidelines:** TDRA / U.ae, [[10]](#ref10)
5.  **CBUAE Consumer Protection Regulation:** Central Bank of the UAE, [[12]](#ref12)

**Secondary Sources:**
1.  **OWASP Top 10 / ASVS:** OWASP Foundation, [[13]](#ref13)
2.  **NIST SSDF (SP 800-218):** NIST, [[14]](#ref14)
3.  **UAE Cybersecurity Compliance Guides:** ITSEC / ValueMentor, [[15]](#ref15)

---

### 11. Gaps and Verification Notes
*   **[Verify]** The specific version of the DESC Web Security Policy is often updated; practitioners should check the DESC portal for the latest "Web Security Policy" document which provides granular coding requirements.
*   **[Not Found]** A single, unified "UAE Secure Coding Standard" document from the Cybersecurity Council was not identified; instead, entities rely on a combination of DESC ISR, NESA IAS, and global standards like OWASP.
*   **[Live Data]** Compliance deadlines for CBUAE's new authentication rules are set for March 2026; implementation status across all LFIs is currently in progress.

---
**Checklist Status:** All items in `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4687217d/RESEARCH_CHECKLIST.md` are marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4687217d/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4687217d/TOOL_RESULTS.md`
- Research child tool results lines: `2484`
- Research child tool results bytes: `116135`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4687217d/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Application security and secure software development

#### 1. Architecture and scope questions
A senior UAE technology practitioner should begin every engagement by documenting the operating context before selecting tools. The working file should answer: which business or public-service outcome is being protected or improved, which data classifications are involved, which emirate or regulator matters, whether the system is federal, local-government, free-zone, private-sector or cross-border, which users require Arabic/English experience, which security controls are mandatory, and which operational owner will maintain the system after launch.

#### 2. UAE compliance and risk checklist
Use this checklist before approving any technology design, software release, cloud migration, AI deployment, data platform, cybersecurity control or outsourced IT service:

- Confirm the legal entity, regulator, sector, data classification and jurisdictional scope.
- Identify whether personal data, health data, financial data, government data, critical infrastructure information, payment data, virtual-asset data or AI training data is processed.
- Confirm data residency, cross-border transfer, encryption, retention, deletion and audit-log requirements.
- Confirm whether UAE PASS, national identity, Arabic localization, accessibility, government design systems or sector-specific APIs are required.
- Confirm the architecture owner, security owner, product owner, data owner and incident-response owner.
- Confirm that threat modeling, privacy impact review, secure coding, dependency review, infrastructure hardening and logging are complete.
- Confirm rollback, backup, disaster recovery, business continuity, support escalation and evidence-retention procedures.
- Confirm that vendor, open-source and cloud-provider dependencies are documented and reviewed for lock-in, security, licensing and resilience.

#### 3. Technical design template
A strong design document for Application security and secure software development should include: purpose, scope, users, regulatory context, data flow, trust boundaries, identity model, integration points, deployment model, infrastructure region, availability model, monitoring plan, security controls, test plan, incident plan, cost assumptions, support model, and known risks. The document should explicitly state which claims are sourced, which assumptions require verification and which decisions are reversible.

#### 4. Engineering quality model
Quality should be measured across reliability, security, maintainability, usability, accessibility, performance, interoperability, privacy, compliance and operational cost. For software systems, include defect escape rate, test coverage, deployment frequency, lead time for change, change failure rate, mean time to restore, vulnerability age, dependency freshness and user-task success rate. For infrastructure, include uptime, latency, capacity, backup success, recovery-point objective, recovery-time objective, patch compliance and privileged-access review status.

#### 5. Security-by-design workflow
For every meaningful release, create a lightweight but complete security record: architecture diagram, data-flow diagram, trust boundaries, STRIDE or equivalent threat model, authentication and authorization design, secrets management design, input-validation approach, logging and monitoring plan, penetration-test scope, vulnerability remediation log and incident escalation contacts. In UAE contexts, this record should also identify whether DESC, TDRA, UAE Cybersecurity Council, CBUAE, VARA, DIFC, ADGM, healthcare or government procurement obligations apply.

#### 6. Common failure modes
The most common failure modes are treating data residency as an afterthought, assuming cloud-provider compliance automatically satisfies customer obligations, translating Arabic UI without RTL and cultural QA, buying cybersecurity tools without operating processes, deploying AI without data governance, relying on screenshots instead of audit evidence, building APIs without lifecycle ownership, and measuring technology success only by delivery date rather than resilience, adoption and security posture.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no system should collect data without a data owner, no API should be published without an authentication and versioning model, no AI model should be deployed without risk controls, no cloud workload should run without logging and backup, no vendor should operate without a defined SLA and exit plan, and no cybersecurity report should be accepted unless it identifies owners, deadlines and evidence for remediation.

## Domain 10: Network security and infrastructure security: firewalls, zero trust, IAM, VPN, Wi-Fi, segmentation, SOC operations, SIEM, endpoint security and incident response

This research report provides a comprehensive overview of network and infrastructure security within the UAE as of July 2026, focusing on regulatory compliance, technical architectures, and operational standards.

### 1. Domain Scope
Network and infrastructure security in the UAE covers the protection of Critical Information Infrastructure (CII), government digital assets, and private sector networks. The domain has shifted from "capacity building" to "active defense" under the **National Cyber Security Strategy (2025-2031)**.
- **Core Components**: Firewalls, Zero Trust Architecture (ZTA), Identity and Access Management (IAM), VPNs, Wi-Fi security, network segmentation, and Security Operations Center (SOC) operations (SIEM, endpoint security, and incident response).
- **UAE Relevance**: High priority due to rapid AI adoption, smart city integration, and the "We the UAE 2031" vision, which expands the digital attack surface.

### 2. UAE Legal, Regulatory, and Policy Context
The UAE's cybersecurity landscape is governed by a tiered regulatory structure:
- **National Cyber Security Strategy (2025-2031)**: Structured around five pillars: Governance, Resilient Digital Environment, Innovation, National Capabilities, and International Collaboration. It introduces the **National Cyber Accreditation Programme (NCAP)** in 2026, restricting unaccredited service providers from working with CII.
  - *Source*: Chambers Global Practice Guides, [[[1]](#ref1)]([[1]](#ref1))
- **UAE Information Assurance (IA) Standard v2.0**: Released in 2025, it aligns with ISO/IEC 27001:2022 and NIST SP 800-53 Rev. 5. It features 6 Management Controls (M1–M6) and 9 Technical Controls (T1–T9), specifically addressing AI, IoT, and cloud security.
  - *Source*: LinkedIn - Hadi Anwar (CPX), [[[16]](#ref16)]([[16]](#ref16))
- **Dubai Electronic Security Center (DESC) ISR v3.1**: The mandatory framework for Dubai government and semi-government entities, focusing on risk-based technical controls and data sovereignty.
  - *Source*: DESC Official Portal, [[[8]](#ref8)]([[8]](#ref8))
- **CBUAE Cybersecurity Framework**: Requires material incidents to be reported within **24 hours**.
  - *Source*: ITSEC, [[[17]](#ref17)]([[17]](#ref17))
- **Data Residency**: Federal Decree-Law No. 45 of 2021 (PDPL) and sector-specific rules (CBUAE, ADHICS) mandate that sensitive data must be stored and processed within UAE borders.
  - *Source*: iConnect IT, [[[18]](#ref18)]([[18]](#ref18))

### 3. Core Concepts and Theory
- **Zero Trust Architecture (ZTA)**: Implemented via the "Never Trust, Always Verify" principle. UAE government guidelines emphasize Identity, Device, Network, and Data as the four technical pillars.
- **Network Segmentation**: Critical for OT/IT convergence. DESC standards require strict isolation of Industrial Control Systems (ICS) from corporate IT networks to prevent lateral movement.
- **IAM (Identity and Access Management)**: Centered on Role-Based Access Control (RBAC) and the Principle of Least Privilege (PoLP).

### 4. Architectures, Patterns, and Workflows
- **SOC/SIEM Operations**: The UAE Cybersecurity Council promotes locally hosted SIEM platforms (e.g., on G42 or country cloud) to ensure data sovereignty and operational proximity.
  - *Source*: Siemens News, [[[19]](#ref19)]([[19]](#ref19))
- **VPN and Remote Work**: VPNs are legal for legitimate business use but must comply with TDRA guidelines. Secure remote work is a national policy mandate as of October 2025.
- **Wi-Fi Security**: TDRA regulates wireless equipment through Type Approval. WPA3 is the recommended standard for government and critical sectors.

### 5. Standards, Frameworks, and Best Practices
- **NIST SP 800-207**: The primary reference for Zero Trust implementations in the UAE.
- **ISO/IEC 27035**: The standard followed by **aeCERT** for national incident management.
- **CIS Controls**: Used as a baseline for technical hardening of endpoints and network infrastructure.

### 6. Technical Tactics and Implementation Details
- **Firewall Configuration**: DESC ISR mandates stateful inspection, application-layer filtering, and quarterly rule-base audits.
- **Endpoint Security**: Deployment of EDR/XDR is required for CII to counter autonomous AI-driven attacks.
- **Encryption**: National policies mandate AES-256 for data at rest and in transit. The UAE is also funding **Post-Quantum Cryptography (PQC)** research to mitigate future decryption threats.
  - *Source*: Chambers Global Practice Guides, [[[1]](#ref1)]([[1]](#ref1))

### 7. Measurement, KPIs, and Operational Metrics
- **Mean Time to Detect (MTTD)** and **Mean Time to Respond (MTTR)**: Primary KPIs for UAE SOCs.
- **Incident Containment Rate (ICR)**: A target of **>90%** is the benchmark for high-performing security teams.
  - *Source*: UnderDefense, [[[20]](#ref20)]([[20]](#ref20))
- **Compliance Automation**: Measured by the percentage of technical sub-controls implemented under the UAE IA Standard.

### 8. UAE Sector Use Cases and Localization Notes
- **Finance**: CBUAE mandates annual 3rd-party penetration testing and 24-hour incident reporting for material breaches.
- **Healthcare (ADHICS)**: Requires unique identifiers, complex passwords, and MFA for all privileged accounts.
- **Energy**: Focuses on IT/OT segmentation and protecting against regional threat actors targeting ICS.

### 9. Professional Practice and Checklists
**Senior Practitioner Audit Checklist**:
- [ ] **Data Residency**: Verify that all sensitive logs and backups are stored within the UAE.
- [ ] **Accreditation**: Confirm managed security service providers (MSSP) hold UAE NCAP accreditation.
- [ ] **Reporting**: Validate that the 24-hour reporting workflow for CBUAE/DESC is documented and tested.
- [ ] **Segmentation**: Audit firewall rules for "Any-Any" allow statements between IT and OT zones.

### 10. Sources
- **Chambers Global Practice Guides**: [[[1]](#ref1)]([[1]](#ref1))
- **DESC Standards & Policies**: [[[8]](#ref8)]([[8]](#ref8))
- **UAE Cybersecurity Council / CPX**: [[[16]](#ref16)]([[16]](#ref16))
- **CBUAE Rulebook**: [[[2]](#ref2)]([[2]](#ref2))
- **aeCERT (TDRA)**: [[[21]](#ref21)]([[21]](#ref21))

### 11. Gaps and Verification Notes
- **Gaps**: Technical configuration details for the "Cyber Crystal Ball" AI threat intelligence platform are restricted to authorized government entities.
- **Verification**: The exact enforcement dates for NCAP accreditation in late 2026 should be verified via the UAE Cybersecurity Council's official announcements.

**Checklist Status**: All items completed and marked `[Y]` in `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/486434bd/RESEARCH_CHECKLIST.md`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/486434bd/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/486434bd/TOOL_RESULTS.md`
- Research child tool results lines: `2151`
- Research child tool results bytes: `109477`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/486434bd/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Network security and infrastructure security

#### 1. Architecture and scope questions
A senior UAE technology practitioner should begin every engagement by documenting the operating context before selecting tools. The working file should answer: which business or public-service outcome is being protected or improved, which data classifications are involved, which emirate or regulator matters, whether the system is federal, local-government, free-zone, private-sector or cross-border, which users require Arabic/English experience, which security controls are mandatory, and which operational owner will maintain the system after launch.

#### 2. UAE compliance and risk checklist
Use this checklist before approving any technology design, software release, cloud migration, AI deployment, data platform, cybersecurity control or outsourced IT service:

- Confirm the legal entity, regulator, sector, data classification and jurisdictional scope.
- Identify whether personal data, health data, financial data, government data, critical infrastructure information, payment data, virtual-asset data or AI training data is processed.
- Confirm data residency, cross-border transfer, encryption, retention, deletion and audit-log requirements.
- Confirm whether UAE PASS, national identity, Arabic localization, accessibility, government design systems or sector-specific APIs are required.
- Confirm the architecture owner, security owner, product owner, data owner and incident-response owner.
- Confirm that threat modeling, privacy impact review, secure coding, dependency review, infrastructure hardening and logging are complete.
- Confirm rollback, backup, disaster recovery, business continuity, support escalation and evidence-retention procedures.
- Confirm that vendor, open-source and cloud-provider dependencies are documented and reviewed for lock-in, security, licensing and resilience.

#### 3. Technical design template
A strong design document for Network security and infrastructure security should include: purpose, scope, users, regulatory context, data flow, trust boundaries, identity model, integration points, deployment model, infrastructure region, availability model, monitoring plan, security controls, test plan, incident plan, cost assumptions, support model, and known risks. The document should explicitly state which claims are sourced, which assumptions require verification and which decisions are reversible.

#### 4. Engineering quality model
Quality should be measured across reliability, security, maintainability, usability, accessibility, performance, interoperability, privacy, compliance and operational cost. For software systems, include defect escape rate, test coverage, deployment frequency, lead time for change, change failure rate, mean time to restore, vulnerability age, dependency freshness and user-task success rate. For infrastructure, include uptime, latency, capacity, backup success, recovery-point objective, recovery-time objective, patch compliance and privileged-access review status.

#### 5. Security-by-design workflow
For every meaningful release, create a lightweight but complete security record: architecture diagram, data-flow diagram, trust boundaries, STRIDE or equivalent threat model, authentication and authorization design, secrets management design, input-validation approach, logging and monitoring plan, penetration-test scope, vulnerability remediation log and incident escalation contacts. In UAE contexts, this record should also identify whether DESC, TDRA, UAE Cybersecurity Council, CBUAE, VARA, DIFC, ADGM, healthcare or government procurement obligations apply.

#### 6. Common failure modes
The most common failure modes are treating data residency as an afterthought, assuming cloud-provider compliance automatically satisfies customer obligations, translating Arabic UI without RTL and cultural QA, buying cybersecurity tools without operating processes, deploying AI without data governance, relying on screenshots instead of audit evidence, building APIs without lifecycle ownership, and measuring technology success only by delivery date rather than resilience, adoption and security posture.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no system should collect data without a data owner, no API should be published without an authentication and versioning model, no AI model should be deployed without risk controls, no cloud workload should run without logging and backup, no vendor should operate without a defined SLA and exit plan, and no cybersecurity report should be accepted unless it identifies owners, deadlines and evidence for remediation.

## Domain 11: Cloud security and identity security: shared responsibility, IAM, CSPM, container security, Kubernetes hardening, logging, encryption, key management and UAE residency issues

### Cloud and Identity Security: UAE Technical Reference (July 2026)

This document provides a comprehensive technical reference for cloud security and identity security within the United Arab Emirates (UAE) context. It covers regulatory requirements, technical implementations, and professional best practices as of July 2026.

## 1. Domain Scope
Cloud security in the UAE encompasses the protection of data, applications, and infrastructure hosted in cloud environments (Public, Private, Hybrid, and Sovereign). Identity security focuses on ensuring that only authorized entities (human or machine) can access these resources.

### UAE Relevance and Use Cases
*   **Government Digital Transformation:** Mandatory migration of government services to DESC-certified cloud providers (Dubai) or sovereign cloud infrastructures (Abu Dhabi/Federal).
*   **Critical Infrastructure:** Protection of energy, water, and transportation sectors using cloud-native security controls.
*   **Financial Services:** Compliance with Central Bank of the UAE (CBUAE) and VARA (Virtual Assets Regulatory Authority) cloud outsourcing regulations.
*   **Sovereign Cloud:** High-security workloads requiring data residency and local operational control, often delivered through partnerships like G42 with Microsoft and Oracle.

## 2. UAE Legal, Regulatory, and Policy Context

### Key Regulators and Policies
*   **Dubai Electronic Security Center (DESC):** Issues the **Cloud Service Provider (CSP) Security Standard**, which is mandatory for all CSPs serving Dubai government and semi-government entities.
    *   > "Compliance with this standard is mandatory for all CSPs wishing to offer cloud services to Dubai government and semi-government entities." — Microsoft Learn, [[22]](#ref22)
*   **Telecommunications and Digital Government Regulatory Authority (TDRA):** Oversees the **National Cloud Security Policy** and the **UAE Information Assurance (IA) Regulation**.
*   **UAE Cybersecurity Council:** Recently approved the **National Encryption Policy (2025)**, mandating a transition to Post-Quantum Cryptography (PQC).
    *   > "The executive regulation calls on government to develop ‘clear, well-defined, and officially approved transition plans from traditional encryption methods to post-quantum cryptography.’" — PQShield, [[23]](#ref23)
*   **UAE Data Office:** Enforces **Federal Decree-Law No. 45 of 2021 (Personal Data Protection Law - PDPL)**, which governs data residency and cross-border transfers.

### Data Residency and Sovereignty
*   **Data Residency:** Refers to the physical location of data. UAE law often requires sensitive government and personal data to remain within UAE borders.
*   **Data Sovereignty:** The legal authority over data. The UAE increasingly requires "Sovereign Cloud" models where the infrastructure is managed by local entities (e.g., G42) to ensure UAE law takes precedence over foreign jurisdictions.
*   **Data Classification:** UAE government data is classified into four levels: **Open, Confidential, Sensitive, and Secret**. "Secret" data typically requires storage on isolated, locally-hosted servers with the highest encryption standards.

## 3. Core Concepts and Theory

### Shared Responsibility Model
The division of security tasks between the CSP and the customer depends on the service model:
*   **IaaS (Infrastructure as a Service):** Customer manages OS, middleware, runtime, data, and applications. CSP manages virtualization, servers, storage, and networking.
*   **PaaS (Platform as a Service):** Customer manages data and applications. CSP manages the underlying platform.
*   **SaaS (Software as a Service):** Customer manages only data and access. CSP manages the entire stack.
*   > "The workload responsibilities vary depending on whether the workload is hosted on SaaS, PaaS, IaaS, or in an on-premises datacenter." — Microsoft Azure, [[24]](#ref24)

### Identity and Access Management (IAM)
*   **Authentication (AuthN):** Verifying who a user is (e.g., MFA, Biometrics).
*   **Authorization (AuthZ):** Determining what a user can do (e.g., RBAC, ABAC).
*   **Privileged Access Management (PAM):** Specialized controls for administrative accounts, a high-priority requirement in DESC and NESA frameworks.

## 4. Architectures, Patterns, and Workflows

### Sovereign Cloud Architecture (UAE Model)
A common pattern in the UAE involves global CSPs (Microsoft, Oracle, AWS) partnering with local entities (G42, Khazna) to provide sovereign regions.
*   **Local Control Plane:** Operational management by UAE nationals or local entities.
*   **Disconnected/Air-gapped Options:** For "Secret" classified data.
*   **Example:** G42 and Microsoft's joint sovereign cloud offering provides Azure services compliant with local privacy and regulatory requirements.

### Cloud Security Posture Management (CSPM) Workflow
1.  **Discovery:** Automated scanning of cloud assets across subscriptions.
2.  **Visibility:** Mapping assets to UAE-specific compliance frameworks (DESC, NESA).
3.  **Remediation:** Automated or manual fixing of misconfigurations (e.g., open S3 buckets, disabled logging).
4.  **Continuous Monitoring:** Real-time alerts for drift from the secure baseline.

## 5. Standards, Frameworks, and Best Practices

### Global Standards Applied in UAE
*   **ISO/IEC 27001 & 27017:** The foundation for the DESC CSP Standard.
*   **Cloud Security Alliance (CSA) Cloud Controls Matrix (CCM):** Explicitly referenced in DESC requirements.
*   **NIST SP 800-190:** Application Container Security Guide.
*   **CIS Benchmarks:** Used for hardening Kubernetes and cloud configurations.

### Secure SDLC for Cloud-Native Apps
*   **Shift Left:** Integrating security (SAST/DAST) into the CI/CD pipeline.
*   **Infrastructure as Code (IaC) Scanning:** Checking Terraform or CloudFormation templates for security flaws before deployment.

## 6. Technical Tactics and Implementation Details

### Kubernetes Hardening (UAE Context)
*   **Least Privilege:** Running pods with non-root users and restricted SecurityContext.
*   **Network Policies:** Implementing zero-trust networking between microservices.
*   **Admission Controllers:** Using OPA (Open Policy Agent) or Kyverno to enforce UAE-specific compliance rules (e.g., "all images must come from a local registry").
*   > "Primary actions include the scanning of containers and Pods for vulnerabilities or misconfigurations, running containers and Pods with the least privileges possible." — NSA/CISA, [[25]](#ref25)

### Encryption and Key Management
*   **National Encryption Policy (2025):** Mandates **Crypto Agility**.
    *   **Requirement:** Systems must be able to rotate keys and switch algorithms (e.g., to PQC) without downtime.
    *   **Requirement:** Automated inventory of all cryptographic assets.
*   **BYOK (Bring Your Own Key):** Preferred by UAE entities to maintain control over data even when stored in public clouds.

### Logging and Retention
*   **DESC/ISR Requirements:** Security logs must be protected from unauthorized modification.
*   **Retention:** While specific periods vary by sector, a common baseline is **12 months** for audit logs, with at least **3 months** immediately available for analysis.

## 7. Measurement, KPIs, and Operational Metrics

| Metric | Description | UAE Target/Benchmark |
| :--- | :--- | :--- |
| **Mean Time to Remediate (MTTR)** | Time taken to fix a cloud misconfiguration. | < 24 hours for Critical/High. |
| **Vulnerability Patching Rate** | Percentage of assets patched within the SLA. | > 95% within 30 days. |
| **Identity Risk Score** | Aggregate score of MFA adoption and privileged account drift. | Aim for < 10% high-risk accounts. |
| **Compliance Score** | Percentage of controls passing DESC/NESA audits. | 100% for mandatory controls. |

## 8. UAE Sector Use Cases and Localization Notes

*   **Healthcare:** Patient data must reside in the UAE. Use of "Health Cloud" with strict IAM to prevent unauthorized access by non-UAE entities.
*   **Finance:** CBUAE requires banks to have a "Right to Audit" clause in cloud contracts and a clear exit strategy.
*   **Smart Cities (Dubai/Abu Dhabi):** IoT devices in smart grids use cloud-based identity (Machine Identities) to authenticate to central management platforms.

## 9. Professional Practice and Checklists

### Cloud Security Audit Checklist
*   [ ] Is the CSP DESC-certified (for Dubai Gov)?
*   [ ] Is MFA enforced for 100% of administrative and user accounts?
*   [ ] Are encryption keys managed in a UAE-hosted HSM or KMS?
*   [ ] Is there an automated CSPM tool monitoring for configuration drift?
*   [ ] Does the incident response plan include cloud-specific scenarios (e.g., account takeover)?
*   [ ] Is data classified and stored in the appropriate cloud tier (Public vs. Sovereign)?

## 10. Sources

### Primary Sources
*   **Dubai Electronic Security Center (DESC):** CSP Security Standard, [[26]](#ref26)
*   **Digital Dubai:** CSP Security Standard (Updated Jan 2020), [[11]](#ref11)).pdf
*   **TDRA:** UAE Information Assurance Regulation v1.1, [[9]](#ref9)
*   **UAE Government Portal:** Data Protection Laws, [[27]](#ref27)

### Secondary/Vendor Sources
*   **Microsoft Learn:** UAE DESC Compliance, [[22]](#ref22)
*   **Oracle Cloud:** DESC Certification Announcement, [[28]](#ref28)
*   **PQShield:** UAE National Encryption Policy Analysis, [[23]](#ref23)
*   **NSA/CISA:** Kubernetes Hardening Guidance, [[25]](#ref25)

## 11. Gaps and Verification Notes
*   **Specific Logging Retention:** While general best practices suggest 12 months, the exact mandatory retention period for *all* UAE sectors under the 2026 updated policies should be verified per specific sector regulator (e.g., CBUAE vs. DHA).
*   **PQC Implementation Timelines:** The National Encryption Policy is in the "transition plan" phase; specific deadlines for full migration of legacy systems are still being finalized by the Cybersecurity Council.
*   **PDPL Executive Regulations:** While the law is active, specific cross-border transfer "adequacy" lists for 2026 should be checked with the UAE Data Office.

---
**Checklist Status:**
*   Checklist Path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/631f0209/RESEARCH_CHECKLIST.md`
*   All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/631f0209/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/631f0209/TOOL_RESULTS.md`
- Research child tool results lines: `1654`
- Research child tool results bytes: `94371`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/631f0209/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Cloud security and identity security

#### 1. Architecture and scope questions
A senior UAE technology practitioner should begin every engagement by documenting the operating context before selecting tools. The working file should answer: which business or public-service outcome is being protected or improved, which data classifications are involved, which emirate or regulator matters, whether the system is federal, local-government, free-zone, private-sector or cross-border, which users require Arabic/English experience, which security controls are mandatory, and which operational owner will maintain the system after launch.

#### 2. UAE compliance and risk checklist
Use this checklist before approving any technology design, software release, cloud migration, AI deployment, data platform, cybersecurity control or outsourced IT service:

- Confirm the legal entity, regulator, sector, data classification and jurisdictional scope.
- Identify whether personal data, health data, financial data, government data, critical infrastructure information, payment data, virtual-asset data or AI training data is processed.
- Confirm data residency, cross-border transfer, encryption, retention, deletion and audit-log requirements.
- Confirm whether UAE PASS, national identity, Arabic localization, accessibility, government design systems or sector-specific APIs are required.
- Confirm the architecture owner, security owner, product owner, data owner and incident-response owner.
- Confirm that threat modeling, privacy impact review, secure coding, dependency review, infrastructure hardening and logging are complete.
- Confirm rollback, backup, disaster recovery, business continuity, support escalation and evidence-retention procedures.
- Confirm that vendor, open-source and cloud-provider dependencies are documented and reviewed for lock-in, security, licensing and resilience.

#### 3. Technical design template
A strong design document for Cloud security and identity security should include: purpose, scope, users, regulatory context, data flow, trust boundaries, identity model, integration points, deployment model, infrastructure region, availability model, monitoring plan, security controls, test plan, incident plan, cost assumptions, support model, and known risks. The document should explicitly state which claims are sourced, which assumptions require verification and which decisions are reversible.

#### 4. Engineering quality model
Quality should be measured across reliability, security, maintainability, usability, accessibility, performance, interoperability, privacy, compliance and operational cost. For software systems, include defect escape rate, test coverage, deployment frequency, lead time for change, change failure rate, mean time to restore, vulnerability age, dependency freshness and user-task success rate. For infrastructure, include uptime, latency, capacity, backup success, recovery-point objective, recovery-time objective, patch compliance and privileged-access review status.

#### 5. Security-by-design workflow
For every meaningful release, create a lightweight but complete security record: architecture diagram, data-flow diagram, trust boundaries, STRIDE or equivalent threat model, authentication and authorization design, secrets management design, input-validation approach, logging and monitoring plan, penetration-test scope, vulnerability remediation log and incident escalation contacts. In UAE contexts, this record should also identify whether DESC, TDRA, UAE Cybersecurity Council, CBUAE, VARA, DIFC, ADGM, healthcare or government procurement obligations apply.

#### 6. Common failure modes
The most common failure modes are treating data residency as an afterthought, assuming cloud-provider compliance automatically satisfies customer obligations, translating Arabic UI without RTL and cultural QA, buying cybersecurity tools without operating processes, deploying AI without data governance, relying on screenshots instead of audit evidence, building APIs without lifecycle ownership, and measuring technology success only by delivery date rather than resilience, adoption and security posture.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no system should collect data without a data owner, no API should be published without an authentication and versioning model, no AI model should be deployed without risk controls, no cloud workload should run without logging and backup, no vendor should operate without a defined SLA and exit plan, and no cybersecurity report should be accepted unless it identifies owners, deadlines and evidence for remediation.


## Category Appendix: UAE Cybersecurity Control Architecture

### Control families
A practical control architecture includes governance, asset management, identity, network security, endpoint security, application security, cloud security, data protection, vulnerability management, monitoring, incident response, third-party security, awareness, resilience and assurance testing.

### Secure engineering review board
For high-risk systems, create a review board that checks architecture, threat model, authentication, authorization, secrets, dependencies, APIs, logging, data protection, cloud posture, penetration-test findings and operational handover. The board should approve risk acceptance only with an accountable business owner and expiry date.

### SOC-to-engineering feedback loop
SOC findings should feed engineering backlogs. Repeated alerts should become hardening tasks, detection tuning, code fixes, access review, network segmentation, playbook updates or user-awareness actions. A SOC that only reports alerts without engineering remediation will not improve risk posture.

## File-Level Verification Notes

- This file is based on source collector packets generated in July 2026.
- Do not treat vendor product availability, security benchmarks, certification status or regulatory timelines as permanent; verify current authority and vendor documentation before implementation.
- For regulated sectors such as finance, virtual assets, healthcare, education, government services, telecoms, energy and critical infrastructure, obtain current sector-specific guidance before launch or procurement.

## References

<p id="ref1" class="ref_item"><a target="_blank" rel="noreferrer" href="https://practiceguides.chambers.com/practice-guides/cybersecurity-2026/uae/trends-and-developments">[1] practiceguides.chambers.com</a></p>
<p id="ref2" class="ref_item"><a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/article-13-technology-risk-and-information-security">[2] rulebook.centralbank.ae</a></p>
<p id="ref3" class="ref_item"><a target="_blank" rel="noreferrer" href="https://complyan.com/how-dubais-isr-v3-0-is-shaping-smarter-security-standards-in-the-region/">[3] complyan.com</a></p>
<p id="ref4" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/adgm-cyber-risk-management-framework-2026-essential-1ccbc">[4] linkedin.com</a></p>
<p id="ref5" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/information-and-services/justice-safety-and-the-law/cyber-safety-and-digital-security">[5] u.ae</a></p>
<p id="ref6" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.dlapiperdataprotection.com/countries/uae-general/law.html">[6] dlapiperdataprotection.com</a></p>
<p id="ref7" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.v-comply.com/glossary/cybercrime-law-uae/">[7] v-comply.com</a></p>
<p id="ref8" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.desc.gov.ae/regulations/standards-policies/">[8] desc.gov.ae</a></p>
<p id="ref9" class="ref_item"><a target="_blank" rel="noreferrer" href="https://tdra.gov.ae/-/media/About/regulations-and-ruling/EN/UAE-Information-Assurance-Regulation-v1-1-pdf.ashx">[9] tdra.gov.ae</a></p>
<p id="ref10" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/digital-uae/regulatory-framework/api-first">[10] u.ae</a></p>
<p id="ref11" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.digitaldubai.ae/docs/default-source/digital-regulations/cyber/standard/csp-security-standard-(updated-jan-2020">[11] digitaldubai.ae</a></p>
<p id="ref12" class="ref_item"><a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/consumer-protection-regulation">[12] rulebook.centralbank.ae</a></p>
<p id="ref13" class="ref_item"><a target="_blank" rel="noreferrer" href="https://owasp.org/">[13] owasp.org</a></p>
<p id="ref14" class="ref_item"><a target="_blank" rel="noreferrer" href="https://csrc.nist.gov/projects/ssdf">[14] csrc.nist.gov</a></p>
<p id="ref15" class="ref_item"><a target="_blank" rel="noreferrer" href="https://itsecnow.com/regulators/desc-cybersecurity">[15] itsecnow.com</a></p>
<p id="ref16" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/from-policy-practice-decoding-uaes-new-cybersecurity-framework-khan-1uwzf">[16] linkedin.com</a></p>
<p id="ref17" class="ref_item"><a target="_blank" rel="noreferrer" href="https://itsecnow.com/regulators/cbuae-cybersecurity">[17] itsecnow.com</a></p>
<p id="ref18" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.iconnectitbs.com/data-residency-in-the-uae/">[18] iconnectitbs.com</a></p>
<p id="ref19" class="ref_item"><a target="_blank" rel="noreferrer" href="https://news.siemens.com/en-us/uae-cyber-security-council-and-siemens/">[19] news.siemens.com</a></p>
<p id="ref20" class="ref_item"><a target="_blank" rel="noreferrer" href="https://underdefense.com/blog/soc-metrics/">[20] underdefense.com</a></p>
<p id="ref21" class="ref_item"><a target="_blank" rel="noreferrer" href="https://tdra.gov.ae/en/aecert">[21] tdra.gov.ae</a></p>
<p id="ref22" class="ref_item"><a target="_blank" rel="noreferrer" href="https://learn.microsoft.com/en-us/azure/compliance/offerings/offering-uae-desc">[22] learn.microsoft.com</a></p>
<p id="ref23" class="ref_item"><a target="_blank" rel="noreferrer" href="https://pqshield.com/uae-establishes-requirements-for-cryptographic-controls-and-migration-planning/">[23] pqshield.com</a></p>
<p id="ref24" class="ref_item"><a target="_blank" rel="noreferrer" href="https://learn.microsoft.com/en-us/azure/security/fundamentals/shared-responsibility">[24] learn.microsoft.com</a></p>
<p id="ref25" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.nsa.gov/Press-Room/News-Highlights/Article/Article/2716980/nsa-cisa-release-kubernetes-hardening-guidance/">[25] nsa.gov</a></p>
<p id="ref26" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.desc.gov.ae/regulations/certifications/">[26] desc.gov.ae</a></p>
<p id="ref27" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws">[27] u.ae</a></p>
<p id="ref28" class="ref_item"><a target="_blank" rel="noreferrer" href="https://blogs.oracle.com/cloud-infrastructure/oracle-cloud-achieves-new-desc-csp-security-standard-certification">[28] blogs.oracle.com</a></p>
