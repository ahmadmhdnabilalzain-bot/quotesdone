# Web Development, Software Engineering, Product Engineering and SaaS in the UAE

**Purpose.** The software delivery layer: web applications, Arabic/English UX, secure full-stack development, SDLC, Agile, DevOps, QA, product engineering, SaaS, APIs, scalability and UAE commercial constraints. This file is part of a broader UAE technology knowledge library designed for engineers, CTOs, product leaders, cybersecurity teams, AI practitioners, IT managers, founders, consultants and students who need a source-backed operating reference.

**How to use this file.** Start with the domain chapters for source-backed UAE context, then use the practice appendices as implementation checklists. Treat regulation, product availability, cloud service availability, platform policy and security-control claims as verification-sensitive because they can change.

## Category Coverage

- **Domain 03:** Web development in the UAE: frontend, backend, full-stack, accessibility, multilingual Arabic/English UX, hosting, performance, security and compliance
- **Domain 04:** Software engineering practices: SDLC, Agile/Scrum, DevOps, CI/CD, testing, QA, documentation, code review, architecture and engineering management
- **Domain 15:** E-commerce, SaaS and product engineering: product management, UX, APIs, mobile apps, scalability, subscription systems, marketplaces and UAE commercial/legal constraints


## Domain 03: Web development in the UAE: frontend, backend, full-stack, accessibility, multilingual Arabic/English UX, hosting, performance, security and compliance

### Web Development in the UAE: Frontend, Backend, and Compliance

This research report covers the technical, regulatory, and localized aspects of web development within the United Arab Emirates as of July 2026. It focuses on the standards set by the Telecommunications and Digital Government Regulatory Authority (TDRA), the Dubai Electronic Security Center (DESC), and the UAE Data Office.

## Domain Scope
Web development in the UAE is characterized by a "Digital-First" strategy, where government services and private sector platforms are increasingly integrated into unified digital ecosystems. The domain encompasses:
*   **Frontend Development:** Implementation of the UAE Design System (DLS), focusing on responsive, accessible, and high-performance user interfaces.
*   **Backend & Infrastructure:** Secure server-side logic with a heavy emphasis on data residency and local cloud hosting (e.g., Moro Hub, G42, AWS me-central-1).
*   **Multilingual UX:** Native support for Right-to-Left (RTL) Arabic and Left-to-Right (LTR) English scripts, ensuring "script harmony."
*   **Compliance:** Adherence to the UAE Personal Data Protection Law (PDPL) and sector-specific security regulations like the DESC Information Security Regulation (ISR).

## UAE Legal, Regulatory, and Policy Context
The UAE has established a robust legal framework to govern digital activities and protect user data.

### 1. Personal Data Protection Law (PDPL)
**Federal Decree-Law No. 45 of 2021** is the primary legislation governing the processing of personal data in the UAE.
*   **Data Residency:** Articles 22 and 23 specify that personal data may only be transferred outside the UAE to jurisdictions with an "adequate level of protection" or under specific contractual safeguards approved by the UAE Data Office (Source: Trade.gov, [[1]](#ref1)).
*   **Consent:** Explicit consent is generally required for data processing, with rights for individuals to access, rectify, and delete their data (Source: DLA Piper, [[2]](#ref2)).

### 2. Dubai Electronic Security Center (DESC) ISR
The **Information Security Regulation (ISR) v2.0** (and subsequent updates) provides mandatory standards for Dubai government entities.
*   **Scope:** Covers 13 domains including Governance, Operation, and Assurance.
*   **Web Security Policy:** Specifically addresses application security, requiring entities to conduct risk assessments and implement "right-fit" controls (Source: DESC, [[3]](#ref3)).

### 3. TDRA Federal Government Standards
The **Telecommunications and Digital Government Regulatory Authority (TDRA)** mandates the use of the **UAE Design System** for all federal websites to ensure a unified digital experience (Source: TDRA, [[4]](#ref4)).

## Core Concepts and Theory
Practitioners in the UAE must master specific concepts related to regional requirements:
*   **Bi-directional (BiDi) Layouts:** Understanding the CSS `direction: rtl` and `logical properties` (e.g., `margin-inline-start`) to handle Arabic/English switching without duplicating styles.
*   **Sovereign Cloud:** The concept of hosting data within national borders to meet "Sovereign Cloud" requirements, often utilizing local providers like Moro Hub or G42 (Source: iQuasar, [[5]](#ref5)).
*   **Universal Design:** The theory that digital products should be usable by everyone, including "People of Determination" (the UAE term for persons with disabilities), without the need for adaptation.

## Architectures, Patterns, and Workflows
### UAE Design System (DLS) 2.0/3.0
The DLS provides a standardized React-based component library for federal entities.
*   **Workflow:** Developers are encouraged to use the official `@aegov/dls-react` package to maintain consistency in typography, color, and accessibility (Source: GitHub, [[6]](#ref6)).
*   **Pattern:** A "Mobile-First" and "Accessibility-First" approach is mandatory, with components pre-configured for ARIA compliance.

### Data Residency Architecture
Typical architectures involve:
*   **Local Database Hosting:** Sensitive PII (Personally Identifiable Information) must reside in UAE-based data centers.
*   **Hybrid Cloud:** Using global CDNs for static assets while keeping the application logic and database within the UAE AWS region (`me-central-1`) or local sovereign clouds.

## Standards, Frameworks, and Best Practices
### Accessibility Standards
*   **WCAG 2.1 Level AA:** Mandatory for all federal government websites (Source: UAE Design System, [[7]](#ref7)).
*   **Dubai Universal Design Code:** Mandates digital accessibility for all platforms serving the public in Dubai (Source: Deque, [[8]](#ref8)).

### Typography and Branding
*   **Dubai Font:** A bespoke typeface family designed in partnership with Microsoft, supporting both Latin and Arabic scripts simultaneously to ensure visual harmony (Source: Monotype, [[9]](#ref9)).
*   **Font Fallbacks:** The DLS specifies `Noto Kufi Arabic` as the primary fallback for RTL themes (Source: UAE Design System, [[10]](#ref10)).

## Technical Tactics and Implementation Details
### Multilingual Implementation
*   **Language Negotiation:** Using the `Accept-Language` header or URL subdirectories (e.g., `/ar/`, `/en/`) for SEO-friendly language routing.
*   **RTL Mirroring:** Automatically mirroring layouts using tools like `RTLCSS` or Tailwind CSS's native RTL support (`rtl:ml-0 rtl:mr-4`).

### Performance Optimization
*   **Font Loading:** The UAE Design System recommends loading fonts via Google Fonts for performance, but local hosting is preferred for high-security government sites to avoid external dependencies.
*   **Minimum Font Size:** A minimum of **16px** is recommended for body text to ensure readability across devices (Source: UAE Design System, [[10]](#ref10)).

## Measurement, KPIs, and Operational Metrics
Web projects in the UAE are measured against:
*   **Lighthouse Scores:** Target scores of 90+ for Accessibility and SEO are common benchmarks for government portals.
*   **Compliance Audit Pass Rate:** Percentage of DESC ISR or TDRA DLS requirements met during annual audits.
*   **Arabic/English Parity:** Ensuring 100% content and feature parity between the two language versions.

## UAE Sector Use Cases and Localization Notes
*   **Government:** Unified portals (e.g., DubaiNow, TAMM) requiring high-level integration with UAE PASS for authentication.
*   **Healthcare:** Strict data residency under the **Health Data Law**, requiring all patient data to remain in the UAE (Source: Baker McKenzie, [[11]](#ref11)).
*   **Finance:** Compliance with Central Bank of the UAE (CBUAE) and FSRA/DFSA regulations regarding "Open Finance" and data privacy (Source: CBUAE Rulebook, [[12]](#ref12)).

## Professional Practice and Checklists
### Senior Practitioner Checklist for UAE Web Projects:
1.  [ ] **Data Residency:** Is the database hosted in a UAE-based region (e.g., AWS `me-central-1`, Moro Hub)?
2.  [ ] **Authentication:** Is UAE PASS integrated for secure user identity verification?
3.  [ ] **Accessibility:** Does the site meet WCAG 2.1 Level AA? Have you tested with screen readers (VoiceOver/TalkBack) in both Arabic and English?
4.  [ ] **Typography:** Is the Dubai Font or the approved DLS font (Noto Kufi Arabic) implemented correctly?
5.  [ ] **Legal:** Is there a clear Privacy Policy compliant with Federal Decree-Law No. 45 of 2021?
6.  [ ] **RTL Support:** Are all layouts mirrored correctly? Are icons that imply direction (e.g., arrows) flipped?

## Sources
*   **TDRA UAE Design System Guidelines:** [[13]](#ref13)
*   **TDRA Accessibility Guidelines:** [[7]](#ref7)
*   **DESC Standards & Policies:** [[3]](#ref3)
*   **UAE Government Data Protection Laws:** [[14]](#ref14)
*   **Monotype Dubai Font Case Study:** [[9]](#ref9)
*   **Trade.gov UAE Data Flow Intelligence:** [[1]](#ref1)
*   **CBUAE Open Finance Regulation:** [[12]](#ref12)

## Gaps and Verification Notes
*   **Implementing Regulations for PDPL:** While the law was enacted in 2021, the full implementing regulations from the UAE Data Office are expected to provide more granular detail on cross-border transfer mechanisms in late 2024/2025; practitioners should monitor the UAE Data Office for updates.
*   **DESC ISR v3.0:** Some sources mention an ISR v3.0; however, official DESC documentation primarily references v2.0 and specific sub-standards (IoT, Web Security Policy). Verification of the latest version with DESC directly is recommended for Dubai-based projects.
*   **Sovereign Cloud Pricing:** Specific pricing and SLA details for Moro Hub and G42 are typically gated behind NDAs and procurement processes, making public benchmarking difficult.

---
**Checklist Status Summary:**
Checklist path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/014adfd5/RESEARCH_CHECKLIST.md`
All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/014adfd5/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/014adfd5/TOOL_RESULTS.md`
- Research child tool results lines: `1514`
- Research child tool results bytes: `79306`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/014adfd5/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Web development in the UAE

#### 1. Architecture and scope questions
A senior UAE technology practitioner should begin every engagement by documenting the operating context before selecting tools. The working file should answer: which business or public-service outcome is being protected or improved, which data classifications are involved, which emirate or regulator matters, whether the system is federal, local-government, free-zone, private-sector or cross-border, which users require Arabic/English experience, which security controls are mandatory, and which operational owner will maintain the system after launch.

#### 2. UAE compliance and risk checklist
Use this checklist before approving any technology design, software release, cloud migration, AI deployment, data platform, cybersecurity control or outsourced IT service:

- Confirm the legal entity, regulator, sector, data classification and jurisdictional scope.
- Identify whether personal data, health data, financial data, government data, critical infrastructure information, payment data, virtual-asset data or AI training data is processed.
- Confirm data residency, cross-border transfer, encryption, retention, deletion and audit-log requirements.
- Confirm whether UAE PASS, national identity, Arabic localization, accessibility, government design systems or sector-specific APIs are required.
- Confirm the architecture owner, security owner, product owner, data owner and incident-response owner.
- Confirm that threat modeling, privacy impact review, secure coding, dependency review, infrastructure hardening and logging are complete.
- Confirm rollback, backup, disaster recovery, business continuity, support escalation and evidence-retention procedures.
- Confirm that vendor, open-source and cloud-provider dependencies are documented and reviewed for lock-in, security, licensing and resilience.

#### 3. Technical design template
A strong design document for Web development in the UAE should include: purpose, scope, users, regulatory context, data flow, trust boundaries, identity model, integration points, deployment model, infrastructure region, availability model, monitoring plan, security controls, test plan, incident plan, cost assumptions, support model, and known risks. The document should explicitly state which claims are sourced, which assumptions require verification and which decisions are reversible.

#### 4. Engineering quality model
Quality should be measured across reliability, security, maintainability, usability, accessibility, performance, interoperability, privacy, compliance and operational cost. For software systems, include defect escape rate, test coverage, deployment frequency, lead time for change, change failure rate, mean time to restore, vulnerability age, dependency freshness and user-task success rate. For infrastructure, include uptime, latency, capacity, backup success, recovery-point objective, recovery-time objective, patch compliance and privileged-access review status.

#### 5. Security-by-design workflow
For every meaningful release, create a lightweight but complete security record: architecture diagram, data-flow diagram, trust boundaries, STRIDE or equivalent threat model, authentication and authorization design, secrets management design, input-validation approach, logging and monitoring plan, penetration-test scope, vulnerability remediation log and incident escalation contacts. In UAE contexts, this record should also identify whether DESC, TDRA, UAE Cybersecurity Council, CBUAE, VARA, DIFC, ADGM, healthcare or government procurement obligations apply.

#### 6. Common failure modes
The most common failure modes are treating data residency as an afterthought, assuming cloud-provider compliance automatically satisfies customer obligations, translating Arabic UI without RTL and cultural QA, buying cybersecurity tools without operating processes, deploying AI without data governance, relying on screenshots instead of audit evidence, building APIs without lifecycle ownership, and measuring technology success only by delivery date rather than resilience, adoption and security posture.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no system should collect data without a data owner, no API should be published without an authentication and versioning model, no AI model should be deployed without risk controls, no cloud workload should run without logging and backup, no vendor should operate without a defined SLA and exit plan, and no cybersecurity report should be accepted unless it identifies owners, deadlines and evidence for remediation.

## Domain 04: Software engineering practices: SDLC, Agile/Scrum, DevOps, CI/CD, testing, QA, documentation, code review, architecture and engineering management

### Collector Report: Software Engineering Practices in the UAE

This report provides a comprehensive overview of software engineering practices, standards, and regulatory requirements in the United Arab Emirates as of July 2026. It covers the Software Development Lifecycle (SDLC), Agile/Scrum methodologies, DevOps, CI/CD, testing, and engineering management within the UAE's digital transformation framework.

## 1. Domain Scope
The software engineering domain in the UAE is characterized by a rapid shift toward "Digital-First" and "Cloud-First" strategies, driven by national initiatives like **UAE Vision 2031** and **Centennial 2071**.
- **UAE Relevance**: Software engineering is the backbone of the UAE's smart city initiatives (e.g., Dubai Paperless Strategy) and digital government services.
- **Business/Government Use Cases**:
    - **Government**: End-to-end digital service delivery via the **UAE PASS** and **GSB (Government Service Bus)**.
    - **Finance**: Implementation of Open Banking and secure digital transaction processing under CBUAE regulations.
    - **Healthcare**: Secure operation of electronic biomedical devices (EBMD) and interoperable health records (NABIDH).
- **Boundaries**: The scope includes all phases of the SDLC, from requirement gathering to maintenance, with a heavy emphasis on **Secure SDLC (S-SDLC)** as mandated by the Dubai Electronic Security Center (DESC).

## 2. UAE Legal, Regulatory, and Policy Context
Software development in the UAE is governed by a robust framework of federal and local laws:
- **Federal Decree-Law No. 45 of 2021 (Personal Data Protection Law - PDPL)**: The first comprehensive federal data privacy law. It mandates "Privacy by Design" and "Privacy by Default" in software architecture.
    - *Requirement*: Organizations must implement technical and organizational measures to protect personal data. — *UAE Government Portal, [[15]](#ref15)
- **Dubai Information Security Regulation (ISR) v3.1**: Issued by DESC, this is the baseline for all Dubai government entities.
    - **Domain 10 (Secure Development)**: Specifically outlines controls for secure software development, including environment segregation, change management, and vulnerability testing. — *DESC, [[16]](#ref16)
- **TDRA Digital Government Service Standard**: A framework consisting of **50 criteria** to evaluate the quality of digital services, including end-to-end service delivery and proactive service initiation. — *TDRA, [[17]](#ref17)
- **CBUAE Consumer Protection Regulation (CPR)**: Mandates strong authentication (Multi-Factor Authentication) for financial software.
    - *Verbatim*: "To combat weak authentication methods, the notice prohibits FIs from using SMS OTP, email OTP, or static passwords as the sole authentication method for financial transactions." — *OneSpan (CBUAE Notice), [[18]](#ref18)

## 3. Core Concepts and Theory
- **Agile DevOps Reference Model (ADRM)**: A framework used in the UAE to align strategic agility with operational execution, consisting of four layers: Values, Principles, Dimensions, and Practices. — *MDPI Study, [[19]](#ref19)
- **Dynamic Capabilities Framework (DCF)**: Applied by UAE organizations to "Sense, Seize, and Transform" their software engineering competencies in response to rapid technological shifts.
- **Microservices Architecture**: Increasingly adopted in the UAE to enhance scalability and resilience, particularly in large-scale government platforms.

## 4. Architectures, Patterns, and Workflows
- **Target Operating Model (TOM)**: Used by entities like **Digital Dubai** to transition from legacy systems to Agile-based delivery models.
- **UAE Design System 2.0 (DLS 2.0)**: A standardized set of UI components, blocks, and patterns for federal government websites to ensure consistency and accessibility (WCAG 2.2).
    - *Technical Detail*: DLS 2.0 uses a modular approach, allowing components to function correctly in isolation or integrated into larger interfaces. — *UAE Design System, [[20]](#ref20)
- **API-First Strategy**: Mandated for government interoperability via the **GSB**, ensuring that data is shared efficiently between entities.

## 5. Standards, Frameworks, and Best Practices
- **ISO/IEC 27001 & NIST CSF**: The DESC ISR is heavily aligned with these international standards but adds local requirements for data sovereignty and Arabic language support.
- **WCAG 2.2**: The mandatory standard for digital accessibility in UAE government software.
- **Secure SDLC (S-SDLC)**: Integration of security at every phase, including threat modeling, static/dynamic analysis (SAST/DAST), and secure code reviews.
- **OWASP Top 10**: The standard reference for web application security testing in UAE audits.

## 6. Technical Tactics and Implementation Details
- **CI/CD Pipelines**: Automated workflows for building, testing, and deploying code. In the UAE, these often include automated security gates (DevSecOps).
- **Environment Segregation**: Mandatory separation of Development, Testing (QA/Staging), and Production environments as per DESC ISR.
- **Automated Configuration**: Use of Infrastructure as Code (IaC) to ensure consistent and repeatable environment setups.
- **Testing Approaches**:
    - **Automated Acceptance Testing**: Used to validate user stories in Agile sprints.
    - **Performance Testing**: Specifically measuring the **Page Speed Index** as a key metric for user experience. — *UAE Design System, [[21]](#ref21)

## 7. Measurement, KPIs, and Operational Metrics
The UAE Digital Government Online Service Index (DGOSI) uses the **Digital Services Quality Index (DSQI)**, which includes 8 primary measures:
1. **End-to-end service**: 6 criteria.
2. **Proactive service**: 5 criteria.
3. **Identity and authentication**: 4 criteria (e.g., UAE PASS integration).
4. **Service design standards**: 13 criteria (compliance with DLS 2.0).
5. **Service availability and awareness**: 8 criteria (24/7 availability).
6. **Service usage**: 3 criteria.
7. **Customer satisfaction**: 3 criteria.
8. **Reference data service**: 8 criteria (GSB compliance).
— *Source: TDRA, [[17]](#ref17)

**Mandatory Government KPIs**:
- Cost per transaction.
- User satisfaction.
- Completion rate.
- Digital take-up.

## 8. UAE Sector Use Cases and Localization Notes
- **Smart Dubai**: Implemented Agile methodologies to drive city-wide digital transformation, focusing on iterative improvements and culture building. — *Infosysta Case Study, [[22]](#ref22)
- **Healthcare (DHA)**: The **Biomedical Device Security Standard** requires manufacturers to provide a "Manufacturer Disclosure Statement for Medical Device Security (MDS2)" and conduct risk assessments before deployment. — *DHA NABIDH Standard, [[23]](#ref23)
- **Localization**: Software must support **Arabic (RTL)** layouts and cultural nuances in UX design, as specified in the UAE Design System.

## 9. Professional Practice and Checklists
Senior practitioners in the UAE use the following checklists for audits and reviews:
- **DESC ISR Compliance Checklist**: Covers 13 domains, with a focus on Domain 10 for software.
- **DLS 2.0 Self-Assessment Checklist**: Used by developers to validate website compliance before official evaluation.
- **Privacy Impact Assessment (PIA)**: Required under the PDPL for any software processing personal data.

## 10. Gaps and Verification Notes
- **Executive Regulations for PDPL**: While the law (No. 45/2021) is active, specific penalties and some finer details are still being updated via Executive Regulations.
- **Cloud Provider Specifics**: While G42 and Microsoft/AWS have regional presence, specific "Well-Architected" whitepapers tailored *exclusively* to UAE DESC ISR are often proprietary or entity-specific.
- **Verification Needed**: The exact list of the "50 criteria" for DGOSI is partially summarized in public documents; full technical rubrics are often shared directly with government entities.

## Sources
- **Dubai Electronic Security Center (DESC)**: Standards & Policies, [[3]](#ref3)
- **Telecommunications and Digital Government Regulatory Authority (TDRA)**: DGOSI Framework, [[24]](#ref24)
- **UAE Design System**: Getting Started & Assessment, [[25]](#ref25)
- **Central Bank of the UAE (CBUAE)**: Consumer Protection Regulation, [[26]](#ref26)
- **Dubai Health Authority (DHA)**: NABIDH Information Security Standards, [[27]](#ref27)
- **MDPI**: The Agile PMO Paradox: Embracing DevOps in the UAE, [[28]](#ref28)
- **Infosysta**: Digital Transformation at Smart Dubai, [[29]](#ref29)

**Checklist Status**:
- Runtime checklist path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a1fce3e/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a1fce3e/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a1fce3e/TOOL_RESULTS.md`
- Research child tool results lines: `2353`
- Research child tool results bytes: `116684`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a1fce3e/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Software engineering practices

#### 1. Architecture and scope questions
A senior UAE technology practitioner should begin every engagement by documenting the operating context before selecting tools. The working file should answer: which business or public-service outcome is being protected or improved, which data classifications are involved, which emirate or regulator matters, whether the system is federal, local-government, free-zone, private-sector or cross-border, which users require Arabic/English experience, which security controls are mandatory, and which operational owner will maintain the system after launch.

#### 2. UAE compliance and risk checklist
Use this checklist before approving any technology design, software release, cloud migration, AI deployment, data platform, cybersecurity control or outsourced IT service:

- Confirm the legal entity, regulator, sector, data classification and jurisdictional scope.
- Identify whether personal data, health data, financial data, government data, critical infrastructure information, payment data, virtual-asset data or AI training data is processed.
- Confirm data residency, cross-border transfer, encryption, retention, deletion and audit-log requirements.
- Confirm whether UAE PASS, national identity, Arabic localization, accessibility, government design systems or sector-specific APIs are required.
- Confirm the architecture owner, security owner, product owner, data owner and incident-response owner.
- Confirm that threat modeling, privacy impact review, secure coding, dependency review, infrastructure hardening and logging are complete.
- Confirm rollback, backup, disaster recovery, business continuity, support escalation and evidence-retention procedures.
- Confirm that vendor, open-source and cloud-provider dependencies are documented and reviewed for lock-in, security, licensing and resilience.

#### 3. Technical design template
A strong design document for Software engineering practices should include: purpose, scope, users, regulatory context, data flow, trust boundaries, identity model, integration points, deployment model, infrastructure region, availability model, monitoring plan, security controls, test plan, incident plan, cost assumptions, support model, and known risks. The document should explicitly state which claims are sourced, which assumptions require verification and which decisions are reversible.

#### 4. Engineering quality model
Quality should be measured across reliability, security, maintainability, usability, accessibility, performance, interoperability, privacy, compliance and operational cost. For software systems, include defect escape rate, test coverage, deployment frequency, lead time for change, change failure rate, mean time to restore, vulnerability age, dependency freshness and user-task success rate. For infrastructure, include uptime, latency, capacity, backup success, recovery-point objective, recovery-time objective, patch compliance and privileged-access review status.

#### 5. Security-by-design workflow
For every meaningful release, create a lightweight but complete security record: architecture diagram, data-flow diagram, trust boundaries, STRIDE or equivalent threat model, authentication and authorization design, secrets management design, input-validation approach, logging and monitoring plan, penetration-test scope, vulnerability remediation log and incident escalation contacts. In UAE contexts, this record should also identify whether DESC, TDRA, UAE Cybersecurity Council, CBUAE, VARA, DIFC, ADGM, healthcare or government procurement obligations apply.

#### 6. Common failure modes
The most common failure modes are treating data residency as an afterthought, assuming cloud-provider compliance automatically satisfies customer obligations, translating Arabic UI without RTL and cultural QA, buying cybersecurity tools without operating processes, deploying AI without data governance, relying on screenshots instead of audit evidence, building APIs without lifecycle ownership, and measuring technology success only by delivery date rather than resilience, adoption and security posture.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no system should collect data without a data owner, no API should be published without an authentication and versioning model, no AI model should be deployed without risk controls, no cloud workload should run without logging and backup, no vendor should operate without a defined SLA and exit plan, and no cybersecurity report should be accepted unless it identifies owners, deadlines and evidence for remediation.

## Domain 15: E-commerce, SaaS and product engineering: product management, UX, APIs, mobile apps, scalability, subscription systems, marketplaces and UAE commercial/legal constraints

### UAE E-commerce, SaaS, and Product Engineering: Technical and Regulatory Shard (July 2026)

## Domain Scope
The UAE's digital economy is characterized by a rapid transition toward a "mobile-first" and "identity-driven" ecosystem. The technical domain encompasses e-commerce platforms (B2C and B2B), Software-as-a-Service (SaaS) delivery models, and product engineering disciplines tailored for the Middle East market. 

Typical use cases include:
- **Quick-Commerce (Q-Commerce):** Hyper-local delivery services (e.g., Talabat, Noon Minutes) requiring high-concurrency real-time tracking and micro-fulfillment integration.
- **Sovereign SaaS:** Cloud-native applications hosted on local infrastructure (AWS me-central-1, Azure UAE North) to meet data residency requirements for government and regulated sectors.
- **Marketplace Ecosystems:** Multi-tenant platforms integrating local payment rails (Aani) and national identity (UAE Pass).

The boundary of this shard includes product management, UX/UI localization (Arabic RTL), API orchestration, and the commercial/legal constraints unique to the UAE jurisdiction.

## UAE Legal, Regulatory, and Policy Context
The UAE has established a comprehensive legislative framework to govern digital trade and data privacy, significantly updated in 2023 and 2024.

### 1. Trade by Modern Technological Means (TMTM Law)
**Federal Decree-Law No. 14 of 2023** replaced the 2006 e-commerce law to reflect the growth of blockchain, social commerce, and virtual reality trading.
- **Extraterritorial Effect:** Applies to any person engaging in commercial activity via modern technological means inside the UAE or receiving from outside (Article 2).
- **Platform Liability:** E-commerce platform operators are responsible for the failure of third-party sellers to comply with consumer protection requirements (Reed Smith, [[30]](#ref30)).
- **Mandatory Secure Payments:** Digital merchants must provide secure technological protection measures and secure payment methods (Khairallah Legal, [[31]](#ref31)).

### 2. Personal Data Protection Law (PDPL)
**Federal Decree-Law No. 45 of 2021** is the primary data privacy regulation, overseen by the UAE Data Office.
- **Data Subject Rights:** Includes rights to access, rectify, delete, and restrict processing (DLA Piper, [[2]](#ref2)).
- **Compliance Impact:** Mordor Intelligence notes that compliance outlays under the PDPL are a significant restraint on margin expansion for mid-to-large platforms (Mordor Intelligence, [[32]](#ref32)).

### 3. Consumer Protection and Subscriptions
- **Return Rights:** Consumers may return goods if they are defective, incomplete, or if delivery delays render them unusable (Article 14, TMTM Law).
- **Arbitration Constraint:** Contracts valued under AED 50,000 may not include mandatory arbitration clauses, ensuring court access for small claims (Khairallah Legal, [[31]](#ref31)).

## Core Concepts and Theory
- **Mobile-First Architecture:** One source cited 78.67% of e-commerce transactions originating from smartphones in 2025; use it as the latest sourced historical datapoint in the packets and verify current 2026 figures before planning, product engineering must prioritize mobile performance and biometric authentication (Mordor Intelligence, [[32]](#ref32)).
- **Identity-Centric UX:** The integration of **UAE Pass** as a single sign-on (SSO) mechanism is a core concept, reducing cart abandonment by up to 40% (UAE Pass Statistics, [[14]](#ref14)).
- **RTL (Right-to-Left) Design Theory:** Beyond simple translation, RTL requires mirroring layout structures, iconography directionality, and navigation patterns to align with Arabic cognitive processing.

## Architectures, Patterns, and Workflows
### 1. Reference Architecture for UAE SaaS
- **Cloud Regions:** Deployment typically targets **AWS me-central-1** (Abu Dhabi) or **Azure UAE North** (Dubai) to ensure low latency and data residency.
- **Multi-AZ Strategy:** AWS UAE region provides three Availability Zones (AZs) for high availability. Recent regional disruptions have emphasized the need for automated cross-AZ failover (AWS Blog, [[33]](#ref33)).
- **API Management:** Centralized API hubs are mandated for Open Finance, facilitating secure cross-sectoral data sharing (CBUAE Open Finance Regulation, [[34]](#ref34)).

### 2. Engineering Workflows
- **Secure SDLC:** Integration of TDRA and DESC security standards into the CI/CD pipeline.
- **Localization Workflow:** Continuous localization (L10n) processes that handle Arabic RTL testing as a first-class citizen in the QA cycle.

## Standards, Frameworks, and Best Practices
- **UAE Design System:** Provides mandatory guidelines for federal government apps, including specific patterns for English vs. Arabic headers (UAE Design System, [[35]](#ref35)).
- **Information Assurance (IA) Regulation:** TDRA's IA Regulation (v1.1) provides the minimum security levels for critical entities, highly recommended for all private e-commerce operators (TDRA, [[36]](#ref36)).
- **Open Finance Standards:** Mandatory participation for licensed entities in the CBUAE Open Finance Framework, utilizing standardized APIs for transaction initiation (Pinsent Masons, [[37]](#ref37)).

## Technical Tactics and Implementation Details
### 1. Arabic RTL Implementation
- **Header Pattern (Arabic):** `[User Profile/Avatar] [Notifications Icon] [Page Title] [Back Button]` (UAE Design System, [[35]](#ref35)).
- **Biometric Pivot:** The Central Bank's March 2026 sunset of SMS-based OTPs requires a technical shift to fingerprint and facial recognition for checkout authentication (Mordor Intelligence, [[32]](#ref32)).

### 2. Payment Integration
- **Aani Instant Payments:** Integration with the Aani platform allows clearing transactions in under 10 seconds, reducing reliance on Cash-on-Delivery (COD) which historically accounted for 50-60% of orders (Central Bank of the UAE, [[38]](#ref38)).

## Measurement, KPIs, and Operational Metrics
Success in UAE product engineering is measured through:
- **Cycle Time:** Speed of shipping incremental value (Talabat success metric).
- **First-Time Conversion:** Lifted by up to 40% through UAE Pass integration.
- **COD Refusal Rate:** Aani integration aims to reduce customer refusal rates by 12-15 percentage points.
- **Mobile Checkout Speed:** Biometric authentication is projected to raise checkout speed by 30-40% compared to desktop (Mordor Intelligence, [[32]](#ref32)).

## UAE Sector Use Cases and Localization Notes
- **Retail/Fashion:** Commanded 21.59% market share in 2025.
- **Food & Beverage:** Projected to have the highest CAGR (13.16%) through 2031.
- **Localization:** Mandatory "Customer Pulse" feedback mechanisms in government-facing apps (UAE Design System, [[35]](#ref35)).

## Professional Practice and Checklists
### Architecture Review Checklist for UAE SaaS:
- [ ] **Data Residency:** Is the primary database hosted in `me-central-1` or `uaenorth`?
- [ ] **Identity:** Is UAE Pass integrated for authentication to reduce friction?
- [ ] **Payments:** Does the platform support Aani and local digital wallets (e& money, PayIt)?
- [ ] **Security:** Does the app encrypt data at rest and in transit per TDRA IA standards?
- [ ] **UX:** Is the Arabic RTL layout mirrored correctly (navigation, icons, text alignment)?

## Sources
- **Reed Smith:** "UAE Federal Law on Modern Trading by Technological Means," [[30]](#ref30)
- **Mordor Intelligence:** "United Arab Emirates E-commerce Market Analysis," [[32]](#ref32)
- **Khairallah Legal:** "Federal Decree-Law No. 14/2023 on Trading by Modern Technological Means," [[31]](#ref31)
- **UAE Design System:** "Mobile Application Guidelines," [[35]](#ref35)
- **CBUAE Rulebook:** "Retail Payment Services and Card Schemes Regulation," [[38]](#ref38)
- **AWS Blog:** "Now Open – AWS Region in the United Arab Emirates (UAE)," [[33]](#ref33)
- **TDRA:** "UAE Information Assurance Regulation," [[36]](#ref36)

## Gaps and Verification Notes
- **Implementing Regulations:** The TMTM Law (14/2023) refers to Implementing Regulations that were not fully published as of early 2026; specific penalty lists are pending Cabinet Decisions.
- **Open Finance API Specs:** While the framework is mandated, specific technical API schemas for non-banking sectors (e.g., insurance, retail) are still being finalized under Circular 03/2025.
- **Data Residency for Free Zones:** The exact boundary for data residency between "onshore" UAE and financial free zones (DIFC/ADGM) remains a point of technical complexity for SaaS providers serving both.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/c5791ada/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/c5791ada/TOOL_RESULTS.md`
- Research child tool results lines: `1463`
- Research child tool results bytes: `92926`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/c5791ada/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for E-commerce, SaaS and product engineering

#### 1. Architecture and scope questions
A senior UAE technology practitioner should begin every engagement by documenting the operating context before selecting tools. The working file should answer: which business or public-service outcome is being protected or improved, which data classifications are involved, which emirate or regulator matters, whether the system is federal, local-government, free-zone, private-sector or cross-border, which users require Arabic/English experience, which security controls are mandatory, and which operational owner will maintain the system after launch.

#### 2. UAE compliance and risk checklist
Use this checklist before approving any technology design, software release, cloud migration, AI deployment, data platform, cybersecurity control or outsourced IT service:

- Confirm the legal entity, regulator, sector, data classification and jurisdictional scope.
- Identify whether personal data, health data, financial data, government data, critical infrastructure information, payment data, virtual-asset data or AI training data is processed.
- Confirm data residency, cross-border transfer, encryption, retention, deletion and audit-log requirements.
- Confirm whether UAE PASS, national identity, Arabic localization, accessibility, government design systems or sector-specific APIs are required.
- Confirm the architecture owner, security owner, product owner, data owner and incident-response owner.
- Confirm that threat modeling, privacy impact review, secure coding, dependency review, infrastructure hardening and logging are complete.
- Confirm rollback, backup, disaster recovery, business continuity, support escalation and evidence-retention procedures.
- Confirm that vendor, open-source and cloud-provider dependencies are documented and reviewed for lock-in, security, licensing and resilience.

#### 3. Technical design template
A strong design document for E-commerce, SaaS and product engineering should include: purpose, scope, users, regulatory context, data flow, trust boundaries, identity model, integration points, deployment model, infrastructure region, availability model, monitoring plan, security controls, test plan, incident plan, cost assumptions, support model, and known risks. The document should explicitly state which claims are sourced, which assumptions require verification and which decisions are reversible.

#### 4. Engineering quality model
Quality should be measured across reliability, security, maintainability, usability, accessibility, performance, interoperability, privacy, compliance and operational cost. For software systems, include defect escape rate, test coverage, deployment frequency, lead time for change, change failure rate, mean time to restore, vulnerability age, dependency freshness and user-task success rate. For infrastructure, include uptime, latency, capacity, backup success, recovery-point objective, recovery-time objective, patch compliance and privileged-access review status.

#### 5. Security-by-design workflow
For every meaningful release, create a lightweight but complete security record: architecture diagram, data-flow diagram, trust boundaries, STRIDE or equivalent threat model, authentication and authorization design, secrets management design, input-validation approach, logging and monitoring plan, penetration-test scope, vulnerability remediation log and incident escalation contacts. In UAE contexts, this record should also identify whether DESC, TDRA, UAE Cybersecurity Council, CBUAE, VARA, DIFC, ADGM, healthcare or government procurement obligations apply.

#### 6. Common failure modes
The most common failure modes are treating data residency as an afterthought, assuming cloud-provider compliance automatically satisfies customer obligations, translating Arabic UI without RTL and cultural QA, buying cybersecurity tools without operating processes, deploying AI without data governance, relying on screenshots instead of audit evidence, building APIs without lifecycle ownership, and measuring technology success only by delivery date rather than resilience, adoption and security posture.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no system should collect data without a data owner, no API should be published without an authentication and versioning model, no AI model should be deployed without risk controls, no cloud workload should run without logging and backup, no vendor should operate without a defined SLA and exit plan, and no cybersecurity report should be accepted unless it identifies owners, deadlines and evidence for remediation.


## Category Appendix: UAE Software Delivery Operating System

### Delivery lifecycle
A UAE-ready delivery lifecycle moves from discovery to design, architecture, compliance review, development, testing, security review, deployment, monitoring, support and continuous improvement. Every stage should produce evidence. This matters especially where federal, Dubai, financial, healthcare, education or virtual-asset requirements attach to the system.

### Arabic/English product quality
Multilingual product quality is not only translation. It includes RTL layout, form behavior, typography, search behavior, date and currency handling, phone-number validation, accessibility, bilingual support workflows, Arabic metadata and analytics segmentation by language.

### Product engineering governance
Product teams should maintain a decision log, roadmap, metrics tree, API inventory, release notes, known risks, dependency register and customer-feedback loop. For SaaS, add subscription lifecycle, billing events, entitlement logic, usage metering, tenant isolation, support SLAs and data-export capability.

## File-Level Verification Notes

- This file is based on source collector packets generated in July 2026.
- Do not treat vendor product availability, security benchmarks, certification status or regulatory timelines as permanent; verify current authority and vendor documentation before implementation.
- For regulated sectors such as finance, virtual assets, healthcare, education, government services, telecoms, energy and critical infrastructure, obtain current sector-specific guidance before launch or procurement.

## References

<p id="ref1" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.trade.gov/market-intelligence/united-arab-emirates-allows-cross-border-data-flows-personal-data">[1] trade.gov</a></p>
<p id="ref2" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.dlapiperdataprotection.com/countries/uae-general/law.html">[2] dlapiperdataprotection.com</a></p>
<p id="ref3" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.desc.gov.ae/regulations/standards-policies/">[3] desc.gov.ae</a></p>
<p id="ref4" class="ref_item"><a target="_blank" rel="noreferrer" href="https://tdra.gov.ae/en/media/press-release/2024/tdra-launches-the-uae-design-system-2-for-federal-government-websites">[4] tdra.gov.ae</a></p>
<p id="ref5" class="ref_item"><a target="_blank" rel="noreferrer" href="https://iquasar-emea.com/blog/uae-data-residency-sovereign-cloud-guide/">[5] iquasar-emea.com</a></p>
<p id="ref6" class="ref_item"><a target="_blank" rel="noreferrer" href="https://github.com/TDRA-ae/aegov-dls-react">[6] github.com</a></p>
<p id="ref7" class="ref_item"><a target="_blank" rel="noreferrer" href="https://designsystem.gov.ae/guidelines/accessibility">[7] designsystem.gov.ae</a></p>
<p id="ref8" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.deque.com/mena-digital-accessibility-laws/uae/">[8] deque.com</a></p>
<p id="ref9" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.monotype.com/resources/case-studies/dubai">[9] monotype.com</a></p>
<p id="ref10" class="ref_item"><a target="_blank" rel="noreferrer" href="https://designsystem.gov.ae/guidelines/typography">[10] designsystem.gov.ae</a></p>
<p id="ref11" class="ref_item"><a target="_blank" rel="noreferrer" href="https://insightplus.bakermckenzie.com/bm/attachment_dw.action?attkey=FRbANEucS95NMLRN47z%2BeeOgEFCt8EGQJsWJiCH2WAVfnLVn2ghRGMhMH%2FuEdVml">[11] insightplus.bakermckenzie.com</a></p>
<p id="ref12" class="ref_item"><a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/entiresection/47">[12] rulebook.centralbank.ae</a></p>
<p id="ref13" class="ref_item"><a target="_blank" rel="noreferrer" href="https://designsystem.gov.ae/guidelines">[13] designsystem.gov.ae</a></p>
<p id="ref14" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws">[14] u.ae</a></p>
<p id="ref15" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws*">[15] u.ae</a></p>
<p id="ref16" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.desc.gov.ae/regulations/standards-policies/*">[16] desc.gov.ae</a></p>
<p id="ref17" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/uae-competitiveness/Digital-Government-Online-Services-Index-DGOSI*">[17] u.ae</a></p>
<p id="ref18" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.onespan.com/blog/central-bank-of-uae-boosts-protection-against-fraud*">[18] onespan.com</a></p>
<p id="ref19" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.mdpi.com/2674-113X/4/4/24*">[19] mdpi.com</a></p>
<p id="ref20" class="ref_item"><a target="_blank" rel="noreferrer" href="https://designsystem.gov.ae/docs/getting-started*">[20] designsystem.gov.ae</a></p>
<p id="ref21" class="ref_item"><a target="_blank" rel="noreferrer" href="https://designsystem.gov.ae/resources/assessment-criteria*">[21] designsystem.gov.ae</a></p>
<p id="ref22" class="ref_item"><a target="_blank" rel="noreferrer" href="https://infosysta.com/case-studies/digital-transformation-project-task/*">[22] infosysta.com</a></p>
<p id="ref23" class="ref_item"><a target="_blank" rel="noreferrer" href="https://dha.gov.ae/uploads/102022/NABIDH%20Policies%20&amp;%20Standards%20-Information%20Security%20Standards20221021940.pdf*">[23] dha.gov.ae</a></p>
<p id="ref24" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/uae-competitiveness/Digital-Government-Online-Services-Index-DGOSI">[24] u.ae</a></p>
<p id="ref25" class="ref_item"><a target="_blank" rel="noreferrer" href="https://designsystem.gov.ae/docs/getting-started">[25] designsystem.gov.ae</a></p>
<p id="ref26" class="ref_item"><a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/article-6-protection-consumer-data-and-assets">[26] rulebook.centralbank.ae</a></p>
<p id="ref27" class="ref_item"><a target="_blank" rel="noreferrer" href="https://dha.gov.ae/uploads/102022/NABIDH%20Policies%20&amp;%20Standards%20-Information%20Security%20Standards20221021940.pdf">[27] dha.gov.ae</a></p>
<p id="ref28" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.mdpi.com/2674-113X/4/4/24">[28] mdpi.com</a></p>
<p id="ref29" class="ref_item"><a target="_blank" rel="noreferrer" href="https://infosysta.com/case-studies/digital-transformation-project-task/">[29] infosysta.com</a></p>
<p id="ref30" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.reedsmith.com/our-insights/blogs/viewpoints/102iqny/uae-federal-law-on-modern-trading-by-technological-means/">[30] reedsmith.com</a></p>
<p id="ref31" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.khairallahlegal.com/federal-decree-law-no-14-2023-on-trading-by-modern-technological-means/">[31] khairallahlegal.com</a></p>
<p id="ref32" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.mordorintelligence.com/industry-reports/united-arab-emirates-ecommerce-market">[32] mordorintelligence.com</a></p>
<p id="ref33" class="ref_item"><a target="_blank" rel="noreferrer" href="https://aws.amazon.com/blogs/aws/now-open-aws-region-in-the-united-arab-emirates-uae/">[33] aws.amazon.com</a></p>
<p id="ref34" class="ref_item"><a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/open-finance-regulation">[34] rulebook.centralbank.ae</a></p>
<p id="ref35" class="ref_item"><a target="_blank" rel="noreferrer" href="https://designsystem.gov.ae/guidelines/mobile-applications">[35] designsystem.gov.ae</a></p>
<p id="ref36" class="ref_item"><a target="_blank" rel="noreferrer" href="https://tdra.gov.ae/-/media/About/regulations-and-ruling/EN/UAE-Information-Assurance-Regulation-v1-1-pdf.ashx">[36] tdra.gov.ae</a></p>
<p id="ref37" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.pinsentmasons.com/out-law/guides/uae-open-finance">[37] pinsentmasons.com</a></p>
<p id="ref38" class="ref_item"><a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/retail-payment-services-and-card-schemes-regulation">[38] rulebook.centralbank.ae</a></p>
