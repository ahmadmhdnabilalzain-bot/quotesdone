# UAE IT, Computer Science, Software Engineering, Artificial Intelligence and Cybersecurity Knowledge Library

**Version:** July 2026 research build  
**Scope:** UAE-first technology knowledge library with international best-practice context, covering digital economy strategy, computer science foundations, web development, software engineering, cloud, data engineering, AI, cybersecurity, incident response, FinTech technology, IT management, procurement, talent and emerging technologies.

## Library Files

### [Digital Economy, Computer Science Foundations and Technology Talent in the UAE](./01_Digital_Economy_CS_Foundations_and_Talent.md)

The baseline technology context: UAE digital strategies, computer science foundations, engineering education, certifications, competency frameworks, talent pathways and workforce development.

- Domain 01: UAE IT and digital economy landscape: national digital strategies, Digital Government, cloud-first policy, free zones, technology ecosystems and enterprise IT governance
- Domain 02: Computer science foundations for professional practice: algorithms, data structures, operating systems, databases, networking, distributed systems and how they apply in UAE organizations
- Domain 17: Education, certifications and talent pathways: UAE computer science education, coding schools, professional certifications, career paths, hiring standards and competency frameworks

### [Web Development, Software Engineering, Product Engineering and SaaS in the UAE](./02_Web_Software_Product_and_Engineering_Practice.md)

The software delivery layer: web applications, Arabic/English UX, secure full-stack development, SDLC, Agile, DevOps, QA, product engineering, SaaS, APIs, scalability and UAE commercial constraints.

- Domain 03: Web development in the UAE: frontend, backend, full-stack, accessibility, multilingual Arabic/English UX, hosting, performance, security and compliance
- Domain 04: Software engineering practices: SDLC, Agile/Scrum, DevOps, CI/CD, testing, QA, documentation, code review, architecture and engineering management
- Domain 15: E-commerce, SaaS and product engineering: product management, UX, APIs, mobile apps, scalability, subscription systems, marketplaces and UAE commercial/legal constraints

### [Cloud Infrastructure, Data Engineering, Analytics and Emerging Technologies in the UAE](./03_Cloud_Infrastructure_Data_and_Emerging_Technologies.md)

The infrastructure and data layer: sovereign cloud, hyperscaler regions, hybrid architecture, data engineering, databases, BI, IoT, 5G/6G, robotics, digital twins, edge and quantum use cases.

- Domain 05: Cloud computing and infrastructure in the UAE: AWS UAE, Microsoft UAE, Oracle, G42/Khazna, hybrid cloud, Kubernetes, serverless, data residency and cloud governance
- Domain 06: Databases, data engineering and analytics: SQL/NoSQL, data warehouses, lakes, pipelines, BI, data quality, lineage, UAE privacy and sector data constraints
- Domain 18: Emerging technologies in UAE: smart cities, IoT, 5G/6G, edge computing, robotics, quantum, digital twins, metaverse/spatial computing and sector use cases

### [Artificial Intelligence, Machine Learning, Responsible AI and AI Security in the UAE](./04_AI_Machine_Learning_Responsible_AI_and_AI_Security.md)

The AI layer: national AI strategy, sovereign AI, LLMs, MLOps, AI governance, responsible AI, privacy engineering, prompt injection, model security and AI risk controls.

- Domain 07: Artificial intelligence and machine learning in the UAE: national AI strategy, model development, MLOps, generative AI, responsible AI, use cases and governance
- Domain 12: AI security, data privacy and responsible AI: adversarial ML, prompt injection, data leakage, model governance, AI risk controls, privacy engineering and UAE AI policy context

### [Cybersecurity Governance, Application Security, Network Security and Cloud Security in the UAE](./05_Cybersecurity_Governance_AppSec_Network_and_Cloud_Security.md)

The cybersecurity control layer: UAE cyber governance, secure SDLC, OWASP, threat modeling, network defense, zero trust, SOC/SIEM, cloud security, IAM, CSPM, Kubernetes hardening and compliance.

- Domain 08: Cybersecurity governance and regulation in the UAE: UAE Cybersecurity Council, TDRA, NESA/IAS, DESC, PDPL, cybercrime law, sectoral obligations and compliance programs
- Domain 09: Application security and secure software development: OWASP, threat modeling, secure coding, SAST/DAST, dependency security, secrets, API security and DevSecOps
- Domain 10: Network security and infrastructure security: firewalls, zero trust, IAM, VPN, Wi-Fi, segmentation, SOC operations, SIEM, endpoint security and incident response
- Domain 11: Cloud security and identity security: shared responsibility, IAM, CSPM, container security, Kubernetes hardening, logging, encryption, key management and UAE residency issues

### [Incident Response, Digital Forensics, FinTech Technology, IT Management and Procurement in the UAE](./06_Incident_Response_FinTech_IT_Management_and_Procurement.md)

The operations and regulated-technology layer: incident response, forensics, business continuity, payments, open finance, blockchain, virtual assets, ITIL, procurement, outsourcing, SLAs and vendor management.

- Domain 13: Cyber incident response, digital forensics and business continuity: UAE reporting expectations, playbooks, ransomware, evidence handling, backup, DR and crisis communications
- Domain 14: FinTech, payments, blockchain and digital assets technology in UAE: CBUAE, VARA, ADGM/FSRA, DIFC, open finance, payment security and compliance engineering
- Domain 16: IT project management, procurement and outsourcing in UAE: vendor management, SLAs, ITIL, service management, managed services, contracts and government procurement

## Recommended Reading Sequence

1. Start with **Digital Economy, Computer Science Foundations and Technology Talent** to understand the UAE technology baseline.
2. Continue to **Web Development, Software Engineering, Product Engineering and SaaS** to understand delivery practice.
3. Use **Cloud Infrastructure, Data Engineering, Analytics and Emerging Technologies** to plan infrastructure and data foundations.
4. Use **AI, Machine Learning, Responsible AI and AI Security** to govern AI systems.
5. Use **Cybersecurity Governance, AppSec, Network and Cloud Security** to design secure systems.
6. Use **Incident Response, FinTech Technology, IT Management and Procurement** for operations, regulated systems and vendor governance.

## Source Packets

The folder `UAE_IT_Computer_Science_Library_sources/` contains the raw collector packets, coverage map and build report. These are included in the final ZIP for auditability.
