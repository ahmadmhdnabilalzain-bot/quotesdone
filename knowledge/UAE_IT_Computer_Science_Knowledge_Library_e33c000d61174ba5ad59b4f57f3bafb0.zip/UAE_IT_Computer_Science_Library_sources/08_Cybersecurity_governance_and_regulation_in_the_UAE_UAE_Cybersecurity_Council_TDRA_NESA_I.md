# Source Packet 8: Cybersecurity governance and regulation in the UAE: UAE Cybersecurity Council, TDRA, NESA/IAS, DESC, PDPL, cybercrime law, sectoral obligations and compliance programs

# Cybersecurity Governance and Regulation in the UAE

## Domain Scope
Cybersecurity governance in the UAE encompasses the legal, regulatory, and institutional frameworks designed to protect the nation's digital infrastructure, ensure data privacy, and combat cybercrime. As of July 2026, the domain has shifted from "capacity building" to "active defense," driven by the **National Cyber Security Strategy (2025-2031)**.

### UAE Relevance and Use Cases
- **Critical Information Infrastructure (CII):** Protection of energy, finance, healthcare, and telecommunications sectors.
- **Digital Government:** Securing the transition to "Agentic AI" and 100% digital public services.
- **Sovereign Assurance:** Ensuring data residency and digital sovereignty for government and sensitive private sector data.
- **Business Use Cases:** Compliance with federal and emirate-level standards is mandatory for licensing and operation, particularly in regulated sectors like finance (ADGM/DIFC/CBUAE) and healthcare.

---

## UAE Legal, Regulatory, and Policy Context

### Key Regulators and Authorities
1.  **UAE Cybersecurity Council (CSC):** The primary federal body responsible for national cybersecurity strategy, legislation, and the **National Cyber Accreditation Programme (NCAP)**.
2.  **Federal Authority for Artificial Intelligence and Data (FAAID):** Established in June 2026, this authority consolidated the UAE AI Office, TDRA’s Digital Government sector, and the UAE Data Office. It now oversees the **Personal Data Protection Law (PDPL)** and national AI governance.
3.  **Dubai Electronic Security Center (DESC):** The regulator for Dubai government entities and critical infrastructure, enforcing the **Information Security Regulation (ISR)**.

### Primary Laws and Regulations
-   **Federal Decree-Law No. 34 of 2021 (Cybercrime Law):** Criminalizes hacking, data theft, and the spread of rumors. Penalties include imprisonment and fines up to **AED 3 million**.
-   **Federal Decree-Law No. 45 of 2021 (PDPL):** The federal data privacy law. As of 2026, it has entered an "active compliance phase" with FAAID providing practical guidance while formal Executive Regulations are finalized.
-   **National Cyber Security Strategy (2025-2031):** Focuses on five pillars: Governance, Resilient Environment, Secure Innovation (AI/Quantum), National Capabilities, and International Collaboration.
-   **National Cyber Accreditation Programme (NCAP):** Effective 2026, restricts the use of unaccredited cybersecurity service providers for CII.

---

## Core Concepts and Theory
-   **Active Defense:** A proactive posture involving real-time threat hunting and automated response, moving beyond passive perimeter security.
-   **Digital Debt:** The risk posed by legacy vulnerabilities; the CSC reports that ~50% of exploited vulnerabilities in the UAE are >5 years old.
-   **Agentic AI Security:** Governance of autonomous AI agents that execute workflows, focusing on "shadow agents" and model integrity.
-   **Quantum Resilience:** Preparation for post-quantum cryptography (PQC) to counter "harvest now, decrypt later" threats.

---

## Architectures, Patterns, and Workflows

### Reference Architectures
-   **Zero Trust Architecture (ZTA):** Now a binding requirement for ADGM financial institutions (2026) and a core recommendation in DESC ISR v3.0.
-   **Secure Supply Chain:** Implementation of **Software Bill of Materials (SBOM)** is becoming mandatory for government procurement to ensure transparency in software components.

### Compliance Workflows
1.  **Gap Analysis:** Mapping existing controls against NESA IAS v2 or DESC ISR v3.1.
2.  **Risk Assessment:** Annual mandatory assessments approved by senior management.
3.  **Accreditation:** Ensuring all MSSPs and cloud vendors are NCAP-accredited.
4.  **Incident Notification:** Strict 24-hour reporting window for material incidents (ADGM/CBUAE).

---

## Standards, Frameworks, and Best Practices

### Local Standards
-   **NESA Information Assurance Standards (IAS) v2 (2025):** Rebased on ISO/IEC 27001:2022 and NIST SP 800-53 Rev. 5. Includes 15 control families (6 Management, 9 Technical).
-   **DESC Information Security Regulation (ISR) v3.1:** Prescriptive controls for Dubai entities, emphasizing asset classification and executive accountability.
-   **CBUAE Technology Risk & InfoSec Regulation (Article 13):** Mandatory for payment service providers, requiring multi-factor authentication (MFA) for high-risk transactions.

### Global Alignment
-   **ISO/IEC 27001:2022:** The foundational standard for most UAE frameworks.
-   **DORA (Digital Operational Resilience Act):** ADGM’s 2026 framework is closely aligned with EU DORA for financial resilience.

---

## Technical Tactics and Implementation Details
-   **MFA and Token Protection:** Shift from simple MFA to "phishing-resistant" MFA to counter MFA fatigue and token theft.
-   **Encryption:** Mandatory end-to-end encryption for user passwords and sensitive data in transit (CBUAE Article 13).
-   **API Security:** Safeguards for API development to secure data exchange between applications.
-   **PQC Migration:** Requirement for financial and government entities to produce a Post-Quantum Cryptography migration roadmap by late 2026.

---

## Measurement, KPIs, and Operational Metrics
-   **Maturity Levels:** NESA and DESC use a 0-5 maturity scale; entities are often required to reach Level 3 ("Defined") or Level 4 ("Managed") for critical systems.
-   **Incident Response Time:** Target for containment of "Critical" incidents is typically <4 hours.
-   **Compliance Score:** Percentage of mandatory controls implemented (e.g., 136 mandatory sub-controls in NESA IAS).
-   **Cyber Pulse Metrics:** National awareness reach (e.g., 20,000+ women trained in cybersecurity).

---

## UAE Sector Use Cases and Localization Notes
-   **Finance:** CBUAE Federal Decree-Law No. 6 of 2025 imposes strict liability for management in cases of security negligence.
-   **Healthcare:** ADHICS (Abu Dhabi) and NABIDH (Dubai) regulate health data, with strict data residency requirements.
-   **Energy/Utilities:** High focus on Operational Technology (OT) security and state-sponsored sabotage defense.
-   **Localization:** All public-facing portals must provide Arabic/English security guidance and adhere to UAE cultural norms in content filtering (Child Digital Safety Law 2026).

---

## Professional Practice and Checklists

### Audit Checklist for 2026 Compliance
- [ ] **NCAP Check:** Are all cybersecurity vendors and cloud providers NCAP-accredited?
- [ ] **SBOM Inventory:** Is there a Software Bill of Materials for all new software procurement?
- [ ] **DPO Appointment:** Has a Data Protection Officer been registered with FAAID (if processing large-scale sensitive data)?
- [ ] **24-Hour Drill:** Has the incident response team tested the 24-hour regulatory notification workflow?
- [ ] **Legacy Debt:** Have all vulnerabilities >5 years old been patched or mitigated?

---

## Sources

### Primary Sources
- **UAE Cybersecurity Council (CSC):** National Cyber Security Strategy (2025-2031), https://practiceguides.chambers.com/practice-guides/cybersecurity-2026/uae/trends-and-developments
- **Central Bank of the UAE (CBUAE):** Article (13) Technology Risk and Information Security, https://rulebook.centralbank.ae/en/rulebook/article-13-technology-risk-and-information-security
- **Dubai Electronic Security Center (DESC):** Information Security Regulation (ISR) v3.0/3.1, https://complyan.com/how-dubais-isr-v3-0-is-shaping-smarter-security-standards-in-the-region/
- **ADGM FSRA:** Cyber Risk Management Framework 2026, https://www.linkedin.com/pulse/adgm-cyber-risk-management-framework-2026-essential-1ccbc
- **UAE Government Portal (u.ae):** Cyber Safety and Digital Security, https://u.ae/en/information-and-services/justice-safety-and-the-law/cyber-safety-and-digital-security

### Secondary Sources
- **Chambers and Partners:** Cybersecurity 2026 UAE Trends, https://practiceguides.chambers.com/practice-guides/cybersecurity-2026/uae/trends-and-developments
- **DLA Piper:** Data Protection Laws in UAE - General, https://www.dlapiperdataprotection.com/countries/uae-general/law.html
- **V-Comply:** UAE Cybercrime Law Overview, https://www.v-comply.com/glossary/cybercrime-law-uae/

---

## Gaps and Verification Notes
- **PDPL Executive Regulations:** While the law is active, the formal Executive Regulations are still pending as of early 2026; however, FAAID (the new authority) is issuing "practical guidance" that serves as the current compliance baseline.
- **NCAP Provider List:** The official list of NCAP-accredited providers is dynamic; organizations must verify current status via the CSC portal.
- **FAAID Transition:** The consolidation of TDRA and Data Office functions into FAAID (June 2026) is a recent organizational change; some legacy URLs may still point to TDRA or the Data Office.

**Checklist Status:** All items in `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/79a88591/RESEARCH_CHECKLIST.md` are marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/79a88591/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/79a88591/TOOL_RESULTS.md`
- Research child tool results lines: `2087`
- Research child tool results bytes: `135629`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/79a88591/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
