# Source Packet 4: Software engineering practices: SDLC, Agile/Scrum, DevOps, CI/CD, testing, QA, documentation, code review, architecture and engineering management

# Collector Report: Software Engineering Practices in the UAE

This report provides a comprehensive overview of software engineering practices, standards, and regulatory requirements in the United Arab Emirates as of July 2026. It covers the Software Development Lifecycle (SDLC), Agile/Scrum methodologies, DevOps, CI/CD, testing, and engineering management within the UAE's digital transformation framework.

## 1. Domain Scope
The software engineering domain in the UAE is characterized by a rapid shift toward "Digital-First" and "Cloud-First" strategies, driven by national initiatives like **UAE Vision 2031** and **Centennial 2071**.
- **UAE Relevance**: Software engineering is the backbone of the UAE's smart city initiatives (e.g., Dubai Paperless Strategy) and digital government services.
- **Business/Government Use Cases**:
    - **Government**: End-to-end digital service delivery via the **UAE PASS** and **GSB (Government Service Bus)**.
    - **Finance**: Implementation of Open Banking and secure digital transaction processing under CBUAE regulations.
    - **Healthcare**: Secure operation of electronic biomedical devices (EBMD) and interoperable health records (NABIDH).
- **Boundaries**: The scope includes all phases of the SDLC, from requirement gathering to maintenance, with a heavy emphasis on **Secure SDLC (S-SDLC)** as mandated by the Dubai Electronic Security Center (DESC).

## 2. UAE Legal, Regulatory, and Policy Context
Software development in the UAE is governed by a robust framework of federal and local laws:
- **Federal Decree-Law No. 45 of 2021 (Personal Data Protection Law - PDPL)**: The first comprehensive federal data privacy law. It mandates "Privacy by Design" and "Privacy by Default" in software architecture.
    - *Requirement*: Organizations must implement technical and organizational measures to protect personal data. — *UAE Government Portal, https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws*
- **Dubai Information Security Regulation (ISR) v3.1**: Issued by DESC, this is the baseline for all Dubai government entities.
    - **Domain 10 (Secure Development)**: Specifically outlines controls for secure software development, including environment segregation, change management, and vulnerability testing. — *DESC, https://www.desc.gov.ae/regulations/standards-policies/*
- **TDRA Digital Government Service Standard**: A framework consisting of **50 criteria** to evaluate the quality of digital services, including end-to-end service delivery and proactive service initiation. — *TDRA, https://u.ae/en/about-the-uae/uae-competitiveness/Digital-Government-Online-Services-Index-DGOSI*
- **CBUAE Consumer Protection Regulation (CPR)**: Mandates strong authentication (Multi-Factor Authentication) for financial software.
    - *Verbatim*: "To combat weak authentication methods, the notice prohibits FIs from using SMS OTP, email OTP, or static passwords as the sole authentication method for financial transactions." — *OneSpan (CBUAE Notice), https://www.onespan.com/blog/central-bank-of-uae-boosts-protection-against-fraud*

## 3. Core Concepts and Theory
- **Agile DevOps Reference Model (ADRM)**: A framework used in the UAE to align strategic agility with operational execution, consisting of four layers: Values, Principles, Dimensions, and Practices. — *MDPI Study, https://www.mdpi.com/2674-113X/4/4/24*
- **Dynamic Capabilities Framework (DCF)**: Applied by UAE organizations to "Sense, Seize, and Transform" their software engineering competencies in response to rapid technological shifts.
- **Microservices Architecture**: Increasingly adopted in the UAE to enhance scalability and resilience, particularly in large-scale government platforms.

## 4. Architectures, Patterns, and Workflows
- **Target Operating Model (TOM)**: Used by entities like **Digital Dubai** to transition from legacy systems to Agile-based delivery models.
- **UAE Design System 2.0 (DLS 2.0)**: A standardized set of UI components, blocks, and patterns for federal government websites to ensure consistency and accessibility (WCAG 2.2).
    - *Technical Detail*: DLS 2.0 uses a modular approach, allowing components to function correctly in isolation or integrated into larger interfaces. — *UAE Design System, https://designsystem.gov.ae/docs/getting-started*
- **API-First Strategy**: Mandated for government interoperability via the **GSB**, ensuring that data is shared efficiently between entities.

## 5. Standards, Frameworks, and Best Practices
- **ISO/IEC 27001 & NIST CSF**: The DESC ISR is heavily aligned with these international standards but adds local requirements for data sovereignty and Arabic language support.
- **WCAG 2.2**: The mandatory standard for digital accessibility in UAE government software.
- **Secure SDLC (S-SDLC)**: Integration of security at every phase, including threat modeling, static/dynamic analysis (SAST/DAST), and secure code reviews.
- **OWASP Top 10**: The standard reference for web application security testing in UAE audits.

## 6. Technical Tactics and Implementation Details
- **CI/CD Pipelines**: Automated workflows for building, testing, and deploying code. In the UAE, these often include automated security gates (DevSecOps).
- **Environment Segregation**: Mandatory separation of Development, Testing (QA/Staging), and Production environments as per DESC ISR.
- **Automated Configuration**: Use of Infrastructure as Code (IaC) to ensure consistent and repeatable environment setups.
- **Testing Approaches**:
    - **Automated Acceptance Testing**: Used to validate user stories in Agile sprints.
    - **Performance Testing**: Specifically measuring the **Page Speed Index** as a key metric for user experience. — *UAE Design System, https://designsystem.gov.ae/resources/assessment-criteria*

## 7. Measurement, KPIs, and Operational Metrics
The UAE Digital Government Online Service Index (DGOSI) uses the **Digital Services Quality Index (DSQI)**, which includes 8 primary measures:
1. **End-to-end service**: 6 criteria.
2. **Proactive service**: 5 criteria.
3. **Identity and authentication**: 4 criteria (e.g., UAE PASS integration).
4. **Service design standards**: 13 criteria (compliance with DLS 2.0).
5. **Service availability and awareness**: 8 criteria (24/7 availability).
6. **Service usage**: 3 criteria.
7. **Customer satisfaction**: 3 criteria.
8. **Reference data service**: 8 criteria (GSB compliance).
— *Source: TDRA, https://u.ae/en/about-the-uae/uae-competitiveness/Digital-Government-Online-Services-Index-DGOSI*

**Mandatory Government KPIs**:
- Cost per transaction.
- User satisfaction.
- Completion rate.
- Digital take-up.

## 8. UAE Sector Use Cases and Localization Notes
- **Smart Dubai**: Implemented Agile methodologies to drive city-wide digital transformation, focusing on iterative improvements and culture building. — *Infosysta Case Study, https://infosysta.com/case-studies/digital-transformation-project-task/*
- **Healthcare (DHA)**: The **Biomedical Device Security Standard** requires manufacturers to provide a "Manufacturer Disclosure Statement for Medical Device Security (MDS2)" and conduct risk assessments before deployment. — *DHA NABIDH Standard, https://dha.gov.ae/uploads/102022/NABIDH%20Policies%20&%20Standards%20-Information%20Security%20Standards20221021940.pdf*
- **Localization**: Software must support **Arabic (RTL)** layouts and cultural nuances in UX design, as specified in the UAE Design System.

## 9. Professional Practice and Checklists
Senior practitioners in the UAE use the following checklists for audits and reviews:
- **DESC ISR Compliance Checklist**: Covers 13 domains, with a focus on Domain 10 for software.
- **DLS 2.0 Self-Assessment Checklist**: Used by developers to validate website compliance before official evaluation.
- **Privacy Impact Assessment (PIA)**: Required under the PDPL for any software processing personal data.

## 10. Gaps and Verification Notes
- **Executive Regulations for PDPL**: While the law (No. 45/2021) is active, specific penalties and some finer details are still being updated via Executive Regulations.
- **Cloud Provider Specifics**: While G42 and Microsoft/AWS have regional presence, specific "Well-Architected" whitepapers tailored *exclusively* to UAE DESC ISR are often proprietary or entity-specific.
- **Verification Needed**: The exact list of the "50 criteria" for DGOSI is partially summarized in public documents; full technical rubrics are often shared directly with government entities.

## Sources
- **Dubai Electronic Security Center (DESC)**: Standards & Policies, https://www.desc.gov.ae/regulations/standards-policies/
- **Telecommunications and Digital Government Regulatory Authority (TDRA)**: DGOSI Framework, https://u.ae/en/about-the-uae/uae-competitiveness/Digital-Government-Online-Services-Index-DGOSI
- **UAE Design System**: Getting Started & Assessment, https://designsystem.gov.ae/docs/getting-started
- **Central Bank of the UAE (CBUAE)**: Consumer Protection Regulation, https://rulebook.centralbank.ae/en/rulebook/article-6-protection-consumer-data-and-assets
- **Dubai Health Authority (DHA)**: NABIDH Information Security Standards, https://dha.gov.ae/uploads/102022/NABIDH%20Policies%20&%20Standards%20-Information%20Security%20Standards20221021940.pdf
- **MDPI**: The Agile PMO Paradox: Embracing DevOps in the UAE, https://www.mdpi.com/2674-113X/4/4/24
- **Infosysta**: Digital Transformation at Smart Dubai, https://infosysta.com/case-studies/digital-transformation-project-task/

**Checklist Status**:
- Runtime checklist path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a1fce3e/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a1fce3e/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a1fce3e/TOOL_RESULTS.md`
- Research child tool results lines: `2353`
- Research child tool results bytes: `116684`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a1fce3e/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
