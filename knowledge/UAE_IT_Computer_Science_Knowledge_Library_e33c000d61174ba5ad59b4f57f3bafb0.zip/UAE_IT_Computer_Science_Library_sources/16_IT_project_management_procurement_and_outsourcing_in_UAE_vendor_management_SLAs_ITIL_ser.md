# Source Packet 16: IT project management, procurement and outsourcing in UAE: vendor management, SLAs, ITIL, service management, managed services, contracts and government procurement

# IT Project Management, Procurement, and Outsourcing in the UAE

## Domain Scope
IT Project Management (PM), procurement, and outsourcing in the United Arab Emirates (UAE) constitute the operational backbone of the nation's "Digital UAE" and "Smart Dubai" initiatives. This domain encompasses the lifecycle of acquiring, managing, and delivering technology services and infrastructure within a highly regulated environment.

*   **Technical Domain**: Integration of ITIL-based service management, structured project management (PMO), and digital-first procurement workflows.
*   **UAE Relevance**: The UAE government has transitioned to a "Digital by Default" model, necessitating rigorous vendor management and service level agreements (SLAs) to ensure the reliability of critical national infrastructure.
*   **Business/Government Use Cases**:
    *   **Federal Government**: Centralized procurement via the Ministry of Finance's Digital Procurement Platform.
    *   **Dubai Government**: Shared services and infrastructure managed by Digital Dubai and the Dubai Electronic Security Center (DESC).
    *   **Regulated Sectors**: Finance (CBUAE), Healthcare (DHA/DoH), and Energy, where outsourcing is subject to strict data residency and security controls.
*   **Boundaries**: This shard focuses on the administrative and governance layers of IT, excluding the underlying code development but including the frameworks that govern its delivery and maintenance.

## UAE Legal, Regulatory, and Policy Context
The UAE has modernized its procurement and IT governance laws to align with global best practices while maintaining national security and data sovereignty.

*   **Federal Decree-Law No. 11 of 2023 on Procurement**: This law, effective December 1, 2023, sets the general framework for all federal entities (ministries, authorities, and subsidiaries). It aims to enhance "integrity, trust, transparency and competitiveness" (u.ae, https://u.ae/en/information-and-services/business/public-private-people-partnership/ppp/government-tendering-and-awarding).
*   **Dubai Information Security Regulation (ISR) v2.0/v3.1**: Issued by the Dubai Electronic Security Center (DESC), this regulation is mandatory for all Dubai government entities. It includes 13 domains, with specific focus on **Domain 12 (Operations)** and **Domain 13 (Assurance)**, which mandate security controls for third-party service providers and outsourcing (DESC, https://www.desc.gov.ae/regulations/standards-policies/).
*   **Abu Dhabi Law No. 1 of 2017**: Governs the financial system and procurement for the Abu Dhabi government, managed through the Abu Dhabi Government Procurement Gate (ADGPG).
*   **Data Residency and Privacy**: The UAE Data Office and sector-specific regulators (like the Central Bank) enforce strict data localization. For instance, "The NCA’s Cloud Cybersecurity Controls require data residency to be technically enforced, not just contracted" (Usetech, https://usetech.com/blog/sovereign-cloud-in-gcc-the-architecture-behind-data-stays-here/).
*   **TDRA IT Service Management System Policy**: The Telecommunications and Digital Government Regulatory Authority (TDRA) mandates an IT Service Management System (ITSMS) for federal ICT services, ensuring compliance with statutory and contractual requirements (TDRA, https://tdra.gov.ae/-/media/About/Management-Systems-Policies/EN/IT-Service-Management-system-Policy.ashx).

## Core Concepts and Theory
Practitioners in the UAE must master the intersection of international frameworks and local digital platforms.

*   **ITIL (Information Technology Infrastructure Library)**: Widely adopted across UAE government entities (e.g., TDRA, DEWA) for service strategy, design, transition, and operation.
*   **Managed Services vs. Outsourcing**: In the UAE context, managed services often involve local cloud providers (G42, Moro Hub) to satisfy data residency, whereas outsourcing may involve global vendors (Microsoft, AWS) operating within UAE-based data centers.
*   **Digital Procurement Cycle**: The transition from manual tendering to fully electronic cycles. The Federal Procurement Catalogue, for example, "helps speed up procurement procedures and improve efficiency, reducing the purchasing process from 60 days to around 6 minutes" (u.ae, https://u.ae/en/information-and-services/business/public-private-people-partnership/ppp/government-tendering-and-awarding).

## Architectures, Patterns, and Workflows
### Digital Procurement Workflow (Federal)
1.  **Supplier Registration**: Mandatory registration in the Federal Supplier Register via the Ministry of Finance.
2.  **Tendering**: Conducted through the Digital Procurement Platform, connecting federal entities with registered suppliers.
3.  **Awarding**: Automated evaluation and awarding based on technical and financial proposals.
4.  **Punchout Catalogue**: A feature allowing entities to browse supplier stores directly and return to the government platform for approval (MoF, https://mof.gov.ae/en/public-finance/government-procurement/federal-government-procurement-procedures-guide/).

### Project Management Office (PMO) Models
*   **Supportive PMO**: Consultative role, providing templates and training.
*   **Controlling PMO**: Enforces compliance with specific frameworks (common in UAE infrastructure and government).
*   **Directive PMO**: Takes direct ownership of projects (Institute of Project Management, https://instituteprojectmanagement.com/blog/pmo-in-dubai-careers-salaries-certifications-2026/).

## Standards, Frameworks, and Best Practices
*   **ISO/IEC 20000**: The international standard for IT service management, often the basis for UAE government ITSMS policies.
*   **DESC Cloud Service Provider (CSP) Security Standard**: Sets mandatory controls for CSPs serving Dubai government entities (Digital Dubai, https://www.digitaldubai.ae/docs/default-source/digital-regulations/cyber/standard/csp-security-standard-(updated-jan-2020).pdf?sfvrsn=37a6a604_2).
*   **Green Procurement Policy (Dubai)**: Focuses on four categories, including **Information Technology devices**, to reduce environmental footprint and stimulate local supply chains (u.ae, https://u.ae/en/information-and-services/business/public-private-people-partnership/ppp/government-tendering-and-awarding).

## Technical Tactics and Implementation Details
*   **SLA Tiers and Response Times**:
    *   **Critical Services**: Often require 99.95% availability (e.g., Transportation Authority).
    *   **General Inquiries**: Typically answered within 24 hours.
    *   **Escalated Issues**: Resolved within 48 hours (SLA Development Guide for UAE Media Industry, https://static1.squarespace.com/static/663cb3699d4c9b53251f7722/t/671dd5cebd0abe4f6825ec38/1730008527781/Service+Level+Agreement+%28SLA%29+Development+Guide+for+the+UAE+Media+Industry.pdf).
*   **Contractual Clauses**:
    *   **Right to Audit**: Mandatory in technology outsourcing to ensure compliance with DESC/TDRA standards.
    *   **Exit Strategy**: Must be technically and legally defined to prevent vendor lock-in and ensure data portability (Legal 500, https://www.legal500.com/guides/hot-topic/uae-technology-outsourcing-legal-and-regulatory-overview/).
    *   **Data Residency Enforcement**: Technical controls (e.g., geo-fencing, local encryption keys) to ensure data does not leave the UAE.

## Measurement, KPIs, and Operational Metrics
*   **Digitisation Rate**: Dubai government services reached a digitisation rate of **99.5%** as of 2025/2026 (Samena Council, https://www.samenacouncil.org/samena_daily_news?news=97197).
*   **Paperless Compliance**: Dubai achieved **100%** paperless government objective (Digital Dubai, https://mediaoffice.ae/en/news/2023/september/06-09/dubai-digital-transformation).
*   **Cybersecurity Indicators**: Dubai government entities recorded a compliance rate of over **80%** with cybersecurity indicators (Media Office, https://mediaoffice.ae/en/news/2023/september/06-09/dubai-digital-transformation).
*   **Procurement Efficiency**: Reduction in purchasing cycle from **60 days to 6 minutes** via the Federal Procurement Catalogue (u.ae, https://u.ae/en/information-and-services/business/public-private-people-partnership/ppp/government-tendering-and-awarding).

## UAE Sector Use Cases and Localization Notes
*   **Government**: Use of the **Smart Projects Management System (SPMS)** by Digital Dubai to track and manage all government-wide digital initiatives.
*   **Healthcare**: Collaboration between DESC and Dubai Health Authority (DHA) on the **Biomedical Device (BMD) Security Standard** to protect connected medical equipment (DESC, https://www.desc.gov.ae/regulations/standards-policies/).
*   **Finance**: Central Bank of the UAE (CBUAE) mandates specific outsourcing regulations for financial institutions, focusing on operational resilience and data privacy.
*   **Localization**: Procurement platforms (eSupply, ADGPG) are fully bilingual (Arabic/English) and integrated with UAE PASS for secure authentication.

## Professional Practice and Checklists
### IT Procurement Checklist for UAE Practitioners
*   [ ] **Supplier Registration**: Verify vendor is active in the Federal Supplier Register or relevant Emirate portal (eSupply/ADGPG).
*   [ ] **Data Residency**: Confirm the solution hosts all regulated data within UAE borders (e.g., Azure UAE North, AWS UAE Region).
*   [ ] **DESC/ISR Compliance**: For Dubai entities, ensure the vendor meets ISR v2.0/v3.1 controls.
*   [ ] **SLA Alignment**: Match service levels to the criticality of the business process (e.g., 99.95% for public-facing digital services).
*   [ ] **Exit Strategy**: Document the technical process for data extraction and service transition at contract end.
*   [ ] **Local Content**: Evaluate the "Local Content" score in Abu Dhabi procurement to support the local economy (EAD, https://ead.gov.ae/-/media/Project/EAD/EAD/Supplier-Registration/Guide-to-Local-Content-in-Government-Procurement---First-Edition---English.pdf).

## Sources
### Primary Sources
*   **UAE Government Portal (u.ae)**: "Government tendering and awarding", https://u.ae/en/information-and-services/business/public-private-people-partnership/ppp/government-tendering-and-awarding
*   **Ministry of Finance (MoF)**: "Federal Government Procurement Procedures Guide", https://mof.gov.ae/en/public-finance/government-procurement/federal-government-procurement-procedures-guide/
*   **Dubai Electronic Security Center (DESC)**: "Standards & Policies", https://www.desc.gov.ae/regulations/standards-policies/
*   **Telecommunications and Digital Government Regulatory Authority (TDRA)**: "IT Service Management system Policy", https://tdra.gov.ae/-/media/About/Management-Systems-Policies/EN/IT-Service-Management-system-Policy.ashx
*   **Digital Dubai**: "CSP Security Standard", https://www.digitaldubai.ae/docs/default-source/digital-regulations/cyber/standard/csp-security-standard-(updated-jan-2020).pdf?sfvrsn=37a6a604_2

### Secondary Sources
*   **Legal 500**: "UAE: Technology Outsourcing – Legal and Regulatory Overview", https://www.legal500.com/guides/hot-topic/uae-technology-outsourcing-legal-and-regulatory-overview/
*   **Institute of Project Management**: "PMO in Dubai: Careers, Salaries & Certifications 2026", https://instituteprojectmanagement.com/blog/pmo-in-dubai-careers-salaries-certifications-2026/
*   **Usetech**: "Sovereign Cloud in GCC: The Architecture Behind 'Data Stays Here'", https://usetech.com/blog/sovereign-cloud-in-gcc-the-architecture-behind-data-stays-here/

## Gaps and Verification Notes
*   **Specific Penalty Figures**: While financial penalties are mentioned (e.g., for satisfaction below 85% in media), specific liquidated damages for IT downtime in federal contracts are often kept in confidential tender documents and not published in general guides.
*   **ISR v3.1 Full Text**: Publicly available summaries focus on v2.0; v3.1 details are often distributed directly to government entities via secure portals.
*   **Managed Services Pricing**: Live market pricing for managed services in the UAE is highly volatile and subject to individual framework agreements.

---
**Checklist Status Summary**:
Runtime checklist path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/afcb9ece/RESEARCH_CHECKLIST.md`
All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/afcb9ece/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/afcb9ece/TOOL_RESULTS.md`
- Research child tool results lines: `1641`
- Research child tool results bytes: `95033`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/afcb9ece/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
