# Source Packet 14: FinTech, payments, blockchain and digital assets technology in UAE: CBUAE, VARA, ADGM/FSRA, DIFC, open finance, payment security and compliance engineering

# FinTech, Payments, and Digital Assets Technology in the UAE

This research document provides a comprehensive technical and regulatory overview of the FinTech, payments, blockchain, and digital assets landscape in the United Arab Emirates as of July 2026.

## Domain Scope
The UAE FinTech and digital assets domain encompasses the engineering, regulation, and operation of digital financial services, including retail and wholesale payment systems, open finance frameworks, and virtual asset ecosystems. The domain is characterized by a "tri-regulatory" model: federal oversight by the Central Bank of the UAE (CBUAE), and independent financial free-zone regulation in the Abu Dhabi Global Market (ADGM) and Dubai International Financial Centre (DIFC), alongside the specialized Virtual Assets Regulatory Authority (VARA) in Dubai.

**Typical Use Cases:**
*   **Cross-Border Settlement:** Utilizing multi-CBDC platforms like Project mBridge for near-instant wholesale transactions.
*   **Retail Payments:** Integration of the Digital Dirham into consumer wallets and the Wages Protection System (WPS).
*   **Open Finance:** Secure sharing of customer data between banks and third-party providers (TPPs) via a centralized API hub.
*   **Digital Asset Custody:** Institutional-grade storage and management of virtual assets under VARA or FSRA/DFSA regimes.

## UAE Legal, Regulatory, and Policy Context
The UAE has established one of the world's most advanced regulatory frameworks for digital finance, transitioning from "crypto-friendly" to "compliance-first" by 2026.

### Federal Regulations (CBUAE)
*   **Retail Payment Services and Card Schemes Regulation (Circular 15/2021):** Defines nine categories of licensed payment services, including payment account issuance, merchant acquiring, and payment initiation services. (Source: CBUAE Rulebook, https://rulebook.centralbank.ae/en/rulebook/retail-payment-services-and-card-schemes-regulation)
*   **Open Finance Regulation (Circular 03/2025):** Mandates participation for all banks and insurance companies in a phased rollout. It establishes a "Trust Framework" and a centralized "API Hub" for secure data sharing. (Source: CBUAE Rulebook, https://rulebook.centralbank.ae/en/rulebook/open-finance-regulation)
*   **Payment Token Services Regulation (Circular 02/2024):** Regulates the issuance and conversion of "Dirham Payment Tokens" (fiat-referenced tokens/stablecoins). It prohibits algorithmic stablecoins and privacy tokens. (Source: CBUAE Rulebook, https://rulebook.centralbank.ae/en/rulebook/payment-token-services-regulation)

### Emirate-Level and Free Zone Regulations
*   **VARA (Dubai):** Operates under Law No. 4 of 2022. The 2026 Rulebook updates integrate technology risk as a "compliance core," requiring regular vulnerability testing and 24-hour incident reporting. (Source: VARA Rulebook, https://rulebooks.vara.ae/node/12)
*   **ADGM FSRA:** The Digital Assets Framework (updated June 2025) includes DeFi protocol operators and refined "Accepted Virtual Asset" (AVA) criteria. (Source: ADGM, https://www.adgm.com/media/announcements/adgm-fsra-presents-key-enhancements-to-its-digital-assets-framework-at-abu-dhabi-finance-week-2025)
*   **DIFC DFSA:** The Crypto Token Regime (updated January 2026) shifted from a "Recognised List" to a firm-led "Suitable Crypto Token" framework, placing the onus of risk assessment on the licensed firm. (Source: DFSA, https://www.dfsa.ae/crypto)

## Core Concepts and Theory
### Central Bank Digital Currency (CBDC)
The **Digital Dirham** is a sovereign digital currency issued by the CBUAE. It is designed for retail, wholesale, and cross-border use.
> "The Digital Dirham will be introduced in a phased approach... facilitating efficient, cost-effective, and instant cross-border payment and settlement in central bank money." — CBUAE CBDC Report, https://www.centralbank.ae/media/qw1ex32h/cbdc-long-report_july.pdf

### Distributed Ledger Technology (DLT)
The UAE utilizes DLT for wholesale settlement (mBridge) and virtual asset tracking. Technical implementations often favor permissioned ledgers (e.g., Hyperledger Fabric or R3 Corda) for regulatory compliance and privacy.

### Open Finance Trust Framework
A technical and legal structure that ensures all participants (Data Holders and Service Initiators) are verified and adhere to standardized security protocols.

## Architectures, Patterns, and Workflows
### Project mBridge Architecture
mBridge is a multi-CBDC platform built on a custom DLT (the "mBridge Ledger") that enables "atomic" (simultaneous) settlement of cross-border transactions.
*   **Workflow:** A commercial bank in the UAE issues a payment instruction -> The CBUAE validates the Digital Dirham liquidity -> The mBridge Ledger executes the swap with another CBDC (e.g., e-CNY) -> Settlement is completed in under two minutes. (Source: BIS Innovation Hub, https://www.bis.org/about/bisih/topics/cbdc/mcbdc_bridge.htm)

### Open Finance API Hub
The CBUAE operates a centralized API Hub to reduce fragmentation.
*   **Pattern:** RESTful APIs using JSON payloads.
*   **Security:** FAPI 2.0 (Financial-grade API) compliant, utilizing OAuth 2.0 and OpenID Connect (OIDC) for authorization. (Source: Ozone API / CBUAE, https://ozoneapi.com/the-open-finance-tracker/library/cbuae/)

## Standards, Frameworks, and Best Practices
*   **PCI DSS 2026:** Mandatory for all entities handling card data in the UAE. (Source: ValueMentor, https://valuementor.com/blogs/pci-dss-compliance-in-the-uae-requirements-for-banks-fintechs-in-2026)
*   **DESC ISR (Information Security Regulation):** Mandatory for Dubai government and semi-government entities, often adopted as a best practice by private FinTechs. (Source: DESC, https://www.linkedin.com/pulse/how-threat-intelligence-supports-uae-compliance-nesa-cxosc)
*   **NESA NIAF:** The National Electronic Security Authority's framework for critical infrastructure, including financial systems.
*   **Elimination of SMS OTPs:** By March 2026, CBUAE-regulated entities must transition away from SMS/email-based OTPs toward more secure MFA methods (e.g., biometrics or hardware tokens). (Source: Gulf Business, https://www.facebook.com/GulfBusiness/posts/1960939744806158/)

## Technical Tactics and Implementation Details
### Payment Security Controls
*   **End-to-End Encryption (E2EE):** Required for all retail payment user passwords from the mobile app/browser to the verification system.
*   **Session Management:** Mandatory time-out controls and limits on failed login attempts. (Source: CBUAE Rulebook Art. 13, https://rulebook.centralbank.ae/en/rulebook/article-13-technology-risk-and-information-security)

### Virtual Asset Custody
*   **Independent Legal Entity:** VASPs providing custody in Dubai must operate as an independent legal entity from other group activities. (Source: Lexology, https://www.lexology.com/library/detail.aspx?g=8baf101d-8b52-49da-8481-ab039ba01927)
*   **Wallet Management:** Strict requirements for cryptographic key management, including multi-signature (Multi-Sig) or Multi-Party Computation (MPC) for hot and cold wallets.

## Measurement, KPIs, and Operational Metrics
*   **Transaction Latency:** mBridge targets cross-border settlement in < 2 minutes (vs. 3-5 days for traditional SWIFT).
*   **Incident Reporting:** Material cybersecurity incidents must be reported to VARA within 24 hours. (Source: VARA, https://www.linkedin.com/pulse/vara-cybersecurity-requirements-crypto-exchanges-uae-itsecnow-e7hzf)
*   **Uptime:** Financial institutions typically target "five nines" (99.999%) availability for core payment gateways.

## UAE Sector Use Cases and Localization Notes
*   **Wages Protection System (WPS):** A mandatory electronic salary transfer system. Payment Service Providers (PSPs) must be licensed by CBUAE to participate.
*   **Emirates ID Integration:** Increasing use of Emirates ID for biometric authentication in FinTech apps and at ATMs.
*   **Arabic/English UX:** Regulatory requirement for clear disclosure in both languages for retail financial products.

## Professional Practice and Checklists
### Compliance Gap Analysis Checklist for UAE FinTechs
1.  [ ] Identify regulatory nexus (CBUAE vs. VARA vs. ADGM/DIFC).
2.  [ ] Verify license category (e.g., RPSCS Category 1-4).
3.  [ ] Audit MFA implementation (ensure removal of SMS OTP by March 2026).
4.  [ ] Review data residency (ensure compliance with UAE Data Law and CBUAE outsourcing rules).
5.  [ ] Establish 24/7 incident response and regulatory notification workflow.

## Source Links
### Primary Sources
*   **CBUAE Rulebook - Retail Payment Services:** https://rulebook.centralbank.ae/en/rulebook/retail-payment-services-and-card-schemes-regulation
*   **CBUAE Rulebook - Open Finance:** https://rulebook.centralbank.ae/en/rulebook/open-finance-regulation
*   **CBUAE Rulebook - Payment Token Services:** https://rulebook.centralbank.ae/en/rulebook/payment-token-services-regulation
*   **VARA Rulebook - Technology and Information:** https://rulebooks.vara.ae/rulebook/technology-and-information-rulebook
*   **CBUAE CBDC Working Paper (July 2025):** https://www.centralbank.ae/media/qw1ex32h/cbdc-long-report_july.pdf
*   **DFSA Crypto Token Regulation:** https://www.dfsa.ae/crypto

### Secondary Sources
*   **BIS mBridge Project Page:** https://www.bis.org/about/bisih/topics/cbdc/mcbdc_bridge.htm
*   **Ocorian - UAE Digital Asset Guide:** https://www.ocorian.com/knowledge-hub/insights/scaling-digital-asset-businesses-uae-balanced-guide-adgm-difc-and-vara
*   **Pinsent Masons - Open Finance Guide:** https://www.pinsentmasons.com/out-law/guides/uae-open-finance

## Gaps and Verification Notes
*   **mBridge Retail Launch:** While the MVP for wholesale is live, the exact timeline for full retail integration of the Digital Dirham into private wallets is subject to phased CBUAE announcements.
*   **Open Finance Phase 2:** The specific onboarding dates for non-bank entities (e.g., exchange houses, fintechs) in the Open Finance framework are yet to be finalized by the CBUAE.
*   **VARA 2026 Enforcement:** The full impact of the 2026 "Technology Risk" core compliance updates on smaller VASPs is currently being monitored by industry analysts.

---
**Checklist Status Summary:**
Checklist file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/c8b25f70/RESEARCH_CHECKLIST.md`
All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/c8b25f70/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/c8b25f70/TOOL_RESULTS.md`
- Research child tool results lines: `1190`
- Research child tool results bytes: `88692`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/c8b25f70/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
