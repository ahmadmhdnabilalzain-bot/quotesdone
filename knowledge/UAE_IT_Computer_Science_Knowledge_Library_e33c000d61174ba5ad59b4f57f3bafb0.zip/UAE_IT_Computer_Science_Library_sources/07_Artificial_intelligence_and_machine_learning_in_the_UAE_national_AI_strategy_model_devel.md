# Source Packet 7: Artificial intelligence and machine learning in the UAE: national AI strategy, model development, MLOps, generative AI, responsible AI, use cases and governance

# Artificial Intelligence and Machine Learning in the UAE: Research Report

## Domain Scope
The Artificial Intelligence (AI) and Machine Learning (ML) domain in the UAE is defined by a centralized national vision to transition from a resource-based economy to a knowledge-based, AI-driven global hub. The scope encompasses the full lifecycle of AI—from foundational research and large-scale model development (LLMs) to MLOps, generative AI, and responsible governance.

**UAE Relevance & Use Cases:**
- **Government Services:** 100% reliance on AI for government services and data analysis by 2031.
- **Energy:** Optimization of oil and gas production and transition to renewables (e.g., ADNOC's Panorama).
- **Healthcare:** Genomics and personalized medicine (e.g., G42 Healthcare).
- **Finance:** Fraud detection, credit scoring, and automated compliance (CBUAE guidelines).
- **Logistics:** Smart ports and autonomous supply chains (DP World).

**Boundaries:** The domain is bounded by the **UAE National Strategy for Artificial Intelligence 2031**, which prioritizes eight sectors: resources/energy, logistics, tourism, healthcare, cybersecurity, and government efficiency.

## UAE Legal, Regulatory, and Policy Context
The UAE has established a robust policy framework to govern AI development, balancing innovation with ethical safeguards.

**Key Laws and Regulators:**
- **Federal Decree-Law No. 45 of 2021 (Personal Data Protection Law - PDPL):** The primary federal law governing data privacy. 
  - **Article 18 (Automated Processing):** "A Data Subject shall have the right to object to automated decision-making that have legal implications or seriously affect the Data Subject, including Profiling." — *Federal Decree-Law No. 45 of 2021, https://armingaud-avocat.fr/en/federal-decree-law-no-45-of-2021-on-personal-data-protection/*
- **UAE AI Office:** Led by the Minister of State for Artificial Intelligence, Digital Economy, and Remote Work Applications. It oversees the National AI Strategy 2031.
- **UAE AI Ethics Guide (December 2022):** A national framework providing non-binding ethical principles: fairness, transparency, accountability, and safety.
- **Digital Dubai AI Ethics Principles:** Focuses on four sub-principles: Fairness, Accountability, Transparency, and Explainability.
  - "AI systems should be fair, transparent, accountable and understandable." — *Digital Dubai AI Ethics, https://www.digitaldubai.ae/docs/default-source/ai-principles-resources/ai-ethics.pdf*

**Compliance Workflows:**
- **AI Ethics Self-Assessment:** Organizations are encouraged to use the Digital Dubai Self-Assessment Tool to evaluate "significant" and "critical" decisions made by AI.
- **Data Residency:** Sensitive government and health data are subject to strict residency requirements, often requiring hosting on sovereign clouds like G42/Microsoft Azure UAE regions.

## Core Concepts and Theory
Practitioners in the UAE must master both global AI theory and local foundational models.

**Foundational Models:**
- **Falcon LLM (TII):** A series of high-performance open-source models. Falcon 180B is a causal decoder-only model trained on 3.5 trillion tokens.
  - "Falcon-180B is a 180B parameters causal decoder-only model built by TII and trained on 3,500B tokens of RefinedWeb enhanced with curated corpora." — *Hugging Face, https://huggingface.co/tiiuae/falcon-180B*
- **Jais (Inception/G42/MBZUAI):** The world's leading Arabic-centric LLM. Jais 2 (70B) features a redesigned architecture for better reasoning in Modern Standard Arabic and dialects.
  - "Jais 2... Built from the ground up with 70 billion parameters and trained on the richest Arabic-first dataset to date." — *PR Newswire, https://www.prnewswire.com/ae/news-releases/inception-cerebras-and-mbzuai-release-jais-2--the-next-generation-of-the-worlds-leading-arabic-open-weight-llm-302636745.html*

**Infrastructure:**
- **Condor Galaxy:** A global network of AI supercomputers developed by G42 and Cerebras. Condor Galaxy 1 (CG-1) offers 4 exaFLOPs of compute.
  - "Condor Galaxy 1 (CG-1), a 4 exaFLOP, 54 million core, cloud-based AI supercomputer." — *G42, https://www.g42.ai/resources/news/g42-and-cerebras-unveil-worlds-largest-supercomputer-ai-training*

## Architectures, Patterns, and Workflows
**MLOps in the UAE Context:**
- **Toolchains:** Integration of open-source tools (MLflow, Kubeflow) with regional cloud providers. The G42 and Microsoft partnership enables MLOps on Azure UAE regions with sovereign data controls.
- **Sovereign AI Architecture:** Deployment patterns that utilize local data centers for training and inference to comply with PDPL and sector-specific regulations.
- **Workflow Example:**
  1. Data ingestion from local sources (e.g., UAE health records).
  2. Pre-processing using UAE-specific tokenizers (for Arabic NLP).
  3. Training on Condor Galaxy or Azure UAE.
  4. Deployment with monitoring for "drift" and "bias" as per Digital Dubai guidelines.

## Standards, Frameworks, and Best Practices
- **Dubai AI Ethics Toolkit:** Provides a practical framework for ethical AI design, including a self-assessment tool.
- **CBUAE Enabling Technologies Guidelines:** Section 3 provides specific guidance for AI in finance, emphasizing that "The Governing Body and Senior Management... should remain accountable for the outcomes and decisions of their AI Applications." — *CBUAE, https://rulebook.centralbank.ae/sites/default/files/en_net_file_store/CBUAE_EN_2413_VER1.pdf*
- **Global Alignment:** UAE frameworks are designed to complement international standards like UNESCO’s AI ethics recommendation and NIST AI Risk Management Framework.

## Technical Tactics and Implementation Details
- **Arabic NLP:** Use of specialized tokenizers and datasets (e.g., RefinedWeb-Arabic) to handle the morphological complexity of the Arabic language.
- **Distributed Training:** Falcon 180B utilized a custom codebase named **Gigatron**, employing 3D parallelism and Triton kernels for efficiency on A100 clusters.
  - "It used a custom distributed training codebase named Gigatron, which uses 3D parallelism with ZeRO, and custom, high-performance Triton kernels." — *AWS Blog, https://aws.amazon.com/blogs/machine-learning/falcon-180b-foundation-model-from-tii-is-now-available-via-amazon-sagemaker-jumpstart/*
- **Bias Mitigation:** Implementation of "fairness-aware" algorithms that audit datasets for representation of the diverse UAE population (200+ nationalities).

## Measurement, KPIs, and Operational Metrics
**National Strategy Targets:**
- **Economic Growth:** Generate up to **AED 335 billion** in extra growth by 2031.
- **Productivity:** Aim for a **26% increase** in economic output through AI automation.
- **Global Leadership:** Position the UAE among the top nations in the Global AI Index.

**Operational Metrics:**
- **Model Performance:** Perplexity and BLEU scores for Arabic translation/generation.
- **Governance Metrics:** Percentage of AI systems passing the Dubai AI Ethics Self-Assessment.
- **Infrastructure:** ExaFLOPs of available compute capacity (Target: 36 exaFLOPs via Condor Galaxy).

## UAE Sector Use Cases and Localization Notes
- **Energy (ADNOC):** The **Panorama Digital Command Centre** tracks 250,000 real-time data points to optimize production and sustainability.
  - "ADNOC tracks over 250,000 data points in real-time... displaying the information on a 55 m × 4 m COB." — *Q-SYS Case Study, https://www.qsys.com/resource-files/casestudies/q_cs_adnoc.pdf*
- **Localization:** AI systems must support "code-switching" (mixing Arabic and English), a common linguistic pattern in the UAE. Jais 2 is specifically engineered for this.
- **Smart Cities:** Dubai's AI Lab integrates AI into city services, from traffic management to "U.Ask" (government AI assistant).

## Professional Practice and Checklists
**Practitioner Checklist for UAE AI Deployment:**
- [ ] **Regulatory Check:** Does the system comply with PDPL Article 18 regarding automated decisions?
- [ ] **Ethics Audit:** Has the Digital Dubai AI Ethics Self-Assessment been completed?
- [ ] **Data Residency:** Is sensitive data stored within UAE borders (e.g., Azure UAE, G42 Cloud)?
- [ ] **Linguistic Accuracy:** If customer-facing, does the model handle Modern Standard Arabic and local dialects (Khaleeji)?
- [ ] **Accountability:** Is there a named human officer accountable for the AI's decisions (as per CBUAE guidelines)?

## Sources
- **UAE National Strategy for Artificial Intelligence 2031**, https://staticcdn.mbzuai.ac.ae/mbzuaiwpprd01/2022/07/UAE-National-Strategy-for-Artificial-Intelligence-2031.pdf (Primary)
- **Digital Dubai AI Ethics Principles & Guidelines**, https://www.digitaldubai.ae/docs/default-source/ai-principles-resources/ai-ethics.pdf (Primary)
- **Federal Decree-Law No. 45 of 2021 on Personal Data Protection**, https://armingaud-avocat.fr/en/federal-decree-law-no-45-of-2021-on-personal-data-protection/ (Primary)
- **CBUAE Guidelines for Financial Institutions Adopting Enabling Technologies**, https://rulebook.centralbank.ae/sites/default/files/en_net_file_store/CBUAE_EN_2413_VER1.pdf (Primary)
- **G42 News: Condor Galaxy Supercomputer**, https://www.g42.ai/resources/news/g42-and-cerebras-unveil-worlds-largest-supercomputer-ai-training (Primary)
- **Falcon 180B Technical Details (AWS)**, https://aws.amazon.com/blogs/machine-learning/falcon-180b-foundation-model-from-tii-is-now-available-via-amazon-sagemaker-jumpstart/ (Secondary)
- **Jais 2 Release (PR Newswire)**, https://www.prnewswire.com/ae/news-releases/inception-cerebras-and-mbzuai-release-jais-2--the-next-generation-of-the-worlds-leading-arabic-open-weight-llm-302636745.html (Secondary)

## Gaps and Verification Notes
- **Executive Regulations for PDPL:** While the law is active, specific executive regulations detailing fine structures and enforcement mechanisms for AI-specific breaches are still evolving as of mid-2026.
- **Specific KPI Progress:** While the 2031 targets are clear, real-time dashboards for the "AED 335 billion" growth target are not publicly accessible; progress is typically reported in annual government reviews.
- **VARA AI Guidelines:** Specific AI-related guidelines for Virtual Assets (VARA) are in development and should be verified for crypto-AI projects.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/9430e2ba/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/9430e2ba/TOOL_RESULTS.md`
- Research child tool results lines: `2266`
- Research child tool results bytes: `129837`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/9430e2ba/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
