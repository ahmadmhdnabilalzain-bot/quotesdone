# Source Packet 17: Education, certifications and talent pathways: UAE computer science education, coding schools, professional certifications, career paths, hiring standards and competency frameworks

# UAE IT Education, Certifications, and Talent Pathways Research Report

## Domain Scope
The UAE IT education and talent domain encompasses the full lifecycle of technology professional development, from formal higher education and non-traditional coding academies to professional certifications and government-led talent attraction strategies. It is a critical pillar of the **UAE Digital Economy Strategy**, which aims to double the digital economy's contribution to the UAE's non-oil GDP from 11.7% to over 20% by 2032.

**Key Boundaries:**
- **Higher Education:** Accredited universities offering CS, AI, and Cybersecurity degrees.
- **Alternative Pathways:** Tuition-free coding schools (e.g., 42 Abu Dhabi) and bootcamps.
- **Professional Development:** Government-backed academies (TDRA Academy) and industry-standard certifications.
- **Talent Regulation:** Competency frameworks (SFIA, FAHR) and residency incentives (Golden Visa for Coders).

## UAE Legal, Regulatory, and Policy Context
The UAE has established a robust policy framework to institutionalize tech talent development:

- **National Program for Coders:** Launched in 2021, this initiative aims to attract and train **100,000 coders** and establish **1,000 major digital companies** within five years. It provides the **Golden Visa** to 100,000 of the world's best coders.
  > "The goal is to train and attract 100,000 programmers and create 1,000 major digital companies within five years." — Sheikh Mohammed bin Rashid Al Maktoum, Khaleej Times, https://www.khaleejtimes.com/uae/sheikh-mohammed-launches-national-initiative-for-programmers
- **Emiratization (Nafis Program):** Private sector companies with 50+ employees must increase their Emirati workforce by 2% annually to reach **10% by 2026**. This includes specific targets for skilled IT roles.
  > "The aim of the Emiratisation requirements is to ensure that the private sector workforce comprises a minimum of 10% UAE nationals by 2026." — Taylor Wessing, https://www.taylorwessing.com/de/insights-and-events/insights/2022/10/uae-new-emiratisation-requirements-and-consequences-for-failing-to-comply
- **QFEmirates (National Qualifications Framework):** A 10-level framework managed by the **National Qualifications Authority (NQA)**. Level 7 corresponds to a Bachelor's degree, while Level 10 is a Doctorate.
  > "QFEmirates is based on three main features – Number of levels, range of learning outcomes at each level and a qualification structure... Level 10 – equivalent to a doctorate." — KHDA, https://www.khda.gov.ae/CMS/WebParts/TextEditor/Documents/Know_about_National_Qualifications_Framework_QAD_Book_02_Eng.pdf
- **DESC Cyber Force Program:** Mandatory for cybersecurity service providers to Dubai government entities. It requires individuals to hold DESC-approved certifications (e.g., CREST) to demonstrate competence.
  > "To provide certain cyber security services to the government in Dubai, service providers must demonstrate the competence of the individuals via certifications." — DESC Cyber Force Guidelines, https://www.crest-approved.org/wp-content/uploads/2023/08/desc-cyber-force-program-guidelines-v1-1.pdf?ver=1723136648

## Core Concepts and Theory
- **Peer-to-Peer Learning:** Pioneered by **42 Abu Dhabi**, this model removes teachers and traditional classes, focusing on collaborative problem-solving and project-based learning.
- **Competency-Based Education:** The UAE Federal Government uses the **FAHR Technical Competency Framework**, which defines 199 competencies across 20 job families, focusing on "knowledge, skills, and/or abilities required to fulfill job tasks."
- **Agentic AI:** A current focus of the UAE government, with a partnership between the **UAE Government** and **MBZUAI** to train **80,000 federal staff** in Agentic AI deployment.
  > "UAE Government partners with MBZUAI to train 80,000 federal staff in Agentic AI." — EdTech Innovation Hub, https://www.edtechinnovationhub.com/news/uae-government-partners-with-mbzuai-to-train-80000-federal-staff-in-agentic-ai

## Architectures, Patterns, and Workflows
- **Gamified Learning Path:** 42 Abu Dhabi utilizes a 21-level gamified system where students progress through themes like Software Development and AI Applications over 3-5 years.
- **Tiered Learning Journeys:** The **Abu Dhabi Digital Programme** (ADDA/ADSG/ADGMA) uses a three-level certification: **Awareness, Application, and Strategic**.
- **Skills-Based Hiring Workflow:** Transitioning from degree-centric to skills-centric hiring, supported by frameworks like **SFIA (Skills Framework for the Information Age)**, which is adopted by **Digital Dubai** to embed consistency in hiring and promotions.
  > "Technical Competency Framework across all departments, embedding consistency in hiring, development, and promotions." — Digital Dubai Authority, https://blog.stevieawards.com/hubfs/IBA25%20Gold%20Entry%20PDFs_new%20URL/462_Empowering%20Dubai%E2%80%99s%20Digital%20Future-%20Digital%20Dubai%20Authority%E2%80%99s%20Talent%20Management%20Ecosystem.pdf

## Standards, Frameworks, and Best Practices
- **SFIA (Skills Framework for the Information Age):** The global standard for digital skills, widely used in the UAE for defining roles in AI, data science, and cybersecurity.
- **FAHR Technical Competency Framework (2024):** Provides four proficiency levels: **Foundational, Intermediate, Advanced, and Expert**.
- **VARA Technology and Information Rulebook:** Sets competency standards for staff in Virtual Asset Service Providers (VASPs), requiring "Technology Governance and Risk Assessment Frameworks" that include staff competency objectives.
  > "VASPs must implement a technology governance and risk assessment framework... including the requirements for the competency of Staff." — VARA Rulebook, https://rulebooks.vara.ae/sites/default/files/en_net_file_store/VARA_EN_169_VER20250519.pdf

## Technical Tactics and Implementation Details
- **42 Abu Dhabi Level 6 Qualification:** Accredited as equivalent to a Bachelor's Degree in Software Development and AI Applications.
- **The "Piscine":** A 26-day intensive selection process for coding schools to test grit and logic rather than prior knowledge.
- **TDRA Academy (DGOV Academy):** Offers free certified courses in AI, Cybersecurity, and Digital Transformation for the public and government employees.
  > "DGOV Academy... offers FREE online courses with certificates in some of today's most in-demand fields." — LinkedIn/TDRA, https://www.linkedin.com/posts/alisha-sayed-52a1b2203_uae-freecourses-dgovacademy-activity-7477959992239726592-yH1y

## Measurement, KPIs, and Operational Metrics
- **Talent Volume:** Target of **100,000 coders** (National Program for Coders).
- **Company Creation:** Target of **1,000 digital companies** (National Program for Coders).
- **Emiratization Rate:** **10% by 2026** for private sector firms (Nafis).
- **Training Reach:** **15,000 coders** empowered in 6 months via Coders HQ initiatives.
- **Workforce Training:** **80,000 federal staff** to be trained in AI (MBZUAI partnership).

## UAE Sector Use Cases and Localization Notes
- **Government:** Focus on "Digital Transformation Leadership" and "Agentic AI" for civil servants.
- **Cybersecurity:** The **Cyber Pulse** initiative by the UAE Cybersecurity Council focuses on community-wide cyber literacy.
- **Finance/Crypto:** **VARA** and **ADGM** have specific competency requirements for IT and security personnel in regulated firms.
- **Education:** **MBZUAI** (Mohamed bin Zayed University of Artificial Intelligence) serves as a primary research and talent pipeline for AI, with graduates moving into roles at SpaceX and local entities like G42.

## Professional Practice and Checklists
### UAE Tech Hiring Checklist (Based on FAHR/DESC/VARA)
- [ ] **Competency Mapping:** Align job descriptions with the FAHR Technical Competency Framework or SFIA levels.
- [ ] **Certification Verification:** For cybersecurity roles, ensure candidates hold DESC-approved certifications (e.g., CISSP, CISM, CREST).
- [ ] **Emiratization Compliance:** Verify Nafis quota status and prioritize Emirati talent through the Nafis portal.
- [ ] **Residency Support:** Facilitate Golden Visa applications for top-tier coding talent under the National Program for Coders.
- [ ] **VARA/ADGM Compliance:** For regulated sectors, ensure the "Chief Information Security Officer" meets specific regulatory competency bars.

## Source Links
### Primary Sources
- **UAE Government Portal (u.ae):** [Online Training](https://u.ae/en/information-and-services/jobs/training-and-development/online-training), [Emiratisation](https://u.ae/en/information-and-services/jobs/employment-in-the-private-sector/emiratis-employment-in-private-sector)
- **TDRA Academy:** [DGOV Academy Services](https://dgov.tdra.gov.ae/services/dgov-academy)
- **Dubai Electronic Security Center (DESC):** [Cyber Force Guidelines](https://www.crest-approved.org/wp-content/uploads/2023/08/desc-cyber-force-program-guidelines-v1-1.pdf?ver=1723136648)
- **Virtual Assets Regulatory Authority (VARA):** [Technology and Information Rulebook](https://rulebooks.vara.ae/sites/default/files/en_net_file_store/VARA_EN_169_VER20250519.pdf)
- **Federal Authority for Government Human Resources (FAHR):** [Technical Competencies Framework](https://www.fahr.gov.ae/wp-content/uploads/2024/03/a542349e.pdf)
- **KHDA/NQA:** [QFEmirates Handbook](https://www.khda.gov.ae/CMS/WebParts/TextEditor/Documents/Know_about_National_Qualifications_Framework_QAD_Book_02_Eng.pdf)

### Secondary Sources
- **CIO.com:** [UAE Visa Programme for Coders](https://www.cio.com/article/189065/how-uaes-new-visa-programme-for-coders-helps-make-it-an-it-talent-magnet.html)
- **LinkedIn/Industry Reports:** [UAE Digital Talent Market Trends 2026](https://www.linkedin.com/posts/richard-smith-salt_been-a-while-so-thought-i-would-try-and-answer-activity-7460296671835508737-T4F7)

## Gaps and Verification Notes
- **SFIA Adoption Depth:** While Digital Dubai mentions SFIA, the exact extent of its adoption across all 7 levels in other emirates (like Abu Dhabi's ADDA) is less documented in public whitepapers.
- **Golden Visa Statistics:** While the target is 100,000, the current *actual* number of Golden Visas issued specifically to coders as of July 2026 is not publicly updated in real-time; [verify] with the Federal Authority for Identity and Citizenship (ICP).
- **VARA Competence Rulebook:** The specific "Competence" rulebook link was failing to load; details were inferred from the "Technology and Information Rulebook" which contains overlapping personnel requirements.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/04835d2d/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/04835d2d/TOOL_RESULTS.md`
- Research child tool results lines: `1924`
- Research child tool results bytes: `116496`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/04835d2d/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
