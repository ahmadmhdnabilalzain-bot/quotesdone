# Source Packet 5: Cloud computing and infrastructure in the UAE: AWS UAE, Microsoft UAE, Oracle, G42/Khazna, hybrid cloud, Kubernetes, serverless, data residency and cloud governance

# UAE Cloud Computing and Infrastructure Research Report (July 2026)

This report provides a comprehensive overview of the cloud computing landscape in the United Arab Emirates, focusing on major hyperscalers (AWS, Microsoft, Oracle), local sovereign providers (G42/Core42, Khazna), and the stringent regulatory environment governing data residency and cloud security.

## 1. Domain Scope
The UAE cloud domain is characterized by a "Cloud First" national strategy, aiming to transition government and private sector workloads to scalable, secure, and locally-hosted infrastructure.
- **Technical Boundaries**: Includes Public Cloud (Hyperscalers with UAE regions), Sovereign Cloud (Local jurisdictional control), Hybrid Cloud (On-premises integrated with public/private), and Cloud-Native technologies (Kubernetes, Serverless).
- **UAE Relevance**: Cloud is the foundational layer for the UAE's AI-native government ambitions, Smart City initiatives (Digital Dubai), and the "We the UAE 2031" vision.
- **Typical Use Cases**:
    - **Government**: FedNet (Federal Network) cloud services for inter-entity data exchange.
    - **Finance**: Sovereign financial clouds for transaction processing and AML compliance.
    - **Healthcare**: Unified patient records (Malaffi, Nabidh) hosted on compliant local infrastructure.
    - **AI/ML**: Training large language models (e.g., Jais) on sovereign GPU clusters.

## 2. UAE Legal, Regulatory, and Policy Context
The UAE has one of the most robust cloud regulatory frameworks in the region, centered on data sovereignty and cybersecurity.

### Key Regulators and Laws
- **TDRA (Telecommunications and Digital Government Regulatory Authority)**: Issues the **Cloud First Policy** and manages the **Cloud Service Provider (CLSP) Registration** initiative. (Source: TDRA, https://tdra.gov.ae/en/tdra-initiatives/cloud-service-provider)
- **DESC (Dubai Electronic Security Center)**: Mandates the **CSP Security Standard**, which is required for any provider serving Dubai government entities. (Source: DESC, https://www.desc.gov.ae/regulations/certifications/)
- **UAE Cybersecurity Council**: Oversees the **National Cybersecurity Strategy 2023–2026** and the **National Encryption Policy (2025)**, which includes post-quantum cryptography transition plans. (Source: PQShield, https://pqshield.com/uae-establishes-requirements-for-cryptographic-controls-and-migration-planning/)
- **UAE Data Office**: Enforces **Federal Decree-Law No. 45 of 2021 (PDPL)**, governing personal data protection and cross-border transfers.
- **CBUAE (Central Bank of the UAE)**: Issued the **Outsourcing Regulation** and **Consumer Protection Standards**, requiring financial institutions to store customer/transaction data within the UAE. (Source: CBUAE Rulebook, https://rulebook.centralbank.ae/en/rulebook/outsourcing)

### Data Classification Framework
The UAE National Data Classification Framework typically uses four levels:
1. **Open**: Publicly available data.
2. **Confidential**: Internal data with limited impact if leaked.
3. **Sensitive**: Data requiring high protection; must stay in-country.
4. **Secret**: Highly classified government data; requires sovereign cloud hosting.
(Source: HCT Open Data Policy, https://hct.ac.ae/wp-content/uploads/2024/02/hct_Open_data_policy.pdf)

## 3. Core Concepts and Theory
- **Data Residency vs. Sovereignty**: Residency ensures data is physically in the UAE; Sovereignty ensures it is subject only to UAE law and managed by local personnel.
- **Sovereign Cloud**: A model where the cloud provider offers a "region" that is operationally and legally isolated from global infrastructure.
- **Neocloud**: A term used by G42 to describe infrastructure that is sovereign, secure, and AI-optimized. (Source: LinkedIn, https://www.linkedin.com/posts/khaznadatacenters_wearekhazna-activity-7391777610931929088-TPY6)

## 4. Architectures, Patterns, and Workflows
### Hyperscale Regions in the UAE
- **AWS Middle East (UAE) Region**: Launched in 2022 with 3 Availability Zones. Supports local data residency for services like EC2, S3, and RDS. (Source: AWS, https://aws.amazon.com/compliance/uae_data_privacy/)
- **Microsoft Azure UAE**: Regions in **UAE North (Dubai)** and **UAE Central (Abu Dhabi)**. Azure North is a primary hub for government and enterprise workloads. (Source: Microsoft Learn, https://learn.microsoft.com/en-us/azure/compliance/offerings/offering-uae-desc)
- **Oracle Cloud UAE**: Two regions in **Dubai** and **Abu Dhabi**, providing built-in disaster recovery within the country. (Source: Oracle, https://www.oracle.com/news/announcement/second-generation-cloud-region-in-the-uae-100120/)

### Sovereign Architecture: Core42 Insight
Core42 (a G42 company) uses the **Insight** platform to provide sovereign controls over Microsoft Azure.
- **Technical Controls**: 200+ automated controls for data storage, transit, and usage.
- **Jurisdictional Control**: Ensures data is managed by UAE-cleared personnel.
(Source: Core42, https://www.core42.ai/products/sovereign-public-cloud)

## 5. Standards, Frameworks, and Best Practices
- **DESC CSP Security Standard**: Based on ISO/IEC 27001, 27002, 27017, and the Dubai ISR. Mandatory for Dubai government cloud providers.
- **NCEMA 7000:2021**: The UAE National Standard for Business Continuity Management, critical for cloud disaster recovery planning. (Source: NCEMA, https://www.ncema.gov.ae/vassets/48c1c32a/Publication-en.pdf.aspx)
- **NIST & CIS**: Widely used as baseline technical controls for hardening cloud environments in the UAE.

## 6. Technical Tactics and Implementation Details
- **Kubernetes (K8s)**: Becoming the "Enterprise Default" in the UAE for stateful applications and AI pipelines. Digital DEWA and Moro Hub utilize K8s for autonomous utility systems. (Source: Portworx, https://portworx.com/blog/kubernetes-enterprise-adoption-trends/)
- **Serverless**: AWS Lambda and Azure Functions are used for event-driven architectures in UAE fintech and retail to optimize costs.
- **Crypto Agility**: Per the 2025 National Encryption Policy, new cloud systems must allow for rotating keys and switching to post-quantum algorithms without downtime. (Source: PQShield, https://pqshield.com/uae-establishes-requirements-for-cryptographic-controls-and-migration-planning/)

## 7. Measurement, KPIs, and Operational Metrics
- **Uptime/Availability**: Standard SLAs for UAE government cloud (FedNet) often target 99.9% to 99.99%.
- **Data Residency Compliance**: % of regulated workloads hosted within UAE-certified regions.
- **FinOps Metrics**: Cost per transaction, idle resource percentage, and reserved instance coverage.
- **Security Metrics**: Mean Time to Detect (MTTD) and Mean Time to Remediate (MTTR) for cloud misconfigurations.

## 8. UAE Sector Use Cases and Localization Notes
- **Government**: **FedNet** provides a virtual marketplace for digital services across federal entities. (Source: TDRA, https://tdra.gov.ae/en/media/press-release/2022/tdra-recognized-as-the-first-government-entity-providing-sovereign-cloud-services-in-the-region)
- **Finance**: CBUAE's **Sovereign Financial Cloud** (launched Feb 2026) for regulated banking data. (Source: iQuasar, https://iquasar-emea.com/blog/uae-data-residency-sovereign-cloud-guide/)
- **Healthcare**: **Malaffi** (Abu Dhabi) and **Nabidh** (Dubai) health information exchanges require ADHICS-compliant cloud hosting. (Source: Neurula Health, https://neurulatechnologies.com/insights-compliance-2026.html)

## 9. Professional Practice and Checklists
### Cloud Procurement Checklist for UAE Entities
- [ ] **DESC Certification**: Does the CSP hold a valid DESC CSP Security Standard certificate?
- [ ] **Data Residency**: Is the primary and backup data stored exclusively in UAE regions?
- [ ] **Sovereign Controls**: Does the provider offer jurisdictional control (e.g., G42/Core42 Insight)?
- [ ] **CBUAE Compliance**: For banks, does the arrangement allow for "immediate cessation" of services if governance fails?
- [ ] **NCEMA 7000**: Is the cloud DR plan aligned with national business continuity standards?

## 10. Sources
- **TDRA**: Cloud Service Provider Initiative, https://tdra.gov.ae/en/tdra-initiatives/cloud-service-provider
- **DESC**: CSP Security Standard, https://www.desc.gov.ae/regulations/certifications/
- **CBUAE**: Outsourcing Regulation, https://rulebook.centralbank.ae/en/rulebook/outsourcing
- **Core42**: Sovereign Public Cloud, https://www.core42.ai/products/sovereign-public-cloud
- **AWS**: UAE Data Privacy, https://aws.amazon.com/compliance/uae_data_privacy/
- **Microsoft**: Azure UAE Compliance, https://learn.microsoft.com/en-us/azure/compliance/offerings/offering-uae-desc
- **Oracle**: UAE Cloud Regions, https://www.oracle.com/news/announcement/second-generation-cloud-region-in-the-uae-100120/
- **PQShield**: UAE National Encryption Policy, https://pqshield.com/uae-establishes-requirements-for-cryptographic-controls-and-migration-planning/
- **NCEMA**: Business Continuity Standard, https://www.ncema.gov.ae/vassets/48c1c32a/Publication-en.pdf.aspx

## 11. Gaps and Verification Notes
- **National Data Classification Framework**: While levels are defined in sector-specific policies (DoH, HCT), a single unified federal document for all sectors is often referenced but sometimes restricted.
- **Specific Cloud Spend**: Exact 2026 cloud market share percentages for AWS vs. Azure in the UAE are proprietary; estimates suggest Azure leads in government while AWS leads in startups/SMEs.
- **Post-Quantum Implementation**: The transition to PQC is in the "planning and roadmap" phase as of early 2026; live production implementations are still emerging.

### Checklist Status Summary
- Checklist Path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/dc97a730/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/dc97a730/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/dc97a730/TOOL_RESULTS.md`
- Research child tool results lines: `2019`
- Research child tool results bytes: `123778`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/dc97a730/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
