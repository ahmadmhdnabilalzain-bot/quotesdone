# Source Packet 3: Web development in the UAE: frontend, backend, full-stack, accessibility, multilingual Arabic/English UX, hosting, performance, security and compliance

# Web Development in the UAE: Frontend, Backend, and Compliance

This research report covers the technical, regulatory, and localized aspects of web development within the United Arab Emirates as of July 2026. It focuses on the standards set by the Telecommunications and Digital Government Regulatory Authority (TDRA), the Dubai Electronic Security Center (DESC), and the UAE Data Office.

## Domain Scope
Web development in the UAE is characterized by a "Digital-First" strategy, where government services and private sector platforms are increasingly integrated into unified digital ecosystems. The domain encompasses:
*   **Frontend Development:** Implementation of the UAE Design System (DLS), focusing on responsive, accessible, and high-performance user interfaces.
*   **Backend & Infrastructure:** Secure server-side logic with a heavy emphasis on data residency and local cloud hosting (e.g., Moro Hub, G42, AWS me-central-1).
*   **Multilingual UX:** Native support for Right-to-Left (RTL) Arabic and Left-to-Right (LTR) English scripts, ensuring "script harmony."
*   **Compliance:** Adherence to the UAE Personal Data Protection Law (PDPL) and sector-specific security regulations like the DESC Information Security Regulation (ISR).

## UAE Legal, Regulatory, and Policy Context
The UAE has established a robust legal framework to govern digital activities and protect user data.

### 1. Personal Data Protection Law (PDPL)
**Federal Decree-Law No. 45 of 2021** is the primary legislation governing the processing of personal data in the UAE.
*   **Data Residency:** Articles 22 and 23 specify that personal data may only be transferred outside the UAE to jurisdictions with an "adequate level of protection" or under specific contractual safeguards approved by the UAE Data Office (Source: Trade.gov, https://www.trade.gov/market-intelligence/united-arab-emirates-allows-cross-border-data-flows-personal-data).
*   **Consent:** Explicit consent is generally required for data processing, with rights for individuals to access, rectify, and delete their data (Source: DLA Piper, https://www.dlapiperdataprotection.com/countries/uae-general/law.html).

### 2. Dubai Electronic Security Center (DESC) ISR
The **Information Security Regulation (ISR) v2.0** (and subsequent updates) provides mandatory standards for Dubai government entities.
*   **Scope:** Covers 13 domains including Governance, Operation, and Assurance.
*   **Web Security Policy:** Specifically addresses application security, requiring entities to conduct risk assessments and implement "right-fit" controls (Source: DESC, https://www.desc.gov.ae/regulations/standards-policies/).

### 3. TDRA Federal Government Standards
The **Telecommunications and Digital Government Regulatory Authority (TDRA)** mandates the use of the **UAE Design System** for all federal websites to ensure a unified digital experience (Source: TDRA, https://tdra.gov.ae/en/media/press-release/2024/tdra-launches-the-uae-design-system-2-for-federal-government-websites).

## Core Concepts and Theory
Practitioners in the UAE must master specific concepts related to regional requirements:
*   **Bi-directional (BiDi) Layouts:** Understanding the CSS `direction: rtl` and `logical properties` (e.g., `margin-inline-start`) to handle Arabic/English switching without duplicating styles.
*   **Sovereign Cloud:** The concept of hosting data within national borders to meet "Sovereign Cloud" requirements, often utilizing local providers like Moro Hub or G42 (Source: iQuasar, https://iquasar-emea.com/blog/uae-data-residency-sovereign-cloud-guide/).
*   **Universal Design:** The theory that digital products should be usable by everyone, including "People of Determination" (the UAE term for persons with disabilities), without the need for adaptation.

## Architectures, Patterns, and Workflows
### UAE Design System (DLS) 2.0/3.0
The DLS provides a standardized React-based component library for federal entities.
*   **Workflow:** Developers are encouraged to use the official `@aegov/dls-react` package to maintain consistency in typography, color, and accessibility (Source: GitHub, https://github.com/TDRA-ae/aegov-dls-react).
*   **Pattern:** A "Mobile-First" and "Accessibility-First" approach is mandatory, with components pre-configured for ARIA compliance.

### Data Residency Architecture
Typical architectures involve:
*   **Local Database Hosting:** Sensitive PII (Personally Identifiable Information) must reside in UAE-based data centers.
*   **Hybrid Cloud:** Using global CDNs for static assets while keeping the application logic and database within the UAE AWS region (`me-central-1`) or local sovereign clouds.

## Standards, Frameworks, and Best Practices
### Accessibility Standards
*   **WCAG 2.1 Level AA:** Mandatory for all federal government websites (Source: UAE Design System, https://designsystem.gov.ae/guidelines/accessibility).
*   **Dubai Universal Design Code:** Mandates digital accessibility for all platforms serving the public in Dubai (Source: Deque, https://www.deque.com/mena-digital-accessibility-laws/uae/).

### Typography and Branding
*   **Dubai Font:** A bespoke typeface family designed in partnership with Microsoft, supporting both Latin and Arabic scripts simultaneously to ensure visual harmony (Source: Monotype, https://www.monotype.com/resources/case-studies/dubai).
*   **Font Fallbacks:** The DLS specifies `Noto Kufi Arabic` as the primary fallback for RTL themes (Source: UAE Design System, https://designsystem.gov.ae/guidelines/typography).

## Technical Tactics and Implementation Details
### Multilingual Implementation
*   **Language Negotiation:** Using the `Accept-Language` header or URL subdirectories (e.g., `/ar/`, `/en/`) for SEO-friendly language routing.
*   **RTL Mirroring:** Automatically mirroring layouts using tools like `RTLCSS` or Tailwind CSS's native RTL support (`rtl:ml-0 rtl:mr-4`).

### Performance Optimization
*   **Font Loading:** The UAE Design System recommends loading fonts via Google Fonts for performance, but local hosting is preferred for high-security government sites to avoid external dependencies.
*   **Minimum Font Size:** A minimum of **16px** is recommended for body text to ensure readability across devices (Source: UAE Design System, https://designsystem.gov.ae/guidelines/typography).

## Measurement, KPIs, and Operational Metrics
Web projects in the UAE are measured against:
*   **Lighthouse Scores:** Target scores of 90+ for Accessibility and SEO are common benchmarks for government portals.
*   **Compliance Audit Pass Rate:** Percentage of DESC ISR or TDRA DLS requirements met during annual audits.
*   **Arabic/English Parity:** Ensuring 100% content and feature parity between the two language versions.

## UAE Sector Use Cases and Localization Notes
*   **Government:** Unified portals (e.g., DubaiNow, TAMM) requiring high-level integration with UAE PASS for authentication.
*   **Healthcare:** Strict data residency under the **Health Data Law**, requiring all patient data to remain in the UAE (Source: Baker McKenzie, https://insightplus.bakermckenzie.com/bm/attachment_dw.action?attkey=FRbANEucS95NMLRN47z%2BeeOgEFCt8EGQJsWJiCH2WAVfnLVn2ghRGMhMH%2FuEdVml).
*   **Finance:** Compliance with Central Bank of the UAE (CBUAE) and FSRA/DFSA regulations regarding "Open Finance" and data privacy (Source: CBUAE Rulebook, https://rulebook.centralbank.ae/en/entiresection/47).

## Professional Practice and Checklists
### Senior Practitioner Checklist for UAE Web Projects:
1.  [ ] **Data Residency:** Is the database hosted in a UAE-based region (e.g., AWS `me-central-1`, Moro Hub)?
2.  [ ] **Authentication:** Is UAE PASS integrated for secure user identity verification?
3.  [ ] **Accessibility:** Does the site meet WCAG 2.1 Level AA? Have you tested with screen readers (VoiceOver/TalkBack) in both Arabic and English?
4.  [ ] **Typography:** Is the Dubai Font or the approved DLS font (Noto Kufi Arabic) implemented correctly?
5.  [ ] **Legal:** Is there a clear Privacy Policy compliant with Federal Decree-Law No. 45 of 2021?
6.  [ ] **RTL Support:** Are all layouts mirrored correctly? Are icons that imply direction (e.g., arrows) flipped?

## Sources
*   **TDRA UAE Design System Guidelines:** https://designsystem.gov.ae/guidelines
*   **TDRA Accessibility Guidelines:** https://designsystem.gov.ae/guidelines/accessibility
*   **DESC Standards & Policies:** https://www.desc.gov.ae/regulations/standards-policies/
*   **UAE Government Data Protection Laws:** https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws
*   **Monotype Dubai Font Case Study:** https://www.monotype.com/resources/case-studies/dubai
*   **Trade.gov UAE Data Flow Intelligence:** https://www.trade.gov/market-intelligence/united-arab-emirates-allows-cross-border-data-flows-personal-data
*   **CBUAE Open Finance Regulation:** https://rulebook.centralbank.ae/en/entiresection/47

## Gaps and Verification Notes
*   **Implementing Regulations for PDPL:** While the law was enacted in 2021, the full implementing regulations from the UAE Data Office are expected to provide more granular detail on cross-border transfer mechanisms in late 2024/2025; practitioners should monitor the UAE Data Office for updates.
*   **DESC ISR v3.0:** Some sources mention an ISR v3.0; however, official DESC documentation primarily references v2.0 and specific sub-standards (IoT, Web Security Policy). Verification of the latest version with DESC directly is recommended for Dubai-based projects.
*   **Sovereign Cloud Pricing:** Specific pricing and SLA details for Moro Hub and G42 are typically gated behind NDAs and procurement processes, making public benchmarking difficult.

---
**Checklist Status Summary:**
Checklist path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/014adfd5/RESEARCH_CHECKLIST.md`
All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/014adfd5/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/014adfd5/TOOL_RESULTS.md`
- Research child tool results lines: `1514`
- Research child tool results bytes: `79306`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/014adfd5/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
