# UAE General Information — Comprehensive Reference

> Expanded final version prepared July 2026. This file is intended as a practical professional reference library, not legal advice. Values marked `[verify]` should be checked against the live official portal before reliance.

## 1. GEOGRAPHY

The United Arab Emirates (UAE) is situated in the Southeast of the Arabian Peninsula, bordering the Persian Gulf (Arabian Gulf) to the north and the Gulf of Oman to the east. Its geography is characterized by a diverse landscape ranging from coastal salt flats (sabkhas) and rolling sand dunes to rugged mountain ranges.

### 1.1. Exact Coordinates and Area
- **Exact Coordinates**: 24.4539° N, 54.3773° E (Abu Dhabi); 25.2048° N, 55.2708° E (Dubai). Approximate center: 24°N 54°E.
- **Total Area**: 83,600 km² (including islands). Abu Dhabi accounts for approximately 87% of the total land area.
- **Borders**:
  - **Saudi Arabia**: 457 km (south and west).
  - **Oman**: 609 km (east and northeast).
  - **Coastline**: 1,318 km along the Persian Gulf (west) and Gulf of Oman (east).

### 1.2. Al Hajar Mountains
The Al Hajar Mountains (Arabic: جِبَال ٱلْحَجَر, "The Rocky Mountains") are the highest mountain range in the eastern Arabian Peninsula, shared between the UAE and Oman.
- **Geological Description**: The range is primarily composed of the **Semail Ophiolite**, a massive slab of oceanic crust and upper mantle that was thrust (obducted) onto the Arabian continental margin during the Late Cretaceous (~70–95 million years ago).
- **Ophiolite Sequence**: The sequence includes (from bottom to top) peridotite (mantle), gabbro (lower crust), sheeted dikes, and pillow basalts (upper crust). This is one of the best-exposed ophiolite sequences in the world.
- **Age and Formation**: The mountains were formed by the collision of the Arabian and Eurasian plates. The uplift occurred in two main stages: the first during the Late Cretaceous obduction and the second during the Cenozoic (Eocene to Miocene) due to the Zagros collision.
- **Highest Point in UAE**: Jebel Jais in Ras Al Khaimah (1,934 m).

### 1.3. Sabkha (Salt Flats)
Sabkhas are supratidal mudflats or sandflats where evaporite minerals accumulate.
- **Detailed Description**: The UAE's coastal sabkhas, particularly the **Abu Dhabi Sabkha**, are the world's type locality for this landform. They form in arid climates where evaporation exceeds precipitation, leading to the precipitation of gypsum, anhydrite, and halite.
- **Engineering Implications**: Sabkhas present significant challenges for construction due to:
  - **Corrosivity**: High salt content (chlorides and sulfates) aggressively attacks concrete and steel.
  - **Low Bearing Capacity**: The soil is often loose and saturated with brine, requiring specialized foundation techniques like "vibro-compaction" or deep piling.
  - **Groundwater Seepage**: The water table is very shallow (often <1m), leading to flooding and salt crystallization in structures.

### 1.4. Rub' al Khali (The Empty Quarter)
The UAE contains a significant portion of the Rub' al Khali, the largest contiguous sand desert in the world.
- **Area in UAE**: Covers much of the southern and western parts of Abu Dhabi (Liwa region).
- **Dune Types**:
  - **Barchan Dunes**: Crescent-shaped dunes that migrate with the wind.
  - **Seif Dunes**: Long, linear dunes (longitudinal) that can stretch for kilometers.
  - **Mega-dunes**: In the Liwa Oasis area, dunes can reach heights of over 250 meters (e.g., **Moreeb Dune**).
- **Sand Composition**: Primarily quartz with varying amounts of feldspar and carbonate. The red color is due to iron oxide (hematite) coatings on the sand grains.

### 1.5. Maritime Boundaries and EEZ
- **Exclusive Economic Zone (EEZ)**: The UAE declared its EEZ in 1980, extending 200 nautical miles from its baselines (where applicable).
- **Continental Shelf Claims**: The UAE has made submissions to the UN Commission on the Limits of the Continental Shelf (CLCS) to define its maritime boundaries in the Persian Gulf and the Gulf of Oman.
- **Disputed Territories**: The islands of **Abu Musa**, **Greater Tunb**, and **Lesser Tunb** are occupied by Iran but claimed by the UAE (specifically Sharjah and Ras Al Khaimah).

### 1.6. Major Wadis
Wadis are seasonal riverbeds that flow only after heavy rainfall.
- **Wadi Hatta**: Located in the Hatta enclave of Dubai; known for its pools and the Hatta Dam.
- **Wadi Ham**: One of the longest wadis in the UAE, running through Fujairah.
- **Wadi Shawkah**: Located in Ras Al Khaimah; a popular spot for hiking and mountain biking.
- **Seasonal Flow**: Flow is highly ephemeral, often resulting in flash floods during the winter months (December–March).

### 1.7. Islands List
The UAE has over 200 islands.
- **Abu Musa**: 25.87° N, 55.03° E. Disputed with Iran; strategic location near the Strait of Hormuz.
- **Greater Tunb**: 26.26° N, 55.31° E. Disputed with Iran.
- **Lesser Tunb**: 26.24° N, 55.14° E. Disputed with Iran.
- **Sir Abu Nu'ayr**: 25.22° N, 54.22° E. Known for its salt domes and as a nesting site for hawksbill turtles.
- **Dalma**: 24.50° N, 52.31° E. Historically a major pearling center.
- **Das**: 25.15° N, 52.87° E. Major oil and gas processing hub.
- **Zirku**: 24.86° N, 53.07° E. Oil terminal.
- **Arzanah**: 24.78° N, 52.56° E. Oil field and terminal.
- **Sir Bani Yas**: 24.31° N, 52.60° E. Nature reserve established by Sheikh Zayed; home to Arabian oryx, gazelles, and cheetahs.
- **Yas Island**: 24.48° N, 54.60° E. Major leisure and entertainment hub (Ferrari World, Yas Marina Circuit).
- **Saadiyat Island**: 24.53° N, 54.44° E. Cultural district (Louvre Abu Dhabi, Guggenheim Abu Dhabi).
- **Al Maryah Island**: 24.50° N, 54.38° E. Business and financial district (ADGM).
- **Nurai Island**: 24.61° N, 54.48° E. Luxury private island resort.

### 1.8. Protected Areas and Nature Reserves
The UAE has 49 protected areas (as of 2024), covering ~15% of its territory.
- **Marawah Marine Biosphere Reserve**: Largest marine protected area (4,255 km²); home to the world's second-largest population of dugongs.
- **Al Wathba Wetland Reserve**: Known for its flamingo population.
- **Dubai Desert Conservation Reserve (DDCR)**: 225 km²; protects the desert ecosystem and Arabian oryx.
- **Wadi Wurayah National Park**: Fujairah; the UAE's first mountain protected area.
- **Ras Al Khor Wildlife Sanctuary**: Dubai; famous for its flamingos and mangroves.

### 1.9. Climate Zones
The UAE has a desert climate (Köppen: **BWh**).
- **Coastal Zone**: High humidity in summer, mild winters.
- **Inland Desert**: Extreme heat in summer, cold nights in winter.
- **Mountain Zone**: Cooler temperatures and higher rainfall (up to 150-200mm annually).

### 1.10. Seismic Hazard and Soil Types
- **Seismic Hazard**: The UAE is generally a low-to-moderate seismic zone. The Peak Ground Acceleration (PGA) is highest in the north (Ras Al Khaimah/Fujairah) due to proximity to the Makran subduction zone and the Zagros fault.
- **Soil Types**:
  - **Sabkha**: Saline mudflats.
  - **Gypsiferous Soils**: Soils containing high levels of gypsum.
  - **Calcarenite**: Cemented sand dunes (locally known as "faroush").
  - **Desert Pavement**: A surface of closely packed rock fragments (reg).

---

## 2. HISTORY

### 2.1. Pre-Islamic Period
- **Umm Al Nar Culture (2600–2000 BCE)**: Characterized by circular stone tombs and advanced copper smelting. Artifacts found in Abu Dhabi (Umm Al Nar island) and Al Ain (Hili).
- **Mleiha Site (Sharjah)**: A major archaeological site dating from the 3rd century BCE to the 3rd century CE; evidence of trade with the Mediterranean and India.
- **Dibba Settlement**: A strategic port since antiquity; site of the **Battle of Dibba** (632–633 CE) during the Ridda Wars, which secured the Islamic conversion of the region.

### 2.2. British Trucial States Administration
- **Political Agents**: The British maintained Political Agents in the Trucial States (initially based in Sharjah, later Dubai and Abu Dhabi).
- **Residency**: The region was overseen by the **Political Resident in the Persian Gulf**, based in Bushire (Iran) until 1946, then Bahrain until 1971.
- **Trucial States Council (1952)**: Established to encourage cooperation between the seven rulers; the precursor to the federal government.
- **TSDP (Trucial States Development Programme)**: Launched in the 1950s to fund infrastructure, health, and education.

### 2.3. Oil Concession History
- **1935**: First concession granted to **Petroleum Development (Trucial Coast)**, a subsidiary of the **Iraq Petroleum Company (IPC)**.
- **D'Arcy Exploration Co. (BP)**: Involved in early offshore exploration.
- **ADPC (Abu Dhabi Petroleum Company)**: Formed from IPC; discovered the Murban field in 1958.
- **CFP (Total)**: A major partner in the IPC group and later ADNOC.

### 2.4. Union Formation (1968–1971)
- **Abu Dhabi-Dubai Axis**: The 1968 meeting at **As-Samih** between Sheikh Zayed and Sheikh Rashid was the catalyst for the union.
- **Bahrain and Qatar**: Initially part of the "Federation of Nine," they decided to pursue separate independence in 1971.
- **Union Agreement (2 Dec 1971)**: Signed at the Union House in Dubai. Key provisions:
  - Establishment of a federal state with a temporary constitution.
  - Allocation of powers between federal and local governments.
  - Designation of Abu Dhabi as the temporary capital.

### 2.5. Post-Independence Decades
- **1970s**: Oil boom; massive infrastructure development; introduction of the Dirham (1973).
- **1980s**: Economic diversification begins; founding of the GCC (1981); Iran-Iraq War impacts maritime security.
- **1990s**: Gulf War (1990-91); UAE hosts coalition forces; rapid growth of Dubai as a trade hub.
- **2000s**: Real estate boom; construction of Burj Khalifa and Palm Jumeirah; 2008 global financial crisis.

### 2.6. Dubai Debt Crisis 2009
- **Details**: Dubai World announced a debt standstill in Nov 2009, causing global market panic.
- **Bailout**: Abu Dhabi provided a **$10 billion bailout** (via the Central Bank and a $5bn loan) to cover Nakheel's bonds and other obligations.
- **Mechanism**: The bailout was structured as a series of loans and bond purchases by the Abu Dhabi government.

### 2.7. Abraham Accords (2020)
- **Signatories**: UAE, Israel, and the USA (Bahrain joined later).
- **Provisions**: Full normalization of diplomatic, economic, and security relations.
- **Implications**: Significant increase in trade, tourism, and technology cooperation; shift in regional geopolitics.

### 2.8. UAE Armed Forces History
- **Founding**: Formed in 1976 by the unification of the Trucial Oman Scouts and the emirate-level defense forces.
- **Operations**:
  - **Gulf War (1991)**: Liberation of Kuwait.
  - **Somalia (1992)**: UNOSOM II.
  - **Kosovo (1999)**: KFOR.
  - **Afghanistan (2003–2014)**: ISAF.
  - **Yemen War (2015–present)**: Part of the Saudi-led coalition against Houthi rebels.
  - **Sudan**: UAE has been accused of supporting the Rapid Support Forces (RSF), though the government officially denies direct military support.

---

## 3. GOVERNMENT & POLITICS

### 3.1. Key Constitutional Articles (English Text)
- **Article 1**: "The United Arab Emirates is an independent, sovereign, federal state... It shall consist of the following Emirates: Abu Dhabi, Dubai, Sharjah, Ajman, Umm Al Quwain, Ras Al Khaimah, and Fujairah."
- **Article 7**: "Islam shall be the official religion of the Union. The Islamic Shari’ah shall be a principal source of legislation in the Union. The official language of the Union shall be Arabic."
- **Article 9**: "The Union shall have a Flag, an Emblem and a National Anthem... The people of the Union shall be a single people."
- **Article 25**: "All persons shall be equal before the law. No discrimination shall be practised between citizens of the Union by reason of race, nationality, religious belief or social position."
- **Article 120**: Lists exclusive federal jurisdictions: foreign affairs, defense, security, currency, etc.
- **Article 121**: Lists federal legislative jurisdictions: labor, social security, property, extradition, etc.
- **Article 122**: "The Emirates shall have jurisdiction in all matters not assigned to the exclusive jurisdiction of the Union."

### 3.2. Council of Ministers (2026 List)
The UAE Cabinet consists of approximately 35-40 members.
1. **HH Sheikh Mohammed bin Rashid Al Maktoum**: Vice President, PM, Minister of Defence, Ruler of Dubai.
2. **HH Sheikh Mansour bin Zayed Al Nahyan**: Vice President, Deputy PM, Chairman of the Presidential Court.
3. **HH Sheikh Hamdan bin Mohammed Al Maktoum**: Deputy PM, Minister of Defence.
4. **HH Sheikh Maktoum bin Mohammed Al Maktoum**: Deputy PM, Minister of Finance.
5. **HH Sheikh Saif bin Zayed Al Nahyan**: Deputy PM, Minister of Interior.
6. **HH Sheikh Abdullah bin Zayed Al Nahyan**: Deputy PM, Minister of Foreign Affairs.
7. **HE Sheikh Nahayan bin Mabarak Al Nahayan**: Minister of Tolerance and Coexistence.
8. **HE Mohammad bin Abdullah Al Gergawi**: Minister of Cabinet Affairs.
9. **HE Abdulrahman bin Mohamed Al Owais**: Minister of Health and Prevention, Minister of State for FNC Affairs.
10. **HE Mohamed bin Hadi Al Hussaini**: Minister of State for Financial Affairs.
11. **HE Reem bint Ebrahim Al Hashimy**: Minister of State for International Cooperation.
12. **HE Suhail Mohamed AlMazrouei**: Minister of Energy and Infrastructure.
13. **HE Dr. Sultan bin Ahmad Al Jaber**: Minister of Industry and Advanced Technology.
14. **HE Dr. Ahmad bin Abdullah Al Falasi**: Minister of Sports.
15. **HE Dr. Thani bin Ahmed Al Zeyoudi**: Minister of State for Foreign Trade.
16. **HE Shamma bint Sohail Al Mazrui**: Minister of Community Empowerment.
17. **HE Sarah bint Yousef Al Amiri**: Minister of Education.
18. **HE Abdulla bin Touq Al Marri**: Minister of Economy.
19. **HE Dr. Abdulrahman Al Awar**: Minister of Human Resources and Emiratisation.
20. **HE Abdullah bin Sultan Al Nuaimi**: Minister of Justice.
21. **HE Sheikh Salem bin Khalid Al Qassimi**: Minister of Culture.
22. **HE Mohamed bin Hassan Alsuwaidi**: Minister of Investment.
23. **HE Dr. Amna bint Abdullah Al Dahak**: Minister of Climate Change and Environment.
24. **HE Omar bin Sultan Al Olama**: Minister of State for AI, Digital Economy.
25. **HE Maryam bint Ahmed Al Hammadi**: Minister of State, Secretary General of the Cabinet.
*(Note: List includes key portfolios; total ministers including Ministers of State reach ~39).*

### 3.3. Federal National Council (FNC)
- **Electoral Colleges**: Members are not elected by direct universal suffrage. Instead, each ruler appoints an electoral college for their emirate, which then elects half of the FNC members.
- **Voting Eligibility**: Only members of the electoral colleges can vote or run for office. The size of these colleges has increased significantly (from ~6,000 in 2006 to over 330,000 in 2019).
- **Recent Legislation**: Focus on family law reforms, digital economy regulations, and climate change mitigation.

### 3.4. Political System Analysis
- **Federal vs. Emirate Authority**: While the federal government handles defense and foreign policy, individual emirates (especially Abu Dhabi and Dubai) retain significant control over their economies, natural resources, and local infrastructure.
- **Rulers' Courts (Diwans)**: Each emirate has a Diwan that serves as the administrative office of the ruler, handling local petitions, land grants, and tribal affairs.

### 3.5. Foreign Policy and Soft Power
- **GCC Role**: UAE is a key driver of GCC integration and security.
- **OPEC**: UAE is a major producer and influential member of OPEC.
- **Soft Power**:
  - **MBRGI**: Mohammed bin Rashid Global Initiatives (humanitarian aid).
  - **Expo 2020 Dubai**: First World Expo in the MEASA region.
  - **COP28**: Hosted in Dubai (2023), focusing on the "UAE Consensus" for climate action.

---

## 4. ECONOMY

### 4.1. ADNOC Corporate Structure
The Abu Dhabi National Oil Company (ADNOC) is a diversified energy group.
- **Subsidiaries**:
  - **ADNOC Drilling**: Largest national drilling company in the Middle East.
  - **ADNOC Logistics & Services**: Shipping and maritime logistics.
  - **ADNOC Distribution**: Retail fuel and convenience stores.
  - **ADNOC Gas**: Processing and marketing of natural gas.
  - **ADNOC Refining**: Operates the Ruwais refinery (one of the world's largest).
  - **ADNOC Chemicals (Borouge)**: Joint venture with Borealis for petrochemicals.
  - **ADNOC LNG (ADGAS)**: Liquefied natural gas production.
  - **Fertil**: Fertilizer production.
  - **Ruwais Industrial Zone**: Hub for downstream activities.

### 4.2. Free Zones Economic Data
- **JAFZA (Jebel Ali Free Zone)**: Over 9,500 companies; contributes ~23% of Dubai's GDP.
- **DMCC (Dubai Multi Commodities Centre)**: Over 24,000 member companies; world's leading free zone for gold, diamonds, and tea.
- **DIFC (Dubai International Financial Centre)**: Over 5,500 active registered firms; total assets under management exceed $700 billion.

### 4.3. Banking Sector (Top 10 Banks by Assets - 2024)
1. **First Abu Dhabi Bank (FAB)**: ~AED 1.2 trillion.
2. **Emirates NBD**: ~AED 800 billion.
3. **Abu Dhabi Commercial Bank (ADCB)**: ~AED 550 billion.
4. **Dubai Islamic Bank (DIB)**: ~AED 300 billion.
5. **Mashreq Bank**: ~AED 220 billion.
6. **Abu Dhabi Islamic Bank (ADIB)**: ~AED 190 billion.
7. **Commercial Bank of Dubai (CBD)**: ~AED 130 billion.
8. **National Bank of Fujairah (NBF)**: ~AED 50 billion.
9. **RAKBANK**: ~AED 70 billion.
10. **Sharjah Islamic Bank**: ~AED 65 billion.
*(Note: Tier 1 Capital Ratios typically range from 15% to 18% across the sector).*

### 4.4. Stock Markets
- **ADX (Abu Dhabi Securities Exchange)**: Market cap ~$800 billion. Top companies: IHC, TAQA, ADNOC Gas, Etisalat (e&).
- **DFM (Dubai Financial Market)**: Market cap ~$200 billion. Top companies: Emirates NBD, Emaar Properties, DEWA.

### 4.5. Sovereign Wealth Funds (SWFs)
- **ADIA (Abu Dhabi Investment Authority)**:
  - **Strategy**: Long-term value creation through a diversified global portfolio.
  - **Allocation**: Equities (32-42%), Fixed Income (10-20%), Real Estate (5-10%), Private Equity (7-12%), Infrastructure (2-7%).
  - **Geography**: North America (35-50%), Europe (20-35%), Emerging Markets (15-25%).

### 4.6. Tourism and Trade
- **Hotel Inventory**: Over 180,000 rooms in Dubai; ~35,000 in Abu Dhabi.
- **MICE Market**: Dubai is a global leader in conferences and exhibitions (DWTC).
- **Re-export Hub**: UAE is the world's 3rd largest re-export hub. Top commodities: electronics, precious stones, vehicles.

### 4.7. Federal Budget 2024
- **Total Expenditure**: AED 64.06 billion.
- **Revenue Breakdown**: Primarily from federal fees, investments, and contributions from Abu Dhabi and Dubai.
- **Expenditure by Ministry**:
  - **Social Development & Benefits**: AED 26.7 billion (42%).
  - **Government Affairs**: AED 25.2 billion (39%).
  - **Education**: AED 10.2 billion.
  - **Health**: AED 5.2 billion.

---

## 5. DEMOGRAPHICS

### 5.1. Historical Population Growth
| Year | Population (Millions) |
| :--- | :--- |
| 1975 | 0.54 |
| 1980 | 1.02 |
| 1985 | 1.38 |
| 1990 | 1.90 |
| 1995 | 2.43 |
| 2000 | 3.49 |
| 2005 | 4.66 |
| 2010 | 6.94 |
| 2015 | 8.67 |
| 2020 | 9.45 |
| 2024 | 11.03 |

### 5.2. Labour Force Data
- **By Sector**:
  - Construction: ~35%
  - Wholesale & Retail Trade: ~18%
  - Manufacturing: ~10%
  - Financial Services: ~5%
  - Hospitality: ~8%

### 5.3. Migrant Worker Conditions
- **Kafala System**: Historically tied workers to employers.
- **Reforms (2021+)**: Introduction of the "Green Visa," "Golden Visa," and the ability for workers to change jobs without employer consent after contract completion.
- **Housing Standards**: Mandatory "Labour Cities" with specific requirements for space, sanitation, and recreation.

### 5.4. UAE National Demographics
- **Tribal Affiliations**:
  - **Bani Yas**: The dominant confederation in Abu Dhabi (Al Nahyan) and Dubai (Al Maktoum).
  - **Al Qawasim**: Rulers of Sharjah and Ras Al Khaimah.
  - **Al Nuaimi**: Rulers of Ajman.
  - **Al Mualla**: Rulers of Umm Al Quwain.
  - **Al Sharqi**: Rulers of Fujairah.

### 5.5. Housing
- **Split**: ~30% Villas, ~70% Apartments (in urban areas like Dubai).
- **Average Rent**:
  - Dubai (2BR): AED 80,000 - 150,000.
  - Abu Dhabi (2BR): AED 70,000 - 130,000.
  - Northern Emirates: AED 30,000 - 60,000.

---

## 6. CULTURE

### 6.1. Traditional Sports
- **Camel Racing**:
  - **Rules**: Races are typically 4km to 10km.
  - **Robot Jockeys**: Introduced in 2004 to replace child jockeys; controlled by trainers in SUVs driving alongside the track.
  - **Al Marmoom Camelodrome**: Dubai's premier racing venue.
- **Falconry**:
  - **Species**: Peregrine, Saker, and Gyrfalcon.
  - **CITES**: UAE is a signatory; all falcons must have passports.
  - **Al Ain Falcon Hospital**: World's largest avian hospital.

### 6.2. Pearl Diving
- **Season**: *Al Ghaus Al Kabeer* (The Big Dive) from June to September.
- **Tools**: *Al-Miyas* (nose clip), *Al-Khashaba* (toe clip), *Al-Dayyin* (basket).
- **Collapse**: The industry collapsed in the 1930s due to the invention of cultured pearls by Mikimoto in Japan.

### 6.3. Traditional Food
- **Machboos**: Spiced rice with meat or fish.
- **Harees**: Beaten wheat and meat porridge.
- **Luqaimat**: Sweet fried dough balls with date syrup.
- **Balaleet**: Sweet vermicelli with omelet.
- **Saloona**: Meat and vegetable stew.
- **Thareed**: Bread soaked in meat broth.

### 6.4. National Dress
- **Kandura**: Men's white robe. Variants: Emirati (no collar, tassel), Saudi (collar, buttons), Kuwaiti (collar, one button).
- **Abaya**: Women's black cloak. Regional styles vary in embroidery and cut.
- **Burkha**: Traditional metallic-looking face mask worn by older Emirati women.

### 6.5. Islamic Practice
- **Mosque Density**: Over 9,000 mosques in the UAE.
- **Ramadan**: Public eating, drinking, and smoking are prohibited during daylight hours (though rules have relaxed for tourists in recent years).

---

## 7. INFRASTRUCTURE

### 7.1. Major Expressways
- **E11 (Sheikh Zayed Road)**: 558 km; Abu Dhabi to RAK.
- **E311 (MBZ Road)**: Bypass road connecting all emirates.
- **E611 (Emirates Road)**: Outer bypass for heavy traffic.
- **E66 (Al Ain Road)**: Connects Dubai and Al Ain.
- **E44 (Dubai-Hatta Highway)**: Connects Dubai to the Hatta enclave.

### 7.2. Bridges and Tunnels
- **Maqta Bridge**: First bridge connecting Abu Dhabi island to the mainland (1968).
- **Al Shindagha Tunnel**: Connects Bur Dubai and Deira (now supplemented by the Infinity Bridge).
- **Business Bay Crossing**: 13 lanes.

### 7.3. Utilities and Telecoms
- **DEWA Capacity**: ~14,500 MW.
- **Telecoms**: **e&** (formerly Etisalat) and **du**.
- **Submarine Cables**: FALCON, SMW5, EIG, IMEWE all land in the UAE, making it a global data hub.

---

## 8. EDUCATION

### 8.1. University Rankings (QS 2024)
1. **Khalifa University**: #143
2. **UAE University**: #290
3. **American University of Sharjah**: #364
4. **University of Sharjah**: #465

### 8.2. KHDA Ratings (Dubai 2023/24)
- **Outstanding**: 20 schools.
- **Very Good**: 39 schools.
- **Good**: 84 schools.
- **Acceptable**: 55 schools.

---

## 9. HEALTH

### 9.1. Disease Burden
- **Leading Causes of Death**: Cardiovascular disease (38%), Cancer (15%), Road accidents (10%).
- **Diabetes**: Prevalence ~19% among adults.

### 9.2. Major Hospitals
- **Cleveland Clinic Abu Dhabi**: 364 beds; multi-specialty.
- **Sheikh Khalifa Medical City (SKMC)**: 586 beds.
- **Rashid Hospital (Dubai)**: 762 beds; trauma center.
- **American Hospital Dubai**: 254 beds.

---



## 10. Emirate-by-Emirate Reference Tables

### 10.1 Core Administrative Profile

| Emirate | Capital / Seat | Approximate Area | Main Urban Centres | Economic Profile | Key Professional Notes |
|---|---:|---:|---|---|---|
| Abu Dhabi | Abu Dhabi City | ~67,000 km² | Abu Dhabi, Al Ain, Ruwais, Madinat Zayed, Liwa | Oil and gas, sovereign investment, heavy industry, ports, energy, aerospace, culture, federal government | Largest emirate by area; controls most hydrocarbon reserves; major construction regulatory routes pass through DMT/TAMM, ADDC/AADC, Civil Defence, EAD and ADREC/Tawtheeq. |
| Dubai | Dubai City | ~4,114 km² | Deira, Bur Dubai, Jumeirah, Marina, JLT, Business Bay, Jebel Ali, Hatta | Trade, logistics, aviation, tourism, real estate, finance, technology, retail | Highly portal-driven: DM, DET, DLD/RERA, RTA, DEWA, DCD, Trakhees, DIFC, VARA and numerous free-zone authorities. |
| Sharjah | Sharjah City | ~2,590 km² | Sharjah City, Khor Fakkan, Kalba, Dibba Al Hisn, Al Dhaid | Culture, education, manufacturing, ports, logistics, publishing, affordable housing | Three-coast/emirate geography; important east-coast port at Khor Fakkan; municipality and SEWA approvals central to projects. |
| Ajman | Ajman City | ~259 km² | Ajman City, Masfout, Manama | Manufacturing, real estate, services, port activity, SME licensing | Compact urban jurisdiction; Ajman Free Zone and municipal approvals important for SME and light-industrial operators. |
| Umm Al Quwain | Umm Al Quwain City | ~720 km² | UAQ City, Falaj Al Mualla | Fisheries, light industry, tourism, wetlands, logistics | Lower-density emirate with sensitive coastal lagoons and mangroves; environmental and municipal checks are material for development. |
| Ras Al Khaimah | Ras Al Khaimah City | ~2,486 km² | RAK City, Al Hamra, Julfar, Khatt, Jebel Jais area | Tourism, quarries, cement, ceramics, real estate, ports, RAKEZ | Mountain geology, quarrying and tourism dominate many technical issues; seismic and slope/geotechnical considerations are more important than in Dubai/Abu Dhabi lowlands. |
| Fujairah | Fujairah City | ~1,450 km² | Fujairah City, Dibba, Masafi, Mirbah | Oil bunkering, ports, logistics, quarrying, tourism, east-coast trade | Only emirate primarily on Gulf of Oman; strategic port outside Strait of Hormuz bottleneck; wadi flood risk and mountain geology influence engineering. |

### 10.2 Emirate Regulatory Orientation for Professionals

| Professional Need | Abu Dhabi | Dubai | Sharjah | Northern Emirates |
|---|---|---|---|---|
| Building permit | DMT / municipality through TAMM | Dubai Municipality; Trakhees for PCFC areas | Sharjah Municipality and planning authorities | Local municipality portals and emirate-specific NOCs |
| Utility connection | ADDC / AADC, DoE oversight | DEWA | SEWA | FEWA / Etihad Water & Electricity, local water/electricity authorities |
| Fire safety | Abu Dhabi Civil Defence | Dubai Civil Defence | Sharjah Civil Defence | Emirate Civil Defence branches |
| Property registration | ADREC / DMT | Dubai Land Department / RERA | Sharjah Real Estate Registration Department [verify] | Emirate land departments [verify] |
| Environmental approvals | EAD for Abu Dhabi; MOCCAE for federal/cross-border matters | Dubai Municipality environment sections; MOCCAE for federal matters | EPAA / municipality [verify] | MOCCAE plus local municipality/environment authority |
| Labour / immigration | MOHRE plus ICP / TAMM services | MOHRE plus GDRFA Dubai / Amer | MOHRE plus ICP | MOHRE plus ICP |

## 11. Detailed Physical Geography, Climate and Natural Hazards

### 11.1 Landforms and engineering implications

The UAE is often described simply as a desert state, but for planning, engineering, insurance and environmental review it is better understood as a set of sharply different landform systems. The low-lying Arabian Gulf coastal plain includes sabkha flats, reclaimed islands, urban waterfronts, mangrove lagoons and artificially dredged channels. The central and southern interior is dominated by dune fields, gravel plains and the Liwa / Rub' al Khali desert transition. The eastern margin rises into the Al Hajar mountain system, with wadis, alluvial fans, gabbro, peridotite and other ophiolitic rocks. Each landform creates a different technical risk profile.

| Landform | Where found | Practical implications | Typical professional checks |
|---|---|---|---|
| Coastal sabkha | Abu Dhabi coast, Dubai lowlands, lagoons, industrial reclaimed areas | Shallow saline groundwater, sulfate/chloride attack, settlement risk, aggressive exposure class for concrete and steel | Geotechnical investigation, groundwater chemistry, sulfate-resistant cement, pile design, waterproofing, corrosion protection, dewatering method statement |
| Reclaimed island / dredged fill | Palm Jumeirah, Yas, Saadiyat, Al Maryah, port expansions | Variable compaction, long-term settlement, liquefaction screening, marine environmental approvals | CPT/SPT logs, vibro-compaction records, settlement monitoring, marine EIA, coastal modelling |
| Dune sand | Dubai desert belt, Abu Dhabi western region, Liwa | Wind erosion, drifting sand, low cohesion, access-road burial, heat-island exposure | Sand-control barriers, road alignment studies, compaction and stabilisation, dust management plan |
| Gravel plains / alluvial fans | Al Ain, RAK, Fujairah foothills | Flash-flood channels, boulder wash, variable bearing strata | Wadi hydrology, flood return period, culvert sizing, setback from wadi channels |
| Mountain rock slopes | RAK, Fujairah, Hatta, Khor Fakkan | Rockfall, slope instability, blasting and quarry controls, seismic design checks | Rock mass rating, slope stabilisation, catch fences, retaining systems, drainage channels |
| Offshore islands / platforms | Das, Zirku, Arzanah, Abu Dhabi offshore fields | Marine corrosion, logistics access, environmental sensitivity, emergency response | Offshore safety case, marine transport plan, oil spill plan, corrosion protection and cathodic systems |

### 11.2 Climate data useful for design and operations

The UAE's climate is hot-desert, but operational risk varies by coast, interior and mountain zone. Coastal cities have high humidity during summer; interior deserts have larger day-night temperature swings; mountain and east-coast locations have higher rainfall and flash-flood exposure. For building design, the most operationally important climate factors are peak dry-bulb temperature, coincident wet-bulb temperature, humidity, solar radiation, dust loading, corrosive marine air, and the winter rainfall pulses that generate wadi floods.

| Climate factor | Typical UAE pattern | Professional relevance |
|---|---|---|
| Summer heat | Long hot season, with daytime temperatures commonly above 40°C in peak months | HVAC sizing, labour midday-break compliance, materials storage, concrete curing, asphalt work planning |
| Humidity | High on Arabian Gulf coast in summer, lower in inland desert | Condensation control, mould prevention, latent cooling load, façade dew-point checks |
| Rainfall | Low annual totals but concentrated winter events; mountains receive higher totals | Stormwater design, wadi crossings, basement flood protection, roof drainage, emergency response |
| Dust / sand | Shamal winds and local dust events can sharply reduce visibility and raise particulate matter | Air filtration, façade maintenance, PV panel cleaning, airport operations, worker respiratory protection |
| Marine salinity | Arabian Gulf has high salinity and high evaporation; Gulf of Oman conditions differ | Desalination, cooling water intake, corrosion, marine ecology, concrete exposure classes |
| Solar radiation | High year-round, especially in open desert | PV yield, façade heat gain, shading, roof SRI, outdoor thermal comfort |

### 11.3 Wadis and flash-flood risk inventory

Wadis are not permanent rivers but episodic flood channels. The danger is that a dry bed can become a high-energy flow path after intense rainfall upstream. Wadi hydrology is especially important for road design, hiking safety, rural settlements, dams, tourism projects and utility corridors.

| Wadi / Area | Emirate / Region | Professional significance |
|---|---|---|
| Wadi Ham | Fujairah / east coast | Among the major drainage systems into Fujairah; relevant to road crossings, flood channels and rural development. |
| Wadi Wurayah | Fujairah | Protected mountain area with biodiversity value; development should consider conservation status and access controls. |
| Wadi Shawka | Ras Al Khaimah | Popular recreation area; flash flood and access-road design considerations. |
| Wadi Hatta | Dubai enclave | Hatta Dam, tourism, mountain recreation and hydrological sensitivity. |
| Wadi Al Helo | Sharjah / east-coast approach | Heritage and mountain-route context; road drainage and tourism safety relevant. |
| Wadi Bih / Jebel Jais drainage | RAK | Steep catchments, road gradients, tourism routes and rockfall/flood risk. |
| Al Ain / Jebel Hafeet wadis | Abu Dhabi | Mountain-foot alluvial fans, archaeology, heritage and road drainage. |

### 11.4 Islands and coastal development reference

| Island / Coastal Asset | Emirate | Main use / status | Professional notes |
|---|---|---|---|
| Saadiyat Island | Abu Dhabi | Cultural district, museums, residential, hospitality, NYUAD | Sensitive coastal and cultural district; major master-planned development. |
| Yas Island | Abu Dhabi | Tourism, F1 circuit, theme parks, hospitality, residential | High event-footfall and traffic planning requirements. |
| Al Maryah Island | Abu Dhabi | ADGM financial district, healthcare, commercial | International financial free-zone overlay. |
| Sir Bani Yas | Abu Dhabi | Wildlife reserve and tourism | Conservation and heritage sensitivity. |
| Dalma | Abu Dhabi | Historic island community and pearl heritage | Transport, heritage and island utility issues. |
| Das / Zirku / Arzanah | Abu Dhabi offshore | Hydrocarbon logistics and processing | Industrial safety, marine environmental controls, offshore emergency planning. |
| Palm Jumeirah | Dubai | Artificial island, residential, hotel, tourism | Reclaimed-land settlement, coastal hydraulics, traffic and utilities. |
| Palm Jebel Ali | Dubai | Large artificial island redevelopment | Long-horizon master planning and infrastructure staging. |
| The World Islands | Dubai | Artificial island archipelago | Marine logistics, dredging, breakwater and private-island utilities. |
| Bluewaters | Dubai | Mixed-use island and tourism | Bridge/transport interface and marine edge design. |
| Abu Musa | Claimed by Sharjah / occupied by Iran | Disputed island | Sovereignty dispute; do not treat as operationally available UAE jurisdiction. |
| Greater Tunb / Lesser Tunb | Claimed by RAK / occupied by Iran | Disputed islands | Sovereignty dispute; official UAE position should be checked on MOFA sources. |

## 12. Historical Chronology — Professional Timeline

### 12.1 Archaeological and pre-Islamic periods

| Period | Approximate dates | Evidence / sites | Why it matters |
|---|---:|---|---|
| Neolithic coastal settlements | c. 6000–3500 BCE | Coastal shell middens, early fishing settlements | Establishes long-term coastal adaptation before modern ports and cities. |
| Hafit period | c. 3200–2600 BCE | Jebel Hafeet beehive tombs, Al Ain region | Important for archaeology, heritage protection and tourism planning. |
| Umm Al Nar culture | c. 2600–2000 BCE | Circular tombs, copper trade, Umm Al Nar island, Hili | Shows early long-distance trade with Mesopotamia, Oman and Indus Valley. |
| Wadi Suq period | c. 2000–1300 BCE | Weapons, ceramics, burials | Transitional period in settlement and trade patterns. |
| Iron Age | c. 1300–300 BCE | Falaj irrigation, fortified sites, Al Ain oasis systems | Irrigation heritage influences UNESCO and oasis conservation. |
| Mleiha / Hellenistic-Parthian period | c. 300 BCE–300 CE | Mleiha, coinage, caravan trade | Important for Sharjah archaeology and cultural-tourism projects. |
| Late antique / early Christian period | c. 5th–7th centuries CE | Sir Bani Yas monastery | Evidence of religious and trade diversity before Islam. |

### 12.2 Islamic, Portuguese and Qawasim maritime periods

The region entered Islamic history during the early Islamic expansion. Dibba is traditionally associated with one of the major Ridda Wars battles after the death of Prophet Muhammad. In later centuries, the ports of the southeastern Arabian coast connected the Gulf, East Africa, Persia and the Indian Ocean. Portuguese involvement from the 16th century created fortified coastal nodes and conflict around Hormuz and the approaches to the Gulf. By the 18th century, the Qawasim of Ras Al Khaimah and Sharjah became a major maritime power; British records described this as piracy, while regional narratives frame it as commercial and naval rivalry in an Indian Ocean context.

### 12.3 Trucial States treaty chronology

| Year | Event | Professional / institutional relevance |
|---:|---|---|
| 1820 | General Maritime Treaty between Britain and Gulf rulers | Start of the treaty framework that later produced the term Trucial States. |
| 1835 | Maritime truce arrangements | Seasonal truce developed into longer peace arrangements. |
| 1853 | Perpetual Maritime Truce | Formalised British maritime security order along the coast. |
| 1892 | Exclusive Agreements | Britain controlled external relations; rulers retained internal authority. |
| 1930s | Oil concessions begin | Petroleum concession law and state finance began to shape modern institutions. |
| 1952 | Trucial States Council established | Early inter-emirate administrative cooperation. |
| 1968 | Britain announces withdrawal east of Suez | Immediate trigger for federation negotiations. |
| 1971 | UAE founded on 2 December | Federal state established; RAK joined in February 1972. |

### 12.4 Post-federation development chronology

| Decade | Key developments |
|---|---|
| 1970s | Federation institutions built; oil revenues funded roads, housing, schools, hospitals and ports; UAE dirham introduced; ADNOC and key state institutions consolidated. |
| 1980s | GCC founded; Jebel Ali Free Zone and Emirates airline created; Dubai's trade/logistics model accelerated; Abu Dhabi continued hydrocarbon and sovereign investment strategy. |
| 1990s | Gulf War security environment; Dubai tourism and real-estate positioning strengthened; free-zone model expanded; ports and airports became regional hubs. |
| 2000s | Burj Khalifa, Palm Jumeirah, DIFC, ADGM planning, global property boom and 2008–2009 crisis; Abu Dhabi and Dubai bailout/restructuring arrangements became central to financial history. |
| 2010s | Expo 2020 awarded; major legal reforms; nuclear programme construction; renewable-energy mega-projects; UAE increasingly active in diplomacy, aid and regional security. |
| 2020s | COVID-19 response, Mars Hope Probe, Abraham Accords, Expo 2020 Dubai, COP28, FATF grey-list exit, corporate tax implementation, rail network launch, major civil/commercial law reforms and digital-government expansion. |

## 13. Constitutional and Federal Governance Detail

### 13.1 Federal structure

The UAE is a federation in which federal authority and emirate authority coexist. Federal competences cover foreign affairs, defence, security, nationality, immigration, currency, federal taxation, communications, air traffic control, labour and other matters listed in the Constitution. Residual powers remain with the emirates. In practice, Abu Dhabi and Dubai have especially extensive local institutional systems, while the federal government provides common rules for labour, immigration, civil transactions, corporate tax, VAT, criminal law, data protection and many strategic policies.

### 13.2 Supreme Council, President and Cabinet

| Institution | Composition | Main functions | Notes |
|---|---|---|---|
| Federal Supreme Council | Rulers of the seven emirates | Supreme constitutional authority; elects President and Vice President; approves major federal matters | Abu Dhabi and Dubai rulers are central to quorum and political practice. |
| President | Elected by Supreme Council from among rulers | Head of state, federal decrees, appointments, representation | Historically the Ruler of Abu Dhabi. |
| Vice Presidents | Elected / appointed according to federal arrangements | Support federal executive leadership | Dubai ruler serves as Vice President and Prime Minister in current practice. |
| Council of Ministers / Cabinet | Prime Minister, deputies, ministers and ministers of state | Federal executive authority; policies, strategies, federal services | Cabinet portfolios are frequently updated; live cabinet list should be verified before publication use. |
| Federal National Council | 40 members, half elected through electoral colleges and half appointed | Advisory parliamentary role; reviews laws and questions ministers | Not a party-based legislature; political parties are not part of UAE system. |
| Federal Supreme Court | Federal constitutional and high judicial authority | Constitutional disputes, federal matters, inter-emirate disputes, selected criminal matters | Dubai and Abu Dhabi maintain local judicial systems for many matters. |

### 13.3 Practical implications of federalism

A professional working in the UAE must separate four layers of authority: federal laws, emirate laws, free-zone regimes, and sector regulators. A business may be licensed in a free zone but still need federal tax registration, MOHRE or free-zone employment compliance, customs registration, banking KYC, VAT/corporate tax filings, and sector-specific permissions. A construction project may sit under Dubai Municipality, Trakhees, DMT, a free-zone authority, or a local municipality, while also needing Civil Defence, utility, transport, environmental and property approvals.

## 14. Economy and Investment Architecture

### 14.1 Macro-economic structure

The UAE economy combines a large hydrocarbon base, sovereign capital, free-zone trade, aviation, ports, tourism, real estate, financial services, renewable energy and advanced-technology policy. Abu Dhabi remains the hydrocarbons and sovereign-investment centre; Dubai is the trade, tourism, aviation, logistics, finance and real-estate hub; Sharjah, RAK, Fujairah and the smaller emirates provide manufacturing, culture, ports, quarrying, affordable housing, free-zone and SME ecosystems.

| Sector | Main emirates / institutions | Reference issues |
|---|---|---|
| Oil and gas | Abu Dhabi, ADNOC, offshore islands, Ruwais | Concession terms, environmental permits, sour gas, LNG, downstream petrochemicals. |
| Trade and logistics | Dubai, JAFZA, DP World, Jebel Ali, DWC, KIZAD, Fujairah | Customs, free-zone licensing, port health, import permits, bonded warehouses. |
| Aviation | Dubai Airports, Emirates, flydubai, Etihad, Air Arabia, GCAA | Airline regulation, airport expansion, air cargo, slot coordination, drone rules. |
| Tourism and hospitality | Dubai, Abu Dhabi, RAK, Sharjah, Fujairah | Hotel classification, liquor permits, event permits, tourism fees, brand standards. |
| Real estate | Dubai DLD/RERA, ADREC, freehold zones | Escrow, Oqood, Ejari/Tawtheeq, rental disputes, service charges. |
| Finance | DIFC, ADGM, CBUAE, DFSA, FSRA, CMA, VARA | Banking licences, fund management, capital markets, virtual assets, AML/CFT. |
| Manufacturing | JAFZA, KIZAD, RAKEZ, Hamriyah, Sharjah industrial zones | Industrial licences, EHS, customs, standards, ICV and local-content programmes. |
| Renewable energy | Masdar, DEWA, EWEC, solar parks | PPAs, grid connection, land, utility procurement, carbon reporting. |

### 14.2 Sovereign wealth and state-owned enterprise ecosystem

| Institution | Role | Typical sectors |
|---|---|---|
| ADIA | Long-term global investment authority for Abu Dhabi | Public equities, fixed income, real estate, private equity, infrastructure. |
| Mubadala | Strategic investment company | Technology, aerospace, healthcare, energy, semiconductors, renewables. |
| ADQ | Abu Dhabi holding company for domestic strategic assets | Ports, food, healthcare, transport, utilities, industrial assets. |
| ICD | Dubai investment holding company | Emirates Group, banking, real estate, transport and Dubai strategic assets. |
| ADNOC | Abu Dhabi national energy company | Upstream, gas, refining, chemicals, logistics, drilling, distribution. |
| DEWA | Dubai utility | Electricity, water, district energy interface, solar park, smart grid. |
| AD Ports Group | Abu Dhabi ports and logistics | Ports, maritime, industrial zones, logistics, economic zones. |
| DP World | Dubai-origin global ports and logistics operator | Ports, terminals, logistics parks, trade corridors. |

### 14.3 Trade, customs and CEPA orientation

The UAE's trade model relies on import, storage, re-export, value-added logistics, free-zone warehousing, gold and precious-stones trading, electronics, automotive re-export, food logistics and regional distribution. Dubai's Jebel Ali and JAFZA are central to this model, but Abu Dhabi's Khalifa Port/KIZAD and Fujairah's bunkering and east-coast port system are also strategic. Comprehensive Economic Partnership Agreements (CEPAs) with India and other states are designed to reduce tariffs, improve investment access and make the UAE a hub for regional trade.

## 15. Demographics, Society and Labour Structure

### 15.1 Population pattern

The UAE has one of the world's highest expatriate shares. This creates a labour market with a small national population, a large private-sector expatriate workforce, and significant household, construction, hospitality, logistics, retail and professional-service labour segments. Demographic statistics vary by source and by whether they count residents, nationals, migrant workers, dependants or census-enumerated population. For official work, use FCSC, emirate statistics centres or the relevant regulator, and mark estimates clearly.

| Population feature | Practical meaning |
|---|---|
| High expatriate share | Labour, housing, schools, healthcare and immigration rules are central to business planning. |
| Male-skewed workforce | Construction, logistics, transport and industrial labour drive demographic gender imbalance. |
| Emiratisation policy | Private-sector firms above thresholds face quota and penalty systems; NAFIS provides incentives. |
| Multi-curriculum education | British, Indian, American, IB, French, Pakistani, Filipino and MoE curricula create a complex school market. |
| Transient residence | Visa status, employment status and sponsor arrangements affect tenancy, banking, healthcare and schooling. |

### 15.2 Labour force sector map

| Sector | Common workforce characteristics | Regulatory interfaces |
|---|---|---|
| Construction | Large expatriate labour force, subcontractors, site accommodation | MOHRE, WPS, municipality, Civil Defence, OHS, accommodation standards. |
| Hospitality and F&B | Shift work, service staff, alcohol/hotel rules, food safety | DET/DTCM, municipality food safety, MOHRE, immigration, Civil Defence. |
| Domestic work | Separate domestic worker law and recruitment agencies | MOHRE/domestic worker framework, ICP, recruitment agency rules. |
| Finance and professional services | High-skilled expatriates, free-zone employment contracts | DIFC/ADGM employment law, CBUAE/DFSA/FSRA, MOHRE depending on jurisdiction. |
| Logistics and transport | Drivers, port workers, warehouse staff | RTA/MOEI/GCAA/ports/customs, MOHRE, OHS. |
| Retail | Large mall workforce, variable hours, part-time work | MOHRE, mall operator rules, consumer protection, VAT. |

## 16. Infrastructure Systems — Expanded Detail

### 16.1 Roads and tolling

| Road / System | Description | Professional use |
|---|---|---|
| E11 | Main Abu Dhabi-Dubai-Ras Al Khaimah coastal highway corridor | Freight, commuting, intercity travel, logistics and emergency planning. |
| E311 | Mohammed bin Zayed Road, major parallel corridor | Industrial, logistics and suburban connectivity. |
| E611 | Emirates Road outer corridor | Heavy vehicles, bypass traffic, logistics links. |
| E66 | Dubai-Al Ain / Hatta connectivity depending segment reference | Tourism, regional access, mountain routes. |
| E44 | Dubai-Hatta road corridor | Hatta tourism and Oman-border movement. |
| Salik | Dubai electronic tolling system | Travel-cost modelling, fleet management and logistics pricing. |

### 16.2 Rail and metro

The national freight network has become an important industrial logistics layer, especially for aggregates, sulphur, cement, containers and future passenger movement. Dubai Metro is the country's most mature urban rail network and anchors transit-oriented development around the Red and Green Lines, Route 2020 and future Blue Line works. Abu Dhabi's rail/metro planning remains important but should be checked against live procurement and DMT announcements.

### 16.3 Airports and aviation infrastructure

| Airport | Role | Notes |
|---|---|---|
| DXB | Dubai International; Emirates and flydubai hub | One of the world's busiest international passenger airports; capacity constraints drive DWC strategy. |
| DWC | Al Maktoum International; future mega-hub | Long-term relocation/expansion target for Dubai aviation and logistics. |
| AUH | Abu Dhabi International / Zayed International branding context [verify] | Etihad hub; Terminal A transformed capacity and passenger experience. |
| SHJ | Sharjah International | Air Arabia hub and important cargo/passenger airport. |
| RKT | Ras Al Khaimah | Tourism and low-cost growth potential. |
| FJR | Fujairah | Cargo, east-coast logistics and strategic location. |
| AAN | Al Ain | Secondary Abu Dhabi emirate airport and training/cargo potential. |

### 16.4 Ports and maritime infrastructure

| Port | Emirate | Strategic function |
|---|---|---|
| Jebel Ali | Dubai | Container, free-zone integration, regional re-export, DP World flagship. |
| Khalifa Port | Abu Dhabi | Semi-automated terminals, KIZAD integration, industrial logistics. |
| Fujairah Port | Fujairah | Bunkering, oil storage, east-coast shipping outside Gulf chokepoint. |
| Khor Fakkan | Sharjah | East-coast container port and Indian Ocean access. |
| Mina Zayed / Abu Dhabi ports | Abu Dhabi | Cruise, legacy port functions, waterfront redevelopment. |
| Ajman / UAQ / RAK ports | Northern Emirates | Regional cargo, fishing, industrial and SME logistics. |

### 16.5 Power and water

The UAE power-water system is shaped by summer peak cooling demand, desalination, high reliability expectations and rapid solar deployment. Utilities are emirate-specific, but federal energy policy, climate targets and grid integration increasingly matter. Desalination and district cooling are especially important because potable water and cooling are core operating costs for buildings, hotels, malls and industrial facilities.

## 17. Education System — Expanded Reference

### 17.1 School governance

| Segment | Regulator | Notes |
|---|---|---|
| Federal public schools | Ministry of Education | UAE nationals receive public education; national curriculum and Arabic/Islamic studies obligations apply. |
| Dubai private schools | KHDA | Inspection reports, fee framework, curriculum licensing and school ratings. |
| Abu Dhabi private schools | ADEK | School licensing, fee approvals, inspection framework and education policy. |
| Sharjah and Northern Emirates private schools | MoE/local education authorities depending jurisdiction [verify] | Curriculum and licensing requirements vary by emirate and authority. |
| Higher education | CAA / free-zone education regulators | Programme accreditation, institutional licensing and professional recognition. |

### 17.2 Higher-education landscape

The UAE higher-education market includes federal universities, emirate-backed institutions, private universities, branch campuses and free-zone education hubs. Key names include UAE University, Khalifa University, University of Sharjah, American University of Sharjah, American University in Dubai, New York University Abu Dhabi, Sorbonne University Abu Dhabi, Heriot-Watt University Dubai, Middlesex University Dubai, Rochester Institute of Technology Dubai and many others. Professional users should check CAA licensing and programme accreditation where a degree is to be used for visa, engineering registration, healthcare licensing, legal admission or academic employment.

## 18. Healthcare System — Expanded Reference

### 18.1 Regulator map

| Jurisdiction | Regulator | Scope |
|---|---|---|
| Dubai | Dubai Health Authority (DHA) | Healthcare facility and professional licensing, insurance framework, clinical standards. |
| Abu Dhabi | Department of Health Abu Dhabi (DoH) | Healthcare licensing, insurance, health data, hospital performance and Malaffi. |
| Northern Emirates | MOHAP | Facility and professional licensing outside emirate-specific authorities. |
| DHCC | Dubai Healthcare City Authority | Healthcare free-zone licensing and clinical governance. |

### 18.2 Major healthcare themes

The UAE healthcare system combines mandatory insurance, public hospitals, private clinics, medical tourism, digital health information exchanges and strict licensing. Disease-burden priorities include diabetes, obesity, cardiovascular disease, cancer screening, road injuries and lifestyle-related chronic disease. Hospitals and clinics must manage licensing, facility inspections, professional credentialing, medical-device approvals, pharmaceuticals, insurance claims and data-protection obligations.

## 19. Culture, Religion and Social Practice — Expanded Reference

### 19.1 Cultural forms

| Cultural element | Detail | Professional relevance |
|---|---|---|
| Falconry | UNESCO-listed regional tradition; falcon passports and veterinary infrastructure are important | Tourism, customs, animal health, event planning. |
| Camel racing | Robot jockeys, major tracks, high-value competitions | Sports tourism, animal welfare, event traffic. |
| Pearl diving | Historic economic foundation before oil; seasonal diving terminology remains heritage content | Museums, cultural programming, school curricula, tourism. |
| Al Sadu | Bedouin weaving tradition | Heritage preservation, cultural design, museum retail. |
| Dhow building | Maritime craft linked to Creek and Gulf trade | Heritage districts, events, coastal tourism. |
| National dress | Kandura, ghitra/agal, abaya, shayla; context-specific etiquette | Hospitality, protocol, HR and public-facing service design. |

### 19.2 Religion and law in public life

Islam is the official religion and Sharia is a principal source of legislation at the constitutional level. At the same time, the UAE hosts a large non-Muslim expatriate population with churches, temples and designated places of worship. Public holidays follow both Gregorian dates and the Islamic lunar calendar. Ramadan affects working hours, hospitality operations, event scheduling and retail footfall. Alcohol, pork and nightlife operate through licensing systems and vary by emirate and venue type.

## 20. Landmark and Tourism Inventory

| Emirate | Key landmarks / assets | Notes |
|---|---|---|
| Abu Dhabi | Sheikh Zayed Grand Mosque, Louvre Abu Dhabi, Qasr Al Hosn, Yas Island, Saadiyat Cultural District, Al Ain Oasis, Qasr Al Watan, Liwa, Sir Bani Yas | Mix of federal capital, culture, heritage, desert tourism and major events. |
| Dubai | Burj Khalifa, Dubai Mall, Museum of the Future, Palm Jumeirah, Dubai Creek, Al Seef, Jumeirah Mosque, Hatta, Expo City, DIFC, Dubai Marina | Tourism and business events are central to economy. |
| Sharjah | Sharjah Heritage Area, Heart of Sharjah, Sharjah Art Foundation, Mleiha, Khor Fakkan amphitheatre, Kalba mangroves | UNESCO/cultural positioning and east-coast nature assets. |
| Ajman | Ajman Museum, Ajman Corniche, Al Zorah mangroves | Smaller-scale tourism and coastal lifestyle. |
| Umm Al Quwain | UAQ mangroves, Dreamland area, old town, islands | Nature, archaeology and low-density tourism. |
| Ras Al Khaimah | Jebel Jais, Jais Flight, Al Hamra, Dhayah Fort, Suwaidi Pearls | Mountain tourism, adventure sports, heritage and beach resorts. |
| Fujairah | Fujairah Fort, Al Bidya Mosque, Snoopy Island, Wadi Wurayah, Dibba, Port of Fujairah | East-coast beaches, diving, mountains and maritime logistics. |

## 21. 2025–2026 Update Log for the General Library

| Topic | 2025–2026 relevance | Verification note |
|---|---|---|
| New Civil Code | Federal Decree-Law No. 25 of 2025 scheduled to reshape civil transactions from 2026 | Check MOJ/elaws for official Arabic text and any English translation. |
| Companies Law amendments | Federal Decree-Law No. 20 of 2025 referenced for class shares, redomiciliation and corporate changes | Check Ministry of Economy/MOJ for implementation decisions. |
| Capital Market Authority | SCA-to-CMA transition referenced for 2026 | Check live regulator portal before using official name in submissions. |
| Etihad Rail passenger service | Passenger-launch references included in the project materials | Verify route, station and timetable with Etihad Rail live announcements. |
| Health insurance expansion | Northern Emirates mandatory insurance references appear in research | Verify with MOHAP/ICP and insurer portals for live implementation. |
| Emiratisation penalties | 2026 penalty references included in business/labour materials | Verify with MOHRE/NAFIS live dashboard rules. |
| AI/digital regulation | AI Strategy 2031, PDPL and digital government remain fast-moving | Verify with TDRA, UAE Data Office and Cybersecurity Council before relying on compliance statements. |

## 22. Verification Notes

This file deliberately separates stable background facts from operationally live facts. Geography, historical periods, institutional roles and emirate profiles are relatively stable. Population, GDP, cabinet membership, school rankings, bank assets, tariffs, airport passenger numbers, rail-launch dates, visa requirements and regulatory fees are live operational data and must be checked against the relevant official portal or statistical authority before contractual, legal, investment or engineering reliance. Where exact figures in the existing file conflicted with other common estimates, the safer practice is to treat them as approximate and verify from FCSC, SCAD, DSC, CBUAE, ministry portals or regulator publications.

### Appendix G1: Geography verification checklist

This checklist is included to make the library operational for professional use and to prevent reliance on outdated estimates.

- Confirm coordinates from municipality/gis. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Confirm area and population from statistical authority. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Check protected-area constraints. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Check flood and wadi maps. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Check geotechnical and groundwater data. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.

### Appendix G2: Government verification checklist

This checklist is included to make the library operational for professional use and to prevent reliance on outdated estimates.

- Confirm cabinet list on uae cabinet portal. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Check constitution text on official portal. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Check federal/local jurisdiction split. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Check free-zone exceptions. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Verify decree commencement dates. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.

### Appendix G3: Economy verification checklist

This checklist is included to make the library operational for professional use and to prevent reliance on outdated estimates.

- Confirm gdp from fcsc/imf. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Confirm bank assets from audited annual reports. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Confirm sovereign fund disclosures. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Confirm trade data from customs/statistics. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
- Confirm oil and gas data from adnoc/opec. Record the source portal, publication date, page title, URL and any reference number before using the fact in a report, contract, permit file or investor memorandum.
