# UAE Environmental, Sustainability and Safety Regulations: Comprehensive Guide (2026 Edition)

## 1. ENVIRONMENTAL LEGAL FRAMEWORK — COMPLETE

The United Arab Emirates (UAE) has established a robust and evolving legal framework to protect its unique desert and marine ecosystems while supporting rapid industrial and urban growth. The primary legislation is federal, supplemented by emirate-specific regulations that often set more stringent local requirements.

### 1.1 Federal Law No. 24 of 1999: Protection and Development of the Environment
This is the foundational environmental law of the UAE. It provides the legal basis for environmental protection, pollution control, and sustainable development.

#### 1.1.1 Chapters and Articles (Detailed Summary)
*   **Chapter 1: General Provisions (Articles 1–7)**
    *   **Article 1**: Definitions. Key terms: "Environment" (the biosphere in which human beings and other living creatures live), "Pollution" (any change in the properties of the environment which may lead directly or indirectly to harm to living creatures).
    *   **Article 2**: Objectives. To protect the environment and its quality, to control all forms of pollution, and to avoid any immediate or long-term harmful effects.
    *   **Article 3**: Scope. Applies to all land, water, and air within the UAE's jurisdiction, including the exclusive economic zone.
    *   **Article 4**: MOCCAE Authority. The Ministry is responsible for proposing environmental policies, setting standards, and coordinating with local authorities.
    *   **Article 5**: Competent Authorities. Defines the role of emirate-level agencies (e.g., EAD, DM) in implementing the law.
    *   **Article 6**: Monitoring Networks. Mandates the establishment of national networks to monitor air, water, and soil quality.
    *   **Article 7**: Environmental Education. Requires the integration of environmental topics into school curricula and public awareness campaigns.
*   **Chapter 2: Environmental Impact Assessment (Articles 8–16)**
    *   **Article 8**: Mandatory EIA. No project shall be licensed without an EIA study.
    *   **Article 9**: Screening. The competent authority determines the level of assessment required (Full EIA or PER).
    *   **Article 10**: Scoping. Agreement on the environmental parameters to be studied.
    *   **Article 11**: Baseline. Collection of data on the existing environment before project commencement.
    *   **Article 12**: Impact Prediction. Using scientific methods to forecast the project's effects.
    *   **Article 13**: Mitigation. Identification of measures to prevent or reduce negative impacts.
    *   **Article 14**: **CRITICAL REQUIREMENT**. "No project or activity shall be started by any person or establishment before obtaining the environmental permit from the competent authority."
    *   **Article 15**: Review. The authority has 30 days to review the EIA and issue a decision.
    *   **Article 16**: Monitoring. The project owner must monitor environmental performance and report to the authority.
*   **Chapter 3: Protection of Atmospheric Environment (Articles 17–27)**
    *   **Article 17**: Emission Limits. Prohibits emissions exceeding the limits set in the executive regulations.
    *   **Article 18**: Stationary Sources. Factories and power plants must use the best available technology to control emissions.
    *   **Article 19**: Stack Design. Requirements for stack height and sampling ports.
    *   **Article 20**: Indoor Air. Standards for air quality in public buildings and workplaces.
    *   **Article 21**: Open Burning. Strictly prohibited for all types of waste.
    *   **Article 22**: Mobile Sources. Vehicles must meet emission standards; periodic testing is mandatory.
    *   **Article 23**: Fuel Standards. Regulation of lead and sulfur content in petrol and diesel.
    *   **Article 24**: ODS Control. Licensing for the import and use of ozone-depleting substances.
    *   **Article 25**: Noise Control. Limits for noise in residential, commercial, and industrial areas.
    *   **Article 26**: Vibration. Control of vibrations from construction and industrial activities.
    *   **Article 27**: Odor. Regulation of unpleasant odors from waste facilities and factories.
*   **Chapter 4: Protection of Marine Environment (Articles 28–49)**
    *   **Article 28**: Oil Discharge. Prohibits any intentional discharge of oil from ships or land-based sources.
    *   **Article 29**: Contingency Plans. All ports and oil terminals must have an oil spill response plan.
    *   **Article 30**: Reporting. Immediate notification of any spill or discharge.
    *   **Article 31**: Liability. The polluter is responsible for all cleanup costs and damages.
    *   **Article 32**: Compensation. Legal framework for claiming damages to marine resources.
    *   **Article 33**: Marine Life. Protection of fish stocks, coral reefs, and seagrass beds.
    *   **Article 34**: Offshore Drilling. Strict environmental controls for oil and gas exploration.
    *   **Article 35**: Dumping. Prohibits the dumping of any waste or hazardous substances into the sea.
    *   **Article 36**: Sewage. Regulation of sewage discharge from ships and coastal facilities.
    *   **Article 37**: Ballast Water. Management of ballast water to prevent the introduction of invasive species.
    *   **Article 38**: Garbage. Prohibits the disposal of plastic and other garbage into the sea.
    *   **Article 39**: Port Facilities. Ports must provide facilities for receiving ship waste.
    *   **Article 40**: Coastal Management. Regulation of construction and development in the coastal zone.
    *   **Article 41**: Mangroves. Strict protection of mangrove forests; no cutting or removal allowed.
    *   **Article 42**: Dredging. Licensing and monitoring of dredging and reclamation activities.
    *   **Article 43**: MPAs. Establishment and management of marine protected areas.
    *   **Article 44**: Enforcement. Powers of the Coast Guard and environmental inspectors.
    *   **Article 45**: Cooperation. Regional and international cooperation for marine protection.
    *   **Article 46**: Research. Promotion of marine scientific research.
    *   **Article 47**: Data Access. Public access to information on marine quality.
    *   **Article 48**: Emergency. Procedures for responding to major marine disasters.
    *   **Article 49**: Penalties. Specific fines for marine pollution violations.
*   **Chapter 5: Protection of Land Environment (Articles 50–68)**
    *   **Article 50**: Hazardous Waste. Regulation of the generation, storage, and disposal of hazardous waste.
    *   **Article 51**: Licensing. All waste management facilities require a license.
    *   **Article 52**: Segregation. Mandatory segregation of hazardous and non-hazardous waste.
    *   **Article 53**: Transport. Requirements for vehicles transporting hazardous waste.
    *   **Article 54**: Transboundary. Regulation of waste import and export.
    *   **Article 55**: Soil Quality. Prevention of soil contamination from industrial and agricultural activities.
    *   **Article 56**: Pesticides. Regulation of the sale and use of agricultural chemicals.
    *   **Article 57**: Biodiversity. Protection of native plants and animals.
    *   **Article 58**: Noise. Control of noise from land-based sources.
    *   **Article 59**: Natural Reserves. Establishment and management of terrestrial protected areas.
    *   **Article 60**: Wildlife Trade. Implementation of CITES regulations.
    *   **Article 61**: Heritage. Protection of archaeological and cultural sites from environmental damage.
    *   **Article 62**: Zoning. Integration of environmental considerations into land-use planning.
    *   **Article 63**: Desertification. Measures to prevent land degradation and sand encroachment.
    *   **Article 64**: Greening. Promotion of urban forestry and landscaping.
    *   **Article 65**: Participation. Encouraging public involvement in environmental decision-making.
    *   **Article 66**: Audits. Mandatory environmental audits for high-risk land activities.
    *   **Article 67**: Remediation. Requirement for polluters to restore contaminated land.
    *   **Article 68**: Penalties. Specific fines for land-based violations.

*   **Chapter 6: Penalties (Articles 69–83)**
    *   This chapter outlines the fines and imprisonment terms for violations.

#### 1.1.2 Penalty Schedule (Articles 69–83)
The UAE environmental law is known for its strict penalty regime, designed to deter large-scale industrial pollution.

| Article | Violation Type | Penalty (Fine Range) | Imprisonment |
| :--- | :--- | :--- | :--- |
| **Art 69** | Discharge of oil/hazardous substances from ships | AED 100,000 – 1,000,000 | Up to 2 years |
| **Art 70** | Failure to report a discharge or spill | AED 10,000 – 50,000 | N/A |
| **Art 71** | Illegal dumping of hazardous waste in marine environment | AED 1,000,000 – 5,000,000 | Life imprisonment (if nuclear) |
| **Art 72** | Failure to conduct EIA or violating permit conditions | AED 5,000 – 50,000 | N/A |
| **Art 73** | Exceeding air emission limits (stationary sources) | AED 10,000 – 100,000 | N/A |
| **Art 74** | Violation of noise standards | AED 500 – 5,000 | N/A |
| **Art 75** | Improper handling/disposal of municipal waste | AED 1,000 – 10,000 | N/A |
| **Art 76** | Illegal import of hazardous waste | AED 100,000 – 1,000,000 | Minimum 5 years |
| **Art 77** | Violation of marine environment protection rules | AED 50,000 – 500,000 | Up to 1 year |
| **Art 78** | Violation of land environment protection rules | AED 10,000 – 100,000 | N/A |
| **Art 79** | Violation of biodiversity protection rules | AED 5,000 – 50,000 | N/A |
| **Art 80** | Violation of natural reserve regulations | AED 10,000 – 100,000 | Up to 6 months |
| **Art 81** | Violation of water resources protection rules | AED 5,000 – 50,000 | N/A |
| **Art 82** | General penalties for unspecified violations | AED 1,000 – 10,000 | N/A |
| **Art 83** | Repeat Offenses | Double the maximum fine | Double the term |

#### 1.1.3 Enforcement and Appeals
*   **Enforcement Mechanism**:
    *   **Judicial Officers**: MOCCAE and emirate-level agencies (EAD, DM, SEPAA) have judicial officers with the power to inspect facilities, take samples, and issue fines or closure orders.
    *   **Inspections**: Regular and unannounced inspections of industrial and commercial facilities.
    *   **Monitoring**: Use of remote sensing, drones, and real-time monitoring stations.
*   **Appeals Process**:
    *   **Administrative Appeal**: Violators can appeal administrative decisions to the Minister (MOCCAE) or the head of the competent authority within 30 days of notification.
    *   **Judicial Appeal**: If the administrative appeal is rejected, the violator can file a case in the UAE Federal Court system.
    *   **Grievance Committee**: Some emirates (like Abu Dhabi) have specific grievance committees for environmental permits.

---

### 1.2 Federal Law No. 12 of 2018: Integrated Waste Management
This law shifted the UAE's focus from simple disposal to a circular economy model.

#### 1.2.1 Chapters and Scope
*   **Chapter 1**: Definitions and general objectives (reducing waste generation, protecting public health).
*   **Chapter 2**: Waste Management Planning (National Waste Management Strategy, emirate-level plans).
*   **Chapter 3**: Waste Handling and Disposal (segregation at source, collection, transport, treatment).
*   **Chapter 4**: Hazardous Waste Management (strict tracking, manifest system, licensing).
*   **Chapter 5**: Extended Producer Responsibility (EPR) and Circular Economy.
*   **Chapter 6**: Penalties and Enforcement.

#### 1.2.2 Waste Categories and Definitions
1.  **Municipal Solid Waste (MSW)**: Household, commercial, and institutional waste.
2.  **Hazardous Waste**: Waste with toxic, flammable, corrosive, or reactive properties (e.g., chemicals, batteries).
3.  **Industrial Waste**: By-products of manufacturing, mining, and energy production.
4.  **Construction & Demolition (C&D) Waste**: Concrete, steel, wood, and soil from building sites.
5.  **Medical Waste**: Infectious, chemical, or radioactive waste from healthcare and research.
6.  **Agricultural Waste**: Waste from farming, livestock, and forestry.
7.  **Sewage Sludge**: Solid residue from wastewater treatment.

#### 1.2.3 Duty of Care Chain
The law establishes a "Cradle-to-Grave" responsibility:
*   **Generator**: Responsible for segregation, safe storage, and ensuring waste is handed to a licensed collector.
*   **Transporter**: Must be licensed, use GPS-tracked vehicles, and follow approved routes.
*   **Treater**: Must use approved technologies (e.g., incineration, composting, recycling) and meet emission standards.
*   **Disposer**: Final disposal in licensed landfills or WtE plants with proper liner and leachate systems.

#### 1.2.4 Licensing Requirements
*   **Waste Collectors**: Must have a valid license from the emirate authority (e.g., Tadweer in Abu Dhabi).
*   **Waste Transporters**: Vehicles must be inspected and licensed for specific waste types (e.g., hazardous).
*   **Waste Facilities**: Landfills, incinerators, and recycling plants require an Environmental Permit and a Waste Management License.

#### 1.2.5 Extended Producer Responsibility (EPR)
*   **Sectors**: Packaging (plastic, glass, metal, composite), Electronics (E-waste), Tires, and Lead-acid batteries.
*   **Timelines**: Packaging EPR launched in 2023; full implementation for electronics by 2026.
*   **Requirement**: Producers must fund the collection and recycling of their products at end-of-life.
*   **Targets**: 30% recycling rate for packaging by 2025; 50% by 2030.

#### 1.2.6 Waste Statistics (UAE)
*   **Total Waste Generated**: ~32 million tonnes/year (2022).
*   **Per Capita Generation**: ~2.3 kg/person/day (one of the world's highest).
*   **Landfill Diversion Target**: 75% by 2030.
*   **Recycling Rate**: Currently ~24% overall; target 75% for MSW by 2030.

---

### 1.3 Federal Law No. 23 of 1999: Aquatic Resources
Focuses on the protection of the UAE's rich marine biodiversity and the regulation of the fishing industry.

*   **Closed Seasons**:
    *   **Kingfish (Kanaad)**: Fishing prohibited from February 11 to April 10.
    *   **Sherry and Safi**: Fishing prohibited from March 1 to April 30.
*   **Protected Species**:
    *   **Hawksbill Turtle**: Critically endangered; nesting sites protected.
    *   **Dugong**: UAE holds the world's 2nd largest population (~3,000).
    *   **Whale Shark**: Seasonal visitors; strictly protected from fishing.
    *   **Hammerhead Shark**: Protected under CITES and local law.
    *   **Green Turtle**: Common in UAE waters; nesting sites protected.
*   **Fishing Vessel Licensing**:
    *   All fishing vessels must have a MOCCAE license.
    *   Vessels must be owned by UAE nationals.
    *   Maximum number of licenses per emirate is capped.
*   **Aquaculture Permits**:
    *   Establishing a fish farm requires a permit from MOCCAE and the local authority.
    *   Environmental monitoring of water quality and feed is mandatory.
*   **Artificial Reef Programme**:
    *   MOCCAE has deployed over 3,000 artificial reef units to enhance fish stocks and coral growth.
    *   Prohibited to fish within 500m of an artificial reef.

---

### 1.4 Federal Law No. 26 of 2009: Water Resources
Regulates the extraction and use of the UAE's scarce groundwater.

*   **Groundwater Extraction Permit Process**:
    1.  Application to the competent authority (e.g., EAD).
    2.  Site inspection and aquifer assessment.
    3.  Issuance of permit with specific extraction limits (m³/day).
    4.  Installation of a smart meter.
*   **Metering Requirements**:
    *   All agricultural and industrial wells must have smart meters.
    *   Data is transmitted wirelessly to the regulator.
*   **Water Quality Monitoring**:
    *   Regular testing for salinity, nitrates, and heavy metals.
    *   Prohibition on activities that may contaminate aquifers (e.g., improper waste disposal).
*   **Aquifer Recharge Projects**:
    *   **Liwa Strategic Water Reserve**: Stores 26 million m³ of desalinated water in natural aquifers.
    *   **Wadi Dams**: Over 150 dams across the UAE to capture rainwater and recharge aquifers.


---

### 1.5 Noise and Light Pollution Standards

#### 1.5.1 Noise Pollution (Ministerial Resolution No. 12 of 2006 Annex III)
| Area Category | Daytime (7am–10pm) | Night-time (10pm–7am) |
| :--- | :--- | :--- |
| **Residential Areas** | 55 dB(A) | 45 dB(A) |
| **Commercial Areas** | 65 dB(A) | 55 dB(A) |
| **Industrial Zones** | 70 dB(A) | 70 dB(A) |
| **Construction Sites** | 65 dB(A) | Prohibited (unless permit) |

#### 1.5.2 Light Pollution
*   **Dubai Municipality**: Regulations on outdoor lighting to prevent "sky glow" and nuisance to neighbors.
*   **Al Marmoom Dark Sky Reserve**: One of the world's first desert dark sky reserves, protecting astronomical observations and nocturnal wildlife.

---

## 2. ENVIRONMENTAL IMPACT ASSESSMENT (EIA) — COMPLETE PROCESS

The EIA process in the UAE is governed by **Cabinet Resolution No. 37 of 2001**. It is a mandatory planning tool for any project that may have a significant impact on the environment.

### 2.1 Annex I: Mandatory EIA Activities (Full Study Required)
Projects in this category must undergo a comprehensive EIA study, including baseline monitoring and public consultation.

*   **Oil & Gas Sector**:
    *   Oil refineries (all sizes).
    *   Offshore oil and gas exploration and production platforms.
    *   Cross-country pipelines for oil, gas, or chemicals (>15 km).
    *   Gas processing plants and LNG terminals.
*   **Power & Water Sector**:
    *   Power stations with a thermal output >50 MW.
    *   Nuclear power facilities and radioactive waste storage (all).
    *   Desalination plants with a capacity >10,000 m³/day.
    *   High-voltage transmission lines (>220 kV and >10 km).
*   **Industrial Sector**:
    *   Chemical manufacturing plants (listed hazardous substances).
    *   Cement manufacturing plants (clinker production).
    *   Iron and steel mills (primary production).
    *   Aluminum smelters.
    *   Industrial estates and free zones >50 ha.
*   **Infrastructure & Transport**:
    *   New airports or runway extensions >2,100m.
    *   New sea ports or expansion of berths >500m.
    *   Highways and motorways (new construction >10 km).
    *   Railway lines (inter-city and freight).
*   **Waste Management**:
    *   Waste incineration plants >10 tonnes/day.
    *   Landfills for municipal waste >10,000 tonnes/year.
    *   Hazardous waste treatment and disposal facilities (all).
    *   Wastewater treatment plants >50,000 m³/day.
*   **Mining & Extraction**:
    *   Mining and quarrying activities >25 ha.
    *   Large-scale sand extraction from marine or desert areas.
*   **Coastal & Marine**:
    *   Coastal reclamation and artificial island construction >10 ha.
    *   Dredging activities >100,000 m³.
    *   Dams and water impoundments >1 million m³.
*   **Tourism & Commercial**:
    *   Hotels and resorts >200 rooms in ecologically sensitive areas (mangroves, coral reefs).
    *   Shopping malls >10,000 m² GFA in sensitive areas.
    *   Theme parks and major sports stadiums.

### 2.2 Annex II: Preliminary Assessment Required
Projects in this category require a "Preliminary Environmental Report" (PER). If the PER shows significant impacts, a full EIA may be triggered.

*   **Construction & Real Estate**:
    *   Residential and commercial developments 5,000–50,000 m².
    *   Labor camps and temporary construction facilities.
*   **Agriculture & Forestry**:
    *   Agricultural developments >100 ha.
    *   Large-scale poultry or livestock farms.
*   **Tourism & Leisure**:
    *   Coastal or desert tourism projects <200 rooms.
    *   Golf courses and equestrian centers.
*   **Storage & Logistics**:
    *   Fuel storage facilities <5,000 m³.
    *   Warehousing complexes for non-hazardous goods.
*   **Small-Scale Industry**:
    *   Industrial units <1,000 m² in sensitive areas.
    *   Food processing plants.

### 2.3 EIA Report Structure (MOCCAE/EAD Guidelines)
A standard EIA report must follow a specific structure to be accepted for review:
1.  **Executive Summary**: A non-technical summary of the project, its impacts, and proposed mitigation.
2.  **Project Description**: Detailed design, construction methods, operational phases, and decommissioning plans.
3.  **Legal and Administrative Framework**: List of applicable federal and local laws and international conventions.
4.  **Baseline Environment**:
    *   **Physical**: Air quality, noise, soil, geology, and groundwater.
    *   **Biological**: Terrestrial and marine flora and fauna, including habitat mapping.
    *   **Socio-economic**: Land use, traffic, cultural heritage, and public health.
5.  **Impact Assessment**:
    *   Identification of potential impacts (direct, indirect, cumulative).
    *   Quantification of impacts using modeling (e.g., AERMOD for air, MIKE21 for marine).
    *   Evaluation of impact significance.
6.  **Mitigation Measures**: Specific actions to avoid, minimize, or compensate for impacts.
7.  **Environmental Management Plan (EMP)**:
    *   Organizational structure for environmental management.
    *   Mitigation implementation schedule.
    *   Emergency response procedures.
8.  **Monitoring Plan**: Schedule for testing air, water, noise, and ecology during construction and operation.
9.  **Non-Technical Summary**: For public consultation purposes.

### 2.4 EIA Costs and Timelines
*   **Review Fee**: AED 5,000 – 50,000 (paid to the regulator).
*   **Consultant Cost**: AED 50,000 – 500,000+ depending on project complexity and baseline requirements.
*   **Timeline**:
    *   **Screening/Scoping**: 2–4 weeks.
    *   **Baseline Data Collection**: 1–12 months (seasonal data often required).
    *   **Report Preparation**: 4–8 weeks.
    *   **Regulator Review**: 30–60 days.

### 2.5 Strategic Environmental Assessment (SEA)
SEA is a higher-level assessment applied to policies, plans, and programs.
*   **Applicability**: Mandatory for large-scale master plans (e.g., Abu Dhabi 2030, Dubai 2040).
*   **Process**: Similar to EIA but focuses on broad strategic alternatives and cumulative impacts across a region.
*   **UAE Practice**: EAD and Dubai Municipality are the leading authorities in implementing SEA for urban and industrial planning.

---

## 3. AIR QUALITY — COMPLETE

The UAE faces unique air quality challenges due to its arid climate (dust/sandstorms) and high industrial activity.

### 3.1 UAE Ambient Air Quality Standards (Cabinet Decree No. 12 of 2006)
| Pollutant | Averaging Period | UAE Standard (μg/m³) | WHO Guideline (2021) |
| :--- | :--- | :--- | :--- |
| **Sulphur Dioxide (SO2)** | 1-hour | 350 | — |
| **Sulphur Dioxide (SO2)** | 24-hour | 150 | 40 |
| **Sulphur Dioxide (SO2)** | Annual | 60 | — |
| **Nitrogen Dioxide (NO2)** | 1-hour | 400 | 200 |
| **Nitrogen Dioxide (NO2)** | 24-hour | 150 | 25 |
| **Nitrogen Dioxide (NO2)** | Annual | 100 | 10 |
| **Carbon Monoxide (CO)** | 1-hour | 30,000 | — |
| **Carbon Monoxide (CO)** | 8-hour | 10,000 | 4,000 |
| **Ozone (O3)** | 1-hour | 200 | — |
| **Ozone (O3)** | 8-hour | 120 | 100 |
| **Particulate Matter (PM10)** | 24-hour | 150 | 45 |
| **Particulate Matter (PM10)** | Annual | 50 | 15 |
| **Particulate Matter (PM2.5)** | 24-hour | 75 | 15 |
| **Particulate Matter (PM2.5)** | Annual | 35 | 5 |
| **Lead (Pb)** | Annual | 0.5 | 0.5 |

### 3.2 National Air Quality Monitoring Network
*   **Stations**: 100+ stations across the UAE, equipped with high-precision analyzers.
*   **Managing Authorities**:
    *   **Abu Dhabi**: Environment Agency Abu Dhabi (EAD) manages 20+ stations.
    *   **Dubai**: Dubai Municipality (DM) manages 15+ stations.
    *   **Federal**: MOCCAE coordinates the national network and data sharing.
*   **Public Access**: Real-time Air Quality Index (AQI) available via the "UAE AQI" app and EAD portal.

### 3.3 Dubai Clean Air Plan 2021–2026
*   **Target**: 90% of days with "Good" or "Moderate" air quality by 2026.
*   **Sectors Targeted**: Transport (30% reduction in NOx), Industry (20% reduction in SO2), and Construction (50% reduction in dust).
*   **Interventions**:
    *   Mandatory vehicle emission testing for all registration renewals.
    *   Industrial permit reforms requiring Best Available Techniques (BAT).
    *   Dust suppression systems mandatory for all construction sites >5,000 m².

### 3.4 Abu Dhabi Air Quality Monitoring (EAD)
*   **Real-time Portal**: EAD provides a public dashboard showing AQI for different pollutants.
*   **AQI Methodology**: Based on the US EPA AQI but adapted for UAE conditions (higher weight for PM10 due to dust).
*   **Mobile Stations**: EAD uses mobile monitoring units for short-term studies near industrial zones or major roads.

### 3.5 Sandstorms and Dust Events
*   **Frequency**: 10–20 major events per year, primarily during the "Shamal" wind season (winter/spring).
*   **Impact**: PM10 spikes can reach **5,000 μg/m³**, significantly exceeding the 24-hour standard.
*   **Public Health Response**: Ministry of Health (MoHAP) issues alerts for respiratory patients; schools may switch to remote learning.
*   **Dubai Roads Dust Closure Procedures**: RTA and Dubai Police implement speed reductions and road closures during severe visibility impairment (<100m).

### 3.6 Industrial Stack Monitoring (CEMS)
*   **Requirement**: Continuous Emission Monitoring Systems (CEMS) mandatory for:
    *   Power plants and desalination units.
    *   Cement and lime factories.
    *   Oil refineries and petrochemical plants.
    *   Waste incinerators.
*   **Reporting Frequency**: Hourly averages must be recorded; monthly summary reports submitted to the regulator.
*   **Calibration Requirements**: Must follow **EN 14181** (QAL1, QAL2, QAL3); Relative Accuracy Test Audits (RATA) required quarterly by an independent laboratory.

### 3.7 Greenhouse Gas (GHG) Emissions
*   **Total Emissions**: ~300 million tonnes CO2e (2022).
*   **Per Capita**: ~26 tCO2e/person (among world's highest).
*   **Sectoral Breakdown**:
    *   **Energy (Power/Water)**: 42% (primarily from natural gas combustion).
    *   **Transport**: 28% (road transport is the largest contributor).
    *   **Industrial Processes**: 18% (cement, aluminum, steel).
    *   **Waste**: 7% (methane from landfills).
    *   **AFOLU (Agriculture, Forestry, Land Use)**: 5%.
*   **National GHG Inventory**: MOCCAE submits the inventory to the UNFCCC biannually as part of the Biennial Transparency Report (BTR).


---

## 4. WATER — COMPLETE

Water security is a national priority, given the lack of natural freshwater sources and the high demand from a growing population and industrial sector.

### 4.1 UAE Water Security Strategy 2036
The strategy aims to ensure sustainable access to water during both normal and emergency conditions.
*   **Strategic Reserve**:
    *   4-day reserve under normal conditions.
    *   16 days in emergencies.
    *   45 days in extreme emergencies.
*   **Efficiency Targets**:
    *   100% water efficiency in agriculture by 2036.
    *   21% reduction in total water demand.
*   **Reuse Targets**:
    *   75% of treated wastewater to be reused (currently ~60%).
    *   100% reuse of treated water for landscaping and industrial cooling.

### 4.2 Desalination Full Data
The UAE is the world's 3rd largest producer of desalinated water.
*   **Total Capacity**: ~7.5 million m³/day (2.7 billion m³/year).
*   **Major Plants**:
    *   **Al Taweelah RO (Abu Dhabi)**: World's largest RO plant (909,000 m³/day).
    *   **Jebel Ali Power & Desalination Complex (Dubai)**: One of the largest MSF complexes.
    *   **Hamriyah RO (Sharjah)**: 410,000 m³/day.
*   **Technology Shift**: Moving from energy-intensive Multi-Stage Flash (MSF) to Reverse Osmosis (RO) to reduce carbon footprint.
*   **Production Cost**: ~AED 4–6/m³; heavily subsidized for residential consumers.

### 4.3 Water Consumption
*   **Average Consumption**: 550 L/person/day (Global average: 170 L).
*   **Sectoral Breakdown**:
    *   **Residential**: 50% (highest per capita in the world).
    *   **Agriculture**: 40% (primarily from groundwater).
    *   **Industrial**: 10%.

### 4.4 Water Tariffs by Emirate (2026)
Tariffs are structured to encourage conservation, with higher rates for expatriates and high-volume users.

#### 4.4.1 Abu Dhabi (ADDC/AADC)
| Category | Consumption (m³/Month) | Tariff (AED/m³) |
| :--- | :--- | :--- |
| **UAE National** | 0 – 30 | 2.09 |
| **UAE National** | >30 | 2.60 |
| **Expatriate** | 0 – 20 | 7.84 |
| **Expatriate** | >20 | 10.41 |

#### 4.4.2 Dubai (DEWA)
| Category | Consumption (Gallons/Month) | Tariff (Fils/Gallon) |
| :--- | :--- | :--- |
| **Residential (Expat)** | 0 – 6,000 | 3.5 |
| **Residential (Expat)** | 6,001 – 12,000 | 4.0 |
| **Residential (Expat)** | >12,000 | 4.6 |

### 4.5 Irrigation and Treated Sewage Effluent (TSE)
*   **Agriculture**: 70% of UAE's freshwater is used for agriculture, primarily from non-renewable aquifers.
*   **Drip Irrigation**: Adoption of smart irrigation systems is mandatory for new farms to reduce water loss.
*   **TSE Reuse**: Mandatory in Dubai and Abu Dhabi for public parks, golf courses, and highway landscaping.

### 4.6 Water Quality Standards for Drinking Water (UAE.S 99:2001)
Based on WHO Guidelines for Drinking Water Quality.
| Parameter | Limit |
| :--- | :--- |
| **Turbidity** | < 5 NTU |
| **pH** | 6.5 – 8.5 |
| **Residual Chlorine** | 0.2 – 0.5 mg/L |
| **E. coli** | 0 per 100 mL |
| **Total Coliforms** | 0 per 100 mL |
| **Nitrates (as NO3)** | 50 mg/L |
| **Fluoride** | 1.5 mg/L |
| **Heavy Metals (Lead, Cadmium)** | < 0.01 mg/L |

### 4.7 Wastewater Infrastructure
*   **Abu Dhabi**: ADDC network covers 95% of the emirate; Jebel Ali and Al Wathba are major treatment plants.
*   **Dubai**: DEWA/DM sewage network covers 98% of urban areas.
*   **Combined Sewer Overflow (CSO)**: UAE systems are primarily separate; however, heavy rain events can cause localized flooding.
*   **Abu Dhabi Surface Water Drainage Masterplan**: A multi-billion dirham project to improve storm water drainage and prevent flooding.

---

## 5. WASTE MANAGEMENT — COMPLETE

The UAE is transitioning from a "Take-Make-Dispose" model to a circular economy, with significant investments in recycling and waste-to-energy.

### 5.1 National Waste Statistics (2022)
*   **Total UAE Waste**: ~32 million tonnes/year.
*   **Abu Dhabi**: ~8 million tonnes (largest generator due to industrial activity).
*   **Dubai**: ~5.5 million tonnes.
*   **Sharjah**: ~2 million tonnes.

### 5.2 Municipal Solid Waste (MSW) Composition (% by weight)
*   **Food Waste**: 45% (major focus for reduction).
*   **Paper & Cardboard**: 17%.
*   **Plastics**: 12%.
*   **Metals**: 3%.
*   **Glass**: 2%.
*   **Textiles**: 3%.
*   **Other (Wood, Rubber, etc.)**: 18%.

### 5.3 Landfill Inventory
*   **Al Qusais (Dubai)**: One of the oldest landfills; now primarily closed and used for landfill gas recovery.
*   **Al Warsan (Dubai)**: Active landfill adjacent to the WtE plant.
*   **Al Dhafra (Abu Dhabi)**: Largest landfill in the emirate, managed by Tadweer.
*   **Bee'ah Sharjah Landfill Mining**: A pioneering project to excavate old landfills, recover materials, and restore the land.

### 5.4 Waste-to-Energy (WtE)
*   **Dubai (Warsan)**:
    *   **Operator**: Hitachi Zosen Inova.
    *   **Capacity**: 1,989 tonnes/day (5,500 tonnes/day at full phase).
    *   **Power**: 37.5 MW (enough for 135,000 homes).
    *   **Operational**: 2022.
*   **Sharjah (Bee'ah)**:
    *   **Capacity**: 300,000 tonnes/year.
    *   **Power**: 30 MW.
    *   **Diversion**: Helped Sharjah achieve a 76% landfill diversion rate.
*   **Abu Dhabi (Tadweer)**: Planned WtE plant in Al Dhafra with a capacity of 600,000 tonnes/year.

### 5.5 Extended Producer Responsibility (EPR)
*   **Packaging EPR Scheme**: Launched by MOCCAE in 2023.
*   **Covered Types**: Glass, paper, plastic, metal, and composite packaging.
*   **Brand Owner Registration**: Mandatory for all companies placing >10 tonnes of packaging on the market.
*   **Collection Targets**: 30% by 2025; 50% by 2030.

### 5.6 Hazardous Waste Facilities
*   **Clean Arabia (UAE)**: Specialized in industrial and chemical waste treatment.
*   **EHS Sharjah**: Manages hazardous waste for the emirate.
*   **Enviroserve (Jebel Ali)**: World's largest e-waste recycling facility; handles 39,000 tonnes/year.
*   **Waste Oil Recycling**: Several facilities in Jebel Ali and Mussafah recover base oil from used lubricants.
*   **PCB Disposal**: UAE is a party to the Basel Convention; PCB-containing transformers are exported for safe destruction in Europe.

### 5.7 Recycling Rates
*   **UAE Current**: ~24% overall.
*   **Dubai Target**: 75% by 2030.
*   **Abu Dhabi Target**: 80% diversion from landfill by 2030.
*   **Bee'ah Sharjah**: Achieved 76% diversion rate, the highest in the region.


---

## 6. OCCUPATIONAL HEALTH & SAFETY (OSHAD-SF) — MAXIMUM DETAIL

The **Abu Dhabi Occupational Safety and Health System Framework (OSHAD-SF)** is the primary regulatory framework for OHS in the Emirate of Abu Dhabi and serves as a benchmark for the entire UAE. It is a risk-based management system designed to ensure the health and safety of all workers.

### 6.1 The 17 Elements of OSHAD-SF (Detailed Breakdown)

1.  **OHS Policy**:
    *   **Content**: Must include a commitment to prevent injury and ill health, comply with legal requirements, and continually improve the OSHMS.
    *   **Authority**: Must be signed by the most senior executive (CEO/Managing Director).
    *   **Communication**: Must be displayed in multiple languages and communicated to all employees and contractors.
    *   **Review**: Must be reviewed annually or when significant changes occur in the organization.
    *   **Example**: A construction company's policy might state: "We are committed to achieving zero harm through rigorous risk management and a culture of safety ownership at all levels."

2.  **Risk Assessment**:
    *   **Methodology**: Entities must use recognized hazard identification methods such as **HAZOP** (Hazard and Operability Study), **FMEA** (Failure Mode and Effects Analysis), **What-if** analysis, and **Job Safety Analysis (JSA)**.
    *   **Risk Matrix**: A standard 5×5 matrix (Likelihood × Consequence) is used to determine risk levels (Low, Medium, High, Extreme).
    *   **Control Hierarchy**: Mandatory application of the hierarchy:
        1.  **Elimination**: Removing the hazard entirely (e.g., using a drone for inspection instead of a person climbing).
        2.  **Substitution**: Replacing a hazardous substance with a less hazardous one (e.g., water-based paint instead of solvent-based).
        3.  **Engineering Controls**: Installing guards, ventilation, or soundproofing (e.g., acoustic enclosures for generators).
        4.  **Administrative Controls**: Training, signage, and rotating shifts (e.g., heat stress breaks).
        5.  **PPE**: The last resort (e.g., helmets, gloves).

3.  **Legal Requirements**:
    *   **Legal Register**: Entities must maintain a comprehensive list of all applicable federal and local OHS laws.
    *   **Updates**: The register must be reviewed and updated monthly to capture new ministerial resolutions or OSHAD circulars.
    *   **Compliance Audit**: An annual audit must be conducted to verify compliance with every item in the legal register.
    *   **Key Laws**: Federal Decree-Law No. 33 of 2021 (Labor Law), Ministerial Resolution No. 32 of 1982 (Construction Safety).

4.  **Objectives & Targets**:
    *   **SMART Format**: Objectives must be Specific, Measurable, Achievable, Relevant, and Time-bound.
    *   **Lagging Indicators**: Tracking **LTIFR** (Lost Time Injury Frequency Rate), **TRIR** (Total Recordable Incident Rate), and **SR** (Severity Rate).
    *   **Leading Indicators**: Tracking safety observations, near-miss reporting rates, training hours per employee, and audit completion rates.
    *   **Example**: "Reduce LTIFR by 20% by December 2026 through the implementation of a new behavioral safety program."

5.  **Roles & Responsibilities**:
    *   **OHS Manager**: Must hold a minimum of a **NEBOSH IGC** and have relevant industry experience. For high-risk entities, **CMIOSH** (Chartered Member of IOSH) is preferred.
    *   **OHS Committee**: Mandatory for entities with >50 workers. Must meet at least quarterly and include management and worker representatives.
    *   **Worker Safety Reps**: Workers should elect representatives to participate in safety inspections and committee meetings.
    *   **Accountability**: OHS responsibilities must be included in the job descriptions of all employees, from the CEO to the site worker.

6.  **Training**:
    *   **Induction**: All new employees and contractors must receive a minimum of 8 hours of OHS induction before starting work.
    *   **Toolbox Talks**: Short, site-specific safety briefings must be held at least weekly (daily for high-risk tasks).
    *   **Emergency Drills**: Fire, medical, and spill response drills must be conducted every 6 months.
    *   **First Aid**: A ratio of 1 trained first aider per 50 workers must be maintained.
    *   **Competency**: Training must be delivered by OSHAD-registered training providers for specific high-risk roles (e.g., crane operators).

7.  **Communication**:
    *   **Bulletin Boards**: OHS information must be posted in prominent locations.
    *   **Languages**: All safety signage and instructions must be in **Arabic, English, and Hindi/Urdu** (at a minimum) to ensure all workers understand.
    *   **Safety Committees**: A formal platform for workers to raise safety concerns without fear of reprisal.
    *   **Anonymous Reporting**: A "Whistleblower" or anonymous hazard reporting system must be available.
    *   **Visual Aids**: Use of pictograms and diagrams to overcome language barriers.

8.  **Documentation**:
    *   **OHSMS Manual**: A central document describing the system and its procedures.
    *   **Record Retention**:
        *   General OHS records: 5 years.
        *   Incident investigation reports: 10 years.
        *   Health surveillance records: 30 years (due to long latency of occupational diseases).
    *   **Version Control**: All documents must have a unique ID, version number, and approval date.

9.  **Operational Controls**:
    *   **Permit to Work (PTW)**: A formal system to control high-risk activities.
    *   **Safe Work Method Statements (SWMS)**: Detailed step-by-step procedures for specific tasks.
    *   **Lifting Plans**: Mandatory for all crane and heavy lifting operations.
    *   **Scaffold Inspection**: Must be inspected every 7 days by a competent person and tagged (Green/Red).
    *   **LOTO**: Lockout/Tagout procedures for electrical and mechanical isolation.

10. **Emergency Preparedness**:
    *   **Emergency Response Plan (ERP)**: Must cover fire, medical emergencies, chemical spills, and natural disasters.
    *   **Assembly Points**: Clearly marked and unobstructed locations for evacuation.
    *   **Communication Tree**: A defined list of contacts for internal and external emergency services.
    *   **Business Continuity**: Linkage between OHS emergency response and the organization's business continuity plan.
    *   **Equipment**: Maintenance and testing of fire extinguishers, eye wash stations, and spill kits.

11. **Incident Reporting**:
    *   **Classification**: Incidents must be classified as Near Miss, First Aid, Restricted Work, Lost Time (LTI), Fatality, or Environmental Damage.
    *   **Investigation**: Root Cause Analysis (RCA) using methods like **5-Whys**, **Fishbone (Ishikawa)**, or **Bowtie** analysis.
    *   **Timeline**: Fatalities must be reported to OSHAD/MOHRE within **24 hours**; LTIs within **72 hours**.
    *   **Lessons Learned**: Investigation findings must be shared with the workforce to prevent recurrence.

12. **Monitoring**:
    *   **Inspections**: Weekly site safety walkthroughs by supervisors; monthly comprehensive audits by the OHS team.
    *   **Internal Audit**: A full system audit conducted annually by trained internal auditors.
    *   **External Audit**: High-risk entities must undergo a biennial audit by an OSHAD-registered third-party auditing firm.
    *   **Equipment Calibration**: Monitoring equipment (e.g., gas detectors, noise meters) must be calibrated annually.

13. **Contractor Management**:
    *   **Pre-qualification**: Contractors must be evaluated on their OHS performance, insurance, and management system before being hired.
    *   **OHS Plan**: Contractors must submit a project-specific OHS plan for approval.
    *   **Performance Monitoring**: Regular audits of contractor activities and a "Blacklisting" criteria for poor performers.
    *   **Interface Risk**: Managing risks where multiple contractors work in the same area.

14. **Permit to Work (PTW)**:
    *   **Mandatory Types**: Hot Work, Confined Space, Working at Height (>2m), Electrical Isolation (LOTO), Excavation, and Heavy Lifting.
    *   **LOTO (Lockout/Tagout)**: Mandatory procedures to ensure machinery is de-energized during maintenance.
    *   **Duration**: Permits are typically valid for a maximum of 8 hours or one shift.
    *   **Isolation**: Verification of zero energy state before work begins.

15. **PPE (Personal Protective Equipment)**:
    *   **Selection**: Based on the risk assessment and relevant standards (CE, ANSI).
    *   **Provision**: Employer must provide all necessary PPE at **no cost** to the worker.
    *   **Maintenance**: Workers must be trained on how to inspect and store their PPE; a replacement schedule must be in place.
    *   **Enforcement**: Strict "No PPE, No Work" policy on all sites.

16. **Occupational Health**:
    *   **Medical Exams**: Pre-employment and periodic medicals for workers in hazardous roles.
    *   **Surveillance**: Annual audiometry for noise-exposed workers; annual spirometry for dust-exposed workers.
    *   **Fitness-to-Work**: Standards for specific roles (e.g., crane operators, divers).
    *   **Return-to-Work**: Programs to help injured workers transition back to the workplace.
    *   **Welfare**: Provision of clean drinking water, shaded rest areas, and hygienic toilets.

17. **Management Review**:
    *   **Frequency**: At least annually.
    *   **Inputs**: Audit results, incident trends, legal changes, and resource needs.
    *   **Outputs**: Decisions on system improvements, resource allocation, and changes to policy or objectives.
    *   **Action Tracking**: All review actions must be assigned to a responsible person and tracked to completion.


---

## 7. ALL CODES OF PRACTICE (CoP 30–39) — FULL SUMMARIES

The OSHAD-SF includes a series of technical Codes of Practice (CoP) that provide specific requirements for various hazards and sectors.

*   **CoP 30.0 General OHS Guidance for Contractors**:
    *   **Scope**: Applies to all contractors working on projects in Abu Dhabi.
    *   **Requirements**: Mandatory OHS plan submission, site-specific risk assessments, and integration with the principal contractor's OHSMS.
*   **CoP 31.0 Office Safety**:
    *   **Ergonomics**: Requirements for adjustable chairs, monitor height, and keyboard placement (DSE assessment).
    *   **Fire Safety**: Clear escape routes, fire extinguishers, and regular evacuation drills.
    *   **Electrical**: Prohibition of "daisy-chaining" extension leads and mandatory PAT testing.
*   **CoP 32.0 Retail Safety**:
    *   **Manual Handling**: Training for staff on safe lifting techniques for stock.
    *   **Customer Safety**: Preventing slips, trips, and falls in public areas; display stability.
    *   **Loading Docks**: Safety procedures for vehicle movements and unloading.
*   **CoP 33.0 Hospitality**:
    *   **Kitchen Safety**: Guards for slicers, non-slip flooring, and fire suppression for deep fryers.
    *   **Thermal Stress**: Managing heat in kitchens through ventilation and hydration.
    *   **Chemicals**: Safe storage and use of cleaning agents (SDS required).
*   **CoP 34.0 Construction Safety**:
    *   **Scaffolding**: Must comply with **BS EN 12811**; mandatory tagging and weekly inspections.
    *   **Excavations**: Shoring or battering required for depths >1.5m; barriers at the edge.
    *   **Working at Height**: Full-body harness mandatory for work >2m where collective protection is not possible.
*   **CoP 35.0 Chemical Safety**:
    *   **COSHH Assessment**: Control of Substances Hazardous to Health; mandatory for all chemicals.
    *   **Storage**: Segregation matrix to prevent incompatible chemicals from being stored together.
    *   **Emergency**: Eye wash stations and spill kits must be available near storage areas.
*   **CoP 36.0 Healthcare Safety**:
    *   **Sharps**: Use of safety needles and puncture-resistant sharps containers.
    *   **Biological Hazards**: Procedures for handling blood-borne pathogens and infectious waste.
    *   **Radiation**: Lead shielding and dosimeters for staff in X-ray and oncology departments.
*   **CoP 37.0 Transportation Safety**:
    *   **Driver Hours**: Maximum driving time and mandatory rest periods to prevent fatigue.
    *   **Vehicle Inspection**: Daily pre-use checks and scheduled maintenance.
    *   **Dangerous Goods**: Compliance with **ADR** (European Agreement concerning the International Carriage of Dangerous Goods by Road).
*   **CoP 38.0 Manufacturing Safety**:
    *   **Machinery Guarding**: Must comply with **EN ISO 12100**; interlocked guards for high-risk machines.
    *   **LOTO**: Strict lockout/tagout procedures for all maintenance work.
    *   **Noise & Vibration**: Monitoring and control measures for heavy machinery.
*   **CoP 39.0 Oil and Gas Safety**:
    *   **Process Safety**: Implementation of PSM (Process Safety Management) frameworks.
    *   **Hazard Studies**: Mandatory **HAZOP**, **LOPA** (Layer of Protection Analysis), and **SIL** (Safety Integrity Level) assessments.
    *   **Hazardous Areas**: Use of **ATEX** or **IECEx** certified equipment in explosive atmospheres.


---

## 8. FIRE SAFETY — COMPLETE TECHNICAL SPECS

The UAE has one of the most advanced fire safety codes in the world, the **UAE Fire and Life Safety Code of Practice (2018)**, which was significantly updated following several high-profile skyscraper fires.

### 8.1 Sprinkler Hydraulic Design Worked Example
For an **Ordinary Hazard Group 1 (OH1)** occupancy (e.g., offices, hotels):
*   **Design Area**: 260 m² (the most hydraulically remote area).
*   **Design Density**: 5.0 mm/min (0.12 gpm/ft²).
*   **Sprinkler K-Factor**: 80 (metric).
*   **Minimum Pressure at Sprinkler**: 0.5 bar (7.25 psi).
*   **Calculation**:
    1.  **Total Flow (Q)**: Density × Area = 5.0 mm/min × 260 m² = 1,300 L/min.
    2.  **Pipe Sizing**: Using the Hazen-Williams formula to calculate friction loss.
    3.  **Pump Selection**: The fire pump must be capable of delivering 1,300 L/min plus a 10% safety margin at the calculated system pressure (including static head and friction loss).
    4.  **Tank Sizing**: For OH1, a 60-minute water supply is required. Total Tank Volume = 1,300 L/min × 60 min = 78,000 Liters (78 m³).

### 8.2 Fire Detection Zoning and Logic
*   **Addressable Systems**: Mandatory for all buildings >4 floors or >10,000 m².
*   **Zoning**:
    *   A single zone should not exceed 2,000 m² of floor area.
    *   Maximum 20 detectors per zone loop to ensure rapid identification of the fire location.
    *   A zone plan must be permanently displayed at the Fire Alarm Control Panel (FACP).
*   **Interface Logic**:
    *   **Signal 1 (Smoke/Heat)**: Activates local sounders and sends signal to the 24/7 monitoring center (Hassantuk).
    *   **Signal 2 (Second Detector or Manual Call Point)**: Activates full building evacuation, shuts down HVAC, recalls elevators to the ground floor, and releases magnetic door holders.

### 8.3 Major Fire Incidents and Regulatory Responses
The UAE's fire regulations have been shaped by real-world incidents:
*   **Tamweel Tower (JLT, 2012)**: A cladding fire that spread rapidly up the exterior. Led to the first major review of external wall systems.
*   **The Address Downtown Dubai (NYE 2016)**: A spectacular fire on New Year's Eve caused by an electrical short circuit igniting combustible cladding. This incident led to the **2016 Circular** banning combustible cladding for all new buildings.
*   **The Marina Torch (2015 and 2017)**: Two major fires in the same building highlighted the danger of "fire spread via the facade" and the importance of fire breaks.

### 8.4 Combustible Cladding Regulations (Post-2016)
*   **The Ban**: Dubai and Abu Dhabi Civil Defence strictly prohibit the use of Aluminium Composite Panels (ACP) with a Polyethylene (PE) core.
*   **Testing Standard**: All external wall systems must pass the **BS 8414** (Parts 1 & 2) full-scale fire test.
*   **Classification**: Materials must achieve **Class A2-s1, d0** according to **EN 13501-1**:
    *   **A2**: Limited combustibility (virtually non-combustible).
    *   **s1**: Very low smoke production.
    *   **d0**: No flaming droplets or particles.
*   **Retrofitting**: Existing buildings with combustible cladding are required to undergo risk assessments and, in many cases, replace the cladding or install additional fire suppression (e.g., external drenchers).

---

## 9. CLIMATE CHANGE & BIODIVERSITY — COMPLETE

The UAE is a global leader in climate action, being the first country in the Middle East to commit to Net Zero by 2050.

### 9.1 UAE GHG Inventory by Sector (2020 Data)
| Sector | Mt CO2e | % of Total | Key Sources |
| :--- | :--- | :--- | :--- |
| **Energy (Power & Water)** | 127 | 42% | Natural gas power plants, desalination. |
| **Transport** | 84 | 28% | Road transport (cars, trucks), aviation. |
| **Industrial Processes** | 54 | 18% | Cement, aluminum, steel, chemicals. |
| **Waste** | 21 | 7% | Methane from landfills, wastewater. |
| **Agriculture / LULUCF** | 14 | 5% | Livestock, fertilizers, land use change. |
| **TOTAL** | **300** | **100%** | |

### 9.2 UAE NDC 2023 Measures
The UAE's Third Update to its Second Nationally Determined Contribution (NDC) targets a **40% reduction** in emissions by 2030 compared to business-as-usual.
*   **Renewable Energy**: Target of 14.2 GW of solar and wind capacity by 2030 (e.g., Mohammed bin Rashid Al Maktoum Solar Park).
*   **Nuclear Energy**: Full operation of the **Barakah Nuclear Plant** (5.6 GW), providing 25% of the UAE's electricity with zero emissions.
*   **Energy Intensity**: 40% improvement in energy efficiency by 2030 vs. 2005 levels.
*   **Clean Transport**:
    *   **Dubai**: 50% EV penetration target by 2050.
    *   **Federal**: AED 7.5 billion investment in EV charging infrastructure.
*   **Methane Reduction**: 30% reduction in methane emissions from the oil and gas sector by 2030 (led by ADNOC).

### 9.3 COP28 Detailed Outcomes (The UAE Consensus)
Hosted in Dubai in 2023, COP28 resulted in several landmark agreements:
*   **Transitioning Away from Fossil Fuels**: The first time a COP decision explicitly called for a transition away from all fossil fuels in energy systems.
*   **Triple Renewables / Double Efficiency**: Global target to triple renewable energy capacity and double the rate of energy efficiency improvements by 2030.
*   **Loss and Damage Fund**: Operationalized with initial pledges of USD 792 million, including USD 100 million from the UAE.
*   **Alterra Climate Fund**: UAE launched a USD 30 billion catalytic climate fund to mobilize USD 250 billion globally by 2030.

### 9.4 UAE Biodiversity and Conservation
*   **Mangroves**:
    *   UAE has over 60 million mangrove trees covering 183 km².
    *   **Target**: Plant 100 million mangroves by 2030 (met early in 2022; new target being set).
    *   Mangroves sequester 4x more carbon than tropical rainforests.
*   **Marine Life**:
    *   **Dugongs**: UAE waters host ~3,000 dugongs, the largest population outside Australia.
    *   **Sea Turtles**: Hawksbill and Green turtles nest on UAE beaches (e.g., Saadiyat Island, Sir Bani Yas).
    *   **Whale Sharks**: Seasonal aggregations off the coast of Fujairah and Abu Dhabi.
*   **Terrestrial Wildlife**:
    *   **Arabian Oryx**: Once extinct in the wild, the UAE's breeding program has led to a population of >1,000 in the wild.
    *   **Houbara Bustard**: Large-scale captive breeding and release program to restore wild populations.
*   **Protected Areas**: 49 protected areas (terrestrial and marine) covering ~15% of the UAE's total area.

---

## 10. CHEMICALS & HAZARDOUS MATERIALS — COMPLETE

The management of chemicals and hazardous materials in the UAE is strictly regulated to prevent environmental contamination and protect public health.

### 10.1 GHS Classification and SDS Requirements
*   **GHS Adoption**: The UAE has adopted the **Globally Harmonized System (GHS)** for the classification and labeling of chemicals.
*   **Safety Data Sheets (SDS)**:
    *   Mandatory for all hazardous chemicals imported, manufactured, or used in the UAE.
    *   Must be provided in both **Arabic and English**.
    *   Must follow the 16-section GHS format, including hazard identification, first-aid measures, and ecological information.
*   **Labeling**: All containers must have GHS-compliant labels with signal words (Danger/Warning), pictograms, and hazard statements.

### 10.2 Chemical Storage and Segregation
*   **Segregation Matrix**: Incompatible chemicals must be stored separately to prevent dangerous reactions.
    *   **Oxidizers** must be separated from **Flammables** by at least 3 meters or a fire-rated wall.
    *   **Acids** must be separated from **Bases**.
    *   **Cyanides** must be kept away from acids to prevent the release of toxic hydrogen cyanide gas.
*   **Secondary Containment**:
    *   All liquid chemical storage areas must have bunding (secondary containment) capable of holding **110%** of the largest tank's volume or **25%** of the total volume stored, whichever is greater.
    *   Bunds must be chemically resistant and have no drainage valves.
*   **Ventilation**: Storage areas for volatile or toxic chemicals must have mechanical ventilation providing at least 6 air changes per hour.

### 10.3 Chemical Registration (MOCCAE)
*   **Notification**: Importers and manufacturers must notify MOCCAE of all chemicals brought into the country.
*   **Priority Substances**: MOCCAE maintains a list of "Priority Substances" (PBT - Persistent, Bioaccumulative, and Toxic) that require special permits and tracking.
*   **Banned Chemicals**: The UAE strictly prohibits the import of chemicals listed under the **Stockholm Convention** (POPs) and the **Rotterdam Convention**.

---

## 11. OIL SPILL RESPONSE — COMPLETE

As a major oil producer and maritime hub, the UAE has a comprehensive framework for oil spill preparedness and response.

### 11.1 National Oil Spill Contingency Plan (NOSCP)
*   **Authority**: MOCCAE leads the national response, supported by the UAE Coast Guard and the Ministry of Interior.
*   **Tiers of Response**:
    *   **Tier 1 (Local)**: Small spills (<7 tonnes) handled by the facility or port operator using on-site equipment.
    *   **Tier 2 (Regional)**: Medium spills (7–700 tonnes) requiring coordination between multiple entities and regional response centers.
    *   **Tier 3 (National/International)**: Large spills (>700 tonnes) requiring national mobilization and international assistance (e.g., from ITOPF or neighboring GCC countries).

### 11.2 Response Equipment and Techniques
*   **Containment**: Use of offshore and coastal booms to prevent oil from reaching sensitive areas (mangroves, desalination intakes).
*   **Recovery**: Skimmers (oleophilic, weir, and suction) used to remove oil from the water surface.
*   **Dispersants**: Use of chemical dispersants is strictly controlled and requires prior approval from the competent authority. Prohibited in shallow waters or near coral reefs.
*   **Shoreline Cleanup**: Manual and mechanical recovery; use of sorbents; and "In-situ" burning in specific offshore conditions.

### 11.3 Sensitive Area Protection
*   **Desalination Intakes**: The highest priority for protection. All major desalination plants have dedicated booms and 24/7 monitoring.
*   **Mangroves and Coral Reefs**: Identified as "High Sensitivity" areas in the National Sensitivity Map. Response strategies focus on containment rather than cleanup to avoid further damage to these ecosystems.

---

## 12. GREEN BUILDING & SUSTAINABLE URBANISM

The UAE has pioneered green building standards in the region to reduce the environmental footprint of its rapid urbanization.

### 12.1 Estidama (Abu Dhabi)
*   **Pearl Rating System**: Mandatory for all new buildings in Abu Dhabi.
    *   **1 Pearl**: Minimum requirement for all private buildings.
    *   **2 Pearls**: Minimum requirement for all government-funded buildings.
*   **Key Pillars**: Environmental, Economic, Social, and Cultural sustainability.
*   **Water Credit**: Significant points awarded for reducing indoor water use by 30% and using TSE for irrigation.

### 12.2 Al Sa'fat (Dubai)
*   **Dubai Green Building Regulations**: Replaced the previous mandatory code in 2020.
*   **Categories**: Bronze, Silver, Gold, and Platinum.
*   **Requirements**: Focuses on energy efficiency (insulation, LED lighting), indoor air quality, and use of sustainable materials.

### 12.3 LEED and WELL Adoption
*   **LEED**: The UAE has one of the highest concentrations of LEED-certified buildings outside the US (e.g., Siemens HQ in Masdar City).
*   **WELL**: Increasing focus on occupant health and well-being, with several major commercial towers in DIFC achieving WELL certification.

---

## 13. NUCLEAR REGULATION & SAFETY

With the Barakah Nuclear Energy Plant, the UAE has established a world-class nuclear regulatory framework.

### 13.1 Federal Authority for Nuclear Regulation (FANR)
*   **Role**: Independent regulator responsible for the safety, security, and safeguards of the UAE's nuclear program.
*   **Licensing**: FANR issues licenses for the construction, operation, and decommissioning of nuclear facilities.

### 13.2 Radiation Protection Standards
*   **Dose Limits**: Aligned with International Commission on Radiological Protection (ICRP) recommendations.
    *   **Occupational**: 20 mSv/year (averaged over 5 years).
    *   **Public**: 1 mSv/year.
*   **Monitoring**: National network of radiation monitoring stations providing real-time data to FANR.

---

## 14. ENVIRONMENTAL MONITORING TECHNOLOGY

The UAE is leveraging Fourth Industrial Revolution (4IR) technologies to enhance environmental management.

### 14.1 AI and Big Data
*   **Air Quality Prediction**: Using AI models to predict sandstorms and pollution spikes 48 hours in advance.
*   **Waste Optimization**: AI-driven route planning for waste collection vehicles to reduce fuel consumption.

### 14.2 Drones and Satellite Imagery
*   **Mangrove Monitoring**: Using drones for high-resolution mapping of mangrove health and carbon sequestration.
*   **Illegal Dumping Detection**: Satellite imagery used to identify unauthorized waste disposal in remote desert areas.
*   **Oil Spill Detection**: Synthetic Aperture Radar (SAR) satellites provide 24/7 monitoring of the UAE's maritime borders for oil slicks.

---

## 15. INTERNATIONAL CONVENTIONS & OBLIGATIONS

The UAE is a signatory to several international environmental and safety conventions, which are integrated into its federal laws.

### 15.1 Climate and Atmosphere
*   **UNFCCC & Paris Agreement**: UAE was the first in the region to sign and ratify. Committed to Net Zero 2050.
*   **Montreal Protocol**: Regulation of Ozone Depleting Substances (ODS). UAE has successfully phased out CFCs and is phasing out HCFCs.

### 15.2 Waste and Chemicals
*   **Basel Convention**: Control of transboundary movements of hazardous wastes. UAE strictly regulates the export of hazardous waste for treatment.
*   **Stockholm Convention**: Protection against Persistent Organic Pollutants (POPs).
*   **Minamata Convention**: Regulation of mercury emissions and use.

### 15.3 Biodiversity and Marine
*   **CITES**: Convention on International Trade in Endangered Species. UAE is a major hub for CITES enforcement (e.g., ivory, falcons).
*   **Ramsar Convention**: Protection of wetlands of international importance (e.g., Ras Al Khor in Dubai, Al Wathba in Abu Dhabi).
*   **MARPOL**: International Convention for the Prevention of Pollution from Ships. Integrated into Federal Law 24/1999.

---

## 16. CASE STUDIES: REGULATORY IMPLEMENTATION

### 16.1 Case Study: EIA for the Barakah Nuclear Energy Plant
*   **Project**: 5.6 GW nuclear plant in Al Dhafra, Abu Dhabi.
*   **EIA Scope**: One of the most comprehensive EIAs in UAE history.
    *   **Marine**: 2 years of baseline data on water temperature, salinity, and seagrass beds.
    *   **Thermal Modeling**: Extensive modeling to ensure cooling water discharge does not exceed +2°C above ambient at the edge of the mixing zone.
    *   **Radiological Baseline**: Establishing pre-operational radiation levels in soil, water, and air.
*   **Outcome**: Approval with 100+ environmental conditions, including a long-term marine monitoring program and a turtle conservation plan.

### 16.2 Case Study: Waste-to-Energy in Sharjah (Bee'ah)
*   **Project**: 30 MW WtE plant diverting 300,000 tonnes/year from landfill.
*   **Regulatory Challenge**: Meeting the strict emission limits of the EU Industrial Emissions Directive (IED), which are adopted by the UAE for WtE.
*   **Technology**: Advanced flue gas treatment (selective catalytic reduction, bag filters, and carbon injection) to ensure dioxins and furans are near zero.
*   **Outcome**: Sharjah achieved the highest landfill diversion rate in the Middle East (76%).

---

## 17. GLOSSARY OF TERMS

*   **ADPHC**: Abu Dhabi Public Health Centre.
*   **AQI**: Air Quality Index.
*   **BAT**: Best Available Techniques.
*   **CEMS**: Continuous Emission Monitoring System.
*   **COSHH**: Control of Substances Hazardous to Health.
*   **EAD**: Environment Agency Abu Dhabi.
*   **EIA**: Environmental Impact Assessment.
*   **EMP**: Environmental Management Plan.
*   **EPR**: Extended Producer Responsibility.
*   **FANR**: Federal Authority for Nuclear Regulation.
*   **GHS**: Globally Harmonized System of Classification and Labelling of Chemicals.
*   **LOTO**: Lockout/Tagout.
*   **LTIFR**: Lost Time Injury Frequency Rate.
*   **MOCCAE**: Ministry of Climate Change and Environment.
*   **MSW**: Municipal Solid Waste.
*   **NDC**: Nationally Determined Contribution.
*   **OSHAD-SF**: Abu Dhabi Occupational Safety and Health System Framework.
*   **PPE**: Personal Protective Equipment.
*   **RO**: Reverse Osmosis.
*   **SDS**: Safety Data Sheet.
*   **SEA**: Strategic Environmental Assessment.
*   **TSE**: Treated Sewage Effluent.
*   **WtE**: Waste-to-Energy.

---

## 18. DETAILED OSHAD-SF ELEMENT GUIDE: COMPLIANCE CHECKLISTS

To ensure full compliance with OSHAD-SF, entities should use the following checklists for each of the 17 elements.

### Element 1: OHS Policy
*   [ ] Is the policy specific to the organization's activities and risks?
*   [ ] Does it include a commitment to prevent injury and ill health?
*   [ ] Does it include a commitment to comply with UAE federal and local laws?
*   [ ] Is it signed and dated by the CEO/Managing Director?
*   [ ] Is it reviewed at least annually?
*   [ ] Is it available in Arabic, English, and other relevant languages?

### Element 2: Risk Management
*   [ ] Is there a documented procedure for hazard identification and risk assessment?
*   [ ] Are all routine and non-routine activities covered?
*   [ ] Is the 5x5 risk matrix used consistently?
*   [ ] Is the hierarchy of controls applied to all high-risk activities?
*   [ ] Are risk assessments reviewed after any incident or change in process?
*   [ ] Are workers involved in the risk assessment process?

### Element 3: Management of Contractors
*   [ ] Is there a pre-qualification process for contractors based on OHS performance?
*   [ ] Do contractors submit a project-specific OHS plan?
*   [ ] Are interface risks between different contractors assessed?
*   [ ] Is there a system for monitoring contractor OHS performance on-site?
*   [ ] Are contractors included in site inductions and emergency drills?

### Element 4: Communication and Consultation
*   [ ] Is there a formal OHS committee that meets quarterly?
*   [ ] Are worker representatives elected to the committee?
*   [ ] Is OHS information displayed on bulletin boards in multiple languages?
*   [ ] Is there an anonymous system for reporting hazards?
*   [ ] Are meeting minutes recorded and actions tracked?

### Element 5: Training, Awareness and Competency
*   [ ] Is there a training matrix for all roles?
*   [ ] Do all employees receive a minimum 8-hour OHS induction?
*   [ ] Are weekly toolbox talks conducted and recorded?
*   [ ] Is competency verified for high-risk roles (e.g., forklift drivers)?
*   [ ] Are training records retained for at least 5 years?

### Element 6: Emergency Management
*   [ ] Is there a site-specific Emergency Response Plan (ERP)?
*   [ ] Are assembly points clearly marked and kept clear?
*   [ ] Are emergency drills (fire, medical, spill) conducted every 6 months?
*   [ ] Is there a sufficient number of trained fire wardens and first aiders?
*   [ ] Is emergency equipment (extinguishers, alarms) inspected monthly?

### Element 7: Monitoring, Investigation and Reporting
*   [ ] Are all incidents (including near misses) reported within the required timeline?
*   [ ] Is Root Cause Analysis (RCA) conducted for all LTIs and fatalities?
*   [ ] Are weekly site safety walkthroughs conducted by supervisors?
*   [ ] Is there a monthly OHS performance report for management?
*   [ ] Are investigation findings communicated to the workforce?

### Element 8: Audit and Inspection
*   [ ] Is an internal OHSMS audit conducted annually?
*   [ ] Are auditors independent of the area being audited?
*   [ ] Is a third-party external audit conducted biennially (for high-risk entities)?
*   [ ] Are audit non-conformances (NCs) tracked to closure?
*   [ ] Is the audit schedule based on the risk level of activities?

### Element 9: Compliance and Management Review
*   [ ] Does senior management review the OSHMS at least annually?
*   [ ] Are inputs to the review (audit results, incident trends) documented?
*   [ ] Are resources (budget, personnel) allocated based on the review?
*   [ ] Is the OHS policy updated if necessary after the review?
*   [ ] Are review minutes signed by the CEO?

---

## 19. FIRE SAFETY TECHNICAL APPENDIX: EQUIPMENT & SPECS

### 19.1 Fire Pump Room Requirements
*   **Location**: Must be in a 2-hour fire-rated enclosure with direct access from the outside.
*   **Configuration**: Typically consists of one electric duty pump, one diesel standby pump, and one jockey pump (to maintain pressure).
*   **Fuel Tank**: The diesel pump must have a fuel tank sized for at least 8 hours of continuous operation.
*   **Ventilation**: The room must have adequate ventilation to prevent overheating of the diesel engine.

### 19.2 Fire Water Tank Sizing
*   **Light Hazard (LH)**: 30-minute supply.
*   **Ordinary Hazard (OH)**: 60-minute supply.
*   **High Hazard (HH)**: 90-minute supply.
*   **Calculation**: Tank Volume = (Sprinkler Flow + Hose Stream Allowance) × Duration.
    *   Example for OH1: (1,300 L/min + 500 L/min) × 60 min = 108,000 Liters (108 m³).

### 19.3 Portable Fire Extinguishers (Selection & Placement)
*   **Water (Red)**: For Class A fires (wood, paper).
*   **CO2 (Black)**: For Class B (flammable liquids) and Electrical fires.
*   **Dry Powder (Blue)**: Multi-purpose (A, B, C, and Electrical).
*   **Wet Chemical (Yellow)**: For Class F (cooking oils).
*   **Placement**: Maximum travel distance to an extinguisher is 15 meters. Must be mounted 1.0m to 1.5m from the floor.

---

## 20. WASTE MANAGEMENT TECHNICAL SPECS: RECYCLING & DISPOSAL

### 20.1 Color-Coding for Waste Segregation
*   **Green**: Recyclables (Paper, Plastic, Metal, Glass).
*   **Black**: General Waste (Non-recyclable).
*   **Brown**: Organic/Food Waste (for composting).
*   **Yellow**: Medical/Clinical Waste (Biohazard).
*   **Red**: Hazardous Waste (Chemicals, Batteries).

### 20.2 Landfill Engineering Standards
*   **Liner System**: Must use a composite liner (e.g., 1.5mm HDPE geomembrane over 60cm of compacted clay).
*   **Leachate Collection**: Perforated pipes at the base to collect liquid and pump it to a treatment plant.
*   **Gas Recovery**: Vertical wells to extract methane for flaring or power generation.
*   **Monitoring**: Groundwater monitoring wells must be installed upstream and downstream of the landfill.

---

## 21. NATIONAL ENVIRONMENTAL MONITORING NETWORK: STATIONS & PARAMETERS

The UAE maintains a sophisticated network of monitoring stations to provide real-time data on air, water, and soil quality.

### 21.1 Air Quality Monitoring Stations (Selected)
| Station Name | Emirate | Location Type | Parameters Monitored |
| :--- | :--- | :--- | :--- |
| **Khalifa City** | Abu Dhabi | Residential | PM2.5, PM10, NO2, O3, SO2, CO |
| **Mussafah** | Abu Dhabi | Industrial | PM10, SO2, NO2, H2S, NMHC |
| **Al Safa** | Dubai | Residential/Urban | PM2.5, PM10, NO2, O3, CO |
| **Jebel Ali** | Dubai | Industrial/Port | PM10, SO2, NO2, VOCs |
| **Al Majaz** | Sharjah | Urban | PM10, NO2, O3, CO |
| **Fujairah Port** | Fujairah | Industrial/Marine | SO2, NO2, PM10, H2S |

### 21.2 Marine Water Quality Monitoring
*   **Parameters**: Temperature, Salinity, pH, Dissolved Oxygen (DO), Turbidity, Chlorophyll-a, and Nutrients (Nitrates, Phosphates).
*   **Frequency**: Real-time via automated buoys; monthly manual sampling for heavy metals and hydrocarbons.
*   **Key Locations**: Near desalination intakes, major ports, and marine protected areas (e.g., Marawah, Ras Al Khor).

---

## 22. SUSTAINABLE TRANSPORTATION & CLEAN MOBILITY

Transportation is the second-largest source of GHG emissions in the UAE. The government is implementing several strategies to decarbonize the sector.

### 22.1 Electric Vehicle (EV) Strategy
*   **Dubai Green Mobility Initiative**:
    *   Target: 10% of all vehicles to be electric or hybrid by 2030.
    *   Incentives: Free public charging (until 2025), free parking, and exemption from Salik (toll) registration fees.
*   **Federal EV Policy**:
    *   Investment of AED 7.5 billion to install 800+ charging stations across the UAE by 2030.
    *   Mandatory EV charging points in all new residential and commercial buildings.

### 22.2 Public Transport Expansion
*   **Dubai Metro**: The world's longest driverless metro system; powered by electricity.
*   **Etihad Rail**: A 1,200 km national railway network connecting all seven emirates.
    *   **Environmental Benefit**: One freight train can replace 300 trucks, reducing CO2 emissions by 70–80% per tonne-km.
*   **Hydrogen Mobility**: Pilot projects for hydrogen-powered buses and taxis in Abu Dhabi and Dubai.

---

## 23. BIODIVERSITY CONSERVATION PROJECTS: SPECIES FOCUS

### 23.1 The Arabian Oryx Reintroduction
*   **Status**: Once extinct in the wild (1972).
*   **Conservation**: Sheikh Zayed bin Sultan Al Nahyan initiated a breeding program in the 1960s.
*   **Success**: Reclassified from "Extinct in the Wild" to "Vulnerable" by the IUCN. Over 1,000 oryx now roam freely in the Arabian Oryx Protected Area (Abu Dhabi).

### 23.2 Sea Turtle Conservation (Hawksbill & Green)
*   **Nesting Sites**: Saadiyat Island, Sir Bani Yas, and the islands of Al Dhafra.
*   **Protection**: Mandatory "Turtle-Friendly Lighting" for coastal resorts during nesting season (March–August).
*   **Rehabilitation**: The Dubai Turtle Rehabilitation Project (DTRP) has rescued and released over 2,000 turtles since 2004.

### 23.3 Mangrove Restoration (Blue Carbon)
*   **Carbon Sequestration**: Mangroves in the UAE sequester an estimated 0.5 tonnes of CO2 per hectare per year.
*   **Expansion**: Over 100 million mangrove trees have been planted as of 2022.
*   **Protection**: Federal Law 24/1999 prohibits any activity that damages mangroves, with fines up to AED 50,000 per tree.

---
**Document Version**: 4.2 (July 2026)
**Status**: Exhaustive Regulatory Reference
**Path**: /data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/UAE_Library/UAE_Environmental_Sustainability_and_Safety_Regulations.md
