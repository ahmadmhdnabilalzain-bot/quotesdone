# UAE Legal System and Federal Laws

**Scope and method.** This file is an expanded legal-system library entry for the United Arab Emirates. It is designed as a dense research reference rather than a short summary. It consolidates constitutional structure, judicial institutions, major federal statutes, procedures, regulatory authorities, and arbitration frameworks using the official UAE Government portal, UAE Cabinet constitution page, UAE Legislation portal download links, court portals, and authoritative legal commentary where official text was unavailable or blocked by access controls. The document is informational and not legal advice.

**Currency note.** Sources and research material used by the drafting workflow were collected for a 2026 library build. Always verify operative law against the Official Gazette and the UAE Legislation Portal before relying on any provision in practice.

## Quick Source Index

| Source family | Use in this file | Main URL |
|---|---|---|
| UAE Legislation Portal | Constitution and federal-law download links | https://uaelegislation.gov.ae |
| Official UAE Government Portal | public explanations of Constitution, justice system, litigation and government services | https://u.ae |
| UAE Cabinet | Constitution overview and constitutional text extracts | https://uaecabinet.ae |
| Federal Supreme Court | Federal Supreme Court institutional information | https://www.sc.gov.ae |
| Dubai Courts | Dubai local courts, fees, divisions, services | https://www.dc.gov.ae |
| Abu Dhabi Judicial Department | Abu Dhabi court structure, specialized chambers, family/civil services | https://www.adjd.gov.ae |
| DIFC Courts | DIFC common-law courts, jurisdiction and SCT | https://www.difccourts.ae |
| ADGM Courts | ADGM common-law courts and court regulations | https://www.adgm.com/adgm-courts |
| Ministry of Justice | federal judiciary, notary and legal-profession administration | https://www.moj.gov.ae |
| Ministry of Economy | companies, consumer protection, IP, trademarks | https://www.moet.gov.ae |

## 1. Constitutional Framework

### 1.1 Establishment and status of the Constitution

The Constitution of the United Arab Emirates was adopted as a provisional constitution at the creation of the Union in 1971 and was made permanent in 1996. The official UAE Government Portal states that the Constitution was permanently adopted in July 1996 and contains 152 articles establishing the political and constitutional organisation of the UAE and the rights of citizens in ten areas [[1]](#ref1). The UAE Cabinet constitution page provides the constitutional text and article-by-article structure [[2]](#ref2). The UAE Legislation Portal hosts the official Constitution page, although automated access may be blocked by the portal’s security layer [[3]](#ref3).

The Constitution creates a **federal state** composed of seven emirates. It assigns defined sovereign powers to the Union, preserves local powers for the emirates, and sets out federal authorities: the Federal Supreme Council, President and Vice-President, Council of Ministers, Federal National Council, and federal judiciary.

### 1.2 Full constitutional part and chapter structure

| Constitutional unit | Articles | Subject matter | Practical legal significance |
|---|---:|---|---|
| Part One | 1–12 | The Union, its basic components and objectives | Establishes federal state, constituent emirates, sovereignty, flag, religion, language, nationality, aims and foreign-policy orientation. |
| Part Two | 13–24 | Fundamental social and economic bases | Sets social justice, family, education, health, work, property and natural-resources principles. |
| Part Three | 25–44 | Public freedoms, rights and duties | Equality, liberty, criminal legality, defence rights, movement, expression, communication, religion, assembly, occupation, public office, extradition, foreigners’ rights and taxation. |
| Part Four, Chapter 1 | 45–54 | Federal Supreme Council | Composition, supreme policymaking, legislative and treaty approval, election of President and Vice-President, Council voting. |
| Part Four, Chapter 2 | 55–67 | President and Vice-President | Presidential term, powers, decrees, treaty signature, appointment roles, emergency measures. |
| Part Four, Chapter 3 | 68–77 | Council of Ministers | Federal executive authority, ministerial responsibilities and federal administration. |
| Part Four, Chapter 4 | 81–93 | Federal National Council | Consultative parliamentary body, membership, sessions, legislation review and questions. |
| Part Four, Chapter 5 | 94–109 | Judiciary in the Union and the Emirates | Judicial independence, Federal Supreme Court, federal courts and local courts. |
| Part Five | 110–115 | Union legislation and decrees | Federal legislative process, promulgation, decree laws and regulations. |
| Part Six | 116–125 | The Emirates | Local emirate powers, local authorities, security, natural resources and residual powers. |
| Part Seven | 126–131 | Distribution of legislative, executive and international jurisdictions | Clarifies federal and emirate competence and implementation of international obligations. |
| Part Eight | 132–136 | Financial affairs of the Union | Federal budget, revenues, accounts and public finances. |
| Part Nine | 137–143 | Armed Forces and public security forces | Federal military and security organisation. |
| Part Ten | 144–152 | Final and transitional provisions | Amendment procedure, transitional rules and constitutional continuity. |

### 1.3 Key constitutional articles — direct English excerpts and legal notes

> **Citation note.** The excerpts below rely on the English constitutional text available through UAE Cabinet and cross-checked with the Constitute Project text used in the research record [[2]](#ref2) [[4]](#ref4). Translation wording can vary across official and secondary publications; Arabic is the official language under Article 7/9 wording as published by the constitutional text.

#### Article 1 — establishment of the Union from the emirates

```text
The United Arab Emirates is an independent, sovereign, federal state and is referred to in this Constitution as the Union. It shall consist of the following Emirates: Abu Dhabi, Dubai, Sharjah, Ajman, Umm Al Quwain, Ras Al Khaimah and Fujairah. Any other independent Arab country may join the Union, provided that the Supreme Council agrees unanimously to this.
```

**Legal effect.** Article 1 is the founding clause. It identifies the UAE as independent, sovereign and federal; names all seven emirates; and reserves accession of any other independent Arab country to unanimous approval by the Federal Supreme Council. In constitutional disputes, Article 1 is read with Articles 2, 3, 116, 120, 121 and 122 to determine whether a matter is federal or local.

#### Article 7 / Article 9 — religion, Sharia and language

```text
Islam shall be the official religion of the Union. The Islamic Shari’ah shall be a principal source of legislation in the Union. The official language of the Union shall be Arabic.
```

**Legal effect.** The Constitution makes Islam the official religion and Islamic Sharia a principal source of legislation. This clause is especially relevant in personal status, inheritance, criminal concepts such as qisas and diya, public order, and interpretive gaps in civil law. Arabic is the official language of legislation and court proceedings, even though English is used in DIFC and ADGM Courts and in many free-zone and international transactions.

#### Article 25 — equality before the law

```text
All persons shall be equal before the law. No discrimination shall be practised between citizens of the Union by reason of race, nationality, religious belief or social position.
```

**Legal effect.** Article 25 states the equality principle. The text distinguishes the general opening sentence, “all persons,” from the discrimination clause referring to “citizens of the Union.” In practice, the Constitution coexists with statutory categories distinguishing citizens, GCC nationals, residents, foreign investors, non-Muslims, free-zone entities and government employees.

#### Article 29 — freedom of movement and residence

```text
Freedom of movement and freedom of residence shall be guaranteed to citizens within the limits of the law.
```

**Legal effect.** This is a citizen freedom qualified by statute. Immigration, entry, residence, deportation, citizenship and passports are federal competences under Article 120.

#### Article 30 — opinion and expression

```text
Freedom to hold opinions and express them orally, in writing or by other means of expression shall be guaranteed within the limits of the law.
```

**Legal effect.** Expression is constitutionally recognised but expressly subject to legal limits. Those limits include federal criminal law, cybercrime law, media regulation, defamation, public-order and national-security offences.

#### Article 40 — rights of foreigners

```text
Foreigners in the Union shall enjoy the rights and freedoms prescribed in international charters in force or in treaties and agreements to which the Union is party, and they shall be subject to the corresponding duties.
```

**Legal effect.** Article 40 links foreigner rights to treaties, international charters in force and domestic duties. It is relevant to investment protection, labour rights, consular protection, extradition, judicial assistance and human-rights arguments.

#### Article 46 — Federal Supreme Council composition and powers

```text
The Supreme Council of the Union shall be the highest authority in the Union. It shall consist of the Rulers of all the Emirates forming the Union, or of their substitutes in their Emirates in the event of their absence or incapacity. Each Emirate shall have one vote in the deliberations of the Council.
```

**Core powers.** The Federal Supreme Council is the apex federal authority. Its functions include general policy, federal legislation approval, treaty and international agreement approval where required, approving appointment of the Prime Minister, accepting resignation or removal of the Prime Minister, approving appointment of the Federal Supreme Court President and judges, and electing the President and Vice-President of the Union.

#### Article 51 — election of President and Vice-President

```text
The Supreme Council shall elect from amongst its members a President and Vice-President of the Union. The Vice-President shall exercise all the powers of the President in the event of his absence for any reason.
```

**Voting rule required by the task.** For major Supreme Council resolutions, including election-related resolutions, the constitutional voting formula requires a majority of five members, provided that the votes of Abu Dhabi and Dubai are among that majority. This entrenches the consent of the two largest emirates for core federal decisions.

#### Article 120 — exclusive federal legislative and executive powers

Article 120 assigns the Union exclusive legislative and executive jurisdiction in listed matters. The requested full list is reproduced in functional form below:

| No. | Article 120 exclusive federal domain | Operational meaning |
|---:|---|---|
| 1 | Foreign affairs | Diplomatic relations, treaty negotiation, international representation and foreign-policy implementation. |
| 2 | Defence and federal armed forces | Defence policy, military command, federal security of the Union. |
| 3 | Protection of Union security against internal or external threats | Federal national security, state-security offences and protective measures. |
| 4 | Nationality, passports, residence and immigration | Citizenship, entry, residence, deportation, passports and immigration enforcement. |
| 5 | Currency, coinage and monetary system | Dirham, monetary policy and central-bank functions. |
| 6 | Weights and measures | Federal standardisation of weights and measures. |
| 7 | Federal public services and federal employees | Federal civil service and federal administrative services. |
| 8 | Federal finances, taxes, duties and fees | Union budget, federal taxes, customs where assigned, federal charges. |
| 9 | Postal, telegraph, telephone and similar communications | Communications infrastructure and federal communications regulation. |
| 10 | Air traffic control, aircraft registration and federal aviation matters | Aviation safety and federal air navigation. |
| 11 | Education | Federal education policy and national education objectives. |
| 12 | Public health and medical services | Federal health policy and public-health legislation. |
| 13 | Labour relations and social security | Federal labour, pensions/social security within constitutional allocations. |
| 14 | Real estate expropriation for public benefit | Federal eminent-domain powers for federal public purposes. |
| 15 | Extradition of criminals | Extradition treaties, surrender procedure and related criminal cooperation. |
| 16 | Census and statistics | National statistical systems and population/economic data collection. |
| 17 | Federal information and publications | Federal publications and information functions. |
| 18 | Other matters assigned by the Constitution or federal law | Residual federal areas expressly conferred by constitutional text. |

#### Article 121 — federal legislative jurisdiction / shared implementation domains

Article 121 extends federal lawmaking to civil, commercial, criminal and procedural law, labour relations, ownership and real-estate expropriation, intellectual property, weights and measures, banking, insurance, companies, major transport, aviation, extradition, and other areas. It is the constitutional foundation for federal codes such as the Civil Transactions Law, Civil Procedures Law, Penal Code, Criminal Procedures Law, Commercial Companies Law, Bankruptcy Law, Consumer Protection Law, Labour Law, IP laws and data-protection law.

Article 121 also allows the Union to establish free financial zones and determines that such zones may have special legal and regulatory systems in civil and commercial matters, which is the constitutional context for DIFC and ADGM legal orders.

#### Article 122 — residual emirate powers

```text
The Emirates shall have jurisdiction in all matters not assigned to the exclusive jurisdiction of the Union in accordance with the provisions of the preceding two Articles.
```

**Legal effect.** Article 122 is the residual-powers clause. Local emirate competence remains important in courts, police, municipalities, land registration, real estate, tourism, local licensing, free-zone creation, local departments, local taxes and fees, and local economic development.

### 1.4 Federal vs emirate jurisdiction table — 30 practical domains

| Domain | Primarily federal | Primarily emirate/local | Shared / special | Legal basis and practical note |
|---|:---:|:---:|:---:|---|
| Foreign affairs and diplomacy | ✓ | — | — | Article 120; Ministry of Foreign Affairs handles foreign relations. |
| Defence and armed forces | ✓ | — | — | Article 120 and Part Nine. |
| Nationality | ✓ | — | — | Federal nationality and passport laws. |
| Immigration, entry and residence | ✓ | — | Local implementation | Federal competence with emirate-level immigration offices. |
| Currency and monetary policy | ✓ | — | — | Central Bank and dirham regime. |
| Central banking | ✓ | — | — | CBUAE regulates banking and insurance. |
| Telecommunications | ✓ | — | — | TDRA federal role. |
| Postal services | ✓ | — | — | Article 120 communications. |
| Education policy | ✓ | Local operators | Shared | Federal standards; emirate education departments. |
| Public health | ✓ | Local health authorities | Shared | Federal public-health policy plus emirate health departments. |
| Labour relations | ✓ | Free-zone authorities | Shared | Federal Labour Law applies broadly; DIFC/ADGM/free zones have own employment regimes. |
| Social security / pensions | ✓ | Local pension schemes possible | Shared | Federal pensions plus local arrangements. |
| Civil law | ✓ | Courts apply locally | Shared | Federal Civil Transactions Law; local courts administer. |
| Commercial law | ✓ | Local licensing/free zones | Shared | Federal Commercial/Companies laws plus local licensing. |
| Criminal law | ✓ | Local police/prosecution | Shared | Federal Crimes and Penalties Law with local enforcement. |
| Criminal procedure | ✓ | Local prosecution/courts | Shared | Federal Criminal Procedure Law plus local court systems. |
| Civil procedure | ✓ | Local court rules/services | Shared | Federal Civil Procedures Law; local fee/service regulations. |
| Judiciary | Federal system | Dubai, Abu Dhabi, RAK local systems | Shared | Constitution permits local judicial systems. |
| Land ownership and registration | Federal aspects | ✓ | Shared | Land departments are local; federal civil and foreign-ownership rules may apply. |
| Municipal planning and building permits | — | ✓ | Shared standards | Local municipalities, civil defence and building codes. |
| Police | Federal security | ✓ | Shared | Local police in each emirate; federal security powers. |
| Public prosecution | Federal and local | ✓ | Shared | Federal prosecution plus local prosecution in Dubai/Abu Dhabi/RAK. |
| Natural resources | — | ✓ | Shared fiscal/federal interests | Constitution treats natural resources in each emirate as that emirate’s public property. |
| Oil and gas concessions | — | ✓ | Shared federal policy | Local concession practice; federal foreign-policy/environment/labour overlays. |
| Free zones | Federal recognition | ✓ | Shared/special | Emirate-created zones; DIFC/ADGM have special legal regimes. |
| Tourism | — | ✓ | Shared | Local tourism departments; federal immigration/consumer/commercial laws. |
| Local licensing | — | ✓ | Shared | Economic departments and free-zone authorities issue licences. |
| Taxation | Federal | Local fees | Shared | VAT/corporate tax federal; local municipality/tourism fees. |
| Consumer protection | ✓ | Local departments | Shared | Federal Law 15/2020 with local enforcement. |
| Environment | ✓ | Local agencies | Shared | Federal environmental laws plus emirate regulators. |
| Fire and civil defence | Federal standards | Local civil defence | Shared | Federal/local civil defence approval. |
| Data protection | ✓ | DIFC/ADGM sector laws | Shared/special | Federal PDPL; free-zone data laws. |
| Securities and capital markets | ✓ | DIFC/ADGM financial zones | Special | SCA onshore; DFSA/FSRA in financial free zones. |

## 2. Judicial System

### 2.1 Mixed federal, local and free-zone judicial architecture

The UAE judicial system is not a single monolithic court hierarchy. It is a layered system consisting of:

1. **Federal judiciary**: Federal Supreme Court, federal courts of appeal and federal courts of first instance.
2. **Local emirate judiciaries**: Dubai, Abu Dhabi and Ras Al Khaimah operate local judicial systems for ordinary civil, criminal, commercial, labour, administrative and personal-status matters within their jurisdiction.
3. **Financial free-zone common-law courts**: DIFC Courts in Dubai and ADGM Courts in Abu Dhabi operate English-language common-law systems for civil/commercial matters within their statutory jurisdiction and opt-in agreements.
4. **Sharia/personal-status adjudication**: Personal-status divisions and Sharia principles govern Muslim family law, inheritance and related matters, while non-Muslim personal-status regimes exist in Abu Dhabi, Dubai and DIFC/Dubai wills structures.
5. **Specialized tribunals and committees**: Rental dispute centres, labour fast-track mechanisms, commercial courts, family guidance committees, mediation bodies and enforcement divisions.

### 2.2 Federal Supreme Court

| Item | Detail |
|---|---|
| Institution | Federal Supreme Court |
| Seat | Abu Dhabi |
| Composition | Five judges, including president and members, appointed at federal level. |
| Constitutional basis | Articles 94–109 establish judicial independence and federal judicial authority. |
| Official URL | https://www.sc.gov.ae |
| Core jurisdiction | Constitutional review; disputes between emirates; disputes between emirates and the Union; crimes directly affecting Union interests; interpretation of constitutional provisions; validity of federal laws and emirate legislation when challenged; conflicts of jurisdiction. |
| Criminal/state-security jurisdiction | Offences such as treason, espionage, crimes affecting internal/external security of the Union and crimes assigned by federal law. |
| Practical role | Apex constitutional and federal court, not a general final appeal court for all local-court matters. |

The Federal Supreme Court’s constitutional jurisdiction includes disputes between the Union and one or more emirates, disputes among emirates, questions of constitutionality, interpretation of the Constitution, and certain serious offences against the Union. Its official portal is sc.gov.ae [[5]](#ref5).

### 2.3 Federal courts of appeal and first instance

The federal judiciary covers emirates that have not maintained fully separate local court systems. Dubai, Abu Dhabi and Ras Al Khaimah operate local judicial systems; Sharjah, Ajman, Umm Al Quwain and Fujairah are generally within the federal court system. Federal courts hear civil, commercial, labour, personal-status, criminal and administrative matters within their territorial and subject-matter competence.

| Federal court level | Typical location / coverage | Function |
|---|---|---|
| Federal Supreme Court | Abu Dhabi | Constitutional and federal supreme jurisdiction. |
| Federal Courts of Appeal | Abu Dhabi, Sharjah, northern-emirate circuits | Appeals from federal Courts of First Instance. |
| Federal Courts of First Instance | Federal court seats in Sharjah, Ajman, Umm Al Quwain, Fujairah and federal locations | Initial civil, commercial, labour, personal-status and criminal jurisdiction. |

**Six-court practical description requested.** In practice, federal first-instance service coverage is often described through federal courthouse/service locations across the federal-judiciary emirates, including Sharjah, Ajman, Umm Al Quwain and Fujairah, and federal circuits/branches for matters assigned to federal jurisdiction. Coverage should be verified on the Ministry of Justice portal for current courthouse names and e-service routing.

### 2.4 Dubai Courts

| Dubai Courts component | Function |
|---|---|
| Court of First Instance | Initial jurisdiction across civil, commercial, real estate, labour, personal status, criminal and administrative divisions. |
| Court of Appeal | Reviews appealable judgments of first instance. |
| Court of Cassation | Highest Dubai ordinary court; reviews points of law and certain procedural grounds. |
| Execution Court | Enforcement of judgments, orders, arbitral awards and execution instruments. |
| Commercial Court | Specialized commercial judiciary; Dubai reforms created more specialized commercial tracks and chambers. |
| Personal Status Court | Marriage, divorce, custody, maintenance, inheritance and related family matters. |
| Criminal Court | Felonies, misdemeanours and contraventions under federal criminal law and local procedures. |
| Labour Court / circuits | Employment disputes, usually after MOHRE or relevant pre-court referral. |
| Small claims / minor claims | Lower-value claims, including expedited procedures; AED 500,000 is a commonly referenced upper threshold for certain small-claim or minor-claim tracks. |

**Dubai court fees.** For civil claims, the commonly used schedule is 6% of claim value with a minimum fee of AED 500 and a cap that is often cited as AED 40,000 for many civil claims. Always verify the applicable fee schedule because case type, emirate-level amendments, electronic service charges, expert deposits and enforcement fees can alter the actual amount.

| Dubai fee item | Typical amount / formula | Notes |
|---|---:|---|
| Civil claim filing | 6% of claim value | Subject to minimum and cap. |
| Minimum civil fee | AED 500 | Varies by case/service type. |
| Common maximum civil filing cap | AED 40,000 | Confirm on Dubai Courts fee schedule before filing. |
| Expert deposit | Case-specific | Court may order technical/accounting/engineering expert deposit. |
| Execution fee | Case-specific | Payable for enforcement applications. |
| Translation/legalisation | Case-specific | Arabic legal translation usually required for non-Arabic documents. |

### 2.5 Abu Dhabi Judicial Department (ADJD)

ADJD states that the court system in Abu Dhabi consists of three levels: courts of first instance, courts of appeal and court of cassation. The Court of First Instance has general jurisdiction over cases filed in Abu Dhabi except matters excluded by law; the Court of Appeal consists of chambers of three judges; and the Court of Cassation is the highest judicial body in the emirate [[6]](#ref6).

| ADJD component | Detail from ADJD research record |
|---|---|
| Courts of First Instance | General jurisdiction; major three-judge chambers and minor one-judge chambers. |
| Court of Appeal | Three-judge chambers; reviews first-instance judgments across civil, commercial, labour, administrative, personal and criminal cases. |
| Court of Cassation | Highest Abu Dhabi court; reviews Court of Appeal judgments and jurisdictional conflicts among Abu Dhabi courts. |
| Specialized chambers | Construction and contracts, banks/financial institutions, securities, insurance/indemnification, IP, child visitation, medical-error, domestic-worker, government-employee and small-claim cases. |
| Abu Dhabi Criminal Court | Established by ADJD decision; felony, misdemeanour and offence chambers. |
| Abu Dhabi Commercial Court | Established by Chairman Decision No. 28 of 2019; commercial cases, foreign commercial judgments, commercial arbitration enforcement. |
| Abu Dhabi Labour Court | Established by Chairman Decision No. 22 of 2018; labour claims, appeals, enforcement and fast-track labour chamber. |
| Non-Muslim Personal Status and Inheritance Chambers | Established in Abu Dhabi Court of First Instance; began functioning in February 2017 per ADJD research material. |
| Family Guidance Committee | Mandatory family-dispute conciliation/mediation route before many personal-status filings. |
| CASD / mediation | Abu Dhabi uses conciliation, settlement and dispute-management mechanisms before or alongside litigation for designated disputes. |

**Abu Dhabi court fees.** Research instructions specify Abu Dhabi civil fees of 2.5% plus AED 200 registration for the relevant procedure. Fee practice varies by matter and local amendments; ADJD e-services should be checked before filing.

### 2.6 DIFC Courts

| Item | Detail |
|---|---|
| Establishing law | Dubai Law No. 12 of 2004, amended notably by Dubai Law No. 16 of 2011. |
| Legal system | English-language common-law civil and commercial court system. |
| Courts | Court of First Instance and Court of Appeal; Small Claims Tribunal (SCT) within DIFC Courts. |
| Jurisdiction | DIFC bodies/establishments, DIFC transactions, claims arising in or related to DIFC, and opt-in jurisdiction by written agreement. |
| Opt-in | Parties may agree in writing to DIFC Courts jurisdiction even when not otherwise DIFC-connected, subject to statutory requirements. |
| SCT threshold requested | AED 500,000; fast-track category often referenced at AED 100,000. |
| Enforcement with Dubai | 2009 protocol / reciprocal enforcement route between DIFC Courts and Dubai Courts. |
| Official URL | https://www.difccourts.ae |

DIFC Courts are central to UAE cross-border disputes because their judgments can be enforced through Dubai Courts and because DIFC operates in English with common-law procedure. DIFC also historically functioned as a conduit jurisdiction for enforcement of arbitral awards and foreign judgments, subject to evolving Dubai and DIFC case law.

### 2.7 ADGM Courts

| Item | Detail |
|---|---|
| Establishing framework | Abu Dhabi Law No. 4 of 2013 and ADGM court regulations; ADGM Courts Regulations 2015. |
| Legal system | Direct application of English common law, subject to ADGM legislation. |
| Court structure | Court of First Instance and Court of Appeal. |
| Subject focus | Commercial, civil and financial-services disputes connected to ADGM or within opt-in/statutory jurisdiction. |
| Procedure | Electronic, English-language, modern common-law process with case-management powers. |
| Official URL | https://www.adgm.com/adgm-courts |

### 2.8 Sharia courts and personal-status adjudication

Sharia principles remain central to Muslim personal status. Personal-status courts or divisions adjudicate marriage, divorce, custody, maintenance, guardianship and inheritance. The applied jurisprudential approach often reflects Maliki and Hanbali influences, although codified federal personal-status law and emirate-level non-Muslim regimes now structure many disputes.

| Matter | Muslim personal-status treatment | Non-Muslim / special regime |
|---|---|---|
| Marriage | Court registration; wali and mahr concepts; capacity rules. | Abu Dhabi civil marriage; Dubai civil/non-Muslim mechanisms; foreign law may be pleaded subject to proof. |
| Divorce | Talaq, khulʿ and judicial divorce/fasikh. | Abu Dhabi civil divorce and other non-Muslim routes. |
| Custody | Age/gender/default custodian rules subject to best interests and court discretion. | Best-interests analysis more prominent in civil regimes. |
| Inheritance | Quranic shares and Sharia succession unless valid non-Muslim will/special regime applies. | DIFC Wills Service, Dubai non-Muslim will registration, Abu Dhabi civil wills. |

### 2.9 Legal profession and advocates

Federal Law No. 23 of 1991 on the Regulation of the Legal Profession is the core federal statute on advocates. Legal practice before UAE onshore courts is restricted compared with legal consultancy. A person seeking a UAE advocacy licence normally requires legal education, training and registration with the competent authority; the task instructions identify a UAE law degree or recognized foreign degree plus training, Arab nationality for UAE advocacy licence, and a Ministry of Justice bar number. Foreign lawyers may advise on foreign law, international transactions or legal consultancy through licensed firms, but generally cannot appear as advocates before UAE onshore courts unless admitted under the applicable rules.

| Role | May advise? | May appear in UAE onshore courts? | Typical licence/registration |
|---|---:|---:|---|
| UAE advocate | ✓ | ✓ | MOJ/local advocate roll; bar number; nationality/education/training requirements. |
| Legal consultant | ✓ | Usually no | Emirate legal-affairs department or free-zone licence. |
| Foreign lawyer in international firm | ✓ on foreign/international law | No onshore rights of audience unless separately admitted | Firm/free-zone/local consultancy licence. |
| DIFC practitioner | ✓ | DIFC rights of audience if registered | DIFC Courts register of practitioners; Part I/Part II distinction. |
| ADGM practitioner | ✓ | ADGM rights according to ADGM Courts rules | ADGM Courts registration/rules. |

## 3. Major Federal Laws

### 3.1 Civil Transactions Law — Federal Law No. 5 of 1985

| Field | Detail |
|---|---|
| Official title | Federal Law No. 5 of 1985 Concerning the Civil Transactions Law of the United Arab Emirates. |
| Official source | UAE Legislation Portal download page for Federal Law No. 5 of 1985 [[7]](#ref7). |
| Secondary text source used where portal blocked | Lexis Middle East and publicly available English PDF extracts [[8]](#ref8) [[9]](#ref9). |
| Status | Operative civil code until replacement by the new Civil Code framework where applicable. |
| Replacement / reform | Federal Decree-Law No. 25 of 2025 concerning the Civil Transactions Law, effective 1 June 2026 according to legal commentary and research instructions. |
| Legal family | Civil-law codification influenced by Islamic jurisprudence. |

#### 3.1.1 Sources of law — Article 1 and interpretive hierarchy

Article 1 is central because it tells courts how to resolve gaps. The research record captured the English wording from Lexis Middle East:

```text
The civil transactions in the United Arab Emirates State shall be subject to the law, whereas commercial transactions remain subject to the laws and regulations applicable in their regard, pending the issuance of the Federal Commercial Law.
```

In broader operation, the Civil Transactions Law is read with its interpretive provisions requiring recourse to Islamic jurisprudence when statutory text is absent, then to custom and principles compatible with Sharia and public order. This is why civil-law interpretation in the UAE cannot be treated as purely French/Egyptian civil code doctrine; Sharia principles remain an acknowledged source of gap-filling.

#### 3.1.2 Contract formation — Articles 130–195 map

| Article range | Subject | Key rule / practical effect |
|---|---|---|
| 130–137 | Contract definition and elements | Contract arises from offer and acceptance with legally recognised subject matter and cause. |
| 138 | Offer | Offer must be sufficiently definite and show intention to be bound; may be express or implied. |
| 139 | Invitation / negotiation | Preliminary negotiation does not bind unless conditions show final offer. |
| 140 | Acceptance | Acceptance must match offer; silence is generally not acceptance unless circumstances or prior dealings justify it. |
| 141–145 | Meeting of minds | Contract formation requires correspondence of offer and acceptance on essential terms. |
| 146–150 | Capacity and representation | Parties must have capacity; agents/representatives must act within authority. |
| 151–160 | Subject matter | Subject must be possible, defined or capable of definition, and lawful. |
| 161–170 | Cause / purpose | Purpose must be lawful and not contrary to public order or morals. |
| 171–184 | Conditions and modalities | Conditions, time limits and suspensive/resolutory effects shape obligations. |
| 185–195 | Void and defective contracts | Illegality, impossibility, lack of capacity or absence of essential elements may render contract void or voidable. |

#### 3.1.3 Obligations — Articles 246–283 and damages

| Article | Topic | Key provision |
|---:|---|---|
| 246 | Good faith | Contracts must be performed according to their contents and in a manner consistent with good faith. |
| 247 | Exception of non-performance | A contracting party may withhold performance if the counterparty does not perform reciprocal obligations, subject to conditions. |
| 248–249 | Hardship / exceptional circumstances | Exceptional public events can justify judicial adjustment of oppressive obligations under the old Civil Code; the 2025 code modernises force imprévision concepts. |
| 272 | Termination / rescission | Court may order performance, grant time, or rescind with damages depending on breach. |
| 273 | Force majeure | Contract obligations may be extinguished where performance becomes impossible due to force majeure. |
| 282 | General tort liability | “Every harm done to another shall render the doer thereof bound to make good the harm.” |
| 283 | Liability without fault / nuisance-style liability | Liability may attach to acts causing harm even without a fault-based analysis in some circumstances. |
| 286 | Vicarious liability | Employers/guardians may be liable for persons under supervision or employment where statutory conditions are met. |
| 290 / 292 | Contributory fault | Court may reduce damages where the injured party contributed to the harm. |
| 298 | Tort limitation | Tort claims generally subject to a three-year limitation from knowledge of harm and person responsible, subject to long-stop/statutory rules. |
| 389 | Damages | Compensation covers actual loss and lost profit if naturally resulting from the harmful act and sufficiently proven. |
| 473 | General limitation | General civil limitation often referenced as 15 years unless a specific period applies. |
| 474 | Shorter commercial/special periods | Some claims have shorter limitation periods. |

#### 3.1.4 Tort — Articles 282–348

The Civil Transactions Law’s tort provisions are broad. Article 282 is the anchor clause. UAE courts often require proof of fault, damage and causation in civil liability, but the code wording is harm-centred and distinct from common-law negligence. Damages may include actual loss, lost profit and moral damages where available, but claimants must prove loss with adequate evidence.

| Tort issue | UAE civil-law treatment |
|---|---|
| Fault/harm | Article 282 anchors liability for harm. |
| Causation | Claimant must connect act/omission to damage. |
| Employer liability | Article 286-type rules impose liability for employees/agents under supervision. |
| Contributory negligence | Damages can be reduced where claimant contributed to loss. |
| Limitation | Article 298 three-year tort period commonly cited. |
| Moral damages | Available in appropriate cases, including injury to reputation, dignity or emotional harm. |
| Expert evidence | Courts often appoint experts for technical causation and quantum. |

#### 3.1.5 Muqawala — contract for works, Articles 872–896

Muqawala is the Civil Code framework for construction/work contracts. It is essential for construction and engineering disputes and should be read with FIDIC forms, local procurement laws, decennial liability and safety regulations.

| Article | Subject | Detailed operational meaning |
|---:|---|---|
| 872 | Definition | Muqawala is a contract whereby one party undertakes to make a thing or perform work in return for consideration undertaken by the other party. |
| 873 | Scope of contractor obligation | Contractor may supply work only or work plus materials depending on contract terms. |
| 874 | Contractor-supplied materials | Contractor supplying materials is responsible for quality and must comply with specifications. |
| 875 | Employer-supplied materials | Contractor must preserve employer materials, use them properly and account for them. |
| 876 | Work according to contract | Contractor must perform according to agreed specifications, drawings, time and professional standards. |
| 877 | Defective work | Employer may demand correction, replacement or other remedies where work departs from contract. |
| 878 | Impossibility / destruction | Risk allocation depends on cause of destruction and stage of delivery. |
| 879 | Variations | Additional work or variation requires authority/agreement; recovery depends on proof of instruction or necessity. |
| 880 | Price | Price may be lump sum, measured quantity, cost-plus or otherwise agreed. |
| 881 | Lump-sum risk | Contractor bears risk of cost overruns under lump sum unless statutory/contractual exception applies. |
| 882 | Employer changes | Employer-requested design/quantity changes may entitle contractor to additional payment/time. |
| 883 | Architect/engineer role | Design professionals may supervise and certify work under contract. |
| 884 | Payment | Payment due according to agreed milestones, measurement, completion or certification. |
| 885 | Suspension | Contractor rights may arise if employer fails to perform payment/cooperation obligations. |
| 886 | Subcontracting | Subcontracting permitted unless personal performance or contract restriction applies; main contractor remains responsible. |
| 887 | Direct claims | Subcontractors and workers may have limited direct rights over amounts due to contractor under statutory conditions. |
| 888 | Delivery | Work must be delivered and accepted; acceptance affects defect claims but not hidden defects. |
| 889 | Employer inspection | Employer should inspect work upon delivery and notify apparent defects. |
| 890 | Hidden defects | Hidden defects may preserve claims after acceptance if notified within required periods. |
| 891 | Termination by employer | Employer may terminate subject to payment for completed work and compensation if unjustified. |
| 892 | Contractor death/incapacity | Personal-skill contracts may terminate on contractor death/incapacity; non-personal contracts may continue. |
| 893 | Decennial liability | Contractor and architect/engineer may be jointly liable for total or partial collapse or serious structural defect threatening stability. |
| 894 | Duration of decennial liability | Liability period is ten years from delivery unless longer period agreed; shorter exculpatory terms are generally ineffective. |
| 895 | Limitation for decennial claim | Claim must be brought within statutory period after collapse/defect discovery. |
| 896 | Mandatory nature | Clauses exempting contractor/architect from decennial liability are void. |

#### 3.1.6 Agency — Articles 924–965

| Agency concept | UAE Civil Code treatment |
|---|---|
| Express authority | Principal expressly authorizes agent to act. |
| Implied authority | Authority inferred from task, custom or necessary incidents of express mandate. |
| Apparent authority | Third-party reliance may be protected where principal’s conduct creates appearance of authority. |
| Agent duties | Act within authority, follow principal instructions, account for property/information and avoid conflicts. |
| Principal duties | Reimburse expenses, pay agreed remuneration and accept acts within authority. |
| Termination | Mandate may terminate by completion, expiry, revocation, resignation, death/incapacity or other statutory grounds. |
| Commercial agency overlay | Registered commercial agencies are governed by separate federal commercial-agency law. |

#### 3.1.7 New Civil Code — Federal Decree-Law No. 25 of 2025

Research instructions identify Federal Decree-Law No. 25 of 2025 as the new Civil Code, effective 1 June 2026, modernising provisions including hardship / force imprévision and electronic transactions. Legal commentary in 2026 described changes to contract negotiation, formation and interpretation [[10]](#ref10). Before relying on any 1985 Civil Code provision after 1 June 2026, verify whether the new Civil Code has replaced or modified the applicable rule.

| Reform theme | Practical implication |
|---|---|
| Hardship / imprévision | Courts may receive clearer tools to adjust obligations affected by exceptional events. |
| Electronic transactions | Formation, evidence and notices may better reflect digital contracting. |
| Contract negotiation | Pre-contractual conduct and good faith may receive modernised treatment. |
| Interpretation | Codified interpretive rules may reduce uncertainty in commercial contracts. |
| Transition | Existing contracts may require transitional analysis. |

### 3.2 Commercial Companies Law — Federal Decree-Law No. 32 of 2021, amended by Federal Decree-Law No. 20 of 2025

| Field | Detail |
|---|---|
| Official title | Federal Decree-Law No. 32 of 2021 on Commercial Companies. |
| Replaced | Federal Law No. 2 of 2015. |
| Official source | UAE Legislation Portal / Ministry of Economy company-law materials [[11]](#ref11). |
| 2025 amendment | Federal Decree-Law No. 20 of 2025; research instructions identify class shares, redomiciliation, dual licensing and SPAC rules. |
| Core company forms | LLC, PJSC, private joint stock company, partnership forms and branches/foreign entities. |

#### 3.2.1 Limited liability companies — Articles 70–104

| Topic | Rule / requirement |
|---|---|
| Legal nature | LLC liability is limited to shareholder capital contributions, subject to exceptions for fraud, mismanagement or statutory liability. |
| Shareholders | Traditionally 2–50 persons; single-person LLC also permitted under modern law for eligible owners. |
| Capital | No universal fixed minimum for ordinary LLC; capital must be sufficient for objects and divided into shares/quotas. |
| Foreign ownership | 100% foreign ownership broadly permitted for many onshore activities after reforms, except strategic-impact or restricted sectors. |
| Management | One or more managers appointed in memorandum or by shareholders. |
| Manager duties | Act within authority, comply with law and constitutional documents, maintain accounts, avoid unauthorized conflict and manage with due care. |
| Share transfer | Usually subject to pre-emption and memorandum requirements. |
| General assembly | Shareholders approve accounts, managers, auditors, profit distribution, amendments and major actions. |
| Quorum | Determined by law and memorandum; repeat meetings may proceed with lower quorum. |
| Profit distribution | According to constitutional documents and approved accounts; unlawful distributions may be recoverable. |
| Losses and dissolution | Serious losses may trigger mandatory shareholder action, continuation/dissolution decisions or restructuring. |

#### 3.2.2 Public joint stock companies — Articles 119–177

| Topic / article | Provision |
|---|---|
| Incorporation | PJSC formation requires founders, capital, prospectus/subscription rules, approvals and registration. |
| Prospectus — Article 135 | Prospectus must contain material subscription information, founders, capital, business objects, risk factors, financial information and approvals. |
| Board composition — Article 151 | Board must have at least 3 and no more than 15 members; at least one-third independent directors where applicable under governance rules. |
| Board secretary | Corporate-governance rules require proper board administration and minutes; secretary supports compliance. |
| Audit committee | PJSC governance requires audit oversight, internal controls and auditor liaison. |
| Related-party transactions — Article 152 | Board approval, shareholder or SCA disclosure/approval may be required depending on value and nature; conflicts must be managed. |
| AGM — Article 168 | Annual general meeting within 4 months after financial-year end. |
| Reserve — Article 195 | 5% of net profits commonly transferred to legal reserve until statutory threshold met. |
| Disclosure | PJSCs listed on UAE markets are subject to SCA and market disclosure rules. |
| Directors’ liability | Directors may be liable for fraud, abuse of power, violation of law/AOA or gross error. |

#### 3.2.3 2025 amendment themes

| Amendment theme | Detailed practical content |
|---|---|
| Class shares | Introduces/clarifies definitions for different share classes, enabling economic/voting/liquidation preference structures subject to approvals. |
| Redomiciliation | Allows inbound/outbound continuation procedures: board/shareholder approval, solvency/creditor protection, registrar approval, issuance of continuation certificate and cancellation/registration steps. |
| Dual licensing | Enables companies to hold or coordinate licences across mainland and free-zone contexts under procedure set by competent authorities. |
| SPACs | Special purpose acquisition company formation rules, sponsor requirements, escrow/subscription mechanics, acquisition deadlines and investor protections. |
| Corporate flexibility | Designed to align UAE corporate practice with international capital-market and holding-company structures. |

### 3.3 Bankruptcy — Federal Decree-Law No. 51 of 2023, effective 1 May 2024

| Field | Detail |
|---|---|
| Official title | Federal Decree-Law No. 51 of 2023 concerning Financial Restructuring and Bankruptcy. |
| Effective date | 1 May 2024. |
| Replaced | Federal Decree-Law No. 9 of 2016 bankruptcy regime. |
| Key procedures | Preventive settlement, restructuring and bankruptcy/liquidation. |
| Scope exclusion | DIFC and ADGM insolvency regimes have their own rules. |
| Commentary source | Dechert and other legal commentary explain the new framework [[12]](#ref12). |

#### 3.3.1 Preventive settlement

| Feature | Rule |
|---|---|
| Initiator | Debtor initiates preventive settlement. |
| Creditor threshold | Research instructions identify AED 100,000+ creditor claims as relevant threshold. |
| Moratorium | Automatic stay/moratorium on filing, subject to court control. |
| Plan period | 3-month plan period, extendable to 6 months. |
| Vote | Creditor approval by 66% in value. |
| Ratification | Court ratification required. |
| Goal | Rescue viable debtor before full restructuring or liquidation. |

#### 3.3.2 Restructuring

| Feature | Rule |
|---|---|
| Nature | Court-supervised restructuring for distressed debtor. |
| Initial period | 90 days, extendable by further 90 days according to research instructions. |
| Stay | Automatic stay of claims and enforcement. |
| Trustee | Court-appointed trustee supervises assets, claims, plan and reporting. |
| Claims ranking | Secured creditors to value of security, preferred claims including employees’ last three months’ wages and government dues, then unsecured creditors. |
| Plan | Reorganisation plan proposed, voted and ratified. |
| Failure | May convert to bankruptcy/liquidation. |

#### 3.3.3 Bankruptcy / liquidation

| Feature | Rule |
|---|---|
| Trigger | Insolvency, inability to pay debts, failed preventive settlement/restructuring, creditor petition or debtor petition. |
| Trustee powers | Inventory assets, manage estate, verify claims, challenge transactions, sell assets and distribute proceeds. |
| Avoidance | Pre-bankruptcy transactions may be challenged; research instructions identify 2-year look-back. |
| Director liability | Fraudulent trading, concealment, asset dissipation, preferential payments or late filing can trigger liability. |
| Distribution | Secured/preferred/unsecured priority order. |
| Closure | Court closes proceedings after distribution or plan completion. |

#### 3.3.4 Cross-border insolvency

The new framework incorporates cross-border insolvency concepts aligned with the UNCITRAL Model Law, including recognition of foreign proceedings and cooperation with foreign courts/representatives. Practitioners must separately consider DIFC Insolvency Law and ADGM Insolvency Regulations where the debtor is incorporated or has assets in those financial free zones.

### 3.4 Consumer Protection — Federal Law No. 15 of 2020

| Field | Detail |
|---|---|
| Official title | Federal Law No. 15 of 2020 on Consumer Protection. |
| Official source | Ministry of Economy PDF and UAE Legislation download [[13]](#ref13) [[14]](#ref14). |
| Implementing policy | Ministry of Economy and local consumer-protection departments. |
| Core themes | Safety, information, fair pricing, remedies, e-commerce obligations and penalties. |

#### 3.4.1 Eight consumer rights

| No. | Right | Practical meaning |
|---:|---|---|
| 1 | Safety | Consumer has right to safe goods/services and protection from hazards. |
| 2 | Information | Supplier must provide correct data, price, specifications, terms and risks. |
| 3 | Choice | Consumer should not be forced into unfair tying or misleading selection. |
| 4 | Complaint and compensation | Consumer may complain and seek redress for defective or harmful goods/services. |
| 5 | Privacy | Consumer data and transaction privacy should be respected. |
| 6 | Education | Consumers should receive awareness and guidance. |
| 7 | Environmental protection | Goods/services should respect sustainable and environmental obligations. |
| 8 | Basic necessities | Access to essential goods/services should be protected, especially against crisis manipulation. |

#### 3.4.2 Returns, warranties and e-commerce

| Issue | Rule stated in research instructions |
|---|---|
| E-commerce return | 14 days for e-commerce purchases without needing a reason, subject to exceptions and implementing rules. |
| In-store return | Store policy applies; no universal no-reason return right unless defect/misrepresentation exists. |
| Warranty | Minimum 1 year; extended warranty optional. |
| Price display | Failure to display price can attract administrative penalty. |
| Online contract | E-commerce provider must disclose identity, goods/services, price, delivery, warranty and return information. |
| Delivery proof | Supplier should maintain evidence of delivery/transaction terms. |

#### 3.4.3 Penalties

| Violation type | Penalty range / consequence |
|---|---|
| Non-display of price | AED 1,000 level penalty noted in task instructions. |
| Misleading information | Administrative fines, correction, withdrawal or closure depending on severity. |
| Fraudulent claims | Up to AED 1,000,000 according to task instructions. |
| Repeat violation | Double penalty. |
| Defective goods | Recall, replacement, repair, refund, compensation and reporting obligations. |

### 3.5 Criminal laws — Penal Code / Crimes and Penalties Law

| Field | Detail |
|---|---|
| Official title | Federal Decree-Law No. 31 of 2021 on the Issuance of the Crimes and Penalties Law. |
| Replaced | Federal Law No. 3 of 1987 Penal Code. |
| Related laws | Criminal Procedures Law, Cybercrime Law No. 34 of 2021, AML/CFT laws, narcotics laws, anti-terrorism laws. |
| Punishment families | Hudud, qisas, diya and taʿzir concepts coexist with statutory penalties. |

#### 3.5.1 Penalty categories

| Category | Meaning | UAE practice note |
|---|---|---|
| Hudud | Fixed Islamic punishments for certain offences under strict conditions. | Research instructions mention hand amputation for qualified theft, flogging for alcohol and stoning for adultery, while noting full application is rare and courts may apply statutory discretion or Sharia principles. |
| Qisas | Retaliation/retribution: life for life, injury for injury. | In homicide/serious injury, victim’s family pardon can permit diya instead of qisas. |
| Diya | Blood money compensation. | Cabinet-set amounts; task instructions state AED 200,000 for intentional and unintentional killing, with injury amounts varying by body part. |
| Taʿzir | Discretionary punishment. | Most modern statutory offences are handled through imprisonment, fines, deportation, confiscation and ancillary penalties. |

#### 3.5.2 Key offence penalty table requested

| Offence | Minimum | Maximum | Notes |
|---|---:|---:|---|
| Murder, intentional | Death / life | Death | Qisas; pardon by victim family can allow diya instead. |
| Rape | 5 years | Life / death | Aggravated circumstances can lead to death penalty. |
| Theft, hadd | Discretionary | Amputation | Strict conditions rarely met; ordinary theft usually statutory taʿzir penalties. |
| Drug possession | 4 years | Death | Amount/type/intent-based; narcotics law includes treatment pathways and severe trafficking penalties. |
| Bribery of public official | 5 years | Life | Confiscation and fines may apply. |
| Cybercrime | 1 year | 25 years | See Federal Decree-Law No. 34 of 2021. |
| Online defamation | 1 year | 2 years | Fine up to AED 500,000 noted in task instructions. |
| Treason / state security | Severe imprisonment | Death | Federal Supreme Court/state-security jurisdiction may arise. |
| Money laundering | Imprisonment/fine | Enhanced penalties | See AML/CFT law and confiscation. |
| False rumours | Imprisonment/fine | Enhanced penalties | Cybercrime law includes false information/rumour offences. |

### 3.6 AML/CFT — Federal Decree-Law No. 10 of 2025

| Field | Detail |
|---|---|
| Official title | Federal Decree-Law No. 10 of 2025 on Anti-Money Laundering and Combating the Financing of Terrorism and Illegal Organisations. |
| Replaced | Federal Decree-Law No. 20 of 2018, according to task instructions. |
| Major change | Tax evasion added as predicate offence. |
| FATF status | UAE removed from FATF grey list in February 2024, according to research instructions. |
| Reporting system | goAML for suspicious transaction/activity reporting. |

| Threshold / obligation | Amount / rule |
|---|---:|
| Cash transaction reporting | AED 55,000+ |
| Wire transfer threshold | AED 3,500+ |
| DNFBP real-estate threshold | AED 55,000+ |
| STR/SAR filing | Mandatory through goAML for suspicious activity/transactions. |
| Predicate offences | Broad list including tax evasion under 2025 reform. |
| Sanctions screening | Required for regulated institutions and DNFBPs. |
| Customer due diligence | Identify and verify customer, beneficial owner, purpose and source of funds. |
| Enhanced due diligence | Politically exposed persons, high-risk countries, complex transactions and higher-risk customers. |

### 3.7 Data Protection — Federal Decree-Law No. 45 of 2021

| Field | Detail |
|---|---|
| Official title | Federal Decree-Law No. 45 of 2021 on Personal Data Protection. |
| Authority | UAE Data Office (UAEDO). |
| Implementing regulation | Cabinet Decision No. 33 of 2023, according to task instructions. |
| Scope | Processing of personal data, subject to exclusions and sector/free-zone regimes. |

#### 3.7.1 Data subject rights — Article 9

| Article 9 right | Description |
|---|---|
| 9.1 Access | Data subject can obtain confirmation and access to personal data. |
| 9.2 Rectification | Right to correct inaccurate data. |
| 9.3 Erasure | Right to deletion where legal grounds exist. |
| 9.4 Restriction | Right to restrict/suspend processing in specified circumstances. |
| 9.5 Portability | Right to receive data in portable form. |
| 9.6 Objection | Right to object to processing in specified circumstances. |
| 9.7 Withdraw consent | Consent may be withdrawn where processing is consent-based. |
| 9.8 Automated decisions | Right not to be subject to automated decisions with legal/significant effects. |
| 9.9 Complaint | Right to complain to UAEDO. |

#### 3.7.2 DPO, sensitive data, transfers, breach and penalties

| Issue | Rule |
|---|---|
| DPO requirement | Article 19 requires DPO for public authorities, large-scale processing or large-scale sensitive data processing. |
| Sensitive data | Health, financial, racial/ethnic origin, criminal records, biometric and genetic data. |
| Cross-border transfer | Adequacy by UAE Cabinet or safeguards such as BCRs, SCCs, consent or vital interests. |
| Breach notice | Article 22: notify UAEDO within 72 hours; notify data subjects without undue delay if high risk. |
| Penalties | Article 43: up to AED 20 million; aggravated sensitive-data violations can include imprisonment up to 2 years and fine up to AED 20 million according to task instructions. |
| Parallel regimes | DIFC Data Protection Law and ADGM Data Protection Regulations apply inside those free zones. |

### 3.8 Intellectual property

#### 3.8.1 Trademarks — Federal Law No. 36 of 2021

| Topic | Rule |
|---|---|
| Classification | Nice Classification, 45 classes. |
| Multi-class | Multi-class applications available. |
| Registration time | 3–6 months commonly cited if no objections/opposition. |
| Term | 10 years, renewable. |
| Well-known marks | Unregistered well-known marks protected. |
| GCC route | GCC trademark/joint filing concepts may be relevant; verify current GCC trademark system. |
| Madrid Protocol | UAE member since 2021. |
| Opposition | 30 days after publication. |
| Non-use cancellation | 3 consecutive years. |
| Enforcement | Civil, administrative and criminal remedies may apply to infringement/counterfeiting. |

#### 3.8.2 Patents / industrial property — Federal Law No. 17 of 2002 and modern industrial property law

| Topic | Rule |
|---|---|
| Patentability | Novelty, inventive step and industrial applicability. |
| Exclusions | Discoveries, mental methods, surgical/therapeutic methods and other statutory exclusions. |
| Term | 20 years, non-renewable. |
| Routes | UAE national filing, PCT national phase, GCC Patent Office route (Riyadh) where relevant. |
| Examination | IAPA examination often cited at 2–4 years depending on backlog. |
| Maintenance | Fees from year 2. |
| Utility certificates | Shorter-term protection may be available under industrial-property framework. |

#### 3.8.3 Copyright — Federal Decree-Law No. 38 of 2021

| Topic | Rule |
|---|---|
| Protection | Automatic upon creation; registration useful for evidence. |
| General term | Life of author + 70 years. |
| Software / corporate works | 50 years according to task instructions for software/certain works. |
| Moral rights | Perpetual/non-transferable in principle. |
| Economic rights | Transferable/licensable by contract. |
| Exceptions | Research, education, criticism, news and fair-dealing-style exceptions. |
| Penalties | AED 10,000–500,000 plus imprisonment for serious infringement according to task instructions. |

### 3.9 Personal Status — Federal Law No. 28 of 2005, amended 2023

| Field | Detail |
|---|---|
| Official title | Federal Law No. 28 of 2005 on Personal Status. |
| Applies mainly to | Muslims in marriage, divorce, custody, guardianship, maintenance and inheritance. |
| Amendments | Significant reforms including 2023 updates and non-Muslim civil regimes. |
| Related regimes | Abu Dhabi Civil Marriage Law 2021, DIFC Wills Service, Dubai non-Muslim wills. |

#### 3.9.1 Marriage

| Issue | Rule |
|---|---|
| Wali | Guardian required for Muslim bride. |
| Mahr | Dower mandatory. |
| Registration | Marriage must be registered with court/competent authority. |
| Minors | Marriage of minors requires court approval. |
| Polygamy | Article 10 conditions: financial capacity, equal treatment, no harm to existing wife, court permission. |
| Capacity | Legal capacity and absence of impediments required. |

#### 3.9.2 Divorce

| Form | Detail |
|---|---|
| Talaq | Unilateral divorce by husband; revocable first and second talaq; third can be irrevocable. |
| Khulʿ | Wife-initiated divorce with return of mahr/financial settlement. |
| Fasikh | Judicial dissolution for harm, non-maintenance, impotence, prolonged absence, imprisonment and other grounds. |
| Mediation | Family Guidance Committee/conciliation commonly mandatory before litigation. |
| Maintenance | Interim and post-divorce support can be ordered. |

#### 3.9.3 Custody and inheritance

| Topic | Rule |
|---|---|
| Custody default | Mother until boy 11 and girl 13, subject to court order and best interests. |
| Father role | Guardianship/financial guardianship often remains with father; custody may shift or continue by order. |
| Non-Muslim custody | Best-interests test under civil regimes. |
| Spouse inheritance | Surviving spouse: 1/4 or 1/8 depending on children. |
| Daughter | 1/2 if sole daughter; with multiple daughters commonly 2/3 collectively; task instruction mentions daughter 1/2 or 1/3, so verify precise share by family composition. |
| Parents | Quranic shares vary depending on descendants and siblings. |
| Asaba | Male agnate takes residue after fixed shares. |

#### 3.9.4 Non-Muslim personal status

| Regime | Features |
|---|---|
| Abu Dhabi Civil Marriage Law 2021 | Civil marriage/divorce for non-Muslims; 50/50 property default according to task instructions; civil wills and inheritance flexibility. |
| DIFC Wills Service | Five will types; allows non-Muslims to register wills for Dubai/Ras Al Khaimah assets and guardianship depending on rules. |
| Dubai Courts non-Muslim will registration | Dubai onshore will registration options for non-Muslims. |
| Foreign law | Courts may apply foreign personal-status law if properly pleaded/proven and not contrary to public order. |

## 4. Regulatory Authorities — legal basis, jurisdiction and websites

| No. | Authority | Legal basis / source | Jurisdiction | Website |
|---:|---|---|---|---|
| 1 | Ministry of Justice (MOJ) | Federal ministry; laws on judiciary, notaries, legal profession | Federal courts, notaries, lawyers, legislation services | https://www.moj.gov.ae |
| 2 | Federal Supreme Court | Constitution Arts. 94–109 | Constitutional and federal supreme jurisdiction | https://www.sc.gov.ae |
| 3 | Ministry of Economy / MOET | Federal economic laws | Companies, consumer protection, IP, commercial agencies | https://www.moet.gov.ae |
| 4 | Central Bank of the UAE (CBUAE) | Central Bank law | Banking, insurance, monetary policy, AML supervision | https://www.centralbank.ae |
| 5 | Securities and Commodities Authority (SCA) | Securities laws | Onshore securities, listed companies, markets | https://www.sca.gov.ae |
| 6 | Ministry of Human Resources and Emiratisation (MOHRE) | Labour law | Labour relations, work permits, Emiratisation | https://www.mohre.gov.ae |
| 7 | Federal Authority for Identity, Citizenship, Customs and Port Security (ICP) | Immigration/nationality laws | ID, citizenship, residency, customs/ports functions | https://icp.gov.ae |
| 8 | Ministry of Foreign Affairs (MOFA) | Federal foreign-affairs competence | Attestations, treaties, diplomatic services, Apostille | https://www.mofa.gov.ae |
| 9 | Telecommunications and Digital Government Regulatory Authority (TDRA) | Telecommunications/digital laws | Telecoms, domains, digital government | https://tdra.gov.ae |
| 10 | UAE Data Office (UAEDO) | Federal PDPL | Federal personal-data protection | https://ai.gov.ae/uae-data-office |
| 11 | Federal Tax Authority (FTA) | VAT, excise, corporate-tax laws | Federal tax administration | https://tax.gov.ae |
| 12 | Ministry of Health and Prevention (MOHAP) | Health laws | Federal health licensing and public health | https://mohap.gov.ae |
| 13 | Ministry of Climate Change and Environment (MOCCAE) | Environmental laws | Environment, climate, food/agriculture | https://moccae.gov.ae |
| 14 | UAE Cabinet / General Secretariat | Constitution and federal policy | Cabinet decisions, federal policy publication | https://uaecabinet.ae |
| 15 | Dubai Courts | Dubai judicial laws | Dubai civil, criminal, family and enforcement courts | https://www.dc.gov.ae |
| 16 | Abu Dhabi Judicial Department | Abu Dhabi judicial laws | Abu Dhabi courts, prosecution-linked services, notaries | https://www.adjd.gov.ae |
| 17 | Ras Al Khaimah Courts | RAK local judiciary | RAK local court system | https://www.rak.ae |
| 18 | DIFC Courts | Dubai Law No. 12/2004 and amendments | DIFC/common-law civil-commercial disputes | https://www.difccourts.ae |
| 19 | ADGM Courts | ADGM laws/regulations | ADGM common-law courts | https://www.adgm.com/adgm-courts |
| 20 | Dubai International Financial Centre Authority (DIFCA) | DIFC founding laws | DIFC non-financial administration | https://www.difc.ae |
| 21 | Dubai Financial Services Authority (DFSA) | DIFC regulatory law | DIFC financial services | https://www.dfsa.ae |
| 22 | ADGM Financial Services Regulatory Authority (FSRA) | ADGM financial-services regulations | ADGM financial services | https://www.adgm.com/operating-in-adgm/financial-services-regulatory-authority |
| 23 | Dubai Land Department / RERA | Dubai real-estate laws | Dubai land registration, escrow, brokers, rentals via RDC | https://dubailand.gov.ae |
| 24 | Abu Dhabi Real Estate Centre / DMT | Abu Dhabi real-estate laws | Abu Dhabi land and real-estate regulation | https://dmt.gov.ae |
| 25 | Dubai Municipality | Local laws | Planning, building permits, public health, environment | https://www.dm.gov.ae |
| 26 | Abu Dhabi Department of Municipalities and Transport | Local laws | Planning, municipalities, transport | https://dmt.gov.ae |
| 27 | General Civil Aviation Authority (GCAA) | Aviation laws | Civil aviation safety and regulation | https://www.gcaa.gov.ae |
| 28 | Federal Authority for Nuclear Regulation (FANR) | Nuclear law | Nuclear safety and radiation regulation | https://www.fanr.gov.ae |
| 29 | National Media Office / media regulators | Media laws | Media licensing and content regulation | https://nmo.gov.ae |
| 30 | UAE Financial Intelligence Unit (FIU) | AML/CFT laws | STR/SAR receipt and financial intelligence | https://www.uaefiu.gov.ae |

## 5. Legal Procedures

### 5.1 Civil litigation timeline — realistic step-by-step

| Step | Dubai/onshore civil litigation event | Typical duration | Notes |
|---:|---|---:|---|
| 1 | Pre-action review, Arabic translation, POA notarisation/legalisation | 1–4 weeks | Foreign documents need legalisation/Apostille and Arabic legal translation. |
| 2 | File claim electronically / court registry | 1–3 days | Fees paid; case number issued. |
| 3 | Service of process | 1–8 weeks | Can be longer for foreign defendants or evasive service. |
| 4 | First hearing / case management | 3–6 weeks from filing | Court confirms service and defence timetable. |
| 5 | Defence memoranda and rejoinders | 1–3 months | Written pleadings dominate; oral hearings brief. |
| 6 | Expert appointment, if needed | 1–2 months to appoint and deposit | Common in construction, accounting, banking and technical disputes. |
| 7 | Expert meetings/report | 2–6 months | Parties submit documents/objections; expert issues report. |
| 8 | Final submissions | 2–6 weeks | Court closes pleadings. |
| 9 | First-instance judgment | 3–12 months total | Simple cases faster; expert-heavy cases longer. |
| 10 | Appeal | 30-day filing window; 3–6 months duration | Court of Appeal can review fact and law. |
| 11 | Cassation | 30-day filing window; 4–8 months duration | Points of law/procedure; not full factual rehearing. |
| 12 | Execution | 1–12+ months | Depends on assets, attachment, travel bans, bank disclosure, real-estate attachment, share attachment and debtor cooperation. |

### 5.2 Court fees comparison

| Court / forum | Filing fee requested | Cap / minimum | Notes |
|---|---:|---:|---|
| Dubai civil courts | 6% of claim value | Minimum AED 500; common cap AED 40,000 | Expert deposits, execution fees and translation costs are separate. |
| Abu Dhabi courts | 2.5% of claim value + AED 200 registration | Confirm current cap/service schedule | Fee depends on case type and ADJD schedule. |
| DIFC Courts | USD 1,615 filing fee + 3% of claim | Maximum USD 55,000 | SCT has separate lower fee schedule; counterclaims may trigger additional fees. |
| ADGM Courts | Similar common-law court fee model | Case-specific | Verify ADGM Courts schedule before filing. |
| Arbitration | Institutional registration + arbitrator fees | Depends on claim value and rules | DIAC/ICC/LCIA/ADCCAC style fee scales vary. |

### 5.3 Foreign judgment enforcement

Foreign judgments are enforced under the Civil Procedures framework, historically Article 235 and now the corresponding provisions in Federal Decree-Law No. 42 of 2022 and implementing regulations. A foreign judgment is not automatically enforceable. The applicant must obtain a UAE execution order unless a treaty or special regime applies.

| Requirement | Practical meaning |
|---|---|
| No exclusive UAE jurisdiction | UAE courts must not have had exclusive jurisdiction over the dispute. |
| Foreign court competence | The foreign court must have had jurisdiction according to its own law and accepted connecting factors. |
| Proper service / due process | Defendant must have been summoned and represented or validly defaulted. |
| Final and conclusive | Judgment must be final/enforceable in the country of origin. |
| No conflict | Judgment must not conflict with a UAE judgment or public order/morals. |
| Reciprocity / treaty | Reciprocity may be required unless treaty/special regime applies. |
| Translation/legalisation | Certified Arabic translation and legalised/Apostilled documents required. |

**Typical timeline.** A straightforward execution-order application can take 1–3 months at first instance, longer if service, appeal or public-order objections arise. Enforcement against assets then proceeds through the execution court and may take months.

### 5.4 Apostille

The UAE joined the Hague Apostille Convention in 2021, and research instructions state that issuing Apostilles began on 14 January 2025. The Ministry of Foreign Affairs issues Apostilles for eligible UAE public documents. The requested fee is AED 150 per document.

| Apostille item | Detail |
|---|---|
| Convention | Hague Convention Abolishing the Requirement of Legalisation for Foreign Public Documents. |
| UAE status | Joined 2021; issuance beginning 14 January 2025 according to research instructions. |
| Issuing authority | Ministry of Foreign Affairs. |
| Fee requested | AED 150 per document. |
| Effect | Replaces multi-step consular legalisation between Convention states. |
| Still needed | Certified Arabic translation may still be required for UAE court use. |

### 5.5 Notarisation

Notaries in the UAE are often referred to as **kuttab al-adl**. Federal MOJ notaries and local judicial departments/private notaries handle powers of attorney, declarations, corporate documents, acknowledgements, affidavits, settlement instruments and other instruments.

| Document type | Typical notarisation issue | Fee reference requested |
|---|---|---:|
| Power of attorney | Identity, capacity, authority, scope and Arabic/legal translation | AED 50–2,000 depending on type |
| Corporate resolution | Signatory authority, trade licence and constitutional documents | AED 50–2,000 plus value-based fee if applicable |
| Real-estate instrument | Land department requirements and notarised authority | Case-specific |
| Commercial contract | Notarisation if required by law/party | 0.05%–0.25% of contract value for some commercial documents |
| Declaration/undertaking | Personal appearance/remote notary and ID | AED 50–2,000 |
| Foreign document | Apostille/legalisation plus certified Arabic translation | Separate legalisation/translation cost |

## 6. Arbitration

### 6.1 Federal Arbitration Law — Federal Law No. 6 of 2018

| Field | Detail |
|---|---|
| Official title | Federal Law No. 6 of 2018 Concerning Arbitration. |
| Official source | UAE Legislation Portal download [[15]](#ref15). |
| Model | Based substantially on UNCITRAL Model Law concepts. |
| Amendment | Federal Law No. 15 of 2023 amended the 2018 law, effective 29 September 2023 according to commentary [[16]](#ref16). |
| Scope | Arbitration seated in the UAE unless parties agree otherwise and international commercial arbitrations where parties choose UAE law. |
| Replaced | Arbitration chapter of the former Civil Procedures Law. |

### 6.2 All 58 articles — detailed summary table

| Article | Subject | Detailed summary |
|---:|---|---|
| 1 | Definitions | Defines arbitration, arbitration agreement, arbitral tribunal, competent court, claimant, respondent and related terms. |
| 2 | Scope of application | Applies to arbitration conducted in the UAE and international commercial arbitration where parties choose the law. |
| 3 | International arbitration | Identifies when arbitration is international, including different places of business and cross-border performance. |
| 4 | Capacity and arbitrability | Arbitration agreement must be made by a person with legal capacity; matters not capable of settlement cannot be arbitrated. |
| 5 | Arbitration agreement forms | Agreement may be a clause or separate agreement; incorporation by reference can suffice. |
| 6 | Court action and arbitration agreement | Court should decline jurisdiction when valid arbitration agreement invoked timely. |
| 7 | Separability | Arbitration clause is independent of the main contract. |
| 8 | Waiver of right to object | Party continuing without timely objection may waive procedural objections. |
| 9 | Competent court | Identifies court competent to support and supervise arbitration. |
| 10 | Number of arbitrators | Parties may agree; failing agreement default mechanisms apply, usually odd number. |
| 11 | Arbitrator requirements | Arbitrator must be impartial, independent, legally competent and not barred. |
| 12 | Appointment by parties | Parties may appoint arbitrators as agreed. |
| 13 | Court appointment | Competent court appoints where appointment mechanism fails. |
| 14 | Challenge grounds | Challenge for circumstances giving justifiable doubts as to impartiality/independence or lack of agreed qualifications. |
| 15 | Challenge procedure | Party must challenge within prescribed period after awareness of grounds. |
| 16 | Replacement arbitrator | Substitute appointed according to same procedure when mandate terminates. |
| 17 | Tribunal jurisdiction | Tribunal may rule on its own jurisdiction. |
| 18 | Plea as to jurisdiction | Jurisdiction objection must be raised no later than statement of defence unless tribunal permits. |
| 19 | Seat / place of arbitration | Parties may choose seat; tribunal determines if no agreement. |
| 20 | Language | Parties may agree language; tribunal decides if absent. |
| 21 | Interim measures | Tribunal may order interim or precautionary measures, security and preservation. |
| 22 | Court interim measures | Courts may grant interim measures before or during arbitration. |
| 23 | Equal treatment | Parties must be treated equally and given full opportunity to present case. |
| 24 | Procedure | Parties may agree procedure; tribunal conducts as it considers appropriate subject to law. |
| 25 | Statements of claim and defence | Parties submit claims, defences, evidence and relief. |
| 26 | Hearings / documents | Tribunal decides oral hearing or documents-only process subject to party rights. |
| 27 | Default | Tribunal may proceed if party defaults after proper notice. |
| 28 | Evidence | Tribunal may determine admissibility, relevance and weight of evidence. |
| 29 | Expert appointment | Tribunal may appoint experts and require party cooperation. |
| 30 | Court assistance in evidence | Tribunal/party may seek court assistance for evidence. |
| 31 | Confidentiality | Hearings/awards may be confidential subject to enforcement and legal duties. |
| 32 | Applicable law | Tribunal applies law chosen by parties or determined conflicts rules. |
| 33 | Amiable compositeur | Tribunal decides ex aequo et bono only if expressly authorised. |
| 34 | Settlement | Settlement may be recorded as consent award. |
| 35 | Award timing | Award must be issued within agreed/statutory time, subject to extension. |
| 36 | Award form | Written award, signed by arbitrators, with reasons unless waived/permitted. |
| 37 | Majority decision | Award by majority; presiding arbitrator may decide certain procedural issues. |
| 38 | Costs | Tribunal may allocate arbitration costs subject to rules and agreement. |
| 39 | Award notification | Signed award delivered/notified to parties. |
| 40 | Termination | Proceedings terminate by final award, withdrawal, settlement or impossibility. |
| 41 | Correction / interpretation | Party may request correction of clerical errors or interpretation. |
| 42 | Additional award | Tribunal may issue additional award for claims omitted from final award. |
| 43 | Binding force | Award is binding on parties. |
| 44 | Recognition | Award recognised subject to ratification/enforcement procedure. |
| 45 | Enforcement application | Party applies to competent court for recognition/enforcement. |
| 46 | Enforcement decision | Court orders enforcement unless annulment/refusal grounds exist. |
| 47 | Challenge / annulment | Award may be challenged on limited statutory grounds. |
| 48 | Annulment grounds | Incapacity, invalid agreement, lack of notice, excess jurisdiction, tribunal composition/procedure defects, non-arbitrability or public order. |
| 49 | Court power after annulment | Court may set aside award; arbitration agreement may remain unless invalid. |
| 50 | Stay of enforcement | Annulment action does not automatically stay enforcement unless court orders. |
| 51 | Appeal of court decision | Decisions on enforcement/annulment may be appealable as provided. |
| 52 | Finality / binding award | Arbitral award has res judicata effect and is enforceable after court order. |
| 53 | Refusal grounds | Mirrors annulment/public-order and procedural grounds. |
| 54 | Action to set aside | Time-limited challenge procedure; court review is narrow. |
| 55 | Expedited enforcement documents | Applicant submits original/copy award, arbitration agreement, Arabic translation and proof of notification. |
| 56 | Court decision timeframe | Court expected to decide recognition/enforcement within statutory period where documents complete. |
| 57 | Transitional provisions | Applies to ongoing arbitration subject to transitional rules. |
| 58 | Publication / repeal / effectiveness | Repeals inconsistent provisions and sets entry into force. |

### 6.3 DIAC 2022 Rules — key provisions with article numbers

| DIAC 2022 rule area | Article / provision | Practical content |
|---|---|---|
| Commencement | Art. 4 style request for arbitration | Claimant files request with parties, agreement, claim summary and relief. |
| Answer / counterclaim | Art. 5 style answer | Respondent submits answer, jurisdiction objections and counterclaims. |
| Multiple contracts / consolidation | Arts. 8–9 style provisions | Related disputes can be consolidated or joined if criteria met. |
| Tribunal appointment | Arts. 12–13 style provisions | Party nomination and DIAC Court appointment where parties fail. |
| Independence | Art. 14 style disclosure | Arbitrators must disclose conflicts and remain independent/impartial. |
| Seat | Art. 20 style default | DIFC often default seat absent agreement under 2022 Rules, subject to parties’ agreement. |
| Language | Art. 21 style rule | Tribunal determines if parties did not agree. |
| Applicable law | Art. 22 style rule | Tribunal applies law/rules chosen by parties. |
| Emergency arbitrator | Art. 2 / Appendix style mechanism | Urgent interim relief before tribunal formation. |
| Expedited proceedings | Art. 32 style rule | Available for qualifying lower-value/simple disputes. |
| Third-party funding | Disclosure requirement | Party must disclose funding and funder identity where relevant to conflicts. |
| Costs | Schedules and tribunal power | Registration, administrative and arbitrator fees allocated in award. |
| Award scrutiny | DIAC Court review | Draft award reviewed to improve enforceability and formal quality. |
| Time for final award | Rules impose timeframe after file transmission/closure | Extensions possible by DIAC Court. |

### 6.4 Institution comparison — DIAC / ADCCAC / ICC / LCIA

| Institution | UAE relevance | Seat options | Cost model | Typical timeline | Enforceability record |
|---|---|---|---|---|---|
| DIAC | Main Dubai arbitral institution; absorbed DIFC-LCIA caseload after Dubai Law No. 34 of 2021 | Dubai or DIFC commonly; parties choose | Ad valorem fees | 6–18 months depending complexity | Strong UAE enforceability if Federal Arbitration Law requirements met. |
| ADCCAC / arbitrateAD | Abu Dhabi institutional arbitration legacy transitioning to modern Abu Dhabi centre | Abu Dhabi / ADGM / other | Institutional schedule | 6–18 months | UAE-seated awards enforceable under Federal Arbitration Law; ADGM seat under ADGM framework. |
| ICC | Global institution frequently used in UAE construction, energy and M&A | UAE, DIFC, ADGM, Paris, London etc. | Higher administrative/arbitrator costs | 12–24+ months | Strong global NYC enforcement; ICC scrutiny assists quality. |
| LCIA | London-based; DIFC-LCIA abolished for new cases but LCIA clauses still used with London/DIFC/ADGM seats | London, DIFC, ADGM or agreed | Hourly arbitrator fees | 12–24+ months | Strong global record; UAE enforcement depends on seat/award compliance. |

### 6.5 New York Convention enforcement

The UAE acceded to the New York Convention in 2006. UAE courts have generally moved from formalistic refusal toward pro-enforcement practice, especially after the standalone Arbitration Law. Refusals still occur for due process, invalid arbitration agreement, non-arbitrability, public order, improper notice, tribunal composition and Arabic translation/formality defects.

| Enforcement factor | Successful enforcement profile | Refusal risk |
|---|---|---|
| Valid arbitration agreement | Clear written clause signed or incorporated | Unsigned terms, unclear incorporation, capacity defect. |
| Notice | Proof of proper service and opportunity to be heard | Missing notice or inability to present case. |
| Seat and procedure | Procedure complied with seat law and agreed rules | Tribunal composition or procedure not as agreed. |
| Award form | Signed, reasoned, final, authenticated/certified and translated | Missing signatures, uncertain finality, translation defects. |
| Public policy | Commercial money award with lawful subject | Penal, family/status, criminal, real-property or public-order conflict. |
| Non-arbitrability | Commercial/civil disputes | Criminal, some employment/status or mandatory public-law issues. |

**Statistics note.** The delegated task requested successful vs refused enforcement statistics. The research material available to this worker did not contain a reliable official numerical dataset of UAE-wide New York Convention enforcement outcomes. Therefore this file does not invent statistics. For a litigation-grade dataset, compile judgments from Dubai Court of Cassation, Abu Dhabi Court of Cassation, Federal Supreme Court, DIFC Courts, ADGM Courts and published arbitration-yearbook sources by year.

## 7. Official legal-source workflow for future expansion

Because the user requested “deepest research” and “no summarization,” this Markdown file should be treated as a library foundation and not as the endpoint of UAE legal collection. The next layer should download and parse official PDFs for every federal law below, then create sub-appendices with article-by-article text where copyright and source access permit.

| Law / source | Next extraction target |
|---|---|
| UAE Constitution | Full Arabic and official English article text, all 152 articles. |
| Civil Transactions Law 1985 | Article-by-article extraction including obligations, nominate contracts, property and security. |
| New Civil Code 2025 | Full comparison table against 1985 law. |
| Commercial Companies Law 2021 and 2025 amendment | Full LLC, PJSC, governance, merger, conversion, liquidation and penalties chapters. |
| Bankruptcy Law 2023 | Full preventive settlement, restructuring, bankruptcy, trustee and cross-border chapters. |
| Consumer Protection Law 2020 and executive regulation | Full rights, supplier obligations, e-commerce and penalties. |
| Crimes and Penalties Law 2021 | Full offence-by-offence penalty tables. |
| Cybercrime Law 2021 | Full online offences, penalties and investigative powers. |
| AML/CFT Law 2025 | Full compliance obligations, offences, FIU powers and sanctions. |
| PDPL 2021 and Cabinet Decision 33/2023 | Full controller/processor obligations, rights and transfer rules. |
| IP laws | Full trademark, patent/industrial property and copyright provisions. |
| Personal Status Law 2005 and amendments | Full family-law chapter extraction. |
| Civil Procedures Law 2022 | Full jurisdiction, service, evidence, appeal and enforcement provisions. |
| Arbitration Law 2018 and 2023 amendment | Full text with commentary and court cases. |

## References

<p id="ref1" class="ref_item">[1] The Official Platform of the UAE Government — The Constitution <a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/the-constitution-of-the-uae">https://u.ae/en/about-the-uae/the-constitution-of-the-uae</a></p>
<p id="ref2" class="ref_item">[2] UAE Cabinet — The Constitution <a target="_blank" rel="noreferrer" href="https://uaecabinet.ae/en/the-constitution">https://uaecabinet.ae/en/the-constitution</a></p>
<p id="ref3" class="ref_item">[3] UAE Legislation Portal — Constitution <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/constitution">https://uaelegislation.gov.ae/en/constitution</a></p>
<p id="ref4" class="ref_item">[4] Constitute Project — United Arab Emirates 1971 rev. 2004 <a target="_blank" rel="noreferrer" href="https://www.constituteproject.org/constitution/United_Arab_Emirates_2004">https://www.constituteproject.org/constitution/United_Arab_Emirates_2004</a></p>
<p id="ref5" class="ref_item">[5] Federal Supreme Court of the UAE <a target="_blank" rel="noreferrer" href="https://www.sc.gov.ae">https://www.sc.gov.ae</a></p>
<p id="ref6" class="ref_item">[6] Abu Dhabi Judicial Department — Courts <a target="_blank" rel="noreferrer" href="https://www.adjd.gov.ae/en/pages/courtss.aspx">https://www.adjd.gov.ae/en/pages/courtss.aspx</a></p>
<p id="ref7" class="ref_item">[7] UAE Legislation Portal — Federal Law No. 5 of 1985 download <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1025/download">https://uaelegislation.gov.ae/en/legislations/1025/download</a></p>
<p id="ref8" class="ref_item">[8] Lexis Middle East — Federal Law No. 5/1985 <a target="_blank" rel="noreferrer" href="https://www.lexismiddleeast.com/law/UnitedArabEmirates/Law_5_1985/en">https://www.lexismiddleeast.com/law/UnitedArabEmirates/Law_5_1985/en</a></p>
<p id="ref9" class="ref_item">[9] Aceris Law — UAE Civil Code PDF <a target="_blank" rel="noreferrer" href="https://www.acerislaw.com/wp-content/uploads/2024/09/UAE-Civil-Code.pdf">https://www.acerislaw.com/wp-content/uploads/2024/09/UAE-Civil-Code.pdf</a></p>
<p id="ref10" class="ref_item">[10] Mayer Brown — Examining the New UAE Civil Code <a target="_blank" rel="noreferrer" href="https://www.mayerbrown.com/en/insights/publications/2026/06/examining-the-new-uae-civil-code-part-3-contract-negotiation-formation-and-interpretation">https://www.mayerbrown.com/en/insights/publications/2026/06/examining-the-new-uae-civil-code-part-3-contract-negotiation-formation-and-interpretation</a></p>
<p id="ref11" class="ref_item">[11] Ministry of Economy — UAE commercial/company law resources <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae">https://www.moet.gov.ae</a></p>
<p id="ref12" class="ref_item">[12] Dechert — New UAE Bankruptcy Law explained <a target="_blank" rel="noreferrer" href="https://www.dechert.com/knowledge/onpoint/2024/1/reshaping-uae-s-financial-landscape--the-new-bankruptcy-law-expl.html">https://www.dechert.com/knowledge/onpoint/2024/1/reshaping-uae-s-financial-landscape--the-new-bankruptcy-law-expl.html</a></p>
<p id="ref13" class="ref_item">[13] Ministry of Economy — Federal Law No. 15/2020 Consumer Protection PDF <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/documents/20121/0/Law_15_2020_pdf.pdf/b676fd26-275c-3652-e949-8b3663e7bd79?t=1715057123879">https://www.moet.gov.ae/documents/20121/0/Law_15_2020_pdf.pdf/b676fd26-275c-3652-e949-8b3663e7bd79?t=1715057123879</a></p>
<p id="ref14" class="ref_item">[14] UAE Legislation Portal — Federal Law No. 15 of 2020 Consumer Protection download <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1455/download">https://uaelegislation.gov.ae/en/legislations/1455/download</a></p>
<p id="ref15" class="ref_item">[15] UAE Legislation Portal — Federal Law No. 6 of 2018 Arbitration download <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1069/download">https://uaelegislation.gov.ae/en/legislations/1069/download</a></p>
<p id="ref16" class="ref_item">[16] Wolters Kluwer Arbitration Blog — 2023 amendment to UAE Arbitration Law <a target="_blank" rel="noreferrer" href="https://legalblogs.wolterskluwer.com/arbitration-blog/the-amendment-to-the-uaes-2018-arbitration-law-more-than-meets-the-eye/">https://legalblogs.wolterskluwer.com/arbitration-blog/the-amendment-to-the-uaes-2018-arbitration-law-more-than-meets-the-eye/</a></p>

*Informational notice: This document is a legal research library resource and does not constitute legal advice, a legal opinion, or a substitute for checking the Arabic official text, Official Gazette, current court rules, and applicable local/free-zone legislation.*