# UAE Business, Investment and Labor Laws: The Definitive Legal Compendium (2026)

This compendium provides an exhaustive, article-by-article and sector-by-sector analysis of the legal framework governing the United Arab Emirates. It is designed for legal practitioners, investors, and corporate entities operating within the UAE mainland and its numerous free zones.

---

## I. COMPANY LAW — FEDERAL DECREE-LAW NO. 32 OF 2021 & 2025 AMENDMENTS

The **Federal Decree-Law No. 32 of 2021 on Commercial Companies** (the "CCL") is the primary legislation governing the formation, management, and dissolution of commercial entities in the UAE mainland. It was significantly amended by **Federal Decree-Law No. 20 of 2025** (effective 1 January 2026), which introduced modern corporate governance tools and enhanced flexibility for investors.

### 1. ALL CHAPTERS OF FEDERAL DECREE-LAW NO. 32 OF 2021

The CCL is structured into 12 Titles and 365 Articles. Below is the comprehensive list of chapters and their scope:

#### TITLE 1: GENERAL PROVISIONS FOR COMPANIES (Articles 1–38)
- **Chapter 1: Companies (Art. 1–9):** This chapter defines the fundamental terms used throughout the law. "State" refers to the UAE, "Ministry" to the Ministry of Economy, and "Authority" to the Securities and Commodities Authority (SCA). It also introduces the concept of the **Special Purpose Acquisition Company (SPAC)** and the **Special Purpose Vehicle (SPV)**. Article 2 outlines the objectives of the law: contributing to the development of the working environment, protecting shareholder rights, supporting foreign investment, and enhancing corporate social responsibility. Article 3 specifies that the law applies to all commercial companies established in the State and foreign companies with a head office or branch in the UAE.
- **Chapter 2: Incorporation and Management (Art. 10–32):** This chapter covers the essential requirements for forming a company. Article 10 is the landmark provision allowing 100% foreign ownership for most commercial activities, subject to "Strategic Impact" restrictions. It also details the requirements for the Memorandum of Association (MOA), trade name reservation, and the liability of founders and managers. Article 15 allows companies to transfer their registration between Emirates or between the mainland and free zones.
- **Chapter 3: Companies’ Registrar (Art. 33–38):** Establishes the role of the Registrar at the Ministry of Economy. The Registrar is responsible for maintaining the commercial register and issuing certificates of incorporation. Article 38 empowers the Cabinet to determine the fees for registration and other services.

#### TITLE 2: PARTNERSHIPS (Articles 39–70)
- **Chapter 1: Joint Liability Company (Art. 39–61):** A company where two or more physical partners are jointly and severally liable for all obligations. Article 39 defines the company, and Article 40 states that joint partners have the capacity of a trader. The chapter covers formation, management, and dissolution, including the adjudication of bankruptcy for all partners if the company goes bankrupt.
- **Chapter 2: Limited Partnership Company (Art. 62–70):** Consists of joint partners (liable) and silent partners (liable only to the extent of their capital). Silent partners cannot participate in management.

#### TITLE 3: LIMITED LIABILITY COMPANY (LLC) (Articles 71–104)
- **Chapter 1: Incorporation (Art. 71–82):** Defines the LLC as a company with 2 to 50 partners. Article 71 limits partner liability to their share in the capital. Article 76 requires the MOA to include specific details like the company's name, purpose, and capital. Article 82 covers the registration process with the Competent Authority.
- **Chapter 2: Management (Art. 83–91):** Appointment of one or more managers. Article 83 allows managers to be appointed in the MOA or by a separate contract. Article 84 details the manager's powers to represent the company. Article 91 covers the removal of managers by a resolution of the partners or a court order.
- **Chapter 3: General Assembly (Art. 92–104):** Rules for annual and extraordinary meetings. Article 92 requires at least one annual meeting. Article 95 gives each partner one vote per share. Article 104 states that PJSC rules apply to LLCs where consistent with their nature.

#### TITLE 4: PUBLIC JOINT STOCK COMPANIES (PJSC) (Articles 105–256)
- **Chapter 1: Definition and Incorporation (Art. 105–142):** Article 105 defines the PJSC as a company with equal negotiable shares. Founders subscribe to part, and the rest is offered for public subscription. Article 110 covers the prospectus, and Article 121 details the founders' committee's role.
- **Chapter 2: Management (Art. 143–172):** Detailed rules for the Board of Directors. Article 143 requires a board of 3 to 11 members. Article 145 covers director independence. Article 153 prohibits directors from competing with the company.
- **Chapter 3: General Assembly (Art. 173–194):** Procedures for shareholder meetings. Article 173 requires an annual meeting within 4 months of the financial year-end. Article 183 covers quorum requirements (50% for ordinary, 75% for extraordinary).
- **Chapter 4: Capital (Art. 195–207):** Minimum capital is AED 30M. Article 195 covers capital increases through rights issues or bonus shares. Article 202 covers capital reduction.
- **Chapter 5: Shares, Bonds, and Sukuk (Art. 208–236):** Article 208 states that shares are negotiable. Article 229 allows the issuance of bonds and sukuk with shareholder approval.
- **Chapter 6: Finance (Art. 237–244):** Article 237 defines the financial year. Article 239 requires a statutory reserve of 5% of net profit annually until it reaches 50% of capital.
- **Chapter 7: Auditors (Art. 245–256):** Article 245 requires the appointment of external auditors. Article 250 details the auditor's duties to report on the company's financial position.

#### TITLE 5: PRIVATE JOINT STOCK COMPANIES (PrJSC) (Articles 257–267)
- Rules for companies with at least 3 shareholders and AED 5M capital. Article 257 defines the PrJSC. Article 266 allows conversion to a PJSC after two years.

#### TITLE 6: HOLDING COMPANIES AND INVESTMENT FUNDS (Articles 268–274)
- **Chapter 1: Holding Companies (Art. 268–272):** Article 268 defines the holding company's purpose as owning shares in other companies. Article 271 prohibits subsidiaries from owning shares in the holding company.
- **Chapter 2: Investment Funds (Art. 273–274):** Legal framework for local investment funds, subject to SCA regulation.

#### TITLE 7: CONVERSION, MERGER, AND ACQUISITION (Articles 275–301)
- **Chapter 1: Conversion (Art. 275–284):** Article 275 allows changing legal form. Article 284 ensures the continuity of legal personality.
- **Chapter 2: Merger (Art. 285–293):** Article 285 defines merger by consolidation or absorption. Article 293 covers the rights of creditors to object.
- **Chapter 3: Division (Art. 294–298):** Article 294 allows splitting a company into two or more entities.
- **Chapter 4: Acquisition (Art. 299–301):** Rules for taking over existing companies, including mandatory bid rules for listed companies.

#### TITLE 8: TERMINATION AND LIQUIDATION (Articles 302–334)
- **Chapter 1: Reasons for Termination (Art. 302–313):** Article 302 lists reasons like expiry of term, completion of objective, or loss of 50% of capital. Article 308 covers dissolution by court order.
- **Chapter 2: Liquidation (Art. 314–334):** Article 314 requires the appointment of liquidators. Article 329 details the order of priority for distributing assets (employees, government, creditors, partners).

#### TITLE 9: FOREIGN COMPANIES (Articles 335–339)
- Article 335 requires foreign companies to have a local service agent (LSA) for certain activities. Article 339 covers the registration of branches and representative offices.

#### TITLE 10: CONTROL AND INSPECTION (Articles 340–345)
- Article 340 empowers the Ministry and SCA to audit and inspect companies. Article 345 covers the inspector's report.

#### TITLE 11: CRIMES AND PENALTIES (Articles 346–358)
- Article 346 imposes fines for fraud. Article 358 covers administrative penalties for regulatory violations.

#### TITLE 12: TRANSITIONAL AND FINAL PROVISIONS (Articles 359–365)
- Article 359 gives companies one year to adjust their status. Article 365 sets the implementation date as 2 January 2022.

---

### 2. FEDERAL DECREE-LAW NO. 20 OF 2025 AMENDMENTS (EFFECTIVE JAN 2026)

The 2025 amendments introduce several groundbreaking changes:

#### 2.1. Class Shares (Preferred, Redeemable, Non-Voting)
- **Preferred Shares:** Grant holders priority in dividend payments or liquidation proceeds. This is particularly useful for venture capital and private equity investors who want to protect their downside while participating in the upside.
- **Redeemable Shares:** Can be bought back by the company at a pre-determined price or time, providing an exit mechanism for investors and allowing the company to manage its capital structure more effectively.
- **Non-Voting Shares:** Allow investors to participate in profits without management control, suitable for family offices or passive investors who want to provide capital without interfering in the day-to-day operations.
- **Implementation:** Must be explicitly stated in the MOA and approved by the relevant authority. The MOA must specify the rights and restrictions attached to each class of shares.

#### 2.2. Redomiciliation Procedure (Step-by-Step)
1. **Board Approval:** The board must approve a redomiciliation plan detailing the reasons for the move, the new jurisdiction, and the impact on shareholders and creditors.
2. **Shareholder Resolution:** 75% majority vote at an Extraordinary General Assembly. Shareholders must be provided with all relevant information to make an informed decision.
3. **Creditor Protection:** 30-day notice period in two local newspapers; creditors can object in court if they believe their rights are prejudiced. The company must demonstrate that it can meet its obligations after the move.
4. **Authority Clearance:** Obtain a "No Objection Certificate" (NOC) from the current registrar. The registrar will check for any outstanding liabilities or legal issues.
5. **New Registration:** Submit the application to the new registrar (e.g., moving from DIFC to Dubai Mainland). The new registrar will issue a new certificate of incorporation.
6. **Continuity:** The company retains its original legal personality, contracts, and liabilities. This ensures that business operations are not disrupted by the move.

#### 2.3. Dual Licensing (Mainland + Free Zone)
- Companies registered in a free zone can now obtain a mainland license from the local DED without establishing a separate branch. This is a major reform that reduces the administrative burden and costs for companies operating in both jurisdictions.
- **Conditions:** Must maintain a physical office in the free zone and meet mainland regulatory requirements for the specific activity. The company must also comply with the labor and immigration rules of both jurisdictions.

#### 2.4. SPACs (Special Purpose Acquisition Companies)
- **Definition:** A PJSC established solely to acquire or merge with another company. SPACs are a popular way for private companies to go public without the traditional IPO process.
- **Capital:** Must be raised through an IPO. The proceeds are held in a trust account until the acquisition is completed.
- **SCA Oversight:** The Securities and Commodities Authority regulates the trust account and the acquisition timeline (usually 24 months). If no acquisition occurs, the capital is returned to shareholders with interest.

#### 2.5. Virtual Meetings
- All corporate meetings (Board and General Assembly) can be held virtually. This is a response to the global shift towards digital communication and enhances shareholder participation, especially for international investors.
- **Requirements:** Secure authentication, real-time participation, and electronic voting records. The company must ensure that all shareholders have equal access to the virtual meeting platform.

---

### 3. LIMITED LIABILITY COMPANY (LLC) — IN-DEPTH

#### 3.1. Formation Steps and Timeline
- **Step 1: Trade Name Reservation:** (1 day) AED 600–1,000. The name must not be misleading or violate public order. It must also not be already in use by another company.
- **Step 2: Initial Approval:** (1 day) AED 120. Confirms the activity and partners are eligible. This is a preliminary check by the DED.
- **Step 3: MOA Drafting & Notarization:** (2 days) Must be in Arabic (or bilingual). Notary fees: ~AED 1,500–3,000. The MOA is the company's constitution and must be signed by all partners in the presence of a notary.
- **Step 4: Office Lease (Ejari):** (1-2 days) Mandatory physical space. The lease must be registered with the local municipality (e.g., Dubai Land Department). The office must meet the minimum size requirements for the licensed activity.
- **Step 5: Final License:** (1 day) Fees vary by activity (AED 10k–50k). Includes membership in the Chamber of Commerce and registration with the Ministry of Labor and Immigration.
**Total Timeline:** 5–10 working days.

#### 3.2. Manager vs. Director Distinction
- **Manager:** The statutory representative. Can be a partner or a third party. Powers are defined in the MOA. Managers have broad authority to bind the company in its dealings with third parties. They are responsible for the day-to-day management of the company.
- **Director:** Usually part of a Board of Directors (optional for LLCs). Directors oversee the manager and set strategic direction. They are responsible for the long-term success of the company and ensuring compliance with the law.
- **Liability:** Managers are liable for any breach of the law, MOA, or mismanagement. They can be held personally liable for company debts in cases of fraud, abuse of power, or gross negligence.

#### 3.3. Shareholder Resolutions
- **Ordinary Resolution (51%):** Approving accounts, appointing auditors, distributing profits, and appointing/removing managers. These resolutions are passed by a simple majority of the shares represented at the meeting.
- **Special Resolution (75%):** Amending MOA, changing capital, merging, or dissolving. Requires notarization and publication in the commercial register. These resolutions require a higher threshold to protect the interests of minority shareholders.

#### 3.4. Profit Distribution and Dissolution
- **Legal Reserve:** 5% of net profit annually until it reaches 50% of capital. This reserve is intended to protect creditors and cannot be distributed to partners as dividends.
- **Dissolution:** If losses reach 50% of capital, the manager must call a general assembly to decide on continuation or dissolution. If they fail to do so, they may be personally liable for the company's debts. Dissolution can also occur upon the expiry of the company's term or the completion of its objective.

---

### 4. PUBLIC JOINT STOCK COMPANY (PJSC) — IN-DEPTH

#### 4.1. Prospectus Requirements
- Must include: Company history, founders' details, use of proceeds, risk factors, 3-year audited financials, and dividend policy. The prospectus must be approved by the SCA and published in two local newspapers. It is the primary document for investors to evaluate the company.

#### 4.2. IPO Process and SCA Approval
- **Minimum Capital:** AED 30,000,000. This ensures that the company has sufficient capital to operate as a public entity.
- **Founders' Share:** Founders must subscribe to 30%–70% of the capital. This ensures that the founders have a significant stake in the company's success.
- **SCA Timeline:** Approval usually takes 30–60 days. The offering period is typically 10–30 days. The company must also be listed on a local stock exchange (e.g., DFM or ADX).

#### 4.3. Board Composition
- **Independent Directors:** At least 1/3 of the board. Independence is defined by the absence of material relationships with the company, its management, or its major shareholders.
- **Committees:** Audit Committee and Nomination & Remuneration Committee are mandatory. They must consist of non-executive directors, with a majority being independent. They play a crucial role in corporate governance.

---

### 5. BRANCH VS. SUBSIDIARY

| Feature | Branch | Subsidiary (LLC) |
|---|---|---|
| **Legal Entity** | Same as Parent | Separate |
| **Liability** | Parent is 100% liable | Limited to capital |
| **Local Service Agent** | Required for some (AED 10k/yr) | Not required |
| **Audit** | Mandatory | Mandatory |
| **Activities** | Limited to Parent's activities | Any licensed activity |

---

### 6. CIVIL COMPANIES FOR PROFESSIONALS
- **Activities:** Engineering, Law, Medicine, Accounting. These companies are formed by professionals to practice their respective fields.
- **Ownership:** 100% foreign ownership allowed, but a Local Service Agent (LSA) is required. The LSA is a UAE national who provides administrative services but has no ownership or management role.
- **Liability:** Partners have unlimited liability for professional errors. This means their personal assets can be used to satisfy claims against the company.

---

### 7. COMMERCIAL AGENCIES — FEDERAL DECREE-LAW NO. 3 OF 2022

#### 7.1. Agent Exclusivity and Protection
- The agent has the exclusive right to sell the products in the agreed territory. The principal cannot appoint another agent or sell directly in that territory. This provides the agent with a protected market to invest in brand development.
- **Registration:** Must be registered at the Ministry of Economy to receive legal protection. Unregistered agencies are governed by the Civil Transactions Law and do not benefit from the exclusivity and termination protections of the Commercial Agencies Law.

#### 7.2. Termination Compensation Formula
- **Article 28:** If the principal terminates without a "material reason," the agent is entitled to compensation. A material reason is typically a serious breach of contract by the agent.
- **Formula:** Based on (1) the agent's investment in marketing/infrastructure; (2) the principal's future benefit from the agent's work; and (3) the duration of the agency.
- **Standard Practice:** Courts often award 1–2 years of average net profit. The agent can also claim for the "fair value" of assets like stock, showrooms, and spare parts. The compensation is intended to reward the agent for their efforts in building the principal's brand in the UAE.

---

## II. FREE ZONES — EVERY MAJOR ZONE IN DETAIL

### 1. JAFZA — JEBEL ALI (DUBAI)
- **Legal Basis:** Dubai Law No. 1 of 1985.
- **Regulator:** Jafza Authority.
- **Entity Types:** FZE, FZCO, Branch.
- **Min Capital:** AED 500,000 (FZCO).
- **Setup Costs:** AED 20,000–30,000.
- **Renewal Fees:** AED 15,000–20,000.
- **Visa Allocation:** 1 visa per 10 sqm.
- **Permitted Activities:** Logistics, Trading, Manufacturing.
- **Special Features:** Largest logistics hub in the region; linked to DP World and Al Maktoum Airport. Offers a wide range of warehouses and industrial land.
- **URL:** [jafza.ae](https://www.jafza.ae)

### 2. DIFC — DUBAI INTERNATIONAL FINANCIAL CENTRE
- **Legal Basis:** Dubai Law No. 9 of 2004.
- **Regulator:** DFSA / DIFC Authority.
- **Entity Types:** Ltd, LP, LLP, Foundation.
- **Min Capital:** USD 50,000 (for most).
- **Setup Costs:** USD 15,000–25,000.
- **Renewal Fees:** USD 10,000–15,000.
- **Visa Allocation:** Based on office size.
- **Permitted Activities:** Banking, Finance, Legal, Fintech.
- **Special Features:** Common Law jurisdiction; independent courts; Employee Workplace Savings Plan (EWSP). A global hub for financial services.
- **URL:** [difc.ae](https://www.difc.ae)

### 3. ADGM — ABU DHABI GLOBAL MARKET
- **Legal Basis:** Federal Decree No. 15 of 2013.
- **Regulator:** FSRA / Registration Authority.
- **Entity Types:** Private Ltd, Public Ltd, Cell Company.
- **Min Capital:** USD 0.
- **Setup Costs:** USD 10,000–15,000.
- **Renewal Fees:** USD 8,000–12,000.
- **Visa Allocation:** Flexible.
- **Permitted Activities:** Finance, Family Offices, Tech.
- **Special Features:** English Common Law; digital-first registration; SPV hub. Offers a sophisticated regulatory environment for investment funds.
- **URL:** [adgm.com](https://www.adgm.com)

### 4. DMCC — DUBAI MULTI COMMODITIES CENTRE
- **Legal Basis:** Dubai Law No. 9 of 2021.
- **Regulator:** DMCC Authority.
- **Entity Types:** DMCC Company, Branch.
- **Min Capital:** AED 50,000.
- **Setup Costs:** AED 15,000–20,000.
- **Renewal Fees:** AED 12,000–15,000.
- **Visa Allocation:** 1 visa per 9 sqm.
- **Permitted Activities:** Commodities, Trading, Crypto.
- **Special Features:** World's #1 Free Zone; Crypto Centre; Commodities trading hub for gold, diamonds, and tea.
- **URL:** [dmcc.ae](https://www.dmcc.ae)

### 5. DAFZA — DUBAI AIRPORT FREE ZONE
- **Legal Basis:** Dubai Law No. 4 of 2009.
- **Regulator:** DAFZA Authority.
- **Min Capital:** AED 1,000.
- **Setup Costs:** AED 15,000–25,000.
- **URL:** [dafz.ae](https://www.dafz.ae)

### 6. DUBAI SILICON OASIS (DSO)
- **Legal Basis:** Dubai Law No. 16 of 2005.
- **Regulator:** DIEZ.
- **Min Capital:** AED 0.
- **Setup Costs:** AED 12,000–18,000.
- **URL:** [dsoa.ae](https://www.dsoa.ae)

### 7. TECOM (INTERNET CITY / MEDIA CITY)
- **Legal Basis:** Dubai Law No. 1 of 2000.
- **Regulator:** DDA.
- **Min Capital:** AED 50,000.
- **Setup Costs:** AED 15,000–25,000.
- **URL:** [tecomgroup.ae](https://www.tecomgroup.ae)

### 8. DUBAI HEALTHCARE CITY (DHCC)
- **Legal Basis:** Dubai Law No. 26 of 2014.
- **Regulator:** DHCC Authority.
- **Min Capital:** AED 50,000.
- **Setup Costs:** AED 20,000–30,000.
- **URL:** [dhcc.ae](https://www.dhcc.ae)

### 9. DUBAI DESIGN DISTRICT (D3)
- **Regulator:** DDA.
- **Min Capital:** AED 50,000.
- **Setup Costs:** AED 15,000–25,000.
- **URL:** [dubaidesigndistrict.com](https://www.dubaidesigndistrict.com)

### 10. KIZAD / KEZAD (ABU DHABI)
- **Legal Basis:** Abu Dhabi Law No. 3 of 2010.
- **Regulator:** AD Ports.
- **Min Capital:** AED 150,000.
- **Setup Costs:** AED 10,000–20,000.
- **URL:** [kezad.ae](https://www.kezad.ae)

### 11. MASDAR CITY FREE ZONE
- **Regulator:** Masdar City Authority.
- **Min Capital:** AED 0.
- **Setup Costs:** AED 10,000–15,000.
- **URL:** [masdarcity.ae](https://www.masdarcity.ae)

### 12. RAKEZ (RAS AL KHAIMAH)
- **Legal Basis:** RAK Law No. 3 of 2009.
- **Regulator:** RAKEZ Authority.
- **Min Capital:** AED 0.
- **Setup Costs:** AED 5,000–12,000.
- **URL:** [rakez.com](https://www.rakez.com)

### 13. SAIF ZONE (SHARJAH)
- **Legal Basis:** Sharjah Amiri Decree 2 of 1995.
- **Min Capital:** AED 150,000.
- **Setup Costs:** AED 6,000–12,000.
- **URL:** [saif-zone.com](https://www.saif-zone.com)

### 14. SHAMS (SHARJAH MEDIA CITY)
- **Legal Basis:** Sharjah Decree 1 of 2017.
- **Min Capital:** AED 0.
- **Setup Costs:** AED 5,000–10,000.
- **URL:** [shams.ae](https://www.shams.ae)

### 15. HAMRIYAH FREE ZONE (SHARJAH)
- **Min Capital:** AED 150,000.
- **Setup Costs:** AED 5,000–9,000.
- **URL:** [hfza.ae](https://www.hfza.ae)

### 16. AJMAN FREE ZONE (AFZ)
- **Min Capital:** AED 185,000.
- **Setup Costs:** AED 6,000–12,000.
- **URL:** [afz.ae](https://www.afz.ae)

### 17. FUJAIRAH CREATIVE CITY / UAQ FTZ
- **Creative City:** [creativecity.ae](https://www.creativecity.ae)
- **UAQ FTZ:** [uaqftz.com](https://www.uaqftz.com)

---

## III. LABOR LAW — ALL ARTICLES

### 1. FEDERAL DECREE-LAW NO. 33 OF 2021: COMPLETE ARTICLE TABLE

| Article | Topic | Key Provision |
|---|---|---|
| **1** | Definitions | Defines Employer, Worker, Juvenile, Private Sector, etc. |
| **2** | Objectives | Aims to balance rights, enhance competitiveness, and attract talent. |
| **3** | Scope | Applies to all private sector; excludes domestic workers and government. |
| **4** | Equality | Prohibits discrimination (race, color, sex, religion, origin). Equal pay for women. |
| **5** | Juveniles | Min age 15; max 6 hours/day; no night shifts or hazardous work. |
| **6** | Recruitment | Employer bears all recruitment costs; no fees from workers. |
| **7** | Work Patterns | Full-time, Part-time, Temporary, Flexible, Remote. |
| **8** | Contract | Fixed-term only (max 3 years, renewable). |
| **9** | Probation | Max 6 months; 14 days notice for termination by employer. |
| **10** | Non-compete | Max 2 years; specific geography/business; legitimate interest. |
| **11** | Outsourcing | Rules for secondment and outsourcing between employers. |
| **12** | Job Change | Worker cannot be forced to do different work without consent (except emergency). |
| **13** | Employer Obligations | Provide safety, health insurance, repatriation, and end-of-service pay. |
| **14** | Forced Labor | Prohibits forced labor, harassment, and bullying. |
| **15** | Death | Wages and gratuity paid to family within 10 days of death. |
| **16** | Worker Obligations | Perform duties, maintain secrets, follow safety rules. |
| **17** | Working Hours | Max 8 hours/day (48/week). Reduced by 2 hours in Ramadan. |
| **18** | Breaks | Max 5 consecutive hours; break min 1 hour. |
| **19** | Overtime | Max 2 hours/day; pay +25% (standard) or +50% (9pm-4am). |
| **20** | Exclusions | Managers/supervisors may be excluded from overtime rules. |
| **21** | Weekend | Min 1 day per week; Friday/Saturday/Sunday as per contract. |
| **22** | Wages | Paid in AED (or other if agreed); via WPS. |
| **23** | Piecework | Calculation based on average output. |
| **24** | Wage Category | Rules for moving from monthly to daily/weekly wage. |
| **25** | Deductions | Max 50% of wage for debts/damages/advances. |
| **26** | Enabling Work | Employer must provide tools/environment for work. |
| **27** | Min Wage | Cabinet to determine (currently no federal min wage for expats). |
| **28** | Public Holidays | Full pay for official holidays. |
| **29** | Annual Leave | 30 days (after 1 year); 2 days/month (6-12 months). |
| **30** | Maternity | 60 days (45 full pay, 15 half pay). Additional 45 days unpaid for illness. |
| **31** | Sick Leave | 90 days/year (15 full, 30 half, 45 unpaid). |
| **32** | Other Leaves | Bereavement (3-5 days), Paternity (5 days), Study (10 days). |
| **33** | Unpaid Leave | Allowed with employer consent. |
| **34** | Absence | Termination allowed if absence > 20 intermittent or 7 consecutive days. |
| **35** | Notice in Leave | Notice period starts after leave ends (unless agreed). |
| **36** | Safety | Employer must provide PPE and safety training. |
| **37** | Work Injury | Employer pays medical costs and salary during treatment. |
| **38** | Non-entitlement | No compensation if injury is self-inflicted or due to intoxication. |
| **39** | Sanctions | Warning, fine (max 5 days), suspension (max 10 days), dismissal. |
| **40** | Suspension | Temporary suspension for investigation (half pay). |
| **41** | Sanction Rules | One sanction per violation; must be within 30 days of discovery. |
| **42** | Termination | Expiry, mutual, notice, death, disability, bankruptcy. |
| **43** | Notice Period | 30 to 90 days. Compensation for shorter notice. |
| **44** | Summary Dismissal | Exhaustive list (10 grounds): fake docs, breach of safety, intoxication, etc. |
| **45** | Quitting | Worker can quit without notice if employer breaches contract or assaults. |
| **46** | Health Fitness | Termination allowed if worker is medically unfit (after sick leave). |
| **47** | Arbitrary Dismissal | Max 3 months basic salary if termination is due to worker's complaint. |
| **48** | Continuity | Contract continues despite change in ownership. |
| **49** | Transfer | Worker can move to new employer after contract ends. |
| **50** | Unlawful Absence | Absconding rules; ban on work for 1 year. |
| **51** | Gratuity | 21 days/year (first 5 years); 30 days/year (after 5 years). Max 2 years pay. |
| **52** | Other Patterns | Gratuity for part-time/flexible work as per regulations. |
| **53** | Final Pay | All entitlements paid within 14 days of termination. |
| **54** | Disputes | MOHRE mediation; binding for claims ≤ AED 50,000. |
| **55** | Fees | Workers exempt from court fees for claims ≤ AED 100,000. |
| **56** | Collective Dispute | Rules for strikes and collective bargaining. |
| **57** | Inspection | MOHRE inspectors have right of entry and record review. |
| **58-64** | Penalties | Fines AED 5k to 1M for various violations (fake Emiratisation, illegal hiring). |
| **65** | Final Provisions | Implementation by MOHRE. |
| **66** | Language | Arabic is the official language for contracts and records. |
| **67** | Dates | Gregorian calendar used for all calculations. |

### 2. IMPLEMENTING REGULATIONS (CABINET RESOLUTION NO. 1 OF 2022)
- **Job Classifications:** 9 levels based on ISCO.
- **Remote Work:** Must be documented; employer provides tools.
- **Overtime:** `(Basic / 30 / 8) * 1.25` (standard) or `* 1.5` (night/holiday).

### 3. MINISTERIAL RESOLUTIONS (2022–2026)
- **MR No. 44 of 2022:** Defines freelance as an independent relationship without a specific employer.
- **MR No. 47 of 2022:** Detailed rules for part-time (pro-rated leave/gratuity) and flexible work.
- **MR No. 340 of 2026:** WPS update—wages due by 1st of month; 85% threshold for compliance.

### 4. WAGE PROTECTION SYSTEM (WPS)
- **Employers Covered:** All private sector (mainland).
- **Frequency:** Monthly.
- **Breach Consequences:** Suspension of work permits; fines; eDNOD (Do-Not-Do) list.

### 5. DIFC & ADGM EMPLOYMENT LAWS
- **DIFC Law No. 4 of 2005:** No WPS; **DEWS** (Employee Workplace Savings) replaces gratuity.
- **ADGM Regulations 2019:** Employment Tribunal for disputes.

### 6. DOMESTIC WORKERS (FEDERAL LAW NO. 10 OF 2017)
- **Rights:** 30 days leave; 12 hours rest; 1 day off/week.
- **Contract:** Standard MOHRE template.

### 7. WORK INJURIES (ARTICLES 59–65)
- **Compensation Table:**
  - **Death/Total Disability:** 24 months basic salary (AED 18k–200k).
  - **Partial Disability:** `% of 24 months pay` based on medical board assessment.

### 8. UNFAIR DISMISSAL
- UAE has no "unfair dismissal" per se. Termination must be for Article 44 grounds or with notice.
- **Arbitrary Dismissal (Art 47):** Max 3 months basic salary if termination is due to a complaint filed by the worker.

### 9. NON-COMPETE ENFORCEABILITY
- Upheld if: (1) Max 2 years; (2) Specific geography; (3) Specific business; (4) Legitimate interest.

---

## IV. EMIRATISATION — COMPLETE

### 1. FEDERAL LAW NO. 38 OF 2022
- **Target:** 10% Emiratisation by end of 2026 for companies with 50+ employees.
- **Small Companies (20-49):** Must hire 1 Emirati in 2024 and 2 in 2025 in 14 specific sectors.

### 2. NAFIS INCENTIVE SCHEME (2026)
- **Salary Support:** Up to AED 7,000/month.
- **Pension:** Government pays employer's share for 5 years.
- **Child Allowance:** AED 800–1,000 per child.

### 3. SECTOR QUOTAS 2026
| Industry | 2026 Target |
|---|---|
| Financial & Insurance | 10% |
| Information & Communication | 10% |
| Real Estate | 10% |
| Professional & Technical | 10% |
| Healthcare | 10% |

### 4. PENALTIES (2026)
- **AED 10,000 per month** per unfilled position.
- **Fake Emiratisation:** Fines up to AED 1,000,000.

---

## VI. TAXATION — ALL DETAILS

### 1. CORPORATE TAX (FEDERAL DECREE-LAW NO. 47 OF 2022)
- **Rate:** 9% on income > AED 375k.
- **QFZP Conditions:** Substance in free zone; qualifying income; de minimis rule (≤ 5% or AED 5M).
- **Pillar Two (DMTT):** 15% for MNEs > EUR 750M.

### 2. VAT (FEDERAL DECREE-LAW NO. 8 OF 2017)
- **Rate:** 5%.
- **Registration:** Mandatory if turnover > AED 375k.

### 3. ECONOMIC SUBSTANCE REGULATIONS (ESR)
- Applies to 9 activities: Banking, Insurance, Fund Management, Lease-Finance, HQ, Shipping, Holding, IP, Distribution & Service Centre.

---

## VII. INTELLECTUAL PROPERTY — ALL DETAILS

### 1. TRADEMARK (LAW NO. 36 OF 2021)
- **Procedure:** Application → Examination → Publication (30 days) → Registration.
- **Timeline:** 3–6 months.
- **Nice Classification:** 45 classes; multi-class allowed.

### 2. PATENT (LAW NO. 11 OF 2021)
- **Protection:** 20 years.

### 3. COPYRIGHT (LAW NO. 38 OF 2021)
- **Protection:** Life + 50 years.

---
**Official Portals:**
- [mohre.gov.ae](https://www.mohre.gov.ae)
- [economy.gov.ae](https://www.economy.gov.ae)
- [icp.gov.ae](https://www.icp.gov.ae)
- [tax.gov.ae](https://www.tax.gov.ae)
- [nafis.ae](https://www.nafis.ae)

---

---

## VIII. DEEP EXPANSION: OFFICIAL-SOURCE BUSINESS, INVESTMENT, LABOUR, TAX AND COMPLIANCE DETAIL

**Expansion note.** This section preserves the earlier compendium and adds deeper official-source detail. Where a rule is based on an official source that was successfully retrieved or identified in the research materials, it is cited with a clickable marker. Where a sub-point is operational practice rather than directly verified in an official source during this expansion, it is labelled as a practical checklist item rather than a statutory quotation. This file is not legal advice.

### A. Company Law and Mainland Corporate Formation — Deep Operating Map

The UAE mainland company-law analysis begins with the Commercial Companies Law framework. The official UAE legislation source identifies Federal Decree-Law No. 32 of 2021 as the baseline commercial-companies statute, and the existing research file records the 2025 amendment package as a major update effective from January 2026. [[1]](#ref1) The most important practical point for investors is that company-law analysis should be separated from licensing analysis: incorporation creates the legal person, but the economic activity, premises, sector regulator approvals, immigration file, labour file, tax registrations and bank onboarding determine whether the business can actually trade.

|Issue|Detailed rule / source-grounded position|Practical consequence|
|---|---|---|
|Commercial Companies Law baseline|Federal Decree-Law No. 32 of 2021 remains the mainland commercial-company statute for commercial companies, foreign branches, governance, restructuring, penalties and final provisions.|Use as primary reference for entity selection, MOA drafting, shareholder authorities, statutory registers, governance approvals and liquidation planning [[1]](#ref1)|
|Scope|Applies to commercial companies established in the UAE and to foreign companies that have headquarters, branches or offices in the State, except where another special regime applies.|Determine whether the company is mainland, free-zone, financial-free-zone or special-regime before applying default CCL rules [[1]](#ref1)|
|Foreign ownership|The research file and current UAE business practice identify Article 10 as the decisive post-2021 rule allowing up to 100% foreign ownership for most mainland activities, subject to strategic-impact restrictions and Emirate-level activity rules.|Do not assume an Emirati shareholder is required for ordinary commercial LLC activities; verify the specific activity with the competent Emirate licensing authority [[1]](#ref1)|
|Company forms|Recognised forms include joint liability companies, limited partnerships, LLCs, public joint stock companies, private joint stock companies, holding companies, investment funds, foreign-company branches and other statutory forms.|Choose form by liability, number of shareholders, funding plan, capital market needs, activity restrictions and regulatory approvals [[1]](#ref1)|
|LLC governance|LLC provisions regulate incorporation, managers, partner assemblies, reserves, profit distribution, manager liability, amendment and dissolution mechanics.|MOA should expressly allocate reserved matters, signing powers, manager appointment/removal, quorum, deadlock and transfer restrictions [[1]](#ref1)|
|PJSC governance|PJSC provisions regulate prospectus, SCA approval, board composition, shareholder assemblies, shares, bonds, sukuk, auditors, reserves, related governance and disclosure.|Listed and public-offer transactions require SCA and market-specific rules beyond ordinary company licensing [[1]](#ref1)|
|Foreign company branch|Foreign branches generally conduct activities of the parent and do not create a separate liability shield equivalent to an LLC subsidiary.|Use for parent-backed operations; avoid if liability ring-fencing or shareholder-level local governance is required [[1]](#ref1)|
|Mergers, conversions and divisions|The CCL contains a full restructuring title covering conversion, merger, division, acquisition, creditor protection and continuity of legal personality.|Include creditor notices, authority approvals, tax analysis, employee transfer treatment and licence migration in transaction timetables [[1]](#ref1)|
|Termination and liquidation|The law sets termination triggers, appointment and authority of liquidators, creditor handling and final deregistration consequences.|Plan for employee final settlement, tax deregistration, ESR/UBO record retention and bank-account closure before licence cancellation [[1]](#ref1)|

#### Mainland licensing workflow checklist

|Step|Raw operational requirement|Risk control / due diligence note|
|---|---|---|
|Activity mapping|Identify the exact activity wording on the relevant Emirate or free-zone activity list.|Different activity labels can trigger different regulator NOCs, office requirements, capital expectations and ownership restrictions.|
|Trade name|Reserve a compliant trade name before final licence issuance.|Avoid restricted words, public-order conflicts, names implying regulated status and names requiring special approval.|
|Initial approval|Obtain preliminary approval that shareholders, managers and activities are acceptable.|Not a licence to trade; it confirms eligibility before lease, MOA and final payment.|
|Constitutional document|Prepare MOA/AOA or free-zone articles.|Include capital, ownership, activity, manager powers, transfer restrictions, reserved matters, profit sharing and dispute clauses.|
|Premises evidence|Submit lease, flexi-desk, establishment card, Ejari or authority-specific evidence.|Mainland and regulated activities often require physical premises; virtual packages may not support all visas or activities.|
|External approvals|Obtain approvals from sector regulators where applicable.|Examples include Central Bank, SCA, TDRA, health authorities, education regulators, municipality, civil defence and transport authorities.|
|Licence issuance|Pay fees and receive licence/certificate.|Do not sign contracts beyond pre-incorporation authority unless founders accept personal liability or ratification mechanisms are in place.|
|Post-licence files|Open immigration, labour, customs, tax and bank files as applicable.|Operational readiness requires more than a trade licence: establishment card, WPS setup, tax registration and UBO filings may be required.|
|Renewal and amendments|Renew annually or per authority cycle; record any change in shareholders, managers, name, activity or address.|Late renewal may freeze visas, bank processes, customs access and government transactions.|

#### 2025 Companies Law amendment package — treatment in this file

- **Class shares:** The existing research materials identify statutory recognition of different share classes as a 2025/2026 reform. Until each registrar publishes final forms and filing requirements, transaction documents should expressly state voting rights, dividend priority, liquidation preference, conversion rights, redemption mechanics and transfer limits. Treat every class-right variation as requiring authority acceptance and amendment of constitutional documents. [[1]](#ref1)
- **Redomiciliation:** Research materials identify redomiciliation as a formal mechanism for moving a company between UAE jurisdictions. Practical implementation should include board approval, shareholder approval, creditor-protection notices where applicable, tax clearance analysis, employee transfer plan, bank consents, licence replacement, immigration/labour file migration and continuity language for contracts. [[1]](#ref1)
- **Dual licensing:** Research materials identify dual licensing as a reform for free-zone companies seeking mainland operating authority. Do not treat it as a blanket permission to trade onshore: the relevant mainland activity, free-zone activity, office location, tax treatment and labour file must all align. [[1]](#ref1)
- **Virtual meetings and digital governance:** Research materials identify virtual meetings as a reform. Companies should adopt written rules for notice, authentication, quorum, e-voting, minutes, recording retention, proxy verification and cybersecurity. [[1]](#ref1)
- **SPAC/SPV and investment vehicles:** The existing file identifies SPACs and SPVs in the CCL vocabulary. Any capital-market vehicle requires SCA/market review and cannot be treated as an ordinary LLC formation. [[1]](#ref1)
- **Non-profit corporate forms:** Research materials identify a dedicated non-profit company concept in the amendment package. Until registrar guidance is checked, treat purpose restrictions, profit-distribution restrictions, reporting duties and donor/funding controls as high-risk drafting points. [[1]](#ref1)

#### Entity-selection matrix for investors

|Use case|Likely structure|Why|Cautions|
|---|---|---|---|
|Small services or trading business on mainland|LLC or single-shareholder LLC|Limited liability, familiar bank onboarding, broad commercial use|Check activity restrictions, professional licensing, office/Ejari, manager authority and tax registration.|
|Parent company wants representative presence|Branch or representative office|No separate shareholders; parent-backed operations|Parent liability remains; activities may be limited; some branches may need local service agent or special approval.|
|VC-backed or multi-investor growth company|LLC with detailed MOA or PrJSC|Can encode reserved matters, transfer rights and governance|If issuing preferred economics, verify 2025 class-share filing practice and registrar acceptance.|
|Public fundraising / listing|PJSC|Public offer and listing architecture|Requires SCA/market approvals, prospectus and public-company governance.|
|Fund, fintech, financial services|DIFC or ADGM regulated entity, fund vehicle or SPV|Financial-free-zone framework and independent courts|Licensing timeline, capital, compliance officer, MLRO and regulator approvals can be significant.|
|Industrial/logistics/export business|JAFZA, KEZAD, Hamriyah or similar free zone|Customs/logistics infrastructure and industrial premises|Mainland sales may require importer/distributor, customs duty and VAT/CT review.|
|Holding, asset isolation or family-office asset vehicle|ADGM/DIFC/SPV/free-zone holding company|Governance and asset ring-fencing|Substance, tax residence, UBO, bank onboarding and foreign asset jurisdiction rules remain critical.|

### B. Free Zones, Mainland Access and Financial Free Zones

Free zones provide separate licensing environments and typically allow 100% foreign ownership. They do not automatically override UAE federal laws on tax, AML/CFT, UBO, immigration or labour unless the relevant law or special free-zone statute says so. For Corporate Tax, FTA guidance treats a Free Zone Person as a juridical person incorporated, established or otherwise registered in a free zone, including relevant free-zone authorities and government-controlled entities established in a free zone. [[5]](#ref5)

|Free zone / group|Detailed profile|Due diligence focus|
|---|---|---|
|DIFC|Dubai financial free zone; independent common-law style legal system, DFSA regulator for financial services, DIFC Courts, DIFC Employment Law framework and DEWS workplace savings.|Use for banking, asset management, fintech, insurance, legal/professional services and regional HQ where DIFC status is commercially valuable [[17]](#ref17) [[18]](#ref18)|
|ADGM|Abu Dhabi financial free zone; FSRA for financial services; Registration Authority; common-law legal architecture and ADGM Courts.|Use for funds, SPVs, family offices, financial services and holding structures needing Abu Dhabi/GCC positioning [[16]](#ref16) [[19]](#ref19)|
|DMCC|Dubai commodities and multi-sector free zone; widely used for trading, commodities, crypto/web3-related ecosystem and professional services.|Check permitted activity wording, office package and visa quota before assuming eligibility.|
|JAFZA|Jebel Ali logistics, industrial and trading zone linked to port and broader DP World ecosystem.|Use for import/export, warehousing, regional distribution and manufacturing operations needing customs/logistics infrastructure.|
|DAFZA|Airport-adjacent Dubai free zone for trading, aviation-adjacent, logistics and services.|Use where proximity to Dubai airport and premium facilities justify cost.|
|DIEZ/DSO/DDA clusters|Specialised Dubai clusters for technology, media, design, internet and related services.|Select by client location, activity list, visa package, office need and regulator NOCs.|
|KEZAD|Abu Dhabi industrial/logistics/manufacturing platform under AD Ports ecosystem.|Use for industrial land, logistics, manufacturing and port-linked distribution.|
|RAKEZ/SAIF/Hamriyah/Ajman/UAQ/Fujairah/Shams|Northern Emirates and Sharjah/Ajman/RAK free zones serving SMEs, trading, media, consultancy and industrial users.|Often cost-effective; confirm bankability, customs needs, visa quotas and mainland trading limitations.|

#### Free-zone transaction limitations and mainland-facing risks

- A free-zone licence is not the same as a mainland trade licence. If the company sells goods or services onshore, check whether it needs a mainland branch, dual licence, distributor, importer of record, e-commerce permission or professional permit.
- Corporate Tax free-zone treatment is not automatic. The FTA bulletin says the Free Zone Person must satisfy QFZP conditions, including substance, qualifying income, arm’s-length/transfer-pricing requirements, audited financial statements and de minimis requirements. [[5]](#ref5)
- Customs treatment differs from VAT and Corporate Tax treatment. Goods entering the mainland from a free zone may trigger customs and VAT consequences even if the company remains licensed in the free zone.
- Regulated financial activities in DIFC/ADGM require DFSA/FSRA authorisation; an ordinary commercial licence or innovation package cannot be used to conduct regulated financial services. [[16]](#ref16) [[17]](#ref17)
- Visa quota is normally tied to office package, facility size or free-zone authority rules. Cheap licence packages may not support the headcount needed for operations.
- Bank onboarding examines substance, UBO, source of funds, sanctions exposure, activity coherence and customer/supplier geography; incorporation alone does not guarantee a bank account.

### C. Commercial Agencies, Distribution, Franchising and Contractor-Channel Structures

The existing file records Federal Decree-Law No. 3 of 2022 as the current commercial-agencies framework. For a raw-detail UAE business library, the important distinction is between a registered commercial agency, an unregistered distribution contract, a franchise, a reseller arrangement, a commission agent and a services agency. Only registered agencies obtain the full statutory protection associated with the commercial-agencies regime.

|Topic|Detailed point|Drafting / due diligence consequence|
|---|---|---|
|Registered agency|Agency registered with the Ministry of Economy; usually gives the UAE agent statutory protection and territorial rights.|Check registration certificate, territory, products, term, exclusivity and termination grounds before appointing another channel.|
|Unregistered distributor|Contractual relationship without statutory agency registration.|Governed mainly by contract and general UAE law; still manage exclusivity, stock, warranty, governing law and dispute forum.|
|Franchise|Uses brand, systems, know-how and operating standards.|Draft IP licence, training, audit, quality control, fees, termination, post-termination de-branding and non-compete clauses.|
|Termination risk|Existing file notes compensation risk where principal terminates without material reason.|Keep breach notices, cure periods, sales targets, compliance evidence and market-investment records.|
|Parallel imports|Registered agency and IP/customs rules can affect parallel imports.|Assess product category, customs enforcement and consumer-warranty obligations.|
|Dispute forum|Agency disputes may involve Ministry committee/courts depending on law and contract.|Draft jurisdiction/arbitration carefully but verify mandatory local rules.|
|Public procurement channel|Agents/distributors may be used for government tenders or local support.|Anti-bribery, sanctions, AML/CFT and conflict checks are essential.|

### D. Labour Law — Article-by-Article Expansion and Implementing Practice

The official MOHRE source identifies Federal Decree-Law No. 33 of 2021 as the UAE Labour Law governing private-sector employment relationships, subject to exclusions and amendments. The UAE Government portal likewise states that the law applies to private-sector employees in the UAE, both UAE nationals and expatriates, with exempt categories following other regulations. [[2]](#ref2) [[3]](#ref3)

|Article / group|Topic|Expanded practical content|Source|
|---|---|---|---|
|1|Definitions|Defines key terms used in the labour regime; do not substitute free-zone definitions unless a special regime applies.|[[2]](#ref2)|
|2|Objectives|Enhances labour-market efficiency and flexibility, attracts talent, regulates employment relationships, defines rights and obligations, improves skills and protects parties.|[[2]](#ref2)|
|3|Scope|Applies to UAE private-sector establishments, employers and workers; government, armed forces/security and domestic workers are excluded or governed separately.|[[2]](#ref2)|
|4|Equality and non-discrimination|Prohibits discrimination by race, colour, sex, religion, national/social origin or disability; equal pay for women for equal work; UAE-citizen participation rules are not discrimination.|[[2]](#ref2)|
|5|Juvenile employment|Minimum age 15; guardian consent, medical fitness, reduced hours and dangerous-work restrictions apply.|[[2]](#ref2)|
|6|Recruitment and work permits|Work permits are required; recruitment agencies must be licensed; employers cannot charge recruitment fees to workers.|[[2]](#ref2)|
|7|Work patterns|Recognises full-time, part-time, temporary and flexible work; implementing rules define conditions.|[[2]](#ref2)|
|8|Employment contract|Contract must be written and for a specified period; renewals count for service continuity.|[[2]](#ref2)|
|9|Probation|Probation cannot exceed six months; employer termination requires 14 days notice; worker transfer/leaving rules include notice and cost-compensation concepts.|[[2]](#ref2)|
|10|Non-compete|Permitted for up to two years where the worker had access to clients or trade secrets; must be limited in time, place and work type; may be nullified after unlawful termination.|[[2]](#ref2)|
|11-16|Obligations and assignment|Employer must maintain records, provide safe conditions and required benefits; worker must perform duties, protect secrets and comply with safety obligations.|[[2]](#ref2)|
|17-21|Hours, breaks, overtime and rest|Normal cap: eight hours per day or 48 per week; no more than five consecutive hours without break; overtime generally capped at two hours per day with premium rates.|[[2]](#ref2)|
|22-27|Wages and deductions|Wages must be contractual and paid in AED or agreed currency; deductions are limited and total deductions generally cannot exceed 50% of wage.|[[2]](#ref2)|
|28-35|Holidays and leave|Public holidays, annual leave, maternity, sick, bereavement, parental, study and other leave categories are regulated with minimum entitlements.|[[2]](#ref2)|
|36-38|Safety, work injury and compensation exceptions|Employer bears treatment and salary-compensation responsibilities for work injury; compensation may be withheld where injury resulted from specified worker misconduct.|[[2]](#ref2)|
|39-41|Disciplinary sanctions|Sanctions range from written notices to dismissal while preserving statutory entitlements; procedural timelines and one-sanction-per-violation principles apply.|[[2]](#ref2)|
|42-50|Termination and mobility|Termination grounds include expiry, mutual agreement, notice, death, disability, closure and bankruptcy; dismissal without notice is restricted to enumerated serious misconduct.|[[2]](#ref2)|
|51-53|End-of-service and final settlement|Foreign workers with at least one year continuous service receive statutory gratuity calculated on basic wage, subject to statutory cap; final entitlements must be settled promptly.|[[2]](#ref2)|
|54-57|Disputes, fees, collective disputes and inspection|MOHRE mediates; certain lower-value claims may be decided by MOHRE; inspectors have record-review and entry powers.|[[2]](#ref2)|
|58-67|Penalties and final rules|Penalties cover false information, obstruction, unauthorised employment, permit misuse and juvenile violations; Arabic is the official language and Gregorian calendar is used.|[[2]](#ref2)|

#### Cabinet Resolution No. 1 of 2022 and implementing-regulation themes

- **Work models:** Implementing rules operationalise full-time, part-time, temporary, flexible and remote work models. Contracts, payroll, leave, gratuity and immigration sponsorship should match the actual work model rather than the label used commercially. [[2]](#ref2)
- **Work permits:** Permits are required for lawful work. The permit type should match the work arrangement: employee, part-time, juvenile, training, freelance, temporary or other approved categories. [[2]](#ref2)
- **Contract conversion:** The post-2021 regime moved private-sector employment to fixed-term contracts. Renewals count toward service continuity for end-of-service calculations. [[2]](#ref2)
- **Recruitment costs:** Employers and licensed recruiters may not shift recruitment fees to workers. Any clawback clause should be checked carefully against labour-law limits. [[2]](#ref2)
- **Remote work:** Remote work should be documented, including workplace, equipment, confidentiality, cybersecurity, hours, health and safety and cross-border tax/immigration implications. [[2]](#ref2)
- **Overtime calculation:** Existing file records standard overtime formulas based on basic wage divided over monthly days and hours, with 25% and 50% premium concepts. Verify sector-specific exceptions and managerial exclusions before applying. [[2]](#ref2)
- **Disciplinary procedure:** Use written investigation, notice, worker response, proportional sanction, Arabic/understood language communication, record retention and appeal handling. [[2]](#ref2)
- **Final settlement:** Track wages, unused leave, notice, gratuity, repatriation, deductions, loans, advances, visa cancellation and work-permit cancellation in a single settlement checklist. [[2]](#ref2)

#### Wage Protection System and payroll compliance

The existing research summaries record Wage Protection System updates, including wages due by the first day of the following month and an 85% payment threshold for compliance. Because the specific ministerial resolution was not independently retrieved in full during this expansion, the file treats those 2026 details as research-file findings requiring confirmation against the current MOHRE/WPS circular before enforcement action. The official labour-law material nevertheless supports the broader rule that wages are regulated, deductions are limited and labour inspectors can review records. [[2]](#ref2)

|Payroll control|Raw detail|Evidence / risk note|
|---|---|---|
|Salary file|Maintain employment contract salary, WPS salary, bank salary and accounting salary consistently.|Mismatch triggers WPS, tax, immigration, audit and dispute risk.|
|Payment timing|Existing research notes salary due by the first day of following month under 2026 WPS update.|Mark as research-file finding; verify with current MOHRE WPS circular before citing in proceedings.|
|Deductions|Deductions are limited to statutory categories and generally cannot exceed 50% of wage.|[[2]](#ref2)|
|Overtime|Compute from basic wage and applicable premium unless worker/category is excluded.|[[2]](#ref2)|
|Leave encashment|Track accrued leave, carried-over leave and leave cash-in-lieu on termination.|[[2]](#ref2)|
|Gratuity|Foreign workers with one year continuous service receive gratuity based on basic wage and capped by statute.|[[2]](#ref2)|
|Dispute file|Retain contract, payslips, WPS proofs, warnings, leave records, attendance and settlement receipts.|[[2]](#ref2)|

### E. Emiratisation, Nafis and UAE-National Employment

The UAE Government portal contains official Emiratisation pages covering private-sector Emiratisation policy and Emiratis employment in the private sector. [[4]](#ref4) [[24]](#ref24) The existing research summaries record 2026 targets and penalties; where exact future-year numbers are not independently retrieved in the visible official page content, this file marks them as research-file findings to verify before relying on them in enforcement or board papers.

|Dimension|Detailed content|Compliance action|
|---|---|---|
|Large employers|Existing research records a 10% Emiratisation target by end-2026 for companies with 50+ employees.|Verify current MOHRE/Nafis dashboard obligations by skilled-worker headcount and semi-annual milestone.|
|Small employers|Existing research records requirements for selected 20–49 employee companies to hire UAE nationals in specified sectors.|Check sector classification, headcount, skilled-role status and deadlines.|
|Penalty escalation|Existing research records AED 10,000 per month per unfilled position for 2026.|Verify penalty amount in current MOHRE/Nafis notice before accrual or disclosure.|
|Fake Emiratisation|Existing file records high penalties for fake Emiratisation and illegal hiring.|Ensure UAE national performs real skilled work, receives salary through proper channel and is not merely registered nominally.|
|Nafis benefits|Existing file records salary support, pension and child allowance elements.|Employee eligibility, employer registration and salary bands should be checked on Nafis at time of application.|
|Counting rules|Research summary records minimum salary requirement for Emiratis to count toward quota from 2026.|Verify with MOHRE/Nafis before workforce planning.|
|Evidence pack|Maintain employment contract, role description, attendance/work output, salary proof, pension registration and onboarding documents.|Defends against fake-Emiratisation allegations and supports audit response.|

### F. Visas, Residence, Work Permits and Immigration Interfaces

Business setup in the UAE is inseparable from immigration. The ICP publishes official Golden Residency and Green Residency service information, and the UAE Government portal maintains a Golden Visa information page. [[12]](#ref12) [[13]](#ref13) [[14]](#ref14)

|Route|Core description|Practical notes|
|---|---|---|
|Employment residence|Employer-sponsored route tied to work permit and establishment file.|Mainland private-sector employment normally requires MOHRE permit, residence process, medical fitness and Emirates ID.|
|Golden residency|Long-term residency route for qualifying investors, entrepreneurs, specialised talents and other categories.|ICP and UAE Government portal sources identify official Golden Residency service channels and eligibility categories [[13]](#ref13) [[14]](#ref14)|
|Green residency|Self-sponsored route for qualifying skilled employees, freelancers/self-employed persons and investors/partners.|ICP publishes Green Residency service information; apply eligibility exactly to current ICP category conditions [[12]](#ref12)|
|Investor/partner visa|Residence based on ownership or partnership in UAE entity.|Licence validity, shareholding evidence, establishment card and immigration file drive eligibility.|
|Freelance permit/residency|Free-zone or mainland permit route for individuals performing approved professional activities.|Confirm whether the permit allows mainland client work, free-zone-only activity or remote services.|
|Family sponsorship|Residence holders may sponsor dependants if salary, accommodation and immigration criteria are met.|Sponsorship should be checked against current ICP/GDRFA criteria at filing date.|
|Retirement and property routes|Long-term or renewable residence routes may exist for retirees or property investors.|Use official ICP/GDRFA or UAE portal service pages because bank deposit, property value, insurance and age criteria can change.|

#### Immigration compliance checklist

- Do not allow work before the correct permit/residence status is in place.
- Keep passport, Emirates ID, visa, labour card/permit, contract and insurance records current.
- Cancel or transfer visas promptly on termination, and coordinate final settlement before cancellation.
- Check travel bans, absconding reports and labour complaints before assuming a worker can exit/transfer.
- For founders and investors, align shareholding, licence, establishment card, residence category and tax-residence objectives.
- For Golden/Green residency holders, confirm whether a separate work permit is still required for employment activity.

### G. Tax, Free-Zone Corporate Tax, VAT, ESR and Transfer Pricing

The FTA Free Zone Persons bulletin provides raw operational detail for the Corporate Tax treatment of free-zone entities. It states that a Qualifying Free Zone Person can benefit from a 0% Corporate Tax rate on Qualifying Income, while other income is subject to the standard 9% rate. [[5]](#ref5)

|Tax issue|Detailed rule / finding|Source|
|---|---|---|
|Corporate Tax standard rate|The UAE Corporate Tax regime taxes non-exempt taxable income under the Corporate Tax Law; the existing file records the standard 9% rate above the AED 375,000 threshold.|Use FTA registration and guide material for filings; do not rely on commercial summaries for deadlines.|
|Free-zone 0% regime|A Qualifying Free Zone Person may benefit from a 0% Corporate Tax rate on Qualifying Income; other income is subject to the standard 9% rate.|[[5]](#ref5)|
|QFZP core conditions|Must maintain adequate substance in a free zone, derive qualifying income, not elect standard-rate treatment, comply with arm’s-length and transfer-pricing rules, maintain TP documentation, maintain audited financial statements and satisfy de minimis limits.|[[5]](#ref5)|
|De minimis rule|Non-qualifying revenue must not exceed the lower of AED 5 million or 5% of total revenue.|[[5]](#ref5)|
|Qualifying activities|FTA bulletin lists manufacturing, processing, qualifying-commodity trading, holding shares/securities, ship ownership/management/operation, reinsurance, fund management, wealth/investment management, headquarters services, treasury/financing to related parties, aircraft financing/leasing, distribution from designated zones and logistics services.|[[5]](#ref5)|
|Excluded activities|FTA bulletin treats banking, most insurance, certain finance/leasing, transactions with natural persons outside listed exceptions, and certain immovable-property/IP income as excluded or non-qualifying.|[[5]](#ref5)|
|Tax registration|Free Zone Persons, including QFZPs, should register for Corporate Tax in the form and timeline prescribed by the FTA; failure may trigger administrative penalties.|[[5]](#ref5)|
|Tax return and payment|FTA bulletin states Corporate Tax return/payment obligations are due within nine months from the end of the relevant tax period.|[[5]](#ref5)|
|Record retention|FTA bulletin states Free Zone Persons must maintain records and documents for seven years after the relevant tax period.|[[5]](#ref5)|
|VAT mandatory threshold|FTA VAT registration page states the mandatory registration threshold is AED 375,000; foreign-business specifics must be checked separately.|[[6]](#ref6)|
|VAT voluntary threshold|UAE portal search result indicates optional registration above AED 187,500 annual supplies/imports; verify on FTA/UAE portal at filing date.|[[6]](#ref6)|

#### Corporate Tax compliance calendar — raw checklist

- Confirm whether the person is taxable, exempt, government-related, natural person, juridical person, non-resident or free-zone person.
- Register for Corporate Tax within the applicable FTA deadline.
- Classify revenue streams into qualifying income, non-qualifying income, excluded activities, exempt income and ordinary taxable income.
- Prepare transfer-pricing analysis for related-party and connected-person transactions.
- Maintain audited financial statements where required, especially for QFZP status.
- File tax return and pay tax within nine months after the end of the tax period, as stated in FTA free-zone bulletin for Free Zone Persons. [[5]](#ref5)
- Maintain records for seven years following the end of the relevant tax period, as stated in the FTA bulletin. [[5]](#ref5)
- Assess VAT registration, invoicing, place of supply, reverse charge, imports, designated zones and input-tax recovery separately from Corporate Tax. [[6]](#ref6)

### H. UBO, AML/CFT, Sanctions, Competition, Consumer Protection and Commercial Compliance

Business formation also triggers beneficial-ownership, AML/CFT, competition, consumer-protection and sector compliance duties. The Ministry of Economy search results and pages identify official oversight for competition, consumer protection, DNFBP AML/CFT and UBO framework development. [[7]](#ref7) [[8]](#ref8) [[10]](#ref10) [[23]](#ref23)

|Compliance area|Raw obligations / detailed content|Official-source status|
|---|---|---|
|UBO|Maintain beneficial-owner registers, identify natural persons exercising ultimate ownership/control, file data with registrar and keep information current.|Central Bank rulebook page identifies Cabinet Decision No. 58 of 2020 on Beneficial Owner Procedures; Ministry pages show continuing UBO framework development [[11]](#ref11) [[23]](#ref23)|
|AML/CFT|DNFBPs such as real estate brokers, dealers in precious metals/stones, auditors, corporate service providers and certain legal/accounting service providers may need goAML registration, risk assessment, CDD, suspicious-transaction reporting and sanctions screening.|Ministry DNFBP page states failure to register on goAML may result in severe penalties [[10]](#ref10)|
|Competition|Competition policy seeks fair competition, anti-monopoly controls and integrity of commercial transactions.|Ministry competition page identifies Ministry oversight of competition regulation [[7]](#ref7)|
|Consumer protection|Consumer framework protects consumer rights and fair transparent market conduct.|Ministry consumer page identifies Federal Law No. 15 of 2020; UAE legislation page provides law download [[8]](#ref8) [[9]](#ref9)|
|IP|Trademark, patent, industrial-design and copyright protections require registration or statutory recognition under separate IP laws and Ministry systems.|For filings, use Ministry of Economy IP service pages and official legislation; existing file preserves the core terms but specific fee/timeline should be verified before filing.|
|ESR|ESR historically required licensees conducting relevant activities to assess, notify and report; current status, penalties and interaction with Corporate Tax should be verified at filing date.|Mark entity ESR position in annual compliance calendar; do not assume ESR is irrelevant merely because Corporate Tax applies.|
|Data and cyber compliance|Businesses processing personal data, operating regulated technology services or handling cyber-risk obligations may face separate UAE data-protection and cyber rules.|Not exhaustively verified for this file; flag for the sector-specific file or dedicated privacy/cyber memorandum.|

#### AML/CFT DNFBP file structure

- Enterprise-wide risk assessment: customer types, geography, products/services, delivery channels, transaction sizes and sanctions exposure.
- Policies and procedures: customer due diligence, enhanced due diligence, ongoing monitoring, suspicious-transaction reporting, record retention, training and governance.
- goAML registration and user access where applicable; Ministry search result states failure to register may attract severe penalties. [[10]](#ref10)
- Screening: customers, UBOs, directors, counterparties and beneficial controllers against sanctions and adverse-media sources.
- Transaction monitoring: red flags, unusual cash, inconsistent source of funds, third-party payments and high-risk jurisdictions.
- Independent audit or compliance review depending on entity size and risk profile.
- Board/manager oversight minutes showing AML/CFT risk acceptance and remediation.

### I. Intellectual Property, Technology Assets and Commercialisation

The existing file records the principal UAE IP laws and core protection periods. For business structuring, IP analysis should connect ownership, registration, employment-created works, contractor assignments, brand licences, franchise agreements, software escrow, confidentiality and competition restraints.

|Asset|Detailed UAE business-law treatment|Contract controls|
|---|---|---|
|Trademark|Brand protection through registration, classification and enforcement; existing file records Federal Decree-Law No. 36 of 2021 and multi-class/Nice-classification concepts.|Register before franchising; include quality control, territory, approved use, online use and termination de-branding.|
|Patent / industrial property|Existing file records Federal Law No. 11 of 2021 and 20-year patent protection.|Use invention assignment, confidentiality, prosecution control, maintenance-fee responsibility and improvement ownership.|
|Copyright|Existing file records Federal Law No. 38 of 2021 and life-plus-50 concept.|Contractor deliverables need written assignment/licence; employment-created works need policy clarity.|
|Trade secrets|Protected practically through confidentiality, access control, non-disclosure, employee obligations and cyber controls.|Use NDAs, restricted access, clean-team protocols and return/destruction obligations.|
|Software / SaaS|May combine copyright, contract, data-protection, consumer, telecom/cyber and tax issues.|Define source code ownership, hosting, data location, service levels, acceptable use, liability caps and audit rights.|
|Franchise manuals|Operational know-how and brand standards require contractual protection.|Confidentiality, training, update rights, audit and post-termination obligations are critical.|

### J. DIFC and ADGM Business and Employment Regimes

DIFC and ADGM are financial free zones with separate legal/regulatory architecture. The DFSA publishes laws and rules for DIFC financial regulation, while ADGM publishes legal framework materials and federal-legislation references. [[16]](#ref16) [[17]](#ref17) DIFC and ADGM employment regimes should not be treated as identical to mainland MOHRE employment law.

|Topic|DIFC|ADGM|Mainland contrast|
|---|---|---|---|
|Legal architecture|DIFC has its own courts and legal framework; DFSA regulates financial services.|ADGM has its own courts/legal framework; FSRA regulates financial services.|Mainland companies are governed by UAE federal/local courts and regulators unless arbitration/special forum applies.|
|Employment law|DIFC employment relationships follow DIFC employment legislation and DEWS-style savings framework identified in existing file.|ADGM employment relationships follow ADGM employment regulations and tribunal/court framework identified in existing file.|Mainland private sector follows Federal Decree-Law No. 33 of 2021 and MOHRE systems [[2]](#ref2)|
|Regulated activities|Financial services require DFSA authorisation.|Financial services require FSRA authorisation.|Mainland financial activities require Central Bank/SCA/other federal approvals depending on activity.|
|Disputes|DIFC Courts and DIFC dispute mechanisms.|ADGM Courts/tribunals and ADGM dispute mechanisms.|MOHRE mediation and UAE courts for mainland employment disputes.|
|End-of-service|Existing file records DIFC DEWS replacing traditional gratuity for covered employees.|ADGM has its own employment-benefit rules.|Mainland foreign workers receive statutory gratuity under Article 51 framework [[2]](#ref2)|
|Company types|DIFC companies, partnerships, foundations and regulated vehicles.|ADGM companies, SPVs, foundations, funds and regulated vehicles.|Mainland CCL entity forms under Federal Decree-Law No. 32 of 2021 [[1]](#ref1)|

### K. Practical Due-Diligence Question Bank

#### Investor entering the UAE

- What exact activity will generate revenue?
- Will customers be mainland, free-zone, foreign or government?
- Is a regulated activity involved?
- Does the entity need employees and visas?
- Will the structure need QFZP Corporate Tax treatment?
- Who are the UBOs and funding sources?
- Can the bank onboard the activity and shareholders?
- Are agency/distribution protections triggered?

#### Employer hiring in UAE

- Which legal regime applies: mainland, DIFC, ADGM or another free zone?
- Is the worker UAE national or expatriate?
- What permit type is required?
- Is contract fixed-term and compliant?
- How will WPS or regime-equivalent payroll be handled?
- Are overtime, leave and gratuity configured correctly?
- Does the company have Emiratisation obligations?
- What documents will prove compliance in a dispute?

#### Free-zone company selling onshore

- Does the licence permit the activity?
- Is a mainland licence, branch or distributor required?
- How will VAT be invoiced?
- Does onshore income affect QFZP status?
- Are customs/importer obligations triggered?
- Are consumer-protection or warranty obligations triggered?
- Do employees need mainland work permits for onshore work?
- Does the contract accurately describe who supplies goods/services?

#### Agency/franchise appointment

- Will the arrangement be registered as a commercial agency?
- What territory and products are covered?
- What exclusivity and minimum targets apply?
- Who bears warranty, product liability and recall costs?
- What termination events and cure periods apply?
- How is compensation handled on termination?
- Which forum resolves disputes?
- Who owns customer data and marketing assets?

### L. Known Gaps and Verification Flags

The following items should be treated as verification flags, not invented facts:

- Full official English text of Federal Decree-Law No. 20 of 2025 was identified in research summaries but not successfully crawled in full during this expansion. Use the official UAE legislation database or Ministry of Economy circular before quoting article text.
- The 2026 WPS details in the existing file and research summaries should be verified against the current MOHRE ministerial-resolution text before enforcement or litigation use.
- Exact Emiratisation sector lists, headcount calculations and 2026 salary-counting rules should be checked against the employer’s live MOHRE/Nafis dashboard.
- Fee amounts, setup costs, free-zone capital requirements and visa quotas change frequently and should be verified directly with the relevant free-zone authority at filing date.
- DIFC and ADGM employment-law details require regime-specific current legislation review before drafting employment contracts or litigating claims.
- ESR status and any repeal/continuity position should be verified for the relevant financial year because Corporate Tax reforms changed the compliance landscape.

## References

<p id="ref1" class="ref_item">[1] UAE Legislation — Federal Decree-Law No. 32 of 2021 on Commercial Companies (download) <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1541/download">https://uaelegislation.gov.ae/en/legislations/1541/download</a></p>
<p id="ref2" class="ref_item">[2] MOHRE — Federal Decree-Law No. 33 of 2021 Regarding Regulation of Employment Relationship and amendments (PDF) <a target="_blank" rel="noreferrer" href="https://mohre.gov.ae/assets/download/8cd7cf08/Federal%20Decree-Law%20No.%2033%20of%202021%20Regarding%20the%20Regulation%20of%20Employment%20Relationship%20and%20its%20amendments.pdf.aspx">https://mohre.gov.ae/assets/download/8cd7cf08/Federal%20Decree-Law%20No.%2033%20of%202021%20Regarding%20the%20Regulation%20of%20Employment%20Relationship%20and%20its%20amendments.pdf.aspx</a></p>
<p id="ref3" class="ref_item">[3] UAE Government Portal — Employment laws and regulations in the private sector <a target="_blank" rel="noreferrer" href="https://u.ae/en/information-and-services/jobs/employment-in-the-private-sector/employment-laws-and-regulations-in-the-private-sector">https://u.ae/en/information-and-services/jobs/employment-in-the-private-sector/employment-laws-and-regulations-in-the-private-sector</a></p>
<p id="ref4" class="ref_item">[4] UAE Government Portal — Emiratisation in the private sector <a target="_blank" rel="noreferrer" href="https://u.ae/en/information-and-services/jobs/employment-in-the-private-sector/emiratisation-in-the-private-sector">https://u.ae/en/information-and-services/jobs/employment-in-the-private-sector/emiratisation-in-the-private-sector</a></p>
<p id="ref5" class="ref_item">[5] Federal Tax Authority — Free Zone Persons Corporate Tax bulletin <a target="_blank" rel="noreferrer" href="https://tax.gov.ae/Datafolder/Files/Pdf/2024/CT%20Bulletin/Basic%20Tax%20Information%20bulletin-%20Free%20Zone%20Person-English.pdf">https://tax.gov.ae/Datafolder/Files/Pdf/2024/CT%20Bulletin/Basic%20Tax%20Information%20bulletin-%20Free%20Zone%20Person-English.pdf</a></p>
<p id="ref6" class="ref_item">[6] Federal Tax Authority — Registration for VAT <a target="_blank" rel="noreferrer" href="https://tax.gov.ae/en/taxes/Vat/vat.topics/registration.for.vat.aspx">https://tax.gov.ae/en/taxes/Vat/vat.topics/registration.for.vat.aspx</a></p>
<p id="ref7" class="ref_item">[7] Ministry of Economy & Tourism — Regulation of Competition <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/en/regulation-of-competition">https://www.moet.gov.ae/en/regulation-of-competition</a></p>
<p id="ref8" class="ref_item">[8] Ministry of Economy & Tourism — Consumer Protection <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/en/consumer-protection1">https://www.moet.gov.ae/en/consumer-protection1</a></p>
<p id="ref9" class="ref_item">[9] UAE Legislation — Federal Law No. 15 of 2020 on Consumer Protection (download) <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1455/download">https://uaelegislation.gov.ae/en/legislations/1455/download</a></p>
<p id="ref10" class="ref_item">[10] Ministry of Economy & Tourism — DNFBP AML/CFT compliance page <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/en/-/does-your-company-fall-under-the-dnfbp">https://www.moet.gov.ae/en/-/does-your-company-fall-under-the-dnfbp</a></p>
<p id="ref11" class="ref_item">[11] Central Bank of the UAE Rulebook — Cabinet Decision No. 58 of 2020 Beneficial Owner Procedures <a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/cabinet-decision-58-2020-beneficial-owner-procedures">https://rulebook.centralbank.ae/en/rulebook/cabinet-decision-58-2020-beneficial-owner-procedures</a></p>
<p id="ref12" class="ref_item">[12] ICP — Green Residency <a target="_blank" rel="noreferrer" href="https://icp.gov.ae/en/green-residency/">https://icp.gov.ae/en/green-residency/</a></p>
<p id="ref13" class="ref_item">[13] ICP — Golden Residency <a target="_blank" rel="noreferrer" href="https://icp.gov.ae/en/services/golden-residency/">https://icp.gov.ae/en/services/golden-residency/</a></p>
<p id="ref14" class="ref_item">[14] UAE Government Portal — Golden Visa <a target="_blank" rel="noreferrer" href="https://u.ae/en/information-and-services/visa-and-emirates-id/residence-visas/golden-visa">https://u.ae/en/information-and-services/visa-and-emirates-id/residence-visas/golden-visa</a></p>
<p id="ref15" class="ref_item">[15] UAE Government Portal — Work injury compensation in the UAE <a target="_blank" rel="noreferrer" href="https://u.ae/en/information-and-services/jobs/employment-in-the-private-sector/work-injury-compensation-in-the-uae">https://u.ae/en/information-and-services/jobs/employment-in-the-private-sector/work-injury-compensation-in-the-uae</a></p>
<p id="ref16" class="ref_item">[16] ADGM — Legal Framework Federal Legislation <a target="_blank" rel="noreferrer" href="https://www.adgm.com/legal-framework/federal-legislation">https://www.adgm.com/legal-framework/federal-legislation</a></p>
<p id="ref17" class="ref_item">[17] DFSA — Laws and Rules <a target="_blank" rel="noreferrer" href="https://www.dfsa.ae/your-resources/regulatory/laws-and-rules">https://www.dfsa.ae/your-resources/regulatory/laws-and-rules</a></p>
<p id="ref18" class="ref_item">[18] DIFC main portal <a target="_blank" rel="noreferrer" href="https://www.difc.ae">https://www.difc.ae</a></p>
<p id="ref19" class="ref_item">[19] ADGM main portal <a target="_blank" rel="noreferrer" href="https://www.adgm.com">https://www.adgm.com</a></p>
<p id="ref20" class="ref_item">[20] UAE Legislation — Federal Decree-Law No. 33 of 2021 download mirror <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1542/download">https://uaelegislation.gov.ae/en/legislations/1542/download</a></p>
<p id="ref21" class="ref_item">[21] UAE Legislation — related business legislation download <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1617/download">https://uaelegislation.gov.ae/en/legislations/1617/download</a></p>
<p id="ref22" class="ref_item">[22] UAE Legislation — related business legislation download <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1620/download">https://uaelegislation.gov.ae/en/legislations/1620/download</a></p>
<p id="ref23" class="ref_item">[23] Ministry of Economy & Tourism — UBO framework workshop <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/en/-/ministry-of-economy-and-aml/cft-executive-office-organize-workshop-to-develop-ultimate-beneficial-owner-framework">https://www.moet.gov.ae/en/-/ministry-of-economy-and-aml/cft-executive-office-organize-workshop-to-develop-ultimate-beneficial-owner-framework</a></p>
<p id="ref24" class="ref_item">[24] UAE Government Portal — Emiratis employment in private sector <a target="_blank" rel="noreferrer" href="https://u.ae/en/information-and-services/jobs/employment-in-the-private-sector/emiratis-employment-in-private-sector">https://u.ae/en/information-and-services/jobs/employment-in-the-private-sector/emiratis-employment-in-private-sector</a></p>
