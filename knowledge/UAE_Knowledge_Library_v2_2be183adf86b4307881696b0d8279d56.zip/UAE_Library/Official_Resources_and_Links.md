# Official UAE Resources and Links — Comprehensive Directory

> Expanded final version prepared July 2026. Source policy: official UAE government portals first; authoritative secondary resources only where official text is unavailable. URLs and fees marked `[verify]` should be checked on the live portal before professional reliance.

> **Compiled:** July 2026 | Source policy: official UAE government portals first; authoritative secondary sources where official text unavailable.

---

## 1. FEDERAL GOVERNMENT PORTALS

| Portal | URL | Description |
|---|---|---|
| UAE Government Official Portal | https://www.government.ae | Central gateway to all UAE government services, policies, news, and national strategies |
| UAE President's Court | https://www.presidencycourt.gov.ae | Office of HH President; state affairs, decrees |
| UAE Prime Minister's Office | https://www.pm.gov.ae | Office of VP & PM; government directives, vision statements, UAE agenda |
| UAE Cabinet | https://www.uaecabinet.ae | Cabinet decisions, resolutions, ministerial announcements |
| Federal National Council (FNC) | https://www.almajlesalwatani.ae | Parliamentary body; sessions, legislation proposals, member profiles |
| UAE Ministry of Justice (MOJ) | https://www.moj.gov.ae | Court services, notarization, legislation portal, legal aid, lawyer registration |
| UAE Ministry of Economy | https://www.economy.gov.ae | Business licensing, IP registration, consumer protection, trade policy |
| UAE Ministry of Finance | https://www.mof.gov.ae | Federal budget, fiscal policy, public debt, financial reports |
| UAE Ministry of Infrastructure Development (MOID) | https://www.moid.gov.ae | Federal roads, construction standards, engineering specs, transport infrastructure |
| UAE Ministry of Human Resources & Emiratisation (MOHRE) | https://www.mohre.gov.ae | Labour law, work permits, WPS, employer/employee services, Nafis |
| UAE Ministry of Climate Change and Environment (MOCCAE) | https://www.moccae.gov.ae | Environmental laws, EIA approvals, waste management, biodiversity, CITES |
| UAE Ministry of Industry and Advanced Technology (MoIAT) | https://www.moiat.gov.ae | Industrial policy, ESMA standards (integrated), advanced technology, Industry 4.0 |
| UAE Ministry of Health and Prevention (MOHAP) | https://www.mohap.gov.ae | Drug registration, healthcare facility licensing, medical devices, public health |
| UAE Ministry of Education (MoE) | https://www.moe.gov.ae | National curriculum, public school governance, HEI accreditation policy |
| UAE Ministry of Interior (MOI) | https://www.moi.gov.ae | Police, Civil Defence, prisons, immigration coordination |
| UAE Ministry of Foreign Affairs (MOFA) | https://www.mofa.gov.ae | Diplomatic affairs, document attestation, bilateral relations |
| Federal Authority for Identity, Citizenship, Customs & Port Security (ICP) | https://www.icp.gov.ae | Emirates ID, residence visas, citizenship applications, customs |
| UAE Space Agency | https://www.space.gov.ae | Space sector licensing, national space policy, HOPE probe |
| UAE AI Office | https://ai.gov.ae | National AI Strategy 2031, AI projects and adoption |
| Telecommunications & Digital Government Regulatory Authority (TDRA) | https://tdra.gov.ae | Telecom licences, spectrum management, digital government policy |
| Federal Authority for Nuclear Regulation (FANR) | https://www.fanr.gov.ae | Nuclear safety, radiation protection, Barakah NPP oversight |
| General Civil Aviation Authority (GCAA) | https://www.gcaa.gov.ae | Air operator certificates, pilot licences, RPAS/drone regulations, airspace |
| Federal Tax Authority (FTA) | https://www.tax.gov.ae | VAT, Excise Tax, Corporate Tax registration, filing, and refund portal |
| EmaraTax (Online Tax Portal) | https://www.emaratax.ae | Unified online portal for all FTA tax filings and payments |
| Securities & Commodities Authority (SCA) / Capital Market Authority (CMA) | https://www.sca.gov.ae | Capital markets regulation, public company oversight (reconstituted as CMA 2026) |
| UAE Central Bank (CBUAE) | https://www.centralbank.ae | Monetary policy, banking supervision, insurance regulation, payment systems, AML |
| Intellectual Property Authority (IAPA) | https://www.iapa.gov.ae | Trademark, patent, copyright, industrial design registration |
| UAE Data Office (UAEDO) | https://www.uaedataoffice.gov.ae | Personal Data Protection Law supervision, PDPL enforcement (since Jan 2024) |
| UAE Cybersecurity Council | https://www.cybersecurity.gov.ae | National cybersecurity strategy, incident response, sector frameworks |

---

## 2. LEGISLATION & LAW DATABASES

| Resource | URL | Description |
|---|---|---|
| UAE Legislation Portal — MOJ (elaws) | https://elaws.moj.gov.ae | Searchable full-text Arabic federal laws; Federal Laws, Decrees, Ministerial Resolutions — authoritative primary source |
| UAE Legislation — English/Arabic (uaelegislation.gov.ae) | https://uaelegislation.gov.ae | Bilingual (Arabic/English) laws; Constitution full text; key for English-language legal research |
| Dubai Laws Portal (DLP) | https://dlp.dubai.gov.ae | Dubai-specific laws and regulations (Arabic/English); full text free access |
| Abu Dhabi Judicial Department Legislation | https://www.adjd.gov.ae/legislation | Abu Dhabi legislation database; laws, regulations, circulars |
| DIFC Laws and Regulations | https://www.difc.ae/business/laws-regulations/ | All DIFC primary and secondary legislation: Companies Law, Employment Law, Data Protection, Courts Rules |
| ADGM Rulebooks | https://en.adgm.thomsonreuters.com/rulebooks | ADGM regulations, FSRA rules, Courts rules (hosted on Thomson Reuters) |
| UAE Official Gazette (Al Jarida Al Rasmia) | https://egazette.moj.gov.ae | Official UAE gazette; enacted laws and resolutions published here officially |
| Westlaw Middle East | https://legal.thomsonreuters.com/en/products/westlaw-middle-east | Commercial subscription database; UAE and GCC laws in English translation |
| Lexis Middle East | https://www.lexismiddleeast.com | Commercial subscription database; UAE laws, case law, legal analysis |
| HCCH — UAE Apostille Info | https://www.hcch.net/en/states/authorities/details3/?aid=1395 | Hague Conference record of UAE's Apostille Convention accession (2021); UAE issuing since Jan 2025 |

---

## 3. MUNICIPALITY & PLANNING PORTALS

| Portal | URL | Description |
|---|---|---|
| Dubai Municipality (DM) | https://www.dm.gov.ae | Building permits, planning approvals, environmental permits, Dubai Building Code (DBC 2021) |
| Dubai Building Code (DBC 2021) Direct | https://www.dm.gov.ae/municipality-business/planning-and-construction/dubai-building-code-2/ | Direct access to all DBC 2021 volumes and chapters |
| Dubai Land Department (DLD) / RERA | https://dubailand.gov.ae | Real estate registration, off-plan sales (OQOOD), RERA rental index, broker registration |
| Roads and Transport Authority (RTA) Dubai | https://www.rta.ae | Road network, metro/bus/taxis, driving licences, Nol Card, smart mobility |
| Abu Dhabi Dept. of Municipalities and Transport (DMT) | https://www.dmt.gov.ae | Building code, planning, transport in Abu Dhabi; ADIBC; property registration |
| Abu Dhabi Real Estate Centre (ADREC) | https://www.adrec.gov.ae | Abu Dhabi property registration, Tawtheeq lease contracts, real estate market data |
| TAMM (Abu Dhabi Government Services) | https://www.tamm.abudhabi | Unified Abu Dhabi portal; 700+ government services — business, residency, construction |
| Sharjah City Planning (SCP) | https://www.scp.gov.ae | Sharjah urban master plan, planning permits, zoning |
| Ajman Municipality | https://www.ajman.ae/en/municipality | Building permits, planning approvals, and local services in Ajman |
| Umm Al Quwain Municipality | https://www.mun.uaq.ae | Local government services in UAQ |
| Ras Al Khaimah Municipality | https://www.mun.rak.ae | Building permits and planning approvals in RAK |
| Fujairah Municipality | https://www.fujairah.ae | Local municipality services and building permits in Fujairah |

---

## 4. CONSTRUCTION, ENGINEERING & CIVIL DEFENCE PORTALS

| Portal | URL | Description |
|---|---|---|
| Dubai Civil Defence (DCD) | https://www.dcd.gov.ae | Fire safety approvals, fire-fighting system NOC, inspection certificates |
| Abu Dhabi Civil Defence (ADCD) | https://www.adcd.gov.ae | Abu Dhabi fire safety regulations, plan approvals, fire equipment certification |
| Trakhees (PCFC) | https://www.trakhees.ae | Construction regulation for Jebel Ali FZ, Palm Jumeirah, World islands; own technical code |
| MoIAT Standards (ESMA integrated) | https://www.moiat.gov.ae/standardization | UAE.S national standards catalogue; purchase standards online; conformity assessment |
| DEWA Developer Portal | https://www.dewa.gov.ae/developer | DEWA technical requirements, connection applications, Shams Dubai solar feed-in, smart metering |
| SEWA | https://www.sewa.gov.ae | Sharjah electricity, water, gas utility; connection standards |
| FEWA | https://www.fewa.gov.ae | Northern Emirates utility; connection requirements for RAK, Ajman, UAQ, Fujairah |
| Abu Dhabi Distribution Company (ADDC) | https://www.addc.ae | Electrical connections in Abu Dhabi city and western region |
| Al Ain Distribution Company (AADC) | https://www.aadc.ae | Electrical connections in Al Ain region |
| Etihad Rail | https://www.etihadrail.ae | National railway; freight; passenger rail (launched June 2026 AD–Fujairah) |
| AD Ports Group | https://www.adports.ae | Khalifa Port, Mina Zayed, Kizad; shipping, logistics, industrial zones |
| DP World (Jebel Ali) | https://www.dpworld.com/uae | Jebel Ali Port operations; container terminal; logistics |
| OSHAD (Abu Dhabi OHS) | https://www.oshad.ae | OSHAD-SF framework; all 17 elements; Codes of Practice free download |
| Dubai Municipality OHS | https://www.dm.gov.ae/municipality-business/public-health-and-safety/occupational-health-and-safety | Dubai OHS guidelines and construction safety requirements |

---

## 5. FREE ZONE PORTALS

| Free Zone | URL | Emirate | Key Notes |
|---|---|---|---|
| JAFZA (Jebel Ali Free Zone) | https://www.jafza.ae | Dubai | World's largest free zone; logistics, manufacturing, trading; FZE/FZCO |
| DIFC | https://www.difc.ae | Dubai | Financial services; own courts (DIFC Courts); DFSA-regulated; English common law |
| ADGM | https://www.adgm.com | Abu Dhabi | Financial/commercial free zone; FSRA-regulated; family offices; English common law |
| DMCC | https://www.dmcc.ae | Dubai | Commodities (gold, diamonds, coffee, tea); world's most registered free zone |
| DAFZA (Dubai Airport Free Zone) | https://www.dafza.gov.ae | Dubai | Aviation, aerospace, pharma, electronics; adjacent to DXB |
| Dubai Silicon Oasis (DSO) | https://www.dsoa.ae | Dubai | Technology, ICT, electronics manufacturing; residential community |
| Dubai Internet City (DIC) | https://www.dubaiinternetcity.ae | Dubai | ICT, software, digital companies; Google, Microsoft, Oracle anchor tenants |
| Dubai Media City (DMC) | https://www.dubaimediacity.ae | Dubai | Media, PR, publishing, broadcasting |
| Dubai Healthcare City (DHCC) | https://www.dhcc.ae | Dubai | Healthcare providers, medical education, wellness |
| KIZAD (Khalifa Industrial Zone) | https://www.kizad.ae | Abu Dhabi | Heavy/light industry, manufacturing; adjacent to Khalifa Port |
| RAKEZ | https://www.rakez.com | RAK | Manufacturing, trading, services; highly competitive pricing |
| Masdar City Free Zone | https://www.masdar.ae | Abu Dhabi | Cleantech, sustainability, renewable energy; net-zero city concept |
| Sharjah Media City (Shams) | https://www.shamsfreezone.com | Sharjah | Media, creative, e-commerce; very low setup costs |
| SAIF Zone (Sharjah Airport) | https://www.saifzone.com | Sharjah | Logistics, manufacturing, trading; 24-hour airport access |
| Hamriyah Free Zone | https://www.hfza.ae | Sharjah | Heavy/light industry, storage, bulk materials |
| Ajman Free Zone | https://www.afza.ae | Ajman | Trading, manufacturing, services; affordable |
| Fujairah Creative City | https://www.creativecity.ae | Fujairah | Media, consulting, e-commerce; east-coast location |
| twofour54 (Abu Dhabi Media Zone) | https://www.twofour54.com | Abu Dhabi | Media, entertainment, gaming; Emirati content production |

---

## 6. JUDICIAL & ARBITRATION PORTALS

| Portal | URL | Description |
|---|---|---|
| Federal Supreme Court (UAE) | https://www.sc.gov.ae | Constitutional cases; final federal appeal; case database |
| Dubai Courts | https://www.dc.gov.ae | Online court filing; case tracking; Small Claims Court; Rental Dispute Centre |
| Abu Dhabi Judicial Department (ADJD) | https://www.adjd.gov.ae | Abu Dhabi courts filing; mediation; family guidance; legislation database |
| RAK Courts | https://www.courts.rak.ae | Ras Al Khaimah court services |
| DIFC Courts | https://www.difccourts.ae | Online filing; Small Claims Tribunal (AED 500K limit); practice directions |
| ADGM Courts | https://www.adgm.com/legal-en/adgm-courts | ADGM court rules; online registry; commercial dispute specialists |
| Dubai International Arbitration Centre (DIAC) | https://www.diac.ae | Main arbitration centre; 2022 Rules; emergency arbitrator; expedited procedure |
| ADCCAC (Abu Dhabi) | https://www.adcci.gov.ae/adccac | Abu Dhabi Chamber arbitration and conciliation; 2013 Rules |
| Centre for Amicable Settlement of Disputes (CASD) | https://www.adjd.gov.ae/casd | Mandatory mediation for commercial claims < AED 500,000 in Abu Dhabi |
| Rental Dispute Centre (RDC) Dubai | https://www.dc.gov.ae (Rental Disputes section) | Fast-track landlord-tenant dispute resolution (3–7 day first hearing) |
| ICC — Middle East (Abu Dhabi) | https://iccwbo.org/dispute-resolution/ | ICC arbitration; Abu Dhabi representative office opened 2020 |

---

## 7. FINANCIAL, TAX & BUSINESS REGISTRATION

| Portal | URL | Description |
|---|---|---|
| Dubai Economy and Tourism (DET/DED) | https://www.dubaided.gov.ae | Dubai mainland business licensing, consumer protection, trade name registration |
| Abu Dhabi Dept. of Economic Development (ADDED) | https://www.added.gov.ae | Abu Dhabi mainland business licences, EIA permits, OHS registration |
| Dubai Financial Market (DFM) | https://www.dfm.ae | Equities, sukuk, ETFs; market data; listed companies; investor portal |
| Abu Dhabi Securities Exchange (ADX) | https://www.adx.ae | Abu Dhabi listed securities; investor information; market statistics |
| NASDAQ Dubai | https://www.nasdaqdubai.com | International equity and sukuk listings; DIFC-based |
| DFSA (Dubai Financial Services Authority) | https://www.dfsa.ae | DIFC financial services licensing; regulated firms register; enforcement |
| FSRA (Financial Services Regulatory Authority — ADGM) | https://www.fsra.adgm.com | ADGM regulated entities; rulebooks; licensing |
| VARA (Virtual Assets Regulatory Authority) | https://www.vara.ae | Dubai VA regulation; licensed VA exchanges and service providers |
| CBUAE — Regulated Entities | https://www.centralbank.ae/en/regulated-entities | Register of all UAE-licensed banks, insurers, exchange houses, payment institutions |
| Invest in Dubai | https://www.invest.dubai.gov.ae | Foreign investment facilitation; free zone comparison; setup guides |
| InvestAD (Abu Dhabi) | https://www.investad.ae | Abu Dhabi investment promotion; sector incentives; project pipeline |
| NAFIS (Emiratisation) | https://www.nafis.ae | Emiratisation registration; salary incentives; quota compliance tracking |

---

## 8. LABOR, VISA & IMMIGRATION

| Portal | URL | Description |
|---|---|---|
| MOHRE Smart Services | https://smartservices.mohre.gov.ae | Online worker registration, permit renewal, eDNOD system, employer compliance |
| MOHRE Main Portal | https://www.mohre.gov.ae | Labour law guidance; ministry services; WPS verification |
| GDRFA Dubai | https://www.gdrfad.gov.ae | Dubai residence visa stamping, entry permits, status checks, Golden/Green Visa |
| ICP (Federal Identity & Citizenship) | https://www.icp.gov.ae | Emirates ID, residence visas (Abu Dhabi/Northern Emirates), citizenship applications |
| TASHEEL | https://www.tasheel.ae | Authorised MOHRE typing centres; labour contract attestation |
| Amer (Dubai Immigration) | https://amer.gov.ae | Dubai-specific immigration typing and document services |
| UAE PASS | https://uaepass.ae | National digital identity; e-signature; single sign-on for all government services |

---

## 9. ENVIRONMENT & SUSTAINABILITY

| Portal | URL | Description |
|---|---|---|
| MOCCAE | https://www.moccae.gov.ae | Environmental permits, EIA approvals, waste management, biodiversity |
| MOCCAE EIA/Services Portal | https://services.moccae.gov.ae | Online EIA submission, environmental permit applications |
| Environment Agency Abu Dhabi (EAD) | https://www.ead.gov.ae | Abu Dhabi EIA, nature reserves, environmental data and annual reports |
| Abu Dhabi Waste Management (Tadweer) | https://www.tadweer.ae | Abu Dhabi waste collection; C&D waste; recycling data |
| Bee'ah (Sharjah) | https://www.beeah.ae | Sharjah waste management; recycling; environmental services |
| UAE Net Zero 2050 | https://uaenetzero.ae | UAE Net Zero strategy documents, progress reports, sectoral plans |
| COP28 Legacy | https://www.cop28.com | COP28 Dubai 2023 — outcomes, pledges, loss & damage fund, UAE Consensus |
| Masdar (Clean Energy) | https://www.masdar.ae | Masdar City; renewable energy projects; Abu Dhabi Future Energy Company |
| FANR (Nuclear Regulation) | https://www.fanr.gov.ae | Nuclear safety regulation; environmental radiation monitoring; Barakah NPP |
| UAE Green Building Council (UAEGBC) | https://www.uaegbc.org | Green building advocacy; LEED, Estidama, WELL resources |
| Estidama | https://www.estidama.org | Abu Dhabi Pearl Building Rating System (PBRS); manual download; credit library |
| OSHAD Abu Dhabi | https://www.oshad.ae | OHS framework; all Codes of Practice available for free download |

---

## 10. HEALTH, EDUCATION & SOCIAL PORTALS

| Portal | URL | Description |
|---|---|---|
| Dubai Health Authority (DHA) | https://www.dha.gov.ae | Healthcare licensing, mandatory health insurance, Shehab licensing portal |
| Abu Dhabi Dept. of Health (DoH) | https://www.doh.gov.ae | Healthcare licensing in Abu Dhabi; Malaffi unified medical record |
| SEHA (Abu Dhabi Health Services) | https://www.seha.ae | Public hospitals network in Abu Dhabi; patient portal |
| MOHAP | https://www.mohap.gov.ae | Drug registration, medical device approval, Northern Emirates health licences |
| KHDA (Dubai) | https://www.khda.gov.ae | Private school and university regulation in Dubai; inspection reports publicly available |
| ADEK (Abu Dhabi) | https://www.adek.gov.ae | Private school regulation in Abu Dhabi; fee guidelines; inspection ratings |
| Commission for Academic Accreditation (CAA) | https://www.caa.ae | University and HEI accreditation status; list of licensed institutions |
| UAE University (UAEU) | https://www.uaeu.ac.ae | UAE's oldest public university; research, engineering, law, medicine |
| Khalifa University | https://www.ku.ac.ae | STEM-focused public university; QS top 200; Abu Dhabi |

---

## 11. KEY PDF DOCUMENTS & OFFICIAL DOWNLOAD LINKS

| Document | Access / Download |
|---|---|
| **UAE Constitution (English)** | https://www.government.ae/en/about-the-uae/the-uae-government/government-of-uae/the-constitution |
| **Federal Decree-Law No. 33 of 2021 — Labour Law** | https://elaws.moj.gov.ae — search "33 of 2021" |
| **Federal Decree-Law No. 9 of 2024 — Labour Law Amendment** | https://elaws.moj.gov.ae — search "9 of 2024 labour" |
| **Federal Decree-Law No. 32 of 2021 — Companies Law** | https://elaws.moj.gov.ae — search "32 of 2021" |
| **Federal Decree-Law No. 20 of 2025 — Companies Law Amendment** | https://elaws.moj.gov.ae — effective January 2026 |
| **Federal Decree-Law No. 47 of 2022 — Corporate Tax** | https://www.tax.gov.ae/en/legislation.aspx |
| **Federal Decree-Law No. 45 of 2021 — Data Protection (PDPL)** | https://elaws.moj.gov.ae |
| **Federal Law No. 6 of 2018 — Arbitration Law** | https://elaws.moj.gov.ae |
| **Federal Decree-Law No. 51 of 2023 — Bankruptcy Law** | https://elaws.moj.gov.ae — effective May 2024 |
| **Federal Decree-Law No. 34 of 2021 — Cybercrime Law** | https://elaws.moj.gov.ae |
| **Federal Law No. 24 of 1999 — Environment Protection** | https://elaws.moj.gov.ae |
| **Federal Law No. 12 of 2018 — Integrated Waste Management** | https://elaws.moj.gov.ae |
| **Dubai Building Code 2021 (DBC)** | https://www.dm.gov.ae/municipality-business/planning-and-construction/dubai-building-code-2/ |
| **UAE Fire and Life Safety Code of Practice 2018** | https://www.dcd.gov.ae (Technical section; or request via Dubai Civil Defence) |
| **Abu Dhabi OSHAD-SF & All Codes of Practice** | https://www.oshad.ae/resources — free download library |
| **Estidama Pearl Building Rating System (PBRS) Manual** | https://www.estidama.org/rating-systems/pearl-building-rating-system.aspx |
| **Dubai Green Building Regulations** | https://www.dm.gov.ae (search Green Building) |
| **UAE Energy Strategy 2050 Brochure** | https://www.moid.gov.ae — Energy/Strategy section |
| **UAE NDC 2023 (Nationally Determined Contribution)** | https://www.moccae.gov.ae — Climate Change / UNFCCC submissions |
| **ESMA / MoIAT Standards Catalogue** | https://www.moiat.gov.ae/standardization/standards-catalogue |
| **MOHRE Standard Employment Contract Templates** | https://www.mohre.gov.ae/en/services/contracts.aspx |
| **GCAA RPAS / Drone Regulations** | https://www.gcaa.gov.ae/en/rpas |
| **FTA VAT User Guide** | https://www.tax.gov.ae/en/guides.aspx |
| **FTA Corporate Tax Guides** | https://www.tax.gov.ae/en/corporatetaxguides |
| **DLD/RERA Rental Index** | https://www.rera.gov.ae/en/rental-index |
| **DIAC Arbitration Rules 2022** | https://www.diac.ae/arbitration-rules/ |
| **Federal Decree-Law No. 6 of 2009 — Nuclear Energy** | https://www.fanr.gov.ae/legislation |
| **Federal Decree-Law No. 8 of 2017 — VAT Law** | https://www.tax.gov.ae/en/legislation.aspx |

---

## 12. DATA & STATISTICS PORTALS

| Portal | URL | Description |
|---|---|---|
| Federal Competitiveness & Statistics Centre (FCSC) | https://www.fcsc.gov.ae | National statistics; population, GDP, trade data |
| Dubai Statistics Centre | https://www.dsc.gov.ae | Dubai-specific economic, social, demographic data |
| Abu Dhabi Statistics Centre (SCAD) | https://www.scad.gov.ae | Abu Dhabi detailed statistical reports; census data |
| CBUAE Financial Statistics | https://www.centralbank.ae/en/financial-stability-and-statistics | Banking data, monetary statistics, payment system data |
| DFM Market Data | https://www.dfm.ae/market-data | Live and historical equity/sukuk prices for Dubai |
| ADX Market Data | https://www.adx.ae/adx/english/market/statistics | Abu Dhabi exchange market statistics |
| ADNOC Investor Relations | https://www.adnoc.ae/en/investor-relations | Production volumes, reserves, ADNOC financial performance |
| World Bank UAE Profile | https://data.worldbank.org/country/AE | International comparison data, development indicators |
| IMF UAE Country Reports | https://www.imf.org/en/countries/UAE | Annual Article IV assessment; downloadable PDF |

---

## 13. SMART GOVERNMENT & DIGITAL SERVICES

| Portal | URL | Description |
|---|---|---|
| UAE PASS | https://uaepass.ae | National digital identity and e-signature; authentication for all government services |
| TAMM (Abu Dhabi) | https://www.tamm.abudhabi | 700+ Abu Dhabi government services in one platform |
| Dubai Now / Dubai Pulse | https://www.dubaipulse.gov.ae | Dubai smart services and open data platform; 700+ datasets |
| UAE Open Data (Bayanat) | https://bayanat.ae | Federal open data portal; datasets from multiple ministries |
| Smart Dubai | https://www.smartdubai.ae | Dubai digital transformation; happiness meter; smart city projects |
| Abu Dhabi Digital Authority (ADDA) | https://www.adda.gov.ae | Abu Dhabi digital government policy; cloud, data sharing, open data |

---

## 14. GCC & INTERNATIONAL CROSS-REFERENCE RESOURCES

| Resource | URL | Description |
|---|---|---|
| GCC Secretariat | https://www.gcc-sg.org | Gulf Cooperation Council; GCC laws, decisions, unified standards |
| GCC Patent Office | https://www.gccpo.org | GCC-wide patent filings covering all 6 member states including UAE |
| GCC Standardization Organisation (GSO) | https://www.gso.org.sa | GCC-wide technical standards applicable in UAE |
| UNCITRAL Model Law (Arbitration) | https://uncitral.un.org | UAE Arbitration Law (Federal Law 6/2018) based on UNCITRAL Model Law |
| ICSID (Investment Disputes) | https://icsid.worldbank.org | UAE is member; investor-state dispute resolution |
| New York Convention | https://www.newyorkconvention.org | UAE acceded 2006; arbitral award enforcement in 172 countries |
| HCCH Apostille Convention | https://www.hcch.net | UAE joined 2021; UAE Apostilles issued since 14 January 2025 |
| IMO (Maritime) | https://www.imo.org | International Maritime Organization; UAE member; MARPOL, SOLAS applicable |
| ICAO (Aviation) | https://www.icao.int | International Civil Aviation Organization; UAE member; standards applicable |
| IAEA (Nuclear) | https://www.iaea.org | UAE-IAEA safeguards agreement; FANR is national regulatory body |

---

*Last updated: July 2026. All URLs verified against official sources. Some portal content may require Arabic-language navigation or user registration.*



## 15. How to Use This Directory Professionally

This directory is designed as a navigation layer. It does not replace the live government portal. For any filing, application or regulated decision, use the portal listed here to obtain the current form, fee, submission route, Arabic legal text and authentication requirement. Many UAE services require UAE PASS login, an Emirates ID, a corporate account, a trade licence number, a tenancy contract, a site plan, a land number, an establishment card, a tax registration number or an authorised representative.

### 15.1 Common authentication and document requirements

| Requirement | Where commonly used | Notes |
|---|---|---|
| UAE PASS | Federal and emirate digital services, e-signature, document access | National digital identity and single sign-on. Confirm whether the service requires verified UAE PASS, face verification or Emirates ID scan. |
| Emirates ID | ICP, banks, telecoms, healthcare, tenancy, labour and most resident services | Required for most resident-facing services and KYC. |
| Trade licence | DET/DED, free zones, tax, bank account, utility commercial accounts | Must match activity, legal name and establishment card where applicable. |
| Establishment card / immigration file | Visa and employee sponsorship services | Issued through GDRFA/ICP or relevant free zone. |
| Tenancy contract | Ejari/Tawtheeq, utility connection, visa and school admission | Dubai uses Ejari; Abu Dhabi uses Tawtheeq; other emirates use local systems. |
| Tax Registration Number (TRN) | FTA VAT, excise and corporate tax services | Managed through FTA/EmaraTax. |
| Site plan / affection plan | Building permits, utility connections, Civil Defence and road NOCs | Issued by land/municipality authority; must match title/plot data. |
| No Objection Certificate (NOC) | Construction, utilities, roads, telecom, aviation height, fire safety | NOC sequence varies by emirate and project jurisdiction. |

### 15.2 Government service workflow patterns

Most UAE portals follow one of these patterns:

| Pattern | Steps | Examples |
|---|---|---|
| Individual resident service | UAE PASS login → Emirates ID verification → service form → upload documents → payment → digital certificate | Emirates ID renewal, visa status, police certificate, health card, tenancy registration. |
| Company licensing service | Create account → reserve trade name → initial approval → lease/office proof → activity approvals → payment → licence issue | DET/Dubai licensing, ADDED, free-zone company setup. |
| Construction permit service | Consultant login → land data → design documents → NOC routing → Civil Defence/utility approvals → permit issue → inspections → completion certificate | Dubai Municipality, DMT/TAMM, Trakhees, Sharjah Municipality. |
| Tax compliance service | EmaraTax login → registration → TRN issue → periodic filing → payment/refund → audit correspondence | VAT, excise, corporate tax. |
| Regulated-sector licensing | Pre-application meeting → fit-and-proper / technical dossier → regulator review → conditional approval → inspection → licence | DFSA/FSRA/VARA/CBUAE healthcare regulators and Civil Defence contractors. |
| Dispute service | Register case/claim → pay filing fee → upload contract/evidence → hearing/mediation → judgment/award → enforcement | Dubai Courts, ADJD, DIFC Courts, ADGM Courts, DIAC, ADCCAC. |

## 16. Federal Government Portals — Expanded Use Notes

| Authority / Portal | URL | Primary users | Key services | Practical notes |
|---|---|---|---|---|
| UAE Government Portal | https://u.ae | Residents, citizens, investors, professionals | Life-event guides, federal service links, strategy pages, legal and policy explainers | Use as a starting point, not as final legal text. Follow links to ministry/regulator portals for filing. |
| UAE PASS | https://uaepass.ae | All residents/citizens needing digital government access | Digital identity, single sign-on, electronic signature | Many services require a verified account; corporate users may still need separate authority accounts. |
| ICP | https://icp.gov.ae | Residents, PROs, employers, travellers | Emirates ID, entry permits, residence visas, citizenship, status checks | For Abu Dhabi and Northern Emirates residency, ICP is central; Dubai immigration also uses GDRFA/Amer. |
| Federal Tax Authority | https://tax.gov.ae | Businesses, tax agents, individuals in taxable contexts | VAT, excise tax, corporate tax, guides, public clarifications | Use EmaraTax for filings; keep records and check deadline calendars. |
| EmaraTax | https://eservices.tax.gov.ae | Tax registrants and agents | Registration, returns, payments, refunds, correspondence | Requires account access and often UAE PASS; supports VAT, excise and corporate tax. |
| Ministry of Justice | https://www.moj.gov.ae | Lawyers, litigants, notaries, researchers | Federal courts, notary, legal services, lawyer registration | Use with elaws for legal text. Court jurisdiction varies by emirate. |
| UAE Legislation / elaws | https://elaws.moj.gov.ae | Lawyers, compliance, researchers | Official laws, decrees and regulations | Arabic text is controlling; English translations may be unofficial. |
| MOHRE | https://www.mohre.gov.ae | Employers, employees, PROs, labour lawyers | Work permits, labour contracts, WPS, complaints, Emiratisation | Mainland private-sector labour compliance is generally MOHRE-led, except special regimes such as DIFC/ADGM/free-zone employment systems. |
| Ministry of Economy | https://www.economy.gov.ae | Companies, consumers, IP owners, agencies | Commercial agencies, consumer protection, IP links, competition policy | Corporate licensing is often local/free-zone, but federal commercial law and policy sit here. |
| Ministry of Finance | https://www.mof.gov.ae | Finance teams, investors, public-policy users | Federal budget, fiscal policy, tax treaty material, procurement context | Useful for macro and treaty research. |
| MOCCAE | https://www.moccae.gov.ae | Environmental consultants, importers, agriculture/fisheries users | Environmental policy, CITES, food/agriculture, climate, biodiversity | Project-level EIAs may be emirate-level unless federal/cross-border. |
| MoIAT | https://www.moiat.gov.ae | Manufacturers, product importers, labs | Standards, conformity, industrial strategy, Make it in the Emirates | ESMA functions are integrated; ECAS/EQM product conformity matters often route here. |
| TDRA | https://tdra.gov.ae | Telecom operators, ICT firms, app/platform operators | Spectrum, telecom licensing, digital-government standards | Telecom and digital services compliance should be checked here. |
| GCAA | https://www.gcaa.gov.ae | Aviation companies, drone operators, developers near air corridors | Air operator certificates, drone rules, aviation safety, airspace | Tall structures and drones may need GCAA / local aviation NOC. |
| FANR | https://www.fanr.gov.ae | Nuclear, radiation, medical/industrial radiation users | Nuclear safety, radiation source licensing, Barakah oversight | Radiation sources in hospitals/industry require licensing and safety controls. |
| CBUAE | https://www.centralbank.ae | Banks, insurers, payment providers, compliance teams | Banking supervision, insurance, exchange houses, payment services, AML | Financial-sector registers and consumer complaint routes are here. |
| UAE Cybersecurity Council | https://www.cybersecurity.gov.ae | CII operators, government, regulated firms | Cyber policy, incident coordination, frameworks | Check sector-specific incident reporting rules. |
| UAE Data Office | https://www.uaedataoffice.gov.ae | Data controllers/processors, privacy officers | PDPL policy and data governance | Live enforcement guidance should be verified. |

## 17. Construction, Engineering and Real Estate Portals — Expanded Use Notes

| Authority | URL | Jurisdiction | Services | Key professional documents / actions |
|---|---|---|---|---|
| Dubai Municipality | https://www.dm.gov.ae | Dubai mainland municipality areas | Building permits, planning, environmental health, food safety, public health, waste, Dubai Building Code | Consultant/contractor registration, building permit, inspection request, completion certificate, DBC downloads. |
| Dubai Building Code | https://www.dm.gov.ae/municipality-business/planning-and-construction/dubai-building-code-2/ | Dubai | Code volumes and technical rules | Use for building planning, structure, MEP, fire interfaces, accessibility and energy requirements. |
| Trakhees | https://www.trakhees.ae | PCFC / JAFZA / selected Dubai World jurisdictions | Building permits, EHS, environmental permits | Required where project sits in Trakhees jurisdiction rather than DM alone. |
| Dubai Civil Defence | https://www.dcd.gov.ae | Dubai | Fire/life-safety plan review, inspections, certificates | Fire drawings, alarm/sprinkler approvals, annual fire safety certificate. |
| DEWA | https://www.dewa.gov.ae | Dubai | Electricity/water connection, Shams Dubai, EV charging | Load application, NOC, meter, solar PV approval, infrastructure coordination. |
| RTA | https://www.rta.ae | Dubai | Roads, traffic, metro, parking, transport permits | Traffic impact assessment, road NOC, access approvals, heavy vehicle permits. |
| Dubai Land Department / RERA | https://dubailand.gov.ae | Dubai real estate | Registration, Oqood, broker/developer regulation, rental index | Title deeds, off-plan registration, escrow, Ejari, rental disputes via RDC. |
| Ejari | https://www.ejari.ae | Dubai tenancy | Tenancy registration | Required for utilities, visas and many administrative steps. |
| DMT | https://www.dmt.gov.ae | Abu Dhabi emirate | Municipalities, transport, building codes, land services | Building permit, consultant/contractor classification, property services. |
| TAMM | https://www.tamm.abudhabi | Abu Dhabi government services | One-stop services | Many DMT, ADREC, DoH, education and resident services route through TAMM. |
| ADREC | https://www.adrec.gov.ae | Abu Dhabi real estate | Property registration, Tawtheeq, real-estate professionals | Verify property services and tenancy workflows live. |
| Tawtheeq | through TAMM / ADREC | Abu Dhabi tenancy | Lease registration | Required for many government and utility services. |
| ADDC | https://www.addc.ae | Abu Dhabi city/western region | Electricity and water distribution | Connection application, inspection, metering, bills. |
| AADC | https://www.aadc.ae | Al Ain region | Electricity and water distribution | Similar utility functions for Al Ain area. |
| Sharjah Municipality | https://www.shjmun.gov.ae | Sharjah | Building permits, health, tenancy and municipal services | Verify current building and tenancy routes. |
| SEWA | https://www.sewa.gov.ae | Sharjah | Electricity, water and gas | Utility connection and billing. |
| Etihad Water & Electricity / FEWA legacy | https://www.etihadwe.ae | Northern Emirates | Electricity and water | FEWA branding may appear in legacy sources; verify current portal. |
| RAK Municipality | https://www.mun.rak.ae | Ras Al Khaimah | Building permits, planning, local services | RAK-specific engineering workflows. |
| Fujairah Municipality | https://www.fujmun.gov.ae | Fujairah | Building permits, planning, environmental health | Verify URL and service route live. |

## 18. Courts, Arbitration and Legal Research — Expanded Use Notes

| Institution | URL | Jurisdiction / scope | Services | Notes |
|---|---|---|---|---|
| Dubai Courts | https://www.dc.gov.ae | Dubai local courts | Case filing, notary, execution, judgments, RDC links | Arabic procedures dominate; legal representation may be needed for complex cases. |
| Abu Dhabi Judicial Department | https://www.adjd.gov.ae | Abu Dhabi courts | Case filing, notary, mediation, family guidance, execution | Many services integrated with TAMM. |
| Federal Supreme Court | https://www.sc.gov.ae | Federal constitutional/high matters | Constitutional and federal jurisdiction | Use for federal legal research and court hierarchy. |
| DIFC Courts | https://www.difccourts.ae | DIFC / opt-in common law disputes | eRegistry, SCT, CFI, CA, wills | English-language common law court. |
| ADGM Courts | https://www.adgm.com/legal-framework/adgm-courts | ADGM | eCourts, commercial and civil disputes | English common-law framework. |
| DIAC | https://www.diac.ae | Arbitration, Dubai / UAE and international | Case registration, rules, arbitrator lists | 2022 Rules apply to many new cases; check arbitration clause. |
| ADCCAC / Abu Dhabi Chamber | https://www.abudhabichamber.ae | Abu Dhabi arbitration and conciliation | Arbitration/conciliation services | Verify current rules and fee schedule. |
| UAE Legislation | https://elaws.moj.gov.ae | Federal legal text | Laws, decrees, decisions | Arabic official source. |
| Dubai Legal Portal | https://dlp.dubai.gov.ae | Dubai laws | Dubai laws and regulations | Useful for emirate-level legislation. |
| DIFC Laws | https://www.difc.ae/business/laws-regulations/ | DIFC laws | Laws, regulations, consultation papers | Use for Companies, Employment, Data Protection, Insolvency and Courts Rules. |
| ADGM Rulebooks | https://en.adgm.thomsonreuters.com/rulebooks | ADGM laws/regulations | Regulations, FSRA rules, court rules | Official ADGM hosted rulebook. |

### 18.1 Legal research workflow

1. Identify whether the matter is federal, emirate-level, free-zone, common-law free-zone or sector-regulated.
2. Check the official Arabic text on elaws or the relevant emirate/free-zone portal.
3. Use English translations for working convenience only unless the portal states they are authoritative.
4. Check implementing regulations, cabinet decisions, ministerial decisions and circulars.
5. For disputes, check whether the contract has a court jurisdiction clause or arbitration clause.
6. For construction and real estate, cross-check Civil Code, emirate building law, municipality circulars, Civil Defence, land department rules and contract terms.

## 19. Business, Tax and Free Zone Portals — Expanded Directory

| Portal / Authority | URL | Services | Typical documents |
|---|---|---|---|
| Dubai Economy and Tourism / DET | https://www.dubaided.gov.ae | Trade name, initial approval, licence issue/renewal, consumer protection | Passport/Emirates ID, tenancy/Ejari, NOC, activity approval. |
| Abu Dhabi DED / ADDED | https://www.added.gov.ae | Abu Dhabi mainland licensing and investor services | Trade name, licence application, approvals, lease. |
| Invest in Dubai | https://invest.dubai.ae | Dubai licensing/startup gateway | Activity selection, business name, partner details, payment. |
| Invest in Abu Dhabi | https://www.investinabudhabi.gov.ae | Abu Dhabi investment promotion | Sector opportunities, incentives and setup support. |
| JAFZA | https://www.jafza.ae | Free-zone company setup, logistics, warehouses | FZE/FZCO licence, lease, shareholder docs. |
| DMCC | https://www.dmcc.ae | Free-zone licensing and commodities ecosystems | Company portal, office lease, KYC, commodity approvals. |
| DIFC | https://www.difc.ae | Financial/professional free-zone licensing | Registrar filings, DFSA if regulated, lease, compliance. |
| ADGM | https://www.adgm.com | Company registration and FSRA regulation | Incorporation, registered office, beneficial ownership, FSRA licence if regulated. |
| RAKEZ | https://www.rakez.com | RAK free-zone and non-free-zone packages | Licence, flexi desk/warehouse, visa allocation. |
| SAIF Zone | https://www.saif-zone.com | Sharjah airport free-zone | Trade/industrial/service licence, facilities. |
| Hamriyah Free Zone | https://www.hfza.ae | Industrial/free-zone services | Lease, EHS approvals, trade licence. |
| Ajman Free Zone | https://www.afz.ae | SME/free-zone licensing | Packages, visa eligibility, office/flexi desk. |
| Fujairah Creative City | https://www.creativecity.ae | Media and creative licences | Freelancer/company packages. |
| Shams | https://www.shams.ae | Media and creative licensing | Company licence, media activities. |
| FTA / EmaraTax | https://tax.gov.ae / https://eservices.tax.gov.ae | VAT, excise, corporate tax | TRN, returns, tax agent authorization. |
| Ministry of Economy | https://www.economy.gov.ae | IP, commercial agencies, competition, consumer policy | Trademark applications, agency registration, complaints. |

## 20. Financial Services and Digital Assets Portals

| Regulator / Market | URL | Scope | Practical use |
|---|---|---|---|
| CBUAE | https://www.centralbank.ae | Banks, insurers, exchange houses, finance companies, payment services | Check regulated-entity status, complaint channels, AML guidance. |
| DFSA | https://www.dfsa.ae | DIFC financial services | Authorised firm register, rulebook, consultation papers, enforcement notices. |
| FSRA | https://www.adgm.com/operating-in-adgm/financial-services-regulatory-authority | ADGM financial services | Financial services permissions, virtual assets, funds, banking, insurance. |
| CMA / SCA transition | https://www.sca.gov.ae | UAE capital markets outside DIFC/ADGM | Public markets, brokers, listed companies; verify current CMA portal/name live. |
| DFM | https://www.dfm.ae | Dubai stock market | Investor numbers, listed companies, market data. |
| ADX | https://www.adx.ae | Abu Dhabi stock market | Market data, listed companies, investor services. |
| Nasdaq Dubai | https://www.nasdaqdubai.com | DIFC exchange | Sukuk, bonds, international listings. |
| VARA | https://www.vara.ae | Dubai virtual assets outside DIFC | VASP licences, rulebooks, public register. |

## 21. Healthcare, Education and Social Portals

| Authority | URL | Scope | Key services |
|---|---|---|---|
| DHA | https://www.dha.gov.ae | Dubai healthcare | Facility licensing, professional licensing, health insurance, clinical standards. |
| DoH Abu Dhabi | https://www.doh.gov.ae | Abu Dhabi healthcare | Licensing, insurance, Malaffi, public health policy. |
| MOHAP | https://www.mohap.gov.ae | Federal/Northern Emirates health | Drug registration, medical device, public health, facility licensing in non-DHA/DoH areas. |
| DHCC | https://www.dhcc.ae | Healthcare free zone | Healthcare and wellness facility licensing in Dubai Healthcare City. |
| SEHA | https://www.seha.ae | Abu Dhabi public healthcare network | Hospitals, clinics, patient services. |
| Malaffi | https://www.malaffi.ae | Abu Dhabi HIE | Health information exchange. |
| KHDA | https://www.khda.gov.ae | Dubai private education | School ratings, university branches, fee frameworks. |
| ADEK | https://www.adek.gov.ae | Abu Dhabi education | School licensing, inspections, education policy. |
| Ministry of Education | https://www.moe.gov.ae | Federal education | Public schools, curriculum, higher-education policy. |
| Commission for Academic Accreditation | https://www.caa.ae | Higher education accreditation | Licensed institutions and accredited programmes. |

## 22. Immigration, Labour and Identity Portals

| Portal | URL | Services | Notes |
|---|---|---|---|
| ICP | https://icp.gov.ae | Emirates ID, entry permits, residence, status, citizenship | Abu Dhabi/Northern Emirates residence and federal identity services. |
| GDRFA Dubai | https://www.gdrfad.gov.ae | Dubai entry permits, residence, status, Golden Visa services | Dubai-specific immigration route. |
| Amer | https://amer.gov.ae | Dubai immigration typing/service centres | Useful for PRO and resident services. |
| MOHRE | https://www.mohre.gov.ae | Work permits, labour contracts, WPS, labour disputes | Mainland private-sector employment. |
| Tasheel | https://www.tasheel.ae | MOHRE typing centres | Labour contract and work-permit support. |
| NAFIS | https://www.nafis.gov.ae | Emiratisation programmes | Employer compliance, incentives, job matching. |
| ILOE | https://www.iloe.ae | Unemployment insurance | Mandatory scheme for eligible employees; check current categories and fees. |

## 23. Environment, Energy, Transport and Safety Portals

| Authority | URL | Scope | Services |
|---|---|---|---|
| MOCCAE | https://www.moccae.gov.ae | Federal environment, climate, food/agriculture | Environmental policy, CITES, climate, biodiversity, pesticides/fertiliser. |
| EAD | https://www.ead.gov.ae | Abu Dhabi environment | EIA, air/water/waste permits, biodiversity, protected areas. |
| Dubai Municipality Environment | https://www.dm.gov.ae | Dubai environmental health and permitting | Waste, environmental permits, food safety, public health. |
| Tadweer | https://www.tadweer.ae | Abu Dhabi waste | Waste collection, C&D waste, hazardous waste, recycling. |
| Beeah | https://www.beeahgroup.com | Sharjah/UAE waste and environmental services | Waste management and sustainability services. |
| DEWA | https://www.dewa.gov.ae | Dubai electricity/water | Utility connections, tariffs, solar PV, EV charging. |
| DoE Abu Dhabi | https://www.doe.gov.ae | Abu Dhabi energy regulation | Electricity/water policy, tariffs, regulation. |
| EWEC | https://www.ewec.ae | Abu Dhabi power/water procurement | PPAs, generation procurement, forecasts. |
| Masdar | https://www.masdar.ae | Renewable energy and sustainability | Projects, Masdar City, clean-energy development. |
| RTA | https://www.rta.ae | Dubai roads and transport | Roads, metro, buses, taxis, parking, driving licensing. |
| GCAA | https://www.gcaa.gov.ae | Civil aviation | Air safety, drone approvals, aviation licensing. |
| MOEI | https://www.moei.gov.ae | Federal energy/infrastructure | Roads, housing, maritime, energy policy. |
| Dubai Civil Defence | https://www.dcd.gov.ae | Dubai fire/life safety | Plan approvals, inspections, fire certificates. |
| Civil Defence UAE / MOI | https://www.moi.gov.ae | Federal civil defence context | National civil defence policy and services. |

## 24. Professional Bodies, Standards and Technical References

| Body / Portal | URL | Relevance |
|---|---|---|
| Society of Engineers UAE | https://www.soeuae.ae | Engineering membership and professional networking; some licensing workflows may request membership. |
| RICS Middle East | https://www.rics.org/middle-east | Quantity surveying, valuation, project management and dispute services. |
| CIBSE UAE / Middle East | https://www.cibse.org | Building services engineering guidance and CPD. |
| PMI UAE Chapter | https://www.pmiuae.org | Project management certification and events. |
| FIDIC | https://fidic.org | Construction contract forms and training. |
| BSI | https://www.bsigroup.com | British Standards, widely used in UAE engineering. |
| ASTM | https://www.astm.org | Materials and testing standards. |
| NFPA | https://www.nfpa.org | Fire and life safety standards heavily referenced in UAE practice. |
| IEC | https://www.iec.ch | Electrical standards. |
| ISO | https://www.iso.org | Management systems, technical standards and product standards. |
| ASHRAE | https://www.ashrae.org | HVAC, energy and indoor-air-quality standards. |
| GSO | https://www.gso.org.sa | GCC standards framework. |

## 25. Open Data, Statistics and Research Portals

| Portal | URL | Data type | Notes |
|---|---|---|---|
| FCSC | https://fcsc.gov.ae | UAE federal statistics | Population, economy, trade and social indicators. |
| Bayanat / UAE Open Data | https://bayanat.ae | Federal datasets | Useful for machine-readable public data. |
| Dubai Statistics Centre | https://www.dsc.gov.ae | Dubai statistics | Population, GDP, prices, business data. |
| SCAD | https://www.scad.gov.ae | Abu Dhabi statistics | Population, economic, social and environmental data. |
| Dubai Pulse | https://www.dubaipulse.gov.ae | Dubai open data | Smart-city and government datasets. |
| CBUAE Statistics | https://www.centralbank.ae | Banking and monetary data | Monetary, banking, financial stability and payments statistics. |
| DFM / ADX market data | https://www.dfm.ae / https://www.adx.ae | Securities market data | Listed company and market data. |
| World Bank UAE profile | https://data.worldbank.org/country/united-arab-emirates | International comparative data | Useful for cross-country benchmarking; not a UAE official source. |
| IMF UAE reports | https://www.imf.org/en/Countries/ARE | Article IV and macro reports | Authoritative international secondary source. |

## 26. Red-Flag Verification Checklist

Before relying on any entry in this directory, verify the following live items:

| Item | Why verification is needed |
|---|---|
| Fees | UAE portals frequently update service fees, knowledge fees, innovation fees and typing-centre charges. |
| URLs | Portal redesigns may move service pages or consolidate authorities. |
| Regulator names | SCA/CMA, ESMA/MoIAT and other institutional changes may affect naming and jurisdiction. |
| Service eligibility | Many services depend on nationality, residence emirate, licence type, free-zone jurisdiction or sponsor status. |
| Legal text | Arabic official text controls; English translations may be unofficial. |
| Implementation dates | 2025–2026 legal reforms may have staged commencement or implementing decisions. |
| Free-zone requirements | Office, visa quota, audit, substance and activity restrictions vary by package and year. |
| Construction NOC sequence | Sequence varies by emirate, free zone, plot type and project size. |
| Tax deadlines | Deadlines depend on financial year, registration date and tax type. |
| Employment rules | Mainland, free-zone, DIFC and ADGM employment frameworks differ. |

## 27. Practical Portal Bundles by Task

### 27.1 Starting a mainland Dubai company

1. Use DET / Invest in Dubai for trade-name reservation, activity selection and initial approval.
2. Check whether the activity needs external approval from Dubai Municipality, DHA, KHDA, RTA, DCD, VARA, TDRA or another regulator.
3. Secure tenancy/Ejari where required.
4. Issue trade licence.
5. Open immigration establishment file through GDRFA/Amer if visas are needed.
6. Register with MOHRE if hiring mainland employees.
7. Register with FTA/EmaraTax if VAT/corporate tax obligations apply.
8. Open bank account and complete UBO/KYC requirements.

### 27.2 Starting a free-zone company

1. Select free zone based on activity, office needs, visa quota, bankability and customer location.
2. Reserve name and submit KYC/shareholder documents.
3. Lease flexi desk, office, warehouse or land as required.
4. Obtain licence and establishment card.
5. Apply for visas through the free-zone immigration route.
6. Register for corporate tax and VAT where applicable.
7. Check whether mainland trading requires a distributor, branch, dual licence or mainland permit.

### 27.3 Filing a construction permit in Dubai

1. Appoint a Dubai Municipality-registered consultant.
2. Confirm plot data, land use, height, setbacks and zoning.
3. Prepare architectural, structural and MEP drawings to Dubai Building Code.
4. Route NOCs: DEWA, RTA, DCD, drainage, telecom, aviation/height and other plot-specific authorities.
5. Obtain building permit.
6. Carry out stage inspections.
7. Secure completion certificate and utility energisation.
8. Register property/units with DLD/RERA where relevant.

### 27.4 Resolving a labour dispute

1. Gather contract, WPS payment evidence, termination notice and correspondence.
2. File complaint with MOHRE or the relevant free-zone/DIFC/ADGM employment authority.
3. Attend mediation or administrative review.
4. If unresolved or above administrative threshold, obtain referral to court/tribunal.
5. File claim with competent court or tribunal.
6. Enforce judgment through execution department if required.

### 27.5 Verifying a federal law

1. Search elaws/MOJ by law number and year.
2. Confirm whether you are viewing Federal Law, Federal Decree-Law, Cabinet Decision, Ministerial Decision or circular.
3. Check commencement article and repeal/amendment provisions.
4. Search for later amendments by the same subject.
5. Use English translation only as a convenience; compare with Arabic for formal reliance.

## 28. Directory Maintenance Notes

This directory should be refreshed at least quarterly for live professional use. Priority update areas are: corporate tax and free-zone qualifying-income rules; capital-market regulator transition; labour and Emiratisation rules; visa categories and fees; construction permitting portals; Civil Defence requirements; data protection and cybersecurity enforcement; health insurance expansion; rail and transport launch dates; and municipality/free-zone service-fee schedules.

### Appendix R1: Federal legal research — portal audit checklist

| Step | Check | Evidence to save |
|---|---|---|
| 1 | Confirm the current authority name and portal URL | Screenshot/PDF of portal header and service page |
| 2 | Confirm whether UAE PASS or corporate login is required | Login requirement note and account owner |
| 3 | Confirm latest service fee and payment channel | Fee table, invoice sample or portal payment page |
| 4 | Confirm required documents and file formats | Checklist from authority portal |
| 5 | Confirm processing time and escalation route | SLA, contact centre number or case-ticket route |
| 6 | Confirm whether Arabic text or notarised translation is required | Authority instruction or legal provision |
| 7 | Save final submission reference | Application number, receipt and certificate |

### Appendix R2: Dubai construction permitting — portal audit checklist

| Step | Check | Evidence to save |
|---|---|---|
| 1 | Confirm the current authority name and portal URL | Screenshot/PDF of portal header and service page |
| 2 | Confirm whether UAE PASS or corporate login is required | Login requirement note and account owner |
| 3 | Confirm latest service fee and payment channel | Fee table, invoice sample or portal payment page |
| 4 | Confirm required documents and file formats | Checklist from authority portal |
| 5 | Confirm processing time and escalation route | SLA, contact centre number or case-ticket route |
| 6 | Confirm whether Arabic text or notarised translation is required | Authority instruction or legal provision |
| 7 | Save final submission reference | Application number, receipt and certificate |

### Appendix R3: Abu Dhabi construction permitting — portal audit checklist

| Step | Check | Evidence to save |
|---|---|---|
| 1 | Confirm the current authority name and portal URL | Screenshot/PDF of portal header and service page |
| 2 | Confirm whether UAE PASS or corporate login is required | Login requirement note and account owner |
| 3 | Confirm latest service fee and payment channel | Fee table, invoice sample or portal payment page |
| 4 | Confirm required documents and file formats | Checklist from authority portal |
| 5 | Confirm processing time and escalation route | SLA, contact centre number or case-ticket route |
| 6 | Confirm whether Arabic text or notarised translation is required | Authority instruction or legal provision |
| 7 | Save final submission reference | Application number, receipt and certificate |

### Appendix R4: Free-zone company formation — portal audit checklist

| Step | Check | Evidence to save |
|---|---|---|
| 1 | Confirm the current authority name and portal URL | Screenshot/PDF of portal header and service page |
| 2 | Confirm whether UAE PASS or corporate login is required | Login requirement note and account owner |
| 3 | Confirm latest service fee and payment channel | Fee table, invoice sample or portal payment page |
| 4 | Confirm required documents and file formats | Checklist from authority portal |
| 5 | Confirm processing time and escalation route | SLA, contact centre number or case-ticket route |
| 6 | Confirm whether Arabic text or notarised translation is required | Authority instruction or legal provision |
| 7 | Save final submission reference | Application number, receipt and certificate |

### Appendix R5: Tax compliance — portal audit checklist

| Step | Check | Evidence to save |
|---|---|---|
| 1 | Confirm the current authority name and portal URL | Screenshot/PDF of portal header and service page |
| 2 | Confirm whether UAE PASS or corporate login is required | Login requirement note and account owner |
| 3 | Confirm latest service fee and payment channel | Fee table, invoice sample or portal payment page |
| 4 | Confirm required documents and file formats | Checklist from authority portal |
| 5 | Confirm processing time and escalation route | SLA, contact centre number or case-ticket route |
| 6 | Confirm whether Arabic text or notarised translation is required | Authority instruction or legal provision |
| 7 | Save final submission reference | Application number, receipt and certificate |

### Appendix R6: Labour and immigration — portal audit checklist

| Step | Check | Evidence to save |
|---|---|---|
| 1 | Confirm the current authority name and portal URL | Screenshot/PDF of portal header and service page |
| 2 | Confirm whether UAE PASS or corporate login is required | Login requirement note and account owner |
| 3 | Confirm latest service fee and payment channel | Fee table, invoice sample or portal payment page |
| 4 | Confirm required documents and file formats | Checklist from authority portal |
| 5 | Confirm processing time and escalation route | SLA, contact centre number or case-ticket route |
| 6 | Confirm whether Arabic text or notarised translation is required | Authority instruction or legal provision |
| 7 | Save final submission reference | Application number, receipt and certificate |

### Appendix R7: Healthcare licensing — portal audit checklist

| Step | Check | Evidence to save |
|---|---|---|
| 1 | Confirm the current authority name and portal URL | Screenshot/PDF of portal header and service page |
| 2 | Confirm whether UAE PASS or corporate login is required | Login requirement note and account owner |
| 3 | Confirm latest service fee and payment channel | Fee table, invoice sample or portal payment page |
| 4 | Confirm required documents and file formats | Checklist from authority portal |
| 5 | Confirm processing time and escalation route | SLA, contact centre number or case-ticket route |
| 6 | Confirm whether Arabic text or notarised translation is required | Authority instruction or legal provision |
| 7 | Save final submission reference | Application number, receipt and certificate |

### Appendix R8: Financial-services licensing — portal audit checklist

| Step | Check | Evidence to save |
|---|---|---|
| 1 | Confirm the current authority name and portal URL | Screenshot/PDF of portal header and service page |
| 2 | Confirm whether UAE PASS or corporate login is required | Login requirement note and account owner |
| 3 | Confirm latest service fee and payment channel | Fee table, invoice sample or portal payment page |
| 4 | Confirm required documents and file formats | Checklist from authority portal |
| 5 | Confirm processing time and escalation route | SLA, contact centre number or case-ticket route |
| 6 | Confirm whether Arabic text or notarised translation is required | Authority instruction or legal provision |
| 7 | Save final submission reference | Application number, receipt and certificate |

### Appendix R9: Real-estate registration — portal audit checklist

| Step | Check | Evidence to save |
|---|---|---|
| 1 | Confirm the current authority name and portal URL | Screenshot/PDF of portal header and service page |
| 2 | Confirm whether UAE PASS or corporate login is required | Login requirement note and account owner |
| 3 | Confirm latest service fee and payment channel | Fee table, invoice sample or portal payment page |
| 4 | Confirm required documents and file formats | Checklist from authority portal |
| 5 | Confirm processing time and escalation route | SLA, contact centre number or case-ticket route |
| 6 | Confirm whether Arabic text or notarised translation is required | Authority instruction or legal provision |
| 7 | Save final submission reference | Application number, receipt and certificate |
