# UAE Engineering Codes and Building Regulations

This document provides a comprehensive and exhaustive overview of the engineering codes, building regulations, and standards governing construction in the United Arab Emirates (UAE), with a focus on the Emirate of Dubai and the Emirate of Abu Dhabi. It is intended for use by architects, engineers, contractors, and developers operating within the UAE construction industry.

---

## 1. OVERVIEW OF UAE STANDARDS ECOSYSTEM

The UAE's regulatory framework for construction is a multi-tiered system involving federal authorities and emirate-level municipalities. Each emirate has the authority to issue its own building codes and regulations, which are often based on international standards but adapted to the local climate, soil conditions, and cultural requirements.

### 1.1 Federal Authorities

#### Ministry of Industry and Advanced Technology (MoIAT)
*   **Role:** Formerly the Emirates Authority for Standardization & Metrology (ESMA), MoIAT is the federal body responsible for developing and publishing **UAE.S** national standards.
*   **Emirates Conformity Assessment Scheme (ECAS):** A mandatory certification scheme for products with high health and safety impacts, including building materials like cement, steel, and glass.
*   **Energy Labelling:** MoIAT manages the energy efficiency labelling for electrical appliances (ACs, refrigerators, lamps) under the UAE.S 5010 series.
*   **Steel Reinforcement:** Cabinet Decision No. 121/2023 mandates that all steel bars for concrete reinforcement must comply with UAE.S GSO ISO 6935-2 or BS 4449.
*   **Cement Standards:** UAE.S 197-1 (Cement - Part 1: Composition, specifications and conformity criteria for common cements).

#### Ministry of Interior - General Directorate of Civil Defence
*   **Role:** Issues the **UAE Fire and Life Safety Code of Practice**, which is mandatory across all emirates.
*   **Approval:** All building designs must receive a No Objection Certificate (NOC) from Civil Defence before a building permit is issued.
*   **Inspections:** Civil Defence conducts inspections during construction and before the issuance of the Completion Certificate.
*   **Licensing:** Civil Defence licenses fire safety consultants, contractors, and suppliers.

### 1.2 Emirate-Level Authorities

#### Dubai Municipality (DM)
*   **Jurisdiction:** The entire Emirate of Dubai, excluding certain free zones.
*   **Primary Code:** **Dubai Building Code (DBC) 2021**.
*   **Portals:** Dubai BPS (Building Permit System) for all permit applications.
*   **Technical Committees:** DM maintains several technical committees for structural, MEP, and architectural standards.

#### Abu Dhabi Department of Municipalities and Transport (DMT)
*   **Jurisdiction:** Abu Dhabi City, Al Ain, and Al Dhafra.
*   **Primary Code:** **Abu Dhabi International Building Code (ADIBC)**.
*   **Sustainability:** Oversees the **Estidama** Pearl Rating System.
*   **Municipalities:** Includes Abu Dhabi City Municipality (ADM), Al Ain City Municipality (AAM), and Al Dhafra Region Municipality (DRM).

#### Trakhees (PCFC)
*   **Jurisdiction:** Jebel Ali Free Zone (JAFZA), Dubai World, Palm Jumeirah, and Nakheel communities.
*   **Regulations:** Applies the **Trakhees Technical Regulations** (Blue Book), which are heavily based on the International Building Code (IBC) and NFPA standards.
*   **EHS:** Environment, Health and Safety (EHS) department oversees construction safety and environmental compliance.

#### Dubai Development Authority (DDA)
*   **Jurisdiction:** Free zones such as Dubai Design District (d3), Dubai Studio City, Dubai Production City, Dubai Science Park, and TECOM areas.
*   **Regulations:** Applies the **Dubai Building Code (DBC)** with specific DDA amendments and Master Planning Guidelines.

---

## 2. DUBAI BUILDING CODE (DBC) 2021 — DEEP DETAIL

The Dubai Building Code (DBC) 2021 is a unified code that replaced several previous regulations, including the Dubai Municipality Green Building Regulations (2010/2014), the Dubai Universal Design Code, and various circulars. It is structured into 10 volumes.

### 2.1 Volume 1: Administration

Volume 1 outlines the legal and administrative framework for construction in Dubai.

#### 2.1.1 Permit Types and Processes
*   **Building Permit:** The primary authorization to commence construction. Requires approved architectural, structural, and MEP drawings.
*   **No Objection Certificate (NOC):** Required from:
    *   **DEWA:** For electricity and water connection.
    *   **RTA:** For road access and traffic impact.
    *   **Civil Defence:** For fire safety systems.
    *   **Etisalat / DU:** For telecommunications.
    *   **Dubai Municipality (Environment):** For waste management and environmental impact.
*   **Mobilization Permit:** Allows for site hoarding, site offices, and preliminary works.
*   **Structural Permit:** Issued for the structural skeleton of the building (piling, foundations, superstructure).
*   **Completion Certificate:** Issued after final inspection, confirming the building is built according to approved plans.
*   **Occupancy Certificate:** Required before the building can be legally occupied.

#### 2.1.2 DM Fees Table (2026 Schedule)
The base DM permit fee is generally calculated based on the Built-Up Area (BUA).

| Project Type | Fee Rate | Minimum Fee | Maximum Cap |
| :--- | :--- | :--- | :--- |
| **Residential (Villas/Townhouses)** | AED 1.00 per sq. ft | AED 200 | N/A |
| **Commercial / Mixed-Use** | AED 1.00 per sq. ft | AED 500 | N/A |
| **Industrial (Warehouses/Factories)** | AED 0.50 per sq. ft | AED 1,000 | AED 250,000 |
| **Fit-out / Internal Alterations** | AED 1.00 per sq. ft | AED 200 | N/A |
| **Mobilization Permit** | AED 0.20 per sq. ft | AED 20,000 | N/A |
| **Demolition Permit** | AED 500 - 5,000 | AED 500 | N/A |
| **Building Completion Certificate** | AED 200 - 500 | AED 200 | N/A |
| **NOC for Infrastructure** | AED 1,000 - 5,000 | AED 1,000 | N/A |
| **TPI Registration Fee** | AED 10,000 | AED 10,000 | N/A |
| **Consultant License Renewal** | AED 5,000 - 15,000 | AED 5,000 | N/A |

#### 2.1.3 Inspection Stages in Detail
Dubai Municipality conducts inspections at critical milestones to ensure compliance with the approved design and the DBC.
1.  **Foundation Inspection:**
    *   **Timing:** After excavation and before pouring the raft or footings.
    *   **Checks:** Soil bearing capacity (verified by geotechnical report), reinforcement size and spacing, concrete cover, and waterproofing.
2.  **Structural Inspection (Skeleton):**
    *   **Timing:** Conducted at every floor level for columns, shear walls, and slabs.
    *   **Checks:** Reinforcement details, formwork stability, concrete grade (verified by delivery notes), and embedded MEP conduits.
3.  **MEP Rough-in Inspection:**
    *   **Timing:** Before closing walls or ceilings.
    *   **Checks:** Pipe pressure tests (water and gas), electrical wiring insulation, ductwork sealing, and fire damper installation.
4.  **Final Inspection (Completion):**
    *   **Timing:** After all works are finished and before the Completion Certificate is issued.
    *   **Checks:** Architectural finishes, structural stability, MEP functionality, fire safety systems (Civil Defence approval required), and accessibility features.

#### 2.1.4 Third-Party Inspection (TPI) Requirements
For complex or high-rise projects, DM requires the appointment of an independent Third-Party Inspection agency.
*   **Mandatory for:** Buildings >G+12, buildings with complex geometry, and buildings with high occupancy risk.
*   **Scope:** Structural integrity, fire safety systems, and façade safety.
*   **Criteria:** TPI firms must be registered with DM and have ISO 17020 accreditation.
*   **Reporting:** TPI must submit monthly reports to DM and a final certification upon completion.

#### 2.1.5 Approved Consultants List Criteria
Consultants are classified into categories based on their technical capability:
*   **G+1:** Limited to ground plus one floor (Villas). Requires 1 licensed architect and 1 licensed structural engineer.
*   **G+4:** Limited to ground plus four floors. Requires 2 licensed architects and 2 licensed structural engineers.
*   **G+12:** Limited to ground plus twelve floors. Requires 3 licensed architects and 3 licensed structural engineers.
*   **Unlimited:** No height restriction. Requires 5+ licensed architects and 5+ licensed structural engineers, plus specialized MEP and fire safety engineers.
*   **Criteria:** Minimum number of licensed engineers, years of experience in the UAE, and a portfolio of successfully completed projects.

### 2.2 Volume 2: Building Planning

Volume 2 covers land use, occupancy, and spatial planning.

#### 2.2.1 Full Occupancy Classification Table (A–I)
Buildings are classified based on their primary use to determine fire safety and egress requirements.

| Group | Occupancy Type | Sub-types / Examples |
| :--- | :--- | :--- |
| **A-1** | **Assembly (Fixed Seating)** | Theaters, Concert Halls, Cinemas |
| **A-2** | **Assembly (Food/Drink)** | Restaurants, Nightclubs, Banquet Halls |
| **A-3** | **Assembly (Worship/General)** | Places of Worship, Libraries, Museums, Art Galleries |
| **A-4** | **Assembly (Indoor Sports)** | Arenas, Skating Rinks, Swimming Pools (with seating) |
| **A-5** | **Assembly (Outdoor Sports)** | Stadiums, Amusement Parks, Grandstands |
| **B** | **Business** | Offices, Banks, Professional Services, Post Offices, Laboratories |
| **E** | **Educational** | Schools, Kindergartens, Nurseries (up to 12th grade) |
| **F-1** | **Factory (Moderate Hazard)** | Manufacturing of furniture, textiles, paper |
| **F-2** | **Factory (Low Hazard)** | Manufacturing of brick, glass, metal |
| **H-1** | **High Hazard (Explosives)** | Detonation hazard |
| **H-2** | **High Hazard (Flammable)** | Deflagration hazard |
| **H-3** | **High Hazard (Combustible)** | Readily support combustion |
| **H-4** | **High Hazard (Toxic)** | Health hazard |
| **H-5** | **High Hazard (Semiconductor)** | Hazardous production materials |
| **I-1** | **Institutional (Assisted Living)** | Nursing homes, group homes |
| **I-2** | **Institutional (Medical)** | Hospitals, clinics (24-hour care) |
| **I-3** | **Institutional (Restraint)** | Prisons, detention centers |
| **I-4** | **Institutional (Day Care)** | Adult or child day care |
| **M** | **Mercantile** | Retail Stores, Department Stores, Markets, Showrooms |
| **R-1** | **Residential (Transient)** | Hotels, Motels, Boarding Houses |
| **R-2** | **Residential (Multi-family)** | Apartments, Condominiums, Dormitories |
| **R-3** | **Residential (One/Two Family)** | Villas, Townhouses |
| **R-4** | **Residential (Care/Assisted)** | Residential care facilities (5-16 occupants) |
| **S-1** | **Storage (Moderate Hazard)** | Warehouses for wood, paper, textiles |
| **S-2** | **Storage (Low Hazard)** | Warehouses for metal, glass, brick |
| **U** | **Utility** | Agricultural buildings, retaining walls, tanks, towers |

#### 2.2.2 Mixed-Use Floor Stacking Rules
*   **Separation:** Different occupancies must be separated by fire-rated assemblies (typically 2-hour).
*   **Stacking:** Residential units are generally not permitted below commercial or industrial uses unless specific acoustic and fire separation measures are met.
*   **Access:** Separate entrances and lift cores are often required for residential and commercial components in a mixed-use tower.
*   **Mechanical Floors:** Often used as a buffer between different occupancy zones.
*   **Podium:** Commercial and retail uses are typically located in the podium, with residential or office towers above.

#### 2.2.3 Floor Area Ratio (FAR) Calculations Worked Example
**Scenario:** A plot in Business Bay with an area of 2,500 m² and an allowable FAR of 5.0.
*   **Total Allowable GFA:** 2,500 m² × 5.0 = 12,500 m².
*   **Exclusions:**
    *   Parking floors (above or below ground).
    *   Mechanical plant rooms (up to 10% of GFA).
    *   Balconies (up to 10% of the floor area).
    *   Staircases and lift shafts (at each floor).
    *   Refuge areas (in high-rise buildings).
*   **Calculation:** If the building has 10 floors of 1,250 m² each, the GFA is 12,500 m², which exactly meets the FAR limit.

#### 2.2.4 Plot Coverage
*   **Residential Villas:** Maximum 60% of the plot area.
*   **Commercial / Mixed-Use:** Up to 80% or 100% in certain high-density zones (e.g., Deira, Bur Dubai).
*   **Industrial:** Maximum 60% to 70%.
*   **Open Space:** Minimum 20% of the plot area must be landscaped or open space in residential zones.

#### 2.2.5 Setback Table for Dubai Zones
Setbacks are measured from the plot boundary to the building face.

| Zone | Front Setback | Side Setback | Rear Setback |
| :--- | :--- | :--- | :--- |
| **R1 (Residential Villa)** | 6.0m | 1.5m | 3.0m |
| **R2 (Townhouse)** | 3.0m | 0.0m (Attached) | 3.0m |
| **R3 (Apartment)** | 3.0m | 1.5m | 3.0m |
| **B1 (Business/Office)** | 3.0m | 3.0m | 3.0m |
| **B2 (Small Office)** | 1.5m | 1.5m | 1.5m |
| **C1 (Commercial)** | 0.0m (Podium) | 0.0m (Podium) | 3.0m |
| **C2 (Retail)** | 1.5m | 1.5m | 1.5m |
| **I1 (Light Industrial)** | 6.0m | 3.0m | 3.0m |
| **I2 (Heavy Industrial)** | 3.0m | 3.0m | 3.0m |
| **HT (Hotel/Tourism)** | 6.0m | 6.0m | 6.0m |

#### 2.2.6 Height Limitations Near Airports (DCAA OLS)
The Dubai Civil Aviation Authority (DCAA) enforces Obstacle Limitation Surfaces (OLS) to protect flight paths.
*   **Inner Horizontal Surface:** 45m above airport elevation.
*   **Conical Surface:** 5% slope up to 145m.
*   **Approach Surface:** 2% slope.
*   **Transitional Surface:** 14.3% slope.
*   **NOC:** Any building exceeding 15m in height or located within 15km of DXB or DWC airports requires a DCAA NOC.
*   **Obstruction Lighting:** Mandatory for all buildings >45m or those within flight paths.

#### 2.2.7 Mezzanine Rules
*   **Area:** A mezzanine cannot exceed 50% of the floor area of the room it is located in.
*   **Height:** Minimum clear height below and above the mezzanine is 2.4m.
*   **Openness:** Mezzanines must remain open to the floor below, except for railings.
*   **Egress:** Must have at least one direct exit to a staircase if the occupant load exceeds 10.
*   **Use:** Mezzanines are typically used for storage or office space within a larger industrial or commercial unit.

#### 2.2.8 Basement Regulations
*   **Depth Limits:** Generally limited to 4 levels below ground unless a special geotechnical study is provided.
*   **Waterproofing:** Class 3 (Dry) waterproofing per BS 8102 is mandatory for all habitable basements.
*   **Ventilation:** Mechanical ventilation with 6 ACH (Air Changes per Hour) is required.
*   **Drainage:** Sump pumps are mandatory for all basements to prevent flooding.
*   **Access:** Must have at least two independent exits if the area exceeds 500 m².


### 2.3 Volume 3: Construction

Volume 3 focuses on structural design and material specifications, ensuring the safety and durability of buildings in Dubai's unique environment.

#### 2.3.1 Concrete Durability Requirements (EN 206)
Dubai's soil and groundwater are highly aggressive, characterized by high chloride and sulfate concentrations. The DBC mandates strict durability requirements based on EN 206 exposure classes.

| Exposure Class | Description | Minimum Cover (mm) | Max w/c Ratio | Minimum Cement (kg/m³) | Cement Type |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **XC1** | Dry or permanently wet | 25 | 0.60 | 260 | OPC / GGBS |
| **XC2** | Wet, rarely dry | 30 | 0.55 | 280 | OPC / GGBS |
| **XC3** | Moderate humidity | 35 | 0.50 | 300 | OPC / GGBS |
| **XC4** | Cyclic wet and dry | 40 | 0.45 | 320 | OPC / GGBS |
| **XS1** | Airborne salt (Coastal) | 50 | 0.40 | 340 | SRPC + Microsilica |
| **XS2** | Submerged in sea water | 60 | 0.35 | 360 | SRPC + Microsilica |
| **XS3** | Tidal and splash zones | 75 | 0.35 | 380 | SRPC + Microsilica |
| **XA1** | Slightly aggressive | 40 | 0.50 | 300 | SRPC |
| **XA2** | Moderately aggressive | 50 | 0.45 | 320 | SRPC |
| **XA3** | Highly aggressive | 75 | 0.40 | 340 | SRPC |

*   **UAE Sabkha:** For foundations in sabkha soil (highly saline), Sulfate Resistant Portland Cement (SRPC) is mandatory.
*   **GGBS:** Ground Granulated Blast-furnace Slag is often used as a partial replacement (up to 70%) for cement to improve durability and reduce heat of hydration.
*   **Microsilica:** Typically added at 5-10% by weight of cement to reduce permeability in severe chloride environments.

#### 2.3.2 Reinforcement Ratios and Details
The DBC follows Eurocode 2 (EN 1992) for reinforcement design.

| Structural Element | Minimum Steel Ratio | Maximum Steel Ratio |
| :--- | :--- | :--- |
| **Beams (Tension)** | 0.2% | 4.0% |
| **Beams (Compression)** | 0.2% | 4.0% |
| **Columns** | 1.0% | 4.0% (8.0% at laps) |
| **Slabs (High Yield)** | 0.13% | 4.0% |
| **Shear Walls (Vertical)** | 0.25% | 4.0% |
| **Shear Walls (Horizontal)** | 0.25% | 4.0% |

*   **Lap Splice Lengths:** Typically 40d to 50d (where d is the bar diameter). For Grade 500B steel in C35/45 concrete, the lap length is approximately 45d.
*   **Mechanical Couplers:** Mandatory for bars >32mm in diameter and in high-seismic zones for bars >20mm.

#### 2.3.3 Construction Tolerances
*   **Verticality (Columns/Walls):** 6mm per 3m height; maximum 25mm for the entire building height.
*   **Level (Slabs/Beams):** 6mm per 3m length; maximum 20mm for the entire floor.
*   **Cross-section Dimensions:** +10mm / -5mm for columns and beams.
*   **Position of Reinforcement:** ±5mm for slabs and walls; ±10mm for beams and columns.

#### 2.3.4 Concrete Mix Design for Hot Weather
Dubai's summer temperatures (often >45°C) require specialized concrete practices.
*   **Temperature Limit:** Fresh concrete temperature must not exceed 32°C at the time of placement.
*   **Ice/Chilled Water:** Mandatory use of flake ice or chilled water in the mix to control temperature.
*   **Retarders:** Admixtures are used to extend the setting time and maintain workability.
*   **Curing:**
    *   Minimum 7 days of continuous wet curing (hessian and polythene).
    *   Shading of the pouring area is mandatory when ambient temperature >35°C.
    *   Windbreaks must be used to prevent rapid evaporation and plastic shrinkage cracking.

### 2.4 Volume 4: Fire Protection

Volume 4 is aligned with the UAE Fire and Life Safety Code and focuses on life safety and property protection.

#### 2.4.1 Full Means of Egress Table
The means of egress must be designed to allow all occupants to reach a safe area within a specified time.

| Occupancy Type | Occupant Load Factor (m²/person) | Max Travel Distance (Sprinklered) | Max Dead-End Corridor |
| :--- | :--- | :--- | :--- |
| **Assembly (Fixed Seating)** | 0.65 | 76m | 6m |
| **Assembly (Unfixed Seating)** | 1.4 | 76m | 6m |
| **Business (Offices)** | 9.3 | 76m | 15m |
| **Educational (Classrooms)** | 1.9 | 76m | 15m |
| **Mercantile (Retail)** | 2.8 | 61m | 15m |
| **Residential (Apartments)** | 18.6 | 61m | 15m |
| **Hotel (Guest Rooms)** | 18.6 | 61m | 15m |
| **Industrial (Factories)** | 9.3 | 76m | 15m |
| **Storage (Warehouses)** | 27.9 | 76m | 15m |

*   **Exit Width Calculation:**
    *   Stairways: 7.6mm per occupant.
    *   Other egress components (doors, corridors): 5.1mm per occupant.
    *   Minimum door width: 900mm clear.
    *   Minimum corridor width: 1,200mm (Residential), 1,800mm (Institutional).

#### 2.4.2 Fire Compartment Sizes and Ratings
*   **Residential:** Maximum 2,000 m² per compartment; 2-hour fire rating.
*   **Commercial:** Maximum 3,000 m² per compartment; 2-hour fire rating.
*   **Parking:** Maximum 4,500 m² per compartment; 2-hour fire rating.
*   **High-Hazard:** Maximum 500 m² per compartment; 3-hour fire rating.

#### 2.4.3 Fire Door Ratings
*   **FD30S:** 30-minute fire resistance with smoke seals (Internal office doors).
*   **FD60S:** 60-minute (Staircase enclosures in buildings <23m).
*   **FD90S:** 90-minute (Staircase enclosures in buildings >23m).
*   **FD120S:** 120-minute (High-risk areas, plant rooms, transformer rooms).

#### 2.4.4 Firefighting Access Roads
*   **Width:** Minimum 6.0m clear width.
*   **Clearance:** Minimum 4.5m vertical clearance.
*   **Turning Radius:** Minimum 12.5m (Outer), 7.5m (Inner).
*   **Dead-end Roads:** If >45m, must have a turnaround (Hammerhead or Cul-de-sac).
*   **Load Bearing:** Must support 25 tonnes for standard vehicles and 60 tonnes for aerial platforms.

#### 2.4.5 Fire-fighting Shafts and Lifts
Mandatory for buildings >18m in height.
*   **Shaft:** Must be 2-hour fire-rated and include a fire-fighting lift, a fire-fighting stair, and a fire main.
*   **Fire-fighting Lift:**
    *   Minimum load: 630 kg.
    *   Minimum speed: 1.0 m/s (must reach top floor in <60 seconds).
    *   Power: Secondary power supply (generator) mandatory.
*   **Fire Command Centre (FCC):** Mandatory for high-rise buildings; minimum 10 m² at the main entrance level.

#### 2.4.6 Dry and Wet Risers
*   **Dry Riser:** Permitted for buildings up to 50m in height. Inlet breeching must be within 18m of the fire access road.
*   **Wet Riser:** Mandatory for buildings >50m in height.
*   **Pressure:** Minimum residual pressure of 0.7 bar at the highest outlet; maximum 7.0 bar (requires pressure reducing valves if higher).


### 2.5 Volume 5: Mechanical (HVAC)

Volume 5 covers the design and installation of HVAC and ventilation systems, focusing on indoor air quality and thermal comfort in Dubai's extreme climate.

#### 2.5.1 Outside Design Conditions (Dubai)
HVAC systems must be sized to handle the peak summer loads while maintaining indoor comfort.

| Season | Dry Bulb (DB) | Wet Bulb (WB) |
| :--- | :--- | :--- |
| **Summer (Peak)** | 46°C | 28°C |
| **Summer (Dehumidification)** | 35°C | 29°C |
| **Winter** | 10°C | 7°C |

*   **Indoor Design Conditions:**
    *   Temperature: 22°C to 24°C DB.
    *   Relative Humidity: 50% ± 10%.
    *   Air Velocity: < 0.25 m/s in the occupied zone.

#### 2.5.2 Cooling Load Calculation and Software
*   **Method:** Must use the **ASHRAE Heat Balance Method** or **Radiant Time Series (RTS)** method.
*   **Software:** Approved tools include Carrier HAP, Trane TRACE 700, IES-VE, and EnergyPlus.
*   **Safety Factors:**
    *   Sensible Load: Max 10%.
    *   Latent Load: Max 5%.
    *   Total Load: Max 10%.

#### 2.5.3 Duct Sizing and Velocity Limits
Ductwork must be sized to minimize noise and pressure drop.

| System Type | Main Duct Velocity (m/s) | Branch Duct Velocity (m/s) |
| :--- | :--- | :--- |
| **Residential** | 5.0 - 7.5 | 3.0 - 4.5 |
| **Offices / Schools** | 7.5 - 10.0 | 4.5 - 6.0 |
| **Retail / Theaters** | 10.0 - 12.5 | 6.0 - 7.5 |
| **Industrial** | 12.5 - 15.0 | 7.5 - 10.0 |

*   **Material:** Galvanized steel (ASTM A653) or pre-insulated panels (PIR/PU).
*   **Insulation:** Minimum 25mm fiberglass or 20mm PIR for indoor ducts; 50mm for outdoor ducts.

#### 2.5.4 Pressurization of Escape Routes
To prevent smoke ingress into staircases and lift lobbies during a fire.
*   **Standard:** EN 12101-6.
*   **Pressure Differential:** 50 Pa (±10 Pa) with all doors closed.
*   **Airflow:** Minimum 0.75 m/s through the open door of the fire floor.
*   **Relief:** Overpressure relief dampers or VFD-controlled fans are mandatory.

#### 2.5.5 Kitchen Exhaust Systems
*   **Class A (High Grease):** Frying, grilling, charbroiling. Requires UV-C filtration or electrostatic precipitators (ESP) and a fire suppression system (Ansul).
*   **Class B (Moderate Grease):** Ovens, ranges, griddles. Requires high-efficiency baffle filters.
*   **Class C (Low Grease):** Steaming, boiling, dishwashing. Requires standard grease filters.
*   **Ductwork:** Minimum 1.2mm stainless steel or 1.6mm carbon steel, fully welded, with 2-hour fire-rated enclosure.

#### 2.5.6 Car Park Ventilation
*   **General Ventilation:** Minimum 6 ACH to maintain CO levels < 30 ppm.
*   **Smoke Clearance:** Minimum 10 ACH or a dedicated smoke extract system.
*   **Jet Fans:** Often used for impulse ventilation to eliminate stagnant pockets.
*   **Sensors:** CO and NO2 sensors must be distributed throughout the car park (1 per 400 m²).

### 2.6 Volume 6: Plumbing

Volume 6 covers water supply, drainage, and storm water systems.

#### 2.6.1 Fixture Unit Calculations (Hunter's Method)
The DBC uses Water Supply Fixture Units (WSFU) and Drainage Fixture Units (DFU) to size pipes.

| Fixture Type | WSFU (Private) | WSFU (Public) | DFU |
| :--- | :--- | :--- | :--- |
| **WC (Flush Tank)** | 3 | 5 | 4 |
| **WC (Flush Valve)** | 6 | 10 | 6 |
| **Lavatory / Wash Basin** | 1 | 2 | 1 |
| **Shower** | 2 | 4 | 2 |
| **Bathtub** | 2 | 4 | 2 |
| **Kitchen Sink** | 2 | 4 | 2 |
| **Urinal (Flush Valve)** | - | 5 | 2 |

#### 2.6.2 Pipe Sizing and Materials
*   **Water Supply:** PPR (Polypropylene Random), PEX, or Copper. Max velocity 2.4 m/s.
*   **Drainage:** PVC-U (Class 4/5), HDPE, or Cast Iron. Minimum slope 1:50 for pipes <75mm; 1:100 for pipes >100mm.
*   **Venting:** Every trap must be protected by a vent pipe to prevent siphonage. S-traps are prohibited; P-traps are mandatory.

#### 2.6.3 Grease Interceptor Sizing
Mandatory for all commercial kitchens to prevent fat, oil, and grease (FOG) from entering the public sewer.
*   **Sizing:** Based on the number of meals per hour or the flow rate of connected fixtures.
*   **Minimum Capacity:** 50 GPM (Gallons Per Minute) for small restaurants; 500+ GPM for large hotel kitchens.
*   **Design:** Must have at least two compartments and a sampling port.

#### 2.6.4 Roof Drainage and Storm Water
Dubai experiences infrequent but intense rainfall.
*   **Rainfall Intensity:**
    *   10-year return (Design): 75mm/hour.
    *   100-year return (Overflow): 110mm/hour.
*   **System:** Gravity or Siphonic (for large roof areas).
*   **Overflow:** Mandatory secondary drainage (scuppers or separate piping) to prevent roof collapse if the primary system is blocked.

#### 2.6.5 Surge Tank and Pump Sizing
*   **Surge Tank:** Required to buffer the incoming water supply. Minimum 24-hour storage capacity for residential buildings.
*   **Transfer Pumps:** Duty/Standby configuration mandatory.
*   **Booster Pumps:** Variable Speed Drive (VSD) mandatory to maintain constant pressure.


### 2.7 Volume 7: Electrical

Volume 7 covers the design and installation of electrical systems, ensuring safety, reliability, and efficiency in accordance with DEWA (Dubai Electricity & Water Authority) regulations.

#### 2.7.1 Load Calculations and Demand Factors
Electrical loads must be calculated to determine the required transformer capacity and cable sizes.

| Occupancy Type | Lighting Load (W/m²) | Power Load (W/m²) | Demand Factor |
| :--- | :--- | :--- | :--- |
| **Residential (Villas)** | 10 - 15 | 20 - 30 | 0.4 - 0.6 |
| **Apartments** | 15 - 20 | 30 - 40 | 0.6 - 0.8 |
| **Offices** | 10 - 12 | 40 - 60 | 0.8 - 0.9 |
| **Retail / Shops** | 20 - 30 | 50 - 80 | 0.9 - 1.0 |
| **Warehouses** | 5 - 10 | 10 - 20 | 0.5 - 0.7 |

*   **Diversity Factor:** Applied to the total connected load to account for the fact that not all loads will be active simultaneously.

#### 2.7.2 Power Factor Correction
Low power factor leads to inefficient energy use and penalties from DEWA.
*   **Requirement:** Minimum Power Factor of **0.90** lagging.
*   **Equipment:** Automatic Power Factor Correction (APFC) panels with capacitor banks.
*   **Location:** Typically installed at the Main Low Voltage (MLV) panel.

#### 2.7.3 Harmonic Distortion Limits (IEEE 519)
Non-linear loads (VFDs, LED lighting, computers) introduce harmonics into the system.
*   **THD (Total Harmonic Distortion):** Must be < 5% at the Point of Common Coupling (PCC).
*   **Individual Harmonics:**
    *   3rd, 5th, 7th: < 3%.
    *   11th, 13th: < 2%.
*   **Mitigation:** Active or passive harmonic filters are required for large non-linear loads.

#### 2.7.4 Earthing and Bonding Systems
*   **System Type:** TN-S (Separate Neutral and Earth) is the standard for Dubai.
*   **Earth Pit:** Minimum two earth pits per building; resistance must be < 1.0 Ohm.
*   **Bonding:** All metallic parts (pipes, ducts, structural steel) must be equipotentially bonded.

#### 2.7.5 Lightning Protection (EN 62305)
*   **Risk Assessment:** Mandatory for all buildings >60m or those with high risk (hospitals, schools).
*   **System:** Air terminals (Faraday cage or ESE), down conductors, and dedicated earth pits.
*   **Surge Protection:** Type 1 and Type 2 Surge Protection Devices (SPDs) are mandatory at the main and sub-main panels.

#### 2.7.6 Emergency Power and UPS
*   **Emergency Generator:** Mandatory for high-rise buildings to power life safety systems (fire pumps, fire lifts, emergency lighting).
*   **UPS (Uninterruptible Power Supply):** Required for data centers, server rooms, and critical medical equipment.
    *   **Tier III:** N+1 redundancy minimum for data centers.

### 2.8 Volume 8: Energy Efficiency

Volume 8 integrates the Dubai Green Building Regulations (DGBR) and focuses on reducing the environmental impact of buildings.

#### 2.8.1 Prescriptive Compliance Path (U-Values)
Buildings must meet minimum thermal performance standards for the building envelope.

| Building Element | Maximum U-Value (W/m²K) | Minimum R-Value (m²K/W) |
| :--- | :--- | :--- |
| **Roof** | 0.20 | 5.00 |
| **External Walls** | 0.57 | 1.75 |
| **Ground Floor Slab** | 0.44 | 2.27 |
| **Glazing (U-Value)** | 1.90 | - |
| **Glazing (SHGC)** | 0.25 | - |

*   **SHGC (Solar Heat Gain Coefficient):** Critical for controlling solar heat gain in Dubai's tropical climate.
*   **WWR (Window-to-Wall Ratio):**
    *   Residential: Max 40%.
    *   Commercial: Max 50%.

#### 2.8.2 Energy Modelling and Performance Path
For complex buildings, the performance path allows for flexibility if the total energy use is lower than the prescriptive baseline.
*   **Software:** EnergyPlus, IES-VE, or eQUEST.
*   **Baseline:** Based on ASHRAE 90.1-2019 Appendix G.
*   **EUI (Energy Use Intensity) Targets:**
    *   Offices: < 120 kWh/m²/year.
    *   Residential: < 150 kWh/m²/year.

#### 2.8.3 Renewable Energy (Solar PV)
*   **Requirement:** Mandatory for all buildings with a roof area >500 m².
*   **Capacity:** Must provide at least 5% of the total connected load or cover 25% of the roof area with PV panels.
*   **Net Metering:** Excess energy can be exported to the DEWA grid under the "Shams Dubai" initiative.

#### 2.8.4 Energy Sub-metering and BAS
*   **Sub-metering:** Mandatory for all major loads (HVAC, Lighting, Power) and for each tenant in a multi-tenant building.
*   **BAS (Building Automation System):** Mandatory for buildings >5,000 m². Must monitor and control HVAC, lighting, and energy use.


### 2.9 Volume 10: Accessibility

#### 2.9.1 Ramp Details
*   **Maximum Slope:** 1:12 (8.33%).
*   **Maximum Cross-slope:** 2%.
*   **Landing:** Required every 9m of horizontal run.
*   **Width:** Minimum 1,200mm clear width.

#### 2.9.2 Hearing Loop Systems
*   Mandatory in assembly areas, reception desks, and meeting rooms >50 m².

---

## 3. ABU DHABI INTERNATIONAL BUILDING CODE (ADIBC) — DEEP DETAIL

The ADIBC is the primary building code for the Emirate of Abu Dhabi, issued by the Department of Municipalities and Transport (DMT).

### 3.1 Basis and Structure
The ADIBC is based on the **International Building Code (IBC) 2018** with specific Abu Dhabi amendments.

#### 3.1.1 Chapter Structure
1.  **Chapter 1: Scope and Administration** - Defines the limits of applicability and enforcement.
2.  **Chapter 2: Definitions** - Standardizes terminology.
3.  **Chapter 3: Use and Occupancy Classification** - Groups buildings by hazard and use.
4.  **Chapter 4: Special Detailed Requirements Based on Use and Occupancy** - High-rise, atria, etc.
5.  **Chapter 5: General Building Heights and Areas** - Limits based on construction type.
6.  **Chapter 6: Types of Construction** - Fire resistance of materials.
7.  **Chapter 7: Fire and Smoke Protection Features** - Compartmentation and firestopping.
8.  **Chapter 8: Interior Finishes** - Flame spread and smoke development.
9.  **Chapter 9: Fire Protection Systems** - Sprinklers, alarms, standpipes.
10. **Chapter 10: Means of Egress** - Exit paths, widths, and distances.
11. **Chapter 11: Accessibility** - Universal design requirements.
12. **Chapter 12: Interior Environment** - Lighting, ventilation, and acoustics.
13. **Chapter 13: Energy Efficiency** - Insulation and HVAC efficiency.
14. **Chapter 14: Exterior Walls** - Cladding and weather protection.
15. **Chapter 15: Roof Assemblies and Rooftop Structures** - Waterproofing and drainage.
16. **Chapter 16: Structural Design** - ASCE 7-16 loads (Wind, Seismic, Live).
17. **Chapter 17: Special Inspections and Tests** - Quality control for critical elements.
18. **Chapter 18: Soils and Foundations** - Geotechnical investigation and foundation design.
19. **Chapter 19: Concrete** - ACI 318 design and construction.
20. **Chapter 20: Aluminum** - Structural aluminum design.
21. **Chapter 21: Masonry** - TMS 402 design and construction.
22. **Chapter 22: Steel** - AISC 360 design and construction.
23. **Chapter 23: Wood** - AWC NDS design (limited use in UAE).
24. **Chapter 24: Glass and Glazing** - Safety and structural glazing.
25. **Chapter 25: Gypsum Board, Gypsum Panel Products and Plaster** - Interior partitions.
26. **Chapter 26: Plastic** - Foam insulation and light-transmitting plastics.
27. **Chapter 27: Electrical** - NFPA 70 (National Electrical Code).
28. **Chapter 28: Mechanical Systems** - HVAC and refrigeration.
29. **Chapter 29: Plumbing Systems** - Water supply and drainage.
30. **Chapter 30: Elevators and Conveying Systems** - Vertical transport.
31. **Chapter 31: Special Construction** - Tents, canopies, and temporary structures.
32. **Chapter 32: Encroachments into the Public Right-of-Way** - Balconies and awnings.
33. **Chapter 33: Safeguards During Construction** - Site safety and protection.
34. **Chapter 34: Existing Buildings** - Alterations, repairs, and change of use.

### 3.2 Key Abu Dhabi Amendments
*   **Estidama:** Minimum 1-Pearl for private buildings; 2-Pearl for government buildings.
*   **Prayer Rooms:** Mandatory in all buildings with a GFA >2,000 m². Must include separate male and female areas.
*   **Ablution Facilities:** Must be provided adjacent to prayer rooms with specific drainage and non-slip flooring.
*   **Arabic Signage:** All public signage must be bilingual (Arabic and English), with Arabic appearing first or above English.
*   **Seismic Requirements:** Increased seismic design parameters for coastal Abu Dhabi compared to the standard IBC values.
*   **Majlis:** Specific requirements for Majlis areas in residential villas.

---

## 4. STRUCTURAL ENGINEERING — DEEP DETAIL

### 4.1 Seismic Design (Eurocode 8)
The UAE uses the National Annex to EN 1998-1 for seismic design.

#### 4.1.1 PGA Map by Location (475-year return)
| Location | Peak Ground Acceleration (PGA) |
| :--- | :--- |
| **Abu Dhabi City** | 0.10g |
| **Dubai City** | 0.06g |
| **Ras Al Khaimah** | 0.15g |
| **Al Ain** | 0.08g |
| **Fujairah** | 0.12g |
| **Sharjah** | 0.08g |
| **Ajman** | 0.08g |

#### 4.1.2 Importance Factors (γI)
*   **Class II (Residential/Office):** 1.0
*   **Class III (Hospitals, Schools):** 1.2
*   **Class IV (Critical Infrastructure):** 1.4

### 4.2 Wind Engineering
#### 4.2.1 Basic Wind Speeds (10-min mean at 10m)
| Location | Wind Speed (m/s) |
| :--- | :--- |
| **Dubai** | 43 m/s |
| **Abu Dhabi** | 45 m/s |
| **Ras Al Khaimah** | 46 m/s |
| **Fujairah** | 42 m/s |

#### 4.2.2 Wind Tunnel Testing
Mandatory for:
*   Buildings >100m in height.
*   Buildings with unusual geometry or dynamic sensitivity.
*   Buildings located in complex urban environments where shielding or funneling may occur.

---

## 5. FIRE SAFETY — DEEP DETAIL

### 5.1 UAE Fire and Life Safety Code Chapter Summaries
1.  **Chapter 1: Administration and General Requirements** - Scope, enforcement, and stakeholder responsibilities.
2.  **Chapter 2: Definitions** - Technical terms and classifications.
3.  **Chapter 3: Occupancy Classifications** - Groups buildings by hazard level.
4.  **Chapter 4: Means of Egress** - Travel distances, exit widths, and signage.
5.  **Chapter 5: Fire Detection and Alarm Systems** - Addressable systems, detector spacing.
6.  **Chapter 6: Fire Suppression Systems** - Sprinklers, water supply, and tank sizing.
7.  **Chapter 7: Standpipe and Hose Systems** - Class I, II, and III systems.
8.  **Chapter 14: High-rise Buildings** - Refuge areas, fire lifts, and phased evacuation.
9.  **Chapter 15: Hazardous Materials** - Storage and handling of flammable/toxic substances.

---

## 6. GREEN BUILDING — DEEP DETAIL

### 6.1 Estidama PBRS v2.0 (2025 Implementation)
*   **Net Water (NW):** Increased weighting on greywater recycling and condensate recovery.
*   **Biodiversity:** New credits for native landscaping and habitat protection.
*   **EV Charging:** Mandatory provision for 10% of parking spaces to have active chargers.

### 6.2 Dubai Green Building Regulations (DGBR)
*   **Lighting Power Density (LPD):**
    *   Offices: ≤ 10 W/m².
    *   Retail: ≤ 16 W/m².
    *   Corridors: ≤ 5 W/m².
*   **Water Efficiency:**
    *   WC: ≤ 4L per flush.
    *   Faucets: ≤ 6L per minute.

---

## 7. SPECIALIST CODES

### 7.1 Swimming Pools (DM Technical Standards)
*   **Filtration:** Turnover rate of 6 hours for residential and 4 hours for commercial pools.
*   **Chlorination:** Free chlorine levels must be maintained between 1.0 and 3.0 mg/L.
*   **Safety:** Anti-entrapment drain covers are mandatory.

### 7.2 Lifts and Escalators
*   **Standard:** EN 81-20 for passenger lifts.
*   **Inspection:** Mandatory DM inspection every 6 months.
*   **Firefighting Lift:** Must have a minimum load of 630 kg and a speed of 1.0 m/s.

### 7.3 Glass and Façades
*   **Wind Load Testing:** Must comply with ASTM E330.
*   **Impact Resistance:** Laminated glass is mandatory for all overhead glazing and balustrades.

### 7.4 Roofing
*   **Slope:** Minimum 1:80 (1.25%) for flat roofs.
*   **Reflectivity:** White reflective membranes with a Solar Reflectance Index (SRI) > 78 are mandatory in Dubai.

---
*Last Updated: July 2026*

---

## SECTION A: ESTIDAMA PEARL BUILDING RATING SYSTEM — CREDIT-BY-CREDIT

This section expands the Abu Dhabi Estidama Pearl framework as a practical, credit-by-credit engineering reference. It is written as an implementation checklist for architects, MEP engineers, façade consultants, structural engineers, sustainability consultants, contractors, commissioning authorities, cost consultants, developers, and government reviewers working on UAE projects. Values and credit interpretations should be verified against the project’s applicable Estidama manual, Abu Dhabi Department of Municipalities and Transport / UPC requirements, and the live development-control conditions for the plot.

### Pearl Integrated Development Rating System (PIDRS) v2.0 — All 7 Categories

#### Category 1: Integrated Development Process (IDP)

The Integrated Development Process category is intended to force early coordination between owner, design consultants, cost advisers, constructors, facility managers, sustainability advisers, commissioning personnel, local authorities, and end users. In UAE projects, this is particularly important because late-stage changes to façade specifications, chilled-water plant sizing, fire strategy, parking layouts, roof plant, district cooling interfaces, and utility corridor reservations can undermine energy, water, thermal-comfort, cost, and constructability outcomes.

##### IDP-R1 (Prerequisite): Integrated Development Plan (IDP)

- **Status:** Mandatory prerequisite; no Pearl certification path proceeds without compliance.
- **Minimum coordination requirement:** minimum 3 stakeholder workshops documented.
- **Required deliverable:** submit an IDP Report at each design stage.
- **Typical UAE workshop sequence:**
  1. **Vision / concept workshop:** owner, master developer, architect, sustainability consultant, cost consultant, MEP lead, traffic consultant, landscape architect, civil/infrastructure engineer, fire consultant.
  2. **Schematic design workshop:** coordinated review of building massing, envelope, water strategy, district cooling / plant location, fire access, façade ratios, orientation, open-space design, shade strategy, and authority interfaces.
  3. **Detailed design / pre-tender workshop:** review of specifications, submittal requirements, metering, commissioning scope, CEMP obligations, energy-model assumptions, material procurement routes, and contractor responsibilities.
- **IDP Report contents:**
  - project vision, sustainability aspirations, Pearl target, certification responsibilities;
  - names, disciplines, and attendance of workshop participants;
  - design decisions taken and deferred decisions requiring later closure;
  - risk register for sustainability, utilities, authority approvals, supply chain, and operation;
  - action tracker with named responsible parties and due dates;
  - design-stage evidence matrix identifying drawings, calculations, reports, and specifications needed for each credit.

##### IDP-1: Project Overview and Aspirations (1 credit)

- **Credit value:** 1 credit.
- **Core requirement:** produce a project overview and aspirations document that records the project’s environmental, social, economic, technical, and operational objectives.
- **GIS site analysis:** include plot boundaries, existing utilities, roadway hierarchy, public transport stops, pedestrian desire lines, solar exposure, noise sources, wind exposure, heat-island risks, adjacent land uses, coastal or wadi constraints, and known ecological sensitivities.
- **500 m radius analysis:** identify amenities, schools, clinics, mosques, parks, supermarkets, public transport points, shaded pedestrian routes, cycling routes, district cooling corridors, stormwater discharge locations, and utility substations within 500 m of the project boundary.
- **Vision document:** describe Pearl target, energy target, water target, materials target, occupant health goals, commissioning intent, operations intent, and target construction-performance metrics.

##### IDP-2: Design Process Management (2 credits)

- **Credit value:** up to 2 credits.
- **Stage Gate reviews:** concept, schematic, detailed design, tender / construction documentation, construction, and handover.
- **BIM coordination plan:** define BIM execution plan, model responsibilities, LOD requirements, coordinate system, clash-detection frequency, model exchange format, COBie / asset-data expectations where required, and information handover to facilities management.
- **Clash detection log:** maintain a discipline-by-discipline log of clashes and actions, including structural openings, risers, fire dampers, smoke-control ducts, chilled-water routes, drainage slopes, façade anchors, roof plant clearances, access routes for maintenance, and ceiling coordination.
- **Design management evidence:** meeting minutes, issue logs, clash reports, design risk register, authority submission tracker, design change register, and updated design-stage credit tracker.

##### IDP-3: Life Cycle Assessment (3 credits)

- **Credit value:** up to 3 credits.
- **LCA method:** whole-life carbon analysis using EN 15978 principles.
- **Minimum comparison:** compare at least 3 structural alternatives.
- **Indicative embodied carbon targets:**
  - residential: ≤600 kg CO2e/m²;
  - commercial: ≤800 kg CO2e/m².
- **Alternatives commonly compared in UAE projects:**
  1. conventional reinforced-concrete frame with flat slabs;
  2. post-tensioned concrete slab system;
  3. composite steel-concrete system;
  4. high-GGBS concrete option;
  5. precast façade / precast structural elements;
  6. reduced basement option with optimized parking;
  7. hybrid system using high-recycled-content steel.
- **Data to document:** concrete quantities by grade, cement replacement percentage, reinforcement tonnage, structural steel tonnage, façade aluminium and glass quantities, blockwork, insulation, gypsum board, floor finishes, roof membranes, and major MEP plant embodied impacts.
- **Deliverable:** LCA report with assumptions, service life, modules included, product data sources, uncertainty notes, alternatives evaluated, preferred design, and reduction pathway.

##### IDP-4: Commissioning Management (2 credits)

- **Credit value:** up to 2 credits.
- **Commissioning Authority:** appoint a Commissioning Authority (CxA) at RIBA Stage 2 or equivalent early design stage.
- **Owner's Project Requirements (OPR):** document performance expectations for indoor conditions, energy, water, metering, system resilience, maintainability, controls, alarm management, seasonal commissioning, training, and operations.
- **Basis of Design alignment:** verify that design narratives, calculations, specifications, controls, and drawings respond to the OPR.
- **Pre-functional checklists:** required before energising / operating major systems, including chillers, AHUs, FAHUs, pumps, cooling towers, heat exchangers, domestic water pumps, fire pumps, smoke-control systems, lighting controls, BMS, renewable-energy systems, and water-treatment systems.
- **Functional Performance Tests (FPT):** verify operating sequences, setpoints, alarms, fail-safe positions, standby equipment operation, duty/standby rotation, smoke-control modes, emergency power interfaces, and BMS trend logging.
- **Handover evidence:** commissioning plan, commissioning specifications, design review comments, pre-functional checklists, FPT scripts, deficiency log, seasonal commissioning plan, training records, systems manual, and final commissioning report.

##### IDP-5: Construction Environmental Management Plan (2 credits)

- **Credit value:** up to 2 credits.
- **CEMP timing:** submit to Estidama pre-construction.
- **Required construction controls:** dust, noise, vibration, waste handling, worker welfare interface, traffic movement, haul routes, wheel washing, hoarding, material storage, fuel storage, spill response, dewatering discharge, concrete washout, and hazardous-material handling.
- **Dust control:** water spraying, covered skips, wheel-wash bays, speed limits on unpaved roads, covered trucks, stockpile sheeting, and boundary monitoring where sensitive receptors exist.
- **Noise and vibration:** baseline monitoring, permitted working hours, silenced plant, acoustic screens, vibration limits near existing structures, notification procedures, and complaint response.
- **Evidence:** CEMP document, monitoring logs, inspection checklists, non-conformance reports, corrective actions, photographs, waste-transfer notes, and training records.

##### IDP-6: Building User Guide (1 credit)

- **Credit value:** 1 credit.
- **Purpose:** provide end users and facilities staff with a practical operational guide that helps the building perform as designed.
- **Languages:** deliver in Arabic and English.
- **Minimum content:**
  - energy-saving guidance for occupants;
  - water-saving guidance;
  - waste segregation and recycling instructions;
  - thermal comfort and thermostat guidance;
  - lighting controls and blinds operation;
  - ventilation and indoor-air-quality advice;
  - smoking policy;
  - cycling, shower, and transport facilities;
  - emergency procedures;
  - contact points for maintenance and sustainability issues.

#### Category 2: Natural Systems (NS)

The Natural Systems category addresses climate adaptation, ecology, heat island, light pollution, habitat, green infrastructure, and protection of sensitive desert, coastal, wadi, sabkha, and marine environments.

##### NS-R1 (Prerequisite): Heat Island Reduction

- **Status:** mandatory prerequisite.
- **Minimum hardscape SRI:** SRI 29 for hardscape; credits cannot be claimed unless this prerequisite is met.
- **Relevant surfaces:** paving, plazas, driveways, car parks, courtyards, podium decks, hardscape paths, and uncovered service yards.
- **UAE implementation notes:** high-albedo materials must be selected with glare, sand staining, maintenance access, slip resistance, and durability in mind.

##### NS-1: Ecological Assessment (1 credit)

- **Credit value:** 1 credit.
- **Phase 1 Habitat Survey:** identify habitat types, existing vegetation, water features, wadis, coastal edges, sabkha, mangrove interface, marine edge, protected species, invasive species, and ecological constraints.
- **Ecological value scoring:** classify low, medium, and high ecological value areas and record constraints on grading, excavation, dewatering, lighting, and access.
- **Greenfield benchmark:** if greenfield, target 25% of site area as ecologically productive.
- **Deliverable:** ecological assessment report with maps, photographs, plant and habitat inventory, protected-area interfaces, risk register, and mitigation measures.

##### NS-2: Natural Systems Protection (2 credits)

- **Credit value:** up to 2 credits.
- **Wadi setback:** minimum 25 m setback from wadis.
- **Sabkha preservation:** avoid disturbance of sabkha where possible; document earthworks, groundwater, salinity, geotechnical risk, and ecological protection measures.
- **Coastal buffer:** coastal protection 100 m buffer where applicable.
- **Construction controls:** fenced exclusion zones, signage, no-storage areas, restricted access, dewatering controls, sediment control, and ecological supervision during enabling works.

##### NS-3: Green Infrastructure (up to 3 credits)

- **Credit value:** up to 3 credits.
- **Measures:** green roofs, permeable paving, bioswales, rain gardens, shaded pedestrian routes, soil-volume provision, vegetated courtyards, planted podiums, and stormwater-retention features.
- **Quantitative examples:**
  - green roofs: minimum 50% of roof area;
  - permeable paving: minimum 30% hardscape;
  - bioswales and rain gardens sized for available runoff and local rainfall events.
- **UAE caution:** green infrastructure must include irrigation strategy, root-zone protection, salt tolerance, greywater / TSE compatibility, and maintenance access.

##### NS-4: Heat Island Reduction — Roof (2 credits)

- **Credit value:** up to 2 credits.
- **Roof SRI:** SRI ≥78 for at least 75% of roof area.
- **Alternative compliance:** green roof, high-reflectance roof, PV-covered roof, or a combination.
- **Design notes:** coordinate roof reflectance with waterproofing type, roof plant access, PV layout, roof anchors, parapets, access walkways, maintenance zones, and glare to neighbouring towers.

##### NS-5: Heat Island Reduction — Site (2 credits)

- **Credit value:** up to 2 credits.
- **Hardscape shading:** provide shading of 30% / 50% of hardscape depending on credit tier.
- **Measures:** high-SRI paving, covered parking, tensile shading, pergolas, PV carports, mature tree canopies, colonnades, arcade walkways, and podium shade structures.
- **Measurement:** calculate shaded area at prescribed solar times and document hardscape area, shade geometry, material SRI, and maintenance considerations.

##### NS-6: Light Pollution Reduction (1 credit)

- **Credit value:** 1 credit.
- **BUG ratings:** use luminaire backlight-uplight-glare ratings per IES TM-15.
- **Uplight:** no uplight above 90° for exterior fixtures.
- **Boundary control:** shield all fixtures above 1000 lumens directed beyond the property boundary.
- **Deliverables:** exterior lighting layout, photometric plan, luminaire cut sheets, BUG rating schedule, boundary illuminance calculations, and night-time commissioning verification.

##### NS-7: Habitat Creation (2 credits)

- **Credit value:** up to 2 credits.
- **Planting:** native plant species from Abu Dhabi approved plant lists; no invasive species.
- **Target:** 80% of planted area native or adapted.
- **Wildlife corridors:** connect planted areas, avoid ecological dead ends, reduce lighting spill, and use planting that supports birds, pollinators, and locally appropriate fauna.
- **Maintenance:** irrigation, soil amendment, replacement planting, pruning, and pest-management plan must be compatible with long-term ecological value.

#### Category 3: Livable Buildings (LB)

Livable Buildings focuses on human health, comfort, indoor environmental quality, acoustic comfort, daylight, views, materials, mould prevention, water hygiene, active transport, and amenity access.

##### LB-R1 (Prerequisite): Minimum Outdoor Air

- **Status:** mandatory prerequisite.
- **Ventilation basis:** minimum outdoor air as per ASHRAE 62.1.
- **CO2 monitoring:** required in densely occupied spaces exceeding 25 people per 1000 ft².
- **CO2 alarm setpoint:** 1100 ppm.
- **Evidence:** ventilation calculations, outdoor-air schedules, FAHU / AHU selections, controls sequences, TAB report, CO2 sensor locations, BMS point list, and commissioning trend logs.

##### LB-R2 (Prerequisite): Environmental Tobacco Smoke Control

- **Status:** mandatory prerequisite.
- **No-smoking perimeter:** no smoking within 7.5 m of building entrances, operable windows, and HVAC intakes.
- **Designated smoking areas:** provide signage, separation, exhaust or open-air positioning, and management controls.

##### LB-1: Indoor Environment Quality Survey (1 credit)

- **Credit value:** 1 credit.
- **Timing:** 6–18 months post-occupancy.
- **Response rate:** minimum 30%.
- **Corrective action threshold:** if less than 60% of respondents are satisfied, prepare corrective action plan.
- **Survey topics:** thermal comfort, air quality, odours, lighting, glare, noise, privacy, controls, cleanliness, maintenance response, wayfinding, and overall satisfaction.

##### LB-2: Daylighting (up to 4 credits)

- **Credit value:** up to 4 credits.
- **Metric:** Spatial Daylight Autonomy sDA300/50% for at least 55% / 75% / 90% of occupied floor area.
- **Glare / overexposure check:** Annual Sunlight Exposure ASE1000,250hr ≤10% of floor area.
- **UAE design implications:** deep overhangs, external shading, fins, recessed glazing, light shelves, high-performance glass, and careful west/east façade control are often necessary.
- **Evidence:** daylight simulation model, material reflectances, glazing transmittance, shading geometry, floor-area calculations, and sensitivity analysis for blinds operation.

##### LB-3: Views to Outside (2 credits)

- **Credit value:** up to 2 credits.
- **Requirement:** direct line of sight to outdoors for 90% of occupied floor area.
- **View cone:** at least 30° horizontal.
- **View zone:** 760 mm to 2285 mm above finished floor.
- **Coordination:** workstation layouts, sill heights, internal partitions, frit patterns, blinds, and façade spandrels can all affect compliance.

##### LB-4: Glare Control (1 credit)

- **Credit value:** 1 credit.
- **Control type:** automated glare control such as motorised blinds or electrochromic glazing on all south- and west-facing glazing.
- **Performance metric:** Daylight Glare Probability (DGP) ≤0.35 for 95% of occupied hours.
- **Controls:** integrate with BMS or local sensors; allow occupant override where appropriate; avoid conflict with daylight targets.

##### LB-5: Acoustic Performance — Noise Isolation (2 credits)

- **Credit value:** up to 2 credits.
- **STC / Rw targets:**
  - residential party walls: ≥55 dB;
  - office partitions: ≥45 dB;
  - hotel rooms: ≥55 dB;
  - mechanical rooms adjacent to occupied spaces: ≥65 dB.
- **Flanking:** address ceiling voids, façade mullions, raised floors, duct penetrations, service risers, door undercuts, back-to-back sockets, and pipe penetrations.
- **Evidence:** acoustic design report, partition types, façade acoustic performance, door schedules, penetration details, and site test results.

##### LB-6: Acoustic Performance — Reverberation (1 credit)

- **Credit value:** 1 credit.
- **RT60 targets:**
  - open-plan office: 0.5–0.8 s;
  - meeting rooms: 0.4–0.6 s;
  - hotel corridors: 0.6–0.9 s;
  - classrooms: 0.4–0.6 s.
- **Calculation basis:** ISO 3382.
- **Design measures:** acoustic ceiling tiles, wall absorbers, carpet, acoustic baffles, perforated panels, acoustic plaster, and soft furnishings.

##### LB-7: Thermal Comfort (2 credits)

- **Credit value:** up to 2 credits.
- **Thermal basis:** operative temperature within ASHRAE 55 comfort zone.
- **PMV target:** -0.5 to +0.5 for at least 90% of occupied hours.
- **Measurement heights:** 0.1 m at ankle level, 0.6 m seated body, 1.1 m seated head.
- **Radiant asymmetry:** less than 10°C.
- **UAE design issues:** solar-heated façades, oversized glazing, cold air dumping, high humidity, poorly balanced VAV terminals, underperforming chilled beams, and poor envelope airtightness can compromise comfort.

##### LB-8: Low Emitting Materials (up to 3 credits)

- **Credit value:** up to 3 credits.
- **VOC / emissions examples:**
  - adhesives: ≤50 g/L;
  - flat paints: ≤50 g/L;
  - carpet: ≤0.5 mg/m²·hr TVOC and ≤0.05 mg/m²·hr formaldehyde under CRI Green Label Plus;
  - composite wood: ≤0.05 ppm formaldehyde under CARB Phase 2.
- **Material categories:** paints, coatings, adhesives, sealants, flooring, ceiling tiles, gypsum board, insulation, composite wood, furniture, millwork, and acoustic finishes.
- **Evidence:** product datasheets, VOC certificates, emissions test reports, procurement logs, substitution register, and site inspection records.

##### LB-9: Mould Prevention (1 credit)

- **Credit value:** 1 credit.
- **Humidity target:** relative humidity ≤60% with continuous monitoring in occupied spaces.
- **Dew-point control:** provide vapour barriers where surface temperature could fall below dew point.
- **Wet-area exhaust:** minimum 50 CFM intermittent or 20 CFM continuous in wet areas.
- **UAE risk areas:** chilled-water pipe condensation, poorly insulated ducts, cold supply-air diffusers, façade thermal bridges, bathrooms, pantry areas, laundry rooms, and hotel guest-room fan-coil units.

##### LB-10: Water Contamination Prevention (1 credit)

- **Credit value:** 1 credit.
- **Legionella basis:** risk assessment per ASHRAE 188.
- **Plan:** water management plan including temperature control, flushing, disinfection, monitoring, corrective actions, and record keeping.
- **Monitoring:** sentinel outlets and distal monitoring.
- **Chlorine residual:** 0.2–0.5 mg/L at all outlets.
- **Systems covered:** domestic cold water, domestic hot water, calorifiers, storage tanks, cooling towers, decorative water features, spas, pools, and irrigation systems where aerosolization is possible.

##### LB-11: Cycling Facilities (2 credits)

- **Credit value:** up to 2 credits.
- **Commercial storage:** 1 secure bike space per 5 occupants.
- **Residential storage:** 1 bike space per unit.
- **Showers:** 1 shower per 10 cyclists.
- **Quality requirements:** covered, lit, CCTV-monitored, accessible, secure, and connected to safe routes.

##### LB-12: Access to Amenities (2 credits)

- **Credit value:** up to 2 credits.
- **Distance:** within 500 m walking distance for key daily amenities.
- **Residential examples:** supermarket, pharmacy, school, mosque, park, clinic, childcare, restaurant, ATM, community facility.
- **Commercial examples:** restaurant, gym, healthcare, convenience retail, transit stop, pharmacy, bank, childcare, park, public service.
- **Alternative threshold:** 8 of 10 amenity categories within 750 m.
- **Evidence:** pedestrian connectivity analysis, map, route distances, barriers, shading, crossings, and amenity schedule.

#### Category 4: Precious Water (PW)

Precious Water is central to UAE sustainable design because potable water is energy-intensive and irrigation demand is high in hot arid climates.

##### PW-R1 (Prerequisite): Outdoor Water Use Reduction

- **Status:** mandatory prerequisite.
- **Irrigation source:** treated wastewater / treated sewage effluent (TSE) is mandatory.
- **Potable-water restriction:** no potable water for irrigation except during establishment period, maximum 12 months.
- **Evidence:** irrigation drawings, TSE connection details, establishment-period strategy, temporary water plan, and operations plan.

##### PW-R2 (Prerequisite): Reduction in Indoor Potable Water Use

- **Status:** mandatory prerequisite.
- **Minimum reduction:** 20% reduction from baseline required before credits can be pursued.
- **Evidence:** fixture schedule, baseline model, design model, occupancy assumptions, flow / flush rates, appliance data, and water balance.

##### PW-1: Reduction in Outdoor Potable Water Use (up to 4 credits)

- **Credit value:** up to 4 credits.
- **Maximum credit strategy:** 100% TSE irrigation.
- **Irrigation technology:** drip or sub-surface irrigation only.
- **Controls:** smart controllers with evapotranspiration adjustment, weather inputs, soil-moisture sensors, flow sensors, leak alarms, zoning by plant water demand, and night-time watering strategies.
- **Landscape strategy:** native / adaptive species, hydrozoning, mulching, soil improvement, shaded planting beds, reduced turf, and efficient irrigation commissioning.

##### PW-2: Reduction in Indoor Potable Water Use (up to 5 credits)

- **Credit value:** up to 5 credits.
- **Credit tiers:** 20% / 30% / 40% / 50% / 60% reduction from baseline.
- **Low-flow fixture examples:**
  - WC: ≤4.8 LPF or 6 LPF dual flush;
  - lavatory: ≤1.9 L/min;
  - shower: ≤5.7 L/min;
  - kitchen sink: ≤6.8 L/min.
- **Metering:** flow meters per circuit.
- **UAE design note:** ensure low-flow selection is compatible with drainage slopes, trap seal protection, user satisfaction, maintenance, and local authority approvals.

##### PW-3: Water Recycling (up to 3 credits)

- **Credit value:** up to 3 credits.
- **Greywater reuse:** laundry and showers to WC flushing, subject to treatment and Abu Dhabi EHSMS greywater standard expectations.
- **Rainwater harvesting:** limited applicability because UAE rainfall is low and episodic; roof runoff can still be captured for irrigation during rainfall events where practical.
- **Process water recycling:** cooling-tower blowdown treatment and reuse, condensate recovery, car-wash recycling, and water-feature filtration recovery.
- **Deliverables:** water balance, treatment process diagram, storage sizing, backflow prevention, cross-connection control, maintenance plan, water-quality monitoring, and authority approvals.

##### PW-4: Water Metering and Leak Detection (2 credits)

- **Credit value:** 2 credits.
- **Sub-meter circuits:** cooling, domestic hot water, irrigation, swimming pools, food and beverage areas, major tenant loads, process water, and reclaimed water.
- **Leak detection:** automated leak detection with 24-hour alarm.
- **BMS integration:** connect meters to BMS or EMS for trend logging and alarms.
- **Reporting:** water-use data logging and monthly reporting to Estidama during first year.

#### Category 5: Resourceful Energy (RE)

Resourceful Energy addresses energy demand, efficient systems, refrigerants, metering, renewables, advanced envelope, and passive cooling.

##### RE-R1 (Prerequisite): Minimum Energy Performance

- **Status:** mandatory prerequisite.
- **Energy Use Intensity targets:**
  - residential: ≤180 kWh/m²/yr;
  - office: ≤220 kWh/m²/yr;
  - hotel: ≤280 kWh/m²/yr;
  - retail: ≤350 kWh/m²/yr.
- **Simulation tools:** EnergyPlus or IES-VE.
- **Documentation:** calibrated model documentation, assumptions, schedules, envelope inputs, internal loads, HVAC efficiencies, lighting power, plug loads, DHW loads, district cooling assumptions, weather file, unmet hours, and sensitivity analysis.

##### RE-R2 (Prerequisite): CFC-Free Refrigerants

- **Status:** mandatory prerequisite.
- **Restriction:** no HCFC refrigerants; R-22 is banned for new compliant systems.
- **Preferred refrigerants listed for documentation:** R-134a, R-410A, R-32, R-1234yf, R-290 for small systems.
- **Required evidence:** refrigerant schedule, GWP documentation, equipment datasheets, leak detection plan, refrigerant-management plan, and maintenance procedures.

##### RE-1: Reduce Energy Demand (up to 5 credits)

- **Credit value:** up to 5 credits.
- **Performance tiers:** 15% / 25% / 35% / 45% / 55% below ASHRAE 90.1-2010 baseline.
- **Compliance methods:** envelope trade-off or whole-building simulation.
- **Indicative WWR limits unless high-performance glazing is used:**
  - north: 40%;
  - east / west: 25%;
  - south: 20%.
- **Demand-reduction measures:** compact massing, external shading, low-SHGC glass, high-performance insulation, air-tightness, efficient lighting, heat recovery, high-efficiency chillers, variable-speed drives, chilled-water temperature reset, demand-controlled ventilation, and plug-load management.

##### RE-2: High Efficiency Systems (2 credits)

- **Credit value:** 2 credits.
- **Chiller COP:** ≥5.6 under AHRI 550/590 conditions.
- **Cooling tower efficiency:** document gpm/hp performance and approach temperature.
- **Pump specific power:** ≤0.45 W/L·s.
- **Fan specific power:** ≤1.5 W/L·s for AHU supply fans.
- **Heat recovery:** enthalpy wheel efficiency ≥60%.
- **Commissioning:** efficiency must be verified through submittal review, factory data, site testing, TAB, BMS trend data, and seasonal commissioning.

##### RE-3: Energy Monitoring and Verification (2 credits)

- **Credit value:** 2 credits.
- **Metering plan:** chiller plant, AHUs, lighting zones, plug loads, tenant loads, lifts, pumps, domestic hot water, renewables, and major process loads.
- **Reports:** monthly energy reports.
- **Variance trigger:** variance greater than 10% triggers investigation.
- **M&V basis:** IPMVP Option B or D.
- **Deliverables:** M&V plan, meter schedule, single-line diagram showing meters, BMS point list, data-retention plan, report template, and responsibilities matrix.

##### RE-4: On-Site Renewable Energy (up to 5 credits)

- **Credit value:** up to 5 credits.
- **Tiers:** PV or other on-site renewables equal to ≥2% / 5% / 10% / 20% / 30% of annual energy consumption.
- **UAE PV yield note:** roof-mounted PV commonly assessed at approximately 150–180 kWh/m²/yr where DNI is around 2200 kWh/m²/yr.
- **Approvals:** grid connection approval from ADDC or DEWA as applicable.
- **Evidence:** PV layout, shading study, inverter schedule, production estimate, grid-connection approval, metering, structural loading, roof waterproofing coordination, and maintenance access.

##### RE-5: Advanced Envelope (2 credits)

- **Credit value:** 2 credits.
- **Measures:** triple-glazed IGUs, vacuum insulated panels, dynamic shading, phase change material in walls, enhanced air barrier, thermally broken frames, high-reflectance roofs, and insulated spandrels.
- **Indicative targets:**
  - opaque measured U-value ≤0.25 W/m²K;
  - SHGC ≤0.20 for west-facing glazing.
- **Façade coordination:** condensation risk, thermal bridging, structural brackets, fire stopping, acoustic performance, maintainability, cleaning access, and glare must be checked.

##### RE-6: Passive Cooling Strategies (1 credit)

- **Credit value:** 1 credit.
- **Strategies:** wind catchers, night purge ventilation, earth-air heat exchangers, evaporative pre-cooling where appropriate, shaded courtyards, thermal mass, stack ventilation, high-albedo surfaces, and landscape cooling.
- **Night purge:** minimum 20 ACH where used.
- **Performance demonstration:** CFD study showing 2°C operative temperature reduction.
- **UAE caution:** passive ventilation must be balanced against humidity, dust, sand ingress, outdoor noise, security, and air-quality conditions.

#### Category 6: Stewarding Materials (SM)

Stewarding Materials targets construction waste, recycled content, regional sourcing, timber, rapidly renewable materials, adaptability, and lifecycle impact.

##### SM-R1 (Prerequisite): Construction Waste Diversion

- **Status:** mandatory prerequisite.
- **Minimum diversion:** 50% of construction waste diverted from landfill.
- **Plan:** waste management plan, designated sorting areas, training, signage, waste streams, licensed haulers, disposal / recycling destinations, and reporting method.
- **Documentation:** tonnes per material stream, tonnes per m², diverted versus landfilled waste, transfer notes, photographs, and monthly waste reports.

##### SM-1: Recycled Content (up to 3 credits)

- **Credit value:** up to 3 credits.
- **Tiers:** ≥10% / 20% / 30% by cost of total materials containing recycled content.
- **Definition:** ISO 14021 recycled-content basis.
- **Common UAE material opportunities:**
  - steel: often 25–30% recycled for conventional production and 95%+ for electric-arc-furnace steel;
  - concrete with GGBS / PFA replacement ≥30%;
  - recycled aggregate where approved;
  - gypsum board with recycled gypsum;
  - aluminium with recycled billet content;
  - carpet tiles with recycled backing.

##### SM-2: Regional Materials (2 credits)

- **Credit value:** up to 2 credits.
- **Tiers:** ≥20% / 40% by cost of materials manufactured within 800 km of site.
- **Examples:** UAE / GCC quarried stone, UAE-produced concrete block, UAE-produced precast panels, locally manufactured aluminium systems, locally produced tiles, and GCC cementitious materials.
- **Documentation:** manufacturer location, extraction location, transport distance, invoice cost, and percentage contribution.

##### SM-3: Certified Timber (1 credit)

- **Credit value:** 1 credit.
- **Requirement:** 100% of wood products FSC-certified or equivalent.
- **Applies to:** structural timber, temporary and permanent formwork where counted, doors, flooring, joinery, furniture, decorative panels, and landscape timber.
- **Restriction:** no virgin tropical hardwood unless certified and accepted by the project criteria.

##### SM-4: Rapidly Renewable Materials (1 credit)

- **Credit value:** 1 credit.
- **Threshold:** minimum 2.5% of total material cost.
- **Examples:** bamboo, linoleum, wheatboard, wool, cork, and other rapidly renewable products.
- **UAE procurement note:** availability, durability, fire performance, moisture performance, and warranty must be checked before specification.

##### SM-5: Adaptive Design (2 credits)

- **Credit value:** up to 2 credits.
- **Flexibility measures:** structural grid flexibility, minimum 6 m bays for column-free space, office floor-to-floor height ≥3.8 m, raised access floors, modular façade system, demountable partitions, adaptable MEP risers, and future tenant-change allowances.
- **Design for Deconstruction (DfD):** document reversible connections, separable layers, material passports, deconstruction sequence, access for replacement, and avoidance of unnecessary composite assemblies.

##### SM-6: Material Lifecycle Assessment (2 credits)

- **Credit value:** up to 2 credits.
- **EPD threshold:** Environmental Product Declarations under ISO 14025 for ≥10 / 20 materials by cost.
- **Reduction target:** embodied carbon reduction versus baseline of ≥10% / 20%.
- **Deliverables:** product EPDs, quantity take-off, baseline model, proposed model, substitution log, supplier declarations, and lifecycle-impact comparison.

#### Category 7: Innovating Practice (IP)

##### IP-1: Innovation Credits (up to 5 credits)

- **Credit value:** up to 5 credits.
- **Basis:** 1 credit per innovation approved by Estidama.
- **Examples:** net-zero water, grid-interactive building, high-performance district-cooling optimization, advanced occupant engagement, verified biophilic design metrics, community engagement programme, circular construction-materials programme, smart leak detection beyond minimum requirements, and operational performance guarantee.
- **Evidence:** innovation narrative, performance target, measurement plan, responsible party, implementation details, and verification method.

##### IP-2: PBRS Accredited Professional (1 credit)

- **Credit value:** 1 credit.
- **Requirement:** at least one Estidama PBRS Accredited Professional on the project team.
- **Involvement:** AP must be registered with DCU and involved through all design stages.
- **Evidence:** AP certificate, appointment letter, meeting minutes, design review comments, and credit-submission responsibility matrix.

### Pearl Rating Thresholds

| Rating | Points Required | Mandatory Credits | Notes |
|--------|----------------|-------------------|-------|
| 1 Pearl | 31+ | All R prerequisites | Minimum for all new Abu Dhabi buildings |
| 2 Pearl | 60+ | All R + additional credits | Government buildings: 2 Pearl minimum |
| 3 Pearl | 90+ | All R + enhanced performance | Large mixed-use target |
| 4 Pearl | 120+ | All R + extensive performance | High-performance commercial target |
| 5 Pearl | 150+ / all available credits | All credits | Exceptional sustainability |

### Estidama Submission Evidence Matrix

| Stage | Typical Evidence | Responsible Parties |
|---|---|---|
| Concept | Pearl target, IDP workshop records, site analysis, preliminary energy and water strategy | Owner, architect, sustainability consultant |
| Schematic Design | Credit tracker, massing analysis, preliminary energy model, landscape water strategy, ecological assessment | Architect, MEP, landscape, sustainability |
| Detailed Design | Specifications, drawings, simulations, LCA, CEMP requirements, commissioning plan | Full consultant team |
| Tender | Contractor obligations, submittal templates, testing requirements, material documentation clauses | QS, consultant team, owner |
| Construction | Submittals, site inspection records, CEMP logs, waste data, commissioning checklists | Contractor, consultants, CxA |
| Handover | Final commissioning report, user guide, as-built metering, training, O&M manuals | Contractor, FM, CxA |

---

## SECTION B: LEED v4.1 IN UAE — CREDIT-BY-CREDIT APPLICATION

LEED v4.1 is not a UAE government code, but it is frequently used by UAE developers, free-zone authorities, international owners, hospitality brands, commercial landlords, and multinational tenants. Application in the UAE requires careful interpretation because climatic conditions, district cooling, TSE irrigation, high cooling loads, intensive water treatment, car-oriented masterplans, and authority-specific approval routes can materially affect credit feasibility.

### LEED BD+C: New Construction & Major Renovation — All 9 Categories

#### Location and Transportation (LT) — maximum 16 points

##### LT-c1: LEED for Neighborhood Development Location (8–16 points)

- **Requirement concept:** locate the project within a certified LEED for Neighborhood Development area.
- **UAE applicability:** most UAE projects cannot achieve this because certified LEED-ND locations are limited.
- **Practical approach:** confirm early whether the master development has LEED-ND certification; if not, pursue alternative LT credits such as density, diverse uses, transit, bicycle facilities, reduced parking, and electric vehicles.

##### LT-c2: Sensitive Land Protection (1 point)

- **Requirement:** avoid prime farmland, floodplains, habitats of threatened species, public parkland, wetlands, and other sensitive locations.
- **UAE context:** desert sites may be achievable if ecological assessment shows no protected habitat, wadi, sabkha, mangrove, turtle nesting, or other sensitive ecological constraint.
- **Evidence:** site survey, ecological assessment, masterplan constraints, government maps, and environmental NOCs where applicable.

##### LT-c3: High-Priority Site (2 points)

- **Requirement:** brownfield remediation, infill development, or other high-priority site conditions.
- **UAE opportunities:** older emirate cores, port areas, industrial redevelopment areas, and infill plots may qualify.
- **Evidence:** contamination assessment, remediation plan, authority records, urban infill mapping, and development-control documentation.

##### LT-c4: Surrounding Density and Diverse Uses (1–5 points)

- **Requirement:** surrounding density and access to diverse uses.
- **Diverse uses distance:** within 400 m walking distance for uses such as restaurants, schools, parks, supermarkets, pharmacy, mosque, bank, clinic, childcare, gym, retail, and community services.
- **Density threshold noted:** ≥22 dwelling units per acre.
- **UAE applicability:** Dubai Marina, Downtown Dubai, Business Bay, DIFC, Deira, Bur Dubai, Abu Dhabi Corniche, Al Maryah, and dense mixed-use districts are often stronger candidates.
- **Evidence:** scaled walking map, route lengths, use inventory, photographs, tenant list, and density calculations.

##### LT-c5: Access to Quality Transit (1–5 points)

- **Requirement:** access to qualifying transit service.
- **Distance examples:** within 400 m of bus stop with at least 100 weekday trips or within 800 m of rail / metro.
- **UAE applicability:** Dubai Metro Red and Green Line proximity can provide a strong route to maximum points; tram, bus, ferry, and intermodal nodes may contribute where service frequency qualifies.
- **Evidence:** transit maps, station distance, service frequency, route schedules, pedestrian route, and entrance-to-stop measurement.

##### LT-c6: Bicycle Facilities (1 point)

- **Short-term racks:** 2.5% of peak visitors, minimum 4.
- **Long-term storage:** 5% of full-time equivalent occupants.
- **Showers:** 1 per 100 FTEs.
- **UAE implementation:** provide shaded and secure bicycle storage; coordinate with Abu Dhabi cycling networks, Dubai cycling tracks, shower/changing access, and safe approach routes.

##### LT-c7: Reduced Parking Footprint (1 point)

- **Requirement:** parking no greater than minimum local code.
- **Preferred parking:** carpool / EV preferred parking for 5% of spaces.
- **Restriction:** avoid new surface parking lots where possible.
- **UAE challenge:** many developments have high parking requirements; early negotiation with planning authorities and master developers is important.

##### LT-c8: Electric Vehicles (1 point)

- **EVSE:** 2% of parking spaces with Level 2 EVSE at 6.2 kW.
- **EV-capable:** conduit to 8% additional spaces.
- **UAE initiatives:** coordinate with DEWA EV Green Charger scheme in Dubai and applicable Abu Dhabi utility requirements.
- **Design coordination:** transformer capacity, load management, billing, fire strategy, ventilation, signage, BMS / EMS integration, and future expansion.

#### Sustainable Sites (SS) — maximum 10 points

##### SS-p1: Construction Activity Pollution Prevention — prerequisite

- **Requirement:** pollution prevention during construction.
- **UAE equivalent:** Erosion and Sediment Control Plan, dust-control plan, stormwater control, and construction environmental controls.
- **Runoff criterion included:** no site runoff turbidity above 280 NTU.
- **Dust:** comply with Dubai / Abu Dhabi construction dust-control expectations, hoarding, wheel wash, stockpile covering, and haul-route control.

##### SS-c1: Site Assessment (1 point)

- **Topics:** topography, hydrology, climate, vegetation, soils, human use, human health effects, noise, air quality, utilities, and surrounding context.
- **Deliverable:** pre-design site assessment with constraints and opportunities map.

##### SS-c2: Site Development — Protect or Restore Habitat (2 points)

- **Previously developed sites:** restore 30% for 1 point or 50% for 2 points with native / adapted plants.
- **Greenfield sites:** protect 40% / 80%.
- **UAE measures:** native planting, soil restoration, shaded habitat, salt-tolerant landscapes, protected desert vegetation, mangrove / coastal interface protection, and reduced night lighting.

##### SS-c3: Open Space (1 point)

- **Requirement:** outdoor space at least 30% of total site area.
- **Vegetated requirement:** at least 25% of outdoor space vegetated.
- **UAE strategies:** podium landscaping, shaded courtyards, roof gardens, terraces, shaded pedestrian routes, and connected open spaces.

##### SS-c4: Rainwater Management (2–3 points)

- **Requirement:** retain 80th / 95th percentile rainfall event on-site using infiltration, evapotranspiration, cisterns, or equivalent strategies.
- **UAE challenge:** annual rainfall is low and episodic, commonly in the 75–200 mm range depending on location and year.
- **Strategies:** green roofs, permeable paving, cisterns, bioswales, retention tanks, dry wells where geotechnically acceptable, and controlled discharge.

##### SS-c5: Heat Island Reduction (2 points)

- **Non-roof:** SRI ≥29 for 50% or shading 50%.
- **Roof:** SRI ≥82 for steep roofs, SRI ≥39 for low-slope roofs, vegetated roof, or solar panels on 75% of roof.
- **UAE implementation:** combine PV, high-reflectance membranes, shaded parking, tree canopy, canopies, and high-SRI paving while managing glare and durability.

##### SS-c6: Light Pollution Reduction (1 point)

- **Basis:** BUG rating and uplight zone LZ0–LZ4.
- **Typical UAE exterior zone:** LZ2 suburban may apply in many cases, but actual zone must be confirmed by context.
- **Evidence:** photometric model, luminaire schedule, BUG ratings, controls, curfew settings, and site boundary light levels.

#### Water Efficiency (WE) — maximum 11 points

##### WE-p1 / WE-p2: Indoor and Outdoor Water Use Reduction — prerequisites

- **Indoor prerequisite:** 20% below baseline.
- **Outdoor prerequisite:** no potable water for irrigation where not appropriate; use climate-adapted planting, efficient irrigation, and TSE where available.

##### WE-p3: Building-Level Water Metering — prerequisite

- **Requirement:** install building-level water meter and commit to sharing or recording water data as required by LEED procedures.
- **UAE coordination:** align meter locations with utility, landlord, district cooling, irrigation, and tenant metering requirements.

##### WE-c1: Outdoor Water Use Reduction (1–2 points)

- **Options:** no irrigation system or 50% reduction using climate-adapted plants and smart controllers.
- **UAE best practice:** all TSE irrigation for maximum performance where available.
- **Evidence:** landscape water requirement calculation, irrigation plan, controller data, plant schedule, TSE connection details, and maintenance strategy.

##### WE-c2: Indoor Water Use Reduction (1–6 points)

- **Tiers:** 25% / 30% / 35% / 40% / 45% / 50% reduction.
- **Fixture examples:** low-flow WCs, faucets, showers, kitchen sinks, and appliances.
- **Commercial kitchen item:** pre-rinse spray valves ≤4.1 L/min.
- **Cooling tower:** chemical-free treatment may be considered where technically justified.

##### WE-c3: Cooling Tower Water Use (1–2 points)

- **Cycles of concentration:** ≥10 for 1 point or ≥20 with alternative water sources for 2 points.
- **UAE issues:** water quality, scaling, drift, blowdown, biological control, make-up water source, condenser-water approach temperature, and chemical-treatment strategy.
- **Reuse:** blowdown to irrigation only if water quality and regulations permit.

##### WE-c4: Water Metering (1 point)

- **Sub-meter targets:** irrigation, indoor plumbing, domestic hot water, reclaimed water, cooling towers, process water, tenant uses, and other major uses.
- **Data:** provide trend logging, monthly review, leak alarms, and reporting responsibility.

#### Energy and Atmosphere (EA) — maximum 33 points

##### EA-p1: Fundamental Commissioning and Verification — prerequisite

- **Cx Authority:** independent commissioning authority.
- **Documents:** OPR, Basis of Design, commissioning plan, design review, submittal review, functional testing, issues log, and commissioning report.
- **UAE systems:** chilled-water plant, district cooling interface, FAHUs, AHUs, smoke-control systems, BMS, lighting controls, renewables, domestic hot water, and water-treatment systems.

##### EA-p2: Minimum Energy Performance — prerequisite

- **Baseline:** ASHRAE 90.1-2016.
- **Minimum improvement:** 5% better than baseline for new construction and 3% for major renovation.
- **UAE modelling concerns:** district cooling modelling, humidity, façade solar gains, occupancy schedules, hotel loads, kitchen loads, external shading, and plug-load assumptions.

##### EA-p3: Building-Level Energy Metering — prerequisite

- **Requirement:** permanent building-level energy meters.
- **Coordinate with:** utility meters, landlord meters, tenant meters, district cooling BTU meters, PV meters, and BMS.

##### EA-p4: Fundamental Refrigerant Management — prerequisite

- **Requirement:** no CFC refrigerants.
- **Evidence:** equipment schedule, refrigerant type, charge, and maintenance plan.

##### EA-c1: Enhanced Commissioning (2–6 points)

- **Enhanced commissioning:** envelope commissioning, additional BAS points, design review, and more extensive verification.
- **Monitoring-based commissioning:** real-time performance verification and continuous re-commissioning protocols.
- **Evidence:** MBCx plan, trend logs, analytics, fault detection, seasonal testing, and corrective action procedures.

##### EA-c2: Optimize Energy Performance (1–18 points)

- **Simulation tiers:** 6% / 8% / 10% / 12% / 14% / 16% / 18% / 20% / 22% / 24% / 26% / 28% / 30% / 32% / 34% / 36% / 38% / 40% / 42%+ above ASHRAE baseline for 1–18 points.
- **Typical UAE achievable range:** 30–40% with strong envelope, efficient HVAC, efficient lighting, optimized controls, and PV support.
- **Measures:** low-SHGC glazing, reduced WWR, external shading, high-efficiency chillers, high-efficiency district cooling interface, heat recovery, demand-controlled ventilation, LED lighting, lighting controls, VFDs, efficient pumps, efficient fans, and optimized setpoints.

##### EA-c3: Advanced Energy Metering (1 point)

- **Threshold:** sub-meter all end uses greater than 10% of total energy.
- **Interval:** 15-minute intervals.
- **Retention:** 36-month data retention.
- **Use:** support M&V, tenant billing, fault detection, retro-commissioning, ESG reporting, and utility-demand management.

##### EA-c4: Demand Response (2 points)

- **Requirement:** enroll in utility demand-response program where available.
- **Target:** automated load shedding of at least 10% peak demand.
- **Integration:** BAS-controlled setpoint resets, lighting reductions, chilled-water reset, non-critical equipment shedding, battery / thermal storage dispatch, and EV charging management.

##### EA-c5: Renewable Energy Production (1–3 points)

- **Tiers:** 1% / 5% / 10% of annual energy from on-site renewables.
- **UAE strategy:** rooftop PV, carport PV, façade-integrated PV where practical, and net-metering approvals.
- **Evidence:** PV yield calculation, shading study, inverter datasheets, grid-connection agreement, meter arrangement, and maintenance plan.

##### EA-c6: Enhanced Refrigerant Management (1 point)

- **Requirement:** GWP-weighted LCCP ≤100 where applicable.
- **Preference:** natural or lower-GWP refrigerants where technically feasible.
- **Evidence:** refrigerant schedule, charge quantities, leakage assumptions, equipment life, and leak testing plan.

#### Materials and Resources (MR) — maximum 13 points

##### MR-p1 / MR-p2: Recyclables Storage and C&D Waste Plan — prerequisites

- **Recyclables:** provide storage and collection for common recyclables.
- **C&D plan:** define waste streams, diversion targets, haulers, sorting approach, and reporting.

##### MR-c1: Building Life-Cycle Impact Reduction (1–5 points)

- **Options:** historic preservation, adaptive reuse, abandoned-building renovation, structure reuse, or whole-building LCA.
- **LCA path:** demonstrate 10% reduction in 3 of 6 impact categories.
- **UAE focus:** structural optimization, cement replacement, reduced basement, façade optimization, recycled metals, and efficient material quantities.

##### MR-c2: Environmental Product Declarations (1–2 points)

- **Disclosure:** 20 products from 5 manufacturers with EPDs.
- **Optimization:** third-party EPDs with GWP ≤10% of category average for 20 products.
- **UAE procurement issue:** EPD availability may vary; early supplier engagement is required.

##### MR-c3: Sourcing of Raw Materials (1–2 points)

- **Disclosure:** 20 products from manufacturers with responsible extraction policies.
- **Optimization:** 25% by cost from responsible sources.
- **Evidence:** supplier policies, certifications, recycled content, regional sourcing, chain-of-custody documents, and invoices.

##### MR-c4: Material Ingredients (1–2 points)

- **Disclosure:** 20 products with HPD or Declare label.
- **Optimization:** 25% by cost with no Red List chemicals.
- **Material categories:** interiors, flooring, ceilings, insulation, adhesives, sealants, furniture, and composite wood.

##### MR-c5: Construction and Demolition Waste Management (1–2 points)

- **Diversion:** 50% for 1 point or 75% for 2 points.
- **Material streams:** minimum 4 streams.
- **Calculation:** weight-based.
- **UAE streams:** concrete, reinforcement steel, timber formwork, pallets, gypsum, cardboard, plastics, packaging, aluminium, glass, excavated material where allowed, and MEP scrap.

#### Indoor Environmental Quality (EQ) — maximum 16 points

##### EQ-p1 / EQ-p2 / EQ-p3: Minimum IAQ, No Smoking, Minimum Acoustic Performance — prerequisites

- **Minimum IAQ:** ASHRAE 62.1 ventilation compliance.
- **No smoking:** environmental tobacco smoke control.
- **Acoustics:** minimum acoustic performance, especially relevant for schools and other sensitive occupancy types.

##### EQ-c1: Enhanced Indoor Air Quality Strategies (1–2 points)

- **Natural ventilation:** 10% of occupied spaces where suitable.
- **Mechanical strategies:** entryway systems at least 3 m deep, MERV 13 filtration, negative pressure in janitor rooms, exhaust for copy / chemical areas, and CO2 monitoring.
- **UAE caution:** natural ventilation must consider heat, humidity, dust, sandstorms, and outdoor air quality.

##### EQ-c2: Low-Emitting Materials (1–3 points)

- **Categories:** paints / coatings, adhesives / sealants, flooring, composite wood, ceilings, walls, insulation, furniture, and exterior-applied products where relevant.
- **Standards mentioned:** SCAQMD Rule 1113 for paints/coatings, SCAQMD Rule 1168 for adhesives/sealants, FloorScore, CRI Green Label Plus, NSF 140, CARB Phase 2, BIFMA e3 / level.
- **Evidence:** VOC content, emissions certificates, product declarations, and procurement records.

##### EQ-c3: Construction IAQ Management Plan (1 point)

- **Basis:** SMACNA IAQ Guidelines during construction.
- **Measures:** protect absorptive materials from moisture, isolate pollutant sources, replace filters before occupancy, prohibit smoking, maintain housekeeping, and protect ducts.
- **Testing / flush-out:** air flush-out of 14,000 CF/SF total air or air testing.
- **Air testing limits included:** CO ≤9 ppm, formaldehyde ≤27 ppb, PM2.5 ≤12 μg/m³, PM10 ≤50 μg/m³, TVOC ≤500 μg/m³.

##### EQ-c4: Indoor Air Quality Assessment (1–2 points)

- **Option 1:** flush-out: 3,500 CF/SF before occupancy with HVAC running plus 14,000 CF/SF cumulative.
- **Option 2:** air testing using contaminant thresholds noted above.
- **UAE issue:** humidity control during flush-out is critical to avoid mould risk.

##### EQ-c5: Thermal Comfort (1 point)

- **Basis:** ASHRAE 55-2017.
- **Controls:** individual control for 50% of spaces and monitoring capability.
- **UAE focus:** avoid overcooling, high air speed complaints, façade radiant asymmetry, and humidity excursions.

##### EQ-c6: Interior Lighting (1–2 points)

- **Controls:** individual lighting controls for 90% of occupants.
- **Lighting quality:** CRI ≥80, UGR ≤19 in offices, and illumination levels per IES Handbook.
- **Design considerations:** daylight integration, dimming, glare control, task lighting, emergency lighting coordination, and scene-setting in hospitality.

##### EQ-c7: Daylighting (1–3 points)

- **Metrics:** sDA300,50% for 55% / 75% / 90% of occupied floor area and ASE1000,250hr ≤10%.
- **UAE design:** combine daylight with solar-control glazing and external shading to prevent cooling-load penalties.

##### EQ-c8: Quality Views (1 point)

- **Requirement:** direct line of sight for 75% of occupied floor area.
- **View content:** vegetation, sky, movement, ground-level activity, and distant objects.

##### EQ-c9: Acoustic Performance (1–2 points)

- **Scope:** background noise, reverberation, sound isolation, exterior noise, MEP noise, and speech privacy.
- **Note:** coordinate acoustic targets with HVAC design, façade design, partitions, doors, ceiling voids, and penetrations.

#### Innovation (IN) — maximum 6 points

##### IN-c1: Innovation (1–5 points)

- **Approach:** 1 point per accepted LEED innovation.
- **Examples:** walkable project, green housekeeping, exemplary performance, pilot credits, occupant engagement, zero-waste operation, smart water monitoring, and verified biodiversity enhancement.

##### IN-c2: LEED Accredited Professional (1 point)

- **Requirement:** LEED AP BD+C on project team.
- **Evidence:** credential, role description, meeting attendance, review comments, and submission responsibility.

#### Regional Priority (RP) — maximum 4 points

UAE Regional Priority Credits commonly emphasise high-impact local issues:

- Outdoor Water Use Reduction (WE-c1);
- Optimize Energy Performance (EA-c2);
- Heat Island Reduction (SS-c5);
- Access to Quality Transit (LT-c5).

### UAE LEED Feasibility Checklist

| Issue | UAE Risk | Design Response |
|---|---|---|
| Cooling-dominated energy load | High HVAC energy and humidity-control demand | Envelope optimization, efficient chilled water, heat recovery, controls |
| Water scarcity | High potable-water impact | TSE irrigation, low-flow fixtures, metering, condensate recovery |
| Heat island | Severe summer surface temperature | High-SRI materials, PV shade, tree canopy, shaded hardscape |
| Transit availability | Site-dependent | Select dense mixed-use sites near metro / bus / tram |
| Materials documentation | EPD / HPD availability varies | Early procurement screening and supplier engagement |
| Construction IAQ | Dust and humidity risks | SMACNA plan, material protection, filtration, controlled flush-out |

---

## SECTION C: SPECIALIST TECHNICAL STANDARDS

This section consolidates specialist technical standards that often appear in UAE building approvals, consultant specifications, authority reviews, third-party inspections, and contractor method statements.

### Swimming Pools and Water Features — Dubai Municipality Technical Requirements

#### Design References

- **Accessibility and inclusive design:** BS 8300 where relevant to access, changing areas, ramps, steps, handrails, and public facilities.
- **Pool water treatment:** PWTAG Technical Note TN2 and related PWTAG guidance, commonly referenced by consultants and operators.
- **UAE application:** coordinate with Dubai Municipality, Civil Defence, public health requirements, hotel operator standards, and project insurance requirements.

#### Turnover Rate

| Pool / Water Feature Type | Typical Turnover Requirement |
|---|---:|
| Competition pool | 4 hours |
| Leisure pool | 2–3 hours |
| Children’s pool | 30 minutes |
| Spa / whirlpool | 15 minutes |

- **Design implication:** children’s pools and spas require high circulation rates relative to volume.
- **Hydraulics:** balance pipe velocity, pump efficiency, noise, filter loading, and surge-tank capacity.
- **Operational note:** turnover calculations must reflect actual working volume, surge volume, backwash, evaporation, and bather load.

#### Filtration

- **Sand filtration:** sand effective size 0.4–0.6 mm; uniformity coefficient ≤1.5.
- **High-rate sand filter:** filtration velocity ≤24 m/hr.
- **Diatomaceous earth filter:** filtration rate ≤4 m/hr.
- **Filter accessories:** pressure gauges, air release, sight glass, sampling points, backwash line, flow meter, isolation valves, and access for media replacement.

#### Chemical Treatment

- **Free chlorine:** 1.0–3.0 mg/L.
- **Combined chlorine:** ≤1.0 mg/L.
- **pH:** 7.2–7.6.
- **Alkalinity:** 80–150 mg/L as CaCO3.
- **Cyanuric acid:** ≤100 mg/L for outdoor pools only.
- **Controls:** automatic dosing, ORP / pH monitoring, chemical bunding, ventilation of chemical rooms, eyewash, spill kits, and chemical segregation.

#### Backwash

- **Minimum backwash rate:** 0.5 m/min.
- **Discharge:** drain to treatment, not directly to sewer without testing.
- **Waste:** 2–5% of pool volume per backwash.
- **Design issue:** backwash tanks and discharge systems must be sized for peak backwash while avoiding flooding plantrooms or violating sewer discharge requirements.

#### Pool Hall HVAC

- **Air temperature:** 1–2°C above water temperature.
- **Relative humidity:** 50–60% RH.
- **Preferred dehumidification:** desiccant or dedicated dehumidification systems in UAE climate.
- **Air changes:**
  - competition pool: 6–10 ACH;
  - leisure pool: 4–8 ACH;
  - 100% fresh air during warm-up and cool-down where specified.
- **Pressure:** natatorium slightly negative relative to adjacent building areas to prevent chloramine migration.
- **Air distribution:** supply air should sweep glazing and deck areas without creating drafts at water level.
- **Corrosion:** all exposed metallic components should be 316L stainless steel or fibreglass; galvanized steel is prohibited in pool hall environments; powder-coated aluminium requires minimum 60 μm coating.

#### Lighting

- **Competition underwater lighting:** 300 lux.
- **Deck level:** 200 lux.
- **Glare:** UGR ≤22 for spectator seating.
- **Safety coordination:** emergency lighting, exit signage, underwater maintenance access, glare control, and electrical safety must be coordinated.

#### Safety

- **Depth marking:** minimum 100 mm high numerals in contrasting colour.
- **Drain covers:** anti-entrapment drain covers to ANSI/ASME A112.19.8.
- **Pool fencing:** ≥1.2 m height.
- **Gate:** self-closing and self-latching.
- **Anti-climb:** no climbable footholds within 1 m of gate.
- **Additional controls:** lifeguard sightlines, rescue equipment, non-slip surfaces, handrails, pool alarms where required, emergency shutoff, and chemical emergency procedures.

### Elevators and Escalators — UAE Regulations

#### Primary Lift Standards

- **Main standard:** EN 81-20:2014, replacing EN 81-1 / EN 81-2 for new installations from 2017 in many applications.
- **Dubai implementation:** Dubai Municipality circular made EN 81-20 mandatory for new lift installations from January 2018; renovations or major modernisations should follow EN 81-20 requirements where applicable.
- **Abu Dhabi:** commercial and government buildings commonly use EN 81-20; ADNOC facilities may use ASME A17.1 depending on owner requirements.

#### Key EN 81-20 Requirements

- **Car area:** minimum 0.28 m² net; preferred residential passenger lift 1.0–1.6 m².
- **Accessibility car size:** minimum 1.1 m × 1.4 m car for wheelchair accessibility under DDA / Abu Dhabi accessibility expectations.
- **Speed tolerance:** ±5% of rated speed.
- **MRL:** machine-room-less lifts permitted, including traction and hydraulic types; rope speed sensor within car frame.
- **Safety gear:** Type A instantaneous for speeds ≤0.63 m/s; Type B progressive for speeds >0.63 m/s.
- **Testing:** EN 81-20 Annex D testing.

#### Pit and Headroom

- **Pit clear height:** ≥0.5 m.
- **Pit fittings:** stop switch, socket, LED lighting ≥50 lux, drainage where applicable, and safe access.
- **Pit refuge:** 0.5 m × 0.6 m × 1.0 m minimum.
- **Headroom:** minimum 3.5 m above highest landing for EN 81-20; car-top safety space 0.3–0.5 m minimum depending on arrangement.

#### Fire Service and Evacuation Lifts

- **Fire service lift:** EN 81-72.
- **Shaft rating:** 1-hour fire-rated shaft for fire service lift as stated in the project criteria; many high-rise fire strategies may require higher ratings through local code review.
- **Power:** separate supply backed by generator.
- **Operation:** Level 0 / 1 / 2 fire service operation.
- **Door:** ≥1.1 m wide × 2.0 m high.
- **Capacity:** ≥1,000 kg.
- **Speed:** reach top floor in ≤60 seconds.
- **Evacuation lift:** EN 81-76, 2-hour rated shaft, for assisted evacuation of mobility-impaired persons.

#### Maintenance and Inspection

- **Inspection:** minimum annual inspection by accredited third-party inspector.
- **Maintenance contract:** mandatory.
- **Log book:** maintained on site.
- **Defect response:** major defects such as rope wear above 25%, guide shoe wear, or buffer deterioration must be rectified within 7 days or the lift taken out of service.
- **Modification:** DM Online NOC for lift modifications.

#### Escalators and Moving Walks

- **Standard:** EN 115-1:2017.
- **Step velocity:** ≤0.75 m/s.
- **Handrail speed:** within ±2% of step speed.
- **Safety features:** yellow demarcation lines, skirt brushes, emergency stop red mushroom buttons at top and bottom, comb-plate safety, missing-step detection, brake monitoring, fire shutter interface, and maintenance access.
- **Large retail example:** major malls may operate dozens of escalators under combined authority and developer maintenance procedures.

### Roofing Systems — UAE Climate Considerations

#### Climate Loads

- **Surface temperature:** 70–80°C summer roof surface temperatures are possible.
- **UV:** high UV exposure; membranes must resist accelerated degradation.
- **Rainfall:** minimal annual rainfall but intense events require robust drainage and overflow.
- **Sand and dust:** abrasion, clogging of drains, and soiling of reflective membranes and PV panels.
- **Thermal cycling:** daily temperature swings can be severe, with ΔT up to 50°C in summer conditions.

#### Dubai Municipality Roofing Specification Items

- **Minimum insulation:** 50 mm PIR or 75 mm XPS.
- **Minimum R-value:** ≥2.5 m²K/W.
- **Waterproofing:** minimum two-layer system such as primer plus two-coat modified bitumen, or TPO / PVC single-ply ≥1.5 mm with seam strength ≥300 N/50 mm.
- **SRI:** minimum 78 under DBC energy expectations.
- **Walkway protection:** 600 mm × 600 mm paving slabs or pressure-treated timber decking over protection mat.
- **Drainage:** minimum 2 roof drains per 200 m² plus overflow scuppers; overflow scupper set 50 mm above drain collection point.

#### Waterproofing Systems Used in UAE

| System | Typical UAE Use | Technical Notes |
|---|---|---|
| APP / SBS modified bitumen | Most common roof waterproofing | Heat-welded or torch-applied; minimum 4 mm APP for torch-applied; 40-year design life if correctly applied |
| TPO | White reflective membrane | SRI around 104 for white; 60 mil / 1.5 mm minimum; hot-air welded seams 40 mm wide; ASTM D6878 |
| PVC | Chemical-resistant areas | Useful near rooftop kitchens / restaurants; ASTM D4434; avoid plasticiser migration near EPS insulation |
| EPDM | Rubber membrane | Black EPDM has low SRI and generally requires overcoating to meet energy criteria; 60 mil minimum; ASTM D4637 |
| Liquid applied | Details and complex shapes | Polyurethane, PMMA, bitumen emulsion; useful for penetrations; UCAS or BBA certification commonly requested |

#### Green Roofs

- **Type:** extensive systems with growing medium 80–150 mm and sedum / native ground cover.
- **Wet load:** design for ≥180 kg/m² wet load.
- **Components:** root barrier, drainage layer, moisture-retention mat, filter fleece, growing medium, irrigation, inspection chambers, and edge restraint.
- **UAE note:** irrigation is essential; do not rely on rainfall.

#### Inverted Roof / IRMA

- **Build-up:** waterproofing directly on structural slab, XPS above membrane, ballast or paving above insulation.
- **Advantage:** protects membrane from UV and thermal cycling.
- **XPS:** closed-cell ASTM C578 Type IV / VI / VII.
- **Compressive strength:** ≥175 kPa.
- **Coordination:** wind uplift, ballast, drainage, roof falls, protection layers, plant plinths, and thermal bridging at parapets.

### Tower Crane Regulations — Dubai

#### Approvals and Registration

- **Civil Defence:** NOC required before installation.
- **Dubai Municipality:** approval of structural adequacy of mast base and ties.
- **Registration:** tower cranes must be registered with DM Construction Works Register.
- **Operator:** crane operator certification such as NPORS or equivalent.

#### Structural Design

- **Mast base:** design for vertical loads, overturning moment, shear, and dynamic effects.
- **Ties:** building frame may experience anchor forces up to 800 kN; third-party structural calculations are required.
- **Temporary works:** independent temporary-works engineer should verify foundations, tie-in levels, climbing sequence, and dismantling assumptions.

#### Site Safety and Aviation

- **Exclusion zone:** radius equal to jib length plus 5 m.
- **Oversailing:** agreement with adjacent site owners required where jib oversails neighbouring property.
- **Aviation:** CAA / DCAA notification if within airport height restriction areas; consultation for cranes >150 m AGL.
- **Warning lights:** aviation warning lights mandatory; ICAO Annex 14 red flashing ≥10 cd above 100 m AGL.
- **Civil Defence:** crane must not impede helicopter access to building top or fire service access road.

#### Testing and Operation

- **Proof load:** rated capacity × 1.25.
- **Inspection:** accredited third-party inspector; annual re-inspection.
- **Anti-collision:** minimum 3 m vertical clearance between jibs on adjacent cranes.
- **Technology:** CCTV on jib, zoning, slew limits, load moment indicators, anti-collision systems, and anemometer.
- **Wind cut-out:** auto-cut-out at wind speed >50 km/h / 13.9 m/s.

---

## SECTION D: STRUCTURE — WORKED EXAMPLES AND DETAILED CALCULATIONS

This section provides practical structural examples for UAE engineers. Calculations are illustrative and must be verified by the project’s appointed structural engineer against the governing authority-approved code, project-specific loads, geotechnical information, material specifications, durability exposure class, robustness requirements, fire strategy, and seismic / wind criteria.

### Concrete Design to BS 8110-1:1997 / BS EN 1992-1-1:2004 (UAE Standard)

#### Example 1: Column Design — Axial Load + Bending (BS EN 1992 Approach)

**Given:**

- Column: 500 mm × 500 mm.
- Concrete: C40/50, fck = 40 N/mm².
- Reinforcement: B500B, fyk = 500 N/mm².
- Design axial load: NEd = 4,500 kN.
- Design moment: MEd = 200 kN·m.
- Reinforcement: 8H32 bars.
- Area of one H32 bar: approximately 804 mm².
- Total steel area: As = 8 × 804 = 6,432 mm², stated as 6,434 mm².

**Step 1 — Gross section area:**

- Ac = 500 × 500 = 250,000 mm².

**Step 2 — Reinforcement ratio:**

- ρ = As / Ac = 6,434 / 250,000 = 0.0257 = 2.57%.
- This sits within common column reinforcement ranges and below the normal 4% congestion threshold noted earlier in this document.

**Step 3 — Design material strengths:**

- Concrete design strength under EC2 style: fcd = αcc fck / γc.
- Using αcc = 0.85 and γc = 1.5: fcd = 0.85 × 40 / 1.5 = 22.67 N/mm².
- Steel design strength: fyd = fyk / γs = 500 / 1.15 = 434.8 N/mm².

**Step 4 — Pure axial compression reference capacity:**

- Concrete contribution approximation: Ac × fcd = 250,000 × 22.67 = 5,667,500 N = 5,667 kN.
- Steel contribution approximation: As × fyd = 6,434 × 434.8 = 2,798,? kN approximately 2,798 kN.
- Combined reference compression capacity before detailed interaction reduction is approximately 8,465 kN.
- Since NEd = 4,500 kN, axial load alone is not the controlling condition; combined bending interaction must be checked.

**Step 5 — Eccentricity from design moment:**

- e = MEd / NEd = 200 kN·m / 4,500 kN = 0.0444 m = 44.4 mm.
- e / h = 44.4 / 500 = 0.089.
- The column must be checked for minimum eccentricity, second-order effects, slenderness, and biaxial bending if the moment is not uniaxial.

**Step 6 — Neutral axis / compression block approach:**

- Neutral axis depth x is solved by equilibrium between compression block, compression steel, tension steel, and axial load.
- For concrete ≤50 N/mm², compression block depth factor λ = 0.8.
- Compression zone depth = λx.
- Lever arms to reinforcement layers depend on nominal cover, link diameter, and main bar diameter.

**Step 7 — Interaction diagram check:**

- Normalised axial load = NEd / (b h fcd).
- b h fcd = 500 × 500 × 22.67 = 5,667,500 N = 5,667 kN.
- NEd / (b h fcd) = 4,500 / 5,667 = 0.794.
- Normalised moment = MEd / (b h² fcd).
- b h² fcd = 500 × 500² × 22.67 = 2.83375 × 10^9 Nmm = 2,833.75 kN·m.
- MEd / (b h² fcd) = 200 / 2,833.75 = 0.071.
- The point (0.794, 0.071) must fall within the capacity envelope for 8H32 reinforcement and the governing cover / bar arrangement.

**Step 8 — Cover and durability:**

- Nominal cover: 40 mm for XS2 exposure in Abu Dhabi coastal assumptions.
- UAE coastal design may require 50 mm nominal cover under Dubai Municipality practice.
- Verify against exposure classification, design life, concrete mix, chloride class, fire rating, and authority requirements.

**Step 9 — Links:**

- Minimum link diameter: 8 mm.
- Maximum spacing is the least of:
  - 0.6 × lesser column dimension = 0.6 × 500 = 300 mm;
  - 20 × main bar diameter = 20 × 32 = 640 mm;
  - 400 mm.
- Therefore use maximum 300 mm spacing, with tighter spacing near beam-column joints, laps, high shear zones, and plastic hinge regions if seismic detailing applies.

**Step 10 — UAE detailing notes:**

- Use corrosion-resistant detailing where exposure is severe.
- Avoid congested laps at floor levels; use couplers where bar diameter or congestion requires.
- Confirm fire rating cover and axis distance.
- Coordinate column dimensions with façade, parking layouts, MEP shafts, architectural finishes, and tolerance allowances.

#### Example 2: Flat Slab Punching Shear (EC2)

**Given:**

- Slab thickness: 250 mm.
- Concrete: C30/37.
- Internal column: 300 mm × 300 mm.
- Factored column reaction: VEd = 1,200 kN.
- Effective depth assumed: d = 212 mm.
- Load enhancement factor: β = 1.15.

**Step 1 — Control perimeter at 2d:**

- u1 = 2(c1 + c2) + 4πd.
- u1 = 2(300 + 300) + 4π(212).
- u1 = 1,200 + 2,663 = 3,863 mm.

**Step 2 — Design punching shear stress:**

- vEd = β × VEd / (u1 × d).
- vEd = 1.15 × 1,200,000 / (3,863 × 212).
- Denominator = 818,? mm² approximately.
- vEd ≈ 1.686 N/mm².

**Step 3 — Concrete punching resistance:**

- vRd,c = CRd,c × k × (100ρl × fck)^(1/3) × 2d/a where relevant to the selected EC2 expression and loaded-area arrangement.
- k = 1 + √(200/d), limited to 2.0.
- With d = 212 mm, √(200/212) = 0.971; k = 1.971.
- ρl is the average flexural reinforcement ratio in orthogonal directions, limited by EC2 rules.

**Step 4 — Decision:**

- If vEd ≤ vRd,c, no punching shear reinforcement is required beyond flexural reinforcement and detailing.
- If vEd > vRd,c, punching shear reinforcement is required.
- Given vEd is relatively high, many UAE flat slab systems of this type would require proprietary stud rails or shear links unless the slab is thickened or column head / drop panel is introduced.

**Step 5 — Reinforcement layout:**

- Common UAE solution: proprietary shear stud rails from systems such as Halfen or Ancon.
- Radial spacing: 0.75d typical maximum.
- 0.75d = 0.75 × 212 = 159 mm.
- Stud rails should begin near the column face and extend outward to the perimeter where vEd is below resistance.
- Coordinate with top mat reinforcement, openings, MEP sleeves, embedded conduits, column capital, and pour sequence.

**Step 6 — Additional checks:**

- Maximum punching stress near column face.
- Openings within influence zone.
- Edge / corner column factors if not internal.
- Moment transfer and unbalanced moment.
- Progressive collapse / robustness ties.
- Deflection, crack width, vibration, and fire rating.

### Seismic Design: UAE Response Spectra

#### Indicative UBC / IBC / ASCE 7 Seismic Parameters

| Location | Ss (0.2s, 5% 50yr) | S1 (1.0s) | Site Class D | SMS | SM1 | SDS | SD1 |
|---|---:|---:|---|---:|---:|---:|---:|
| Abu Dhabi | 0.25g | 0.10g | D | 0.38g | 0.24g | 0.25g | 0.16g |
| Dubai | 0.15g | 0.06g | D | 0.23g | 0.14g | 0.15g | 0.094g |
| Ras Al Khaimah | 0.37g | 0.15g | D | 0.56g | 0.36g | 0.37g | 0.24g |
| Fujairah | 0.40g | 0.16g | D | 0.60g | 0.38g | 0.40g | 0.25g |

#### Seismic Design Category

- Dubai: SDC B.
- Abu Dhabi: SDC B.
- Ras Al Khaimah: SDC C.
- Fujairah: SDC C.

#### Equivalent Lateral Force Procedure (ELFP)

**Base formula:**

- Cs = SDS / (R / Ie).
- V = Cs × W.

**R factors:**

| System | R Factor |
|---|---:|
| Special moment frame, steel | 8.0 |
| Special concentrically braced frame | 6.0 |
| Special reinforced-concrete shear wall | 6.0 |
| Intermediate frame | 5.0 |
| Ordinary frame | 4.0 |

**Illustrative Dubai calculation:**

- SDS = 0.15g.
- System: special reinforced-concrete shear wall, R = 6.0.
- Importance factor Ie = 1.0.
- Cs = 0.15 / (6 / 1.0) = 0.025.
- If seismic weight W = 200,000 kN, base shear V = 0.025 × 200,000 = 5,000 kN.

#### Vertical Distribution

- Fx = V × Cvx.
- Cvx = wx hx^k / Σ(wi hi^k).
- k = 1.0 for T ≤0.5 s.
- k = 2.0 for T ≥2.5 s.
- Interpolate k between 1.0 and 2.0 for intermediate periods as required by the governing standard.

#### P-Δ Check

- Stability coefficient θ = Px × Δ / (Vx × hsx × Cd).
- θ must be ≤0.10 under ASCE 7 style check or forces must be amplified and stability addressed.
- UAE high-rise note: even where seismic base shear is not dominant, P-Δ, wind drift, outrigger behaviour, transfer structures, and construction-stage stability can govern.

### Structural Design Coordination Notes for UAE Projects

- **Durability:** chloride and sulfate exposure often controls concrete cover and mix design.
- **Geotechnics:** sabkha soils, variable fill, high groundwater, and aggressive ground conditions require careful foundation and waterproofing design.
- **Wind:** tall and slender towers commonly require wind tunnel testing.
- **Thermal movement:** long podiums, car parks, roofs, façades, and bridges require expansion joints.
- **Fire:** structural fire resistance must be coordinated with Civil Defence and architectural compartmentation.
- **Construction sequence:** transfer slabs, outriggers, jump-form cores, tower cranes, and temporary works must be engineered.

---

## SECTION E: FIRE AND LIFE SAFETY — COMPLETE UAE FLSC DETAILS

The UAE Fire and Life Safety Code of Practice is one of the most important cross-emirate engineering references. It is enforced through Civil Defence approval, design NOCs, shop drawing approvals, inspections, product approvals, contractor licensing, fire-safety certificates, and annual maintenance requirements. The following table expands the 20-chapter structure into practical design requirements.

### UAE Fire and Life Safety Code of Practice (FLSC) — All 20 Chapters

| Chapter | Title | Key Requirements |
|---------|-------|-----------------|
| 1 | General Requirements | Scope; definitions; testing standards such as BS, EN, NFPA, UL, FM; occupancy classification A–J; roles of owner, consultant, contractor, supplier, and authority; approved products; qualified contractors; NOC procedures; design responsibility. |
| 2 | Means of Egress | Travel distance: low-rise sprinklered 60 m; high-rise 45 m to stair; exit width 0.015 m/person; occupant load calculation; two-exit minimum for more than 49 occupants; exit discharge; 75% at grade; stair protection; exit signage; accessible egress; dead-end limits; common path limits. |
| 3 | Fire Alarm Systems | Addressable systems for buildings over 500 m² or more than 2 storeys; EN 54 components; audio / visual alarms; 72-hour backup battery; AHJ connection such as Dubai Civil Defence network in some zones; cause-and-effect matrix; detector spacing; manual call points; monitoring of sprinkler valves and fire pumps. |
| 4 | Automatic Sprinkler Systems | NFPA 13 or EN 12845; hazard classification including Light Hazard, OH1–OH4, Extra Hazard; K80 standard sprinklers; K115 ELO extended coverage for high ceilings; 18 in clearance below sprinklers; obstruction rules; hydraulic calculation; design density / area; zone control valves; water-flow switches; testing drains. |
| 5 | Special Hazard Suppression | Clean agents such as FM-200 / NOVEC 1230 for data centres and switchrooms; NFPA 2001 design concentration; hold time ≥10 minutes; discharge ≤10 seconds; total flooding vs local application; CO2 restricted in occupied spaces; foam AFFF / FFFP for aircraft hangars and fuel storage per NFPA 11; wet chemical kitchen suppression per NFPA 17A. |
| 6 | Emergency Lighting | EN 1838; minimum 1 lux on escape routes; 0.5 lux in open areas; 3-hour duration; self-contained luminaires or central battery; maintained or non-maintained; exit signs above all exits; green / white running-man signs per ISO 7010; testing and maintenance records. |
| 7 | Smoke Control | Stairwell pressurisation 50 Pa with doors closed and 10 Pa with doors open depending on scenario; smoke exhaust 6 ACH where used; make-up air 50–90% of exhaust; atrium smoke management under NFPA 92A; CFD for complex geometries; dedicated smoke-control fan with 2-hour rated ductwork; controls integrated with fire alarm. |
| 8 | Portable Fire Extinguishers | NFPA 10; maximum travel distance 23 m for Class A and 15 m for Class B; minimum 2.5 kg dry powder for many areas; Class K wet chemical for kitchens; CO2 for electrical risks; annual inspection; pressure checks; 5-year and 12-year tests as applicable; mounting heights and signage. |
| 9 | Fire Pumps | NFPA 20; electric pump plus diesel backup pump; minimum 6 hours diesel fuel; acceptance test at 150% rated flow and at least 65% rated pressure; weekly churn test; annual full-flow test; suction tank minimum 30-minute supply at peak demand; pressure tank not permitted as primary supply; jockey pump; controller monitoring. |
| 10 | Water Supply | Hazen-Williams flow testing; minimum residual pressure 3 bar residential and 4 bar commercial at sprinkler design point; tank fill rate equals demand rate minimum; fire department connection with Storz or BS instantaneous coupling; at least 2 inlets; 100 mm diameter; sectional tanks; water-level alarms. |
| 11 | Construction and Fire Protection | ASTM E119 / BS 476 / EN 1363 fire resistance; structural steel intumescent paint 0.5–3 mm DFT per assessment for 60/90/120 minutes; concrete cover; compartmentation: offices 5,000 m² sprinklered, storage 2,500 m²; penetration seals CE-marked; 60/120-minute ratings; service ducts with fire dampers at penetrations; hot works control. |
| 12 | Building Services | Firefighting lifts EN 81-72; standby generator transfer within 30 seconds to critical loads; emergency lighting, fire pumps, lifts, stair pressurisation; UPS for fire alarm minimum 24-hour standby plus 30-minute alarm; fire-resistant cables such as LPCB / BS 8519 FP200 or Pyrotenax for critical systems; fire stopping around services. |
| 13 | Hazardous Materials | NFPA 704 diamond markings; storage segregation tables; secondary containment 110% of largest container; local exhaust ventilation for vapours; ATEX zoning for flammable liquids and gases; IECEx equipment; spill control; emergency showers; gas detection; ventilation and explosion relief where applicable. |
| 14 | High-Rise Buildings (>23 m or >6 storeys) | Refuge floors every 25 floors in Abu Dhabi or 30 floors in Dubai where applicable; fire command centre at ground / first floor; 2-hour rated core; phased evacuation; voice evacuation system EN 60849 Class A; pressurised stairwells; firefighting shafts; helicopter landing area for buildings over 150 m AGL where required. |
| 15 | Healthcare Facilities | NFPA 101 and NFPA 99; oxygen storage remote from building; isolated power systems in operating rooms; smoke zones; patient evacuation procedures; diesel generators with 4-hour tank; medical gas pipeline systems ISO 7396; nurse call, emergency power, and compartmentation. |
| 16 | Educational Facilities | Maximum travel distance 45 m; two exits from rooms over 49 students; smoke alarms in rooms and corridors; lockdown procedures; assembly points; fire drills; protected stairs; safe discharge; laboratories and workshops treated for special hazards. |
| 17 | Assembly Occupancies | Occupant capacity: 0.65 m²/person theatre seating and 0.46 m²/person standing; emergency lighting in seating areas; exit signs above every aisle; sprinklers required for more than 300 occupants; pre-action systems for museum / gallery areas; crowd management; panic hardware. |
| 18 | Industrial and Storage | NFPA 13 in-rack sprinklers for palletised storage over 3.7 m; flue spaces; commodity classification; NFPA 30 flammable-liquid storage; dust collection explosion protection under NFPA 68 / 69; forklift charging; hazardous area classification; smoke vents where required. |
| 19 | Fire Codes Enforcement | Dubai Civil Defence inspection schedule; violation notices: first warning with 30 days rectification, second AED 10,000–500,000 fine, third closure order; annual fire safety certificate; responsible person designation; maintenance contracts; record keeping; Civil Defence portal submissions. |
| 20 | Referenced Standards | NFPA 1, 10, 11, 12, 13, 14, 15, 16, 17, 17A, 20, 25, 30, 30B, 45, 54, 58, 68, 72, 92, 99, 101, 110, 111, 130, 160, 232, 2001; BS 476 Parts 3/6/7/20/22; EN 1363, EN 54, EN 81-72, EN 1838, EN 12845; UL 300, UL 300A; FM DS 2-0, FM DS 3-26. |

### Fire Strategy Report — Typical UAE Contents

A complete fire strategy report for a UAE building commonly includes:

1. project description, height, area, occupancy, construction type, and authority jurisdiction;
2. applicable codes and standards;
3. occupancy classification and occupant load;
4. means of egress calculations, travel distance, stair capacity, exit discharge, and refuge strategy;
5. fire compartmentation plans and ratings;
6. façade fire strategy and cavity barrier design;
7. fire detection and alarm cause-and-effect matrix;
8. sprinkler and standpipe design basis;
9. smoke-control strategy;
10. firefighting access and Civil Defence vehicle access;
11. fire command centre layout;
12. fire pump and tank sizing;
13. emergency power and fire-rated cable strategy;
14. special hazards;
15. commissioning, inspection, and maintenance requirements.

### UAE Fire-System Commissioning Checklist

- Fire alarm panel programming and cause-and-effect tests.
- Manual call point, detector, sounder, beacon, and interface testing.
- Sprinkler flow switch and tamper switch testing.
- Fire pump churn, duty, diesel, and jockey pump testing.
- Hydrant and hose-reel flow testing.
- Stair pressurisation pressure and door-opening force testing.
- Smoke extract fan start, damper position, and make-up air testing.
- Generator transfer test for life-safety loads.
- Fire lift recall and firefighter operation.
- Emergency lighting 3-hour discharge test.
- Fire door inspection and self-closing verification.
- Penetration firestop inspection.
- Kitchen suppression and fuel shutoff test.
- Clean-agent room integrity / door fan test.

---

## SECTION F: ABU DHABI UTILITIES CONNECTION — DETAILED PROCESS

Utility connection in the UAE is a design-critical and programme-critical process. Early load estimates, room reservations, wayleave corridors, transformer requirements, meter locations, earthing arrangements, water storage, fire-water demand, district cooling, telecommunications, and road access must be coordinated before authority submission.

### ADDC (Abu Dhabi Distribution Company) Connection Process

#### Step 1: Pre-Application

- Obtain municipality no-objection where required.
- Prepare cadastral map.
- Confirm approved building permit status or permit pathway.
- Establish plot load assumptions, land-use, phasing, and expected energisation date.
- Identify whether the project is LV, MV, or requires primary substation coordination.

#### Step 2: Load Application through ADDC eServices Portal

- Submit connected load in kVA.
- State supply voltage: LV 415 V, MV 11 kV, or 33 kV as applicable.
- Provide diversity factor and load schedule.
- Submit architectural plan showing electrical room location.
- Include single-line diagram where requested, project location plan, owner / consultant details, and authority reference numbers.

#### Step 3: Feasibility Study

- ADDC performs network analysis.
- Typical duration: 10–20 working days, subject to project complexity and network constraints.
- If MV is required, allocate substation compound.
- Confirm cable route, access, transformer room, RMU location, metering approach, and any network reinforcement.

#### Step 4: Offer Letter

- ADDC issues offer letter.
- Capital contribution may apply if network reinforcement is required and shared with developer.
- Meter position is agreed.
- Supply point drawing is issued or confirmed.
- Developer reviews cost, programme, responsibilities, civil works, and access obligations.

#### Step 5: Technical Design Submission

- Submit HV / LV switchgear single-line diagram.
- Use ADDC-approved contractor where required.
- Include transformer room layout, RMU, LV panel, cable containment, earthing, ventilation, fire rating, access, and safety signage.
- Coordinate with architectural, structural, MEP, fire, and security drawings.

#### Step 6: Pre-Energisation Inspection

- ADDC inspector and contractor inspect installation.
- Check metering cabinet, CT / VT panels, cable termination, clearances, labels, earthing, safety equipment, access, and room readiness.
- Earthing test: ≤1 Ω for buildings over 250 kVA.
- Confirm protection settings and test certificates.

#### Step 7: Energisation Certificate

- ADDC issues energisation certificate after successful inspection and completion of required documentation.
- Building systems may then proceed to testing, commissioning, authority inspection, and handover as applicable.

#### ADDC Supply and Transformer Notes

- **LV supply limit:** up to 250 kVA single 415 V three-phase supply.
- **Above LV limit:** MV 11 kV ring main unit generally required.
- **MV transformers:** ADDC-approved; oil-cooled often preferred; 11 kV / 415 V, common capacities 1000 / 1600 / 2000 kVA.
- **Transformer room:** 2-hour fire-rated; oil sump; ventilation; minimum clearances; safe access; cable trenching; lifting / replacement route; fire detection; and signage.

### DEWA (Dubai Electricity and Water Authority) Connection Process

Although this section is placed under Abu Dhabi utility processes, Dubai projects commonly require parallel understanding of DEWA procedures because many UAE consultants work across emirates.

#### Step 1: DM Building Permit and NOC

- Obtain Dubai Municipality building permit and required NOCs.
- Coordinate with master developer, free-zone authority, Civil Defence, RTA, telecom providers, and district cooling provider where applicable.

#### Step 2: DEWA Digital Services Load Application

- Apply through DEWA Digital Services.
- Submit load schedule, drawings, project details, and consultant / contractor information.
- Provide electrical inspection certificate from DM-approved inspector where required.
- Confirm meter rooms, LV rooms, substation location, water meter chambers, and utility corridors.

#### Step 3: Load Scheduling and Smart Meter Installation

- DEWA schedules load and meter installation.
- Smart meter / AMI coordination is completed.
- Developer must ensure access, room readiness, labels, cable containment, and safety clearances.

#### Step 4: Connection to Network

- Underground HV cable may be required if load exceeds 400 kVA.
- DEWA contractor executes utility connection where required.
- Pillar box or service position may be placed at boundary.
- Civil works by developer include trenches, ducts, chambers, reinstatement, and access arrangements.

#### DEWA Shams Dubai — Solar PV Net Metering

- **Purpose:** approval for solar PV connection and net metering.
- **Application:** through DEWA portal.
- **Process:** design submission, contractor approval, technical inspection, reverse-flow meter, interconnection approval, and commissioning.
- **Export value noted for planning:** payment for excess exported at DEWA buy-back rate stated as AED 0.25/kWh for first 500 kW.
- **Design coordination:** roof loading, waterproofing, fire access, DC cable routes, inverter rooms, isolation, signage, O&M access, cleaning, and monitoring.

#### DEWA EV Green Charger

- **Scope:** public or semi-public EV charging registration.
- **DEWA role:** DEWA may install and operate in some cases depending on programme and site.
- **Design considerations:** electrical capacity, load management, billing, access control, fire strategy, ventilation in enclosed car parks, parking signage, disabled-accessible EV bays, and future expansion conduit.

### Utility Coordination Checklist for UAE Building Projects

| Discipline | Utility Coordination Item | Typical Evidence |
|---|---|---|
| Architecture | Electrical rooms, transformer rooms, meter rooms, access doors, clearances | Plans, sections, room data sheets |
| Structural | Transformer plinths, cable trenches, crane / replacement routes, openings | Structural drawings, load checks |
| Electrical | Load schedule, SLD, protection, earthing, metering | SLD, calculations, test certificates |
| Mechanical | Ventilation and cooling for electrical rooms, smoke control interface | HVAC drawings, heat load calculations |
| Fire | Fire rating, detection, suppression, emergency access | Fire strategy, Civil Defence drawings |
| Civil | Utility corridors, trenches, chambers, reinstatement | Infrastructure drawings, NOCs |
| Sustainability | PV, EV charging, metering, demand response | Energy model, PV drawings, meter plan |
| FM / Operations | Access, maintainability, replacement route, safety procedures | O&M manuals, training records |

### Practical Programme Risks

- Late increase in connected load.
- Under-sized transformer room or missing replacement route.
- Utility corridor conflict with landscape, roads, basements, or other services.
- Earthing test failure.
- Meter room not ready for inspection.
- Fire rating or ventilation not coordinated.
- PV or EV load added after DEWA / ADDC load approval.
- District cooling interface load not aligned with electrical and water assumptions.
- Delayed NOC from road, telecom, Civil Defence, municipality, or master developer.

---

*Appendix sections A–F appended: July 2026*
