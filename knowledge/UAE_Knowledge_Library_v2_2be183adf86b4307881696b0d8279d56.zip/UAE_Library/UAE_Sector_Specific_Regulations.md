# UAE Sector-Specific Regulations

**Scope and date.** This file is an expanded sector-by-sector regulatory library for the United Arab Emirates as of **9 July 2026**. It preserves useful material from the previous draft while expanding it into a deeper official-source reference. The file is designed as a working research document, not legal advice. Where a point is based on a live legal text, regulator page, official service page, or authority announcement, it is cited inline. Where a previous draft contained a current or future claim that could not be verified from the available official/authoritative research materials, the claim is clearly marked as **[Not independently verified in the available sources]** rather than being presented as fact.

**How to use this file.** The UAE regulates many sectors through a layered system: federal decree-laws and Cabinet decisions; emirate-level laws and executive councils; free-zone regulators such as the DIFC, ADGM, VARA and DMCC; and sector regulators such as TDRA, FANR, GCAA, CBUAE, DHA, DoH, MOHAP, KHDA, ADEK, DLD/RERA, ADAFSA, MOCCAE and others. A complete compliance review for a project normally requires checking (1) the federal law, (2) the local emirate regulator, (3) free-zone rules if the entity is licensed in a free zone, (4) sector circulars and standards, and (5) licence conditions.

## 1. Sector regulator map

| Sector | Primary federal / UAE-wide authorities | Emirate / free-zone authorities commonly relevant | Core instruments and portals |
| :--- | :--- | :--- | :--- |
| Electricity, water and energy transition | Ministry of Energy and Infrastructure; Federal electricity and water entities; UAE Energy Strategy 2050 information on the UAE Government portal | DEWA in Dubai; Abu Dhabi Department of Energy, EWEC, TRANSCO, ADDC/AADC; Etihad Water and Electricity for Northern Emirates | DEWA tariff and billing pages; Abu Dhabi DoE tariff framework; energy-strategy pages; utility connection and conservation rules [[1]](#ref1) [[2]](#ref2) [[3]](#ref3) |
| Nuclear | Federal Authority for Nuclear Regulation (FANR); Emirates Nuclear Energy Corporation (ENEC) as programme owner / operator group | Barakah plant in Abu Dhabi / Al Dhafra; Nawah Energy Company | Federal Law No. 6 of 2009 on peaceful nuclear energy; FANR regulations; ENEC Barakah official FAQs [[4]](#ref4) |
| Oil and gas | Federal and emirate energy authorities; in Abu Dhabi, Supreme Council for Financial and Economic Affairs; ADNOC group | Dubai ENOC; Sharjah SNOC; free zones for trading and storage | ADNOC concessions, listed-company disclosures and Abu Dhabi energy governance; IFAD/Murban market structure where relevant [[5]](#ref5) [[6]](#ref6) |
| Telecommunications and digital government | Telecommunications and Digital Government Regulatory Authority (TDRA) | Operators e& and du; free-zone data-centre and cloud activities; emirate digital government entities | Federal telecom law framework; TDRA policies; internet guidelines; numbering, spectrum, type approval and licensing [[7]](#ref7) [[8]](#ref8) |
| Cybersecurity and cybercrime | UAE Cybersecurity Council; TDRA; Ministry of Interior; UAE Government cyber-safety portal | Dubai Electronic Security Center and emirate-level cyber entities | Federal Decree-Law No. 34 of 2021 on rumours and cybercrimes; National Cybersecurity Strategy; IA Regulation; reporting portals [[9]](#ref9) [[10]](#ref10) |
| Personal data and privacy | UAE Data Office; UAE Government data protection portal | DIFC Commissioner of Data Protection; ADGM Office of Data Protection; sector regulators | Federal Decree-Law No. 45 of 2021 on Personal Data Protection; DIFC/ADGM regimes; breach notification and data-subject rights [[11]](#ref11) [[12]](#ref12) |
| Roads, rail, public transport and logistics | Ministry of Energy and Infrastructure; Ministry of Interior; GCAA for aviation; federal maritime bodies | Dubai RTA; Abu Dhabi Mobility / ITC; Etihad Rail; DP World; Abu Dhabi Ports | Federal traffic regulation; RTA law and policies; Etihad Rail network materials; port and maritime regulations [[13]](#ref13) [[14]](#ref14) [[15]](#ref15) |
| Aviation and drones | General Civil Aviation Authority (GCAA) | Dubai Civil Aviation Authority; airport operators; customs/free zones | UAE civil aviation regulations; UAS / drone registration; airport and airline licensing; airworthiness and safety rules [[16]](#ref16) |
| Financial services and markets | UAE Central Bank; new federal Capital Market Authority / former SCA framework; Ministry of Finance | DIFC/DFSA; ADGM/FSRA; Dubai VARA; DFM, ADX, Nasdaq Dubai | Banking, insurance, payment services, capital markets, virtual assets and AML/CFT frameworks [[17]](#ref17) [[18]](#ref18) [[19]](#ref19) |
| Healthcare | Ministry of Health and Prevention (MOHAP) | Dubai Health Authority (DHA); Abu Dhabi Department of Health (DoH); Emirates Health Services; free-zone health clusters | Medical facility licensing; professionals licensing; medicines registration; health insurance; medical liability; health data exchange [[20]](#ref20) [[21]](#ref21) [[22]](#ref22) |
| Education | Ministry of Education; Commission for Academic Accreditation (CAA) | KHDA in Dubai; ADEK in Abu Dhabi; SPEA in Sharjah | School licensing, inspection, fees, curricula approvals, higher education accreditation [[23]](#ref23) [[24]](#ref24) |
| Real estate | Federal ownership and civil-code principles | Dubai Land Department / RERA / RDC; Abu Dhabi Real Estate Centre; Sharjah, Ajman and other land departments | Title registration, escrow, off-plan, brokerage, leasing, rent index, tenancy registration [[25]](#ref25) |
| Food, agriculture, F&B and consumer product safety | Ministry of Climate Change and Environment (MOCCAE); UAE Government food safety portal | ADAFSA in Abu Dhabi; Dubai Municipality; Sharjah Municipality; local economic departments | Federal Law No. 10 of 2015 on Food Safety; ZAD; FIRS; halal and labelling; Abu Dhabi Nutri-Mark [[26]](#ref26) [[27]](#ref27) [[28]](#ref28) |
| Tourism, hospitality, media and culture | Ministry of Economy; National Media Office / UAE Media Council context; federal consumer and AML laws | Dubai DET/DTCM; Abu Dhabi DCT; local tourism, hotel, alcohol and event regulators; Media City and Creative City free zones | Hotel classification, tourism licences, event permits, media-content rules, advertising and influencer permits |
| AI, digital economy and space | UAE AI Office; TDRA; UAE Data Office; UAE Space Agency | DIFC/ADGM fintech regulators; Dubai AI and digital government bodies; MBRSC and Yahsat ecosystem | UAE AI Strategy 2031; PDPL; sectoral AI guidance; space law and licensing [[29]](#ref29) |

## 2. Energy, electricity, water, oil, gas and nuclear

### 2.1 Electricity and water sector structure

The UAE electricity and water sector is not a single national retail market. It is divided by emirate and utility area. Dubai is served by the **Dubai Electricity and Water Authority (DEWA)**; Abu Dhabi is structured around the Department of Energy, EWEC, TRANSCO and the distribution companies ADDC/AADC; and the Northern Emirates are primarily served by **Etihad Water and Electricity**. The Abu Dhabi Department of Energy explains that water and electricity sector charges include wholesale generation / production, transmission, distribution and supply, as well as wastewater and recycled-water activities, and that intra-sector tariffs include Bulk Supply Tariffs and Transmission Use of System charges [[2]](#ref2).

The practical compliance consequence is that an industrial, residential, data-centre, district-cooling, hotel or major commercial project must check the utility area first. Connection requirements, deposit rules, approved contractor requirements, metering, load-approval processes and tariff categories differ by utility. In Dubai, DEWA states that slab tariffs and fuel surcharge are applied on monthly electricity and water consumption, with progressive pricing as consumption increases and fuel surcharge calculated from electricity and water consumption [[1]](#ref1). In Abu Dhabi, the DoE framework differentiates intra-sector economic charges from end-user tariffs and directs customers to the distribution companies for end-user tariff details [[2]](#ref2).

### 2.2 Dubai electricity and water — DEWA

DEWA is the local integrated utility responsible for Dubai electricity and water supply. The prior draft listed Dubai slab tariffs as AED 0.23/kWh to AED 0.38/kWh for electricity slabs and AED 0.03 to AED 0.04 per imperial gallon for water slabs. The supporting research confirmed the official DEWA page describes the **slab-tariff concept** and fuel surcharge but did not capture the full current table in the crawler output; therefore any exact 2026 numerical tariff table in this file should be checked against the live DEWA tariff page before reliance [[1]](#ref1).

**Operational items normally checked for a Dubai project:**

- **Electricity load approval.** Developers and consultants must obtain DEWA approvals for connected load, substation requirements, metering and energisation. High-load projects such as data centres, hotels, cold-storage, district-cooling plants and heavy commercial facilities require early coordination.
- **Water demand and infrastructure connection.** Domestic water, fire-water storage, irrigation and process-water demand are treated separately in engineering submissions.
- **Fuel surcharge.** DEWA states that fuel surcharge varies with fuel prices supplied to DEWA generation plants and is calculated based on electricity and water consumption [[1]](#ref1).
- **Solar PV / distributed generation.** Dubai solar projects are subject to DEWA connection rules and approved-contractor processes. The previous draft described Shams Dubai net metering; that programme should be checked against current DEWA solar-connection guidance before project reliance.
- **Conservation and demand management.** DEWA tariff policy is presented as supporting efficient consumption and conservation [[1]](#ref1).

### 2.3 Abu Dhabi electricity, water and recycled water

The Abu Dhabi Department of Energy describes a sector in which transactions occur on an economic basis, with the government able to set tariffs below cost and subsidise the distribution companies for the shortfall [[2]](#ref2). The DoE also identifies: (1) EWEC as responsible for the Electricity and Water Bulk Supply Tariff, (2) TRANSCO as responsible for Transmission Use of System charges, and (3) Abu Dhabi Sewerage Services Company as responsible for recycled-water bulk-supply tariff arrangements [[2]](#ref2).

The supporting research retrieved a 2025 tariff PDF from TAQA Distribution/ADDC and a secondary 2026 tariff guide. Because the delegated task requires official/authoritative material, this file treats **TAQA Distribution / ADDC current tariff documents and DoE pages as the authoritative starting point** and treats third-party calculator pages as non-binding. The research captured official business-rate snippets showing, for example, business water and electricity categories in 2025 tariff materials, but a full 2026 end-user tariff table was not captured from an official page in the available materials [[2]](#ref2).

**Abu Dhabi sector roles:**

| Role | Entity | Function |
| :--- | :--- | :--- |
| Policy / regulation | Abu Dhabi Department of Energy | Sector regulation, licensing, price-control and tariff framework [[2]](#ref2) |
| Bulk procurement | Emirates Water and Electricity Company (EWEC) | Bulk power and water procurement and Bulk Supply Tariff setting within the sector framework [[2]](#ref2) |
| Transmission | TRANSCO | Electricity and water transmission; Transmission Use of System charges [[2]](#ref2) |
| Distribution and supply | ADDC and AADC | End-user electricity and water distribution in Abu Dhabi city / regions and Al Ain |
| Recycled water / wastewater | ADSSC and related entities | Recycled-water bulk and end-user tariff chain [[2]](#ref2) |

### 2.4 Etihad Water and Electricity / Northern Emirates

Etihad Water and Electricity serves major parts of the Northern Emirates. The previous draft described residential, industrial and water tariff structures; however, the available supporting research did not capture a complete official 2026 EtihadWE tariff table. Therefore, exact tariff numbers from the earlier draft are preserved only as **[Not independently verified in the available sources]**. The compliance rule remains clear: connection, billing, load approval and service rules in Ras Al Khaimah, Ajman, Umm Al Quwain and Fujairah should be checked against EtihadWE’s live tariff/service pages and the project’s emirate-specific planning authority.

### 2.5 Renewable energy and clean-energy strategy

The UAE Government portal describes national energy-transition policy through the UAE Energy Strategy 2050 and related clean-energy targets [[3]](#ref3). Dubai’s solar development is anchored by DEWA’s Mohammed bin Rashid Al Maktoum Solar Park, while Abu Dhabi has major utility-scale solar projects such as Noor Abu Dhabi and Al Dhafra Solar PV. The prior draft listed the Mohammed bin Rashid Al Maktoum Solar Park target of 5,000 MW by 2030 and Al Dhafra Solar PV at 2,100 MW; these are consistent with widely published government and project materials, but users should verify final operating-capacity and commissioning details against the relevant project authority when using the figures in a tender or feasibility model.

**Common renewable-energy compliance issues:**

- land allocation and grid-connection approvals;
- environmental impact assessment and construction permits;
- power purchase agreement / procurement framework;
- grid-code compliance and metering;
- battery-energy-storage permitting where applicable;
- occupational safety and electrical contractor licensing;
- import and conformity requirements for PV modules, inverters and batteries;
- civil-defence requirements for battery or electrical rooms.

### 2.6 Nuclear energy — FANR, ENEC and Barakah

The UAE nuclear-energy sector is regulated at federal level by **FANR** under the peaceful-use nuclear framework. ENEC’s official Barakah materials state that the UAE signed a **123 Agreement with the United States** incorporating non-proliferation commitments [[4]](#ref4). The research also captured World Nuclear Association material stating that ENEC signed a fuel-supply agreement with Framatome in July 2025 for nuclear fuel assemblies for Barakah, with first deliveries later in 2025 as part of a fuel qualification programme to diversify the plant’s fuel supply chain [[30]](#ref30).

The earlier file correctly identified the Barakah plant as a four-unit APR-1400 nuclear power plant with total capacity commonly described as 5,600 MW. The current available research confirms Barakah is central to UAE decarbonisation and energy-security policy, but exact 2026 generation contribution percentages should be checked against ENEC/FANR annual data before citing in a financial model.

**Nuclear compliance themes:**

- **Independent regulator.** FANR licensing, inspection and enforcement apply across construction, commissioning, operation, radiation protection, safeguards, emergency preparedness and waste management.
- **Non-proliferation.** The UAE’s nuclear policy is built around no domestic enrichment and no reprocessing; the 123 Agreement is a key international reference point [[4]](#ref4).
- **Safety case.** Plant operation depends on licensing, safety analysis, operating limits and conditions, emergency arrangements, security arrangements and environmental monitoring.
- **Supply chain.** Nuclear-grade procurement requires qualification, quality assurance, traceability and regulator-auditable documentation.
- **Radiation sources.** FANR also regulates non-power uses of ionising radiation in medicine, industry and research.

### 2.7 Oil and gas — Abu Dhabi, Dubai and Sharjah

The UAE’s upstream oil and gas governance is emirate-led. Abu Dhabi’s sector is dominated by ADNOC and Abu Dhabi government policy; Dubai has ENOC; Sharjah has SNOC. The previous file noted Abu Dhabi’s Supreme Council for Financial and Economic Affairs as the high-level Abu Dhabi authority and ADNOC as the national company. Supporting research captured ADNOC official announcements about its listed companies and 2025 internal transfers of shareholdings to XRG [[5]](#ref5) [[6]](#ref6).

ADNOC announced in October 2025 that six publicly listed companies targeted AED 158 billion in dividends through 2030, subject to approvals, and that those six listed companies represented more than AED 550 billion of market capitalisation [[5]](#ref5). ADNOC separately announced internal transfers of shareholdings in listed companies to XRG in 2025 [[6]](#ref6). These facts matter for sector-specific regulation because the UAE oil-and-gas sector is increasingly linked to listed-company governance, investor disclosure, related-party transactions and capital-markets regulation.

**Oil and gas regulatory checklist:**

| Topic | Typical authority / instrument | Practical compliance notes |
| :--- | :--- | :--- |
| Upstream concessions | Abu Dhabi government / ADNOC concession framework | Field-specific concession rights, production-sharing or joint-venture arrangements, HSE, local content, export controls |
| Midstream pipelines and terminals | ADNOC / port authorities / civil defence / environmental authorities | Pipeline integrity, hazardous-area classification, emergency response, land corridors, maritime interfaces |
| Downstream refining and distribution | ADNOC, ENOC, local economic departments, civil defence | Fuel stations, storage tanks, LPG, hazardous materials, fire safety, metrology and consumer protection |
| Trading and derivatives | IFAD, exchanges, financial regulators, free zones | Murban crude trading, exchange membership, clearing, AML, sanctions screening |
| Environmental controls | MOCCAE, EAD, Dubai Municipality, emirate environment authorities | Flaring, emissions, waste, oil-spill response, EIA, marine protection |

## 3. Telecommunications, digital infrastructure and internet regulation

### 3.1 TDRA and licensed operators

The **Telecommunications and Digital Government Regulatory Authority (TDRA)** regulates the telecommunications and digital government sector. The earlier file referenced Federal Decree-Law No. 3 of 2003 as amended and identified e& and du as the principal licensed telecom operators. TDRA’s official website is the starting point for spectrum, numbering, type approval, telecom licensing, digital-government policy and internet-guideline materials [[7]](#ref7) [[8]](#ref8).

The 2025/2026 research captured TDRA’s official announcement that it launched the **6th Generation (6G) Initiative** on 11 November 2025. TDRA stated that the initiative was announced during the inaugural meeting of the 6G Committee, with participation by government entities, telecom service providers, universities, R&D centres and global mobile technology providers [[7]](#ref7). This is one of the clearest official 2025 updates in the sector.

### 3.2 Licensing and telecom activities

Telecommunications licensing in the UAE is not limited to consumer mobile networks. Relevant regulated activities include:

- public fixed and mobile networks;
- internet access and broadband services;
- satellite and VSAT services;
- spectrum use and radio equipment;
- number allocation and portability;
- type approval for telecom equipment;
- cloud, data-centre and digital infrastructure services where telecom or data-sovereignty rules apply;
- critical information infrastructure and emergency communications.

Telecom equipment importers, IoT-device vendors, drone-communications providers, smart-meter vendors, building-management-system suppliers and industrial-control vendors may need TDRA type approval or spectrum confirmation even when they do not operate a telecom network.

### 3.3 Internet content, prohibited categories and filtering

TDRA’s Internet Guidelines page explains that a list of prohibited content categories has been defined and that internet service providers in the UAE are obliged to block access to websites and webpages containing content falling within those prohibited categories [[8]](#ref8). The page gives pornography and nudity as examples of content considered unacceptable under UAE public-morality standards and advises websites targeting UAE users to respect the prohibited-content categories to avoid denial of access [[8]](#ref8).

**Compliance implications:**

- digital platforms should review UAE content rules before targeting UAE users;
- advertising, influencer content, media streaming and user-generated-content services should build moderation workflows;
- gambling, adult content, hate speech, extremist content, illegal drugs and other prohibited categories are high-risk;
- platform terms should allow geo-blocking, takedown and regulator-response mechanisms;
- businesses should not advise customers to bypass lawful filtering.

### 3.4 VoIP, VPN and cybercrime

The earlier file stated that unlicensed VoIP remains restricted and that VPN misuse is regulated. The available research confirms that Federal Decree-Law No. 34 of 2021 is treated as the UAE’s primary cybercrime legislation by authoritative sources and that VPN misuse for illegal purposes can fall within cybercrime provisions [[9]](#ref9). Because consumer VoIP availability can change by app, operator, plan and business licence, users should verify live operator and TDRA policies before making customer-facing statements.

### 3.5 Cybersecurity Council, national strategy and reporting

The UAE Government cyber-safety portal states that cyber safety and digital security are serious issues in the UAE and lists resources including the law on combatting rumours and cybercrimes, the RZAM app, online cybercrime reporting, UAE Information Assurance Regulation, digital wellbeing support, digital security, children’s digital safety, eSignature and digital certification, the UAE Cybersecurity Council, the Global Cybersecurity Index and the Dubai Cyber Index [[10]](#ref10). The research also captured a TDRA-hosted National Cybersecurity Strategy PDF whose vision is to create safe and resilient cyber infrastructure enabling national development [[31]](#ref31).

**Cybersecurity compliance baseline:**

| Control family | UAE-facing requirement area | Examples |
| :--- | :--- | :--- |
| Governance | Board / executive accountability; security policies | Cyber-risk register, approved information-security policy, incident-response plan |
| Asset and data inventory | Know systems, data and third parties | Data maps, cloud inventory, IoT inventory, privileged-access register |
| Technical controls | Protect networks and systems | MFA, endpoint protection, segmentation, vulnerability management, secure configuration |
| Incident response | Report, contain and preserve evidence | SOC process, regulator-notification playbook, cybercrime reporting pathway |
| Critical infrastructure | Higher expectations for essential services | Utilities, telecom, aviation, finance, healthcare, ports and government suppliers |
| Awareness | User behaviour and phishing resilience | Cyber Pulse / awareness, staff training, supplier obligations |

## 4. Personal data protection, privacy and digital compliance

### 4.1 Federal PDPL

The UAE’s onshore federal data protection framework is anchored by **Federal Decree-Law No. 45 of 2021 regarding the Protection of Personal Data**. The UAE Government data-protection page lists personal data protection law, data and privacy protection, and the UAE Data Office as key resources [[11]](#ref11). DataGuidance summarises the PDPL as covering processing of personal data belonging to data subjects within the UAE and outlining consent conditions, data-subject rights, controller/processor obligations, breach notification, data-protection officer requirements and technical/organisational security measures [[12]](#ref12).

The previous draft stated that “full enforcement” was active in 2026 and that penalties were up to AED 20 million. The available research did not capture an official penalty table or a confirmed “full enforcement” date. Therefore that statement is **[Not independently verified in the available sources]**. The accurate source-grounded position is that the PDPL exists, the UAE Data Office is the regulator identified in authoritative summaries, and businesses should design compliance around the law’s core obligations [[11]](#ref11) [[12]](#ref12).

### 4.2 PDPL rights and obligations

DataGuidance identifies rights and obligations including access, rectification, correction, deletion, restriction of processing, cessation of processing, transfer of data, objection to automated processing, cross-border transfer requirements, security obligations and breach notification [[12]](#ref12). DLA Piper’s data-protection summary similarly highlights that the PDPL introduces GDPR-like obligations and data-subject rights, and that breach notification and security requirements raise cyber-security expectations for businesses in the UAE [[32]](#ref32).

**Practical PDPL checklist:**

- identify controllers, processors and joint-controller relationships;
- map data categories, including sensitive health, biometric, financial, location and children’s data;
- document lawful basis / consent where required;
- maintain privacy notices in accessible language;
- implement data-subject request procedures;
- review cross-border transfer mechanisms;
- ensure processor contracts include confidentiality, security, sub-processing and deletion/return terms;
- maintain breach response and regulator-notification process;
- align marketing databases and profiling with consent and opt-out requirements;
- coordinate PDPL compliance with cybercrime, telecom, health-data, banking and free-zone regimes.

### 4.3 Free-zone privacy overlays

Many UAE businesses operate in DIFC or ADGM, each of which has its own data-protection regime. A company licensed in a financial free zone may therefore have to comply with the free-zone law as well as federal rules when it processes data outside the zone or interacts with onshore data subjects. Health, telecom, banking and education sectors also have sectoral confidentiality or data-sharing rules. The safest method is to build one data-governance programme that maps every applicable regulator and applies the strictest relevant operational control.

## 5. Transport, roads, rail, aviation, maritime and logistics

### 5.1 Federal traffic regulation and road safety

The earlier file referenced Federal Decree-Law No. 7 of 2023, while the supporting research located **Federal Decree-Law No. 14 of 2024 on Traffic Regulation**, described by an authoritative legal source as replacing Federal Law No. 21 of 1995 on Traffic [[13]](#ref13). The UAE Legislation portal download was blocked by a security service in the research crawl, so this file cites the legal-source summary and marks exact article-level extracts as requiring verification from the official legislation PDF.

The research captured legal commentary stating that certain serious offences under the updated traffic framework include fines of AED 50,000 for using fake, forged or obscured number plates, allowing a person under 18 to drive, and reckless driving, while jumping a red light was described as AED 3,000, 12 black points and 30-day impoundment [[13]](#ref13). Because fine tables can vary between federal law, implementing regulations and emirate police systems, users should verify the live Dubai Police / Abu Dhabi Police / Ministry of Interior fine schedule before operational reliance.

### 5.2 Dubai RTA and public transport

Dubai’s Roads and Transport Authority regulates road transport, public transport, taxis, marine transit, driver licensing interfaces, Salik/tolls, metro/tram operations and many mobility services. The RTA portal is the official gateway for customer and business services [[14]](#ref14). The research captured the 2026 Dubai Media Office announcement that the **Dubai Metro Gold Line** was approved at AED 34 billion, expanding the Dubai Metro network by 35% with completion scheduled in the announcement text [[33]](#ref33). Railway Gazette and other sources describe the Gold Line as a 42 km fully underground route with 18 stations serving strategic areas and expected to relieve congestion at key Red Line sections [[34]](#ref34).

The earlier file did not include Dubai’s newest metro expansion. The expanded record should include:

| Dubai rail / metro item | Status in available sources | Regulatory relevance |
| :--- | :--- | :--- |
| Red and Green Lines | Existing metro network | RTA operations, station-area planning, transit-oriented development, advertising and retail concessions |
| Route 2020 / Expo-related extension | Existing network expansion | Interchange, ridership, real estate and event connectivity |
| Blue Line | Officially announced earlier; research cited 30 km / 14 stations from secondary sources | Land acquisition, utility diversion, construction permits, station integration |
| Gold Line | 2026 Dubai Media Office announcement captured: AED 34bn, network expansion by 35% [[33]](#ref33) | Major underground civil works, rail safety, tunnelling, utility protection, TOD and congestion policy |
| Salik and parking | RTA / Salik PJSC systems | Tolling, parking tariffs, vehicle registration, fleet costs |

### 5.3 Abu Dhabi Mobility and roads

Abu Dhabi’s public-transport and road-mobility services are now accessed through **Abu Dhabi Mobility** / Integrated Transport Centre channels. The official portal includes public transport, maritime mapping and mobility services, and the research captured a 2026 “One Million Green Kilometres” milestone item on the portal [[15]](#ref15). Abu Dhabi road projects, bus systems, taxis, school transport, parking and tolls require checking DMT / Abu Dhabi Mobility service conditions and local permits.

The research repeatedly attempted to verify detailed Abu Dhabi Metro “Gold/Silver line” claims but did not obtain an official current project page. Therefore any detailed Abu Dhabi Metro route, cost, station count or launch schedule in non-official sources is **[Not independently verified in the available sources]**. The verified position is that Abu Dhabi Mobility is the official mobility portal and that specific metro claims require further official confirmation [[15]](#ref15).

### 5.4 Etihad Rail

Etihad Rail is the national railway project. The research captured Railway Technology material stating that passenger trains are planned to operate at 200 km/h with capacity of 400 passengers per train, and that freight wagons include hopper, flat, single-well container and five-car well-container wagons equipped with braking, signalling, control, communication and safety systems [[35]](#ref35). It also captured broader descriptions of a network intended to connect all seven emirates and link to Saudi Arabia via Ghuweifat, with standard-gauge, mixed-use traffic, European signalling and heavy-haul axle loads in secondary material [[36]](#ref36).

The previous draft listed a very specific 2026-2027 passenger launch schedule with dates and fares. The supporting materials did not capture an official Etihad Rail page confirming those exact dates and fares. Therefore that schedule is **[Not independently verified in the available sources]** and should not be treated as final. A cautious compliance record should state only that passenger service planning and integration were reported for 2026 in authoritative media, but exact opening dates, stations and fares must be verified from Etihad Rail before use in a customer or investment document.

### 5.5 Aviation — GCAA, airports and airlines

The **General Civil Aviation Authority (GCAA)** is the federal civil-aviation regulator. The previous draft identified GCAA as the aviation authority and noted the AED 128 billion expansion of Al Maktoum International Airport (DWC), targeting a future 260 million passenger capacity. The DWC expansion claim is widely publicised by Dubai official channels, but the supporting snippets in this task focused more on fleet, airport and UAS evidence. Users should verify DWC project phasing against Dubai Airports / Dubai Media Office before reliance in a project schedule.

Aviation-sector compliance includes air-operator certificates, airport operator approvals, ground-handling, cargo and dangerous goods, airworthiness, maintenance organisation approvals, pilot licensing, safety management systems, accident/incident reporting, airport security, slot coordination, consumer travel rules and customs/immigration processes.

### 5.6 Drones and unmanned aircraft systems

GCAA’s UAS registration page states that all UAS/drones used by individuals for recreational purposes shall be registered with GCAA, and the research captured GCAA requirements that the user and UAS/drone must be registered before flying; UAS/drones weighing 5 kg or less are only allowed in approved flying zones indicated in the “My Drone Hub” mobile application; camera usage is only allowed in flying zones; drones must not be equipped with drop/release devices; and flight must remain within line-of-sight and not more than 400 feet above ground level [[16]](#ref16).

**Drone compliance table:**

| Use case | Core requirements from available official source | Additional likely requirements |
| :--- | :--- | :--- |
| Recreational drone | User and drone registration; approved green zones; line-of-sight; max 400 ft; camera only in permitted zones [[16]](#ref16) | Emirate-specific rules, privacy rules, no-fly-zone checks |
| Commercial photography / survey | GCAA registration; organisation/operator pathway identified in research [[16]](#ref16) | Commercial licence, insurance, client/site permits, DCAA or emirate aviation approvals |
| Industrial inspection | Registration and operator controls | Critical infrastructure owner approval, HSE method statement, data security |
| BVLOS / autonomous delivery | Not confirmed as generally permitted in available official source | Specific GCAA approval, safety case, airspace coordination, liability and insurance |

### 5.7 Maritime, ports and logistics

The UAE’s logistics sector is built around Jebel Ali, Khalifa Port, Port Fujairah, Sharjah ports, airports, free zones, customs corridors and the emerging rail network. The research captured Abu Dhabi Ports’ official statement that it owns and operates 10 ports and terminals in the UAE, with facilities positioned to use sea, air, road and rail connectivity [[37]](#ref37). Third-party logistics research listed Jebel Ali, Khalifa Port and other UAE ports with throughput/capacity data, but such numerical figures should be checked against DP World, Abu Dhabi Ports and port annual reports before reliance [[38]](#ref38).

Maritime-sector regulation includes vessel registration, flag-state and port-state controls, marine zoning, pilotage, bunkering, dangerous goods, free-zone licensing, customs, bonded warehouses, sanctions screening, environmental rules and oil-spill preparedness. Abu Dhabi Mobility’s portal includes Al Nalia, described in the crawl as an interactive map application for public maritime users and mariners to view maritime zoning [[15]](#ref15). That is a practical example of how maritime compliance is increasingly map- and permit-based.

## 6. Financial services, capital markets, banking, insurance and virtual assets

### 6.1 Regulatory architecture

The UAE financial-services system has several layers:

- **UAE Central Bank (CBUAE)** for banks, finance companies, payment services, stored-value facilities, insurance, exchange houses and monetary/financial stability.
- **Federal capital markets regulator.** The research captured 2026 legal updates stating that Federal Decree-Law No. 32 of 2025 created the Capital Market Authority framework and Federal Decree-Law No. 33 of 2025 regulates capital markets, entering into force on 1 January 2026 and repealing Federal Law No. 4 of 2000 [[17]](#ref17) [[18]](#ref18).
- **DFM, ADX and Nasdaq Dubai** as trading venues / exchanges, with DFM describing itself as a platform for trading DFM and Nasdaq Dubai listed securities and providing investor-number services [[39]](#ref39).
- **DIFC / DFSA** and **ADGM / FSRA** for financial free-zone entities.
- **Dubai VARA** for Dubai virtual-asset activities outside DIFC.

### 6.2 2026 federal capital-markets overhaul

Cleary Gottlieb’s legal update states that the UAE President issued Federal Decree-Law No. 32 of 2025 concerning the Capital Market Authority and Federal Decree-Law No. 33 of 2025 concerning regulation of the capital market, that the Decree-Laws entered into force on 1 January 2026, and that they repealed Federal Law No. 4 of 2000 concerning the Emirates Securities and Commodities Authority and Market [[18]](#ref18). King & Spalding similarly states that all entities and persons subject to the Capital Market Law must regularise their status within one year from 1 January 2026, extendable by the CMA, and that existing Cabinet and Authority decisions remain in force to the extent not conflicting until replaced [[17]](#ref17).

**Key practical effects:**

| Topic | Change / rule captured in available sources | Compliance action |
| :--- | :--- | :--- |
| Regulator identity | SCA framework replaced / succeeded by CMA under new laws [[17]](#ref17) [[18]](#ref18) | Update licences, policies, legal references and board packs |
| Effective date | 1 January 2026 [[17]](#ref17) [[18]](#ref18) | Treat 2026 as transition year |
| Repealed law | Federal Law No. 4 of 2000 repealed according to legal updates [[17]](#ref17) [[18]](#ref18) | Stop relying on old law except preserved decisions |
| Regularisation | One-year period from 1 January 2026, extendable by CMA [[17]](#ref17) | Gap assessment and filings by 1 January 2027 unless extended |
| Existing decisions | Existing Cabinet/Authority decisions remain if not conflicting until replaced [[17]](#ref17) | Maintain old-rule compliance while monitoring implementing decisions |

### 6.3 Banking, payments and insurance

CBUAE regulation covers prudential requirements, consumer protection, AML/CFT, payment services, stored value, exchange houses, finance companies, insurance and outsourcing. Even where detailed CBUAE pages were not captured in the supporting research, no UAE financial-services compliance library should omit the Central Bank. Project teams should check CBUAE rulebooks and notices for:

- licensing category and permissible activities;
- fit-and-proper requirements for controllers, directors and senior managers;
- minimum capital and prudential ratios;
- conduct-of-business and consumer-protection rules;
- AML/CFT and sanctions screening;
- outsourcing, cloud and technology-risk management;
- open finance / open banking obligations;
- complaints and dispute mechanisms;
- insurance distribution and policy wording approval where applicable.

### 6.4 Virtual assets — VARA and free zones

The earlier draft stated that Dubai’s Virtual Assets Regulatory Authority (VARA) has licensing categories including advisory, broker-dealer, custody, exchange, lending/borrowing, management/investment and transfer/settlement, with a standard application fee of AED 40,000. The supporting research did not capture the official VARA fee schedule; therefore the fee figure is **[Not independently verified in the available sources]**. The category list is consistent with the widely known VARA rulebook structure, but the live VARA rulebooks should be checked before quoting fees or application steps.

**Virtual-asset compliance framework:**

| Activity | Likely regulator | Key issues |
| :--- | :--- | :--- |
| Dubai onshore / non-DIFC exchange, broker, custody or advisory | VARA | Licence category, paid-up capital, MLRO, travel rule, custody segregation, market conduct |
| DIFC virtual-asset financial services | DFSA | Token recognition, financial-services permissions, custody and client assets |
| ADGM virtual-asset activities | FSRA | Multilateral trading, custody, broker/dealer, technology governance |
| Payment token / fiat gateway | CBUAE plus VA regulator | Stored value, payment services, AML, bank relationships |
| Token issuance / securities token | CMA / free-zone regulator | Prospectus, offering exemptions, market abuse, custody |

### 6.5 Islamic finance and sukuk

Dubai and Abu Dhabi are major Islamic-finance centres. The supporting research captured Nasdaq Dubai sukuk listing items, including a USD 500 million sukuk listing by the Islamic Corporation for the Development of the Private Sector on Nasdaq Dubai [[40]](#ref40). For Islamic-finance compliance, a transaction may require Sharia governance, prospectus or offering approvals, listing rules, trustee documentation, commodity murabaha arrangements, tax/zakat analysis, CBUAE / DFSA / FSRA / CMA permissions and AML/CFT compliance.

## 7. Healthcare, health insurance, life sciences and medical data

### 7.1 Healthcare regulators

Healthcare regulation is split between federal and emirate authorities. MOHAP is the federal ministry and regulator for many Northern Emirates activities and medicines/health products. DHA regulates Dubai healthcare facilities and professionals. DoH regulates Abu Dhabi healthcare. Emirates Health Services operates federal health facilities. Free zones such as Dubai Healthcare City have additional licensing frameworks.

DHA’s July 2024 electronic-medical-record transition guideline states that the Health Regulation Sector is mandated under Dubai laws to develop regulation, policy, standards and guidelines to promote the growth and development of Dubai’s health sector, and that the guideline applies to all DHA-licensed healthcare facilities planning transition from one EMR to another, for reintegration with NABIDH [[21]](#ref21).

### 7.2 Mandatory health insurance

The earlier draft stated that Abu Dhabi and Dubai have mandatory health insurance and that the Northern Emirates mandate began on 1 January 2025 with a basic plan starting around AED 320/year. The supporting research summary confirmed this as a collected finding, but the full official source text was not included in the visible snippets. Therefore the exact AED 320 premium should be checked against MOHRE/ICP/MOHAP/insurer official service pages before reliance in a policy or employee handbook. The regulatory principle remains: residency issuance/renewal is increasingly linked to health-insurance coverage across all emirates.

### 7.3 Digital health records — NABIDH, Salama and Malaffi

DHA’s NABIDH initiative is Dubai’s health-information exchange. Kyndryl’s 2024 announcement, cited in the research, states that DHA’s NABIDH connected more than **9.47 million patient records** and more than **1,300 healthcare facilities** in Dubai, and that NABIDH is intended to create a single comprehensive electronic medical file accessible across providers [[22]](#ref22). DHA’s EMR transition guideline links facility EMR changes to NABIDH integration [[21]](#ref21).

Abu Dhabi’s Malaffi is the emirate health-information exchange, though the supporting snippets did not capture the official Malaffi page. The compliance point is that health-data systems in both Dubai and Abu Dhabi are not ordinary IT projects: they require regulator-approved integration, privacy, cybersecurity, data-quality and interoperability controls.

**Healthcare data checklist:**

- patient consent and confidentiality basis;
- health-record retention and audit trails;
- HIE integration requirements;
- EMR transition plan and data migration validation;
- breach notification and incident response;
- role-based access and identity management;
- hosting / cloud approval where required;
- secondary use of health data for research or AI;
- cross-border transfer restrictions;
- medical-device software and clinical decision-support validation.

### 7.4 Medical liability and professional licensing

The earlier draft identified Federal Law No. 4 of 2016 on Medical Liability. Medical liability compliance normally includes professional licensing, scope of practice, informed consent, medical-record documentation, adverse-event reporting, malpractice insurance, medical committees and disciplinary processes. For practitioners, the key operational question is not only federal law but the emirate regulator’s professional-qualification requirements, exam equivalencies, continuing professional development and facility privileges.

### 7.5 Medicines, controlled substances and medical products

MOHAP controls medicines, narcotics/controlled medicines, medical devices and health-product registration at federal level. A robust life-sciences compliance review should cover:

- marketing authorisation and product registration;
- local agent/importer requirements;
- pharmacovigilance and adverse-event reporting;
- pricing and reimbursement where applicable;
- controlled-substance schedules, prescription controls and storage registers;
- cold-chain import and distribution;
- medical-device classification and conformity;
- clinical-trial approvals and ethics committee review;
- advertising and claims restrictions.

The supporting research did not capture a complete MOHAP medicines registration manual; therefore this file does not invent approval timelines or fee amounts.

## 8. Education, higher education and school regulation

### 8.1 Dubai KHDA

Dubai private schools are regulated by KHDA. KHDA’s official Education Cost Index page was captured in research; it identifies an **Education Cost Index of 2.35%** for Dubai’s for-profit private schools and is an official 2025 KHDA update [[23]](#ref23). KHDA’s school directory was also captured as the official source for school listings and ratings [[41]](#ref41).

The earlier draft stated that Dubai private school inspections resume for the 2026-27 academic year with no more than 24 hours’ notice. This was present in the research summary but the visible snippets did not show the underlying official page. Therefore the 24-hour-notice claim should be verified against KHDA’s official inspection circular or news release before formal reliance.

**KHDA operational topics:**

| Topic | Compliance issue |
| :--- | :--- |
| School licensing | Owner, operator, premises, curriculum and principal approvals |
| Inspection | DSIB framework, wellbeing, inclusion, Arabic/Islamic education, safeguarding |
| Fees | Fee increases linked to inspection rating and Education Cost Index; exact annual caps from KHDA circulars [[23]](#ref23) |
| Curriculum | British, IB, Indian, US, UAE Ministry and other curricula must meet KHDA and federal requirements |
| Staff | Teacher qualifications, leadership approvals, safeguarding and conduct |
| Student data | PDPL, KHDA systems, parent communication and cybersecurity |
| School transport | RTA / local transport rules, bus safety and supervision |

### 8.2 Abu Dhabi ADEK and other emirates

Abu Dhabi schools are regulated by ADEK. The earlier draft stated that 13 Abu Dhabi schools were rated “Outstanding” in the 2025-26 cycle; the visible supporting snippets did not include the official ADEK page, so that exact figure is **[Not independently verified in the available sources]**. Sharjah private schools are regulated by SPEA, and other emirates have their own education authorities in addition to federal Ministry of Education requirements.

### 8.3 Higher education and accreditation

Higher education institutions in the UAE generally require licensing and programme accreditation from the Commission for Academic Accreditation unless operating under a recognised free-zone or international branch framework with specific approvals. Compliance topics include institutional licensure, programme accreditation, faculty qualifications, quality assurance, student protection, advertising of degrees, online/blended delivery approvals, research ethics and recognition of qualifications.

## 9. Real estate, leasing, brokerage and construction-linked property regulation

### 9.1 Dubai Land Department, RERA and tenancy systems

Dubai real estate is regulated by Dubai Land Department (DLD), the Real Estate Regulatory Agency (RERA) and the Rental Disputes Center. The earlier file referenced Dubai’s Smart Rental Index and rent-increase caps of 5%, 10%, 15% or 20% based on the gap between current rent and the index. The supporting research summary confirmed an AI-driven Smart Rental Index, but visible snippets did not capture the official DLD page. Therefore exact 2026 algorithm language and rent cap application should be verified directly against the DLD/RERA calculator and applicable decree before use.

**Dubai real-estate compliance areas:**

- title registration and transfer;
- 4% transfer fee and trustee-office fees (verify current fee schedule directly);
- off-plan project registration and escrow;
- broker registration and advertising permits;
- Ejari tenancy registration;
- rent-increase calculator / index;
- homeowners associations and jointly owned property;
- construction completion and handover;
- mortgage registration and lender requirements;
- rental disputes and enforcement.

### 9.2 Abu Dhabi Real Estate Centre and Tawtheeq

The earlier file identified Abu Dhabi Real Estate Centre (ADREC) and Tawtheeq tenancy registration. Abu Dhabi real-estate compliance differs from Dubai in title structure, municipality fees, off-plan rules, Musataha/long-term lease arrangements, designated investment zones, property management, owners’ associations and dispute pathways. For any Abu Dhabi transaction, the land department / ADREC rules should be checked directly.

### 9.3 Real estate and infrastructure interface

Real estate is heavily affected by sector-specific regulations outside property law: utility connection, civil defence, district cooling, environmental permits, telecom in-building coverage, data-centre energy load, hotel/tourism classification, school/clinic licensing and transport impact. Large developments near metro, rail, port, airport or logistics zones must include right-of-way protection, noise, vibration, access, parking, traffic impact and safety approvals.

## 10. Food safety, F&B, agriculture, halal and Nutri-Mark

### 10.1 Federal food-safety framework

The UAE Government food-safety page states that food safety in the UAE is governed by legal provisions and entities responsible for ensuring food safety, and links to the federal food-safety law, the National Food Accreditation and Registration System, the National Rapid Alert System, imported-food controls and local food-safety entities [[26]](#ref26). The research also captured the official UAE Legislation download page for **Federal Law No. 10 of 2015 concerning Food Safety**, with snippets referring to regulations, management systems, terms, codes, data, packaging, labelling and statement-label requirements [[27]](#ref27).

Food businesses must therefore treat the UAE framework as both federal and local. A food importer may need MOCCAE/ZAD registration, local municipality label approval, customs clearance, health certificates, halal certificates where relevant, temperature-control records and local warehouse/vehicle approvals.

### 10.2 Food import, label assessment and ZAD / FIRS

The research captured USDA/GAIN material explaining that UAE importers are required to apply for label assessment on food items prior to entry, and that this process assesses compliance with UAE food standards and regulations through ZAD or Dubai Municipality’s Food Import and Re-export Service (FIRS). The label assessment process reviews barcode, trade name, brand name, nutritional information, country of origin, shelf life, storage condition and related product information [[42]](#ref42).

The U.S. International Trade Administration page states that UAE labels must be in Arabic only or Arabic/English, Arabic stickers are accepted, and production and expiry dates must be printed on the original manufactured label [[28]](#ref28). This is a critical practical point for importers because shipment delays often arise from label language, date format, shelf-life and ingredient/allergen issues.

### 10.3 Food labelling compliance checklist

| Label element | UAE compliance point from available sources | Notes |
| :--- | :--- | :--- |
| Language | Arabic only or Arabic/English; Arabic stickers accepted [[28]](#ref28) | Check product category and emirate requirements |
| Dates | Production and expiry dates must be printed on original manufactured label [[28]](#ref28) | Avoid removable date stickers where prohibited |
| Product identity | Trade name, brand, barcode, origin and storage reviewed in label assessment [[42]](#ref42) | Match invoice, certificate and package |
| Nutrition | Nutritional information reviewed in label assessment [[42]](#ref42) | Nutri-Mark may add Abu Dhabi front-of-pack requirement |
| Shelf life | Shelf life reviewed in label assessment [[42]](#ref42) | Category-specific shelf-life rules apply |
| Halal | Meat and animal-derived products require approved halal certification | Verify MOCCAE-approved bodies and product category |
| Claims | Nutrition and health claims controlled by applicable standards | Avoid unapproved medical or therapeutic claims |
| Allergens | Must be checked against UAE/GSO rules | Maintain formulation records |

### 10.4 Abu Dhabi Nutri-Mark

The research captured multiple authoritative and industry sources about **Nutri-Mark**, Abu Dhabi’s front-of-pack nutrition labelling system. FoodTimes reported that Nutri-Mark is mandatory from **1 June 2025**, developed by the Abu Dhabi Quality and Conformity Council and Abu Dhabi Public Health Centre, and uses an A–E colour-coded rating tailored to regional context, UAE nutritional standards, local dietary patterns and halal requirements [[43]](#ref43). Campden BRI described Nutri-Mark as mandatory from 1 June 2025 for five product categories sold in Abu Dhabi, with plans to expand scope [[44]](#ref44). A notified Abu Dhabi guideline states that the colour-coded rating system is intended to make it easier for consumers to make informed choices and choose healthier options [[45]](#ref45).

The exact product-scope, transition period, enforcement mechanism and algorithm should be checked against the official Abu Dhabi guideline for each product category. The research captured secondary statements that initial categories include dairy, oils, beverages, baked goods and children’s snacks, but those category details should be verified from the official guideline before packaging changes [[43]](#ref43) [[44]](#ref44).

### 10.5 Restaurants, catering and F&B operations

F&B businesses are regulated by local municipalities and economic departments as well as federal food-safety law. A restaurant, cloud kitchen, hotel kitchen, catering business or food truck normally needs:

- trade licence with approved activity;
- food-control approval for layout, equipment, storage and workflow;
- food-handler training / occupational health cards;
- HACCP or food-safety management system where required;
- temperature logs and traceability;
- pest-control contracts;
- grease-trap and waste contracts;
- civil-defence approval for gas, extraction and fire systems;
- delivery-platform and vehicle hygiene compliance;
- Ramadan, alcohol, shisha or entertainment permits where applicable;
- allergen and menu-claim controls.

### 10.6 Agriculture, veterinary and food security

Agriculture and veterinary activities involve MOCCAE, emirate agriculture/food authorities and customs. Regulated areas include live animal import, veterinary medicines, animal feed, plant quarantine, pesticides, organic claims, fisheries, aquaculture, farms, slaughterhouses and food-security programmes. The previous draft mentioned the ZAD system; the UAE Government food-safety page confirms the National Food Accreditation and Registration System as a key food-safety service [[26]](#ref26).

## 11. AI, digital economy, fintech and space

### 11.1 UAE AI Strategy 2031 and governance approach

The UAE Government and AI Office describe the UAE AI Strategy 2031 as the national strategy for artificial intelligence; the earlier draft stated it focuses on priority sectors including energy, logistics and healthcare. The supporting research captured AI-regulatory commentary noting that UAE AI guidance includes non-binding guidelines adopted by key financial regulators such as CBUAE and securities/free-zone regulators [[46]](#ref46). Because AI regulation is still evolving, the UAE approach is best understood as a combination of national strategy, sector guidance, data protection, cyber rules, consumer protection, financial-services model-risk controls and health/medical-device rules.

### 11.2 AI compliance by sector

| Sector | AI use cases | UAE regulatory issues |
| :--- | :--- | :--- |
| Finance | Credit scoring, fraud detection, robo-advice, algorithmic trading | CBUAE/DFSA/FSRA/CMA governance, explainability, outsourcing, consumer protection, AML |
| Healthcare | Diagnostic support, triage, imaging, patient-risk scoring | DHA/DoH/MOHAP approvals, clinical validation, medical liability, health data privacy |
| Telecom | Network optimisation, content filtering, fraud prevention | TDRA rules, cyber resilience, customer data, lawful interception obligations |
| Real estate | Smart rental index, valuation, tenant screening | DLD/RERA transparency, consumer protection, data accuracy, discrimination risk |
| Transport | Traffic signals, autonomous vehicles, fleet optimisation | RTA/Abu Dhabi Mobility approvals, safety case, liability, cybersecurity |
| Education | Adaptive learning, proctoring, student analytics | KHDA/ADEK approvals, children’s data, fairness and parental notice |
| Government | Digital services, identity, predictive services | UAE digital government standards, data governance, security and auditability |

### 11.3 Fintech, open finance and regulatory sandboxes

Fintech regulation can fall under CBUAE, DFSA, FSRA, VARA or the new federal capital-markets framework depending on the product. Payment initiation, stored value, remittance, crypto exchange, tokenised securities, crowdfunding, robo-advice, lending, BNPL, insurance technology and data aggregation are not interchangeable. Each has its own licence perimeter.

**Fintech compliance steps:**

1. Define the exact product flow: who holds money, who gives advice, who executes trades, who stores assets, who controls keys, and who contracts with the customer.
2. Identify geography: onshore UAE, DIFC, ADGM, Dubai outside DIFC, offshore customers, or cross-border marketing.
3. Map regulated activities: banking, payment service, securities, commodities, derivatives, insurance, virtual assets or credit.
4. Check AML/CFT and sanctions obligations.
5. Review technology outsourcing, cloud, cybersecurity and data-residency rules.
6. Prepare consumer disclosures and complaint handling.
7. If using AI, document model governance, testing, explainability and bias controls.

### 11.4 Space sector

The earlier file referenced Federal Law No. 12 of 2019 on the space sector and the Emirates Mission to the Asteroid Belt. The supporting research did not capture the official law text, so this file preserves the topic but avoids detailed invented requirements. Space-sector regulation covers licensing of space activities, satellite operations, launch services, spectrum coordination, liability, insurance, remote sensing, debris mitigation, national security and international treaty obligations. UAE Space Agency, MBRSC, Yahsat and Thuraya ecosystem activities require checking the specific licence type and spectrum/orbital filings.

## 12. Tourism, hospitality, media and entertainment

### 12.1 Tourism and hotel regulation

Tourism and hospitality regulation is local-emirate heavy. Dubai’s Department of Economy and Tourism / DTCM, Abu Dhabi’s Department of Culture and Tourism, and other emirate tourism authorities regulate hotel classification, tourism licences, tour operators, holiday homes, events, guides, desert safari activities, ticketing, consumer complaints and promotional campaigns.

**Common hotel / hospitality compliance areas:**

- hotel establishment licence and classification;
- building completion, civil defence and municipality approvals;
- food and beverage permits, kitchens and food safety;
- alcohol licence / permit rules where applicable;
- pool, spa, gym and health-club licensing;
- entertainment and event permits;
- tourism dirham / local fees;
- guest registration and police/immigration interfaces;
- employment and accommodation rules;
- environmental, waste and sustainability requirements;
- accessibility and fire/life-safety compliance.

The supporting research set did not contain detailed official tourism fee tables; therefore this file does not state exact room-fee, classification or permit amounts.

### 12.2 Media, advertising and influencer activity

Media and advertising activities may require approvals from federal media authorities, free-zone media authorities and emirate event regulators. Regulated areas include print and digital publishing, broadcast, streaming, outdoor advertising, cinema, influencer marketing, social-media advertising, event filming, drone filming, public-decency rules, political/religious content, children’s content, health/financial claims and intellectual property.

A UAE-facing advertising campaign should be checked for:

- trade licence / media licence activity;
- influencer permit or agency arrangement;
- content restrictions under media and cybercrime rules;
- consumer-protection and price-promotion rules;
- health, food, finance or real-estate advertising restrictions;
- copyright and music licensing;
- Arabic language requirements where applicable;
- event and filming permits.

## 13. 2025–2026 update log and verification status

| Update | Status in available research | Verification note |
| :--- | :--- | :--- |
| TDRA launched UAE 6G Initiative on 11 Nov 2025 | Verified from TDRA official page [[7]](#ref7) | Include as official 2025 telecom update |
| Federal capital-markets overhaul effective 1 Jan 2026 | Verified from authoritative legal updates citing FDL 32/2025 and FDL 33/2025 [[17]](#ref17) [[18]](#ref18) | Official UAE Legislation download was blocked in crawl, but law-firm summaries are detailed |
| CMA replaces/succeeds SCA; one-year regularisation period | Verified from King & Spalding / Cleary summaries [[17]](#ref17) [[18]](#ref18) | Monitor implementing resolutions |
| Abu Dhabi Nutri-Mark mandatory from 1 Jun 2025 | Verified from authoritative secondary sources and official/notified guideline snippets [[43]](#ref43) [[44]](#ref44) [[45]](#ref45) | Check official guideline by product category |
| Dubai Metro Gold Line approved in 2026 | Verified from Dubai Media Office / rail sources [[33]](#ref33) [[34]](#ref34) | Exact opening and phasing should be checked against RTA/Dubai Media Office |
| Etihad Rail exact passenger launch dates and fares | Not verified in available official sources | Treat previous draft schedule as **[Not independently verified]** |
| Northern Emirates mandatory health insurance and AED 320 basic plan | Present in research summary but official snippet not visible | Verify on ICP/MOHRE/MOHAP/insurer official pages before reliance |
| PDPL “full enforcement” and AED 20m penalties | Not verified in available sources | Keep PDPL obligations but do not state penalty amount without official source |
| Abu Dhabi Metro detailed Gold/Silver lines | Not verified in available official sources | Use Abu Dhabi Mobility portal only as verified mobility authority |
| DEWA / ADDC / EtihadWE exact 2026 tariffs | Partial official framework only | Verify live tariff PDFs before financial modelling |

## 14. Sector-by-sector due diligence checklist

### 14.1 Energy / utilities

- Identify utility area: DEWA, ADDC/AADC, EtihadWE, SEWA or other.
- Obtain load assessment and connection approval.
- Verify current tariff category and fuel surcharge.
- Check solar PV / battery connection rules.
- Confirm district cooling interface if applicable.
- Review EIA and emissions approvals for generation or industrial energy use.
- Confirm civil defence approval for electrical rooms, transformers, fuel tanks and batteries.
- For nuclear or radiation sources, check FANR licensing.

### 14.2 Telecom / digital infrastructure

- Confirm if activity requires TDRA licence or type approval.
- Check spectrum, numbering, IoT and equipment approval.
- Review internet-content and prohibited-category rules.
- Implement cybersecurity controls and incident reporting.
- Check PDPL and data-localisation / transfer issues.
- For critical infrastructure, check enhanced security requirements.

### 14.3 Transport / logistics

- Verify road, rail, port, airport or maritime authority.
- Obtain vehicle, driver, fleet and transport-activity licences.
- Check dangerous-goods rules.
- For drones, register user and drone with GCAA and use approved zones.
- For ports/free zones, confirm customs, bonded warehouse and sanctions screening.
- For passenger services, check safety, accessibility and consumer rules.

### 14.4 Finance / fintech

- Map regulated activity and regulator.
- Check CBUAE / CMA / DFSA / FSRA / VARA perimeter.
- Prepare AML/CFT policies and MLRO appointment.
- Review capital, governance, technology and outsourcing rules.
- Confirm customer disclosures and complaints process.
- For virtual assets, check custody, travel rule and token approval.
- For securities offerings, check prospectus or exemption.

### 14.5 Healthcare / life sciences

- Confirm facility and professional licensing authority.
- Register medicines, devices or health products as required.
- Maintain health-data privacy and HIE integration.
- Implement medical liability, consent and recordkeeping controls.
- Verify insurance requirements for employees/residents/patients.
- Check controlled-substance storage, prescription and registers.

### 14.6 Education

- Confirm school / higher education regulator.
- Obtain licence, premises and curriculum approvals.
- Follow inspection and fee framework.
- Maintain safeguarding, inclusion and wellbeing policies.
- Check teacher qualifications and transport safety.
- Protect student data and parent communications.

### 14.7 Real estate

- Verify title, ownership eligibility and registration fees.
- Register off-plan project and escrow where required.
- Confirm brokerage licence and advertising permit.
- Register leases through Ejari/Tawtheeq or local system.
- Use current rent index / calculator.
- Check service charges, owners’ association and handover requirements.

### 14.8 Food / F&B

- Obtain trade licence and food-control approval.
- Complete label assessment through ZAD/FIRS as applicable.
- Ensure Arabic or Arabic/English labels and original production/expiry dates.
- Check halal certification and health claims.
- Apply Nutri-Mark where Abu Dhabi product categories require it.
- Maintain HACCP/food-safety records, temperature logs and traceability.

### 14.9 AI / media / tourism

- For AI, map data, model risk, sector rules and consumer impact.
- For media, check content, advertising and influencer permits.
- For tourism, check hotel classification, event permits and guest reporting.
- For digital campaigns, combine media, cybercrime, consumer and PDPL checks.

## 15. Known gaps requiring further official extraction

The user requested the deepest possible research and raw detail. This file expands the sector-specific document to practical library depth, but the following items still require direct extraction from official PDFs or regulator systems before the document can claim literal completeness:

1. Full current DEWA, ADDC/AADC, EtihadWE and SEWA tariff PDFs and fee tables.
2. Official Etihad Rail passenger station, fare and launch schedule.
3. Official Dubai RTA Gold Line and Blue Line design / construction documents beyond media announcements.
4. Official Abu Dhabi Metro status documents, if current.
5. Full text of Federal Decree-Law No. 14 of 2024 on Traffic Regulation and executive fine tables.
6. Full CBUAE rulebook extracts for banking, payments, insurance and open finance.
7. Official VARA fee schedules and rulebook extracts current to 2026.
8. MOHAP medicines, medical-device and controlled-substance manuals.
9. KHDA/ADEK current school inspection and fee circulars.
10. DLD/RERA Smart Rental Index official methodology and current rent-increase calculator extracts.
11. Official Abu Dhabi Nutri-Mark product-category annexes and enforcement circulars.
12. Tourism and media authority current fee tables and permit manuals.

## References

<p id="ref1" class="ref_item">[1] Dubai Electricity and Water Authority, Slab Tariff <a target="_blank" rel="noreferrer" href="https://dewa.gov.ae/en/consumer/billing/slab-tariff">https://dewa.gov.ae/en/consumer/billing/slab-tariff</a></p>
<p id="ref2" class="ref_item">[2] Abu Dhabi Department of Energy, Tariffs and charges <a target="_blank" rel="noreferrer" href="https://www.doe.gov.ae/en/Legislation-and-Compliance/Economic-Regulations/Tariffs-and-charges">https://www.doe.gov.ae/en/Legislation-and-Compliance/Economic-Regulations/Tariffs-and-charges</a></p>
<p id="ref3" class="ref_item">[3] UAE Government portal, Energy and energy strategy resources <a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/strategies-initiatives-and-awards/strategies-plans-and-visions/environment-and-energy/uae-energy-strategy-2050">https://u.ae/en/about-the-uae/strategies-initiatives-and-awards/strategies-plans-and-visions/environment-and-energy/uae-energy-strategy-2050</a></p>
<p id="ref4" class="ref_item">[4] Emirates Nuclear Energy Corporation, Frequently Asked Questions About the Barakah Plant <a target="_blank" rel="noreferrer" href="https://www.enec.ae/barakah-plant/frequently-asked-questions/">https://www.enec.ae/barakah-plant/frequently-asked-questions/</a></p>
<p id="ref5" class="ref_item">[5] ADNOC, ADNOC Listed Companies Target Record AED 158 Billion in Dividends <a target="_blank" rel="noreferrer" href="https://www.adnoc.ae/en/news-and-media/press-releases/2025/adnoc-listed-companies-target-record-aed-158-billion-43-billion-in-dividends">https://www.adnoc.ae/en/news-and-media/press-releases/2025/adnoc-listed-companies-target-record-aed-158-billion-43-billion-in-dividends</a></p>
<p id="ref6" class="ref_item">[6] ADNOC, Internal Transfers of Shareholdings in Listed Companies to XRG <a target="_blank" rel="noreferrer" href="https://www.adnoc.ae/en/news-and-media/press-releases/2025/adnoc-announces-internal-transfers-of-shareholdings-in-its-listed-companies-to-xrg">https://www.adnoc.ae/en/news-and-media/press-releases/2025/adnoc-announces-internal-transfers-of-shareholdings-in-its-listed-companies-to-xrg</a></p>
<p id="ref7" class="ref_item">[7] TDRA, Launch of the 6th Generation (6G) Initiative <a target="_blank" rel="noreferrer" href="https://tdra.gov.ae/en/media/press-release/2025/6-g">https://tdra.gov.ae/en/media/press-release/2025/6-g</a></p>
<p id="ref8" class="ref_item">[8] TDRA, Internet Guidelines <a target="_blank" rel="noreferrer" href="https://tdra.gov.ae/en/about/tdra-sectors/information-and-digital-government/policy-and-programs-department/internet-guidelines">https://tdra.gov.ae/en/about/tdra-sectors/information-and-digital-government/policy-and-programs-department/internet-guidelines</a></p>
<p id="ref9" class="ref_item">[9] Chambers, Understanding VPN Use in the UAE <a target="_blank" rel="noreferrer" href="https://chambers.com/articles/understanding-vpn-use-in-the-uae-what-you-need-to-know">https://chambers.com/articles/understanding-vpn-use-in-the-uae-what-you-need-to-know</a></p>
<p id="ref10" class="ref_item">[10] UAE Government portal, Cyber safety and digital security <a target="_blank" rel="noreferrer" href="https://u.ae/en/information-and-services/justice-safety-and-the-law/cyber-safety-and-digital-security">https://u.ae/en/information-and-services/justice-safety-and-the-law/cyber-safety-and-digital-security</a></p>
<p id="ref11" class="ref_item">[11] UAE Government portal, Data protection laws <a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws">https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws</a></p>
<p id="ref12" class="ref_item">[12] DataGuidance, United Arab Emirates jurisdiction profile <a target="_blank" rel="noreferrer" href="https://www.dataguidance.com/jurisdictions/united-arab-emirates">https://www.dataguidance.com/jurisdictions/united-arab-emirates</a></p>
<p id="ref13" class="ref_item">[13] Motei, Federal Decree-Law No. 14 of 2024 on Traffic Regulation <a target="_blank" rel="noreferrer" href="https://motei.com/federal-decree-law-no-14-of-2024-on-traffic-regulation/">https://motei.com/federal-decree-law-no-14-of-2024-on-traffic-regulation/</a></p>
<p id="ref14" class="ref_item">[14] Dubai Roads and Transport Authority <a target="_blank" rel="noreferrer" href="https://www.rta.ae/">https://www.rta.ae/</a></p>
<p id="ref15" class="ref_item">[15] Abu Dhabi Mobility <a target="_blank" rel="noreferrer" href="https://admobility.gov.ae/en/home">https://admobility.gov.ae/en/home</a></p>
<p id="ref16" class="ref_item">[16] UAE General Civil Aviation Authority, UAS Registration <a target="_blank" rel="noreferrer" href="https://www.gcaa.gov.ae/en/pages/UASRegistration.aspx/">https://www.gcaa.gov.ae/en/pages/UASRegistration.aspx/</a></p>
<p id="ref17" class="ref_item">[17] King & Spalding, A New Era for UAE Federal Securities Regulation <a target="_blank" rel="noreferrer" href="https://www.kslaw.com/news-and-insights/a-new-era-for-uae-federal-securities-regulation-the-2025-cma-decree-laws-february-2026">https://www.kslaw.com/news-and-insights/a-new-era-for-uae-federal-securities-regulation-the-2025-cma-decree-laws-february-2026</a></p>
<p id="ref18" class="ref_item">[18] Cleary Gottlieb, UAE Capital Markets Overhaul 2026 <a target="_blank" rel="noreferrer" href="https://www.clearygottlieb.com/news-and-insights/publication-listing/uae-capital-markets-overhaul-2026-new-regulatory-framework-for-the-capital-market-authority">https://www.clearygottlieb.com/news-and-insights/publication-listing/uae-capital-markets-overhaul-2026-new-regulatory-framework-for-the-capital-market-authority</a></p>
<p id="ref19" class="ref_item">[19] DFM, Region's leading financial exchange <a target="_blank" rel="noreferrer" href="https://www.dfm.ae/">https://www.dfm.ae/</a></p>
<p id="ref20" class="ref_item">[20] Ministry of Health and Prevention <a target="_blank" rel="noreferrer" href="https://mohap.gov.ae/">https://mohap.gov.ae/</a></p>
<p id="ref21" class="ref_item">[21] DHA, Guideline for Electronic Medical Record Transition in Healthcare Facilities <a target="_blank" rel="noreferrer" href="https://www.dha.gov.ae/uploads/072024/EMR%20Transition%20Guidline2024727664.pdf">https://www.dha.gov.ae/uploads/072024/EMR%20Transition%20Guidline2024727664.pdf</a></p>
<p id="ref22" class="ref_item">[22] Kyndryl, DHA NABIDH connects over 9.47M patient records <a target="_blank" rel="noreferrer" href="https://www.kyndryl.com/us/en/about-us/news/2024/11/digitizing-healthcare-services-for-dubai-health-authority">https://www.kyndryl.com/us/en/about-us/news/2024/11/digitizing-healthcare-services-for-dubai-health-authority</a></p>
<p id="ref23" class="ref_item">[23] KHDA, Education Cost Index <a target="_blank" rel="noreferrer" href="https://web.khda.gov.ae/en/About-Us/News/2025/Education-Cost-Index">https://web.khda.gov.ae/en/About-Us/News/2025/Education-Cost-Index</a></p>
<p id="ref24" class="ref_item">[24] ADEK <a target="_blank" rel="noreferrer" href="https://www.adek.gov.ae/">https://www.adek.gov.ae/</a></p>
<p id="ref25" class="ref_item">[25] Dubai Land Department <a target="_blank" rel="noreferrer" href="https://dubailand.gov.ae/">https://dubailand.gov.ae/</a></p>
<p id="ref26" class="ref_item">[26] UAE Government portal, Food safety <a target="_blank" rel="noreferrer" href="https://u.ae/en/information-and-services/health-and-fitness/food-safety-and-health-tips">https://u.ae/en/information-and-services/health-and-fitness/food-safety-and-health-tips</a></p>
<p id="ref27" class="ref_item">[27] UAE Legislation, Federal Law No. 10 of 2015 Concerning Food Safety <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1161/download">https://uaelegislation.gov.ae/en/legislations/1161/download</a></p>
<p id="ref28" class="ref_item">[28] International Trade Administration, UAE Labeling/Marking Requirements <a target="_blank" rel="noreferrer" href="https://www.trade.gov/knowledge-product/united-arab-emirates-labelingmarking-requirements">https://www.trade.gov/knowledge-product/united-arab-emirates-labelingmarking-requirements</a></p>
<p id="ref29" class="ref_item">[29] UAE Artificial Intelligence Office <a target="_blank" rel="noreferrer" href="https://ai.gov.ae/">https://ai.gov.ae/</a></p>
<p id="ref30" class="ref_item">[30] World Nuclear Association, Nuclear Power in the United Arab Emirates <a target="_blank" rel="noreferrer" href="https://world-nuclear.org/information-library/country-profiles/countries-t-z/united-arab-emirates">https://world-nuclear.org/information-library/country-profiles/countries-t-z/united-arab-emirates</a></p>
<p id="ref31" class="ref_item">[31] TDRA, National Cybersecurity Strategy PDF <a target="_blank" rel="noreferrer" href="https://tdra.gov.ae/userfiles/assets/Lw3seRUaIMd.pdf">https://tdra.gov.ae/userfiles/assets/Lw3seRUaIMd.pdf</a></p>
<p id="ref32" class="ref_item">[32] DLA Piper, Data protection laws in UAE - General <a target="_blank" rel="noreferrer" href="https://www.dlapiperdataprotection.com/countries/uae-general/law.html">https://www.dlapiperdataprotection.com/countries/uae-general/law.html</a></p>
<p id="ref33" class="ref_item">[33] Dubai Media Office, Mohammed bin Rashid approves Dubai Metro Gold Line <a target="_blank" rel="noreferrer" href="https://www.mediaoffice.ae/en/news/2026/april/22-04/mohammed-bin-rashid-approves-dubai-metro-gold-line">https://www.mediaoffice.ae/en/news/2026/april/22-04/mohammed-bin-rashid-approves-dubai-metro-gold-line</a></p>
<p id="ref34" class="ref_item">[34] Railway Gazette, Dubai Gold Line underground metro project approved <a target="_blank" rel="noreferrer" href="https://www.railwaygazette.com/sponsored-content/2026/06/29/dubais-gold-line-underground-metro-project-approved-2/">https://www.railwaygazette.com/sponsored-content/2026/06/29/dubais-gold-line-underground-metro-project-approved-2/</a></p>
<p id="ref35" class="ref_item">[35] Railway Technology, Etihad Rail UAE project <a target="_blank" rel="noreferrer" href="https://www.railway-technology.com/projects/etihad-rail/">https://www.railway-technology.com/projects/etihad-rail/</a></p>
<p id="ref36" class="ref_item">[36] Etihad Rail overview source captured in research <a target="_blank" rel="noreferrer" href="https://en.wikipedia.org/wiki/Etihad_Rail">https://en.wikipedia.org/wiki/Etihad_Rail</a></p>
<p id="ref37" class="ref_item">[37] Abu Dhabi Ports <a target="_blank" rel="noreferrer" href="https://www.adports.ae/">https://www.adports.ae/</a></p>
<p id="ref38" class="ref_item">[38] FreightAmigo, UAE top ports overview <a target="_blank" rel="noreferrer" href="https://www.freightamigo.com/en/blog/logistics/top-five-ports-in-the-united-arab-emirates/">https://www.freightamigo.com/en/blog/logistics/top-five-ports-in-the-united-arab-emirates/</a></p>
<p id="ref39" class="ref_item">[39] Dubai Financial Market <a target="_blank" rel="noreferrer" href="https://www.dfm.ae/">https://www.dfm.ae/</a></p>
<p id="ref40" class="ref_item">[40] ICD, Nasdaq Dubai welcomes USD 500 million Sukuk listing <a target="_blank" rel="noreferrer" href="https://www.icd-ps.org/en/news/nasdaq-dubai-welcomes-usd-500-million-sukuk-listing-by-the-islamic-corporation-for-the-development-of-the-private-sector">https://www.icd-ps.org/en/news/nasdaq-dubai-welcomes-usd-500-million-sukuk-listing-by-the-islamic-corporation-for-the-development-of-the-private-sector</a></p>
<p id="ref41" class="ref_item">[41] KHDA Schools Directory <a target="_blank" rel="noreferrer" href="https://web.khda.gov.ae/en/Education-Directory/schools">https://web.khda.gov.ae/en/Education-Directory/schools</a></p>
<p id="ref42" class="ref_item">[42] USDA FAS, UAE Food and Agricultural Import Regulations and Standards report <a target="_blank" rel="noreferrer" href="https://apps.fas.usda.gov/newgainapi/api/report/downloadreportbyfilename?filename=Food%20and%20Agricultural%20Import%20Regulations%20and%20Standards%202018%20_Dubai_United%20Arab%20Emirates_5-1-2019.pdf">https://apps.fas.usda.gov/newgainapi/api/report/downloadreportbyfilename?filename=Food%20and%20Agricultural%20Import%20Regulations%20and%20Standards%202018%20_Dubai_United%20Arab%20Emirates_5-1-2019.pdf</a></p>
<p id="ref43" class="ref_item">[43] FoodTimes, Abu Dhabi Nutri-Mark nutrition labelling system 2025 <a target="_blank" rel="noreferrer" href="https://www.foodtimes.eu/consumers-and-health/abu-dhabi-nutri-mark-nutrition-labelling-system-2025/">https://www.foodtimes.eu/consumers-and-health/abu-dhabi-nutri-mark-nutrition-labelling-system-2025/</a></p>
<p id="ref44" class="ref_item">[44] Campden BRI, Nutri-Score vs Nutri-Mark differences <a target="_blank" rel="noreferrer" href="https://www.campdenbri.co.uk/blogs/differences-nutrition-labelling-schemes.php">https://www.campdenbri.co.uk/blogs/differences-nutrition-labelling-schemes.php</a></p>
<p id="ref45" class="ref_item">[45] Abu Dhabi Nutri-Mark notified guideline PDF <a target="_blank" rel="noreferrer" href="https://micor.agriculture.gov.au/Dairy/Documents/UAE%20-%20labelling%20-%20Feb%202025%20-%20notified%20document.pdf">https://micor.agriculture.gov.au/Dairy/Documents/UAE%20-%20labelling%20-%20Feb%202025%20-%20notified%20document.pdf</a></p>
<p id="ref46" class="ref_item">[46] Latham & Watkins, AI in the UAE regulatory landscape <a target="_blank" rel="noreferrer" href="https://www.lw.com/en/insights/ai-in-the-uae-understanding-the-regulatory-landscape-and-key-authorities">https://www.lw.com/en/insights/ai-in-the-uae-understanding-the-regulatory-landscape-and-key-authorities</a></p>

**End of Document**