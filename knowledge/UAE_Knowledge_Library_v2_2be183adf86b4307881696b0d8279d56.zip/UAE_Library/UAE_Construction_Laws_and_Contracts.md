# UAE Construction Laws and Contracts

> **Compiled:** July 2026.  
> **Scope:** UAE construction law, muqawala contracts, decennial liability, procurement, FIDIC/NEC4, dispute resolution, contractor/consultant registration, BIM, and 2023–2026 developments.  
> **Research standard:** deep-library file with extensive article text, tables, direct extracts, and source-linked notes. It is not legal advice; always verify against the official Arabic text, the signed contract, emirate regulations, and current implementing decisions.

## 1. LEGAL FRAMEWORK

### 1.1 Primary federal sources

| Instrument | Status | Construction relevance |
|---|---|---|
| Federal Law No. 5 of 1985 Civil Transactions Law | Historical/current for contracts before 1 June 2026; official UAE legislation source exists, and an extractable English PDF copy was used for article text [[1]](#ref1) [[2]](#ref2) | Contract formation, tort/civil liability, muqawala, decennial liability, limitation, payment, security and property concepts |
| Federal Decree-Law No. 25 of 2025 Civil Transactions Law | Repeals Federal Law No. 5/1985 and comes into force on 1 June 2026 according to Article 2/3 previews [[3]](#ref3) [[4]](#ref4) | Re-codifies muqawala in Articles 812–839 and changes construction risk allocation [[5]](#ref5) |
| Federal Law No. 11 of 2023 Procurement in the Federal Government | Federal procurement statute with Ministry of Finance PDF source [[11]](#ref11) | Tendering, procurement system, purchasing principles, award controls, contracting controls and complaints |
| DIAC Rules / 2025 Table of Fees and Costs | 2025 fee table applies to proceedings commenced after 1 January 2025 [[13]](#ref13) | Arbitration cost budgeting for construction disputes |

### 1.2 Civil Code chapter map relevant to construction

- Introductory provisions: interpretation, custom, public policy, persons and property.
- Contract formation: Articles 198–245. These include offer/acceptance, capacity, defective consent, object, cause, void/voidable/suspended contracts and options. Full extract appears in Appendix A [[2]](#ref2).
- Tort and civil liability: Articles 282–348. Full extract appears in Appendix B because tort provisions are essential for site accidents, negligence, third-party damage, collapse, fire and unsafe-building claims [[2]](#ref2).
- Contract for work / muqawala: Articles 872–896. Full text appears in Section 2 [[2]](#ref2).
- Limitation: general claims are commonly analysed under the Civil Code's general limitation framework, while Article 883 has a specific three-year hearing bar from collapse or discovery of defect for decennial warranty claims [[2]](#ref2).

### 1.3 New Civil Code — transition and construction changes

The researched sources report that the New Civil Code comes into force on 1 June 2026, replaces Federal Law No. 5 of 1985, and moves construction/muqawala provisions from Articles 872–896 to Articles 812–839 [[3]](#ref3) [[4]](#ref4) [[5]](#ref5). The Old Civil Code continues to apply to contracts concluded before 1 June 2026, while contracts concluded after that date fall under the New Civil Code according to K&L Gates' construction analysis [[5]](#ref5).

#### Full list of reported changes for construction / works contracts

| Old article / concept | New article / concept | Key change | Practical effect |
|---|---|---|---|
| Arts. 872–896 | Arts. 812–839 | Re-numbered and restructured muqawala chapter [[5]](#ref5) | Update contract references, pleadings, opinions and notice templates |
| No express old termination-for-convenience article in muqawala chapter | Art. 836 | Codifies employer withdrawal before completion; compensation includes expenses, completed works and lost profit, with court reduction for avoided cost/alternative profit [[5]](#ref5) | Termination clauses should specify valuation, mitigation and proof |
| Old Art. 887 lump sum plan rule | Art. 829(2) | Confirms extra payment for change/increase by agreement and adds employer-fault basis [[5]](#ref5) | Variation administration becomes even more notice/document dependent |
| General hardship doctrine plus old lump-sum rule | Art. 829(3) | Exceptional unforeseen general circumstances may allow court/tribunal to restore balance, extend time, increase/decrease remuneration or terminate [[5]](#ref5) [[6]](#ref6) [[22]](#ref22) | Price escalation and pandemic/war disruption claims are separated from pure force majeure |
| Old Code had no express construction notice article equivalent | Art. 816(3) | Contractor must notify employer immediately of events/circumstances impeding proper execution; failure means contractor bears consequences [[5]](#ref5) | Advance notice of cost/time impact becomes statutory risk-control point |
| Electronic dealings historically governed by separate e-transactions rules and contract principles | New Code recognition of modern contracting/electronic dealings is reported as part of legislative modernisation [[6]](#ref6) | Electronic contract evidence and digital notices become more central | Contracts should define approved platforms, deemed receipt and e-signature authority |
| Decennial liability under Arts. 880–883 | New provisions maintain 10-year guarantee framework in restructured chapter according to research summary | Core public-policy liability expected to continue | Parties still cannot contract out of structural guarantee |
| Old force majeure / impossibility and hardship separation | Updated force majeure and exceptional circumstances language [[22]](#ref22) | More express judicial tools for construction disruption | Separate records for impossibility, prevention, hardship and employer-risk delay |

#### Old Article → New Article comparison table

| Old Article | New Article / reported equivalent | Key change / continuity |
|---:|---:|---|
| 872 | 812 | Definition of muqawala/contracting agreement continues as contract for work/remuneration [[5]](#ref5) |
| 873 | 813 | Contractor/employer material-supply models retained; drafting should identify who supplies materials |
| 874 | 814 | Work description, quantity, method, duration and remuneration remain core formation details |
| 875 | 815 | Contractor responsibility for materials and care of employer-supplied materials continues |
| 876 | 816 | Tools/accessories and execution obligations; new Art. 816(3) notice obligation is a major addition [[5]](#ref5) |
| 877 | 817 | Defective or contrary performance remedies continue; notice/cure and replacement contractor logic remains |
| 878 | 818 | Contractor warranty for results of act/work remains; unavoidable accident/force majeure defence must be evidenced |
| 879 | 819 | Contractor lien/retention over work product has continuing conceptual relevance |
| 880 | 829 / decennial section equivalent | 10-year structural guarantee maintained; new Art. 829(3) hardship also affects lump-sum construction economics [[5]](#ref5) |
| 881 | decennial architect design equivalent | Architect/designer liability principles continue; scope depends on design-only vs design+supervision |
| 882 | non-exclusion provision equivalent | Clauses excluding/limiting decennial warranty remain void/public-policy risk |
| 883 | limitation equivalent | Three-year period from collapse/discovery remains a key procedural issue in old law; check new text for exact wording |
| 884–889 | 830–835 approximate | Delivery, payment, estimates, lump sums and architect remuneration are modernised/reordered |
| 890–891 | 837–838 approximate | Subcontracting and no direct subcontractor claim absent assignment/referral continue conceptually |
| 892–896 | 839 and related termination provisions | Completion, rescission, impossibility, compensation and death/personal skill termination are restructured; Art. 836 expressly covers convenience withdrawal [[5]](#ref5) |

### 1.4 Contract formation, tort and limitation — why Articles 198–245 and 282–348 matter

Construction contracts are usually negotiated as lengthy bespoke or FIDIC-based documents, but UAE courts still analyse them through Civil Code formation and validity concepts. Articles 198–245 are central for offer/acceptance, agreed scope, price, cause, capacity, duress, mistake, deceit, void/voidable consequences, and suspended authority. Articles 282–348 matter because construction disputes often include tort claims, building collapse, unsafe equipment, falling objects, fire damage, road/public safety issues, employer/employee responsibility, and third-party property damage. The full extracts in the appendices preserve raw statutory language for deeper use.

---

## 2. MUQAWALA — ARTICLES 872–896 FULL TEXT

The following is the extractable English text of Articles 872–896 from the English PDF copy of Federal Law No. 5 of 1985 used in this research file [[2]](#ref2).

```text
Article 872
Contract for work is one by virtue of which one of the parties undertakes to do a piece of work in
consideration of a remuneration which the other party undertakes to pay.
Article 873
1-The contractor may undertake to supply the work only, the master of the work being responsible for the
supply of materials which the contractor uses in or for the performance of his work.
2-The contractor may undertake to supply the material and the work as well.
Article 874
In a contract for work, the location, the kind of work, its quantity, the way it should be performed and the
duration of work must be described and the remuneration fixed.

SECTION TWO
EFFECTS OF CONTRACTING

CONTRACTOR'S LIABILITIES -1
Article 875
1-In case the master sets forth as a condition that the contractor has to provide all or part of the materials,
he is responsible for its good quality as provided for in the contract, if any, otherwise in conformity with the
current custom.
2- When the materials are supplied by the master, the contractor is bound to care for their preservation,
observe in his work the technical requirements and to return to their owner whatever left of it; otherwise he
shall warrant against perishing, defect or loss thereof.
Article 876
In the absence of an agreement or trade custom to the contrary, the contractor shall provide, at his own
expense, the tools and accessories he needs to perform his work.
Article 877
The contractor shall perform his work according to the conditions of the contract. If it is established that he
is fulfilling his obligations in a manner that is defective or contrary to the agreement, the master may ask the
immediate rescission of the contract, if remedying the situation is impossible, otherwise the master may
summon the contractor to abide by the terms of the contract and rectify, within a reasonable time, the manner
in which he is performing the work. If at the expiration of the fixed delay, the contractor fails to comply with
this requirement, the master may ask the judge the resiliation of the contract or authorize him to hand over
the completion of the work to another contractor at the expense of the first contractor.





Article 878
The contractor shall warrant the results of his act and work against prejudice or loss whether or not caused
by his trespassing or negligence. There is no warrant if this occurs from an accident that could not be
avoided.
Article 879
1-If the contractor's work shall produce some effects on the property, he may have a lien over it until he
receives the remuneration due to him, and if it perishes in his possession prior to payment of the
remuneration, he shall neither be liable to warrant nor entitled to remuneration.
2- If his work shall not have any effect on the property itself, she shall have no right to detain it in payment
of his remuneration and if he does so he shall be liable to warrant against his unlawful act.
Article 880
1-If the object of the contracting contract was the erection of buildings or other fixed constructions that the
architect has designed, to be executed by the contractor, under his supervision, they shall be jointly liable, for
a period of ten years or a longer agreed period , to indemnify the master of work for total or partial
destruction of these buildings or fixed constructions and for every defect endangering the solidity and
security of the building; all this unless the two contracting parties agreed that these constructions are meant to
stay for less than ten years.
2-This obligation to indemnify shall remain in effect even if the defect or the destruction is due to a defect
in the ground itself, and even if the master authorized the erection of the defective buildings or fixed
constructions.
3-The ten year period shall start as of the time of delivery of the work.
Article 881
If the architect’s work is limited to the preparation of the plans without being entrusted with the
supervision of their execution, he shall be responsible only for defects in the plans.
Article 882
Any clause tending to exonerate or limit the warranty of the contractor or the architect is void.
Article 883
Court action on the warranty may not be heard after three years from the occurrence of the destruction or
the discovery of the defect.

OBLIGATIONS OF THE MASTER -2
Article 884
The master must take delivery of the completed work as soon as the contractor completes it and places it at
his disposal. If the master, in spite of being formally summoned, fails without reasonable cause to take
delivery, and the work perishes in the hands of the contractor or becomes defective, without any trespassing
or neglect from the latter, he shall not be bound to warrant.
Article 885
The master is bound to pay the remuneration for the work upon taking delivery of the work contracted,
unless otherwise agreed or practiced by custom.
Article 886
1-When a contract is concluded in accordance with an estimate drawn up on a unit price basis and it
becomes evident, during the course of the work, that it will be necessary to complete the work, according to
the agreed plan, to considerably exceed the estimated price, the contractor is bound to notify the master





forthwith of the matter stating the anticipated increase in price. If he fails to do so, he shall forfeit his right to
recover the expenses incurred in excess of the estimate.
2-If the estimated excess in the price for the execution of the plans is considerable, the master may release
himself from the contract and stop the execution without delay and pay the contractor the cost of the works
done by him estimated in accordance with the terms of the contract.
Article 887
1-When a contract is concluded on a lump sum basis according to an agreed plan, the contractor has no
claim to an increase in price required for the execution of the plan.
2-If a modification or addition is made to the plan, with the consent of the master, the current agreement
with the contractor, as regards such a modification or addition, shall be observed.
Article 888
If the contract did not specify a price for the work, the contractor shall be entitled to the price for similar
works, in addition to the cost of the materials provided by him as required by the works.
Article 889
1-If there were no agreement as to the remuneration of the architect, who made the plans for the building
and supervised their execution, he shall be entitled to the remuneration payable for similar work, in
accordance with the current custom.
2- If happens what impedes the completion of the work’s execution, according to the design he has
prepared, he shall deserve the wage according to what he has performed.

SECTION THREE
SUB-CONTRACTING
Article 890
1-The contractor may entrust the execution, of the whole or part of the work, to a sub-contractor unless he
is precluded from so doing by a clause in the contract, or unless the nature of the work requires that he
executes the work in person.
2-The contractor, in such a case, shall remain responsible towards the master of the work.
Article 891
The subcontractor may not have a claim against the master, as regards the dues of the first contractor,
unless the latter refers him to the master.

SECTION FOUR
THE END OF A CONTRACT FOR WORK
Article 892
The contract for work shall come to an end by completing or by rescission of the contract by mutual
agreement or by order of the court.
Article 893
When an excuse arises that prevents the execution of the contract, or the completion of its execution, any
of the contracting parties may ask for its rescission or termination, as the case may be.
Article 894





If the contractor has started the execution of the work and then became unable to accomplish it, for a
reason beyond his control, he shall be entitled to value of the completed work, in addition to the expenses
disbursed for its execution to the extent of the benefit that the masters derives from such work.
Article 895
The party prejudiced from rescission may claim compensation from the other party within the limits
allowed by custom.
Article 896
1-A contract for work is dissolved by the death of the contractor, if it was agreed that he executes the work
in person or if his personal skill was taken into account in the contract.
2-If the contract does not include such provision, or if such personal skill was not taken into account in the
contract, the master may ask for the rescission of the contract in case the heirs do not offer the necessary
qualifications for the proper execution of the works.
3- In both instances, the value of the completed works and the expenses incurred shall devolve to the heirs
in accordance with the contract and what is required by custom.

CHAPTER TWO
EMPLOYMENT CONTRACT
SECTION ONE
FORMATION AND CONDITIONS
```

### 2.1 Article-by-article operational reading

| Article | Subject | Construction contract meaning |
|---:|---|---|
| 872 | Definition | Work-for-remuneration foundation of construction, MEP, fit-out, infrastructure and specialist packages |
| 873 | Work-only or materials+work | Determines who bears procurement, quality, loss and price-escalation risk for materials |
| 874 | Essential description | Location, kind, quantity, method, duration and remuneration should be clear; ambiguity fuels variation/payment disputes |
| 875 | Materials | Contractor warrants quality of contractor-supplied materials and must preserve employer-supplied materials |
| 876 | Tools | Contractor normally supplies tools/accessories at own cost absent agreement/custom |
| 877 | Defective performance | Employer can seek rescission or replacement contractor after cure route where remedying is possible |
| 878 | Warranty of result | Contractor warrants prejudice/loss caused by act/work unless unavoidable accident |
| 879 | Lien | Contractor may retain property affected by work until remuneration, subject to limits |
| 880 | Decennial liability | Architect and contractor jointly liable for 10 years for collapse/structural defects threatening solidity/security |
| 881 | Design-only architect | Architect limited to plan defects if not supervising execution |
| 882 | No exclusion | Any clause excluding or limiting contractor/architect warranty is void |
| 883 | Limitation | Warranty action not heard after 3 years from collapse or discovery |
| 884 | Taking delivery | Employer must take delivery; refusal without cause shifts risk if no contractor fault |
| 885 | Payment | Remuneration due upon delivery unless agreement/custom differs |
| 886 | Unit-price estimate excess | Contractor must promptly notify substantial estimate overrun or lose excess recovery |
| 887 | Lump sum | No increase for executing agreed plan; modifications/additions follow agreement |
| 888 | No price specified | Contractor gets price for similar works plus materials supplied |
| 889 | Architect remuneration | Similar/custom remuneration if none agreed; partial wage if completion impeded |
| 890 | Subcontracting | Permitted unless prohibited or personal execution required; main contractor remains responsible |
| 891 | Subcontractor claim | No direct claim against employer unless referred/assigned by main contractor |
| 892 | End | Completion or rescission by agreement/court |
| 893 | Excuse | Either party may seek rescission/termination where excuse prevents execution/completion |
| 894 | Contractor inability beyond control | Contractor entitled to value of completed work and useful expenses |
| 895 | Compensation | Prejudiced party may claim custom-limited compensation |
| 896 | Death/personal skill | Contract dissolves if personal execution/skill was essential; heirs may recover value/expenses |

---

## 3. DECENNIAL LIABILITY — EXHAUSTIVE ANALYSIS

### 3.1 Statutory text: Articles 880–883

Article 880 is the centre of UAE decennial liability. In the extracted text, Article 880 provides that if the object of the contracting contract is the erection of buildings or other fixed constructions designed by an architect and executed by the contractor under supervision, the architect and contractor are jointly liable for ten years, or a longer agreed period, to indemnify the master of works for total or partial destruction and every defect endangering solidity and security, unless the works were meant to last less than ten years. It also states that liability remains even where the defect or destruction is due to a defect in the ground itself or where the master authorised defective construction, and that the ten-year period starts at delivery [[2]](#ref2).

Article 881 states that if the architect’s work is limited to preparation of plans without supervision, the architect is responsible only for plan defects. Article 882 states that any clause tending to exonerate or limit the warranty of the contractor or architect is void. Article 883 states that a court action on the warranty may not be heard after three years from occurrence of destruction or discovery of defect [[2]](#ref2).

### 3.2 Elements of liability

| Element | Requirement | Practical proof |
|---|---|---|
| Type of asset | Building or other fixed construction | Contract, drawings, handover certificate, authority completion certificate |
| Defect type | Total/partial destruction or defect endangering solidity/security | Structural expert report, intrusive testing, monitoring, photos, authority notices |
| Liable parties | Contractor and supervising architect/engineer jointly; design-only architect limited to plan defects | Appointment scope, supervision records, design responsibility matrix |
| Period | 10 years from delivery, unless longer agreed | Taking-Over Certificate, completion certificate, handover minutes |
| Action period | 3 years from collapse/discovery | Discovery report date, expert instruction date, owner notice date |
| Exclusion | Exoneration/limitation void | Contract clauses cannot defeat statutory warranty |
| Land defect | Liability remains even if ground defect caused collapse/defect | Geotechnical reports do not automatically excuse contractor/architect |

### 3.3 UAE case law requested in the research brief

- **Dubai Court of Cassation Case 150/2007**: cited in the research brief for the principle that a land defect can still trigger Article 880 liability. This aligns with Article 880(2), which expressly keeps the indemnity obligation alive even if the defect/destruction is due to a defect in the ground itself [[2]](#ref2).
- **Abu Dhabi Court of Cassation Case 293/Year 3**: cited for the principle that the delivery date is the start of the 10-year period. This aligns with Article 880(3), which states that the ten-year period starts from delivery [[2]](#ref2).
- **Abu Dhabi Court of Cassation Case 721/Year 3**: cited for compensation scope under Article 880. The text makes the remedy indemnity/compensation for destruction or qualifying defects; quantum normally requires structural causation, repair method, loss of use, diminution and consequential cost evidence.

### 3.4 Public-policy and non-waiver consequences

Al Tamimi's commentary describes decennial liability as strict and non-excludable, with no proof of negligence required, and states that parties can only resist liability by force majeure or external cause rather than by contractual exclusion [[7]](#ref7). The statutory text itself supports this through Article 882's invalidity of exoneration/limitation clauses [[2]](#ref2). Practical consequences:

1. A cap on liability in the contract may not cap decennial liability.
2. A defects liability certificate does not waive latent structural defects.
3. Employer approval of defective construction does not necessarily defeat Article 880.
4. A ground-condition defence is difficult because Article 880 expressly includes ground defects.
5. Subcontractor risk must be passed down by indemnity because the employer's statutory claim usually focuses on contractor/architect, not subcontractor privity.

### 3.5 Decennial liability insurance / latent defects insurance

The UAE market increasingly uses 10-year latent defect or decennial liability insurance on major residential, hospitality, infrastructure and financed developments. The research brief identified typical market participants as AIG, Lloyd's syndicates, Zurich and ADNIC, with indicative premiums commonly discussed at **0.5%–1.5% of construction cost** for qualifying projects. This is market-practice information rather than a universally mandatory UAE statutory requirement. Current research did **not** verify a UAE-wide mandatory decennial insurance law; therefore this file records the safer position: decennial liability is mandatory by law, while decennial liability insurance is not yet universally mandatory across the UAE but is increasingly required by developers, lenders and major employers.

Typical underwriting focus:

- structural design review and peer review;
- geotechnical report adequacy;
- waterproofing and façade risk;
- fire/life safety interface;
- contractor/consultant track record;
- quality assurance and inspection test plans;
- maintenance obligations and exclusions;
- handover documentation and as-built records.

### 3.6 New Civil Code impact on decennial liability

The New Civil Code restructures muqawala provisions into Articles 812–839 [[5]](#ref5). Research indicates that the 10-year guarantee principle continues, while hardship and force majeure language is modernised. Article 829(3), although primarily discussed for lump-sum economics, may influence contractor arguments where exceptional circumstances undermine the foundation of the contract [[5]](#ref5) [[6]](#ref6) [[22]](#ref22). Updated force majeure definitions may affect Article 881-type external-cause analysis, but statutory decennial warranty remains a high-risk, public-policy exposure.

---

## 4. FIDIC AND NEC4 IN UAE CONSTRUCTION

### 4.1 FIDIC Red Book 1999 — all 20 clauses with UAE amendments

| Clause | Title | Full Summary | UAE Standard Amendments |
|---:|---|---|---|
| 1 | General Provisions | Definitions, communications, law/language, priority of documents, assignment, care and supply of documents. UAE amendments usually impose UAE law, bilingual/Arabic precedence, stricter notice addresses, electronic correspondence rules, and employer-friendly document precedence. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 2 | The Employer | Site access, permits, employer financial arrangements, claims by employer. UAE amendments often narrow employer financing disclosure, expand employer set-off rights, and require contractor assistance for authority NOCs. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 3 | The Engineer | Engineer duties, delegation, instructions, determinations. UAE government forms often make the engineer closer to employer representative; 2017 reforms emphasize neutral/fair determinations. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 4 | The Contractor | General obligations, performance security, subcontractors, staff/labour, quality, safety, as-built records. UAE amendments commonly require 10% on-demand bonds, UAE bank guarantees, authority approvals, worker welfare and Emiratisation/local-content obligations. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 5 | Nominated Subcontractors | Nominated subcontractor objections, payment evidence and indemnities. In UAE practice this is linked with specialist MEP, façade, lifts, fire and utility packages and Article 890 main-contractor responsibility. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 6 | Staff and Labour | Engagement, rates, accommodation, health and safety, records. UAE amendments incorporate Labour Law, wage protection, midday break rules, accommodation standards and visa/work permit compliance. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 7 | Plant, Materials and Workmanship | Testing, inspection, rejection, remedial work and ownership of materials. UAE amendments add authority-approved materials, Civil Defence/DEWA/ADDC approvals, factory tests and traceability. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 8 | Commencement, Delays and Suspension | Commencement, programme, EOT, delays, suspension. UAE amendments usually preserve 28-day claim notice, P6 programme requirements, monthly updates and delay damages caps. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 9 | Tests on Completion | Contractor obligations for completion testing, delayed tests and retesting. UAE amendments align with Civil Defence, utilities energisation, commissioning certificates and integrated systems testing. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 10 | Employer’s Taking Over | Taking-over procedure, parts of works, interference with tests, surfaces requiring reinstatement. UAE amendments link taking over to authority completion certificates and handover dossiers. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 11 | Defects Liability | Completion of outstanding work, cost of remedying defects, extension of DNP, failure to remedy. UAE amendments distinguish contractual DLP from non-waivable decennial liability. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 12 | Measurement and Evaluation | Measurement, method of measurement and valuation. UAE remeasurement contracts rely on BoQ, approved measurement sheets, QS certification and engineer determinations. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 13 | Variations and Adjustments | Engineer variations, value engineering, variation procedure, provisional sums, dayworks, adjustments for changes in law/cost. UAE amendments often require written VO before work, board approvals and strict authority delegation. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 14 | Contract Price and Payment | Advance payment, interim payments, payment certificates, delayed payment, retention, final account. UAE amendments set advance bonds, 5–10% retention, 50/50 retention release and no-interest rules. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 15 | Termination by Employer | Notices to correct, termination grounds, valuation after termination. UAE amendments expand insolvency, corruption, abandonment, progress failure and sanctions grounds. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 16 | Suspension and Termination by Contractor | Contractor suspension/termination for non-payment or prolonged suspension. UAE employer forms frequently narrow these remedies and lengthen cure periods. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 17 | Risk and Responsibility | Care of works, indemnities, employer risks, consequences and limitation. UAE amendments link insurance, site security, third-party property and public-authority risk. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 18 | Insurance | CAR, third party, workers compensation, professional indemnity, plant and other insurances. UAE amendments require local admitted insurers, employer co-insurance, waiver of subrogation and policy approval. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 19 | Force Majeure / Exceptional Events | Notice, consequences, optional termination and release from performance. UAE practice interprets force majeure narrowly; hardship and New Civil Code Article 829(3) must be considered separately. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |
| 20 | Claims, Disputes and Arbitration | Contractor claims, DAB decision, amicable settlement, arbitration. UAE amendments replace ICC with DIAC/ADCCAC/ICC as project-specific, retain 28-day notice and set seat/language. | Typical UAE drafting expands employer controls, bonds, notices, authority approvals, Arabic/UAE law hierarchy, DIAC or local-seat arbitration, and stricter documentary conditions. |


### 4.2 FIDIC 2017 key changes

- **Clause 3 — Engineer:** 2017 drafting makes the Engineer's determinations more expressly fair and reasonable and clarifies the Engineer's role. The research brief emphasises that the Engineer cannot simply act as the employer's agent when making determinations.
- **Clause 8.5 — Concurrent delay:** concurrent-cause analysis is required. In practical UAE delay analysis, parties distinguish employer-risk delay, contractor-risk delay and true concurrency; neither party should gain time or money for delay it caused.
- **Clause 13 — Variations:** modern forms make the VO process more formal: proposal, agreement, and determination if no agreement. Clause 13.2 value engineering allows contractor proposals that reduce cost, accelerate completion, improve efficiency or enhance lifecycle value.
- **Clause 14 — Payment:** advance payment is often 10% if stated; payment provisions are more structured, with advance bond, IPC timetable, retention and final account controls.
- **Clauses 20/21 — Claims and disputes:** 2017 separates Claims (Clause 20) from Disputes and Arbitration (Clause 21). The 28-day notice remains central; fully detailed claims are often due within 84 days. DAAB is promoted as a dispute avoidance mechanism.
- **Clause 21 — DAAB:** standing DAAB is recommended for complex projects; ad hoc boards may be used for smaller projects. A DAAB decision is generally due within 84 days. Non-compliance can itself become a failure to comply, and contested decisions proceed to arbitration under the contract's chosen institution.

### 4.3 NEC4 vs FIDIC comparison

| Feature | NEC4 ECC | FIDIC Red Book |
|---|---|---|
| Philosophy | Collaborative; early warning; mutual trust | Traditional; defined roles; claims-based |
| Risk allocation | Shared; Compensation Events cover employer risks | Defined risk lists; employer vs contractor risks |
| Programme | Accepted Programme central; monthly updates | Programme required but less central |
| Variations | Compensation Events; quotation and assessment | VO procedure; Engineer determines value |
| Disputes | W1 standard or W2 statutory adjudication options | DAB/DAAB then arbitration |
| Early Warning | Mandatory notice; Risk Register | No direct equivalent in 1999 Red Book |
| Cost management | Activity Schedule, BoQ, target cost or reimbursable options | Re-measurement under Red Book or lump sum in modified forms |
| UAE adoption | Growing in Abu Dhabi government and ADNOC-influenced environments according to market research | Dominant for over 30 years; widely used by government, utilities and private developers |

### 4.4 NEC4 ECC option details

| Option | Name | UAE use case | Risk profile |
|---|---|---|---|
| A | Priced contract with Activity Schedule | Most common NEC4 lump-sum style | Contractor takes quantity/productivity risk except compensation events |
| B | Priced contract with Bill of Quantities | Infrastructure and civil works with measurable quantities | Employer carries quantity remeasurement risk |
| C | Target Cost with Activity Schedule | Alliancing/collaborative infrastructure | Pain/gain share incentivises cost control |
| D | Target Cost with Bill of Quantities | Large civil works with uncertain quantities | Shared risk with remeasurement structure |
| E | Cost Reimbursable | Emergency works, undefined scope, early works | Employer bears cost risk with fee controls |
| F | Management Contract | Construction management / trade package procurement | Management contractor paid fee; employer bears package risk |

### 4.5 NEC4 Compensation Events — Clause 60.1 working list

1. **Compensation Event 1:** change to Scope/Works Information. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
2. **Compensation Event 2:** employer does not provide access by access date. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
3. **Compensation Event 3:** employer does not provide something by date in Accepted Programme. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
4. **Compensation Event 4:** employer instructs stopping or not starting work. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
5. **Compensation Event 5:** employer or others do not work within stated times/conditions. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
6. **Compensation Event 6:** engineer/supervisor withholds acceptance for reasons not stated. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
7. **Compensation Event 7:** employer changes a decision. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
8. **Compensation Event 8:** supervisor instructs search and no defect is found. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
9. **Compensation Event 9:** employer gives an instruction to deal with an object of value or historical interest. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
10. **Compensation Event 10:** employer changes Key Date or Completion Date. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
11. **Compensation Event 11:** employer does not reply to communication within period. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
12. **Compensation Event 12:** physical conditions are encountered that are unlikely/low probability. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
13. **Compensation Event 13:** weather measurements exceed stated data. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
14. **Compensation Event 14:** employer risk event occurs. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
15. **Compensation Event 15:** employer breaches contract. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
16. **Compensation Event 16:** prevention event stops completion by planned completion. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
17. **Compensation Event 17:** additional compensation events stated in Contract Data. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.
18. **Compensation Event 18:** correction of an assumption stated in quotation assessment. In UAE administration, this should be logged by early warning/notice, linked to Accepted Programme activity impact, priced through quotation, and closed in a compensation-event register.


---

## 5. GOVERNMENT PROCUREMENT AND LOCAL CONTENT

### 5.1 Federal Law No. 11 of 2023 — nine chapters

Lexis' preview table of contents lists the law as: Chapter 1 Definitions and Objectives (Articles 1–2); Chapter 2 Scope of Application and Exceptions (Articles 3–4); Chapter 3 Governance and Competencies (Articles 5–7); Chapter 4 Procurement System and Purchasing Principles (Articles 8–15); Chapter 5 Purchase Provisions and Methods (Articles 16–22); Chapter 6 Awarding Provisions and Controls (Articles 23–29); Chapter 7 Contracting Provisions and Controls (Articles 30–37); Chapter 8 Considering Complaints (Article 38); Chapter 9 General Provisions (Articles 39–45) [[12]](#ref12).

| Chapter | Articles | Detailed construction relevance |
|---|---:|---|
| 1. Definitions and objectives | 1–2 | Defines UAE, Government, Ministry, Federal Entities, procurement, procurement process, annual plan, emergency procurement, procurement system, public interest, public value, supplier, participating supplier, confidential and sensitive commercial information, tender announcement and public tender. The objectives include digital procurement, equality, fair treatment, non-discrimination, integrity, transparency, competition, public value, SME support, sustainable development and national economy objectives [[11]](#ref11). |
| 2. Scope and exceptions | 3–4 | Applies to procurement/contracting of federal entities, with exceptions requiring article-by-article verification from the official PDF. Defence/security and strategic entities may use separate regimes. |
| 3. Governance and competencies | 5–7 | Establishes governance, delegation matrix and authority controls. For mega-projects, approvals and financial limits are critical. The research brief records ministerial approval for procurements above AED 250M; verify against implementing matrix for live tenders. |
| 4. Procurement system and purchasing principles | 8–15 | E-procurement, purchasing principles, transparency, publication, confidentiality, fair competition and audit trails. |
| 5. Purchase provisions and methods | 16–22 | Open tender, limited tender, direct contracting, emergency procurement, sole source and other methods. |
| 6. Awarding provisions and controls | 23–29 | Evaluation committees, technical/financial scoring, award recommendation, best value and rejection controls. |
| 7. Contracting provisions and controls | 30–37 | Contract execution, guarantees, performance security, variations, extensions, default and close-out. |
| 8. Considering complaints | 38 | Procurement complaint mechanism; the research brief requested a 10-day filing / 15-day review workflow, but live users must verify current implementing regulation and tender conditions. |
| 9. General provisions | 39–45 | General offences, transitional rules, implementation and publication. The user-requested Article 52 penalty reference was not verified in the chapter map; because Lexis preview shows only Articles 1–45, any Article 52 penalty table should be treated as unverified for this law unless a later implementing regulation contains it [[12]](#ref12). |

### 5.2 Key requested procurement articles and controls

| Requested item | Deep research treatment |
|---|---|
| Art. 1 definitions | Definitions extracted from MoF PDF include procurement authority concepts through Federal Entity, procurement process, procurement annual plan, emergency procurement, procurement system, public interest, public value, supplier, participating supplier and tender announcement [[11]](#ref11). |
| Art. 4 scope/exclusions | Covered under Chapter 2; verify exact exclusions in official PDF before relying. |
| Art. 6 authority thresholds | Delegation matrix governs financial/non-financial approvals; the brief's AED 250M ministerial threshold is recorded as a working procurement threshold subject to live matrix confirmation. |
| Art. 8 transparency | Chapter 4 procurement system/purchasing principles supports transparency, digital system and fair competition. |
| Art. 12 open tender | Open tender steps should include procurement plan, tender announcement, tender documents, clarification, bid submission, opening, technical/financial evaluation, award and publication. |
| Art. 17 direct contracting | Typical conditions: sole source, emergency, follow-on compatibility, IP/technical exclusivity and documented justification. |
| Art. 20 technical/financial evaluation | For complex works a 60/40 technical/financial weighting is common; for simple commodities 30/70 may be used. Tender documents control actual weight. |
| Art. 25 framework agreements | Frameworks are suitable for repetitive works/services; the brief records a maximum 4-year framework with mini-competitions for call-offs, subject to implementing regulation. |
| Art. 32 performance guarantee | Performance guarantees commonly 5–10% in UAE construction and government procurement, usually unconditional UAE bank guarantee. |
| Art. 40 disputes | Complaint committee and court appeal route should be checked against Chapter 8/implementing regulations. |
| Art. 52 penalties | Not verified in the located Law 11/2023 table of contents; do not rely without a separate regulation/source. |

### 5.3 Dubai procurement and RTA

Dubai government procurement is commonly run through DGEP/e-tender systems and Dubai Law No. 6 of 1997 as amended. The research brief records a local preference of 5% for Dubai-registered firms and a minimum three-member evaluation committee, but those values should be checked against the live tender and procurement manual. RTA supplier policy states that vendors may be subject to prequalification when entering supplies/contracts above AED 1 million [[16]](#ref16). Reuters reported the Dubai Metro Blue Line award at AED 20.5 billion / USD 5.6 billion in December 2024, illustrating the scale of RTA procurement [[17]](#ref17).

### 5.4 ADNOC / National ICV

MoIAT's ICV formula page gives a formula including **((Value of Purchase x ICV of supplier) + Emirati Cost + 60% of Expat Cost) / Total Cost**, plus an asset component based on UAE asset value / total asset value [[15]](#ref15). The research brief expands this for construction bids as:

```text
ICV Score = (Total Emirati Employee Cost × 1.0
           + Total Non-Emirati Employee Cost in UAE × 0.60
           + Total Asset Depreciation in UAE × 1.0
           + Total Purchase of Goods/Services in UAE with ICV certification × ICV Certificate %)
           / Total Revenue × 100
```

Practical ADNOC/ICV controls:

- ICV certificate is based on audited financial data and must be issued by approved certifying bodies; Big Four and major UAE audit firms are commonly used.
- The research brief records a **30% ICV score target** for many ADNOC contracts and ICV improvement plans for contracts over **AED 25M**; verify tender-specific ICV rules.
- Contractors should flow ICV requirements to subcontractors and suppliers, because Tier 1 ICV can be affected by uncertified vendors.
- Baseline ICV submissions should be included with bid; final ICV reporting often occurs at contract completion or within a post-completion period stated in the contract.

---

## 6. DISPUTE RESOLUTION AND EXPERT EVIDENCE

### 6.1 DIAC 2025 fee schedule

DIAC's 2025 Table states that fees are displayed in USD for illustration and payment directions are issued in AED; the registration fee under Articles 4 and 5 is **USD 3,000** and is non-refundable [[13]](#ref13).

| Amount in dispute | Arbitrator fee per arbitrator | Administrative fee |
|---:|---:|---:|
| to USD 25,000 | USD 2,000–8,000 | USD 3,000 |
| USD 50,001–100,000 | min USD 3,000 + 5% above 50,000; max USD 9,000 + 5% above 50,000 | USD 4,500 + 2.73% above 50,000 |
| USD 500,001–1,000,000 | min USD 15,000 + 1% above 500,000; max USD 36,720 + 3% above 500,000 | USD 15,000 + 0.99% above 500,000 |
| USD 1,000,001–2,000,000 | min USD 20,000 + 0.8% above 1,000,000; max USD 52,920 + 2.3% above 1,000,000 | USD 23,000 + 0.625% above 1,000,000 |
| USD 2,000,001–5,000,000 | min USD 28,000 + 0.4% above 2,000,000; max USD 80,640 + 1.4% above 2,000,000 | USD 30,000 + 0.438% above 2,000,000 |
| USD 5,000,001–10,000,000 | min USD 40,000 + 0.2% above 5,000,000; max USD 127,680 + 0.5% above 5,000,000 | USD 43,000 + 0.175% above 5,000,000 |
| USD 10,000,001–50,000,000 | min USD 50,000 + 0.05% above 10,000,000; max USD 159,850 + 0.2% above 10,000,000 | USD 52,000 + 0.063% above 10,000,000 |

For a USD 2 million dispute, Aceris reports DIAC administrative fees of USD 29,250 and per-arbitrator fees of USD 28,000–75,920 under the 2025 table [[14]](#ref14). For the requested USD 2.7M / AED 10M example, the brief's calculation of around USD 33,625 admin fee is directionally consistent with the USD 2M+ tier, but exact calculation should use the live calculator/table.

### 6.2 AED 50M construction dispute cost example

| Cost head | Typical range / note |
|---|---|
| Registration | USD 3,000 non-refundable [[13]](#ref13) |
| DIAC administrative fee | Approximately USD 52,000 + 0.063% above USD 10M for USD 10M–50M range; for AED 50M (~USD 13.6M), around USD 75k–85k is a conservative planning range after expenses/VAT assumptions |
| Arbitrator fees | For a 3-arbitrator tribunal, often USD 180k–360k depending claim size and court determination |
| Delay/quantum experts | AED 100k–500k each for major disputes; mega-project disputes can exceed this |
| Legal fees | AED 500k–3M+ depending firm, hearing length, document volume and expert intensity |
| Total cost | Often 5–15% of claim value for hard-fought construction arbitration, excluding internal management time |

### 6.3 Expert evidence: delay, quantum and defects

Delay analysis methods used in UAE disputes often follow SCL Protocol categories:

1. As-Planned vs As-Built — simple but vulnerable where baseline unrealistic.
2. Impacted As-Planned — inserts delay events into baseline; useful early but often criticised if not reality-tested.
3. Time Impact Analysis — preferred for contemporaneous prospective analysis when reliable updates exist.
4. Collapsed As-Built — removes employer delays from as-built programme; useful retrospectively but assumption-heavy.
5. Windows Analysis — divides project into windows and studies critical path movement; strong where monthly updates exist.

Quantum experts prepare measured mile productivity analysis, loss and expense claims, prolongation cost, disruption cost, acceleration cost, variation valuation, final account, Scott Schedule defect matrices and repair-cost models. RICS is the dominant professional body for quantity surveyors in the UAE market; the research brief records 4,000+ UAE RICS members and RICS dispute resolution services as relevant market infrastructure.

---

## 7. CONTRACTOR REGISTRATION — ALL EMIRATES

| Emirate | Authority | Max grades | Min capital Grade 1 | Max contract value Grade 1 | Renewal | URL / note |
|---|---|---|---:|---:|---|---|
| Dubai | Dubai Municipality | G1–G5 | AED 30M | Unlimited | Annual | dm.gov.ae; values from research brief, verify current DM classification |
| Abu Dhabi | DMT | Special/A–D | AED 20M+ | Unlimited | Annual | DMT classification requirements page [[21]](#ref21) |
| Sharjah | Sharjah Municipality | G1–G5 | AED 10M | Unlimited | Annual | sharjah.ae; portal extraction incomplete, verify live |
| Ras Al Khaimah | RAK Municipality | G+1 to G+4 | AED 5M | Per grade | Annual | RAK SANAD page identifies technical staff requirements [[19]](#ref19) |
| Ajman | Ajman Municipality | 1–5 | AED 3M | AED 50M | Annual | ajman.ae; research brief value, verify live |
| Umm Al Quwain | UAQ Municipality | 1–3 | AED 1M | AED 20M | Annual | mun.uaq.ae; research brief value, verify live |
| Fujairah | Fujairah Municipality | 1–4 | AED 2M | AED 30M | Annual | fujairah.ae; research brief value, verify live |

### 7.1 Dubai Municipality specialist subcontractor categories

- **Piling and deep foundations:** separate specialist approval; minimum geotechnical/civil engineering competence; method statements, load tests and monitoring.
- **Post-tensioning:** specialist category with system approvals, stressing records and independent checks.
- **Curtain walling and glazing:** façade engineering, structural calculations, wind-load and fire-stopping interface.
- **MEP works:** separate MEP contractor licensing; electrical, plumbing, HVAC and controls approvals.
- **Fire protection systems:** Civil Defence approval, NFPA competence, shop drawings, testing and commissioning certificates.
- **Lifting equipment:** tower cranes and hoists require registration, inspection, operator competence and Civil Defence/municipal NOCs where applicable.

### 7.2 Federal engineering-project e-qualification

MOEI's service page for registration/e-qualification covers consultants, contractors and suppliers for engineering projects and records service fees such as AED 500 for new registration and annual renewal/fine concepts [[20]](#ref20). For federal infrastructure tenders, contractors should maintain both emirate classification and federal e-qualification where required.

---

## 8. STANDARD CONSULTANCY APPOINTMENTS

### 8.1 FIDIC White Book 2017

| Clause group | Subject | UAE drafting focus |
|---|---|---|
| 1 | Definitions and interpretation | UAE law, Arabic/English, project documents, authority definitions |
| 2 | Commencement and completion | Notice to proceed, programme, deliverable schedule, suspension |
| 3 | Services | Scope matrix, design stages, supervision, authority approvals, BIM deliverables |
| 4 | Payment | Time-based, lump sum, milestone, percentage fee, reimbursables, VAT |
| 5 | Consultant obligations | Skill/care, fitness only if expressly assumed, conflicts, records, authority coordination |
| 6 | Client obligations | Information, access, decisions, payment, permits support |
| 7 | Insurance | PI, professional liability, cyber/BIM, public liability, minimum AED limits |
| 8 | Disputes | DAAB/expert determination/arbitration; DIAC or local court routes |

Fee methods in UAE consultancy appointments:

- time-based hourly/daily rates;
- lump sum by stage;
- percentage of construction cost, often 3–6% for full design plus supervision on ordinary building projects, subject to complexity;
- cost reimbursable plus fee;
- hybrid design lump sum plus supervision monthly retainer.

### 8.2 Dubai Municipality consultant grades

| Grade | Scope | Minimum staff | Minimum PI insurance |
|---|---|---|---:|
| A | Unlimited height/area | 10 engineers; at least 2 senior grade A | AED 5M |
| B | Up to 150m / 50,000m² | 5 engineers | AED 3M |
| C | Up to 45m / 10,000m² | 3 engineers | AED 1M |
| D | Residential villas and small works | 1 engineer | AED 500K |
| E | Technical drawings only | Draftsman | N/A |

These values are from the research brief and should be verified against current Dubai Municipality circulars before use in a live appointment.

---

## 9. BIM REQUIREMENTS AND DIGITAL CONSTRUCTION

### 9.1 Dubai Municipality BIM Circular 207 of 2018 — working requirements

The research brief records Dubai Municipality BIM Circular 207/2018 as requiring BIM for government projects above AED 30M and complex multi-use projects above 20,000m². Required deliverables include architectural, structural and MEP models, clash detection report, BIM Execution Plan, common data environment access, federated model, issue log and RFI tracking.

| LOD | Meaning | Construction use |
|---:|---|---|
| 100 | Concept massing | Planning, early area and volume |
| 200 | Schematic approximate size/shape/location | Design coordination and cost planning |
| 300 | Defined geometry and dimensions | Design development and construction documentation |
| 350 | Coordination model with interfaces/connectors | Clash detection and trade coordination |
| 400 | Fabrication/assembly detail | Shop drawings, fabrication, installation |
| 500 | As-built verified model | Handover, FM, asset management |

Autodesk describes LOD progression from basic design intent through as-built facility management, with LOD 500 reflecting actual installed elements for FM use [[18]](#ref18).

### 9.2 Abu Dhabi / ISO 19650 protocol

Abu Dhabi and major UAE infrastructure clients use ISO 19650 concepts: ISO 19650-1 for concepts/principles, ISO 19650-2 for delivery phase, ISO 19650-3 for operational phase, common data environment, information requirements, BIM execution plan, COBie/asset data and Asset Information Model integration. The research brief records a UAE government target of BIM Level 3 / full digital integration by 2030.

### 9.3 CDE and model governance

- Approved CDE: Aconex, ProjectWise or equivalent.
- Naming: ISO-style naming convention, revision/status codes, suitability codes.
- Model federation: architecture, structure, MEP, façade, landscape, infrastructure.
- Clash detection: Navisworks/Solibri report, severity, owner, due date, closure evidence.
- Handover: COBie, asset tags, O&M manuals, warranties, serial numbers, maintenance plans.
- Legal risk: model reliance, design responsibility, status codes, native-file ownership, cyber/access logs.

---

## 10. RECENT DEVELOPMENTS 2023–2026

| Development | Detail | Construction impact |
|---|---|---|
| New Civil Code transition | Effective 1 June 2026; old Law 5/1985 repealed; muqawala restructured [[3]](#ref3) [[5]](#ref5) | Re-paper FIDIC amendments, bespoke terms, claim notices and legal opinions |
| Price escalation 2021–2023 | Research brief records courts rejecting force majeure for ordinary price increases and applying hardship narrowly | Contractors need escalation clauses, provisional sums, fluctuation formulae and early notices |
| Labour supply recovery 2022–2024 | Recruitment from India, Pakistan, Bangladesh, Philippines and worker welfare improvements | Labour cost/productivity assumptions and accommodation compliance remain material |
| Digital construction | BIM mandates, digital twins, smart permits, digital NOCs, drone progress monitoring | Better evidence but higher data-governance obligations |
| Modular/off-site construction | Dubai modular guidelines reported in 2024 research brief; steel modular for affordable housing | Shifts risk to factory QA, transport, lifting, interfaces and authority approvals |
| Dubai Metro Blue Line | Reuters reported AED 20.5bn award in December 2024 [[17]](#ref17) | Major infrastructure procurement, local content, programme and interface management |

---

## Appendix A — Civil Code Articles 198–245 contract formation excerpt

```text
Article 198
Whoever is under a mistake may not avail himself of it in a manner contradicting with the requirements of
good faith.

OBJECT AND CAUSE OF CONTRACT-5

A- OBJECT OF THE CONTRACT
Article 199
Every contract must have an object to be added to it.
Article 200
1-In pecuniary transactions, the object must be appraisable.
2-It may consist of a bare property, usufruct as it may consist of an act or abstention there from.
Article 201
Should the object be impossible in itself shall be impossible in itself, at the time of the contract, the
contract shall be void.
Article 202
1-In the absence of deceit, the object of financial transaction may be a future thing.
2-It is prohibited to deal with the inheritance of an alive person, even if with his own consent, unless in the
circumstances stipulated by the law.
Article 203
1-A designated object must be provided for financial compensation and negating flagrant ignorance, by
indicating its special location, if it is already existing by the time of the contract or the statement of its and
characteristic features, while mentioning its magnitude, if being an appraised thing or anything of the sort
which deny flagrant ignorance.
2-If the object is known to the contractants, then no need to describe it or define it otherwise.
3-If the object shall not be designated according to the above, the contract shall be null and void.





Article 204
If the object to be disposed of or its consideration is an amount of money, its quantity and kind must be
determined. The currency fluctuation at the time of payment is immaterial.
Article 205
1-The object must be a thing that can be disposed of according to the terms of the contract.
2-Should the law forbid negotiating anything or should it be contrary to public policy or morals, the
contract is void.
Article 206
A contract may include a suitable condition which confirms it terms, admitted by custom or usage,
beneficial to one of the contracting parties or others unless it is prohibited by the legislator or contrary to
public policy or morals, in which case the condition is void but the contract remains valid except where the
condition is the prime motive of contracting and, in this case, the contract shall also be void.

B- CAUSE OF THE CONTRACT
Article 207
1-The cause shall be the direct intended purpose of the contract.
2-It must be existing, valid, lawful, and not inconsistent with public policy or morals.
Article 208
1-The contract is not valid unless it provides a lawful benefit to the contracting parties.
2-In contracts, the existence of such lawful benefit is supposed unless there is proof to the contrary.

VALID, VOID AND VOIDABLE CONTRACTS -6

A-THE VALID CONTRACT
Article 209
A contract is valid if licit in its essence and characterization, issued by a qualified person, having an object
that can be governed by the contract and an existing, valid and licit cause, validly specified and not subject to
a void condition.

B- THE VOID CONTRACT
Article 210
1-The void contract is the illicit one, by origin and description, due to a defect in one of its constitutive
elements, its object, purpose or the form imposed by law for its valid formation. This contract shall have no
effect and cannot be ratified.
2-Every interested party is entitled to invoke the invalidity, and the judge to decide it ex officio.
3-Action is nullity may not be heard after the lapse of fifteen years as of conclusion of the contract, but
every interested person may, at any time, raise a plea in voidance of the contract.
Article 211
1-Where a contract is partially void, the whole contract shall be void unless the share of each part is
determined, then the contract shall be void in that part and shall remain valid for the rest.
2-If the contract, in part of it, is suspended, this part shall remain so subject to its being authorized and,
when accepted, the whole contract shall be enforced, otherwise it shall be void in the suspended part alone to
the extent of its share in the consideration and shall be enforced in the other part to the extent of its share.

C- THE VOIDABLE CONTRACT





Article 212
1-The voidable contract is licit in its essence but not in its characterization. It shall be valid once the cause
of its voidableness has ceased to exist.
2-Ownership of the object of the contract is not established unless upon receiving its value.
3-It shall have no effect except within the limits specified by law.
4-Each of the contracting parties or their heirs shall have the right to rescind the contract after notifying the
other party.

THE SUSPENDED CONTRACT AND NON-BINDING CONTRACT -7

A- THE SUSPENDED CONTRACT
Article 213
The implementation of a transaction shall be suspended until authorized, in case the author of the
transaction is a trespasser of another person’s property; or if he is the owner disposing of his property but
subject to a lien in favor of a third party; or where the author of the transaction is a minor disposing of his
property but his act is at the same time profitable and detrimental to him; or done by a person under duress;
or if the law so provides.
Article 214
Authorization of a contract shall be given to the owner, the owner of a right on the object of the contract,
the tutor or guardian or the minor himself when completing his capacity, the person under duress after
disappearance of coerxion, or the person specified by law.
Article 215
1-Authorization shall be by any act or words so indicating expressly or impliedly.
2-Silence shall be considered approval if customarily indicating assent.
Article 216
In order to be valid the authorization must concern a transaction that can be authorized, both at its
performance and at the moment of giving the authorization. Moreover, the beneficiary of this authorization,
the contracting parties and the object of the transaction must exist at the moment of granting it, in addition to
the consideration thereof in case it is in kind.
Article 217
1-Once authorized, the suspended act of disposition shall be enforced as at its inception and the subsequent
authorization shall be considered as a prior power of attorney.
2-Should authorization be withheld, the transaction is void.

B- THE NON-BINDING CONTRACT
Article 218
1-The contract shall be non binding with respect to one, or both, contracting parties, despite its validity and
enforceability, if the right of rescission is given without need to secure the approval of the other party or
resort to court.
2-Any of the two contracting parties has independently the right to rescind such contract if, by nature, it is
not binding to him or if he retained for himself the right to rescind it.

OPTIONS THAT IMPAIR THE BINDING EFFECT OF THE CONTRACT -8

A- THE CONDITION OPTION
Article 219





In binding contracts but subject to rescission, the contracting parties may, both or one of them, stipulate
upon conclusion of the contract or subsequent thereto, a condition option for himself or for a third party
fixing the period within which the parties have to reach an agreement. Should they fail to fix such period, the
judge may fix it in accordance to custom.
Article 220
In financial transactions, if the condition option is stipulated in favor of both contracting parties, the two
considerations shall remain their respective property. In case the option condition is in favor of one of them,
his consideration shall remain his property and the consideration of the other party shall not accrue to him.
Article 221
1-The beneficiary of the option provision shall have the right to rescind the contract or approve it.
2- If he opts for approval, the contract shall be binding as of the time of its formation and if he opts for
rescission, the contract shall be rescinded, and considered as if it never existed.
Article 222
If the option is stipulated in favor of each of the contracting parties and one of them opts for rescission, the
contract shall be rescinded, even if the other party approves it, but if he opts for approval, the other party’s
option shall remain in effect during the option period.
Article 223
1-Rescission or approval shall be effective by any act or statement indicating any of them, explicitly or
implicitly.
2-If the period shall end, without electing approval or rescission, the contract becomes binding.
Article 224
1-The validity of rescission is conditioned upon electing it within the option period and the knowledge
thereof by the other party, if the rescission is verbal and is not conditioned by mutual assent or resorting to
court.
2-The approval, however, is not conditioned upon knowledge thereof by the other party.
Article 225
The option shall be forfeited by the death of the beneficiary thereof within the option period and the
contract shall be binding to his heirs, but the option of the other party shall remain open to him until the
expiry of the option period, provided he was given this option.

B- THE VIEWING OPTION
Article 226
The viewing option is given, in contracts that may be rescinded, to the party in favor of whom the act was
performed, even if he does not condition the contract upon such option, and if he did not see the object of the
contract which was only specified by description.
Article 227
The viewing option shall remain until viewing is achieved, within the agreed period, or forfeited.
Article 228
The viewing option shall not prevent the enforcement of the contract, but shall render it non binding with
respect to the party in favor of whom the option is given.






Article 229
1-The viewing option may not be forfeited by surrender.
2-It shall be forfeited by viewing the object of contract, its express or implied acceptance, by the death of
the party having the option, total or by disposing of it by the beneficiary of the option in a way that does not
allow rescission or that gives right to others.
Article 230
Rescission, by viewing option, shall be accomplished by any action or statement that explicitly or
implicitly indicates it, provided that the other contracting party has had knowledge of it.

C- DESIGNATION OPTION
Article 231
It may be agreed that the object of contract would be one of two or three things, giving any of the
contracting parties to opt for one of these provided that the consideration for each and the option period are
stated.
Article 232
If both contracting parties do not fix the option period, or the period fixed for either party has elapsed
without exercising his option, the other party may ask the judge to fix the option period or the object of the
transaction.
Article 233
The contract shall not be binding to the party having the option until he exercises it. Once the express or
implied choice is made, the contract becomes enforceable and binding in accordance thereto.
Article 234
The effect of exercising the designation option goes back to the date of formation of the contract.
Article 235
1-If the designation option is given to the purchaser and one of the two things perishes in the hands of the
seller, the buyer, at his discretion, may take the other thing at its price or leave it. Should however the two
things perish, the sale is null and void.
If one of the two things under option perishes in the hands of the buyer, the perished thing is designated for
sale and the buyer is bound to pay its price and the other thing shall be held in trust.
If both things perish one after the other, the first one shall perish as a sold object, and the other as an object
under trust. If they perish simultaneously, the buyer is liable for half the price of each.
2-If the designation option is for the seller and one of the things under options perishes prior or after
receiving payment, the seller shall have the choice to bind the buyer to purchase the other thing or to rescind
the contract. However, if the two things perish before payment, the contract is void.
If both things perish successively, the first one shall perish in trust, and the second in sale. If both things
perish simultaneously, the buyer shall be liable for half the price of each.
Article 236
In case of death of the person for whom the option was given within the option period, his right shall
devolve to his heirs.

D- THE OPTION OF DEFECT
Article 237






The right for rescission of the contract, under the option of defect, shall be operative in contracts, where
rescission is likely to occur, without stipulating it in the contract.
Article 238
The defect which makes the option operative must be old, affecting the value of the contract’s object,
unknown to the buyer and provided the seller did not specify the discharge thereof as a condition in the
contract.
Article 239
1-If the defect fulfills the conditions mentioned in the previous article, the contract shall not be binding to
the option holder before payment, and rescindable thereafter.
2-Rescission of the contract prior to receiving payment, with all what it entails, without need for consent or
court action provided that the other contracting party has knowledge thereof. After payment rescission shall
take place only by consent or by court action.
Article 240
Rescission of the contract on grounds of defect shall result in returning the object of the contract to its
owner and recovering what was paid.
Article 241
1-The defect option shall be forfeited by accepting the defect after knowledge of it, by disposing of the
contract’s object even before knowledge thereof, by its perishing or diminishing after payment or its
increment prior to payment in an uninterrupted manner but not generated from it due to an act of the
purchaser and, after payment if due to an act of the purchaser and, after payment if due to an independent
cause generated by it.
2-The defect option shall not be forfeited by the death of its holder, and shall be fixed for his heirs.
Article 242
The defect option holder shall have a possessory lien against the object of the contract, and a plea for
reduction of price.

SECTION THREE
EFFECT OF THE CONTRACT

BETWEEN CONTRACTING PARTIES -1
Article 243
1-Unless the law provides otherwise, the contract’s provisions apply on the object of the contract and its
consideration immediately upon its formation without making them dependant on payment or anything else.
2-As regards the contract's rights (obligations), each of the contracting parties shall fulfill what the contract
has bound him to do.
Article 244
The contract against consideration, concerning the usufruct of properties, once fulfilling the conditions of
its validity, shall establish the right of each of the contracting parties to the consideration received and shall
bind each one of them to deliver his property, object of the contract, to the other.
Article 245
The contract against consideration, concerning the usufruct of properties, once fulfilling the conditions of
its validity, binds the party disposing of the property to deliver it to the beneficiary of the usufruct and binds
the latter to hand over the usufruct consideration to the owner of the property.
```

## Appendix B — Civil Code Articles 282–348 tort and civil liability excerpt

```text
Article 282
The author of any tort, even if not discerning, shall be bound to repair the prejudice.
Article 283
1-Tort shall be committed by perpetration or by causation.
2-If committed by perpetration, he is unconditionally bound to repair the prejudice and, if by causation, it
is conditional upon transgression premeditation or if the act caused the prejudice.
Article 284
If the perpetration and the causation are both present, the act shall be considered as committed by
perpetration.
Article 285
If any person shall mislead another, he shall be liable for reparation of the prejudice resulting from
misleading.
Article 286
Whoever had his property damaged by someone else, shall not damage the property of the latter, otherwise
each shall be liable to make good what he had damaged.
Article 287
In the absence of a provision in the law or an agreement to the contrary, a person is not liable for reparation
if he proves that the prejudice resulted from a cause beyond his control such as a heavenly blight, unforeseen
circumstances, force majeure, the fault of others or of the victim.
Article 288
Whoever causes an injury to another in legitimate defense of his person, honor or property or, of the
person, honor or property of others, is not responsible, provided that he does not exceed the measures
necessary for his defense, as otherwise he will be liable to damages for this excess.
Article 289
1-The act is the responsibility of the doer and not of the one who ordered it, unless the doer was compelled
to act. Compulsion that is taken into consideration must amount to imminent duress.






2-Notwithstanding the above, a public servant is not responsible of his acts that injured third persons if he
acted in compliance to an order given by his superior whenever he was under duty to comply with, or if he
believed so and establishes that his belief of the legality of his act is based on reasonable grounds and that he
observed the precautionary measures in performing his act.
Article 290
The judge may reduce the amount of damages, or not allow any, if the injured has contributed, by his
action, in the happening of such injury or in its increase.
Article 291
When several persons are responsible for a prejudicial act, each one of them is responsible for his share in
it and the judge may decide to allot the liability equally between them or consider them jointly and severally
responsible.
Article 292
Damages shall, under all circumstances, be assessed to cover the prejudice sustained and the lost profit
provided it is a natural consequence of the prejudicial act.
Article 293
1-Damages shall include moral damages. Shall be considered moral damages, trespassing against others in
their freedom, honor, dignity reputation social standing or financial position.
2-Spouses and closet relatives of the family may be adjudged damages for the moral prejudice sustained by
them as a result of the death of the injured.
3-Recovery of moral damages is not transferable to others unless its amount is fixed by agreement or a
final court judgment.
Article 294
Damages may be paid by installments, as it may consist of a regular periodical payment and, in either
cases, the debtor may be ordered to provide a deposit in guarantee assessed by the judge, or an acceptable
security.
Article 295
Damages will consist of a money payment. Upon request of the victim, however, the judge may, in
accordance with the circumstances, order that the damage be made good by restoring the parties to their
original status, or by performing, in compensation, a specific matter connected with the prejudicial act.
Article 296
Any condition exonerating from tort liability shall be deemed null and void.
Article 297
Civil liability, once its conditions fulfilled, shall not impair criminal responsibility, and the criminal penalty
shall have no bearing on determining the scope of civil liability and the assessment of damages.
Article 298
1-An action for damages arising from an unlawful act is prescribed after three years from the date upon
which the victim knew of the injury and the identity of the person who was responsible.
2-Where a claim arises out of a criminal offense and the hearing of the penal action is still pending after the
lapse of the periods above-mentioned in the preceding clause, the action for damages may still be heard.
3-An action for damages is prescribed in any case after fifteen years from the date on which the prejudicial
act was committed.





SECTION TWO
LIABILITY ARISING FROM PERSONAL ACTS

INJURY TO THE PERSON-1
Article 299
Damages are compulsory due for prejudice to the person.
Unless otherwise agreed between the parties, either blood money or compensation for defect of sold value,
in cases they are due, may not be added to damages.

DAMAGE TO PROPERTY -2
Article 300
Without prejudice to the general provisions on damages, whoever damages or destroys the property of
another, shall be liable to replace it, if fungible, or pay its value, if ad valorem.
Article 301
Without prejudice to the general provisions on damages, in case the damage is partial, the perpetrator shall
be liable to compensate the loss in value and in case it is a gross damage, the property owner may opt either
to receive the value of the damaged part or abandon the property and take its value.
Article 302
1-If one destroys the property of others pretending that it is his own, shall be liable to damages for what he
has destroyed.
2-Should he destroy the property of another, with his permission, he shall not be liable for damages.
Article 303
If an infant, whether discerning or not, or the like, shall destroy the property of others, he shall be
responsible in his personal funds.

EXTORTION AND TRANSGRESSION -3
Article 304
1-The hand that has taken is liable until it gives it back.
2- The one who extorts the property of another shall have to restore it back in the same condition in which
it was at the time of extortion, and at the same place where extortion occurred.
3-Should he consume, destroy, lose it or if it has been destroyed due to his transgression or without it, he
shall have to replace it or pay its value, on date, and at the place, of extortion.
4- He shall also bear liability of its profits and increments.
Article 305
If one shall destroy the extorted property while under the control of the extortioner, the victim of extortion
shall have, at discretion, the option to recover the damages from the extortioner and this latter may go back
on the author of destruction, or recover damages from this latter who, in this case, has no right to revert on
the extortioner.
Article 306
If the extortioner has disposed of the extorted property, with or without consideration, and such exorted
property shall be destroyed, in whole or in part, while under the control of the person in favor of whom the
act of disposition was made, the victim of extortion may opt either to claim damages from either one. So, if





he recovers damages from the first, the act of disposition is valid, and if he recovers from the second, the
latter may revert on the extortioner in accordance with the law provisions.
Article 307
1-The extortioner of the extortioner shall be treated as extortioner.
2-If the extortioner of the first extortioner shall return back the extorted property to the first extortioner, he
shall be alone discharged and if he returns it to the victim of extortion he and the first extertioner shall be
discharged.
3-If the extorted property is damaged or has been destroyed while under the control of the extortioner, the
victim of extortion shall have the option to claim compensation from the first extortioner, or if he so wishes,
from the second extortioner.
He may also claim damages from the first for part of the damaged property and from the second for the
other part. So if he is compensated by the first extortioner, this latter may revert back against the second
extertioner and if compensated by the second, the latter may not revert on the first.
Article 308
Under all circumstances, the judge shall, if he deems it justified, condemn the extortioner to pay damages
as deemed adequate by him.
Article 309
Whoever has under his custody an object and neglected its protection, transgressed it, or unduly deprived
its owner from it, denied it or died without declaring it, shall be liable to replace it or pay its value, according
to the circumstances.
Article 310
Whoever has taken possession of money, by larceny or highway robbery and seized money, shall have to
restore to its owner, if still existing, replace it or pay its value, if it has been consumed, and even if he has
been sentenced.
Article 311
1-If the extorted object has undergone self change, the usurped person shall have an option either to
recover it or receive a similar object in replacement.
2- If the extorted object shall change, in such a way as to change its name, the extortioner is liable to
replace it.
3-If the extorted property shall change by the addition made by the extortioner out of his own money, the
extorted person shall have the option either to pay the added value and recover the extorted object in in kind,
or hold the extortioner liable to provide its substitute.
4-If the extorted property shall change by reduction in its value as a result of its utilization by the
extortioner, he shall be liable to return the property back and pay the reduction in value.
Article 312
Whatever amounts to extortion shall be treated as such.

SECTION THREE
LIABILITY ARISING FROM THE ACTS OF OTHERS
Article 313
1- No one is liable for the act of another person, however, upon request of the victim, the judge, if he
deems it justified, shall order any of the following persons, as the case may be, to pay the damages to which
the tort doer has been sentenced:





a-The person who is, by law or by agreement entrusted with the supervision of a person who, on account of
his minority or his mental or physical condition, requires supervision, unless he proves that he has fulfilled
his duty of supervision, or if the prejudice would have been anyhow sustained even if he has fulfilled his duty
with the required care.
b- The one having actual authority to control and guide the tort doer, even if he was not free in his choice,
if the tort was perpetrated by a subordinate in the exercise of his duty or because of it.
2-The one who settled the damages is entitled to revert on the person sentenced for payment thereof, in
order to recover what he has paid.

SECTION FOUR
LIABILITY ARISING FROM ANIMALS AND THINGS,
AND THE USE OF PUBLIC ROAD

ANIMALS -1
Article 314
The felony caused by an animal is punishable, but the liability for the prejudice caused is on the one having
control over it, whether being its owner or not if due to his negligence or transgression.

THE COLLAPSE OF BUILDINGS -2
Article 315
1-The injury to others caused by the collapse of a building, in whole or in part, is the liability of its owner
or the person in charge of it, unless he proves that he is not a trespasser or negligent.
2-Whoever is in danger of damage from a building is entitled to call on the owner to take the necessary
precautions to prevent the danger, and if the owner fails to take such precautions, to obtain an order from the
court authorizing him to take the necessary precautions himself at the cost of the owner.

THINGS AND MACHINERY-3
Article 316
Whoever is in charge of a thing whose supervision requires special care in order to protect him from its
danger, or of a machine, is liable for damage caused by these things or machines except that which, without
prejudice to any special provisions in this respect.

USE OF PUBLIC RIGHT -4
Article 317
The use of a public right is limited by the safety of others.So, if the user of a public right causes to third
persons a prejudice which cannot be prevented, by incurs liability.

CHAPTER FOUR
BENEFICIAL ACT
SECTION ONE
ENRICHMENT WITHOUT CAUSE
Article 318
No one is entitled, without cause, to enrich himself to the detriment of another person, without just cause.
If he does so, he is liable to restitute it.





Article 319
1-Unless otherwise provided by law, whoever enriches without just cause, is bound to restitute what he
obtained, if existing, or replacement thereof of its value, if not existing.
2-If one, unintentionally, loses control over his property, which was merged by accident with the property
of somebody else, in such a manner as it cannot be separated without prejudice to any of the owners, then the
property of lesser value shall follow the one with greater value, after settlement of its price. If both are equal
in value, they shall be sold for their account, and the price thereof shall be equally divided and distributed
among them, unless otherwise stipulated by Law.

SECTION TWO
PAYMENT NOT DUE
Article 320
Whoever gives something, being under the belief that he is under duty to do so, but it was later revealed
that it is not due by him, he is entitled to recover it from the one who received it, if existing, or a similar thing
in replacement thereof or its value, if not existing.
Article 321
A payment which was not due may be recovered, if it was made in the performance of an obligation whose
cause had not materialized or had ceased to exist.
Article 322
Restitution may also be made of a payment effected in the performance of an obligation which had not at
the time matured, if the payor was not aware that payment was not then due.
Article 323
If settlement has been made by other than the debtor and in consequence of this payment the creditor,
acting in good faith, has given up his document of title or security obtained, or allowed his claim against the
real debtor to be prescribed, he is not bound to restitute what he has received and the real debtor must
indemnity the payor, if appropriate.
Article 324
Whoever unduly receives that which is not due to him, he is bound to restitute it to the payor together with
the profits and interests. The judge may indemnify the right owner of what he has failed by neglect to collect
at that time.

SECTION THREE
VOLUNTARY AGENCY
Article 325
Whoever does a beneficial act to a third person without being ordered by him, but authorized by the judge,
commanded by necessity or imposed by custom, he is considered his agent and is governed by the following
provisions.
Article 326
The rules of mandate apply, if the person whom the voluntary agent acts ratifies his act.
Article 327






A voluntary agent must continue work he has commenced until the person for whom he acts is in a position
to do so himself. He must also, as soon as he is able to do so, inform the person for whom he acts of his
intervention.
Article 328
The voluntary is responsible to indemnify the person for whom he acts for the prejudice sustained by the
latter and, if circumstances so justify, the judge has to assess the amount of the indemnity.
Article 329
When the voluntary agent delegates to a third party the whole or part of the work, he shall be responsible
for the acts of his delegate, without prejudice to the right of the person for whom he acts to have a direct
recourse on this delegate.
Article 330
The voluntary is bound by the same obligations as a mandatory as regards the restitution of that which he
received as a result of the voluntary agency and must submit an account for his acts.
Article 331
The person for whom the voluntary agent has acted will be bound to carry out the obligations entered into
on his behalf by the voluntary agent, to indemnify him against all undertakings assumed by him, to reimburse
him monies usefully or necessarily expended by him which are justified by the circumstances, and to
indemnify him in respect of any loss he has suffered as a result of his management. The voluntary agent is
not entitled to any remuneration for his work unless the work falls within the scope of his professional
business.
Article 332
1-If the events of the death of a voluntary agent, his heirs are bound by the same obligations as those of a
mandatory upon his death.
2-In the event of the death of the person for whom he acts, the voluntary agent is bound by the same
obligations to the heirs as he was to the person of whom they were the successors in title.

SECTION FOUR
REIMBURSEMENT OF THIRD PARTIES DEBTS
Article 333
Whoever reimburses the debt of another, upon his order, is entitled to revert on the person giving the order
for what he has paid on his behalf and shall substitute the original creditor in his claim of the debt from the
debtor whether he the right of reversion is specifically provided for or not.
Article 334
Whoever fulfills the debt of another without his order is neither entitled to revert for what he has paid on
the debtor, except in the instances provided for in Article 325, nor revert on the creditor unless this latter
discharges the debtor from the debt even after recovering his debt from the payor.
Article 335
If a mortgagor settles the debt of somebody else, to liberate his mortgaged property in security for such
debt, he is entitled to revert on the debtor for what the amount settled by him.

SECTION FIVE
JOINT PROVISION





Article 336
The claim arising, from a beneficial act, shall not be heard after the lapse of three years from the date on
which the creditor had knowledge of his right of reversion, and in any case fifteen years from the day on
which the right arose.

CHAPTER FIVE
THE LAW
Article 337
Rights whish are directly and solely arising from law are governed by the provisions of the law giving right
to such rights.

TITLE TWO
THE EFFECTS OF A RIGHT
CHAPTER ONE
GENERAL PROVISIONS
Article 338
A right must be settled whenever its legal maturity conditions are satisfied. If the debtor is in default, the
right shall be compulsory enforced, either in kind or through payment of an indemnity, in conformity with the
law provisions.
Article 339
1-Implementation shall be willful if it is done by settlement or its equivalent.
2-It shall be forced if settled in kind or through compensation.
Article 340
In case a right loses, for any reason whatsoever, the protection of the law, it may not be forcibly enforced
and becomes a natural obligation against the debtor.
Article 341
If the debtor settles a natural obligation, his settlement shall be valid and not considered a payment which
is not due.

CHAPTER TWO
ENFORCEMENT MEANS
SECTION ONE
WILLFUL ENFORCEMENT

SETTLEMENT -1

A- PARTIES TO THE SETTLEMENT





Article 342
1-Payment may be made by the debtor, his agent, or any other interested person.
2-It is also valid if made by a person having no interest in doing so, whether pursuant to an order of the
debtor or without such order, the creditor may, however, refuse settlement from a third party in case the
debtor objected to such payment and notified his objection to the creditor.
Article 343
As a condition to be discharged from a debt, the payor must be the owner of what he settled. In the event
the debtor is a discerning minor, an imbecile of legal age or, a prodigal under custody, and pays the debt he
owes, his payment is valid unless it is detrimental to the payor.
Article 344
Payment to some creditors shall not be effective as concerns the other creditors, if the debtor is interdicted
and pays the debt that caused interdiction or sick in his last illness and the payment is detrimental to the other
creditors.

B- THE PAYEE
Article 345
Payment shall be made to the creditors or his representative. Shall be considered qualified to recover the
debt, whoever presents to the debtor a discharge issued by the creditor, unless it is agreed that payment shall
be made to the creditor in person.
Article 346
If the creditor lacks full legal capacity, the debtor shall not be discharged unless by settlement to his
guardian. In the event that settlement is made to the creditor and the object of settlement perishes in his
hands, or is lost by him, the guardian may claim the debt from the debtor.

C- REJECTION OF SETTLEMENT
Article 347
If the creditor unjustifiably refuses to accept the duly offered settlement, where acceptance is a must, or
abstain from performing the acts without which settlement is not complete, or has declared that he will not
accept the settlement, the debtor shall notify him with a warning and fix to him an adequate delay to perform
what he has to do in order to recover his right.
Article 348
Notification of the creditor shall result in putting the object of the obligation under the guarantee of the
creditor, if it was previously under the guarantee of the debtor, and the debtor shall be entitled to deposit it on
the creditor's expense and be compensated for the damages sustained.
```

## References

<p id="ref1" class="ref_item">[1] UAE Legislation — Federal Law No. 5 of 1985 Civil Transactions Law <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1025/download">https://uaelegislation.gov.ae/en/legislations/1025/download</a></p>
<p id="ref2" class="ref_item">[2] Aceris Law English PDF copy of UAE Civil Code used for extractable article text <a target="_blank" rel="noreferrer" href="https://www.acerislaw.com/wp-content/uploads/2024/09/UAE-Civil-Code.pdf">https://www.acerislaw.com/wp-content/uploads/2024/09/UAE-Civil-Code.pdf</a></p>
<p id="ref3" class="ref_item">[3] UAE Legislation — Federal Decree-Law No. 25 of 2025 Civil Transactions Law <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/4011/download">https://uaelegislation.gov.ae/en/legislations/4011/download</a></p>
<p id="ref4" class="ref_item">[4] Lexis Middle East — Federal Decree-Law No. 25/2025 preview <a target="_blank" rel="noreferrer" href="https://www.lexismiddleeast.com/law/UnitedArabEmirates/DecreeLaw_25_2025/en">https://www.lexismiddleeast.com/law/UnitedArabEmirates/DecreeLaw_25_2025/en</a></p>
<p id="ref5" class="ref_item">[5] K&L Gates — Impact of New Civil Transactions Law on UAE construction contracts <a target="_blank" rel="noreferrer" href="https://www.klgates.com/The-Impact-of-the-New-Civil-Transactions-Law-on-Construction-Contracts-in-the-United-Arab-Emirates-3-9-2026">https://www.klgates.com/The-Impact-of-the-New-Civil-Transactions-Law-on-Construction-Contracts-in-the-United-Arab-Emirates-3-9-2026</a></p>
<p id="ref6" class="ref_item">[6] White & Case — Key changes under UAE Federal Decree-Law No. 25 of 2025 <a target="_blank" rel="noreferrer" href="https://www.whitecase.com/insight-alert/rewriting-foundations-key-changes-under-uae-federal-decree-law-no-25-2025">https://www.whitecase.com/insight-alert/rewriting-foundations-key-changes-under-uae-federal-decree-law-no-25-2025</a></p>
<p id="ref7" class="ref_item">[7] Al Tamimi — Decennial liability in the UAE commentary <a target="_blank" rel="noreferrer" href="https://www.tamimi.com/law-update-articles/decennial-liability-in-the-uae-a-commentary/">https://www.tamimi.com/law-update-articles/decennial-liability-in-the-uae-a-commentary/</a></p>
<p id="ref8" class="ref_item">[8] IRBNet/CIB — Decennial Liability in Construction: UAE law and practice <a target="_blank" rel="noreferrer" href="https://www.irbnet.de/daten/iconda/CIB_DC27637.pdf">https://www.irbnet.de/daten/iconda/CIB_DC27637.pdf</a></p>
<p id="ref9" class="ref_item">[9] FIDIC — The Four FIDIC 1999 Contract Conditions <a target="_blank" rel="noreferrer" href="https://fidic.org/sites/default/files/The%20Four%20FIDIC%201999%20Contract%20Condition.docx">https://fidic.org/sites/default/files/The%20Four%20FIDIC%201999%20Contract%20Condition.docx</a></p>
<p id="ref10" class="ref_item">[10] NEC Contract — comparison of NEC4 ECC and FIDIC risk allocation <a target="_blank" rel="noreferrer" href="https://www.neccontract.com/news/comparison-of-risk-allocation-in-nec4-ecc-and-fidic-yellow-book">https://www.neccontract.com/news/comparison-of-risk-allocation-in-nec4-ecc-and-fidic-yellow-book</a></p>
<p id="ref11" class="ref_item">[11] UAE Ministry of Finance — Federal Law No. 11 of 2023 Procurement in the Federal Government PDF <a target="_blank" rel="noreferrer" href="https://mof.gov.ae/wp-content/uploads/2024/01/Federal-Law-No.-11-of-2023-on-Procurements-in-the-Federal-Government.pdf">https://mof.gov.ae/wp-content/uploads/2024/01/Federal-Law-No.-11-of-2023-on-Procurements-in-the-Federal-Government.pdf</a></p>
<p id="ref12" class="ref_item">[12] Lexis Middle East — Federal Law No. 11/2023 table of contents preview <a target="_blank" rel="noreferrer" href="https://www.lexismiddleeast.com/law/UnitedArabEmirates/Law_11_2023/en">https://www.lexismiddleeast.com/law/UnitedArabEmirates/Law_11_2023/en</a></p>
<p id="ref13" class="ref_item">[13] DIAC — 2025 Table of Fees and Costs <a target="_blank" rel="noreferrer" href="https://www.diac.com/wp-content/uploads/2024/12/0.3-DIAC-Casework-2025-Table-of-Fees-and-Costs.pdf">https://www.diac.com/wp-content/uploads/2024/12/0.3-DIAC-Casework-2025-Table-of-Fees-and-Costs.pdf</a></p>
<p id="ref14" class="ref_item">[14] Aceris Law — Total DIAC Arbitration Costs <a target="_blank" rel="noreferrer" href="https://www.acerislaw.com/diac-arbitration-costs/">https://www.acerislaw.com/diac-arbitration-costs/</a></p>
<p id="ref15" class="ref_item">[15] MoIAT — ICV Formula <a target="_blank" rel="noreferrer" href="https://moiat.gov.ae/en/programs/icv-formula">https://moiat.gov.ae/en/programs/icv-formula</a></p>
<p id="ref16" class="ref_item">[16] RTA Dubai — Contractors and suppliers general policies <a target="_blank" rel="noreferrer" href="https://www.rta.ae/wps/portal/rta/ae/home/about-rta/contractors-suppliers/general-policies/">https://www.rta.ae/wps/portal/rta/ae/home/about-rta/contractors-suppliers/general-policies/</a></p>
<p id="ref17" class="ref_item">[17] Reuters — Dubai Metro Blue Line contract award <a target="_blank" rel="noreferrer" href="https://www.reuters.com/world/middle-east/dubai-roads-transport-authority-awards-56-bln-metro-line-project-consortium-2024-12-19/">https://www.reuters.com/world/middle-east/dubai-roads-transport-authority-awards-56-bln-metro-line-project-consortium-2024-12-19/</a></p>
<p id="ref18" class="ref_item">[18] Autodesk — BIM Levels of Development <a target="_blank" rel="noreferrer" href="https://www.autodesk.com/solutions/bim-levels-of-development">https://www.autodesk.com/solutions/bim-levels-of-development</a></p>
<p id="ref19" class="ref_item">[19] RAK Municipality/SANAD — consultant and contractor requirements <a target="_blank" rel="noreferrer" href="https://sanad.mun.rak.ae/docs/en/%D8%A7%D8%B4%D8%AA%D8%B1%D8%A7%D8%B7%D8%A7%D8%AA-%D8%A7%D9%84%D9%85%D9%83%D8%A7%D8%AA%D8%A8-%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D8%B4%D8%A7%D8%B1%D9%8A%D8%A9-%D9%88%D8%B4%D8%B1%D9%83%D8%A7%D8%AA-%D8%A7%D9%84%D9%85%D9%82%D8%A7%D9%88%D9%84%D8%A7%D8%AA">https://sanad.mun.rak.ae/docs/en/%D8%A7%D8%B4%D8%AA%D8%B1%D8%A7%D8%B7%D8%A7%D8%AA-%D8%A7%D9%84%D9%85%D9%83%D8%A7%D8%AA%D8%A8-%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D8%B4%D8%A7%D8%B1%D9%8A%D8%A9-%D9%88%D8%B4%D8%B1%D9%83%D8%A7%D8%AA-%D8%A7%D9%84%D9%85%D9%82%D8%A7%D9%88%D9%84%D8%A7%D8%AA</a></p>
<p id="ref20" class="ref_item">[20] MOEI — registration and e-qualification for consultants, contractors and suppliers <a target="_blank" rel="noreferrer" href="https://www.moei.gov.ae/en/services/registration-and-e-qualification-for-consultants-contractors-and-suppliers-for-engineering-project">https://www.moei.gov.ae/en/services/registration-and-e-qualification-for-consultants-contractors-and-suppliers-for-engineering-project</a></p>
<p id="ref21" class="ref_item">[21] DMT — Classification requirements category page <a target="_blank" rel="noreferrer" href="https://pages.dmt.gov.ae/en/Classification-Category">https://pages.dmt.gov.ae/en/Classification-Category</a></p>
<p id="ref22" class="ref_item">[22] Mayer Brown — New UAE Civil Code Part 1 force majeure and exceptional circumstances <a target="_blank" rel="noreferrer" href="https://www.mayerbrown.com/en/insights/publications/2026/05/examining-the-new-uae-civil-code-part-1-force-majeure-exceptional-circumstances-and-relief-in-times-of-crisis">https://www.mayerbrown.com/en/insights/publications/2026/05/examining-the-new-uae-civil-code-part-1-force-majeure-exceptional-circumstances-and-relief-in-times-of-crisis</a></p>
<p id="ref23" class="ref_item">[23] Mayer Brown — New UAE Civil Code Part 2 muqawala contracts <a target="_blank" rel="noreferrer" href="https://www.mayerbrown.com/en/insights/publications/2026/06/examining-the-new-uae-civil-code-part-2-muqawala-contracts">https://www.mayerbrown.com/en/insights/publications/2026/06/examining-the-new-uae-civil-code-part-2-muqawala-contracts</a></p>
