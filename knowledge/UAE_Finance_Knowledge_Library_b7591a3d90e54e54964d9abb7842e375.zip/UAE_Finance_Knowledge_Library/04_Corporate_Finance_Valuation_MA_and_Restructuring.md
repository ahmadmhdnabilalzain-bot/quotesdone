# Corporate Finance, Valuation, M&A, Restructuring, and Financial Analysis in the UAE

This chapter treats **corporate finance, valuation, M&A, restructuring, and financial analysis in the UAE** as a professional operating manual for UAE finance teams, auditors, controllers, CFOs, compliance officers, bankers, analysts, and advisors. The UAE finance environment is not a single-rule system: it combines federal law and regulators, financial free-zone rulebooks, international standards, tax authority requirements, and sector-specific supervisory expectations. The source base used for this chapter comes from the collected research packets and prioritizes official regulators and standard setters where available.

For practical work, each topic should be read through four lenses: (1) the legal or regulatory rule that creates the obligation; (2) the accounting, audit, tax, risk, or valuation standard that determines technical treatment; (3) the evidence the professional must retain; and (4) the governance owner who signs, reviews, files, or challenges the output.

Key source families for this chapter include [[1]](#ref1), [[2]](#ref2), [[1]](#ref1).

## 1. Corporate Finance Scope

Corporate finance in the UAE covers capital allocation, investment appraisal, funding decisions, dividend policy, M&A, takeover rules for listed companies, restructuring reliefs, bankruptcy, valuation, and management performance analysis. The research base connects this chapter to the Commercial Companies Law, SCA/market rules, Corporate Tax, bankruptcy law, IFRS and valuation professional standards. [[1]](#ref1)[[1]](#ref1)

## 2. Source Research Digest — Corporate Finance


**Research topic:** Corporate finance, capital budgeting, cost of capital, M&A and restructuring in UAE context

**Extracted report title:** Corporate finance, capital budgeting, cost of capital, M&A and restructuring in UAE context

I have completed the research for the assigned shard (5/12) regarding UAE Corporate Finance, Capital Budgeting, Cost of Capital, M&A, and Restructuring. Below is a summary of the evidence collected and the status of the research as of July 2026.

### **Research Summary**

#### **1. Core Frameworks and Regulatory Overhaul (2025-2026)**
*   **Capital Market Authority (CMA):** As of January 1, 2026, the **Capital Market Authority (CMA)** has replaced the Securities and Commodities Authority (SCA) under **Federal Decree-Law No. 32 of 2025**. This new regulator oversees public M&A, offerings, and market conduct with expanded powers over virtual assets and cross-border activities.
*   **Commercial Companies Law (CCL):** **Federal Decree-Law No. 20 of 2025** significantly amended the 2021 Companies Law. Key changes include the introduction of **class shares**, enhanced deadlock resolution tools, and the ability for companies to migrate registrations between emirates and free zones while maintaining legal personality.
*   **Bankruptcy and Restructuring:** **Federal Decree-Law No. 51 of 2023** (effective May 2024) replaced the 2016 law. It introduced the **"Preventive Settlement"** procedure, a court-supervised mechanism allowing debtors to manage assets without a trustee during a 3-to-6 month moratorium.

#### **2. M&A and Capital Budgeting in the UAE Context**
*   **Takeover Rules:** The **CMA Takeover Code** (Decision No. 18/R.M of 2017, as updated) remains the primary guide for listed PJSCs, maintaining a **30% (plus one share) mandatory offer threshold**.
*   **Corporate Tax Impact:** Under **Federal Decree-Law No. 47 of 2022**, capital budgeting must account for the **Interest Deduction Limitation Rule**. Net interest expenditure is capped at the higher of **30% of adjusted EBITDA** or a **safe harbour of AED 12 million**.
*   **Sovereign Investment:** The emergence of **L'IMAD** in Abu Dhabi (consolidating ADQ assets) as a **$300 billion sovereign platform** has shifted the M&A landscape, focusing on "disciplined ownership" and domestic industrial scaling.

#### **3. Cost of Capital (July 2026 Data)**
*   **Risk-Free Rate ($):** UAE 10-year government bonds are trading at approximately **4.85%**, typically priced at a spread (approx. 105-135 bps) over US Treasuries.
*   **Equity Risk Premium (ERP):** Estimated at **4.23% to 5.03%** for the UAE market, depending on the valuation model (e.g., Damodaran's adjusted country risk approach).
*   **Valuation Standards:** Professional practice is strictly aligned with the **RICS Red Book** and **International Valuation Standards (IVS)**, with the 2024 IVS edition being the current benchmark for M&A and financial reporting.

#### **4. Professional Practice and Certifications**
*   **Certifications:** CFA and CMA (US) remain the gold standards for corporate finance roles. For valuation, **RICS** and **TAQEEM** (often referenced in regional cross-border deals) are critical.
*   **Advisory:** M&A transactions typically require a 2-4 month timeline for private deals, involving legal, financial, and tax due diligence (DD) specifically focused on UAE-specific licensing and UBO (Ultimate Beneficial Ownership) compliance.

### **Checklist Status (Path: `/data/workspace/.../RESEARCH_CHECKLIST.md`)**
*   **[Y]** Define domain scope and relevance to UAE finance library.
*   **[Y]** Identify core frameworks/laws (Companies Law 2025, CMA 2026).
*   **[Y]** Research UAE-specific M&A rules (Takeover Code, Foreign Ownership).
*   **[Y]** Research Cost of Capital components (RFR, ERP, WACC).
*   **[Y]** Research Capital Budgeting factors (Tax interest caps, Free Zones).
*   **[Y]** Research Restructuring and Bankruptcy Law (2023 Decree).
*   **[Y]** Identify professional practice and certification links.
*   **[Y]** Document sources and gaps.

### **Gaps and Verification Notes**
*   **Specific Sector Thresholds:** While the general interest cap is AED 12M, specific "Qualifying Infrastructure Projects" have exemptions that require project-by-project verification.
*   **CMA Implementing Regulations:** As the CMA is a new entity (est. 2026), some legacy SCA circulars are still being codified into the new CMA Rulebook; practitioners should verify the latest "Administrative Decisions" on the CMA portal.

**Sources include:** UAE Ministry of Economy, Capital Market Authority (CMA), UAE Federal Tax Authority (FTA), Al Tamimi & Co, Cleary Gottlieb, Gibson Dunn, and RICS Global Standards.

---


## 3. Source Research Digest — Valuation and Financial Analysis


**Research topic:** Financial statement analysis, ratios, valuation and business performance management

**Extracted report title:** Financial statement analysis, ratios, valuation and business performance management

This research report provides a comprehensive technical deep-dive into financial statement analysis, valuation, and business performance management within the United Arab Emirates (UAE) regulatory and professional landscape as of July 2026.

### 1. Domain Scope
The domain of Financial Statement Analysis (FSA), Valuation, and Business Performance Management (BPM) is the analytical engine of the UAE finance sector. It bridges raw accounting data (IFRS) with strategic decision-making, investment appraisal, and regulatory compliance. In the UAE, this domain is critical due to:
*   **Capital Market Integrity**: Ensuring transparency for listed entities on ADX and DFM under the applicable onshore capital-markets regulator, reflecting the research transition from SCA to CMA.
*   **Financial Stability**: Monitoring the health of the banking sector via Central Bank of the UAE (CBUAE) prudential ratios.
*   **Economic Diversification**: Supporting the "We the UAE 2031" vision by providing standardized valuation for the massive real estate and infrastructure sectors.
*   **Tax Compliance**: Providing the basis for taxable income calculation under the UAE Corporate Tax Law (Federal Decree-Law No. 47 of 2022).

### 2. Core Frameworks and Standards
The UAE operates a multi-tiered regulatory framework depending on the jurisdiction (Onshore, DIFC, or ADGM).

*   **Financial Reporting Standards**: IFRS is the mandatory framework for all listed companies and financial institutions in the UAE.
    *   > "All the public joint stock companies are expected to comply with the rules. The SCA, being the regulatory authority supervising listed companies, shall oversee the application of this Guide." — *PwC, Navigating the SCA Amendments (2024) [[3]](#ref3)
*   **Valuation Standards**:
    *   **International Valuation Standards (IVS)**: Adopted as the primary benchmark for business and asset valuation.
    *   **RICS Red Book (Global Standards)**: Mandatory for RICS-qualified professionals in the UAE, incorporating IVS 2024.
    *   **Taqeem**: The Saudi Authority for Accredited Valuers (Taqeem) standards are often referenced in regional cross-border transactions, though the UAE primarily follows IVS/RICS.
*   **Internal Control Frameworks**:
    *   **COSO Framework**: Explicitly recommended by the SCA for listed companies to manage risk and internal controls.
    *   > "Companies are mandated to implement a robust internal control framework (preferably Committee of Sponsoring Organizations of the Treadway Commission Framework (COSO)) for effective risk and control management, as outlined in Article 14(7)." — *PwC, Navigating the SCA Amendments (2024) [[3]](#ref3)

### 3. UAE-Specific Rules and Practical Notes
#### A. Banking Sector Prudential Ratios (CBUAE)
The CBUAE enforces strict quantitative requirements aligned with Basel III to ensure systemic stability.
*   **Capital Adequacy Ratio (CAR)**: Minimum **10.5%** (excluding buffers).
*   **Common Equity Tier 1 (CET1)**: Minimum **7%** of Risk-Weighted Assets (RWA).
*   **Leverage Ratio**: Minimum **3.0%** for all banks; **3.5%** for Domestic Systemically Important Banks (D-SIBs).
*   **Liquidity Ratios**:
    *   **Eligible Liquid Assets Ratio (ELAR)**: Banks must hold **10%** of total balance sheet liabilities in high-quality liquid assets.
    *   **Advances to Stable Resources Ratio (ASRR)**: Limits the extent to which long-term assets are funded by unstable liabilities.
    *   > "The UAE instituted a higher minimum capital requirement of 10.5% (excluding capital buffers), applicable to all licensed banks." — *CBUAE, Standards for Capital Adequacy of Banks in the UAE [[4]](#ref4)

#### B. Real Estate Valuation (Dubai/DLD)
In Dubai, real estate valuation is strictly regulated by the Dubai Land Department (DLD) and RERA.
*   **Valuation Fees**: Range from **AED 2,000 to AED 15,000** depending on property type.
*   **Legal Basis**: Executive Council Resolution No. (37) of 2015 and Administrative Resolution No. (67) of 2020.
*   **Mandatory Use**: Valuations are required for property transfers, mortgages, and court disputes.
*   > "Dubai Land Department has ensured that this guide is developed by the International Valuation Standards issued by the International Valuation Standards Council (IVSC)." — *DLD, Dubai Real Estate Valuation Guide (2025) [[5]](#ref5)

#### C. Corporate Tax and Audited Financial Statements
Under Ministerial Decision No. 84 of 2025, specific entities must maintain audited financial statements for tax purposes:
*   **Tax Groups**: Must prepare audited special purpose financial statements regardless of revenue size.
*   **Revenue Threshold**: Generally, taxable persons with revenue exceeding **AED 50 million** must have audited FS.
*   **Qualifying Free Zone Persons (QFZP)**: Must maintain audited FS to benefit from the 0% tax rate.

### 4. Technical Content: Formulas and Procedures
#### A. Financial Ratio Analysis (UAE Context)
While standard IFRS ratios apply, UAE analysts focus on:
1.  **Liquidity**: Current Ratio ($Current Assets / Current Liabilities$) and Quick Ratio.
2.  **Solvency**: Debt-to-Equity and Interest Coverage Ratio (critical for highly leveraged real estate firms).
3.  **Profitability**: ROE and ROA, with specific attention to "Non-Oil Revenue" growth for diversified conglomerates.
4.  **Islamic Finance Ratios**: For Islamic banks (ADIB, DIB), analysts use AAOIFI-based metrics such as the **Investment Risk Reserve** and **Profit Equalization Reserve** levels.

#### B. Business Valuation Methodologies
Accepted methods in UAE courts and for M&A:
*   **Income Approach**: Discounted Cash Flow (DCF) is the "gold standard."
    *   *UAE Nuance*: Risk-free rates are typically pegged to US Treasuries plus a UAE country risk premium (though the UAE's sovereign rating often results in a low premium).
*   **Market Approach**: Comparable Company Analysis (CCA) and Precedent Transactions.
    *   *UAE Nuance*: EBITDA multiples for UAE private companies typically range from **6x to 10x**, varying by sector (e.g., higher for Tech/Fintech in ADGM/DIFC).
*   **Asset-Based Approach**: Used primarily for holding companies and real estate-heavy entities.

#### C. Performance Management (BPM)
*   **Government Sector**: Uses the **Adaa Performance System** to track thousands of KPIs against national strategies.
*   **Private Sector**: Increasing adoption of **ESG (Environmental, Social, and Governance)** metrics in performance reports, driven by SCA's 2024 amendments requiring ESG disclosures for listed firms.

### 5. Professional Practice
*   **Audit Oversight**: The SCA and DFSA signed a Memorandum of Understanding (MoU) in October 2025 to enhance audit oversight, focusing on firm registration and inspection to improve financial reporting integrity.
*   **Expert Evidence**: IVS-compliant valuation reports are mandatory for expert testimony in UAE courts, ADGM Arbitration, and DIFC proceedings.
*   **Internal Audit**: Must remain a distinct function and cannot be merged with other operational roles (SCA Article 67).

### 6. Certification Knowledge
*   **UAE Chartered Accountant (UAECA)**: A national qualification developed by the Accountants and Auditors Association (AAA) in partnership with ACCA. It is the premier local designation for financial analysis and audit.
*   **CFA (Chartered Financial Analyst)**: Highly regarded for valuation and investment analysis roles in the DIFC and ADGM.
*   **RICS Registered Valuer**: Mandatory for real estate valuation professionals in Dubai.

### 7. Gaps and Verification Notes
*   **[Verify]**: The specific "additional procedures" for Qualifying Free Zone Persons (QFZP) engaged in distribution activities under the 2025 Corporate Tax updates are still awaiting detailed guidance from the FTA.
*   **[Not found]**: A unified "UAE National Supplement" for the RICS Red Book 2026 was not explicitly found; practitioners currently use the Global Standards with local DLD/RERA alignment.
*   **[Conflict]**: There is a minor practical conflict between IFRS 16 (Leases) and local "Ejari" registration practices regarding the determination of lease terms for "Right of Use" assets, often requiring professional judgment by UAE auditors.

### Sources
*   **SCA/PwC**: *Navigating the SCA Amendments (2024) [[3]](#ref3)
*   **CBUAE**: *Standards for Capital Adequacy of Banks in the UAE [[4]](#ref4)
*   **Dubai Land Department**: *Dubai Real Estate Valuation Guide (2025) [[5]](#ref5)
*   **ACCA Global**: *Support for students in the UAE (UAECA) [[6]](#ref6)
*   **KPMG**: *Updated Ministerial Decision on Audited Financial Statements (2025) [[7]](#ref7)
*   **DFSA**: *Regulatory Reporting Regime [[8]](#ref8)
*   **ADGM**: *GEN 6.2 Financial Statements and Reporting Standards [[9]](#ref9)

**Checklist Status Summary**:
Checklist file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/8a7af6b5/RESEARCH_CHECKLIST.md`
All items marked `[Y]`.

---


### Core corporate finance formulas

- **Net present value:** `Σ(Cash flow_t ÷ (1 + r)^t) - Initial investment`. **Use:** Accept projects with positive NPV when assumptions and strategic risk are acceptable.
- **Internal rate of return:** `Discount rate where NPV = 0`. **Use:** Compare project return to hurdle rate and WACC.
- **Weighted average cost of capital:** `(E/V × Cost of equity) + (D/V × Cost of debt × (1 - tax rate))`. **Use:** Discount rate for enterprise cash flows where capital structure assumptions are appropriate.
- **Free cash flow to firm:** `EBIT × (1 - tax rate) + D&A - Capex - ΔNWC`. **Use:** Enterprise valuation cash-flow basis.
- **Enterprise value:** `Equity value + Debt + Preferred interests + Non-controlling interests - Cash`. **Use:** Bridge between operating business value and equity value.
- **EBITDA margin:** `EBITDA ÷ Revenue`. **Use:** Operating performance and valuation multiple comparator.
- **Net working capital:** `Current operating assets - Current operating liabilities`. **Use:** Liquidity and deal-price adjustment measure.

## 4. Valuation Methodology Manual

### DCF model build checklist

1. **Historical base** — Reconcile audited financial statements, management accounts, one-off items, tax status and working-capital seasonality.
2. **Revenue forecast** — Separate price, volume, customer retention, new contracts, market capacity, regulation and collection assumptions.
3. **Margin forecast** — Build gross margin, staff costs, rent, utilities, logistics, marketing, overheads and inflation drivers.
4. **Tax and free-zone assumptions** — Reflect UAE Corporate Tax, exemptions, reliefs and transfer-pricing impacts where supported by evidence.
5. **Capex and working capital** — Model maintenance capex, growth capex, inventory, receivables, payables and contract assets/liabilities.
6. **Discount rate and terminal value** — Document beta, risk-free rate, equity risk premium, country/size risk, capital structure, cost of debt and terminal growth.
7. **Sensitivity** — Show valuation range using WACC, terminal growth, EBITDA margin, revenue growth and working-capital scenarios.

## 5. M&A and Restructuring in the UAE

The research identifies UAE takeover rules for public joint stock companies, including the mandatory bid threshold of 30% plus one share and squeeze-out threshold of 90% plus one share in the SCA takeover framework. [[1]](#ref1)

### M&A due diligence checklist

1. **Financial due diligence** — Quality of earnings, normalized EBITDA, working-capital peg, net debt, off-balance-sheet items and forecast support.
2. **Tax due diligence** — Corporate Tax registration, VAT filings, TP, related parties, free-zone status, contingent liabilities and tax elections.
3. **Legal and regulatory** — Licences, ownership, approvals, employment, litigation, contracts, change-of-control clauses and sector restrictions.
4. **Commercial diligence** — Market size, customers, churn, pricing, competitors, supplier dependency and growth pipeline.
5. **Integration planning** — Chart of accounts, ERP, banking mandates, payroll, tax groups, reporting timetable and internal controls.

## 6. Bankruptcy, Distress and Turnaround

The finance role in distress is to preserve liquidity, forecast cash accurately, maintain creditor communication, protect books and records, identify going-concern risks, and evaluate restructuring routes. UAE restructuring analysis should connect cash-flow forecasts with legal advice on insolvency and bankruptcy frameworks identified in the research.
## 7. Ratio Analysis Library

| Category | Ratio | Formula | Use |
| --- | --- | --- | --- |
| Liquidity | Current ratio | Current assets ÷ Current liabilities | Short-term solvency indicator. |
| Liquidity | Quick ratio | (Cash + receivables + near-cash assets) ÷ Current liabilities | Stricter liquidity measure excluding inventory. |
| Leverage | Debt / EBITDA | Interest-bearing debt ÷ EBITDA | Debt capacity and covenant measure. |
| Coverage | Interest coverage | EBITDA or EBIT ÷ Interest expense | Ability to service finance costs. |
| Profitability | ROE | Net profit ÷ Equity | Shareholder return indicator. |
| Profitability | ROIC | NOPAT ÷ Invested capital | Return on operating capital. |
| Efficiency | Receivable days | Trade receivables ÷ Revenue × 365 | Collection performance. |
| Efficiency | Inventory days | Inventory ÷ Cost of sales × 365 | Stockholding efficiency. |
| Efficiency | Payable days | Trade payables ÷ Cost of sales × 365 | Supplier-financing indicator. |

## Expert Appendix: Control Matrices, Work Programs, and Field Templates

### Template 1: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 2: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 3: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 4: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 5: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 6: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 7: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 8: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?



## Deep Practice Appendix: Deal and Valuation Control Pack

### A. Investment committee paper structure
A professional investment committee paper should include the strategic rationale, transaction perimeter, valuation range, base case, downside case, upside case, sources and uses, funding plan, tax assumptions, regulatory approvals, integration requirements, key risks, sensitivity analysis, decision requested and conditions precedent. Every key number should tie to a model tab, diligence report, contract, audited account or management forecast.

### B. Normalized EBITDA bridge
A normalized EBITDA bridge should separate recurring operations from one-off income, one-off costs, owner expenses, non-market related-party pricing, discontinued activities, litigation, restructuring costs, unusual bad debts, non-recurring professional fees, and timing differences. The bridge should not be treated as value evidence unless every adjustment is supported by documentation and reviewed for tax and accounting consistency.

### C. Working-capital peg file
For acquisitions, the working-capital peg file should define included and excluded accounts, reference periods, seasonality, abnormal balances, debt-like items, cash-like items, related-party balances, tax liabilities, customer advances, supplier rebates and inventory provisioning. This file often drives purchase price adjustments and should be reconciled to audited or reviewed financial information.

## References

<p id="ref1" class="ref_item">[1] aaa4uae.ae <a target="_blank" rel="noreferrer" href="https://aaa4uae.ae/fellowship-program/">https://aaa4uae.ae/fellowship-program/</a></p>
<p id="ref2" class="ref_item">[2] UAE Ministry of Finance <a target="_blank" rel="noreferrer" href="https://mof.gov.ae/federal-budget-framework-and-process/">https://mof.gov.ae/federal-budget-framework-and-process/</a></p>
<p id="ref3" class="ref_item">[3] pwc.com <a target="_blank" rel="noreferrer" href="https://www.pwc.com/m1/en/publications/documents/2024/navigating-the-sca-amendments.pdf">https://www.pwc.com/m1/en/publications/documents/2024/navigating-the-sca-amendments.pdf</a></p>
<p id="ref4" class="ref_item">[4] Central Bank of the UAE Rulebook <a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae">https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae</a></p>
<p id="ref5" class="ref_item">[5] dubailand.gov.ae <a target="_blank" rel="noreferrer" href="https://dubailand.gov.ae/media/j5wh5jay/valution-standars-en_5_7_2020.pdf">https://dubailand.gov.ae/media/j5wh5jay/valution-standars-en_5_7_2020.pdf</a></p>
<p id="ref6" class="ref_item">[6] accaglobal.com <a target="_blank" rel="noreferrer" href="https://www.accaglobal.com/middle-east/en/student/student-support-middle-east.html">https://www.accaglobal.com/middle-east/en/student/student-support-middle-east.html</a></p>
<p id="ref7" class="ref_item">[7] kpmg.com <a target="_blank" rel="noreferrer" href="https://kpmg.com/ae/en/insights/tax-insights/updated-ministerial-decision-on-audited-financial-statements.html">https://kpmg.com/ae/en/insights/tax-insights/updated-ministerial-decision-on-audited-financial-statements.html</a></p>
<p id="ref8" class="ref_item">[8] dfsa.ae <a target="_blank" rel="noreferrer" href="https://www.dfsa.ae/application/files/4015/8992/8155/20190324-DFSA-Regulatory-Reporting-Regime-1.pdf">https://www.dfsa.ae/application/files/4015/8992/8155/20190324-DFSA-Regulatory-Reporting-Regime-1.pdf</a></p>
<p id="ref9" class="ref_item">[9] en.adgm.thomsonreuters.com <a target="_blank" rel="noreferrer" href="https://en.adgm.thomsonreuters.com/rulebook/gen-62-financial-statements-and-financial-reporting-standards">https://en.adgm.thomsonreuters.com/rulebook/gen-62-financial-statements-and-financial-reporting-standards</a></p>
