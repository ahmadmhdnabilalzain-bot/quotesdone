# Audit, Assurance, Ethics, Quality Management, and the UAE Profession

This chapter treats **audit, assurance, ethics, quality management, and professional standards in the UAE** as a professional operating manual for UAE finance teams, auditors, controllers, CFOs, compliance officers, bankers, analysts, and advisors. The UAE finance environment is not a single-rule system: it combines federal law and regulators, financial free-zone rulebooks, international standards, tax authority requirements, and sector-specific supervisory expectations. The source base used for this chapter comes from the collected research packets and prioritizes official regulators and standard setters where available.

For practical work, each topic should be read through four lenses: (1) the legal or regulatory rule that creates the obligation; (2) the accounting, audit, tax, risk, or valuation standard that determines technical treatment; (3) the evidence the professional must retain; and (4) the governance owner who signs, reviews, files, or challenges the output.

Key source families for this chapter include [[1]](#ref1), [[2]](#ref2), [[3]](#ref3).

## 1. Audit and Assurance Architecture

Audit and assurance in the UAE combines Federal Decree-Law No. 41 of 2023 on the accounting and auditing profession, the Commercial Companies Law audit requirements, International Standards on Auditing, International Standards on Quality Management, the IESBA Code, regulator-specific requirements for listed and financial institutions, and specialized Sharia audit requirements for Islamic financial institutions. [[1]](#ref1)[[1]](#ref1)[[2]](#ref2)

## 2. Source Research Digest


**Research topic:** Audit and assurance standards: ISA, ISQM, IESBA ethics, UAE audit practice

**Extracted report title:** UAE Audit and Assurance Standards: Knowledge Library Shard

# UAE Audit and Assurance Standards: Knowledge Library Shard

## 1. Domain Scope
The Audit and Assurance domain in the United Arab Emirates (UAE) encompasses the legal, regulatory, and professional frameworks that govern the examination of financial records and the provision of assurance services. This domain is a cornerstone of the UAE finance knowledge library because it provides the mechanism for verifying the "true and fair view" of financial statements, which is essential for:
*   **Investor Confidence:** Ensuring the reliability of financial disclosures in the UAE's rapidly growing capital markets.
*   **Regulatory Compliance:** Meeting the stringent requirements of the Ministry of Economy, Central Bank, and financial free zone regulators (DFSA and FSRA).
*   **Market Integrity:** Preventing corporate fraud and ensuring the stability of the financial system, particularly in the banking and insurance sectors.

The scope includes the adoption of International Standards on Auditing (ISA), quality management standards (ISQM), ethical requirements (IESBA), and UAE-specific statutory mandates such as auditor rotation and joint audits.

## 2. Core Frameworks and Standards

### 2.1 Primary Legislation
*   **Federal Decree-Law No. 41/2023 on the Regulation of the Accounting and Auditing Profession:** This is the primary federal law governing the profession as of late 2023/2024, replacing the previous Federal Law No. 12 of 2014. It defines the requirements for licensing, professional conduct, and the scope of services for chartered accountants and accounting firms.
    > "The objectives of this Decree Law shall be: 1. Regulation of the accounting and auditing profession and its practice in the State. 2. Raising efficiency of the profession related services and operations... 3. Governance of accountability mechanisms for practitioners." — *Federal Decree-Law No. 41/2023, Article 2 [[4]](#ref4)
*   **Federal Decree-Law No. 32 of 2021 (Commercial Companies Law):** Mandates that every joint-stock company or limited liability company must have one or more auditors to audit its accounts annually.

### 2.2 Authoritative Standards
*   **International Standards on Auditing (ISA):** The UAE has fully adopted ISAs as issued by the International Auditing and Assurance Standards Board (IAASB).
*   **International Standards on Quality Management (ISQM 1 & 2):** These standards replaced ISQC 1. While the Emirates Association for Accountants and Auditors (EAAA) is working on federal-level implementation, they are already mandatory for auditors registered in the DIFC (DFSA) and ADGM (FSRA).
*   **IESBA Code of Ethics:** The *International Code of Ethics for Professional Accountants (including International Independence Standards)* is the benchmark for ethical behavior and independence for UAE auditors.

### 2.3 Regulators
*   **Ministry of Economy (MoE):** The federal regulator for the auditing profession in mainland UAE.
*   **Capital Markets Authority (CMA):** Effective January 1, 2026, the CMA replaced the Securities and Commodities Authority (SCA) as the regulator for listed companies and capital markets.
*   **Central Bank of the UAE (CBUAE):** Regulates auditors of banks, exchange houses, and insurance companies.
*   **Dubai Financial Services Authority (DFSA):** The independent regulator for the Dubai International Financial Centre (DIFC).
*   **Financial Services Regulatory Authority (FSRA):** The independent regulator for the Abu Dhabi Global Market (ADGM).

## 3. UAE-Specific Rules and Practical Notes

### 3.1 Auditor Registration and Licensing
Auditors in the UAE must be registered in the "Register of Practicing Auditors" maintained by the Ministry of Economy.
*   **UAECA Fellowship (UAE Chartered Accountant):** To be licensed, individuals must complete the UAE Fellowship Program, developed in collaboration with ACCA. This includes exams in:
    1.  UAE Certificate in International Financial Reporting.
    2.  UAE Certificate in International Auditing.
    3.  UAE Tax and Regulation Certificate (covering UAE-specific laws).
*   **CPE Requirements:** Registered auditors must complete at least **30 hours** of Continuing Professional Development (CPD) annually to renew their fellowship certificate. — *AAA UAE [[5]](#ref5)

### 3.2 Auditor Rotation
To maintain independence, the UAE enforces strict rotation rules for high-interest entities:
*   **Listed Companies (CMA/SCA Rules):** Audit firms must be rotated every **6 years**, with a cooling-off period of **3 years**. The audit partner must be rotated every **3 years**. — *CBUAE Rulebook, Article 3-3 [[6]](#ref6)
*   **Financial Institutions:** The Central Bank requires a procurement procedure for a new audit firm at least every 6 years.

### 3.3 Joint Audit Requirements
*   **Banks and Insurance Companies:** Under CBUAE regulations, these entities are often required to appoint **two independent auditors** (Joint Audit) to enhance the quality and reliability of the audit process.

### 3.4 Professional Indemnity Insurance
All accounting firms must maintain a valid professional indemnity insurance policy to cover potential liabilities arising from auditing errors. The Ministry of Economy recently amended policies to provide better coverage for practitioners. — *Ministry of Economy [[7]](#ref7)

## 4. Technical Content: Procedures and Checklists

### 4.1 Audit Reporting (ISA 700 Series)
Auditors in the UAE must follow the ISA 700 (Revised) format. For listed entities, the inclusion of **Key Audit Matters (KAMs)** under ISA 701 is mandatory.
*   **KAMs in UAE:** Common KAMs include valuation of investment properties (highly relevant in the UAE real estate market), impairment of financial assets (IFRS 9), and revenue recognition.

### 4.2 Quality Management (ISQM 1)
Firms must establish a System of Quality Management (SoQM) that addresses:
*   **Governance and Leadership:** The "tone at the top."
*   **Relevant Ethical Requirements:** Compliance with the IESBA Code.
*   **Acceptance and Continuance:** Rigorous vetting of clients to prevent AML/CFT risks.
*   **Engagement Performance:** Ensuring audits meet ISA requirements.

### 4.3 Audit Procedures for UAE Entities (Checklist)
1.  **Statutory Compliance:** Verify the company's trade license, Memorandum of Association (MoA), and UBO (Ultimate Beneficial Owner) register.
2.  **Tax Audit Linkage:** Ensure financial statements align with Corporate Tax filings (9% rate for taxable income > AED 375,000).
3.  **Real Estate Valuation:** For property-heavy entities, verify valuations against RERA (Dubai) or similar emirate-level standards.
4.  **Related Party Transactions:** Extensive disclosure is required under UAE law to prevent conflict of interest.

## 5. Professional Practice
Expert professionals in the UAE must manage a complex landscape where federal laws intersect with free zone regulations.
*   **Dual Licensing:** A firm may need to be registered with the MoE for mainland clients and separately with the DFSA or FSRA for free zone clients.
*   **AML/CFT Focus:** Auditors are "Designated Non-Financial Businesses and Professions" (DNFBPs) and have strict reporting obligations for suspicious transactions to the Financial Intelligence Unit (FIU).

## 6. Certification Knowledge
*   **UAECA:** The primary local qualification.
*   **International Equivalencies:** The MoE recognizes fellowships from IFAC member bodies (e.g., ACCA, ICAEW, CPA Australia, AICPA) but requires the UAE-specific fellowship modules for local licensing.
*   **IESBA Proportionality:** Small and Medium Practices (SMPs) in the UAE are encouraged to use the IESBA Proportionality Guide to apply ethics standards effectively without the overhead of large-firm systems. — *IESBA [[2]](#ref2)

## 7. Sources
*   **Federal Decree-Law No. 41/2023 [[8]](#ref8)
*   **CBUAE Rulebook (External Audit) [[9]](#ref9)
*   **AAA UAE Fellowship Program [[1]](#ref1)
*   **ACCA UAE Tax and Regulation Certificate [[10]](#ref10)
*   **DFSA Auditor Registration [[11]](#ref11)
*   **ADGM Auditor Rules [[12]](#ref12)
*   **IFAC UAE Adoption Status [[13]](#ref13)

## 8. Gaps and Verification Notes
*   **ISQM Adoption:** While mandatory in free zones, the formal federal-level "effective date" for all mainland firms is still being harmonized by the AAA and MoE as of mid-2026.
*   **CMA Rulebook:** As the CMA is a new entity (Jan 2026), practitioners should verify if specific circulars have superseded the old SCA Decision No. 3/RM of 2020 regarding governance and audit committees.
*   **Joint Audit Thresholds:** Specific asset/revenue thresholds for mandatory joint audits in the insurance sector are subject to periodic CBUAE circulars and should be verified for the current financial year.

**Checklist Status Summary:**
*   Research Checklist Path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/0101cfbd/RESEARCH_CHECKLIST.md`
*   All items marked `[Y]`.

---


## 3. Statutory Audit Workflow

### End-to-end audit file architecture

1. **Acceptance and continuance** — Independence, conflicts, competence, engagement risk, AML screening, scope, fee basis and signed engagement letter.
2. **Planning** — Materiality, performance materiality, risk assessment, fraud brainstorming, control environment, significant classes of transactions and group scope.
3. **Understanding the entity** — Legal structure, licences, business model, systems, related parties, financing, tax status and regulatory perimeter.
4. **Risk response** — Controls testing, substantive testing, sampling, confirmations, analytics, estimates, journal testing and specialist involvement.
5. **Completion** — Subsequent events, going concern, misstatement evaluation, representation letter, partner review, EQ review where applicable and audit report sign-off.
6. **Archiving** — Final assembly, retention, confidentiality, quality review evidence and restricted access.

### Audit planning measures

- **Planning materiality:** `Selected benchmark × professional percentage`. **Use:** Sets the quantitative threshold for financial statement misstatement planning.
- **Performance materiality:** `Planning materiality × risk-adjusted percentage`. **Use:** Reduces aggregation risk in audit testing.
- **Tolerable misstatement:** `Performance materiality allocated to account or population`. **Use:** Used in sampling and substantive testing.
- **Clearly trivial threshold:** `Planning materiality × small percentage`. **Use:** Threshold below which misstatements may not be accumulated.

## 4. ISA-Based Audit Area Guide

### Revenue and receivables

Audit teams should connect revenue testing to contracts, invoices, delivery evidence, customer acceptance, credit notes, subsequent receipts, VAT treatment and IFRS 15 judgments. Fraud risk should be considered where revenue targets, management incentives, cut-off pressure or unusual manual journals exist.
### Inventory and cost of sales

Inventory work should cover count attendance, cut-off, costing, slow-moving stock, net realizable value, consignment stock, goods in transit, warehouse controls, ERP access and reconciliation to cost of sales.
### Cash, banking and treasury

Bank testing should cover direct confirmations, facility letters, covenants, restricted cash, bank charges, foreign currency, trade-finance instruments, guarantees and subsequent clearance of reconciling items.
### Related parties and owners

UAE audits require careful related-party procedures because owner-managed groups, family businesses, free-zone entities, branches and director-controlled suppliers/customers may create hidden relationship and transfer-pricing risks.
## 5. ISQM 1 and Firm-Level Quality Management

The research identifies ISQM 1 and ISQM 2 as effective quality-management standards replacing the former quality-control model. A UAE audit firm should maintain quality objectives, risk assessment, governance and leadership responsibilities, ethical requirements, acceptance and continuance controls, engagement performance policies, resources, information and communication, monitoring and remediation. [[1]](#ref1)

### ISQM operating checklist

1. **Quality risk assessment** — Identify risks that could prevent the firm from achieving audit quality objectives.
2. **Ethics and independence** — Maintain declarations, restricted-entity lists, partner rotation tracking and non-audit service approvals.
3. **Engagement performance** — Document methodology, consultation rules, supervision, review, EQ review and report-release controls.
4. **Resources** — Track competence, training, workload, specialists, technology and outsourced service providers.
5. **Monitoring and remediation** — Perform cold file reviews, root-cause analysis, remediation plans and annual quality evaluation.

## 6. Ethics and Independence

The research identifies the IESBA Code of Ethics as an authoritative ethical framework, with adoption evidence in the UAE public-sector audit context. Professional accountants should apply the fundamental principles of integrity, objectivity, professional competence and due care, confidentiality, and professional behavior, while identifying threats and safeguards for independence. [[2]](#ref2)
## 7. UAE Regulator-Specific Assurance


**Research topic:** Risk management, internal control, COSO, ERM, fraud, AML/CFT and compliance

**Extracted report title:** UAE Finance Knowledge Library: Risk Management, Internal Control, and Compliance

# UAE Finance Knowledge Library: Risk Management, Internal Control, and Compliance

This research document provides a comprehensive overview of the risk management, internal control, fraud prevention, and AML/CFT landscape in the United Arab Emirates as of July 2026. It incorporates the major legislative overhauls of 2024 and 2025, including the new Federal AML Law and the updated SCA Corporate Governance Code.

## 1. Domain Scope
The domain of Risk Management, Internal Control, and Compliance is the "defensive architecture" of the UAE finance sector. It encompasses the frameworks used to identify, assess, and mitigate financial and operational risks, the systems of internal control that ensure the reliability of financial reporting, and the regulatory compliance mechanisms designed to prevent financial crimes such as money laundering, terrorism financing, and fraud.

In the UAE, this domain is critical due to the country's status as a global financial hub, which necessitates alignment with international standards (FATF, Basel, IOSCO) while addressing local legal specificities across onshore (Federal), offshore (DIFC/ADGM), and sector-specific (CBUAE/SCA) jurisdictions.

## 2. Core Frameworks and Standards

### 2.1. Anti-Money Laundering and Counter-Terrorism Financing (AML/CFT)
The UAE legal framework for AML/CFT underwent a massive transformation in late 2025.
*   **Primary Law**: **Federal Decree-Law No. 10 of 2025** Regarding Anti-Money Laundering, Combating the Financing of Terrorism, and the Financing of Proliferation (the "New AML Law"). This law repealed the 2018 legislation.
*   **Executive Regulations**: **Cabinet Resolution No. 134 of 2025**, which provides the detailed implementing rules for the New AML Law.
*   **Key Regulators**:
    *   **Executive Office for AML/CFT**: Oversees the national strategy.
    *   **Financial Intelligence Unit (FIU)**: The central agency for receiving and analyzing Suspicious Transaction Reports (STRs) via the **goAML** portal.
    *   **CBUAE, SCA, DFSA (DIFC), and FSRA (ADGM)**: Supervisory authorities for their respective sectors.

### 2.2. Internal Control and Corporate Governance
*   **SCA Corporate Governance Code**: Governs Public Joint Stock Companies (PJSCs). Significant amendments were introduced via **SCA Board Decision No. 2/RM of 2024**, mandating the adoption of global frameworks like **COSO**.
*   **CBUAE Corporate Governance Regulation for Banks**: Establishes the "Three Lines of Defense" model and requires independent risk and compliance functions.
*   **International Standards**: **COSO (2013 Internal Control / 2017 ERM)** and **ISO 31000:2018** are the preferred frameworks for risk management and internal control in the UAE.

## 3. UAE-Specific Rules and Practical Notes

### 3.1. The "New AML Law" (Law 10 of 2025) Highlights
The 2025 law introduced several "firsts" for the UAE:
*   **Proliferation Financing (PF)**: Expressly included in the legal framework to align with FATF standards.
*   **Objective Test for Knowledge**: Liability now arises if a person "actually knew or it would have been reasonable for them to have known" about the illicit nature of funds (White & Case, ). [[14]](#ref14)
*   **Virtual Assets**: Directly regulated under the framework, with strict licensing for Virtual Asset Service Providers (VASPs).
*   **Personal Liability for Managers**: Managers can be held criminally liable if a violation occurs due to a breach of their employment duties (LinkedIn, ). [[15]](#ref15)

### 3.2. Internal Control Mandates (SCA 2024 Amendments)
*   **COSO Preference**: The SCA now explicitly prefers the **COSO** framework for internal control and risk management systems in PJSCs (KPMG, ). [[16]](#ref16)
*   **Separation of Functions**: Prohibits the merging of the Compliance Officer and Internal Audit roles.
*   **External Audit Opinion**: External auditors are now increasingly required to issue a separate report opining on the effectiveness of the company's internal control and risk management framework.

### 3.3. Fraud and Financial Crime (Penal Code 2021)
*   **Federal Decree-Law No. 31 of 2021** (UAE Penal Code) defines core financial crimes:
    *   **Article 451 (Fraud)**: Using fraudulent means or a false name/capacity to deceive a victim and obtain property.
    *   **Article 453 (Breach of Trust/Embezzlement)**: Misappropriating or misusing property entrusted to a person (Chambers, ). [[17]](#ref17)
    *   **Bribery (Articles 275-286)**: Strictly prohibits public and private sector bribery, including "facilitation payments."

## 4. Technical Content: Penalties and Procedures

### 4.1. AML/CFT Penalty Matrix (Law 10 of 2025)
> "Legal persons can face fines between AED 5 million and AED 100 million, or amounts linked to the criminal property, and may be dissolved or closed." — ProactUAE [[18]](#ref18)

| Offence Type | Individual Penalty (2025 Law) | Corporate Penalty (2025 Law) |
| :--- | :--- | :--- |
| **Money Laundering** | 1-10 years prison + Fine up to AED 5M or property value | AED 5M - 100M fine |
| **Aggravated ML** | Temporary imprisonment + Fine AED 1M - 10M | Higher of AED 10M or 2x property value |
| **Tipping Off** | Prison (min 1 year) + Fine AED 100k - 500k | N/A |
| **Failure to Report** | Prison and/or Fine AED 50k - 300k | Administrative fines up to AED 5M |

### 4.2. Reporting Procedures (goAML)
*   **STR (Suspicious Transaction Report)**: Filed for completed transactions where suspicion exists.
*   **SAR (Suspicious Activity Report)**: Filed for *attempted* transactions or suspicious behavior where no transaction occurred (GRC Advisors, ). [[19]](#ref19)
*   **Timeline**: Reports must be filed "immediately" upon the formation of suspicion. In practice, regulators expect filing within 24-48 hours of the internal MLRO decision.

### 4.3. Bankruptcy and Liability (Law 51 of 2023)
The new Bankruptcy Law (effective May 2024) introduced **Article 244**, which extends liability to **de facto managers** if they were negligent in managing the company leading to its financial distress (Al Tamimi, ). [[20]](#ref20)

## 5. Professional Practice

### 5.1

## 8. Professional Qualification and Licensing Map


**Research topic:** Professional certifications and competency map: CPA, ACCA, CMA, CFA, CIA, CISA, FRM, CA, DipIFR and UAE finance career pathways

**Extracted report title:** Professional Certifications and UAE Finance Career Pathways

# Professional Certifications and UAE Finance Career Pathways

This research shard details the professional certification landscape and career progression frameworks for finance, accounting, and auditing professionals in the United Arab Emirates (UAE) as of July 2026. It covers the national qualification (UAECA), international certifications (CPA, ACCA, CFA, etc.), and the regulatory requirements for auditors and tax agents.

## Domain Scope
The professional certifications and competency domain encompasses the formal qualifications, licensing requirements, and career development structures that define the finance profession in the UAE. This domain is critical to the finance knowledge library as it establishes the standards for professional entry, the legal right to practice (especially in audit and tax), and the alignment of local talent with international benchmarks (IFRS, ISA). It bridges the gap between academic education and professional practice in a market characterized by a high concentration of international financial hubs (DIFC, ADGM) and a robust nationalization drive (Nafis).

## Core Frameworks and Standards
The UAE finance profession is governed by a mix of federal laws and international standards:
- **Federal Decree-Law No. 12 of 2014 (and its Executive Regulations):** Regulates the profession of auditors in the UAE, establishing the Ministry of Economy (MoE) as the primary regulator.
- **Cabinet Resolution No. 74 of 2023:** Details the eligibility criteria for Tax Agents under the Federal Tax Authority (FTA).
- **International Standards:** The UAE mandates **International Financial Reporting Standards (IFRS)** for accounting and **International Standards on Auditing (ISA)** for audit, as overseen by the Accountants and Auditors Association (AAA) UAE, an IFAC member.
- **Joint Examination Scheme (JES):** A strategic partnership between the AAA and ACCA that forms the basis of the national UAECA qualification.

## UAE-Specific Rules and Licensing

### 1. UAE Chartered Accountant (UAECA) & AAA Fellowship
The UAECA is the national professional qualification, implemented through a partnership between the Accountants and Auditors Association (AAA) and ACCA.
- **Structure:** Based on the ACCA qualification but co-branded with AAA. Members of ACCA in the UAE are eligible for dual membership as UAECA.
- **Fellowship Program:** Required for registration as a practicing auditor with the Ministry of Economy.
- **Exam Requirements:** Depending on the candidate's background (7 defined cases), they must pass up to three exams:
  - **International Accounting (IFRS):** Nature of IASB, revenue, assets, financial instruments.
  - **International Auditing (ISA):** Documentation, fraud, planning, reporting.
  - **UAE Legislation & Taxation:** Legal system, free zones, VAT, Corporate Tax.
- **Exemptions:** Holders of fellowships from AICPA (USA), ICAEW (UK), ACCA (UK), CPA Canada, CAANZ (Australia/NZ), and SOCPA (Saudi Arabia) are exempt from IFRS and ISA exams but **must** pass the UAE Legislation & Taxation exam.
- **Fees:** Annual fellowship membership fee is **AED 1,050**. Exam fees are approximately **£310** for IFRS/ISA and **£430** for UAE Tax.
- **Source:** AAA UAE Fellowship Program [[1]](#ref1)

### 2. Ministry of Economy (MoE) Auditor Registration
To practice as an auditor for mainland companies, individuals must be registered in the MoE's Practicing Auditors Register.
- **Experience:** Minimum **5 years** of practical auditing experience after obtaining a bachelor's degree.
- **Education:** Bachelor's in accounting or a related field with at least **15 credit hours** of approved accounting courses.
- **Licensing Fee:** **AED 4,500** for a three-year registration.
- **National Participation:** For auditing firms, the national participation rate must not be less than **25%** of the capital, and one partner must be a UAE citizen.
- **Source:** MoE Professional License - Chartered Accountant [[3]](#ref3)

### 3. FTA Tax Agent Registration
The Federal Tax Authority (FTA) regulates the registration of Tax Agents who assist taxable persons with their obligations.
- **Requirements:**
  - Bachelor’s or Master’s degree in tax, accounting, or law (or a recognized international tax certificate if the degree is in another field).
  - **3 years** of recent professional experience in tax, accounting, or law.
  - Proficiency in both Arabic and English.
  - Passing the FTA’s Tax Agent examination.
- **Fees:** **AED 3,000** for registration (renewable every 3 years).
- **Source:** FTA Tax Agent Registration [[21]](#ref21)

## Technical Content: Certification Competency Maps (2026)

### CPA (Certified Public Accountant - US)
The 2026 CPA Evolution model focuses on a core + discipline structure.
- **Core Sections:** Financial Accounting and Reporting (FAR), Auditing and Attestation (AUD), and Taxation and Regulation (REG).
- **FAR 2026 Weighting:** Financial Reporting (30–40%), Balance Sheet Accounts (30–40%), Transactions (25–35%), and State/Local Governments (5–15%).
- **Source:** Zell Education CPA FAR Syllabus 2026 [[22]](#ref22)

### ACCA (Association of Chartered Certified Accountants)
- **Competency Framework:** Covers 10 areas including Financial & Management Accounting, Audit & Assurance, Tax, Governance, Risk & Control, and Data Analytics.
- **UAE Context:** Operates under the Joint Examination Scheme (JES) with AAA. All exams in the UAE are co-branded.
- **Source:** ACCA Middle East Student Support [[23]](#ref23)

### CFA (Certified Financial Analyst)
- **2026 Updates:** Minimal changes to Level I; Level II removed one Learning Outcome Statement (LOS).
- **Focus:** Ethical and Professional Standards (15–20% at Level I), Quantitative Methods, Economics, Financial Statement Analysis, and Portfolio Management.
- **Source:** CFA Institute Curriculum Updates [[24]](#ref24)

### CIA (Certified Internal Auditor)
- **2025/2026 Syllabus:** Part 3 (Business Knowledge) now emphasizes Internal Audit Operations (25%) and Engagement Results/Monitoring (45%), with a shift toward practical application of the Global Internal Audit Standards.
- **Source:** IIA CIA Exam Syllabus [[25]](#ref25)

### FRM (Financial Risk Manager)
- **2026 Syllabus:** Part I remains stable (Foundations, Quantitative Analysis, Financial Markets, Valuation). Part II has major updates in Market, Credit, and Operational Risk, including new readings on AI and model validation.
- **Source:** GARP FRM Study Materials [[26]](#ref26)

## Professional Practice and Career Pathways

### 1. Financial Free Zones (DIFC & ADGM)
- **DIFC (Dubai International Financial Centre):** Regulated by the DFSA. Focuses on investment banking, asset management, and fintech. Career paths often require CFA or specialized compliance certifications.
- **ADGM (Abu Dhabi Global Market):** Regulated by the FSRA. Known for its "Financial Compliance Pathways" program in collaboration with the ADGM Academy to develop national talent in compliance and risk.
- **Source:** ADGM Academy Financial Compliance Pathways [[27]](#ref27)

### 2. The "Big 4" and Audit Firms
- **Pathways:** Graduate programs typically require candidates to pursue ACCA, ICAEW, or CPA.
- **UAE Requirement:** Senior auditors and partners must obtain the AAA Fellowship and MoE registration to sign off on mainland audits.
- **Source:** Securing an Audit Licence in the UAE [[28]](#ref28)

### 3. Public Sector and Nationalization (Nafis)
- The **Nafis** program (Emirati Talent Competitiveness Council) provides salary subsidies and training support for UAE nationals entering the private finance sector.
- **Competency Focus:** Strong emphasis on UAECA and professional certifications to ensure local talent meets international standards.

## Gaps and Verification Notes
- **[Verify]** The exact passing score for the FTA Tax Agent exam in 2026; while requirements are listed, the specific "pass mark" percentage is often subject to internal FTA policy updates.
- **[Not Found]** Specific 2026 fee updates for 

## Expert Appendix: Control Matrices, Work Programs, and Field Templates

### Template 1: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 2: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 3: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 4: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 5: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 6: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 7: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 8: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Certification exemption verification note
Some secondary sources in the research suggested that ICAI (India) and ICAP (Pakistan) holders may be exempt from IFRS/ISA exams for the AAA Fellowship; the source packet flags this as a conflict and indicates that primary AAA documentation should be checked before relying on any automatic exemption. Treat this as **[verify before reliance]** for candidates and employers.

## References

<p id="ref1" class="ref_item">[1] aaa4uae.ae <a target="_blank" rel="noreferrer" href="https://aaa4uae.ae/fellowship-program/">https://aaa4uae.ae/fellowship-program/</a></p>
<p id="ref2" class="ref_item">[2] ethicsboard.org <a target="_blank" rel="noreferrer" href="https://www.ethicsboard.org/news-events/2026-05/iesba-releases-guide-proportionality-iesba-code*">https://www.ethicsboard.org/news-events/2026-05/iesba-releases-guide-proportionality-iesba-code*</a></p>
<p id="ref3" class="ref_item">[3] moet.gov.ae <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/en/w/request-to-register-natural-persons-in-the-practicing-auditors-register">https://www.moet.gov.ae/en/w/request-to-register-natural-persons-in-the-practicing-auditors-register</a></p>
<p id="ref4" class="ref_item">[4] moet.gov.ae <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/documents/20121/0/Federal+Decree+Law+No.+%2841%29+of+2023.pdf*">https://www.moet.gov.ae/documents/20121/0/Federal+Decree+Law+No.+%2841%29+of+2023.pdf*</a></p>
<p id="ref5" class="ref_item">[5] aaa4uae.ae <a target="_blank" rel="noreferrer" href="https://aaa4uae.ae/fellowship-program/*">https://aaa4uae.ae/fellowship-program/*</a></p>
<p id="ref6" class="ref_item">[6] Central Bank of the UAE Rulebook <a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/article-3-external-audit-1*">https://rulebook.centralbank.ae/en/rulebook/article-3-external-audit-1*</a></p>
<p id="ref7" class="ref_item">[7] moet.gov.ae <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/en/-/ministry-of-economy-announces-amendments-to-insurance-policies-against-liabilities-from-auditing-mistakes*">https://www.moet.gov.ae/en/-/ministry-of-economy-announces-amendments-to-insurance-policies-against-liabilities-from-auditing-mistakes*</a></p>
<p id="ref8" class="ref_item">[8] moet.gov.ae <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/documents/20121/0/Federal+Decree+Law+No.+%2841%29+of+2023.pdf">https://www.moet.gov.ae/documents/20121/0/Federal+Decree+Law+No.+%2841%29+of+2023.pdf</a></p>
<p id="ref9" class="ref_item">[9] Central Bank of the UAE Rulebook <a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/article-3-external-audit-1">https://rulebook.centralbank.ae/en/rulebook/article-3-external-audit-1</a></p>
<p id="ref10" class="ref_item">[10] accaglobal.com <a target="_blank" rel="noreferrer" href="https://www.accaglobal.com/us/en/qualifications/glance/UAE-Tax-and-Regulation-Certificate1.html">https://www.accaglobal.com/us/en/qualifications/glance/UAE-Tax-and-Regulation-Certificate1.html</a></p>
<p id="ref11" class="ref_item">[11] dfsa.ae <a target="_blank" rel="noreferrer" href="https://www.dfsa.ae/what-we-do/supervision/audit-supervision/auditor-registration">https://www.dfsa.ae/what-we-do/supervision/audit-supervision/auditor-registration</a></p>
<p id="ref12" class="ref_item">[12] en.adgm.thomsonreuters.com <a target="_blank" rel="noreferrer" href="https://en.adgm.thomsonreuters.com/rulebook/10-criteria-registration">https://en.adgm.thomsonreuters.com/rulebook/10-criteria-registration</a></p>
<p id="ref13" class="ref_item">[13] ifac.org <a target="_blank" rel="noreferrer" href="https://www.ifac.org/about-ifac/membership/members/united-arab-emirates-accountants-and-auditors-association">https://www.ifac.org/about-ifac/membership/members/united-arab-emirates-accountants-and-auditors-association</a></p>
<p id="ref14" class="ref_item">[14] whitecase.com <a target="_blank" rel="noreferrer" href="https://www.whitecase.com/insight-alert/uae-enacts-new-aml-law-what-are-key-changes-and-what-does-mean-your-business">https://www.whitecase.com/insight-alert/uae-enacts-new-aml-law-what-are-key-changes-and-what-does-mean-your-business</a></p>
<p id="ref15" class="ref_item">[15] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/key-changes-uaes-federal-decree-law-10-2025-amluae-vwqqf">https://www.linkedin.com/pulse/key-changes-uaes-federal-decree-law-10-2025-amluae-vwqqf</a></p>
<p id="ref16" class="ref_item">[16] KPMG <a target="_blank" rel="noreferrer" href="https://assets.kpmg.com/content/dam/kpmg/ae/pdf-2024/09/amendments-to-sca-governance-code.pdf">https://assets.kpmg.com/content/dam/kpmg/ae/pdf-2024/09/amendments-to-sca-governance-code.pdf</a></p>
<p id="ref17" class="ref_item">[17] chambers.com <a target="_blank" rel="noreferrer" href="https://chambers.com/articles/how-to-handle-breach-of-trust-cases-in-dubai-expert-guide-from-a-lawyer-in-uae">https://chambers.com/articles/how-to-handle-breach-of-trust-cases-in-dubai-expert-guide-from-a-lawyer-in-uae</a></p>
<p id="ref18" class="ref_item">[18] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/uae-amlcft-law-federal-decree-law-10-2025-guide-proactuae-mjsof">https://www.linkedin.com/pulse/uae-amlcft-law-federal-decree-law-10-2025-guide-proactuae-mjsof</a></p>
<p id="ref19" class="ref_item">[19] grcadvisors.ae <a target="_blank" rel="noreferrer" href="https://grcadvisors.ae/suspicious-activity-report/">https://grcadvisors.ae/suspicious-activity-report/</a></p>
<p id="ref20" class="ref_item">[20] tamimi.com <a target="_blank" rel="noreferrer" href="https://www.tamimi.com/news/overview-of-uaes-new-financial-restructuring-and-bankruptcy-legislation-2/">https://www.tamimi.com/news/overview-of-uaes-new-financial-restructuring-and-bankruptcy-legislation-2/</a></p>
<p id="ref21" class="ref_item">[21] tax.gov.ae <a target="_blank" rel="noreferrer" href="https://tax.gov.ae/en/services/registration.of.tax.agents.aspx">https://tax.gov.ae/en/services/registration.of.tax.agents.aspx</a></p>
<p id="ref22" class="ref_item">[22] zelleducation.com <a target="_blank" rel="noreferrer" href="https://www.zelleducation.com/blog/cpa-far-syllabus-2026/">https://www.zelleducation.com/blog/cpa-far-syllabus-2026/</a></p>
<p id="ref23" class="ref_item">[23] accaglobal.com <a target="_blank" rel="noreferrer" href="https://www.accaglobal.com/middle-east/en/student/student-support-middle-east.html">https://www.accaglobal.com/middle-east/en/student/student-support-middle-east.html</a></p>
<p id="ref24" class="ref_item">[24] cfainstitute.org <a target="_blank" rel="noreferrer" href="https://www.cfainstitute.org/about/press-room/2026/cfa-institute-announces-updates-to-cfa-program-curriculum">https://www.cfainstitute.org/about/press-room/2026/cfa-institute-announces-updates-to-cfa-program-curriculum</a></p>
<p id="ref25" class="ref_item">[25] theiia.org <a target="_blank" rel="noreferrer" href="https://www.theiia.org/en/certifications/cia/exam-prep-resources/exam-syllabus/">https://www.theiia.org/en/certifications/cia/exam-prep-resources/exam-syllabus/</a></p>
<p id="ref26" class="ref_item">[26] garp.org <a target="_blank" rel="noreferrer" href="https://www.garp.org/frm/study-materials">https://www.garp.org/frm/study-materials</a></p>
<p id="ref27" class="ref_item">[27] instagram.com <a target="_blank" rel="noreferrer" href="https://www.instagram.com/p/DVdloU2Ar3L/">https://www.instagram.com/p/DVdloU2Ar3L/</a></p>
<p id="ref28" class="ref_item">[28] rakez.com <a target="_blank" rel="noreferrer" href="https://rakez.com/en/Blog/Details/Article/178/securing-an-audit-licence-in-the-united-arab-emirates">https://rakez.com/en/Blog/Details/Article/178/securing-an-audit-licence-in-the-united-arab-emirates</a></p>
