# UAE Finance Knowledge Library

Generated as a UAE-focused professional finance, accounting, auditing, tax, governance, banking, markets, Islamic finance, FP&A, public finance and career reference library.

## Files

- `00_Master_Index_and_Source_Map.md` — 11,143 characters
- `01_Financial_Reporting_IFRS_and_Accounting.md` — 39,093 characters
- `02_UAE_Tax_VAT_Transfer_Pricing_and_ESR.md` — 35,063 characters
- `03_Audit_Assurance_Ethics_and_Professional_Standards.md` — 50,788 characters
- `04_Corporate_Finance_Valuation_MA_and_Restructuring.md` — 37,166 characters
- `05_Banking_Treasury_Capital_Markets_and_Islamic_Finance.md` — 46,432 characters
- `06_Risk_Internal_Control_AML_Governance_and_Compliance.md` — 33,430 characters
- `07_Management_Accounting_FPandA_Public_Finance_and_Careers.md` — 51,911 characters

Total Markdown characters: 305,026
