# Management Accounting, FP&A, Public Finance, Government Accounting, and Finance Careers

This chapter treats **management accounting, FP&A, public finance, government accounting, and UAE finance careers** as a professional operating manual for UAE finance teams, auditors, controllers, CFOs, compliance officers, bankers, analysts, and advisors. The UAE finance environment is not a single-rule system: it combines federal law and regulators, financial free-zone rulebooks, international standards, tax authority requirements, and sector-specific supervisory expectations. The source base used for this chapter comes from the collected research packets and prioritizes official regulators and standard setters where available.

For practical work, each topic should be read through four lenses: (1) the legal or regulatory rule that creates the obligation; (2) the accounting, audit, tax, risk, or valuation standard that determines technical treatment; (3) the evidence the professional must retain; and (4) the governance owner who signs, reviews, files, or challenges the output.

Key source families for this chapter include [[1]](#ref1), [[2]](#ref2), [[3]](#ref3).

## 1. Management Accounting and FP&A Scope

Management accounting and FP&A translate strategy into budgets, forecasts, pricing, cost control, variance analysis, investment decisions and performance dashboards. In the UAE, the research connects this discipline to federal budgeting, Corporate Tax, transfer pricing, real estate escrow accounting, public finance, sovereign wealth funds and professional career pathways. [[1]](#ref1)[[2]](#ref2)

## 2. Source Research Digest — FP&A


**Research topic:** Management accounting, budgeting, forecasting, costing and FP&A

**Extracted report title:** Management Accounting, Budgeting, Forecasting, Costing, and FP&A in the UAE

# Management Accounting, Budgeting, Forecasting, Costing, and FP&A in the UAE

This research report covers the management accounting and Financial Planning & Analysis (FP&A) landscape in the United Arab Emirates (UAE) as of July 2026. It focuses on the transition to new international standards (IFRS 18), the integration of federal tax regimes (Corporate Tax, VAT), and the specific regulatory requirements for budgeting and reporting in both federal and private sectors.

## 1. Domain Scope
Management accounting and FP&A in the UAE encompass the internal processes used by organizations to plan, budget, forecast, and control costs to support strategic decision-making. This domain is critical to the UAE finance library because:
*   **Fiscal Transformation**: The UAE has transitioned from a tax-free environment to a sophisticated fiscal regime (VAT in 2018, Corporate Tax in 2023), requiring advanced management accounting for tax optimization and compliance.
*   **Economic Diversification**: As the UAE moves toward a non-oil economy, FP&A is the primary tool for resource allocation in high-growth sectors like technology, renewable energy, and tourism.
*   **Regulatory Maturity**: Regulators like the DFSA (DIFC) and FSRA (ADGM) mandate rigorous prudential reporting and internal controls that rely on management accounting frameworks.

## 2. Core Frameworks and Standards
The UAE does not have a unique national Management Accounting GAAP; instead, it relies on international frameworks and specific federal laws.

### Primary Frameworks
*   **IFRS 18 (Presentation and Disclosure in Financial Statements)**: Replacing IAS 1, this standard is effective January 1, 2027, but requires 2026 comparative data. It introduces mandatory "Operating Profit" subtotals and "Management Performance Measures" (MPMs) which directly impact how UAE firms report internal performance to external stakeholders.
    > "IFRS 18 requires new defined subtotals in the statement of profit or loss... and requires companies to disclose information about management-defined performance measures (MPMs)." — IFRS Foundation [[4]](#ref4)
*   **IMA (Institute of Management Accountants) & CIMA (Chartered Institute of Management Accountants)**: These bodies provide the professional standards (e.g., Global Management Accounting Principles) widely adopted by UAE-based CFOs and controllers.
*   **Ministerial Decision No. 114/2023**: Mandates the use of IFRS or IFRS for SMEs for calculating taxable income under the Corporate Tax Law, effectively standardizing the "base" for management accounting.
    > "According to this decision, only IFRS and IFRS for SMEs are acceptable for financial reporting purposes in calculating taxable income." — Middle East Briefing [[5]](#ref5)

## 3. UAE-Specific Rules and Practical Notes

### Corporate Tax (CT) and FP&A
The UAE Corporate Tax (9% on income > AED 375,000) has transformed budgeting from a "pre-tax" to a "post-tax" exercise.
*   **Transfer Pricing (TP)**: Firms with revenue ≥ AED 200 million must maintain a Local File and Master File. FP&A teams must now model inter-company transactions at "Arm's Length" to avoid FTA penalties.
    > "A taxable person is required to maintain a master file and local file where... the taxable person has revenue of AED 200 million or more." — Chambers & Partners [[6]](#ref6)
*   **Realisation Basis**: Management accountants can elect to account for gains/losses on a realisation basis for tax purposes, requiring separate tracking of unrealized fair value movements in internal reports.

### Federal Budgeting Process
The UAE Federal Government operates on a multi-year strategic budget cycle (currently 2027–2029).
*   **Participatory Budgeting**: Federal entities must submit annual estimates by the end of the third month of the fiscal year (March) following a circular from the Ministry of Finance.
*   **Zero-Based vs. Incremental**: While many private firms use incremental budgeting, the federal government has moved toward performance-based budgeting linked to Key Performance Indicators (KPIs).

### Emiratization (Nafis) Impact
The Nafis program requires private sector companies (50+ employees) to increase Emirati workforce representation by 2% annually.
*   **Budgeting for Fines**: Non-compliance results in monthly fines starting at AED 6,000 per unmet position, increasing annually. FP&A teams must include these as "contingent liabilities" or "operating expenses" in 2026 budgets.
    > "Non-compliance results in monthly fines starting from AED 6,000 per unmet Emirati position, increasing yearly." — LinkedIn (Nafis Guide) [[7]](#ref7)

## 4. Technical Content: Concepts and Procedures

### Management Performance Measures (MPMs) under IFRS 18
UAE firms must now reconcile MPMs (e.g., "Adjusted EBITDA") to the nearest IFRS subtotal (Operating Profit).
*   **Formula for Operating Profit (IFRS 18)**: `Revenue - Cost of Sales - Distribution Costs - Administrative Expenses - Other Operating Income/Expenses`.
*   **MPM Reconciliation Table**:
    | Measure | Adjustment | IFRS Subtotal |
    | :--- | :--- | :--- |
    | Adjusted Operating Profit | Add back: Restructuring Costs | Operating Profit |
    | Underlying EBITDA | Add back: Depr/Amort + One-offs | Operating Profit |

### Costing in Construction and Manufacturing
Given the UAE's infrastructure focus, **Job Costing** and **Contract Costing** (IFRS 15) are dominant.
*   **VAT Impact on Costing**: VAT is generally recoverable (input tax), but cash flow timing (filing periods) must be modeled in project budgets to avoid liquidity gaps.
*   **Standard Costing**: Used in manufacturing (e.g., aluminum, petrochemicals) to manage variance against high energy and labor costs.

## 5. Professional Practice
*   **CFO Role Evolution**: In 2026, UAE CFOs are focused on "Tax-Aware FP&A." This involves integrating Corporate Tax impact into every investment appraisal (NPV/IRR calculations).
*   **Automation**: Due to IFRS 18 and CT requirements, manual spreadsheets are being replaced by ERP-integrated EPM (Enterprise Performance Management) tools to handle "disaggregation" requirements.
*   **Free Zone Nuances**: Firms in the DIFC or ADGM must follow specific prudential rules (e.g., PIB module in DFSA) which require management accountants to monitor capital adequacy and liquidity ratios daily.

## 6. Certification and Competencies
*   **UAE Chartered Accountant (UAECA)**: Offered by the Accountants and Auditors Association (AAA), this is the local benchmark, often paired with ACCA or ICAEW.
*   **CMA (Certified Management Accountant)**: Highly valued for FP&A roles in the UAE, particularly for its focus on decision support and cost management.
*   **AAA-ACCA Partnership**: A strategic alliance to develop the national profession, allowing ACCA members to obtain UAE audit and accounting rights after local law assessments.

## Sources
*   **IFRS Foundation**: IFRS 18 Effects Analysis (April 2024). [[4]](#ref4)
*   **UAE Ministry of Finance**: Federal Budget Framework. [[1]](#ref1)
*   **Middle East Briefing**: Accounting Standards in the UAE. [[5]](#ref5)
*   **Chambers & Partners**: UAE Transfer Pricing 2026 Guide. [[6]](#ref6)
*   **PwC Viewpoint**: IFRS 18 Insights for Financial Services. [[8]](#ref8)
*   **LinkedIn (Tehmina Aziz)**: IFRS 18 Key Changes for UAE. [[9]](#ref9)
*   **Nafis Program (LinkedIn Guide)**: Emiratisation Quotas 2026. [[7]](#ref7)

## Gaps and Verification Notes
*   **Federal Budget Procedures Manual**: The full internal manual is not publicly available; only high-level circulars and participatory process descriptions are accessible.
*   **Specific Costing Formulas**: Industry-specific standard costs (e.g., per ton of aluminum) are proprietary and vary by firm; research focused on the *methodology* (Standard Costing) rather than specific values.
*   **IFRS 18 Implementation**: As the standard is not yet effective (2027), current "MPM" examples are based on early-adopter guidance and transition reports rather than final 2027 filings.

**Checklist Status**:
*   Checklist Path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/f909b636/RESEARCH_CHECKLIST.md`
*   All items marked `[Y]`.

---


## 3. Source Research Digest — Public Finance


**Research topic:** Public sector finance, government accounting, procurement, grants and sovereign wealth in UAE

**Extracted report title:** Public sector finance, government accounting, procurement, grants and sovereign wealth in UAE

### UAE Public Sector Finance, Government Accounting, Procurement, Grants, and Sovereign Wealth

This research report provides a comprehensive overview of the public sector finance domain in the United Arab Emirates (UAE), focusing on federal frameworks, accounting standards, procurement regulations, and the governance of sovereign wealth funds as of July 2026.

---

#### 1. Domain Scope
Public sector finance in the UAE encompasses the management of federal and local government revenues, expenditures, and assets. It is a foundational pillar of the UAE's "We the UAE 2031" vision, aiming to create a globally competitive and sustainable economy. This domain governs how public funds are collected (taxes, oil revenues, investment returns), allocated (federal budget), and spent (procurement, grants), while ensuring transparency through rigorous accounting and auditing standards.

#### 2. Core Frameworks and Standards
The UAE's public finance system is governed by a hierarchy of federal laws and international standards:

*   **Primary Legislation**:
    *   **Federal Decree-Law No. 26 of 2019 on Public Finance**: The cornerstone of federal financial management, defining the budget cycle, revenue collection, and expenditure controls.
    *   **Federal Decree-Law No. 11 of 2023 on Procurement**: Regulates the acquisition of goods and services by federal entities, emphasizing digital transformation and transparency.
*   **Accounting Standards**:
    *   **Federal Government Accrual Accounting Standards (FGAAS)**: These standards are directly aligned with the **International Public Sector Accounting Standards (IPSAS)**. The UAE transitioned from a modified cash basis to full accrual accounting in 2021-2022 to enhance asset management and financial transparency.
    *   **Unified Chart of Accounts**: A standardized classification system used by all federal entities to ensure consistency in financial reporting.
*   **Regulators and Oversight**:
    *   **Ministry of Finance (MoF)**: Responsible for federal budgeting, financial policy, and the implementation of FGAAS.
    *   **State Audit Institution (SAI)**: The supreme audit authority, mandated by Federal Law No. 8 of 2011 to audit federal entities and ensure the integrity of public funds.

#### 3. UAE-Specific Rules and Practical Notes
*   **Accrual Accounting Implementation**: The "Manual of Federal Government Accrual Accounting Standards" (updated October 2025) provides the technical roadmap for federal entities.
    > "The Ministry of Finance launched a comprehensive and integrated program to convert the Federal Government’s accounting framework from modified cash basis to accrual basis... to identify, maintain and monitor all Federal Government’s assets and evaluate and monitor all Federal liabilities." — Lexis Middle East [[10]](#ref10)
*   **Digital Procurement Platform**: All federal procurement must be conducted through the centralized Digital Procurement Platform. This system automates the entire lifecycle from tendering to contract management and payment.
*   **SME Preference**: Under Federal Law No. 2 of 2014 and the 2023 Procurement Law, federal entities are encouraged to allocate a portion of their procurement spend to Small and Medium Enterprises (SMEs).
*   **Treasury Single Account (TSA)**: All federal revenues are consolidated into a TSA managed by the MoF to optimize liquidity management and oversight.

#### 4. Technical Content: Budgeting, Procurement, and Grants

##### A. Federal Budget Cycle
The UAE uses a multi-year budgeting approach (typically 5 years) to ensure long-term fiscal planning.
*   **Preparation**: MoF issues a circular to federal entities to submit their budget proposals based on strategic priorities.
*   **Approval**: The Cabinet reviews the draft budget, which is then ratified by the Federal National Council (FNC) and the Federal Supreme Council.
*   **2026 Budget**: The 2026 Federal Budget was themed "Investing in the Human to Ensure a Prosperous Future," with significant allocations for social development, health, and education (MoF, 2026).

##### B. Procurement Methods (Decree-Law No. 11 of 2023)
| Method | Description | Application |
| :--- | :--- | :--- |
| **Public Tender** | Open to all qualified suppliers via the Digital Procurement Platform. | Default method for most procurements. |
| **Restricted Tender** | Invitation-only for a pre-qualified list of suppliers. | Used for specialized or technical requirements. |
| **Direct Order** | Direct negotiation with a single supplier. | Reserved for emergencies or unique proprietary items. |

##### C. Sovereign Wealth Funds (SWFs)
The UAE manages several of the world's largest SWFs, each with distinct mandates:
*   **Emirates Investment Authority (EIA)**: The sole federal SWF, mandated to invest federal government funds to create long-term value.
    > "EIA is mandated to strategically invest funds allocated by the Federal Government to create long-term value for the UAE and contribute to the future prosperity." — EIA [[11]](#ref11)
*   **Abu Dhabi Investment Authority (ADIA)**: Focuses on long-term capital preservation and growth through a globally diversified portfolio.
*   **Mubadala Investment Company**: A strategic investment arm of Abu Dhabi, focusing on economic diversification and high-impact sectors like AI, energy transition, and healthcare.
    > "Assets under management grew 17% in 2025 to AED 1.4 trillion (US$385 billion), with annualized five- and ten-year returns exceeding 10%." — Mubadala [[12]](#ref12)
*   **ADQ**: An Abu Dhabi-based holding company with a portfolio of major enterprises in energy, food, and logistics.
*   **Investment Corporation of Dubai (ICD)**: The principal investment arm of the Government of Dubai.

#### 5. Professional Practice
Finance professionals in the UAE public sector must navigate a landscape of rapid digital and regulatory change.
*   **IPSAS Compliance**: Accountants must ensure that financial statements reflect the fair value of assets and liabilities, a significant shift from the previous cash-based focus on budget execution.
*   **Audit Readiness**: With the SAI's enhanced powers, federal entities must maintain rigorous documentation and internal controls, particularly regarding procurement and grant disbursements.
*   **Digital Proficiency**: Mastery of the Digital Procurement Platform and the MoF's Unified Financial System is mandatory for operational roles.

#### 6. Certification Knowledge
*   **IPSAS Certification**: Highly valued for public sector accountants; often supported by the MoF through training programs with ACCA.
*   **CIPFA (Chartered Institute of Public Finance and Accountancy)**: The global standard for public sector financial management.
*   **CPA/ACCA/CA**: Standard professional accounting qualifications remain the baseline for senior financial roles.

#### 7. Source Links
*   [Federal Decree-Law No. 11 of 2023 on Procurement]() [[13]](#ref13)
*   [Federal Decree-Law No. 26 of 2019 on Public Finance]() [[14]](#ref14)
*   [Mubadala 2025 Annual Results]() [[12]](#ref12)
*   [Emirates Investment Authority Governance]() [[15]](#ref15)
*   [Manual of Federal Government Accrual Accounting Standards (FGAAS)]() [[10]](#ref10)

#### 8. Gaps and Verification Notes
*   **Threshold Specifics**: While the 2023 Procurement Law outlines methods, the specific financial thresholds (e.g., the AED limit for direct orders) are often set in the **Executive Regulations (Cabinet Resolution No. 122 of 2024)** and subsequent ministerial circulars, which require periodic verification.
*   **Local vs. Federal**: This report focuses on the Federal level. Local governments (Abu Dhabi, Dubai, etc.) have their own specific procurement laws and accounting manuals (e.g., Abu Dhabi's Law No. 1 of 2017 on Financial System of Abu Dhabi Government).
*   **Grant Manuals**: Detailed internal manuals for grant administration are often not public; however, high-level policies are governed by the Public Finance Law.

---
**Checklist Status Summary**:
- Checklist Path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/c3dfb910/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---


## 4. Source Research Digest — Careers and Certifications


**Research topic:** Professional certifications and competency map: CPA, ACCA, CMA, CFA, CIA, CISA, FRM, CA, DipIFR and UAE finance career pathways

**Extracted report title:** Professional Certifications and UAE Finance Career Pathways

# Professional Certifications and UAE Finance Career Pathways

This research shard details the professional certification landscape and career progression frameworks for finance, accounting, and auditing professionals in the United Arab Emirates (UAE) as of July 2026. It covers the national qualification (UAECA), international certifications (CPA, ACCA, CFA, etc.), and the regulatory requirements for auditors and tax agents.

## Domain Scope
The professional certifications and competency domain encompasses the formal qualifications, licensing requirements, and career development structures that define the finance profession in the UAE. This domain is critical to the finance knowledge library as it establishes the standards for professional entry, the legal right to practice (especially in audit and tax), and the alignment of local talent with international benchmarks (IFRS, ISA). It bridges the gap between academic education and professional practice in a market characterized by a high concentration of international financial hubs (DIFC, ADGM) and a robust nationalization drive (Nafis).

## Core Frameworks and Standards
The UAE finance profession is governed by a mix of federal laws and international standards:
- **Federal Decree-Law No. 12 of 2014 (and its Executive Regulations):** Regulates the profession of auditors in the UAE, establishing the Ministry of Economy (MoE) as the primary regulator.
- **Cabinet Resolution No. 74 of 2023:** Details the eligibility criteria for Tax Agents under the Federal Tax Authority (FTA).
- **International Standards:** The UAE mandates **International Financial Reporting Standards (IFRS)** for accounting and **International Standards on Auditing (ISA)** for audit, as overseen by the Accountants and Auditors Association (AAA) UAE, an IFAC member.
- **Joint Examination Scheme (JES):** A strategic partnership between the AAA and ACCA that forms the basis of the national UAECA qualification.

## UAE-Specific Rules and Licensing

### 1. UAE Chartered Accountant (UAECA) & AAA Fellowship
The UAECA is the national professional qualification, implemented through a partnership between the Accountants and Auditors Association (AAA) and ACCA.
- **Structure:** Based on the ACCA qualification but co-branded with AAA. Members of ACCA in the UAE are eligible for dual membership as UAECA.
- **Fellowship Program:** Required for registration as a practicing auditor with the Ministry of Economy.
- **Exam Requirements:** Depending on the candidate's background (7 defined cases), they must pass up to three exams:
  - **International Accounting (IFRS):** Nature of IASB, revenue, assets, financial instruments.
  - **International Auditing (ISA):** Documentation, fraud, planning, reporting.
  - **UAE Legislation & Taxation:** Legal system, free zones, VAT, Corporate Tax.
- **Exemptions:** Holders of fellowships from AICPA (USA), ICAEW (UK), ACCA (UK), CPA Canada, CAANZ (Australia/NZ), and SOCPA (Saudi Arabia) are exempt from IFRS and ISA exams but **must** pass the UAE Legislation & Taxation exam.
- **Fees:** Annual fellowship membership fee is **AED 1,050**. Exam fees are approximately **£310** for IFRS/ISA and **£430** for UAE Tax.
- **Source:** AAA UAE Fellowship Program [[2]](#ref2)

### 2. Ministry of Economy (MoE) Auditor Registration
To practice as an auditor for mainland companies, individuals must be registered in the MoE's Practicing Auditors Register.
- **Experience:** Minimum **5 years** of practical auditing experience after obtaining a bachelor's degree.
- **Education:** Bachelor's in accounting or a related field with at least **15 credit hours** of approved accounting courses.
- **Licensing Fee:** **AED 4,500** for a three-year registration.
- **National Participation:** For auditing firms, the national participation rate must not be less than **25%** of the capital, and one partner must be a UAE citizen.
- **Source:** MoE Professional License - Chartered Accountant [[3]](#ref3)

### 3. FTA Tax Agent Registration
The Federal Tax Authority (FTA) regulates the registration of Tax Agents who assist taxable persons with their obligations.
- **Requirements:**
  - Bachelor’s or Master’s degree in tax, accounting, or law (or a recognized international tax certificate if the degree is in another field).
  - **3 years** of recent professional experience in tax, accounting, or law.
  - Proficiency in both Arabic and English.
  - Passing the FTA’s Tax Agent examination.
- **Fees:** **AED 3,000** for registration (renewable every 3 years).
- **Source:** FTA Tax Agent Registration [[16]](#ref16)

## Technical Content: Certification Competency Maps (2026)

### CPA (Certified Public Accountant - US)
The 2026 CPA Evolution model focuses on a core + discipline structure.
- **Core Sections:** Financial Accounting and Reporting (FAR), Auditing and Attestation (AUD), and Taxation and Regulation (REG).
- **FAR 2026 Weighting:** Financial Reporting (30–40%), Balance Sheet Accounts (30–40%), Transactions (25–35%), and State/Local Governments (5–15%).
- **Source:** Zell Education CPA FAR Syllabus 2026 [[17]](#ref17)

### ACCA (Association of Chartered Certified Accountants)
- **Competency Framework:** Covers 10 areas including Financial & Management Accounting, Audit & Assurance, Tax, Governance, Risk & Control, and Data Analytics.
- **UAE Context:** Operates under the Joint Examination Scheme (JES) with AAA. All exams in the UAE are co-branded.
- **Source:** ACCA Middle East Student Support [[18]](#ref18)

### CFA (Certified Financial Analyst)
- **2026 Updates:** Minimal changes to Level I; Level II removed one Learning Outcome Statement (LOS).
- **Focus:** Ethical and Professional Standards (15–20% at Level I), Quantitative Methods, Economics, Financial Statement Analysis, and Portfolio Management.
- **Source:** CFA Institute Curriculum Updates [[19]](#ref19)

### CIA (Certified Internal Auditor)
- **2025/2026 Syllabus:** Part 3 (Business Knowledge) now emphasizes Internal Audit Operations (25%) and Engagement Results/Monitoring (45%), with a shift toward practical application of the Global Internal Audit Standards.
- **Source:** IIA CIA Exam Syllabus [[20]](#ref20)

### FRM (Financial Risk Manager)
- **2026 Syllabus:** Part I remains stable (Foundations, Quantitative Analysis, Financial Markets, Valuation). Part II has major updates in Market, Credit, and Operational Risk, including new readings on AI and model validation.
- **Source:** GARP FRM Study Materials [[21]](#ref21)

## Professional Practice and Career Pathways

### 1. Financial Free Zones (DIFC & ADGM)
- **DIFC (Dubai International Financial Centre):** Regulated by the DFSA. Focuses on investment banking, asset management, and fintech. Career paths often require CFA or specialized compliance certifications.
- **ADGM (Abu Dhabi Global Market):** Regulated by the FSRA. Known for its "Financial Compliance Pathways" program in collaboration with the ADGM Academy to develop national talent in compliance and risk.
- **Source:** ADGM Academy Financial Compliance Pathways [[22]](#ref22)

### 2. The "Big 4" and Audit Firms
- **Pathways:** Graduate programs typically require candidates to pursue ACCA, ICAEW, or CPA.
- **UAE Requirement:** Senior auditors and partners must obtain the AAA Fellowship and MoE registration to sign off on mainland audits.
- **Source:** Securing an Audit Licence in the UAE [[23]](#ref23)

### 3. Public Sector and Nationalization (Nafis)
- The **Nafis** program (Emirati Talent Competitiveness Council) provides salary subsidies and training support for UAE nationals entering the private finance sector.
- **Competency Focus:** Strong emphasis on UAECA and professional certifications to ensure local talent meets international standards.

## Gaps and Verification Notes
- **[Verify]** The exact passing score for the FTA Tax Agent exam in 2026; while requirements are listed, the specific "pass mark" percentage is often subject to internal FTA policy updates.
- **[Not Found]** Specific 2026 fee updates for ADGM/DIFC individual practitioner registrations; these are typically updated in annual fee schedules not yet fully indexed in public search for 2026.
- **[Conflict]** Some secondary sources suggest ICAI (India) and ICAP (Pakistan) holders are exempt from IFRS/ISA exams for the AAA Fellowship; however, primary AAA documentation (Case 7) indicates that while they are IFAC members, they do not currently hold the same "automatic exemption" status as the six primary bodies (AICPA, ICAEW, etc.) and may need to sit all three exams unless a specific MRA (Mutual Recognition Agreement) is active.

## Sources
1. **AAA UAE Fellowship Program [[2]](#ref2)
2. **Ministry of Economy (MoE) Auditor Registration [[3]](#ref3)
3. **Federal Tax Authority (FTA) Tax Agent Registration [[16]](#ref16)
4. **ACCA Middle East Student Support [[18]](#ref18)
5. **CFA Institute 2026 Curriculum Updates [[19]](#ref19)
6. **IIA CIA Exam Syllabus [[20]](#ref20)
7. **GARP FRM 2026 Learning Objectives [[21]](#ref21)
8. **Zell Education CPA FAR 2026 Guide [[17]](#ref17)
9. **RAKEZ Audit Licence Guide [[23]](#ref23)

**Checklist Status:**
- Runtime checklist path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/148003d1/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---


### Management accounting and FP&A formulas

- **Budget variance:** `Actual result - Budgeted result`. **Use:** Measures deviation from plan.
- **Variance percentage:** `Variance ÷ Budgeted result`. **Use:** Normalizes variance by budget size.
- **Contribution margin:** `Sales - Variable costs`. **Use:** Product, customer and channel profitability measure.
- **Contribution margin ratio:** `Contribution margin ÷ Sales`. **Use:** Pricing and break-even analysis.
- **Break-even sales units:** `Fixed costs ÷ Contribution margin per unit`. **Use:** Volume needed to cover fixed costs.
- **Operating leverage:** `Contribution margin ÷ Operating profit`. **Use:** Sensitivity of operating profit to revenue changes.
- **Rolling forecast update:** `Actuals to date + Forecast for remaining period`. **Use:** Dynamic forecast rather than fixed annual plan.

### FP&A monthly cycle checklist

1. **Close coordination** — Confirm accounting close timetable, accruals, revenue cut-off, cost allocations and management adjustments.
2. **Variance analysis** — Explain price, volume, mix, rate, efficiency, FX, timing and one-off variances.
3. **Forecast refresh** — Update sales pipeline, staffing, capex, working capital, financing, tax and cash assumptions.
4. **Business partnering** — Meet department heads and convert operational drivers into financial forecasts.
5. **Management pack** — Prepare executive summary, KPI dashboard, P&L, balance sheet, cash flow, risks, opportunities and decisions needed.

## 5. Public Finance and Government Accounting

The research identifies Federal Decree-Law No. 26 of 2019 on Public Finance, the federal fiscal year from January 1 to December 31, a 2026 federal budget, Federal Government Accrual Accounting Standards aligned with IPSAS, Federal Decree-Law No. 11 of 2023 on procurement, the UAE Accountability Authority and sovereign wealth-fund structures. [[1]](#ref1)

### Public finance control checklist

1. **Budget preparation** — Align requests with strategic priorities, expenditure ceilings, revenue forecasts and MoF circulars.
2. **Commitment control** — Monitor purchase commitments, budget availability, approvals, contract milestones and payment timing.
3. **Accrual accounting** — Recognize assets, liabilities, revenues and expenses based on accrual principles and retain asset registers.
4. **Procurement compliance** — Use approved procurement methods, evaluation records, conflict declarations and award documentation.
5. **Audit readiness** — Maintain evidence for financial, compliance and performance audit by accountability bodies.

## 6. Certification and Career Pathway Map

| Pathway | Representative credentials | UAE finance use |
| --- | --- | --- |
| Financial reporting / audit | ACCA, CPA, CA, DipIFR, UAECA | IFRS, audit, tax, ethics and statutory reporting roles. |
| Management accounting / FP&A | CMA, CIMA-style competencies, FP&A credentials | Budgeting, costing, performance management and decision support. |
| Investment / valuation | CFA, valuation credentials, RICS for real estate valuation | Portfolio analysis, corporate finance, valuation and capital markets. |
| Risk / internal audit | CIA, CISA, FRM | Internal audit, controls, IT audit, risk management and compliance. |
| Islamic finance | AAOIFI-related credentials and Sharia governance training | Islamic banking, takaful, sukuk and Sharia audit support. |

## 7. Competency Framework for UAE Finance Leaders

| Competency | Detailed capability | Typical role |
| --- | --- | --- |
| Technical accounting | IFRS, consolidation, financial instruments, leases, tax accounting and disclosures. | Controller, finance manager, audit manager. |
| Tax and regulation | CT, VAT, TP, ESR/Pillar Two, regulator reporting and governance. | Tax manager, CFO, compliance finance lead. |
| Commercial finance | Pricing, margins, customer profitability, capex, working capital and forecasting. | FP&A manager, business finance partner. |
| Risk and control | ICFR, AML awareness, fraud risk, internal audit and governance reporting. | Risk manager, internal auditor, CFO. |
| Markets and treasury | Banking, trade finance, liquidity, FX, capital markets and investments. | Treasurer, corporate finance manager. |
| Leadership | Ethics, communication, board reporting, team development and strategic decision support. | CFO, finance director, partner. |

## Expert Appendix: Control Matrices, Work Programs, and Field Templates

### Template 1: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 2: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 3: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 4: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 5: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 6: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 7: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 8: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


## References

<p id="ref1" class="ref_item">[1] UAE Ministry of Finance <a target="_blank" rel="noreferrer" href="https://mof.gov.ae/federal-budget-framework-and-process/">https://mof.gov.ae/federal-budget-framework-and-process/</a></p>
<p id="ref2" class="ref_item">[2] aaa4uae.ae <a target="_blank" rel="noreferrer" href="https://aaa4uae.ae/fellowship-program/">https://aaa4uae.ae/fellowship-program/</a></p>
<p id="ref3" class="ref_item">[3] moet.gov.ae <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/en/w/request-to-register-natural-persons-in-the-practicing-auditors-register">https://www.moet.gov.ae/en/w/request-to-register-natural-persons-in-the-practicing-auditors-register</a></p>
<p id="ref4" class="ref_item">[4] ifrs.org <a target="_blank" rel="noreferrer" href="https://www.ifrs.org/content/dam/ifrs/publications/amendments/english/2024/effect-analysis-ifrs18-april2024.pdf">https://www.ifrs.org/content/dam/ifrs/publications/amendments/english/2024/effect-analysis-ifrs18-april2024.pdf</a></p>
<p id="ref5" class="ref_item">[5] middleeastbriefing.com <a target="_blank" rel="noreferrer" href="https://www.middleeastbriefing.com/doing-business-guide/uae/taxation-and-accounting/accounting-standards-uae">https://www.middleeastbriefing.com/doing-business-guide/uae/taxation-and-accounting/accounting-standards-uae</a></p>
<p id="ref6" class="ref_item">[6] practiceguides.chambers.com <a target="_blank" rel="noreferrer" href="https://practiceguides.chambers.com/practice-guides/transfer-pricing-2026/uae/trends-and-developments/O24969">https://practiceguides.chambers.com/practice-guides/transfer-pricing-2026/uae/trends-and-developments/O24969</a></p>
<p id="ref7" class="ref_item">[7] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/delicatesoft_emiratisation-nafis-quotas-2026-a-complete-activity-7462752391789109249-7iO2">https://www.linkedin.com/posts/delicatesoft_emiratisation-nafis-quotas-2026-a-complete-activity-7462752391789109249-7iO2</a></p>
<p id="ref8" class="ref_item">[8] viewpoint.pwc.com <a target="_blank" rel="noreferrer" href="https://viewpoint.pwc.com/dt/gx/en/pwc/in_briefs/in_briefs_INT/in_briefs_INT/ifrs18insights.html">https://viewpoint.pwc.com/dt/gx/en/pwc/in_briefs/in_briefs_INT/in_briefs_INT/ifrs18insights.html</a></p>
<p id="ref9" class="ref_item">[9] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/tehmina-aziz_ifrs18-ifrsuae-corporatetaxuae-activity-7374381899009478656-bIW2">https://www.linkedin.com/posts/tehmina-aziz_ifrs18-ifrsuae-corporatetaxuae-activity-7374381899009478656-bIW2</a></p>
<p id="ref10" class="ref_item">[10] lexismiddleeast.com <a target="_blank" rel="noreferrer" href="https://www.lexismiddleeast.com/regulatory/UnitedArabEmirates/UAEMinistryFinance_Manual_of_Federal_Government_Accrual_Accounting_Standards/en">https://www.lexismiddleeast.com/regulatory/UnitedArabEmirates/UAEMinistryFinance_Manual_of_Federal_Government_Accrual_Accounting_Standards/en</a></p>
<p id="ref11" class="ref_item">[11] eia.gov.ae <a target="_blank" rel="noreferrer" href="https://www.eia.gov.ae/">https://www.eia.gov.ae/</a></p>
<p id="ref12" class="ref_item">[12] mubadala.com <a target="_blank" rel="noreferrer" href="https://www.mubadala.com/en/news/strong-performance-by-uae-portfolio-drives-mubadalas-growth-in-2025">https://www.mubadala.com/en/news/strong-performance-by-uae-portfolio-drives-mubadalas-growth-in-2025</a></p>
<p id="ref13" class="ref_item">[13] UAE Ministry of Finance <a target="_blank" rel="noreferrer" href="https://mof.gov.ae/wp-content/uploads/2024/01/Federal-Law-No.-11-of-2023-on-Procurements-in-the-Federal-Government.pdf">https://mof.gov.ae/wp-content/uploads/2024/01/Federal-Law-No.-11-of-2023-on-Procurements-in-the-Federal-Government.pdf</a></p>
<p id="ref14" class="ref_item">[14] UAE Ministry of Finance <a target="_blank" rel="noreferrer" href="https://mof.gov.ae/wp-content/uploads/2023/08/FEDERAL-DECRETAL-LAW-NO-26-OF-2019-ON-PUBLIC-FINANCIAL-MANAGEMENT.pdf">https://mof.gov.ae/wp-content/uploads/2023/08/FEDERAL-DECRETAL-LAW-NO-26-OF-2019-ON-PUBLIC-FINANCIAL-MANAGEMENT.pdf</a></p>
<p id="ref15" class="ref_item">[15] eia.gov.ae <a target="_blank" rel="noreferrer" href="https://www.eia.gov.ae/governance/">https://www.eia.gov.ae/governance/</a></p>
<p id="ref16" class="ref_item">[16] tax.gov.ae <a target="_blank" rel="noreferrer" href="https://tax.gov.ae/en/services/registration.of.tax.agents.aspx">https://tax.gov.ae/en/services/registration.of.tax.agents.aspx</a></p>
<p id="ref17" class="ref_item">[17] zelleducation.com <a target="_blank" rel="noreferrer" href="https://www.zelleducation.com/blog/cpa-far-syllabus-2026/">https://www.zelleducation.com/blog/cpa-far-syllabus-2026/</a></p>
<p id="ref18" class="ref_item">[18] accaglobal.com <a target="_blank" rel="noreferrer" href="https://www.accaglobal.com/middle-east/en/student/student-support-middle-east.html">https://www.accaglobal.com/middle-east/en/student/student-support-middle-east.html</a></p>
<p id="ref19" class="ref_item">[19] cfainstitute.org <a target="_blank" rel="noreferrer" href="https://www.cfainstitute.org/about/press-room/2026/cfa-institute-announces-updates-to-cfa-program-curriculum">https://www.cfainstitute.org/about/press-room/2026/cfa-institute-announces-updates-to-cfa-program-curriculum</a></p>
<p id="ref20" class="ref_item">[20] theiia.org <a target="_blank" rel="noreferrer" href="https://www.theiia.org/en/certifications/cia/exam-prep-resources/exam-syllabus/">https://www.theiia.org/en/certifications/cia/exam-prep-resources/exam-syllabus/</a></p>
<p id="ref21" class="ref_item">[21] garp.org <a target="_blank" rel="noreferrer" href="https://www.garp.org/frm/study-materials">https://www.garp.org/frm/study-materials</a></p>
<p id="ref22" class="ref_item">[22] instagram.com <a target="_blank" rel="noreferrer" href="https://www.instagram.com/p/DVdloU2Ar3L/">https://www.instagram.com/p/DVdloU2Ar3L/</a></p>
<p id="ref23" class="ref_item">[23] rakez.com <a target="_blank" rel="noreferrer" href="https://rakez.com/en/Blog/Details/Article/178/securing-an-audit-licence-in-the-united-arab-emirates">https://rakez.com/en/Blog/Details/Article/178/securing-an-audit-licence-in-the-united-arab-emirates</a></p>
