# UAE Corporate Tax, VAT, Excise, Transfer Pricing, ESR, and Pillar Two

This chapter treats **UAE tax, VAT, excise, transfer pricing, ESR, and Pillar Two** as a professional operating manual for UAE finance teams, auditors, controllers, CFOs, compliance officers, bankers, analysts, and advisors. The UAE finance environment is not a single-rule system: it combines federal law and regulators, financial free-zone rulebooks, international standards, tax authority requirements, and sector-specific supervisory expectations. The source base used for this chapter comes from the collected research packets and prioritizes official regulators and standard setters where available.

For practical work, each topic should be read through four lenses: (1) the legal or regulatory rule that creates the obligation; (2) the accounting, audit, tax, risk, or valuation standard that determines technical treatment; (3) the evidence the professional must retain; and (4) the governance owner who signs, reviews, files, or challenges the output.

Key source families for this chapter include [[1]](#ref1), [[2]](#ref2), [[3]](#ref3).

## 1. UAE Tax System Overview

The UAE tax system now includes federal Corporate Tax, VAT, Excise Tax, transfer-pricing documentation, tax-procedure rules, and a Pillar Two Domestic Minimum Top-up Tax framework for large multinational groups. The research base identifies the Federal Tax Authority and Ministry of Finance as the core tax institutions, with official and professional guidance forming the practical compliance base. [[1]](#ref1)

## 2. Source Research Digest


**Research topic:** UAE corporate tax, VAT, excise tax, transfer pricing and ESR

**Extracted report title:** UAE corporate tax, VAT, excise tax, transfer pricing and ESR

This research shard covers the UAE's primary tax and regulatory frameworks as of July 2026, focusing on Corporate Tax, VAT, Excise Tax, Transfer Pricing, and Economic Substance Regulations (ESR).

### 1. Domain Scope
This domain encompasses the direct and indirect tax landscape of the UAE, which has undergone significant transformation since 2023. It is a critical component of the finance knowledge library as it dictates the compliance, reporting, and financial planning requirements for all business entities operating within the UAE mainland and Free Zones.

### 2. Core Frameworks and Standards
*   **Corporate Tax (CT):** Federal Decree-Law No. 47 of 2022 on the Taxation of Corporations and Businesses.
*   **Value Added Tax (VAT):** Federal Decree-Law No. 8 of 2017, significantly amended by Federal Decree-Law No. 16 of 2025 (effective Jan 1, 2026).
*   **Excise Tax:** Federal Decree-Law No. 7 of 2017, with rates updated by Cabinet Decision No. 197 of 2025.
*   **Transfer Pricing (TP):** Integrated into the CT Law (Articles 34 & 55) and detailed in Ministerial Decision No. 97 of 2023.
*   **Economic Substance (ESR):** Cabinet Decision No. 57 of 2020, amended by Cabinet Decision No. 98 of 2024.
*   **Regulators:** Federal Tax Authority (FTA) and the Ministry of Finance (MoF).

### 3. UAE-Specific Rules and Technical Content

#### Corporate Tax (CT)
*   **Standard Rate:** 9% on Taxable Income exceeding AED 375,000. 0% on income up to this threshold.
*   **Free Zones:** Qualifying Free Zone Persons (QFZP) can benefit from a 0% rate on "Qualifying Income."
*   **Qualifying Income:** Includes income from transactions with other Free Zone Persons and income from "Qualifying Activities" (e.g., manufacturing, logistics, fund management) as per Ministerial Decision No. 265 of 2023.
*   **Small Business Relief:** The research identifies Small Business Relief for resident persons with revenue below AED 3 million for the period ending 31 December 2026; as of July 2026 this should be treated as an active but time-limited relief that needs confirmation before year-end planning.

#### Value Added Tax (VAT) - 2026 Amendments
*   **Effective Date:** January 1, 2026 (Federal Decree-Law No. 16 of 2025).
*   **Self-Invoicing:** The requirement for taxable persons to issue a self-invoice under the Reverse Charge Mechanism (RCM) is removed. Documentation like supplier invoices and contracts now suffices.
*   **Statute of Limitations:** A strict 5-year limit is introduced for refund claims and the use of excess input tax credit.
*   **Input VAT Recovery:** FTA must deny recovery if a supply is part of a fraudulent chain.

#### Excise Tax - 2026 Tiered System
*   **Sweetened Drinks:** Shifted from a flat 50% to a tiered volumetric rate based on sugar content (Cabinet Decision No. 197 of 2025):
    *   < 5g sugar/100ml: AED 0 per litre.
    *   5g to < 8g sugar/100ml: AED 0.79 per litre.
    *   ≥ 8g sugar/100ml: AED 1.09 per litre.
*   **Tobacco & Energy Drinks:** Remain at 100%.

#### Transfer Pricing (TP)
*   **Documentation Thresholds:** Taxable persons must maintain a Master File and Local File if:
    1.  Revenue in the relevant tax period is ≥ AED 200 million; OR
    2.  They are part of a Multi-National Entitity (MNE) Group with consolidated revenue ≥ AED 3.15 billion.
*   **Arm's Length Principle:** Applies to all transactions with Related Parties and Connected Persons, regardless of the documentation threshold.

#### Economic Substance Regulations (ESR)
*   **Cancellation:** Cabinet Decision No. 98 of 2024 cancelled ESR filing requirements for financial years starting on or after January 1, 2023.
*   **Reasoning:** The introduction of Corporate Tax effectively manages substance requirements, particularly for Free Zone entities seeking the 0% rate.
*   **Historical Compliance:** ESR remains applicable for the period Jan 1, 2019, to Dec 31, 2022.

### 4. Professional Practice and Certification
*   **Tax Agent Certification:** Professionals must be FTA-certified. Requirements include a Bachelor's/Master's in tax, accounting, or law, 3 years of relevant experience, and passing the FTA Tax Agent exam.
*   **Compliance Cycle:** Finance professionals now manage an integrated cycle of monthly/quarterly VAT returns, annual CT returns (within 9 months of year-end), and TP disclosure forms.

### 5. Sources
*   **UAE Ministry of Finance (MoF):** [Corporate Tax Law PDF]() [[4]](#ref4)
*   **Federal Tax Authority (FTA):** [Legislation Portal]() [[5]](#ref5)
*   **KPMG:** [VAT 2026 Amendments Summary]() [[6]](#ref6)
*   **PwC:** [ESR Cancellation Update]() [[7]](#ref7)
*   **Deloitte:** [TP Documentation Thresholds]() [[8]](#ref8)

### 6. Checklist Status
All items in the `RESEARCH_CHECKLIST.md` have been addressed and marked as `[Y]`. No major gaps were identified, though the practical implementation of the 2026 VAT and Excise changes will require monitoring as the effective date approaches.

---


## 3. Corporate Tax Professional Manual

### Rate and relief architecture

| Area | Rule / implication | Source |
| --- | --- | --- |
| Taxable income up to AED 375,000 | 0% rate identified in the research packet. | [[2]](#ref2) |
| Taxable income above AED 375,000 | 9% standard UAE Corporate Tax rate identified in the research packet. | [[2]](#ref2) |
| Small Business Relief | Available where resident taxable person revenue does not exceed AED 3,000,000, with the research noting temporary availability until 31 December 2026. | [[2]](#ref2) |
| DMTT / Pillar Two | Applies to in-scope MNE groups meeting the EUR 750 million consolidated revenue threshold; intended to ensure a 15% minimum effective tax rate in the UAE. | [[9]](#ref9) |

### Corporate Tax return preparation checklist

1. **Entity classification** — Confirm resident/non-resident status, juridical/natural person treatment, exempt-person status and free-zone position.
2. **Revenue threshold review** — Test Small Business Relief and financial statement standard thresholds using complete revenue data.
3. **Accounting profit bridge** — Start with accounting profit, then list permanent differences, temporary differences, disallowed expenses, exempt income and relief claims.
4. **Interest limitation** — Identify net interest expense, adjusted EBITDA, de minimis thresholds, related-party financing and exempt financing arrangements.
5. **Group relief and restructuring** — Document qualifying group ownership, asset/liability transfers, business restructuring relief and clawback periods.
6. **Related-party transactions** — Prepare related-party and connected-person schedules, TP method selection and documentation status.
7. **Filing evidence** — Retain returns, elections, calculations, board approvals, tax invoices, accounting records and FTA correspondence.

## 4. Transfer Pricing and Related-Party Governance


**Research topic:** Management accounting, budgeting, forecasting, costing and FP&A

**Extracted report title:** Management Accounting, Budgeting, Forecasting, Costing, and FP&A in the UAE

# Management Accounting, Budgeting, Forecasting, Costing, and FP&A in the UAE

This research report covers the management accounting and Financial Planning & Analysis (FP&A) landscape in the United Arab Emirates (UAE) as of July 2026. It focuses on the transition to new international standards (IFRS 18), the integration of federal tax regimes (Corporate Tax, VAT), and the specific regulatory requirements for budgeting and reporting in both federal and private sectors.

## 1. Domain Scope
Management accounting and FP&A in the UAE encompass the internal processes used by organizations to plan, budget, forecast, and control costs to support strategic decision-making. This domain is critical to the UAE finance library because:
*   **Fiscal Transformation**: The UAE has transitioned from a tax-free environment to a sophisticated fiscal regime (VAT in 2018, Corporate Tax in 2023), requiring advanced management accounting for tax optimization and compliance.
*   **Economic Diversification**: As the UAE moves toward a non-oil economy, FP&A is the primary tool for resource allocation in high-growth sectors like technology, renewable energy, and tourism.
*   **Regulatory Maturity**: Regulators like the DFSA (DIFC) and FSRA (ADGM) mandate rigorous prudential reporting and internal controls that rely on management accounting frameworks.

## 2. Core Frameworks and Standards
The UAE does not have a unique national Management Accounting GAAP; instead, it relies on international frameworks and specific federal laws.

### Primary Frameworks
*   **IFRS 18 (Presentation and Disclosure in Financial Statements)**: Replacing IAS 1, this standard is effective January 1, 2027, but requires 2026 comparative data. It introduces mandatory "Operating Profit" subtotals and "Management Performance Measures" (MPMs) which directly impact how UAE firms report internal performance to external stakeholders.
    > "IFRS 18 requires new defined subtotals in the statement of profit or loss... and requires companies to disclose information about management-defined performance measures (MPMs)." — IFRS Foundation [[10]](#ref10)
*   **IMA (Institute of Management Accountants) & CIMA (Chartered Institute of Management Accountants)**: These bodies provide the professional standards (e.g., Global Management Accounting Principles) widely adopted by UAE-based CFOs and controllers.
*   **Ministerial Decision No. 114/2023**: Mandates the use of IFRS or IFRS for SMEs for calculating taxable income under the Corporate Tax Law, effectively standardizing the "base" for management accounting.
    > "According to this decision, only IFRS and IFRS for SMEs are acceptable for financial reporting purposes in calculating taxable income." — Middle East Briefing [[11]](#ref11)

## 3. UAE-Specific Rules and Practical Notes

### Corporate Tax (CT) and FP&A
The UAE Corporate Tax (9% on income > AED 375,000) has transformed budgeting from a "pre-tax" to a "post-tax" exercise.
*   **Transfer Pricing (TP)**: Firms with revenue ≥ AED 200 million must maintain a Local File and Master File. FP&A teams must now model inter-company transactions at "Arm's Length" to avoid FTA penalties.
    > "A taxable person is required to maintain a master file and local file where... the taxable person has revenue of AED 200 million or more." — Chambers & Partners [[12]](#ref12)
*   **Realisation Basis**: Management accountants can elect to account for gains/losses on a realisation basis for tax purposes, requiring separate tracking of unrealized fair value movements in internal reports.

### Federal Budgeting Process
The UAE Federal Government operates on a multi-year strategic budget cycle (currently 2027–2029).
*   **Participatory Budgeting**: Federal entities must submit annual estimates by the end of the third month of the fiscal year (March) following a circular from the Ministry of Finance.
*   **Zero-Based vs. Incremental**: While many private firms use incremental budgeting, the federal government has moved toward performance-based budgeting linked to Key Performance Indicators (KPIs).

### Emiratization (Nafis) Impact
The Nafis program requires private sector companies (50+ employees) to increase Emirati workforce representation by 2% annually.
*   **Budgeting for Fines**: Non-compliance results in monthly fines starting at AED 6,000 per unmet position, increasing annually. FP&A teams must include these as "contingent liabilities"

The UAE transfer-pricing process should be operated as a finance-control cycle, not as a once-a-year tax appendage. The controller should maintain a related-party register, legal agreements, intercompany invoices, service benefit evidence, benchmarking files, management-fee allocations, loan agreements, guarantees, royalty calculations and board approval minutes.
### Tax and transfer-pricing working formulas

- **Taxable income bridge:** `Accounting profit + disallowable expenses - exempt income ± timing differences ± relief adjustments`. **Use:** Core tax return reconciliation.
- **Effective tax rate:** `Tax expense ÷ Accounting profit before tax`. **Use:** High-level review of current/deferred tax and Pillar Two exposure.
- **Related-party markup:** `(Intercompany charge - Cost base) ÷ Cost base`. **Use:** Tests cost-plus service arrangements.
- **Interest coverage:** `EBITDA ÷ Net interest expense`. **Use:** Financing risk and interest limitation review.
- **VAT payable:** `Output VAT - Recoverable input VAT ± adjustments`. **Use:** VAT return control.

## 5. VAT and Excise Tax Operating Manual

VAT compliance should be built around supply classification, place of supply, time of supply, tax invoice controls, input-tax recovery, blocked or partial recovery, reverse charge, imports, exports, credit notes and refund windows. The research identifies 2026 VAT amendments and reverse-charge refinements, including documentation requirements rather than self-invoicing in certain reverse-charge scenarios. [[13]](#ref13)

### VAT control checklist

1. **Master data** — Tag customers, suppliers, countries, TRNs, registration status, VAT groups and free-zone records.
2. **Sales controls** — Validate tax invoices, taxable/exempt/zero-rated treatment, export evidence and credit notes.
3. **Purchase controls** — Check supplier TRN, tax invoice validity, business purpose, blocked input tax and reverse-charge treatment.
4. **Return reconciliation** — Tie VAT return boxes to GL accounts, sales ledger, purchase ledger, customs import records and adjustments.
5. **Refund support** — Retain source evidence for refund windows, credit balances and FTA queries.

## 6. ESR, Pillar Two and International Tax Governance

The research notes the transition of Economic Substance Regulations and the development of Pillar Two rules for large multinational groups. A UAE finance team should maintain a matrix of activities, revenues, employees, premises, board decisions, outsourcing, substance evidence, CbCR status, DMTT status, and group reporting packs. [[9]](#ref9)
## 7. Tax Risk Register

| Risk | Effect | Control response |
| --- | --- | --- |
| Missed CT registration or filing | Late filings, penalties and blocked tax-good-standing evidence. | Maintain a tax calendar owned by finance and reviewed by CFO. |
| Unsupported free-zone treatment | Qualifying-income analysis is incomplete or not tied to contracts and customer location. | Prepare a transaction-level free-zone analysis file. |
| Weak TP evidence | Management fees, royalties, loans or recharges lack benefit evidence or benchmarking. | Use signed agreements, service logs and benchmarking support. |
| VAT invoice errors | TRN, place of supply, tax amount or invoice format errors. | Automate invoice validation and reconcile VAT codes monthly. |
| Pillar Two blind spot | Large groups miss UAE DMTT reporting timelines and data requirements. | Coordinate with group tax and maintain jurisdictional data packs. |

## Expert Appendix: Control Matrices, Work Programs, and Field Templates

### Template 1: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 2: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 3: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 4: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 5: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 6: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 7: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 8: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?



## Deep Practice Appendix: UAE Tax Governance Binder

### A. Tax calendar and accountability matrix
A UAE tax calendar should list every registration, return, election, payment, refund request, disclosure, documentation request and renewal. Each obligation should have an owner, reviewer, due date, evidence location, escalation route and status. The calendar should cover Corporate Tax, VAT, Excise Tax, transfer pricing, ESR transition files, Pillar Two monitoring where relevant, and regulator correspondence.

### B. Transaction tax coding controls
Finance teams should maintain a tax coding matrix for sales, purchases, imports, exports, recharges, employee expenses, director fees, related-party transactions, exempt supplies, zero-rated supplies, reverse-charge items and blocked input tax. The matrix should be approved by tax leadership and embedded in the accounting system to reduce manual judgment at invoice-entry stage.

### C. Transfer-pricing evidence package
A practical transfer-pricing package should include the related-party register, intercompany agreements, invoices, benefit evidence, allocation keys, management-service descriptions, loan agreements, guarantee terms, benchmark files, board approvals, functional analysis, TP method selection and reconciliation to the general ledger. The file should be maintained throughout the year rather than reconstructed after an FTA request.

## References

<p id="ref1" class="ref_item">[1] UAE Ministry of Finance <a target="_blank" rel="noreferrer" href="https://mof.gov.ae/federal-budget-framework-and-process/">https://mof.gov.ae/federal-budget-framework-and-process/</a></p>
<p id="ref2" class="ref_item">[2] viewpoint.pwc.com <a target="_blank" rel="noreferrer" href="https://viewpoint.pwc.com/dt/gx/en/pwc/in_briefs/in_briefs_INT/in_briefs_INT/ifrs18insights.html">https://viewpoint.pwc.com/dt/gx/en/pwc/in_briefs/in_briefs_INT/in_briefs_INT/ifrs18insights.html</a></p>
<p id="ref3" class="ref_item">[3] aaa4uae.ae <a target="_blank" rel="noreferrer" href="https://aaa4uae.ae/fellowship-program/">https://aaa4uae.ae/fellowship-program/</a></p>
<p id="ref4" class="ref_item">[4] UAE Ministry of Finance <a target="_blank" rel="noreferrer" href="https://mof.gov.ae/wp-content/uploads/2022/12/Federal-Decree-Law-No.-47-of-2022-EN.pdf">https://mof.gov.ae/wp-content/uploads/2022/12/Federal-Decree-Law-No.-47-of-2022-EN.pdf</a></p>
<p id="ref5" class="ref_item">[5] tax.gov.ae <a target="_blank" rel="noreferrer" href="https://tax.gov.ae/en/Legislation.aspx">https://tax.gov.ae/en/Legislation.aspx</a></p>
<p id="ref6" class="ref_item">[6] kpmg.com <a target="_blank" rel="noreferrer" href="https://kpmg.com/ae/en/insights/tax-insights/federal-decree-law-no-16-and-17-of-2025.html">https://kpmg.com/ae/en/insights/tax-insights/federal-decree-law-no-16-and-17-of-2025.html</a></p>
<p id="ref7" class="ref_item">[7] pwc.com <a target="_blank" rel="noreferrer" href="https://www.pwc.com/m1/en/services/tax/middle-east-tax-news-alerts/2024/cabinet-of-ministers-issued-decision-no98-of-2024-uae-economic-substance-regulations.html">https://www.pwc.com/m1/en/services/tax/middle-east-tax-news-alerts/2024/cabinet-of-ministers-issued-decision-no98-of-2024-uae-economic-substance-regulations.html</a></p>
<p id="ref8" class="ref_item">[8] deloitte.com <a target="_blank" rel="noreferrer" href="https://www.deloitte.com/middle-east/en/services/tax/research/requirements-maintaining-transfer-pricing-documentation.html">https://www.deloitte.com/middle-east/en/services/tax/research/requirements-maintaining-transfer-pricing-documentation.html</a></p>
<p id="ref9" class="ref_item">[9] whitecase.com <a target="_blank" rel="noreferrer" href="https://www.whitecase.com/insight-alert/uae-enacts-new-aml-law-what-are-key-changes-and-what-does-mean-your-business">https://www.whitecase.com/insight-alert/uae-enacts-new-aml-law-what-are-key-changes-and-what-does-mean-your-business</a></p>
<p id="ref10" class="ref_item">[10] ifrs.org <a target="_blank" rel="noreferrer" href="https://www.ifrs.org/content/dam/ifrs/publications/amendments/english/2024/effect-analysis-ifrs18-april2024.pdf">https://www.ifrs.org/content/dam/ifrs/publications/amendments/english/2024/effect-analysis-ifrs18-april2024.pdf</a></p>
<p id="ref11" class="ref_item">[11] middleeastbriefing.com <a target="_blank" rel="noreferrer" href="https://www.middleeastbriefing.com/doing-business-guide/uae/taxation-and-accounting/accounting-standards-uae">https://www.middleeastbriefing.com/doing-business-guide/uae/taxation-and-accounting/accounting-standards-uae</a></p>
<p id="ref12" class="ref_item">[12] practiceguides.chambers.com <a target="_blank" rel="noreferrer" href="https://practiceguides.chambers.com/practice-guides/transfer-pricing-2026/uae/trends-and-developments/O24969">https://practiceguides.chambers.com/practice-guides/transfer-pricing-2026/uae/trends-and-developments/O24969</a></p>
<p id="ref13" class="ref_item">[13] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/audiix_uae-wps-wageprotectionsystem-activity-7462403695356596224-4OrX*">https://www.linkedin.com/posts/audiix_uae-wps-wageprotectionsystem-activity-7462403695356596224-4OrX*</a></p>
