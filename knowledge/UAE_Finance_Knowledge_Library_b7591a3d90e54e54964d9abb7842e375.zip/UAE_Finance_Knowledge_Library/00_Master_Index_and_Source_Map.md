# UAE Finance Knowledge Library — Master Index and Source Map

This master index introduces the UAE Finance Knowledge Library: a professional Markdown reference covering accounting, finance, auditing, tax, governance, banking, capital markets, Islamic finance, FP&A, public finance and career pathways. It is designed as a UAE-focused reference with international standards where relevant, using source-backed research collected in July 2026. [[1]](#ref1)[[2]](#ref2)[[4]](#ref4)

## Library Files

- **[Financial Reporting, IFRS Accounting Standards, and UAE Statutory Accounts](./01_Financial_Reporting_IFRS_and_Accounting.md)** — `01_Financial_Reporting_IFRS_and_Accounting.md` — 39,093 characters.
- **[UAE Corporate Tax, VAT, Excise, Transfer Pricing, ESR, and Pillar Two](./02_UAE_Tax_VAT_Transfer_Pricing_and_ESR.md)** — `02_UAE_Tax_VAT_Transfer_Pricing_and_ESR.md` — 35,063 characters.
- **[Audit, Assurance, Ethics, Quality Management, and the UAE Profession](./03_Audit_Assurance_Ethics_and_Professional_Standards.md)** — `03_Audit_Assurance_Ethics_and_Professional_Standards.md` — 50,788 characters.
- **[Corporate Finance, Valuation, M&A, Restructuring, and Financial Analysis in the UAE](./04_Corporate_Finance_Valuation_MA_and_Restructuring.md)** — `04_Corporate_Finance_Valuation_MA_and_Restructuring.md` — 37,166 characters.
- **[Banking, Treasury, Trade Finance, Capital Markets, Funds, Sukuk, and Islamic Finance](./05_Banking_Treasury_Capital_Markets_and_Islamic_Finance.md)** — `05_Banking_Treasury_Capital_Markets_and_Islamic_Finance.md` — 46,432 characters.
- **[Risk Management, Internal Control, AML/CFT, Governance, and Compliance](./06_Risk_Internal_Control_AML_Governance_and_Compliance.md)** — `06_Risk_Internal_Control_AML_Governance_and_Compliance.md` — 33,430 characters.
- **[Management Accounting, FP&A, Public Finance, Government Accounting, and Finance Careers](./07_Management_Accounting_FPandA_Public_Finance_and_Careers.md)** — `07_Management_Accounting_FPandA_Public_Finance_and_Careers.md` — 51,911 characters.

## How to Use This Library

1. Start with the chapter that matches the professional decision: reporting, tax, audit, corporate finance, banking/markets, risk/compliance or FP&A/public finance.
2. Use the checklists as working-paper prompts, not as a replacement for legal, tax, audit or regulatory advice.
3. Treat every cited legal or regulatory item as requiring current verification before filing, signing or advising, especially where implementation dates, thresholds or regulator names change.
4. For entity-specific work, create an evidence file containing the trade licence, ownership, financial statements, tax registrations, bank facilities, board minutes, contracts and regulator correspondence.

## Canonical Coverage Map

# UAE Finance Knowledge Library — Canonical Coverage Map

Generated from `wide_research/uae_finance_domains.json` and research child outputs.

## Final File Structure

### 00_Master_Index_and_Source_Map.md
- **Title:** Master Index, Source Map, and How to Use the UAE Finance Knowledge Library
- **Target size:** 25,000+ characters
- **Source packets:** all packets
- **Coverage:** Scope, audience, source policy, UAE finance ecosystem map, regulator map, standards map, file guide, cross-domain index, glossary starter.

### 01_Financial_Reporting_IFRS_and_Accounting.md
- **Title:** Financial Reporting, IFRS Accounting Standards, and UAE Statutory Accounts
- **Target size:** 45,000+ characters
- **Source packets:** IFRS accounting standards and financial reporting for UAE entities; Islamic finance packet for AAOIFI contrasts
- **Coverage:** IFRS adoption, UAE CCL audit/accounts requirements, CT accounting basis, IFRS for SMEs, IFRS 9, IFRS 15/16/17, presentation, disclosures, sector issues, AAOIFI comparison.

### 02_UAE_Tax_VAT_Transfer_Pricing_and_ESR.md
- **Title:** UAE Corporate Tax, VAT, Excise, Transfer Pricing, ESR, and Pillar Two
- **Target size:** 50,000+ characters
- **Source packets:** UAE corporate tax, VAT, excise tax, transfer pricing and ESR; Management accounting TP packet; Corporate finance restructuring tax packet
- **Coverage:** CT rates, free zones, SBR, qualifying income, deductible expenses, interest limitation, VAT, excise, TP documentation, ESR transition, DMTT/Pillar Two, practical compliance calendars.

### 03_Audit_Assurance_Ethics_and_Professional_Standards.md
- **Title:** Audit, Assurance, Ethics, Quality Management, and the UAE Profession
- **Target size:** 45,000+ characters
- **Source packets:** Audit and assurance standards; Professional certifications and career pathways; Risk/ICFR packet
- **Coverage:** ISA, ISQM, IESBA, MoE auditor registration, CCL audit duties, SCA ICFR, CBUAE external audit, Sharia audit, audit methodology and working papers.

### 04_Corporate_Finance_Valuation_MA_and_Restructuring.md
- **Title:** Corporate Finance, Valuation, M&A, Restructuring, and Financial Analysis in the UAE
- **Target size:** 50,000+ characters
- **Source packets:** Corporate finance, M&A and restructuring; Financial statement analysis, valuation and business performance management
- **Coverage:** Capital budgeting, WACC, DCF, multiples, financial statement analysis, M&A rules, takeover thresholds, tax-neutral restructuring, bankruptcy, working capital impact.

### 05_Banking_Treasury_Capital_Markets_and_Islamic_Finance.md
- **Title:** Banking, Treasury, Trade Finance, Capital Markets, Funds, Sukuk, and Islamic Finance
- **Target size:** 60,000+ characters
- **Source packets:** Banking/treasury/trade finance; Capital markets/securities/funds; Islamic finance/Sharia/takaful/sukuk
- **Coverage:** CBUAE 2025 law, Basel liquidity, treasury centres, trade finance instruments, CMA/DFSA/FSRA markets, funds/REITs, sukuk, AAOIFI, takaful, Sharia governance.

### 06_Risk_Internal_Control_AML_Governance_and_Compliance.md
- **Title:** Risk Management, Internal Control, AML/CFT, Governance, and Compliance
- **Target size:** 45,000+ characters
- **Source packets:** Risk management/internal control/AML/CFT; Audit; Capital markets governance; Banking compliance
- **Coverage:** COSO, ERM, ICFR, AML/CFT 2025, FATF, sanctions/proliferation financing, fraud risk, governance codes, three lines model, compliance monitoring.

### 07_Management_Accounting_FPandA_Public_Finance_and_Careers.md
- **Title:** Management Accounting, FP&A, Public Finance, Government Accounting, and Finance Careers
- **Target size:** 50,000+ characters
- **Source packets:** Management accounting/FP&A; Public sector finance/government accounting/procurement/SWFs; Professional certifications
- **Coverage:** Budgeting, forecasting, costing, variance analysis, KPIs, federal budget, FGAAS/IPSAS, procurement, sovereign wealth funds, competency maps, career pathways.

## Source Packets
- Packet 01: `UAE_Finance_Library_sources/01_professional_certifications_and_competency_map_cpa_acca_cma_cfa_cia_cisa_frm_ca_dipifr_and.md` — Professional certifications and competency map: CPA, ACCA, CMA, CFA, CIA, CISA, FRM, CA, DipIFR and UAE finance career pathways (12,311 chars)
- Packet 02: `UAE_Finance_Library_sources/02_banking_treasury_cash_management_trade_finance_and_working_capital_in_uae.md` — Banking, treasury, cash management, trade finance and working capital in UAE (9,983 chars)
- Packet 03: `UAE_Finance_Library_sources/03_management_accounting_budgeting_forecasting_costing_and_fp_a.md` — Management accounting, budgeting, forecasting, costing and FP&A (10,992 chars)
- Packet 04: `UAE_Finance_Library_sources/04_capital_markets_securities_funds_reits_sukuk_bonds_and_uae_financial_regulators.md` — Capital markets, securities, funds, REITs, sukuk, bonds and UAE financial regulators (10,572 chars)
- Packet 05: `UAE_Finance_Library_sources/05_financial_statement_analysis_ratios_valuation_and_business_performance_management.md` — Financial statement analysis, ratios, valuation and business performance management (11,587 chars)
- Packet 06: `UAE_Finance_Library_sources/06_ifrs_accounting_standards_and_financial_reporting_for_uae_entities.md` — IFRS accounting standards and financial reporting for UAE entities (10,969 chars)
- Packet 07: `UAE_Finance_Library_sources/07_audit_and_assurance_standards_isa_isqm_iesba_ethics_uae_audit_practice.md` — Audit and assurance standards: ISA, ISQM, IESBA ethics, UAE audit practice (11,556 chars)
- Packet 08: `UAE_Finance_Library_sources/08_public_sector_finance_government_accounting_procurement_grants_and_sovereign_wealth_in_uae.md` — Public sector finance, government accounting, procurement, grants and sovereign wealth in UAE (10,687 chars)
- Packet 09: `UAE_Finance_Library_sources/09_risk_management_internal_control_coso_erm_fraud_aml_cft_and_compliance.md` — Risk management, internal control, COSO, ERM, fraud, AML/CFT and compliance (11,091 chars)
- Packet 10: `UAE_Finance_Library_sources/10_corporate_finance_capital_budgeting_cost_of_capital_m_a_and_restructuring_in_uae_context.md` — Corporate finance, capital budgeting, cost of capital, M&A and restructuring in UAE context (6,310 chars)
- Packet 11: `UAE_Finance_Library_sources/11_islamic_finance_sharia_accounting_takaful_sukuk_and_aaoifi_standards.md` — Islamic finance, Sharia accounting, takaful, sukuk and AAOIFI standards (4,810 chars)
- Packet 12: `UAE_Finance_Library_sources/12_uae_corporate_tax_vat_excise_tax_transfer_pricing_and_esr.md` — UAE corporate tax, VAT, excise tax, transfer pricing and ESR (7,002 chars)

## References

<p id="ref1" class="ref_item">[1] UAE Ministry of Finance <a target="_blank" rel="noreferrer" href="https://mof.gov.ae/federal-budget-framework-and-process/">https://mof.gov.ae/federal-budget-framework-and-process/</a></p>
<p id="ref2" class="ref_item">[2] ifrs.org <a target="_blank" rel="noreferrer" href="https://www.ifrs.org/content/dam/ifrs/publications/amendments/english/2024/effect-analysis-ifrs18-april2024.pdf">https://www.ifrs.org/content/dam/ifrs/publications/amendments/english/2024/effect-analysis-ifrs18-april2024.pdf</a></p>
<p id="ref3" class="ref_item">[3] aaa4uae.ae <a target="_blank" rel="noreferrer" href="https://aaa4uae.ae/fellowship-program/">https://aaa4uae.ae/fellowship-program/</a></p>
<p id="ref4" class="ref_item">[4] Central Bank of the UAE Rulebook <a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae*">https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae*</a></p>
<p id="ref5" class="ref_item">[5] whitecase.com <a target="_blank" rel="noreferrer" href="https://www.whitecase.com/insight-alert/uae-enacts-new-aml-law-what-are-key-changes-and-what-does-mean-your-business">https://www.whitecase.com/insight-alert/uae-enacts-new-aml-law-what-are-key-changes-and-what-does-mean-your-business</a></p>
<p id="ref6" class="ref_item">[6] kpmg.com <a target="_blank" rel="noreferrer" href="https://kpmg.com/ae/en/insights/tax-insights/updated-ministerial-decision-on-audited-financial-statements.html">https://kpmg.com/ae/en/insights/tax-insights/updated-ministerial-decision-on-audited-financial-statements.html</a></p>
