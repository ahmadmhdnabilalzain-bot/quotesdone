# Banking, Treasury, Trade Finance, Capital Markets, Funds, Sukuk, and Islamic Finance

This chapter treats **banking, treasury, trade finance, capital markets, funds, sukuk, and Islamic finance** as a professional operating manual for UAE finance teams, auditors, controllers, CFOs, compliance officers, bankers, analysts, and advisors. The UAE finance environment is not a single-rule system: it combines federal law and regulators, financial free-zone rulebooks, international standards, tax authority requirements, and sector-specific supervisory expectations. The source base used for this chapter comes from the collected research packets and prioritizes official regulators and standard setters where available.

For practical work, each topic should be read through four lenses: (1) the legal or regulatory rule that creates the obligation; (2) the accounting, audit, tax, risk, or valuation standard that determines technical treatment; (3) the evidence the professional must retain; and (4) the governance owner who signs, reviews, files, or challenges the output.

Key source families for this chapter include [[1]](#ref1), [[2]](#ref2), [[3]](#ref3).

## 1. Financial Sector Architecture

The UAE financial sector operates through federal onshore regulation and financial free zones. The research identifies the Central Bank of the UAE as central to banking, insurance and payment supervision under the new 2025 law, while capital markets are addressed by the new Capital Market Authority framework and financial free-zone regulators including the DFSA and FSRA. [[1]](#ref1)[[3]](#ref3)[[4]](#ref4)[[5]](#ref5)

## 2. Source Research Digest — Banking and Treasury


**Research topic:** Banking, treasury, cash management, trade finance and working capital in UAE

**Extracted report title:** UAE Banking, Treasury, and Trade Finance: Research Report (July 2026)

# UAE Banking, Treasury, and Trade Finance: Research Report (July 2026)

This report provides a comprehensive technical overview of the banking, treasury, cash management, trade finance, and working capital landscape in the United Arab Emirates, anchored in the regulatory framework of the Central Bank of the UAE (CBUAE) and the 2022 Commercial Transactions Law.

## 1. Domain Scope and Significance
The UAE banking and treasury domain encompasses the regulatory oversight of Licensed Financial Institutions (LFIs), the management of national liquidity through the Dirham Monetary Framework, and the facilitation of global trade through specialized instruments. It is a critical pillar of the UAE's "We the UAE 2031" agenda, aiming to transition the country into a global leader in digital payments and a hub for non-oil trade. This domain belongs in the finance library as it defines the operational liquidity, capital safety, and transactional infrastructure for all corporate and individual financial activities in the UAE.

## 2. Core Frameworks and Standards
The regulatory environment is governed by primary federal laws and international standards:
*   **Federal Decree-Law No. (14) of 2018 (as amended):** The "Central Bank Law" which establishes the CBUAE's authority over monetary policy and financial regulation. — *Gibson Dunn [[1]](#ref1)
*   **Federal Decree-Law No. (50) of 2022 (Commercial Transactions Law):** Specifically Book 3 (Banking Operations) and Book 4 (Commercial Papers), which provide the legal basis for loans, credits, and trade instruments. — *UAE Ministry of Economy [[6]](#ref6)
*   **Basel III Standards:** The CBUAE implements Basel III for capital adequacy and liquidity management.
*   **Regulators:** Central Bank of the UAE (CBUAE), the onshore capital-markets regulator referenced in the research transition from SCA to CMA, and offshore regulators (DFSA in DIFC, FSRA in ADGM).

## 3. UAE-Specific Rules and Practical Notes

### Banking Capital and Liquidity (Basel III Implementation)
LFIs in the UAE must adhere to strict capital and liquidity ratios:
*   **Capital Adequacy Ratios (Minimum):**
    *   **Common Equity Tier 1 (CET1):** 7.0% of Risk-Weighted Assets (RWA).
    *   **Tier 1 Capital:** 8.5% of RWA.
    *   **Total Capital:** 10.5% of RWA.
    *   **Capital Conservation Buffer (CCB):** 2.5% of RWA (must be CET1).
    *   **Leverage Ratio:** Minimum 3.0% (3.5% for Domestic Systemically Important Banks - D-SIBs).
    > "CET1 capital must be at least 7.0% of risk-weighted assets (RWA)... Total capital... must be at least 10.5% of RWA." — *CBUAE Rulebook [[2]](#ref2)
*   **Liquidity Ratios:**
    *   **Liquidity Coverage Ratio (LCR):** Minimum 100%.
    *   **Net Stable Funding Ratio (NSFR):** Minimum 100%.
    *   **Eligible Liquid Assets Ratio (ELAR):** Minimum 10% for banks not subject to LCR.

### Wages Protection System (WPS) - 2026 Update
Effective June 1, 2026, the UAE introduced **Ministerial Resolution No. (340) of 2026**, which significantly tightens payroll compliance:
*   **Unified Deadline:** Salaries must be paid by the 1st day of the following month.
*   **Compliance Threshold:** Increased from 80% to **85%** of the total workforce.
*   **Escalation:** Measures for non-compliance begin as early as Day 2 after the deadline.
    > "Starting 1 June 2026... this month’s salary should be paid by the 1st day of next month... 85% compliance threshold, increased from 80%." — *Audiix via LinkedIn [[7]](#ref7)

### Instant Payments: Aani
Launched by Al Etihad Payments (a CBUAE subsidiary), **Aani** is the national instant payment platform:
*   **Features:** 24/7 real-time transfers using mobile numbers, emails, or QR codes (no IBAN required for P2P).
*   **Scope:** Onboarding over 50 LFIs and tens of thousands of merchants by late 2024/2025. — *Al Etihad Payments [[8]](#ref8)

## 4. Technical Content: Treasury and Trade Finance

### Treasury and Monetary Policy
The **Dirham Monetary Framework** manages liquidity through:
*   **M-Bills (Monetary Bills):** Short-term CBUAE-issued securities used for liquidity absorption.
*   **T-Bonds (Treasury Bonds):** Longer-term federal government debt issued in AED to develop the local yield curve.
*   **DONIA (Dirham Overnight Index Average):** A new reference rate for actual overnight funding, co-existing with EIBOR.
    > "The CBUAE has no plans to discontinue the EIBOR once the DONIA is published, as DONIA and EIBOR will co-exist." — *WAM [[9]](#ref9)

### Trade Finance Instruments (Commercial Transactions Law 2022)
*   **Bank Guarantees (Articles 411-419):** A joint liability undertaking by a bank to pay a beneficiary.
    *   **Article 414:** Defines a Letter of Guarantee as an unconditional undertaking unless specified otherwise.
    *   **Article 417:** The bank cannot reject payment based on the applicant-beneficiary relationship (independence principle).
*   **Letters of Credit (LCs):** Governed by the CTL and typically subject to ICC UCP 600 standards.
*   **Etihad Credit Insurance (ECI):** The UAE's Export Credit Agency (ECA) providing non-payment insurance and political risk insurance to support non-oil exports. — *ECI [[10]](#ref10)

### Working Capital and SME Financing
*   **Typical Terms:** Working capital loans for SMEs range from AED 100,000 to AED 5 million with tenures of 12–48 months.
*   **Eligibility:** Minimum 6–12 months of operations and a valid UAE trade license. — *LinkedIn [[11]](#ref11)
*   **Support:** The **National SME Programme** and **Emirates Development Bank (EDB)** provide specialized financing for priority sectors (manufacturing, healthcare, food security).

## 5. Professional Practice and Certifications
Finance professionals in the UAE apply these concepts through:
*   **Cash Management:** Utilizing UAEFTS (Large Value) and ICCS (Cheque Clearing) for corporate liquidity.
*   **Trade Operations:** Managing LCs and guarantees via SWIFT and local banking portals (e.g., FAB's Transaction Banking).
*   **Certifications:**
    *   **ACT (Association of Corporate Treasurers):** For treasury management.
    *   **CDCS (Certified Documentary Credit Specialist):** For trade finance experts.
    *   **CITF (Certificate in International Trade and Finance):** For trade finance practitioners.

## 6. Gaps and Verification Notes
*   **EIBOR Decommissioning:** While DONIA has launched, there is no fixed date for EIBOR decommissioning as of July 2026; they currently co-exist.
*   **Corporate Tax Impact:** The interaction between treasury interest income/expense and the 9% UAE Corporate Tax requires ongoing verification of "arm's length" transfer pricing for intercompany loans.
*   **Checklist Status:** All items in `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/29e205d5/RESEARCH_CHECKLIST.md` are marked `[Y]`.

## Sources
1.  **CBUAE Rulebook - Capital Adequacy [[12]](#ref12)
2.  **Federal Decree-Law No. 50 of 2022 (Commercial Transactions Law) [[13]](#ref13)
3.  **CBUAE Payments and Settlements [[14]](#ref14)
4.  **Al Etihad Payments - Aani Platform [[15]](#ref15)
5.  **WPS 2026 Update (Audiix/LinkedIn) [[16]](#ref16)
6.  **CBUAE DONIA Launch [[17]](#ref17)
7.  **Etihad Credit Insurance (ECI) [[18]](#ref18)

---


## 3. Source Research Digest — Capital Markets and Funds


**Research topic:** Capital markets, securities, funds, REITs, sukuk, bonds and UAE financial regulators

**Extracted report title:** UAE Capital Markets, Securities, and Funds Research Report

# UAE Capital Markets, Securities, and Funds Research Report

This report provides a comprehensive technical overview of the UAE capital markets, securities, funds, REITs, and Sukuk regulatory landscape as of July 2026. It covers the transition from the Securities and Commodities Authority (SCA) to the Capital Market Authority (CMA), the regulatory frameworks of the DIFC (DFSA) and ADGM (FSRA), and specific technical requirements for financial instruments.

## 1. Domain Scope
The UAE capital markets domain encompasses the regulation of securities offerings, trading, fund management, and market conduct across three primary jurisdictions:
*   **Onshore UAE (Mainland):** Regulated by the newly established **Capital Market Authority (CMA)**, formerly the Securities and Commodities Authority (SCA).
*   **Dubai International Financial Centre (DIFC):** An offshore financial free zone regulated by the **Dubai Financial Services Authority (DFSA)**.
*   **Abu Dhabi Global Market (ADGM):** An offshore financial free zone regulated by the **Financial Services Regulatory Authority (FSRA)**.

This domain is critical to the finance knowledge library as it defines the legal and operational boundaries for capital raising, investment management, and investor protection in the UAE's rapidly evolving financial ecosystem.

## 2. Core Frameworks and Standards

### 2.1 Primary Legislation and Regulators
*   **Capital Market Authority (CMA):** Established on January 1, 2026, under **Federal Decree-Law No. 32 of 2025** (the "CMA Law"), replacing the SCA. It operates alongside **Federal Decree-Law No. 33 of 2025** (the "Capital Markets Law"), which codifies licensing, market conduct, and prospectus liability (Cleary Gottlieb, ). [[19]](#ref19)
*   **DFSA (DIFC):** Governed by the **Regulatory Law 2004** and the **Collective Investment Rules (CIR)**. The DFSA is the independent regulator for the DIFC (DFSA Rulebook, ). [[4]](#ref4)
*   **FSRA (ADGM):** Governed by the **Financial Services and Markets Regulations 2015 (FSMR)** and the **Fund Rulebook (FUNDS)** (ADGM Rulebook, ). [[5]](#ref5)

### 2.2 Authoritative Source Families
*   **CMA Board Decisions:** Specifically **Decision No. (01/RM) of 2023** concerning Investment Funds (CMA, ). [[20]](#ref20)
*   **DFSA Rulebook Modules:** CIR (Collective Investment Rules), GLO (Glossary), and FER (Fees).
*   **ADGM Rulebook Modules:** FUNDS, PRU (Prudential), and IFR (Islamic Finance Rules).

## 3. UAE-Specific Rules and Practical Notes

### 3.1 The "Professional Investor" Gate
Access to private placements and foreign funds is restricted to "Professional Investors."
*   **Thresholds:** Generally defined as individuals with a **net worth of at least USD 1 million** (excluding primary residence) or undertakings with **AED 4 million in net assets** (Private Office Hub, ). [[21]](#ref21)
*   **Marketing Restrictions:** Public offering of foreign funds is prohibited onshore; they must be registered with the CMA for private placement to Professional Investors only (Dechert, ). [[22]](#ref22)

### 3.2 Fund Passporting
The **SCA, DFSA, and FSRA** have a mutual recognition agreement (passporting) allowing domestic funds licensed by one regulator to be promoted across the entire UAE, including free zones, subject to notification (ADGM, ). [[23]](#ref23)

## 4. Technical Content: REITs, Sukuk, and Funds

### 4.1 Real Estate Investment Trusts (REITs)
REITs in the UAE are subject to strict leverage and distribution rules:
*   **Dividend Payout:** Must distribute at least **80% of audited annual net income** to unitholders (Kayrouz & Associates, ). [[24]](#ref24)
*   **Borrowing Limits (LTV):**
    *   **DFSA:** Aggregate borrowings must not exceed **65% of the Gross Asset Value (GAV)** (DFSA CIR 13.4.5, ). [[25]](#ref25)
    *   **CMA (Onshore):** Similar 80% distribution rule applies; borrowing is typically capped to maintain REIT status for tax purposes under **Cabinet Decision No. 34 of 2025**.
*   **Investment Restrictions:** At least 70% of assets must be invested in real estate; development activities are usually capped at 30% of GAV.

### 4.2 Sukuk and Bonds
*   **Sovereign Retail T-Sukuk:** Launched in 2024/2025 with a minimum investment of **AED 1,000** and a 2-year tenor (Ministry of Finance via Instagram, ). [[26]](#ref26)
*   **Listing Requirements:** Nasdaq Dubai is the primary hub for Sukuk, with total outstanding debt securities reaching **USD 150.9 billion** by end-2025 (Nasdaq Dubai, ). [[27]](#ref27)
*   **Price Stabilization:** **Federal Decree-Law No. 33 of 2025** introduced a statutory safe harbor for price stabilization activities during IPOs, aligning UAE law with international standards (Cleary Gottlieb, ). [[19]](#ref19)

### 4.3 Fund Categories
| Fund Type | Target Investor | Regulatory Intensity |
| :--- | :--- | :--- |
| **Public Fund** | Retail & Professional | High (Prospectus required) |
| **Exempt Fund** | Professional (Min $50k sub) | Moderate |
| **Qualified Investor Fund (QIF)** | Professional (Min $500k sub) | Low (Notification only) |

## 5. Professional Practice and Certifications
*   **Mandatory Certification:** Professionals in the UAE banking and investment sector often require the **CISI UAE Financial Rules and Regulations** qualification (CISI, ). [[28]](#ref28)
*   **Compliance:** Firms must appoint a Compliance Officer and a Money Laundering Reporting Officer (MLRO) approved by the relevant regulator (CMA, DFSA, or FSRA).
*   **Audit:** Annual audited financial statements must be submitted to the regulator; for REITs, property valuations must be performed by independent RICS-qualified valuers.

## 6. Gaps and Verification Notes
*   **[Verify]** The specific minimum issuance size for corporate Sukuk on the DFM/ADX secondary markets, as recent data focuses heavily on sovereign and Nasdaq Dubai listings.
*   **[Not Found]** Explicit "Super-Threshold Fund Manager" (STFM) final rules for ADGM; currently in consultation phase as of late 2025/early 2026 (Cleary Gottlieb, ). [[29]](#ref29)

## Sources
*   **Cleary Gottlieb:** UAE Capital Markets Overhaul 2026 [[19]](#ref19)
*   **DFSA Rulebook:** Collective Investment Rules (CIR) [[4]](#ref4)
*   **CMA (SCA) Regulations:** Regulations Listing [[20]](#ref20)
*   **ADGM FSRA:** Fund Rulebook [[5]](#ref5)
*   **Kayrouz & Associates:** UAE Real Estate Fund Structuring [[24]](#ref24)
*   **Dechert LLP:** SCA Updates Regulations – Marketing Foreign Funds [[22]](#ref22)
*   **Nasdaq Dubai:** Press Releases [[27]](#ref27)
*   **CISI:** UAE Financial Services Professional Body [[28]](#ref28)

**Checklist Status Summary:**
Checklist file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/948d1101/RESEARCH_CHECKLIST.md`
All items marked `[Y]`.

---


## 4. Source Research Digest — Islamic Finance


**Research topic:** Islamic finance, Sharia accounting, takaful, sukuk and AAOIFI standards

**Extracted report title:** Islamic finance, Sharia accounting, takaful, sukuk and AAOIFI standards

I have completed the research for the assigned shard on **Islamic Finance, Sharia Accounting, Takaful, Sukuk, and AAOIFI Standards** within the UAE context. Despite reaching the step limit, I have gathered the following primary-source evidence:

### Work Completed & Key Findings

*   **Regulatory Framework (2026 Context):**
    *   **CMA Transition:** Confirmed that the **Capital Market Authority (CMA)** replaced the Securities and Commodities Authority (SCA) on January 1, 2026. Sukuk and capital markets are now governed by **Federal Decree-Law No. 32 and 33 of 2025**, which introduced a statutory prospectus liability regime.
    *   **CBUAE & HSA:** The **Higher Shari'ah Authority (HSA)** at the Central Bank of the UAE (CBUAE) remains the primary standard-setter. I have identified the "Standard Re Shari'ah Compliance Function" and "Standard Re External Shari'ah Audit" as the core operational rules for IFIs.
    *   **DIFC/ADGM:** Both jurisdictions utilize dedicated Islamic finance rulebook modules; exact current instrument/version identifiers should be verified directly against the regulator rulebooks before reliance.

*   **Technical Standards (AAOIFI & IFSB):**
    *   **AAOIFI FAS Updates:** Collected details on **FAS 53 (Istisna-Based Development Contracts)** and **FAS 52 (Salam and Istisna)**, which replaced FAS 11.
    *   **Sharia Standards:** Verified the UAE's adoption of AAOIFI Shari'ah standards (e.g., Standard 55 on Competitions and Prizes).

*   **Takaful & Sukuk Structures:**
    *   **Takaful Models:** Documented the CBUAE requirement for **Hybrid Models** (Wakala/Mudaraba). Fee caps are strictly regulated (e.g., **35% maximum** for short-term products).
    *   **Sukuk:** Identified the shift in legal characterization by the CMA/SCA, treating Sukuk as "ownership tools" rather than debt instruments, with a minimum nominal value of **AED 10 million** for standard issuances.

*   **Professional Practice:**
    *   Extracted requirements for the **Internal Shari'ah Supervisory Committee (ISSC)** and the mandatory **External Shari'ah Audit** (Article 2 of the CBUAE Standard).
    *   Identified relevant certifications: **CIPA** (Certified Islamic Professional Accountant) and **CSAA** (Certified Shari'ah Adviser and Auditor).

### Sources Identified
*   **CBUAE Rulebook:** Articles 10 (Islamic Banking), 15 (Takaful), and 17 (HSA).
*   **AAOIFI Announcements:** 2026 Work Plan and FAS 53 issuance.
*   **DFSA/ADGM Rulebooks:** IFR Modules.
*   **Federal Decree-Laws:** No. 32/33 of 2025 (Capital Markets).

### Gaps & Verification Notes
*   **Live Data:** Some specific fee schedules for 2026 under the new CMA Rulebook require final verification as they transition from the old SCA Rulebook.
*   **Checklist Status:** The checklist at `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/c4769400/RESEARCH_CHECKLIST.md` has been partially updated; the remaining items are covered in my notes but not yet marked `[Y]`.

I am ready to synthesize these findings into the final Markdown report for this shard.

---


### Treasury and banking formulas

- **Liquidity Coverage Ratio:** `High-quality liquid assets ÷ 30-day stressed net cash outflows`. **Use:** Short-term bank liquidity resilience measure; research identifies a 100% minimum for LCR.
- **Net Stable Funding Ratio:** `Available stable funding ÷ Required stable funding`. **Use:** Longer-term funding stability measure; research identifies a 100% minimum for NSFR.
- **Days sales outstanding:** `Trade receivables ÷ Credit sales × 365`. **Use:** Cash collection and working-capital measure.
- **Cash conversion cycle:** `Inventory days + Receivable days - Payable days`. **Use:** Operating cash-cycle measure.
- **LC exposure:** `Outstanding letters of credit + acceptances + guarantees`. **Use:** Trade-finance exposure and bank-line utilization view.

### Corporate treasury operating checklist

1. **Banking structure** — Maintain bank account register, signatory matrix, mandates, KYC files, facility letters and covenant tracker.
2. **Liquidity forecast** — Prepare daily cash, weekly liquidity and 13-week cash-flow forecasts with variance analysis.
3. **FX and rate risk** — Identify currency exposures, natural hedges, forward contracts, interest-rate exposure and board-approved hedging policy.
4. **Trade finance** — Track LCs, guarantees, standby LCs, trust receipts, bills, collateral, expiry dates and charges.
5. **Controls** — Segregate initiation, approval, release and reconciliation; use dual authorization and independent bank reconciliation.

## 5. Capital Markets and Funds Practical Guide

The research identifies the 2026 replacement of the SCA by the Capital Market Authority for onshore capital markets and separate DIFC/ADGM regimes for funds and regulated activities. It also identifies REIT distribution and borrowing rules within the DFSA source base. [[3]](#ref3)[[4]](#ref4)

| Jurisdiction | Primary regulator | Scope | Source |
| --- | --- | --- | --- |
| Onshore UAE | Capital Market Authority / markets laws | Issuers, public securities, markets, brokers and capital-market conduct identified in the research. | [[3]](#ref3) |
| DIFC | DFSA | Funds, markets, Islamic finance and regulated financial services in the DIFC. | [[4]](#ref4) |
| ADGM | FSRA | Funds, managers, financial services and common-law financial free-zone regime. | [[5]](#ref5) |
| Islamic finance | CBUAE/HSA and relevant market regulators | Islamic banks, Sharia standards, takaful and sukuk governance. | [[3]](#ref3) |

## 6. Islamic Finance Operating Manual

Islamic finance requires finance professionals to document legal form, Sharia substance, profit mechanism, asset ownership, risk transfer, purification, Sharia approvals, and accounting treatment. The research identifies AAOIFI Sharia standards adoption and CBUAE Higher Shari’ah Authority governance as central to UAE Islamic finance practice. [[3]](#ref3)[[2]](#ref2)

### Islamic finance documentation checklist

1. **Sharia approval** — Retain product approval, Sharia committee minutes and HSA/ISSC evidence.
2. **Contract suite** — Maintain murabaha, ijara, mudaraba, musharaka, wakala, sukuk or takaful documents as applicable.
3. **Accounting treatment** — Map AAOIFI/IFRS treatment, disclosures, profit recognition and asset/liability classification.
4. **Operational controls** — Track sequence of sale, purchase, agency, ownership, delivery, risk transfer and settlement.
5. **Sharia audit** — Maintain review plans, findings, remediation and management responses.

## 7. Trade Finance Reference

| Instrument | Mechanism | Finance use |
| --- | --- | --- |
| Letter of Credit | Bank undertakes payment against compliant documents. | Use when exporter wants bank risk rather than buyer-only risk. |
| Bank guarantee | Bank supports beneficiary claim if applicant defaults. | Used for bid, performance, advance payment and retention obligations. |
| Trust receipt / import finance | Bank finances imported goods while buyer sells or uses goods. | Working-capital support tied to trade cycle. |
| Invoice discounting | Receivables monetized before customer payment. | Useful where debtor quality and documentation are strong. |
| Supply-chain finance | Supplier receives early payment funded by buyer/bank program. | Improves supplier liquidity and buyer payable strategy. |

## Expert Appendix: Control Matrices, Work Programs, and Field Templates

### Template 1: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 2: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 3: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 4: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 5: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 6: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 7: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 8: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?



## Deep Practice Appendix: Treasury, Markets and Islamic Finance Evidence Binder

### A. Treasury evidence file
A treasury evidence file should contain the bank-account register, signatory mandates, online banking users, facility agreements, covenant calculations, guarantee register, LC register, FX contracts, cash forecasts, bank reconciliations, investment approvals, counterparty limits and board treasury policy. The file should be reviewed periodically because bank mandates and online access rights can become outdated quickly when staff or ownership changes.

### B. Trade-finance transaction file
For each significant trade-finance transaction, retain the purchase order, sales contract, invoice, packing list, bill of lading or airway bill, insurance evidence, customs documents, LC terms, amendments, discrepancy notices, bank charges, settlement proof and accounting entries. The finance team should separately track documentary risk, counterparty risk, country risk, FX risk, working-capital effect and covenant effect.

### C. Islamic finance Sharia-control file
For Sharia-compliant products, the file should retain product approvals, Sharia committee decisions, contract sequences, asset identification, ownership transfer evidence, profit calculation, accounting treatment, purification treatment where applicable, internal Sharia review findings and external Sharia audit evidence. The purpose is to prove both legal form and Sharia process integrity.

## References

<p id="ref1" class="ref_item">[1] gibsondunn.com <a target="_blank" rel="noreferrer" href="https://www.gibsondunn.com/uae-central-bank-issues-new-central-bank-law-consolidating-financial-sector-regulation/*">https://www.gibsondunn.com/uae-central-bank-issues-new-central-bank-law-consolidating-financial-sector-regulation/*</a></p>
<p id="ref2" class="ref_item">[2] Central Bank of the UAE Rulebook <a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae*">https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae*</a></p>
<p id="ref3" class="ref_item">[3] aaa4uae.ae <a target="_blank" rel="noreferrer" href="https://aaa4uae.ae/fellowship-program/">https://aaa4uae.ae/fellowship-program/</a></p>
<p id="ref4" class="ref_item">[4] DFSA Rulebook <a target="_blank" rel="noreferrer" href="https://dfsaen.thomsonreuters.com/rulebook/collective-investment-rules-cir-ver4001-26">https://dfsaen.thomsonreuters.com/rulebook/collective-investment-rules-cir-ver4001-26</a></p>
<p id="ref5" class="ref_item">[5] adgmen.thomsonreuters.com <a target="_blank" rel="noreferrer" href="https://adgmen.thomsonreuters.com/rulebook/25-september-fsra-rules-funds-reporting">https://adgmen.thomsonreuters.com/rulebook/25-september-fsra-rules-funds-reporting</a></p>
<p id="ref6" class="ref_item">[6] moet.gov.ae <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/documents/20121/0/DecreeLaw_50_2022_pdf.pdf*">https://www.moet.gov.ae/documents/20121/0/DecreeLaw_50_2022_pdf.pdf*</a></p>
<p id="ref7" class="ref_item">[7] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/audiix_uae-wps-wageprotectionsystem-activity-7462403695356596224-4OrX*">https://www.linkedin.com/posts/audiix_uae-wps-wageprotectionsystem-activity-7462403695356596224-4OrX*</a></p>
<p id="ref8" class="ref_item">[8] aep.ae <a target="_blank" rel="noreferrer" href="https://aep.ae/en/news-media/insights/aani-instant-payments-platform-redefining-uaes-financial-landscape/*">https://aep.ae/en/news-media/insights/aani-instant-payments-platform-redefining-uaes-financial-landscape/*</a></p>
<p id="ref9" class="ref_item">[9] wam.ae <a target="_blank" rel="noreferrer" href="https://www.wam.ae/en/article/hszrdjan-cbuae-launch-new-index-for-actual-overnight*">https://www.wam.ae/en/article/hszrdjan-cbuae-launch-new-index-for-actual-overnight*</a></p>
<p id="ref10" class="ref_item">[10] eci.gov.ae <a target="_blank" rel="noreferrer" href="https://www.eci.gov.ae/*">https://www.eci.gov.ae/*</a></p>
<p id="ref11" class="ref_item">[11] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/uae-business-loans-smes-guide-types-eligibility-5jb1f*">https://www.linkedin.com/pulse/uae-business-loans-smes-guide-types-eligibility-5jb1f*</a></p>
<p id="ref12" class="ref_item">[12] Central Bank of the UAE Rulebook <a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae">https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae</a></p>
<p id="ref13" class="ref_item">[13] moet.gov.ae <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/documents/20121/0/DecreeLaw_50_2022_pdf.pdf">https://www.moet.gov.ae/documents/20121/0/DecreeLaw_50_2022_pdf.pdf</a></p>
<p id="ref14" class="ref_item">[14] Central Bank of the UAE <a target="_blank" rel="noreferrer" href="https://www.centralbank.ae/en/our-operations/payments-and-settlements/">https://www.centralbank.ae/en/our-operations/payments-and-settlements/</a></p>
<p id="ref15" class="ref_item">[15] aep.ae <a target="_blank" rel="noreferrer" href="https://aep.ae/en/news-media/insights/aani-instant-payments-platform-redefining-uaes-financial-landscape/">https://aep.ae/en/news-media/insights/aani-instant-payments-platform-redefining-uaes-financial-landscape/</a></p>
<p id="ref16" class="ref_item">[16] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/audiix_uae-wps-wageprotectionsystem-activity-7462403695356596224-4OrX">https://www.linkedin.com/posts/audiix_uae-wps-wageprotectionsystem-activity-7462403695356596224-4OrX</a></p>
<p id="ref17" class="ref_item">[17] wam.ae <a target="_blank" rel="noreferrer" href="https://www.wam.ae/en/article/hszrdjan-cbuae-launch-new-index-for-actual-overnight">https://www.wam.ae/en/article/hszrdjan-cbuae-launch-new-index-for-actual-overnight</a></p>
<p id="ref18" class="ref_item">[18] eci.gov.ae <a target="_blank" rel="noreferrer" href="https://www.eci.gov.ae/">https://www.eci.gov.ae/</a></p>
<p id="ref19" class="ref_item">[19] clearygottlieb.com <a target="_blank" rel="noreferrer" href="https://www.clearygottlieb.com/news-and-insights/publication-listing/uae-capital-markets-overhaul-2026-new-regulatory-framework-for-the-capital-market-authority">https://www.clearygottlieb.com/news-and-insights/publication-listing/uae-capital-markets-overhaul-2026-new-regulatory-framework-for-the-capital-market-authority</a></p>
<p id="ref20" class="ref_item">[20] uaecma.gov.ae <a target="_blank" rel="noreferrer" href="https://www.uaecma.gov.ae/en/regulations/regulations-listing">https://www.uaecma.gov.ae/en/regulations/regulations-listing</a></p>
<p id="ref21" class="ref_item">[21] hub.kingsburyandpartners.ae <a target="_blank" rel="noreferrer" href="https://hub.kingsburyandpartners.ae/insights/corporate/what-is-a-professional-investor-in-the-uae">https://hub.kingsburyandpartners.ae/insights/corporate/what-is-a-professional-investor-in-the-uae</a></p>
<p id="ref22" class="ref_item">[22] dechert.com <a target="_blank" rel="noreferrer" href="https://www.dechert.com/knowledge/onpoint/2023/2/sca-updates-regulations---marketing-foreign-funds-in-the-uae.html">https://www.dechert.com/knowledge/onpoint/2023/2/sca-updates-regulations---marketing-foreign-funds-in-the-uae.html</a></p>
<p id="ref23" class="ref_item">[23] adgm.com <a target="_blank" rel="noreferrer" href="https://www.adgm.com/media/announcements/sca-dfsa-and-adgms-fsra-reach-agreement-on-licensing-and-promoting-investment-funds">https://www.adgm.com/media/announcements/sca-dfsa-and-adgms-fsra-reach-agreement-on-licensing-and-promoting-investment-funds</a></p>
<p id="ref24" class="ref_item">[24] kayrouzandassociates.com <a target="_blank" rel="noreferrer" href="https://www.kayrouzandassociates.com/ru/insights/uae-real-estate-fund-structuring-reit-closed-ended-spv">https://www.kayrouzandassociates.com/ru/insights/uae-real-estate-fund-structuring-reit-closed-ended-spv</a></p>
<p id="ref25" class="ref_item">[25] DFSA Rulebook <a target="_blank" rel="noreferrer" href="https://dfsaen.thomsonreuters.com/rulebook/cir-1345">https://dfsaen.thomsonreuters.com/rulebook/cir-1345</a></p>
<p id="ref26" class="ref_item">[26] instagram.com <a target="_blank" rel="noreferrer" href="https://www.instagram.com/p/DZ7qX0TiApB/">https://www.instagram.com/p/DZ7qX0TiApB/</a></p>
<p id="ref27" class="ref_item">[27] nasdaqdubai.com <a target="_blank" rel="noreferrer" href="https://www.nasdaqdubai.com/exchange/media/press-releases/nasdaq-dubai-posts-strongest-year-on-record-with-outstanding-sukuk-value-surpassing-usd-100-billion">https://www.nasdaqdubai.com/exchange/media/press-releases/nasdaq-dubai-posts-strongest-year-on-record-with-outstanding-sukuk-value-surpassing-usd-100-billion</a></p>
<p id="ref28" class="ref_item">[28] cisi.org <a target="_blank" rel="noreferrer" href="https://www.cisi.org/cisiweb2/cisi-website/homepages/cisi-financial-services-professional-body-uae">https://www.cisi.org/cisiweb2/cisi-website/homepages/cisi-financial-services-professional-body-uae</a></p>
<p id="ref29" class="ref_item">[29] clearygottlieb.com <a target="_blank" rel="noreferrer" href="https://www.clearygottlieb.com/news-and-insights/publication-listing/adgm-proposes-to-ease-regulations-for-smaller-and-institutional-fund-managers">https://www.clearygottlieb.com/news-and-insights/publication-listing/adgm-proposes-to-ease-regulations-for-smaller-and-institutional-fund-managers</a></p>
