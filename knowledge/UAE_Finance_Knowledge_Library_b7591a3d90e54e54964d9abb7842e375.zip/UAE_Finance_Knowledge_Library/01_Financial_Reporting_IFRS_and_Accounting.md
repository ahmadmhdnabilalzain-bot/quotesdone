# Financial Reporting, IFRS Accounting Standards, and UAE Statutory Accounts

This chapter treats **financial reporting, IFRS Accounting Standards, and UAE statutory accounts** as a professional operating manual for UAE finance teams, auditors, controllers, CFOs, compliance officers, bankers, analysts, and advisors. The UAE finance environment is not a single-rule system: it combines federal law and regulators, financial free-zone rulebooks, international standards, tax authority requirements, and sector-specific supervisory expectations. The source base used for this chapter comes from the collected research packets and prioritizes official regulators and standard setters where available.

For practical work, each topic should be read through four lenses: (1) the legal or regulatory rule that creates the obligation; (2) the accounting, audit, tax, risk, or valuation standard that determines technical treatment; (3) the evidence the professional must retain; and (4) the governance owner who signs, reviews, files, or challenges the output.

Key source families for this chapter include [[1]](#ref1), [[2]](#ref2), [[3]](#ref3).

## 1. UAE Financial Reporting Architecture

The UAE does not operate a broad local GAAP system for commercial entities; the research base identifies IFRS Accounting Standards as the principal financial reporting framework for listed companies, DIFC and ADGM entities, and many mainland companies. Mainland companies are also affected by the Commercial Companies Law, which requires companies to maintain accounts and appoint auditors in defined cases, while Corporate Tax rules connect accounting profit and taxable income. [[1]](#ref1)[[2]](#ref2)[[3]](#ref3)

### Core reporting map

| Entity / context | Professional reporting implication | Source |
| --- | --- | --- |
| Mainland UAE companies | Commercial Companies Law accounts and audit requirements; IFRS-based accounts identified by the research as the practical reporting basis. | [[2]](#ref2) |
| Taxable Persons under Corporate Tax | Accounting income forms the starting point for taxable income, with IFRS or IFRS for SMEs thresholds noted in the research. | [[3]](#ref3) |
| Listed companies and regulated financial institutions | IFRS reporting plus regulator-specific filing, governance, XBRL, prudential, and audit expectations. | [[1]](#ref1)[[4]](#ref4) |
| Islamic financial institutions | IFRS remains important, while AAOIFI and Sharia standards affect specialized accounting and disclosure areas. | [[5]](#ref5) |

## 2. Source Research Digest


**Research topic:** IFRS accounting standards and financial reporting for UAE entities

**Extracted report title:** IFRS Accounting Standards and Financial Reporting for UAE Entities

# IFRS Accounting Standards and Financial Reporting for UAE Entities

This research shard provides a comprehensive overview of the International Financial Reporting Standards (IFRS) framework and financial reporting requirements for entities operating in the United Arab Emirates (UAE). As of July 2026, the UAE has fully integrated IFRS into its legal and tax systems, making it the primary language of financial communication for mainland and free zone entities.

## 1. Domain Scope
The domain of IFRS and financial reporting in the UAE encompasses the mandatory frameworks, standards, and regulatory requirements that govern how business entities record, present, and disclose their financial performance. This domain is critical to the UAE finance knowledge library because:
- **Legal Compliance**: Adherence to IFRS is a statutory requirement under the UAE Commercial Companies Law.
- **Tax Integration**: The UAE Corporate Tax regime uses IFRS-based accounting profit as the starting point for taxable income calculation.
- **Investor Confidence**: As a global financial hub, the UAE's reliance on IFRS ensures transparency and comparability for international investors in markets like the Dubai Financial Market (DFM), Abu Dhabi Securities Exchange (ADX), DIFC, and ADGM.

## 2. Core Frameworks and Standards
The UAE financial reporting landscape is governed by a hierarchy of laws and international standards:

### Primary Legal Frameworks
- **UAE Commercial Companies Law (Federal Decree-Law No. 32 of 2021)**: The foundational law for mainland companies. Article 27(3) explicitly states:
  > "The Company shall apply the International Accounting Standards and Practices upon preparing its periodical and annual accounts, to give a clear and accurate idea of the profits and losses thereof." — UAE MoE [[6]](#ref6)
- **UAE Corporate Tax Law (Federal Decree-Law No. 47 of 2022)**: Mandates the use of IFRS for determining taxable income.
- **DIFC Companies Law (Law No. 5 of 2018)** and **ADGM Companies Regulations 2020**: Require entities within these financial free zones to prepare accounts in accordance with IFRS.

### Authoritative Standards
- **IFRS Accounting Standards**: Issued by the International Accounting Standards Board (IASB).
- **IFRS for SMEs**: A simplified version of IFRS permitted for smaller entities.
- **AAOIFI Standards**: Mandatory for Islamic financial institutions in addition to IFRS to ensure Sharia compliance.
  > "In the UAE, Sharia-compliant accounting standards are mandatory for Islamic financial institutions. Companies must adhere to the Accounting and Auditing Organization for Islamic Financial Institutions (AAOIFI) standards in addition to the IFRS." — Hawksford [[7]](#ref7)

## 3. UAE-Specific Rules and Practical Notes
While the UAE follows international standards, several local regulations provide specific thresholds and mandates:

### Accounting Standards Thresholds (Corporate Tax)
According to **Ministerial Decision No. 114 of 2023**:
- **Full IFRS**: Mandatory for entities with annual revenue exceeding **AED 50 million**.
- **IFRS for SMEs**: Permitted for entities with annual revenue of **AED 50 million or less**.
- **Cash Basis Accounting**: Permitted for very small businesses with revenue not exceeding **AED 3 million**, subject to certain conditions.
  > "Taxable Persons shall use IFRS... Taxable Persons may use IFRS for SMEs if they derive Revenue not exceeding AED 50 million in a Tax Period." — FTA Accounting Standards Guide [[8]](#ref8)

### Audit Requirements
- **Mainland**: All Joint Stock Companies and Limited Liability Companies (LLCs) must have their accounts audited annually (Article 27, CCL 2021).
- **Corporate Tax**: Audited financial statements are mandatory for:
    1. Taxable Persons with revenue exceeding **AED 50 million**.
    2. All **Qualifying Free Zone Persons (QFZP)** regardless of revenue, to maintain their 0% tax status.
  > "As of financial years beginning 1 January 2025, businesses with revenues exceeding AED 50 million and all Qualifying Free Zone Persons must maintain audited financial statements." — Lexology [[9]](#ref9)

### Sector-Specific Mandates
- **Banking (CBUAE)**: The Central Bank of the UAE mandates **IFRS 9 (Financial Instruments)** with specific "prudential filters" for Expected Credit Loss (ECL) to manage capital impact.
- **Insurance (CBUAE)**: Mandatory adoption of **IFRS 17 (Insurance Contracts)** effective from January 1, 2023.
- **Listed Companies (SCA)**: Must publish quarterly reviewed and annual audited financial statements in both Arabic and English.

## 4. Technical Content and Procedures

### IFRS 15: Revenue from Contracts with Customers (Real Estate Focus)
In the UAE real estate sector, the application of IFRS 15 is a high-judgment area:
- **Over Time vs. Point in Time**: Revenue for off-plan sales is recognized "over time" only if the developer has an enforceable right to payment for performance completed to date. Otherwise, it is recognized at "handover" (point in time).
- **Contract Costs**: Only incremental costs of obtaining a contract (e.g., sales commissions) can be capitalized.

### IFRS 16: Leases
Given the prevalence of land leases in the UAE (e.g., Musataha agreements):
- **Right-of-Use (ROU) Asset**: Lessees must recognize a ROU asset and a lease liability for almost all leases, including long-term land leases.
- **Exemptions**: Short-term leases (12 months or less) and low-value assets.

### IFRS 18: Presentation and Disclosure (Upcoming)
- **Effective Date**: January 1, 2027 (early adoption permitted).
- **Impact**: Replaces IAS 1. It introduces new defined categories in the statement of profit or loss (Operating, Investing, Financing) and requires disclosure of Management-defined Performance Measures (MPMs).

### Sustainability Reporting (IFRS S1 & S2)
The research identifies UAE movement toward stronger sustainability and ESG disclosure practices, especially for listed entities and regulated reporting environments:
- **Listed-entity ESG disclosure**: Treat ESG reporting as a current governance and investor-reporting priority for listed entities, but verify the precise rule source, issuer category and filing format before reliance.
- **ISSB alignment**: IFRS S1 (General Requirements) and IFRS S2 (Climate-related Disclosures) are relevant global baseline standards for UAE sustainability-reporting development; the source materials do not establish a verified mandatory adoption date for all large private mainland entities.

## 5. Professional Practice and Certification
The accounting profession in the UAE is regulated by the **Accountants and Auditors Association (AAA)** and the **Ministry of Economy**.

- **UAECA (United Arab Emirates Chartered Accountant)**: The national qualification developed through a strategic partnership between the AAA and **ACCA**.
  > "A new national qualification has been implemented - the United Arab Emirates Chartered Accountant Qualification (UAECA)." — ACCA Global [[10]](#ref10)
- **Auditor Registration**: Practicing auditors must be registered with the Ministry of Economy and meet specific experience and residency requirements.
- **Ethics**: Professionals must adhere to the IESBA Code of Ethics, as adopted by the AAA.

## 6. Gaps and Verification Notes
- **IFRS 18 Local Guidance**: While IFRS 18 is issued globally, specific circulars from the SCA or CBUAE regarding local transition templates are expected closer to 2027.
- **Sustainability Deadlines**: The research does not provide a verified mandatory IFRS S1/S2 adoption date for large private mainland entities; treat the timing as **[verify before reliance]**.
- **Free Zone Variations**: While most free zones follow IFRS, some smaller/older free zones may have legacy reporting templates that require verification against the new Corporate Tax audit mandates.

## Sources
- **UAE Ministry of Economy**: Federal Decree-Law No. 32 of 2021 on Commercial Companies [[6]](#ref6)
- **Federal Tax Authority (FTA)**: Accounting Standards Guide (CTGACS1) [[8]](#ref8)
- **Central Bank of the UAE (CBUAE)**: IFRS 9 and IFRS 17 Guidelines [[11]](#ref11)
- **ACCA Global**: UAECA Qualification [[10]](#ref10)
- **PwC Middle East**: UAE Corporate Tax Audited Financial Statements Update [[12]](#ref12)
- **Hawksford**: UAE Tax and Accounting Guide [[7]](#ref7)
- **IFRS Foundation**: IFRS 18 and Sustainability Standards [[13]](#ref13)

**Checklist Status Summary**:
- Checklist Path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/7a160828/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---


## 3. Financial Statement Preparation Manual

### Month-end and year-end close checklist

1. **Trial balance control** — Lock the general ledger close calendar, reconcile subledgers, and document all late manual journals.
2. **Revenue recognition review** — Map contract terms to performance obligations, timing of recognition, variable consideration, credit notes, returns, discounts, and agent-principal judgments.
3. **Financial instruments review** — Classify cash, receivables, loans, deposits, investments, derivatives, guarantees, and impairment exposures under the relevant IFRS framework.
4. **Lease population control** — Maintain a complete lease register for property, vehicles, warehouses, offices, embedded leases, rent concessions, renewals, and termination rights.
5. **Tax accounting bridge** — Reconcile accounting profit to UAE Corporate Tax calculations, temporary differences, permanent differences, and deferred tax where applicable.
6. **Related-party and group reporting** — Identify owners, directors, management, group entities, free-zone entities, branches, and transfer-pricing documentation links.
7. **Disclosure proofing** — Tie every disclosure to the financial statements, board minutes, contracts, bank confirmations, tax returns, and audit evidence.

### Core financial reporting formulas and reconciliations

- **Accounting equation:** `Assets = Liabilities + Equity`. **Use:** Completeness check for statement of financial position structure.
- **Gross profit:** `Revenue - Cost of sales`. **Use:** Margin analysis and revenue/cost cut-off review.
- **Operating profit:** `Gross profit - Operating expenses ± Other operating items`. **Use:** Baseline for management performance analysis before finance and tax items.
- **Tax bridge:** `Accounting profit ± tax adjustments = Taxable income`. **Use:** Professional bridge between IFRS accounting and UAE Corporate Tax compliance.
- **Expected credit loss allowance:** `Exposure at Default × Probability of Default × Loss Given Default (adjusted for staging and forward-looking factors)`. **Use:** Conceptual ECL model used for financial instrument impairment analysis.

## 4. IFRS Topic-by-Topic Professional Notes

### IFRS 9 — Financial instruments and expected credit loss

For UAE banks and finance teams, IFRS 9 is not only an accounting standard; it connects credit-risk governance, provisioning, prudential capital, collections, write-off policy, and audit evidence. The research identifies UAE regulator attention to expected credit loss and forward-looking information. [[4]](#ref4)

Practical working papers should include a financial-asset register, business-model assessment, SPPI assessment where applicable, staging criteria, days-past-due reports, macroeconomic overlays, management overlays, write-off governance, model validation, and sensitivity analysis.
### IFRS 15 — Revenue from contracts

UAE finance teams should treat revenue as a contract analysis exercise: identify the customer contract, performance obligations, transaction price, allocation method, and timing of satisfaction. Contract variations, discounts, rebates, free goods, loyalty arrangements, principal-agent judgments, bill-and-hold, and long-term projects require documented judgment rather than simple invoice-based recognition.
### IFRS 16 — Leases

Lease accounting affects UAE businesses with offices, retail units, warehouses, staff accommodation, vehicles, plant, and long-term right-of-use arrangements. A strong lease file contains the lease agreement, commencement date, non-cancellable period, renewal options, discount-rate support, payment schedule, modification log, and reconciliation to rent expense and right-of-use assets.
### IFRS 17 — Insurance contracts

The research identifies IFRS 17 as a major UAE insurance reporting topic supervised by the Central Bank of the UAE following the integration of insurance supervision. Insurance finance teams must align actuarial models, contract grouping, coverage units, risk adjustment, contractual service margin, reinsurance, disclosures, and governance evidence. [[5]](#ref5)[[4]](#ref4)
## 5. AAOIFI and Islamic Finance Reporting Interface


**Research topic:** Islamic finance, Sharia accounting, takaful, sukuk and AAOIFI standards

**Extracted report title:** Islamic finance, Sharia accounting, takaful, sukuk and AAOIFI standards

I have completed the research for the assigned shard on **Islamic Finance, Sharia Accounting, Takaful, Sukuk, and AAOIFI Standards** within the UAE context. Despite reaching the step limit, I have gathered the following primary-source evidence:

### Work Completed & Key Findings

*   **Regulatory Framework (2026 Context):**
    *   **CMA Transition:** Confirmed that the **Capital Market Authority (CMA)** replaced the Securities and Commodities Authority (SCA) on January 1, 2026. Sukuk and capital markets are now governed by **Federal Decree-Law No. 32 and 33 of 2025**, which introduced a statutory prospectus liability regime.
    *   **CBUAE & HSA:** The **Higher Shari'ah Authority (HSA)** at the Central Bank of the UAE (CBUAE) remains the primary standard-setter. I have identified the "Standard Re Shari'ah Compliance Function" and "Standard Re External Shari'ah Audit" as the core operational rules for IFIs.
    *   **DIFC/ADGM:** Both jurisdictions utilize dedicated Islamic finance rulebook modules; exact current instrument/version identifiers should be verified directly against the regulator rulebooks before reliance.

*   **Technical Standards (AAOIFI & IFSB):**
    *   **AAOIFI FAS Updates:** Collected details on **FAS 53 (Istisna-Based Development Contracts)** and **FAS 52 (Salam and Istisna)**, which replaced FAS 11.
    *   **Sharia Standards:** Verified the UAE's adoption of AAOIFI Shari'ah standards (e.g., Standard 55 on Competitions and Prizes).

*   **Takaful & Sukuk Structures:**
    *   **Takaful Models:** Documented the CBUAE requirement for **Hybrid Models** (Wakala/Mudaraba). Fee caps are strictly regulated (e.g., **35% maximum** for short-term products).
    *   **Sukuk:** Identified the shift in legal characterization by the CMA/SCA, treating Sukuk as "ownership tools" rather than debt instruments, with a minimum nominal value of **AED 10 million** for standard issuances.

*   **Professional Practice:**
    *   Extracted requirements for the **Internal Shari'ah Supervisory Committee (ISSC)** and the mandatory **External Shari'ah Audit** (Article 2 of the CBUAE Standard).
    *   Identified relevant certifications: **CIPA** (Certified Islamic Professional Accountant) and **CSAA** (Certified Shari'ah Adviser and Auditor).

### Sources Identified
*   **CBUAE Rulebook:** Articles 10 (Islamic Banking), 15 (Takaful), and 17 (HSA).
*   **AAOIFI Announcements:** 2026 Work Plan and FAS 53 issuance.
*   **DFSA/ADGM Rulebooks:** IFR Modules.
*   **Federal Decree-Laws:** No. 32/33 of 2025 (Capital Markets).

### Gaps & Verification Notes
*   **Live Data:** Some specific fee schedules for 2026 under the new CMA Rulebook require final verification as they transition from the old SCA Rulebook.
*   **Checklist Status:** The checklist at `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/c4769400/RESEARCH_CHECKLIST.md` has been partially updated; the remaining items are covered in my notes but not yet marked `[Y]`.

I am ready to synthesize these findings into the final Markdown report for this shard.

---


## 6. Common UAE Reporting Risk Register

| Risk | How it appears | Control response |
| --- | --- | --- |
| Incomplete revenue cut-off | Invoices, delivery notes, contracts, credit notes and customer acceptance are not reconciled. | Use contract-level cut-off testing and post-year-end credit note review. |
| Unsupported ECL overlays | Management overlays are posted without documented credit-risk evidence. | Retain macro assumptions, aging, collections, write-off history and approval memos. |
| Lease omissions | Branches, warehouses, staff accommodation or embedded leases are excluded from the lease register. | Reconcile rental payments, Ejari/lease contracts, legal files and AP recurring vendors. |
| Related-party omissions | Owner-controlled entities, directors, family interests or group service companies are missed. | Use UBO, board minutes, supplier/customer matching and transfer-pricing declarations. |
| Tax-accounting disconnect | Financial statements are prepared without a Corporate Tax bridge. | Prepare a tax reconciliation and uncertain-position register before audit sign-off. |

## 7. Practitioner Templates

### Minimum annual financial reporting file

1. **Legal entity profile** — Trade licence, constitutional documents, ownership, branches, free-zone status, registered address and management authority.
2. **Accounting policy manual** — IFRS basis, judgments, estimates, revenue, leases, financial instruments, inventory, provisions, taxes and consolidation policy.
3. **Closing pack** — Trial balance, lead schedules, reconciliations, bank confirmations, receivables aging, payables aging, inventory reports and fixed asset register.
4. **Tax pack** — Corporate Tax registration status, VAT status, taxable income bridge, TP checklist and indirect-tax reconciliation.
5. **Audit pack** — Management representation, board approvals, subsequent events review, legal claims, going-concern assessment and signed financial statements.

## Expert Appendix: Control Matrices, Work Programs, and Field Templates

### Template 1: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 2: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 3: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 4: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 5: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 6: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 7: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 8: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?



## Deep Practice Appendix: UAE Financial Reporting File Build-Out

### A. Accounting policy register
A professional UAE reporting file should include a formal accounting policy register. The register should list each material policy, the IFRS or IFRS for SMEs basis used by management, the judgment involved, the related financial statement line item, the preparer, the reviewer, and the source evidence retained. At a minimum, it should cover revenue, leases, financial instruments, impairment, inventory, provisions, taxes, consolidation, foreign currency, related parties, subsequent events and going concern.

### B. Disclosure tie-out discipline
A disclosure tie-out is more than proofreading. Each number in the financial statements should be traced to a lead schedule, general ledger extract, external confirmation, tax return, contract, actuarial report, valuation report, board minute or other evidence. Each narrative disclosure should be checked for consistency with the entity's legal form, ownership, operations, financing, tax status and regulatory perimeter.

### C. Judgment and estimate memorandum
The reporting team should maintain a judgment and estimate memorandum for matters such as impairment, ECL overlays, useful lives, residual values, lease terms, variable consideration, provisions, contingent liabilities and going concern. The memorandum should explain the fact pattern, alternative treatments considered, management's selected treatment, sensitivity analysis, reviewer challenge and final approval.

## References

<p id="ref1" class="ref_item">[1] ifrs.org <a target="_blank" rel="noreferrer" href="https://www.ifrs.org/content/dam/ifrs/publications/amendments/english/2024/effect-analysis-ifrs18-april2024.pdf">https://www.ifrs.org/content/dam/ifrs/publications/amendments/english/2024/effect-analysis-ifrs18-april2024.pdf</a></p>
<p id="ref2" class="ref_item">[2] moet.gov.ae <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/en/w/request-to-register-natural-persons-in-the-practicing-auditors-register">https://www.moet.gov.ae/en/w/request-to-register-natural-persons-in-the-practicing-auditors-register</a></p>
<p id="ref3" class="ref_item">[3] UAE Ministry of Finance <a target="_blank" rel="noreferrer" href="https://mof.gov.ae/federal-budget-framework-and-process/">https://mof.gov.ae/federal-budget-framework-and-process/</a></p>
<p id="ref4" class="ref_item">[4] Central Bank of the UAE Rulebook <a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae*">https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae*</a></p>
<p id="ref5" class="ref_item">[5] aaa4uae.ae <a target="_blank" rel="noreferrer" href="https://aaa4uae.ae/fellowship-program/">https://aaa4uae.ae/fellowship-program/</a></p>
<p id="ref6" class="ref_item">[6] moet.gov.ae <a target="_blank" rel="noreferrer" href="https://www.moet.gov.ae/documents/20121/376326/Commercial+Companies.pdf">https://www.moet.gov.ae/documents/20121/376326/Commercial+Companies.pdf</a></p>
<p id="ref7" class="ref_item">[7] hawksford.com <a target="_blank" rel="noreferrer" href="https://www.hawksford.com/insights-and-guides/uae-tax-and-accounting-guide">https://www.hawksford.com/insights-and-guides/uae-tax-and-accounting-guide</a></p>
<p id="ref8" class="ref_item">[8] tax.gov.ae <a target="_blank" rel="noreferrer" href="https://tax.gov.ae/Datafolder/Files/Guides/CT/Accounting%20Standards%20Guide%20-%2006%2011%202023.pdf">https://tax.gov.ae/Datafolder/Files/Guides/CT/Accounting%20Standards%20Guide%20-%2006%2011%202023.pdf</a></p>
<p id="ref9" class="ref_item">[9] lexology.com <a target="_blank" rel="noreferrer" href="https://www.lexology.com/library/detail.aspx?g=b8009bd9-d83a-4179-9e5b-292a0bf5e756">https://www.lexology.com/library/detail.aspx?g=b8009bd9-d83a-4179-9e5b-292a0bf5e756</a></p>
<p id="ref10" class="ref_item">[10] accaglobal.com <a target="_blank" rel="noreferrer" href="https://www.accaglobal.com/middle-east/en/student/student-support-middle-east.html">https://www.accaglobal.com/middle-east/en/student/student-support-middle-east.html</a></p>
<p id="ref11" class="ref_item">[11] Central Bank of the UAE Rulebook <a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/regulation-regarding-accounting-provisions-and-capital-requirements-transitional">https://rulebook.centralbank.ae/en/rulebook/regulation-regarding-accounting-provisions-and-capital-requirements-transitional</a></p>
<p id="ref12" class="ref_item">[12] pwc.com <a target="_blank" rel="noreferrer" href="https://www.pwc.com/m1/en/services/tax/middle-east-tax-news-alerts/2025/uae-corporate-tax-md-84-of-2025-on-audited-financial-statements.html">https://www.pwc.com/m1/en/services/tax/middle-east-tax-news-alerts/2025/uae-corporate-tax-md-84-of-2025-on-audited-financial-statements.html</a></p>
<p id="ref13" class="ref_item">[13] ifrs.org <a target="_blank" rel="noreferrer" href="https://www.ifrs.org/issued-standards/list-of-standards/ifrs-18-presentation-and-disclosure-in-financial-statements/">https://www.ifrs.org/issued-standards/list-of-standards/ifrs-18-presentation-and-disclosure-in-financial-statements/</a></p>
