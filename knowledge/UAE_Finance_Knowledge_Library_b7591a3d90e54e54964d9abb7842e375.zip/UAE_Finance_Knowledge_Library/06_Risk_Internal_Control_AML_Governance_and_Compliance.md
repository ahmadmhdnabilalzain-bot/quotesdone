# Risk Management, Internal Control, AML/CFT, Governance, and Compliance

This chapter treats **risk management, internal control, AML/CFT, governance, and compliance in the UAE** as a professional operating manual for UAE finance teams, auditors, controllers, CFOs, compliance officers, bankers, analysts, and advisors. The UAE finance environment is not a single-rule system: it combines federal law and regulators, financial free-zone rulebooks, international standards, tax authority requirements, and sector-specific supervisory expectations. The source base used for this chapter comes from the collected research packets and prioritizes official regulators and standard setters where available.

For practical work, each topic should be read through four lenses: (1) the legal or regulatory rule that creates the obligation; (2) the accounting, audit, tax, risk, or valuation standard that determines technical treatment; (3) the evidence the professional must retain; and (4) the governance owner who signs, reviews, files, or challenges the output.

Key source families for this chapter include [[1]](#ref1), [[2]](#ref2), [[3]](#ref3).

## 1. Risk and Compliance Architecture

Risk management in UAE finance covers enterprise risk management, internal control, ICFR, fraud prevention, AML/CFT, sanctions, proliferation financing, governance codes, regulatory reporting and board oversight. The research identifies AML/CFT legal reforms, SCA governance-code amendments, CBUAE internal-control expectations, COSO preference in governance material, and FATF-related reform momentum. [[1]](#ref1)[[2]](#ref2)[[3]](#ref3)

## 2. Source Research Digest


**Research topic:** Risk management, internal control, COSO, ERM, fraud, AML/CFT and compliance

**Extracted report title:** UAE Finance Knowledge Library: Risk Management, Internal Control, and Compliance

# UAE Finance Knowledge Library: Risk Management, Internal Control, and Compliance

This research document provides a comprehensive overview of the risk management, internal control, fraud prevention, and AML/CFT landscape in the United Arab Emirates as of July 2026. It incorporates the major legislative overhauls of 2024 and 2025, including the new Federal AML Law and the updated SCA Corporate Governance Code.

## 1. Domain Scope
The domain of Risk Management, Internal Control, and Compliance is the "defensive architecture" of the UAE finance sector. It encompasses the frameworks used to identify, assess, and mitigate financial and operational risks, the systems of internal control that ensure the reliability of financial reporting, and the regulatory compliance mechanisms designed to prevent financial crimes such as money laundering, terrorism financing, and fraud.

In the UAE, this domain is critical due to the country's status as a global financial hub, which necessitates alignment with international standards (FATF, Basel, IOSCO) while addressing local legal specificities across onshore (Federal), offshore (DIFC/ADGM), and sector-specific (CBUAE/SCA) jurisdictions.

## 2. Core Frameworks and Standards

### 2.1. Anti-Money Laundering and Counter-Terrorism Financing (AML/CFT)
The UAE legal framework for AML/CFT underwent a massive transformation in late 2025.
*   **Primary Law**: **Federal Decree-Law No. 10 of 2025** Regarding Anti-Money Laundering, Combating the Financing of Terrorism, and the Financing of Proliferation (the "New AML Law"). This law repealed the 2018 legislation.
*   **Executive Regulations**: **Cabinet Resolution No. 134 of 2025**, which provides the detailed implementing rules for the New AML Law.
*   **Key Regulators**:
    *   **Executive Office for AML/CFT**: Oversees the national strategy.
    *   **Financial Intelligence Unit (FIU)**: The central agency for receiving and analyzing Suspicious Transaction Reports (STRs) via the **goAML** portal.
    *   **CBUAE, SCA, DFSA (DIFC), and FSRA (ADGM)**: Supervisory authorities for their respective sectors.

### 2.2. Internal Control and Corporate Governance
*   **SCA Corporate Governance Code**: Governs Public Joint Stock Companies (PJSCs). Significant amendments were introduced via **SCA Board Decision No. 2/RM of 2024**, mandating the adoption of global frameworks like **COSO**.
*   **CBUAE Corporate Governance Regulation for Banks**: Establishes the "Three Lines of Defense" model and requires independent risk and compliance functions.
*   **International Standards**: **COSO (2013 Internal Control / 2017 ERM)** and **ISO 31000:2018** are the preferred frameworks for risk management and internal control in the UAE.

## 3. UAE-Specific Rules and Practical Notes

### 3.1. The "New AML Law" (Law 10 of 2025) Highlights
The 2025 law introduced several "firsts" for the UAE:
*   **Proliferation Financing (PF)**: Expressly included in the legal framework to align with FATF standards.
*   **Objective Test for Knowledge**: Liability now arises if a person "actually knew or it would have been reasonable for them to have known" about the illicit nature of funds (White & Case, ). [[1]](#ref1)
*   **Virtual Assets**: Directly regulated under the framework, with strict licensing for Virtual Asset Service Providers (VASPs).
*   **Personal Liability for Managers**: Managers can be held criminally liable if a violation occurs due to a breach of their employment duties (LinkedIn, ). [[4]](#ref4)

### 3.2. Internal Control Mandates (SCA 2024 Amendments)
*   **COSO Preference**: The SCA now explicitly prefers the **COSO** framework for internal control and risk management systems in PJSCs (KPMG, ). [[5]](#ref5)
*   **Separation of Functions**: Prohibits the merging of the Compliance Officer and Internal Audit roles.
*   **External Audit Opinion**: External auditors are now increasingly required to issue a separate report opining on the effectiveness of the company's internal control and risk management framework.

### 3.3. Fraud and Financial Crime (Penal Code 2021)
*   **Federal Decree-Law No. 31 of 2021** (UAE Penal Code) defines core financial crimes:
    *   **Article 451 (Fraud)**: Using fraudulent means or a false name/capacity to deceive a victim and obtain property.
    *   **Article 453 (Breach of Trust/Embezzlement)**: Misappropriating or misusing property entrusted to a person (Chambers, ). [[6]](#ref6)
    *   **Bribery (Articles 275-286)**: Strictly prohibits public and private sector bribery, including "facilitation payments."

## 4. Technical Content: Penalties and Procedures

### 4.1. AML/CFT Penalty Matrix (Law 10 of 2025)
> "Legal persons can face fines between AED 5 million and AED 100 million, or amounts linked to the criminal property, and may be dissolved or closed." — ProactUAE [[7]](#ref7)

| Offence Type | Individual Penalty (2025 Law) | Corporate Penalty (2025 Law) |
| :--- | :--- | :--- |
| **Money Laundering** | 1-10 years prison + Fine up to AED 5M or property value | AED 5M - 100M fine |
| **Aggravated ML** | Temporary imprisonment + Fine AED 1M - 10M | Higher of AED 10M or 2x property value |
| **Tipping Off** | Prison (min 1 year) + Fine AED 100k - 500k | N/A |
| **Failure to Report** | Prison and/or Fine AED 50k - 300k | Administrative fines up to AED 5M |

### 4.2. Reporting Procedures (goAML)
*   **STR (Suspicious Transaction Report)**: Filed for completed transactions where suspicion exists.
*   **SAR (Suspicious Activity Report)**: Filed for *attempted* transactions or suspicious behavior where no transaction occurred (GRC Advisors, ). [[8]](#ref8)
*   **Timeline**: Reports must be filed "immediately" upon the formation of suspicion. In practice, regulators expect filing within 24-48 hours of the internal MLRO decision.

### 4.3. Bankruptcy and Liability (Law 51 of 2023)
The new Bankruptcy Law (effective May 2024) introduced **Article 244**, which extends liability to **de facto managers** if they were negligent in managing the company leading to its financial distress (Al Tamimi, ). [[9]](#ref9)

## 5. Professional Practice

### 5.1. The Role of the MLRO (Money Laundering Reporting Officer)
In the UAE, the MLRO is a mandatory, regulator-approved role. Responsibilities include:
*   Operating the **goAML** portal.
*   Conducting the **Annual AML Risk Assessment**.
*   Ensuring **Customer Due Diligence (CDD)** and **Enhanced Due Diligence (EDD)** for high-risk clients (PEPs, sanctioned entities).

### 5.2. Internal Audit and Risk Committees
Professionals apply the **COSO ERM** framework by:
1.  **Governance and Culture**: Setting the "tone at the top."
2.  **Strategy and Objective-Setting**: Aligning risk appetite with business goals.
3.  **Performance**: Identifying and prioritizing risks (Risk Heat Maps).
4.  **Review and Revision**: Continuous monitoring of control effectiveness.

## 6. Certification Knowledge
Key certifications recognized and often required by UAE regulators (CBUAE/DFSA/FSRA) include:
*   **CAMS (Certified Anti-Money Laundering Specialist)**: The gold standard for AML professionals in the UAE.
*   **ICA (International Compliance Association)**: Diplomas in Governance, Risk, and Compliance.
*   **CIA (Certified Internal Auditor)**: Essential for internal audit roles in listed companies.
*   **CRMA (Certification in Risk Management Assurance)**: Focused on ERM implementation.

## 7. Source Links
*   **CBUAE Rulebook [[10]](#ref10)
*   **SCA Regulations [[11]](#ref11)
*   **UAE FIU Knowledge Centre [[12]](#ref12)
*   **DFSA Rulebook [[13]](#ref13)
*   **ADGM FSRA AML Rulebook [[14]](#ref14)

## 8. Gaps and Verification Notes
*   **Executive Regulations for Law 10/2025**: While Cabinet Resolution 134/2025 is in force, sector-specific guidance (e.g., from the SCA for brokers) is still being updated to reflect the new "objective test" for knowledge.
*   **Whistleblower Protections**: While ADGM and DIFC have robust whistleblower laws, onshore federal protection is primarily governed by the Penal Code and specific sector regulations; a unified federal whistleblower law is a recommended area for follow-up.
*   **Commercial Gaming**: The inclusion of "commercial gaming" as a DNFBP sector is a new development (2025) following the establishment of the GRCRA; specific compliance manuals for this sector are currently in development.

**Checklist Status Summary**:
*   Checklist file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/48bf31f9/RESEARCH_CHECKLIST.md`
*   All items marked `[Y]`.

---


## 3. COSO Internal Control Manual

A strong control framework converts policy into repeatable evidence. For UAE finance teams, COSO-style controls should be mapped to the control environment, risk assessment, control activities, information and communication, and monitoring. The research identifies COSO as a preferred global-practice framework in UAE governance amendments. [[2]](#ref2)

### ICFR control documentation checklist

1. **Process narrative** — Document transaction flow, systems, roles, approvals, reports and interfaces.
2. **Risk-control matrix** — Map financial statement assertions to risks, controls, frequency, owner, evidence and testing method.
3. **IT general controls** — Access, change management, operations, backups, privileged users and segregation of duties.
4. **Entity-level controls** — Board oversight, audit committee, code of conduct, whistleblowing, risk management and finance competence.
5. **Deficiency evaluation** — Rate design gaps, operating failures, compensating controls, severity, remediation and disclosure impact.

### Risk measurement formulas

- **Expected loss:** `Probability of default × Loss given default × Exposure at default`. **Use:** Credit-risk loss estimate.
- **Residual risk:** `Inherent risk - Control effectiveness`. **Use:** Practical risk-rating concept for risk registers.
- **Control failure rate:** `Exceptions found ÷ Items tested`. **Use:** Control operating-effectiveness measure.
- **AML alert conversion:** `Suspicious cases escalated ÷ Alerts generated`. **Use:** Quality measure for transaction-monitoring scenarios.

## 4. AML/CFT and Financial Crime Compliance

The research identifies Federal Decree-Law No. 10 of 2025 as a major AML/CFT reform and notes explicit attention to proliferation financing, virtual assets, objective knowledge tests and manager liability. Finance professionals should treat AML not only as a compliance department topic but also as a payments, onboarding, vendor, customer, treasury and audit concern. [[1]](#ref1)
### AML/CFT control checklist

1. **Business risk assessment** — Assess customers, geographies, products, channels, transactions, delivery models and sanctions exposure.
2. **Customer due diligence** — Verify identity, beneficial ownership, purpose, source of funds, source of wealth and ongoing monitoring.
3. **Screening** — Screen customers, suppliers, employees, directors, UBOs and transactions against sanctions and adverse media.
4. **Transaction monitoring** — Use scenarios for unusual activity, structuring, rapid movement of funds, high-risk jurisdictions and trade anomalies.
5. **Suspicious reporting** — Escalate, investigate, document rationale and file required reports through prescribed channels where applicable.
6. **Training and governance** — Maintain policies, MLRO responsibilities, board reporting, independent testing and remediation evidence.

## 5. Governance and Board Oversight

The research identifies UAE governance reforms affecting board responsibilities, internal control and risk management. Finance leaders should provide the board and audit committee with dashboards on financial reporting, liquidity, tax, audit issues, internal-control deficiencies, AML indicators, fraud incidents, compliance breaches, litigation and regulatory correspondence. [[2]](#ref2)
## 6. Three Lines Model Applied to UAE Finance

| Line / layer | Typical owners | Role |
| --- | --- | --- |
| First line | Operations and finance process owners | Own controls, reconciliations, approvals, tax filings and transaction evidence. |
| Second line | Risk, compliance, tax governance, Sharia compliance where applicable | Set policies, monitor compliance, advise, challenge and report risk. |
| Third line | Internal audit | Provide independent assurance over governance, risk management and controls. |
| External assurance | External audit, regulators, Sharia auditors and specialist reviewers | Provide statutory, regulatory or specialized assurance. |

## 7. Fraud Risk Scenarios

| Scenario | Typical pattern | Control response |
| --- | --- | --- |
| Revenue manipulation | Fictitious sales, premature recognition, side letters, credit-note suppression. | Revenue analytics, contract review, cut-off testing and customer confirmations. |
| Procurement fraud | Vendor conflicts, inflated prices, split POs, kickbacks. | Vendor due diligence, three-way match, conflict declarations and spend analytics. |
| Payroll fraud | Ghost employees, unauthorized allowances, final-settlement manipulation. | HR-payroll reconciliation, bank-account checks and approval controls. |
| Treasury fraud | Unauthorized payments, altered bank details, fake invoices. | Call-back controls, bank mandate review and dual authorization. |
| Tax fraud or error | Incorrect VAT treatment, false invoices, unsupported CT positions. | Tax reconciliation, invoice validation and documented tax review. |

## Expert Appendix: Control Matrices, Work Programs, and Field Templates

### Template 1: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 2: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 3: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 4: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 5: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 6: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 7: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?


### Template 8: Professional working-paper block

**Objective.** Define the financial, regulatory, tax, audit, valuation, governance or reporting assertion being addressed. The objective should state the decision being supported, the evidence needed, the person responsible, and the review level required.

**Inputs.** Use signed contracts, regulator filings, general-ledger extracts, bank confirmations, invoices, board minutes, tax returns, management accounts, system reports, legal documents, policy manuals and correspondence available for the entity.

**Procedure.** Reconcile source records to the ledger; test mathematical accuracy; compare current period against prior period, budget and forecast; identify exceptions; obtain explanations; inspect third-party evidence; document judgments; and conclude whether the objective has been met.

**Evidence standard.** Retain original source documents, preparer sign-off, reviewer sign-off, version history, exception log, management response and final conclusion. Where a matter depends on regulation or standards, retain the relevant source reference and cite the applicable requirement.

**Common exceptions.** Missing support, inconsistent dates, unsigned contracts, unexplained manual journals, related-party omissions, undocumented management estimates, unapproved spreadsheets, stale assumptions, unreconciled balances and missing reviewer evidence.

**CFO-level question.** What decision changes if this analysis is wrong, and which control prevents that error from reaching the financial statements, tax return, board pack, audit file or regulatory submission?



## Deep Practice Appendix: Risk and Compliance Testing Library

### A. Control test design
A control test should identify the control objective, population, frequency, owner, evidence, sample selection method, attributes tested, exception criteria and conclusion. For automated controls, the test should include the system report, report parameters, access control evidence and IT general-control reliance. For manual controls, the test should include preparer and reviewer evidence.

### B. AML and sanctions investigation file
An AML investigation file should include the alert, customer profile, ownership information, transaction history, screening results, source-of-funds evidence, source-of-wealth evidence where relevant, adverse media notes, investigator conclusion, escalation decision, MLRO review, reporting decision and post-case monitoring action. The rationale for closing an alert should be as clear as the rationale for escalating one.

### C. Board risk pack
A board risk pack should summarize key risks, risk appetite breaches, control deficiencies, audit findings, regulatory correspondence, AML indicators, fraud matters, tax exposures, cyber and system-access risks, litigation, liquidity pressure and remediation status. The pack should distinguish facts, judgments, open issues and decisions required from the board or audit committee.

## References

<p id="ref1" class="ref_item">[1] whitecase.com <a target="_blank" rel="noreferrer" href="https://www.whitecase.com/insight-alert/uae-enacts-new-aml-law-what-are-key-changes-and-what-does-mean-your-business">https://www.whitecase.com/insight-alert/uae-enacts-new-aml-law-what-are-key-changes-and-what-does-mean-your-business</a></p>
<p id="ref2" class="ref_item">[2] kpmg.com <a target="_blank" rel="noreferrer" href="https://kpmg.com/ae/en/insights/tax-insights/updated-ministerial-decision-on-audited-financial-statements.html">https://kpmg.com/ae/en/insights/tax-insights/updated-ministerial-decision-on-audited-financial-statements.html</a></p>
<p id="ref3" class="ref_item">[3] Central Bank of the UAE Rulebook <a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae*">https://rulebook.centralbank.ae/en/rulebook/standards-capital-adequacy-banks-uae*</a></p>
<p id="ref4" class="ref_item">[4] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/key-changes-uaes-federal-decree-law-10-2025-amluae-vwqqf">https://www.linkedin.com/pulse/key-changes-uaes-federal-decree-law-10-2025-amluae-vwqqf</a></p>
<p id="ref5" class="ref_item">[5] KPMG <a target="_blank" rel="noreferrer" href="https://assets.kpmg.com/content/dam/kpmg/ae/pdf-2024/09/amendments-to-sca-governance-code.pdf">https://assets.kpmg.com/content/dam/kpmg/ae/pdf-2024/09/amendments-to-sca-governance-code.pdf</a></p>
<p id="ref6" class="ref_item">[6] chambers.com <a target="_blank" rel="noreferrer" href="https://chambers.com/articles/how-to-handle-breach-of-trust-cases-in-dubai-expert-guide-from-a-lawyer-in-uae">https://chambers.com/articles/how-to-handle-breach-of-trust-cases-in-dubai-expert-guide-from-a-lawyer-in-uae</a></p>
<p id="ref7" class="ref_item">[7] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/uae-amlcft-law-federal-decree-law-10-2025-guide-proactuae-mjsof">https://www.linkedin.com/pulse/uae-amlcft-law-federal-decree-law-10-2025-guide-proactuae-mjsof</a></p>
<p id="ref8" class="ref_item">[8] grcadvisors.ae <a target="_blank" rel="noreferrer" href="https://grcadvisors.ae/suspicious-activity-report/">https://grcadvisors.ae/suspicious-activity-report/</a></p>
<p id="ref9" class="ref_item">[9] tamimi.com <a target="_blank" rel="noreferrer" href="https://www.tamimi.com/news/overview-of-uaes-new-financial-restructuring-and-bankruptcy-legislation-2/">https://www.tamimi.com/news/overview-of-uaes-new-financial-restructuring-and-bankruptcy-legislation-2/</a></p>
<p id="ref10" class="ref_item">[10] Central Bank of the UAE Rulebook <a target="_blank" rel="noreferrer" href="https://rulebook.centralbank.ae/">https://rulebook.centralbank.ae/</a></p>
<p id="ref11" class="ref_item">[11] beta.sca.gov.ae <a target="_blank" rel="noreferrer" href="https://beta.sca.gov.ae/en/regulations/">https://beta.sca.gov.ae/en/regulations/</a></p>
<p id="ref12" class="ref_item">[12] uaefiu.gov.ae <a target="_blank" rel="noreferrer" href="https://uaefiu.gov.ae/en/more/knowledge-centre/">https://uaefiu.gov.ae/en/more/knowledge-centre/</a></p>
<p id="ref13" class="ref_item">[13] DFSA Rulebook <a target="_blank" rel="noreferrer" href="https://dfsaen.thomsonreuters.com/">https://dfsaen.thomsonreuters.com/</a></p>
<p id="ref14" class="ref_item">[14] en.adgm.thomsonreuters.com <a target="_blank" rel="noreferrer" href="https://en.adgm.thomsonreuters.com/rulebook/anti-money-laundering-and-sanctions-rulebook-aml">https://en.adgm.thomsonreuters.com/rulebook/anti-money-laundering-and-sanctions-rulebook-aml</a></p>
