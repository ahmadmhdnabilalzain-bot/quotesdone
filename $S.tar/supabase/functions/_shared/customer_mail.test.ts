// The customer's Messages -> e-mail channel must never show back-office mail. Pure function, no
// permissions: `deno test supabase/functions/_shared/customer_mail.test.ts`.
import { assertEquals } from 'jsr:@std/assert@1';
import { composeMailReply, isCustomerCorrespondence, isInternalMailbox, noAutoReply } from './customer_mail.ts';

Deno.test('the GoDaddy expense forward seen live on 14 Sep 2026 is excluded', () => {
  // The exact shape accountant/index.ts writes for a booked historical-sweep receipt.
  assertEquals(isCustomerCorrespondence({
    to_email: 'expenses@mail.quotesdone.com',
    owner_role: null,
    body: '[expense subscription] GoDaddy 40.95 AED on 2026-08-14 +pdf — accountant historical sweep, Resend inbound id 0000',
  }), false);
  // The same body even if the recipient were recorded differently: the tag alone excludes it.
  assertEquals(isCustomerCorrespondence({ to_email: 'info@mail.quotesdone.com', body: '[expense one-off] GoDaddy 40.95 AED' }), false);
});

Deno.test('refused, held and owned receipt rows are excluded', () => {
  assertEquals(isCustomerCorrespondence({ to_email: 'x@example.invalid', body: '[REFUSED — sender is not on app_secrets.expense_forwarders] ...' }), false);
  assertEquals(isCustomerCorrespondence({ to_email: 'x@example.invalid', body: '[HELD — no amount could be read, nothing booked] ...' }), false);
  assertEquals(isCustomerCorrespondence({ to_email: 'x@example.invalid', body: '[receipt received but NOT booked — sender not allowlisted] ...' }), false);
  assertEquals(isCustomerCorrespondence({ to_email: 'info@mail.quotesdone.com', owner_role: 'bookkeeper', body: 'hello' }), false);
});

Deno.test('mail to internal mailboxes is excluded, info@ is not', () => {
  for (const a of ['expenses@mail.quotesdone.com', 'Expenses <EXPENSES@mail.quotesdone.com>', 'docs@mail.quotesdone.com',
    'supplier@quotesdone.com', 'management@quotesdone.com', 'info@mail.quotesdone.com, expenses@mail.quotesdone.com']) {
    assertEquals(isInternalMailbox(a), true, a);
  }
  for (const a of ['info@mail.quotesdone.com', 'info@quotesdone.com', 'expenses@example.invalid', '', null]) {
    assertEquals(isInternalMailbox(a), false, String(a));
  }
});

Deno.test('a normal customer message is kept', () => {
  assertEquals(isCustomerCorrespondence({
    to_email: 'info@mail.quotesdone.com', owner_role: null,
    body: 'Hi, I posted a kitchen fit-out request yesterday — when will I see quotes?',
  }), true);
});

// ── the automatic reply (28 Sep 2026, customer_support) ─────────────────────────────────────────────
const FOUNDER = ['management@quotesdone.com', 'owner@example.invalid'];
const cust = (o: Record<string, unknown> = {}) => ({ from_email: 'zz-demo-customer@example.invalid', to_email: 'info@mail.quotesdone.com', body: 'Hello', ...o });

Deno.test('a customer writing to info@ is answered', () => {
  assertEquals(noAutoReply(cust(), FOUNDER), null);
  assertEquals(noAutoReply(cust({ raw: { auto_submitted: 'no' } }), FOUNDER), null);
});

Deno.test('the four classes the founder named are never answered', () => {
  assertEquals(noAutoReply(cust({ from_email: 'Owner@Example.invalid' }), FOUNDER), 'founder');
  assertEquals(noAutoReply(cust({ from_email: 'management@quotesdone.com' }), FOUNDER), 'founder');
  assertEquals(noAutoReply(cust({ from_email: 'security-noreply@linkedin.com' }), FOUNDER), 'no_reply'); // inbound 159, 23 Sep
  assertEquals(noAutoReply(cust({ from_email: 'no-reply@accounts.google.com' }), FOUNDER), 'no_reply');
  assertEquals(noAutoReply(cust({ from_email: 'verify@example.invalid' }), FOUNDER), 'no_reply');
  assertEquals(noAutoReply(cust({ from_email: 'MAILER-DAEMON@amazonses.com' }), FOUNDER), 'bounce');
  assertEquals(noAutoReply(cust({ raw: { content_type: 'multipart/report; report-type=delivery-status' } }), FOUNDER), 'bounce');
  assertEquals(noAutoReply(cust({ raw: { calendar: true } }), FOUNDER), 'calendar');
  assertEquals(noAutoReply(cust({ to_email: 'calendar+b3a7@mail.quotesdone.com' }), FOUNDER), 'calendar');
  assertEquals(noAutoReply(cust({ raw: { auto_submitted: 'auto-replied' } }), FOUNDER), 'auto_submitted');
  assertEquals(noAutoReply(cust({ to_email: 'expenses@mail.quotesdone.com' }), FOUNDER), 'internal');
  assertEquals(noAutoReply(cust({ from_email: 'x@mail.quotesdone.com' }), FOUNDER), 'internal');
  assertEquals(noAutoReply(cust({ from_email: '' }), FOUNDER), 'no_reply');
});

// Rulings 1195/1196 (12 Oct 2026): the passage, receipt and person sentences were removed; the body is always the
// model's reply and only the greeting and sign-off are code.
Deno.test('the e-mail is the model reply between a fixed greeting and sign-off, in the asker\'s language', () => {
  const a = composeMailReply({ lang: 'en', answer: 'You pay 3% only when you reveal.' });
  assertEquals(a, 'Hello,\n\nYou pay 3% only when you reveal.\n\nKind regards,\nThe QuotesDone Team');
  const ar = composeMailReply({ lang: 'ar', answer: 'تدفع 3% فقط عند الكشف.' });
  assertEquals(ar.startsWith('مرحباً') && ar.includes('تدفع 3% فقط عند الكشف.'), true);
});
