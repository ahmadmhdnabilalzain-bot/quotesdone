import { siteCors } from '../_shared/site_origins.ts';
// claim_lookup v2 - public "is this your company?" check for the supplier claim flow.
//
// SECURITY FIX 19 Jul 2026 ---------------------------------------------------------------------
// v1 accepted { id } - the sequential leads.id primary key - and returned company_name + emirate
// to any anonymous caller. Walking id = 1,2,3... therefore dumped the entire 20,470-row supplier
// lead database: the core commercial asset of the marketplace, and the thing the whole anonymous
// model exists to protect. It was not an authentication bug (this endpoint is public BY DESIGN -
// an invited supplier has no account yet, so there is nobody to authenticate), it was an
// IDENTIFIER bug: the lookup key was guessable.
//
// v2 accepts only leads.claim_token, an unguessable UUID added in the
// leads_claim_token_stop_enumeration migration. Guessing one is infeasible, so the endpoint stays
// public while bulk harvesting stops.
//
// The raw-id path is deliberately REMOVED rather than deprecated: zero claim invitations had been
// sent and zero leads claimed when this shipped, so nothing in the wild depends on it. Anything
// still calling with { id } is either stale internal code or someone enumerating - both of which
// we want to see, so those calls are rejected AND logged rather than silently supported.
//
// OUTREACH MUST NOW LINK WITH THE TOKEN, e.g.
//     https://quotesdone.com/claim?t=<leads.claim_token>
// Never put leads.id in a supplier invitation.
import { createClient } from 'jsr:@supabase/supabase-js@2';
import { observe, annotate } from '../_shared/observe.ts';
import { probeCaller } from '../_shared/probe_caller.ts';
const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, content-type' };
const J = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'Content-Type': 'application/json', ...CORS } });
const T0 = Date.now();

async function logRun(status: string, counts: Record<string, unknown>, note: string) {
  try {
    await admin.from('agent_runs').insert({ agent: 'claim_lookup', status, counts,
      note: String(note || '').slice(0, 500),
      started_at: new Date(T0).toISOString(), finished_at: new Date().toISOString() });
  } catch (_e) { /* never let logging break the lookup */ }
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(siteCors(observe('claim_lookup', async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: CORS });
  // KEEP-WARM (resilience_ping; 28 Sep 2026 it_engineer, supplier journey). No auth, no DB: the isolate is
  // what needs exercising. See warmPortal() in resilience_ping/index.ts.
  if (req.headers.get('x-qd-warm') === '1') return new Response(null, { status: 204 });
  try {
    const body = await req.json().catch(() => ({} as any));
    const token = String(body.token || body.t || '').trim();

    // Reject-and-log the old enumerable shape. A burst of these is a scrape in progress.
    if (!token && (body.id || body.ref)) {
      await logRun('error', { rejected_legacy_id: 1, asked_id: Number(body.id || body.ref) || null },
        'claim_lookup was called with a numeric lead id, which is no longer accepted. Until 19 Jul 2026 this returned company_name and emirate for any sequential id, allowing the whole 20,470-row supplier database to be enumerated. Either an outreach template still builds links with leads.id (fix the template to use claim_token) or someone is attempting a scrape.');
      return J({ ok: false, error: 'invalid_link', message: 'This claim link is out of date. Please use the link from your latest invitation, or contact management@quotesdone.com.' }, 400);
    }

    if (!token || !UUID_RE.test(token)) {
      // Our own hourly launch-path probe is marked fixture by its credential, never by its say-so
      // (_shared/probe_caller.ts; 7 Oct 2026, handoff 100487: 24 of 24 refusals in a day were that probe).
      return annotate(J({ ok: false, error: 'invalid_link', message: 'This claim link is not valid. Please use the link from your invitation.' }, 400),
        await probeCaller(admin, req, 'claim_lookup'));
    }

    const { data: l, error } = await admin.from('leads')
      .select('id,company_name,emirate,claimed,approval_status,permanently_closed,banned')
      .eq('claim_token', token).maybeSingle();

    if (error) {
      await logRun('error', { lookup_ok: 0 }, 'claim_lookup could not read the leads table (' + String(error.message).slice(0, 140) + '), so a supplier with a VALID invitation link was told their link is invalid. This is a database failure, not a bad link - the supplier may abandon the claim.');
      return J({ ok: false, error: 'temporarily_unavailable', message: 'We could not check this link just now. Please try again shortly.' }, 503);
    }

    // Unknown token: do not distinguish "never existed" from "closed" in the response.
    // banned is read alongside permanently_closed and answered identically -- the invitation link
    // of a sanctioned party is a working front door otherwise (founder instruction 516, 18 Sep 2026).
    // fn_supplier_screening_decide also nulls claim_token, so this is the second lock, not the only one.
    if (!l || l.permanently_closed || l.banned === true) {
      await logRun('ok', { found: 0 }, 'claim_lookup received a well-formed token that matched no available lead. With unguessable tokens this should be rare; a run of these suggests a broken outreach template rather than probing, since tokens cannot be guessed.');
      return J({ ok: false, error: 'not_found', message: 'This claim link is no longer available. Please contact management@quotesdone.com.' }, 404);
    }

    // THE CLICK IS RECORDED (21 Sep 2026, sales_engineer): the first opening of an unclaimed invitation
    // is what fn_supplier_registration_reminders_due follows up on day 2 and day 6. Only the first one
    // (`is null`), so a reload does not restart the supplier's clock. A failure here must never cost the
    // supplier the page, so it is logged and the lookup answers as before.
    // The click stamp and the run log are independent writes, so they run together (28 Sep 2026,
    // it_engineer): the supplier's answer waited on two round trips in turn.
    const stampClick = async () => {
      if (l.claimed) return;
      const { error: clickErr } = await admin.from('leads').update({ invite_clicked_at: new Date().toISOString() })
        .eq('id', l.id).is('invite_clicked_at', null);
      if (clickErr) console.error('claim_lookup: could not record the click —', clickErr.message);
    };
    await Promise.all([stampClick(), logRun('ok', { found: 1, already_claimed: l.claimed ? 1 : 0 },
      'claim_lookup resolved a valid invitation token' + (l.claimed ? ' for a lead that has ALREADY been claimed - the supplier will be told it is taken.' : ' for an unclaimed lead; the supplier can proceed to claim it.'))]);

    return J({ ok: true, company_name: l.company_name || null, emirate: l.emirate || null,
      claimable: !l.claimed, already_claimed: !!l.claimed });
  } catch (e) {
    await logRun('error', { unhandled_exception: 1 }, 'claim_lookup threw an unhandled exception: ' + String((e as Error)?.message || e).slice(0, 200) + ' - a supplier trying to claim their listing was blocked for an internal reason.');
    return J({ ok: false, error: 'error' }, 500);
  }
})));
