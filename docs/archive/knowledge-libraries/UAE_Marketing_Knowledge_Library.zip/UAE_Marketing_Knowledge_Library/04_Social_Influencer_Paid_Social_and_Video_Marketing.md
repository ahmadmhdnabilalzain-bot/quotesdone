# Social Media, Influencer, Paid Social, Video and YouTube Marketing in the UAE

**Purpose.** The social and video layer: platform roles, creator marketing, paid social, content formats, YouTube, short-form video, disclosure, filming permits and community workflows. This file is one part of a broader UAE marketing knowledge library designed for senior marketers, agency leads, founders, communications teams and operators who need a source-backed operating reference.

**How to use this file.** Start with the domain chapters for source-backed concepts and UAE-specific constraints, then use the practice appendices as implementation checklists. Treat regulatory, platform and pricing items as verification-sensitive because rules and platform policies can change.

## Category Coverage

- **Domain 05:** Social media strategy in the UAE: Instagram, TikTok, Snapchat, LinkedIn, X, Facebook, platform roles, content formats and community management
- **Domain 06:** Influencer marketing and creator economy in UAE/GCC: licensing, paid partnerships, contracts, pricing models, disclosure, whitelisting and measurement
- **Domain 08:** Paid social advertising in UAE: Meta, TikTok, Snapchat, LinkedIn, X, audience targeting, creative testing, retargeting and platform policy constraints
- **Domain 17:** Video, YouTube and short-form content marketing in UAE: production workflows, hooks, platform SEO, creator formats, paid amplification and measurement


## Domain 05: Social media strategy in the UAE: Instagram, TikTok, Snapchat, LinkedIn, X, Facebook, platform roles, content formats and community management

### Social Media Strategy in the UAE: Instagram, TikTok, Snapchat, LinkedIn, X, and Facebook

This research report provides a comprehensive overview of the social media landscape in the United Arab Emirates (UAE) as of July 2026. It covers regulatory requirements, platform-specific strategies, technical tactics, and cultural localization essential for professional marketing practice in the region.

## 1. Domain Scope and UAE Relevance
Social media in the UAE is characterized by one of the highest penetration rates globally, reaching extremely high population-level coverage, with source packets reporting social-media identities near or above the resident population (DataReportal, [[1]](#ref1)).

*   **Typical Business Use Cases**:
    *   **E-commerce**: Direct sales via TikTok Shop and Instagram Shopping.
    *   **B2B Lead Generation**: LinkedIn is the primary channel for professional services and government-linked entities.
    *   **Brand Awareness**: High-frequency video content on TikTok and Instagram Reels.
    *   **Customer Service**: WhatsApp and Facebook Messenger are the "conversion layers" for real-time inquiry resolution.
*   **Boundaries**: While social media is a dominant marketing channel, it is strictly governed by federal laws regarding content, licensing, and privacy.

## 2. UAE Legal, Regulatory, and Platform Rules
The UAE has implemented a rigorous regulatory framework for social media, particularly concerning commercial activities and influencer marketing.

### 2.1. Licensing and Permits
*   **The Two-License Rule**: For 2026 planning, individuals engaging in advertising activities on digital platforms should verify both commercial-licence and UAE Media Council advertiser-permit obligations:
    1.  **Commercial Trade License**: A business or freelance license (e.g., E-Trade license costing approx. AED 1,400).
    2.  **Advertiser Permit**: Issued by the UAE Media Council. This permit is mandatory for paid ads, brand collaborations, sponsored posts, and "gifted" products (UAE Media Council, [[2]](#ref2)).
*   **Fees and Penalties**: The Advertiser Permit is free for the first three years for UAE citizens and residents. Failure to comply can result in fines ranging from **AED 3,000 to AED 10,000** (Ahlan Live, [[3]](#ref3)).

### 2.2. Content Standards and Cybercrime Law
*   **Federal Decree-Law No. 34 of 2021 (Cybercrime Law)**: This law treats online speech with the same weight as physical conduct. Prohibited activities include defamation, online insults, spreading rumors, and privacy violations. Fines can reach **AED 1,000,000** (UAE Expert Hub, [[4]](#ref4)).
*   **TDRA Internet Guidelines**: Content must respect "public morality." Prohibited categories include nudity, pornography, and content that violates religious or cultural values (TDRA, [[5]](#ref5)).

## 3. Core Frameworks and Strategy
### 3.1. Platform Roles in the UAE (2026)
*   **Instagram**: The "Visual Storefront." Used for high-aesthetic brand storytelling and influencer collaborations.
*   **TikTok**: The "Entertainment Hub." Dominates short-form video with users spending an average of **95 minutes daily** on the app (Evokad, [[6]](#ref6)).
*   **Snapchat**: The "Private Community." Highly popular among UAE nationals (Emiratis) for peer-to-peer sharing and AR-driven brand experiences.
*   **LinkedIn**: The "Professional Authority." Essential for B2B, with 97% of B2B marketers in the region incorporating it into their strategy.
*   **Facebook**: The "Community Connector." Still holds a massive user base (18.6M identities in June 2026) and is primary for expat community groups (NapoleonCat, [[7]](#ref7)).

### 3.2. Audience Segmentation
*   **Gen Z**: Prefer YouTube (91%), Instagram (86%), and TikTok (79%).
*   **Millennials**: High usage of Facebook (89%) and Instagram (81%).
*   **Expats vs. Nationals**: Expats (approx. 88% of population) are highly active on Facebook and Instagram, while UAE Nationals show a strong preference for Snapchat and TikTok.

## 4. Technical Tactics and Workflows
### 4.1. Content Formats
*   **Short-Form Video**: Reels and TikToks are the highest-performing formats. Arabic content outperforms English by **15-25% in engagement** (The Hovi, [[8]](#ref8)).
*   **Ephemeral Content**: Instagram Stories yield **29% higher CTR** than standard feed placements (Evokad, [[6]](#ref6)).

### 4.2. Community Management Workflow
*   **Response Time**: Best practice in the UAE is to respond to every comment within **1-2 hours**, particularly on Instagram and TikTok, to satisfy algorithm requirements and high consumer expectations (Reddit, [[9]](#ref9)).
*   **Language**: Bilingual strategies (Arabic/English) are mandatory for mass-market brands.

## 5. Measurement, KPIs, and Analytics
### 5.1. Advertising Benchmarks (2025/2026)
*   **CPM (Cost Per Mille)**:
    *   **Meta (UAE)**: AED 18–40 depending on placement (Instagram Feed is typically higher than Facebook).
    *   **TikTok**: $4–$7 (Cost leader).
    *   **LinkedIn**: $33–$65 (Premium B2B targeting).
*   **CTR (Click-Through Rate)**: The platform-wide median for Facebook Ads hit **2.19% in 2025** (Rule1.ai, [[10]](#ref10)).

### 5.2. Attribution and Dashboards
*   **Share of Voice (SOV)**: Critical for competitive benchmarking in the luxury and travel sectors, where SOV benchmarks range from **25% to 40%** (Umbrex, [[11]](#ref11)).

## 6. UAE Cultural Localization and Audience Notes
### 6.1. Ramadan and Eid Strategy
*   **Spending**: UAE retail spending during Ramadan hit **$10 billion in 2025** (DMI Digital Marketing, [[12]](#ref12)).
*   **Posting Times**: Shift posting frequency to **2x daily**, with peak engagement times between **7 PM and 11 PM (Post-Iftar)** (Vybinex, [[13]](#ref13)).
*   **Acquisition**: High-value customers are often acquired **before** Ramadan begins; pre-Ramadan users show **20% higher retention** (AppsFlyer, [[14]](#ref14)).

### 6.2. Cultural Sensitivities
*   **Visuals**: Avoid imagery that contradicts local values (e.g., immodest clothing, alcohol).
*   **Language**: Use local dialects (Khaleeji) for high-engagement Emirati-focused campaigns, while Modern Standard Arabic (MSA) is used for broader regional reach.

## 7. Professional Practice and Checklists
### 7.1. Campaign Planning Checklist
*   [ ] Verify Advertiser Permit and Trade License for all influencers.
*   [ ] Ensure all sponsored content is clearly labeled (e.g., #Ad, #PaidPartnership).
*   [ ] Audit AI-driven ad placements (Advantage+ or TikTok Smart Creative) for brand safety.
*   [ ] Schedule content around prayer times and local holidays (National Day, Eid).

### 7.2. Crisis Management
*   **Response Speed**: Leading GCC organizations aim for **73% faster response times** using 24/7 monitoring systems (OBA PR, [[15]](#ref15)).

## 8. Sources
*   **DataReportal**: Digital 2025: The United Arab Emirates, [[1]](#ref1)
*   **UAE Media Council**: Advertiser Permit Services, [[2]](#ref2)
*   **TDRA**: Internet Guidelines, [[5]](#ref5)
*   **UAE Expert Hub**: UAE Social Media Laws and Fines, [[4]](#ref4)
*   **Evokad**: Social Media Advertising Platform Guide 2026, [[6]](#ref6)
*   **The Hovi**: Social Media Marketing in GCC & MENA 2026, [[8]](#ref8)
*   **AppsFlyer**: Ramadan 2026 Marketing Strategies, [[14]](#ref14)
*   **NapoleonCat**: Social Media Users in UAE 2026, [[7]](#ref7)

## 9. Gaps and Verification Notes
*   **Influencer Pricing**: Exact market rates for UAE influencers in 2026 are highly variable and often not publicly disclosed; verification via agency rate cards is recommended.
*   **Platform Policy Changes**: Meta and TikTok frequently update their AI-driven ad tools; monthly audits of campaign structures are necessary.
*   **Live Data**: Social media identity counts in the source packets are near or above the resident population, which indicates multiple identities and methodological differences rather than unique-person reach, indicating a high prevalence of multiple accounts per user which may skew reach metrics.

---
**Checklist Status Summary**:
Checklist file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/39d496c0/RESEARCH_CHECKLIST.md`
All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/39d496c0/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/39d496c0/TOOL_RESULTS.md`
- Research child tool results lines: `1354`
- Research child tool results bytes: `75751`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/39d496c0/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Social media strategy in the UAE

#### 1. Strategic diagnosis questions
A senior UAE marketing practitioner should begin by documenting the commercial context before choosing tactics. The working file should answer the following questions in plain language: what business outcome must change, which UAE audience segment is being prioritized, which emirate or free-zone context matters, whether the campaign is Arabic-first, English-first or bilingual, which legal or platform obligations apply, which channel owns demand creation, which channel owns conversion, and which data source will be treated as the source of truth. If any of those answers are unknown, the campaign should be marked as incomplete rather than pushed into execution.

#### 2. UAE compliance control checklist
Use this checklist before approving any public-facing campaign, content calendar, landing page, creator collaboration, paid advertisement, email sequence, SMS blast, WhatsApp template, marketplace listing or lead-generation form:

- Confirm the responsible legal entity, trade licence context, advertiser or media-permit obligations, and the person accountable for approval.
- Confirm whether personal data is collected, the lawful basis used, the consent capture method, opt-out wording, privacy-policy link, retention period and deletion workflow.
- Confirm whether the asset includes religious, cultural, national-symbol, public-morals, child-safety, health, financial, real-estate, education or investment claims.
- Confirm whether the content is advertising, editorial, sponsorship, affiliate promotion, employee advocacy, user-generated content, PR, or transactional communication.
- Confirm that paid, sponsored, gifted or affiliate content is visibly disclosed in the language understood by the target audience.
- Confirm that Arabic text has been reviewed by a qualified Arabic speaker and that RTL design has not broken navigation, icons, price display, form flow or CTA hierarchy.
- Confirm that campaign screenshots, approvals, consent logs, creative versions, media plans, UTMs and performance reports are archived for auditability.

#### 3. Briefing template
A strong brief for Social media strategy in the UAE should contain: campaign objective, commercial target, audience segment, emirate/geography, Arabic/English language requirements, offer, proof points, legal restrictions, brand tone, required assets, channel mix, budget range, landing destination, measurement plan, reporting cadence, approval owners and escalation path. The brief should state what cannot be claimed as clearly as what can be claimed.

#### 4. Measurement design
Before launch, define the KPI tree. At the top is the business KPI, such as qualified leads, booked consultations, revenue, repeat purchases, pipeline value or retention. The next level contains channel KPIs such as reach, impressions, CTR, CPC, CPM, engagement rate, video completion rate, form-start rate, WhatsApp-start rate, conversion rate, CPL, CPA, AOV, ROAS or LTV. The final level contains diagnostic indicators such as page speed, scroll depth, search query match, ad frequency, creative fatigue, unsubscribe rate, bounce rate, consent opt-in rate and sales-response time.

#### 5. Documentation workflow
For a professional-grade UAE marketing library, each campaign should produce a reusable knowledge asset. Archive the final brief, research notes, audience assumptions, approved copy, Arabic localization notes, creative files, landing-page screenshots, UTM naming table, consent evidence, platform configuration, launch checklist, daily monitoring notes, final report and lessons learned. This allows future teams to distinguish verified UAE market learning from assumptions.

#### 6. Common failure modes
The most common failure modes are launching English-only material for audiences who require Arabic trust signals, copying global campaigns without cultural adaptation, treating WhatsApp as an informal afterthought rather than a governed conversion channel, running paid media without a clean measurement architecture, treating influencer content as personal speech when it is advertising, using generic landing pages with weak local proof, making unsupported claims in regulated sectors, and optimizing for vanity metrics instead of qualified commercial outcomes.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no channel should be activated unless its role in the funnel is explicit, no claim should be published unless it is supportable, no data should be collected unless consent and retention are defined, no Arabic localization should be treated as mere translation, and no report should be accepted unless it explains what decision will change as a result of the data.

## Domain 06: Influencer marketing and creator economy in UAE/GCC: licensing, paid partnerships, contracts, pricing models, disclosure, whitelisting and measurement

### Influencer Marketing and Creator Economy in UAE/GCC: Research Report

## Domain Scope
Influencer marketing in the UAE and GCC has evolved from a supplementary tactic to a core pillar of the digital marketing ecosystem. As of July 2026, the UAE remains the regional hub for the creator economy, driven by high social media penetration (exceeding 99% in some demographics) and a young, mobile-first population.

- **UAE Relevance**: The UAE serves as the primary base for regional "Mega" influencers and talent management agencies. The market is characterized by a dual-language environment (Arabic and English) and a high concentration of luxury, tourism, and e-commerce-driven campaigns.
- **Business Use Cases**:
    - **E-commerce Acceleration**: Direct integration with platforms like Amazon.ae and Noon via affiliate codes and "Live Shopping" events.
    - **Brand Awareness**: High-impact "Mega" influencer partnerships for government initiatives and major retail launches (e.g., Dubai Shopping Festival).
    - **Performance Marketing**: Utilizing "Micro" and "Nano" influencers for high-engagement niche targeting and whitelisting (paid amplification of creator content).
- **Boundaries**: This domain covers paid partnerships, gifted collaborations, and affiliate marketing. It excludes organic user-generated content (UGC) that does not involve a commercial relationship or promotional intent.

## UAE Legal, Regulatory, and Platform Rules
The UAE has implemented some of the world's most structured regulations for content creators to ensure transparency and consumer protection.

### 1. Licensing Requirements
As of early 2026, a dual-licensing regime is mandatory for all influencers conducting commercial activities in the UAE.
- **Trade License**: Influencers must hold a valid commercial trade license or a freelancer permit from a relevant licensing authority (e.g., Dubai Economy and Tourism, Abu Dhabi Department of Economic Development (ADDED), or free zones like Shams or TECOM).
- **UAE Media Council (UAEMC) Advertiser Permit**: Effective February 1, 2026, all individuals publishing promotional content must obtain an "Advertiser Permit" from the UAE Media Council.
    - **Cost**: Free of charge for the first three years for UAE citizens and residents. Starting from the fourth year, an annual renewal fee of AED 1,000 applies.
    - **Visitor Permits**: Non-residents can obtain a 3-month permit for AED 500, renewable once.
    - **Fines**: Failure to obtain the permit by the January 31, 2026 deadline can result in fines ranging from AED 3,000 to AED 10,000, with severe or repeat violations reaching up to AED 1,000,000.
    - **Source**: UAE Media Council, [[2]](#ref2); Village Justice, [[16]](#ref16),55918.html

### 2. Abu Dhabi Specific Regulations (ADDED)
The Abu Dhabi Department of Economic Development (ADDED) requires influencers operating within the emirate to obtain specific permits.
- **Fees**: Individual influencers are charged AED 1,250, while businesses/agencies are charged AED 5,000 for the required licenses.
- **Source**: Imfluence, [[17]](#ref17)

### 3. Disclosure and Advertising Standards
- **Mandatory Disclosure**: All paid or gifted content must be clearly labeled. Common tags include #ad, #paidpartnership, or #sponsored. The disclosure must be "accurate and free from ambiguity" and placed prominently (not buried in a "see more" section).
- **Content Restrictions**: Content must respect UAE public morals, religious values, and national symbols. Offending religion or national symbols can trigger six-figure fines.
- **Source**: Lexology, [[18]](#ref18)

### 4. Data Privacy (UAE PDPL)
The UAE Federal Decree-Law No. 45 of 2021 on the Protection of Personal Data (PDPL) applies to influencer marketing when creators collect follower data (e.g., for giveaways or newsletters).
- **Consent**: Explicit consent is required for data processing.
- **Rights**: Individuals have the right to access, rectify, and delete their data.
- **Source**: DLA Piper, [[19]](#ref19)

## Core Frameworks and Strategy
### 1. Influencer Tiering Model (UAE Benchmarks)
| Tier | Follower Count | Typical Use Case |
| :--- | :--- | :--- |
| **Nano** | 1K – 10K | Hyper-local engagement, community trust, low cost. |
| **Micro** | 10K – 100K | Niche expertise, high engagement rates (4-7%). |
| **Macro** | 100K – 1M | Broad reach, brand association, professional production. |
| **Mega** | 1M+ | Mass awareness, celebrity status, high cost. |

### 2. Campaign Architecture
- **Discovery**: Using AI-driven platforms (e.g., IQFluence, Kolsquare) to filter by UAE-specific audience percentage (ensuring the influencer's followers are actually in the UAE).
- **Briefing**: Providing "Creative Guardrails" rather than strict scripts to maintain the creator's authentic voice.
- **Whitelisting (Paid Amplification)**: A strategic shift where brands run ads *through* the influencer's handle.
    - > "Whitelisting typically costs an additional 20–50% on top of the base influencer content rate." — Influee, [[20]](#ref20)

## Technical Tactics and Workflows
### 1. Whitelisting Workflow
- **Meta (Instagram/Facebook)**:
    1. Creator links Instagram to a Facebook Page.
    2. Brand requests "Partnership Ad" access via Meta Business Manager.
    3. Creator approves the request in their Professional Dashboard.
    4. Brand creates ads in Ads Manager using the creator's identity.
- **TikTok (Spark Ads)**:
    1. Creator enables "Ad Authorization" in TikTok settings.
    2. Creator generates a "Video Code" for a specific post.
    3. Brand enters the code in TikTok Ads Manager to promote the post.
- **Source**: Leadsie, [[21]](#ref21); TikTok, [[22]](#ref22)

### 2. Affiliate and Creator Programs
- **Amazon.ae Influencer Program**: Allows creators to build "Storefronts." Commissions range up to 9% on qualifying purchases.
- **Noon Affiliate Program**: Offers up to 10% commission on sales generated via unique links or coupon codes.
- **Source**: Amazon.ae, [[23]](#ref23); Noon, [[24]](#ref24)

## Measurement, KPIs, and Analytics
### 1. Key Performance Indicators (KPIs)
- **Engagement Rate (ER)**: (Likes + Comments + Saves + Shares) / Reach.
    - > "The average engagement rate on social media across all platforms ranges from 2.5% to 6.5%." — IQFluence, [[25]](#ref25)
- **Cost Per Engagement (CPE)**: Total Spend / Total Engagements.
- **Conversion Rate**: Percentage of users who clicked an affiliate link and made a purchase.
- **Earned Media Value (EMV)**: A dollar value assigned to the reach and engagement generated, compared to equivalent paid media costs.

### 2. Benchmarks (2026 Estimates)
- **Instagram Reels**: ~3.1% ER.
- **LinkedIn**: ~6.1% ER (highest for professional/B2B influencers).
- **TikTok**: High volatility but often delivers the lowest Cost Per View (CPV).
- **Source**: Hootsuite, [[26]](#ref26); IQFluence, [[25]](#ref25)

## UAE Cultural Localization and Audience Notes
### 1. Ramadan and Eid
- **Content Shift**: During Ramadan, content pivots toward family, spirituality, recipes (Iftar/Suhoor), and "Ramadan Majlis" events.
- **Timing**: Peak engagement shifts to late night (post-Iftar) and early morning (Suhoor).
- **Majlis Events**: Brands often host influencers in physical "Majlis" setups for interactive masterclasses and networking.
- **Source**: Campaign Middle East, [[27]](#ref27); LinkedIn, [[28]](#ref28)

### 2. Language and Demographics
- **Arabic-First Imperative**: For campaigns targeting UAE Nationals (Emiratis) and the wider GCC, high-quality Khaleeji Arabic content is essential.
- **Expat Audiences**: English-language content dominates for the large Western and Asian expat communities in Dubai and Abu Dhabi.

## Professional Practice and Checklists
### 1. Influencer Contract Checklist
- [ ] **Scope of Work**: Exact number of Stories, Reels, and Posts.
- [ ] **Usage Rights**: Duration and platforms where the brand can reuse the content.
- [ ] **Exclusivity**: Period during which the influencer cannot work with direct competitors.
- [ ] **Morality Clause**:
    - > "A morality or conduct clause allows a brand to terminate an agreement... if the creator engages in conduct the brand considers reputationally damaging." — Neo Legal, [[29]](#ref29)
- [ ] **Licensing Warranty**: Influencer must warrant they hold a valid UAEMC Advertiser Permit and Trade License.
- [ ] **Jurisdiction**: Typically Dubai International Financial Centre (DIFC) or Abu Dhabi Global Market (ADGM) for international-standard contracts.

### 2. Pricing Models
- **Pay-per-Post**: Fixed fee based on follower count and expected reach.
- **Performance-based**: Commission on sales (common for Nano/Micro).
- **Hybrid**: Small base fee + performance bonus.
- **Pricing Benchmarks (2026)**:
    - **Micro (10K-100K)**: $200 – $1,500 per Reel.
    - **Macro (100K-1M)**: $3,000 – $20,000 per Reel.
    - **Source**: IQFluence, [[30]](#ref30)

## Sources
### Primary Sources
- **UAE Media Council (UAEMC)**: Official Advertiser Permit guidelines and fees. [[2]](#ref2)
- **Amazon.ae Affiliate Program**: Participation requirements and commission rates. [[23]](#ref23)
- **Noon Affiliate Program**: Commission structure and signup process. [[24]](#ref24)
- **UAE Federal Decree-Law No. 45 of 2021 (PDPL)**: Data protection regulations. (Referenced via DLA Piper).

### Secondary Sources
- **Village Justice**: Analysis of the 2026 UAE Media Law updates. [[16]](#ref16),55918.html
- **IQFluence**: 2026 pricing and engagement benchmarks. [[30]](#ref30)
- **Neo Legal**: Legal insights on morality clauses and creator residency. [[29]](#ref29)
- **Campaign Middle East**: Strategic roadmap for Ramadan influencer marketing. [[27]](#ref27)
- **Influee**: Technical guide to influencer whitelisting. [[20]](#ref20)

## Gaps and Verification Notes
- **Live Data Verification**: While the January 31, 2026 deadline for the Advertiser Permit is widely reported, the *actual* enforcement rigor and frequency of the maximum AED 1,000,000 fine should be monitored through official UAEMC press releases.
- **Platform Changes**: Meta and TikTok frequently update their "Partnership Ads" interfaces; workflows should be verified against live platform documentation at the time of campaign launch.
- **Noon Ambassador Program**: Some sources mention a separate "Ambassador" program (ambassadors.noon.com) which may have different requirements than the standard affiliate program; this requires direct portal access to verify.

***

**Checklist Status Summary**:
- Checklist Path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/6a6aa967/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/6a6aa967/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/6a6aa967/TOOL_RESULTS.md`
- Research child tool results lines: `1118`
- Research child tool results bytes: `48221`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/6a6aa967/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Influencer marketing and creator economy in UAE/GCC

#### 1. Strategic diagnosis questions
A senior UAE marketing practitioner should begin by documenting the commercial context before choosing tactics. The working file should answer the following questions in plain language: what business outcome must change, which UAE audience segment is being prioritized, which emirate or free-zone context matters, whether the campaign is Arabic-first, English-first or bilingual, which legal or platform obligations apply, which channel owns demand creation, which channel owns conversion, and which data source will be treated as the source of truth. If any of those answers are unknown, the campaign should be marked as incomplete rather than pushed into execution.

#### 2. UAE compliance control checklist
Use this checklist before approving any public-facing campaign, content calendar, landing page, creator collaboration, paid advertisement, email sequence, SMS blast, WhatsApp template, marketplace listing or lead-generation form:

- Confirm the responsible legal entity, trade licence context, advertiser or media-permit obligations, and the person accountable for approval.
- Confirm whether personal data is collected, the lawful basis used, the consent capture method, opt-out wording, privacy-policy link, retention period and deletion workflow.
- Confirm whether the asset includes religious, cultural, national-symbol, public-morals, child-safety, health, financial, real-estate, education or investment claims.
- Confirm whether the content is advertising, editorial, sponsorship, affiliate promotion, employee advocacy, user-generated content, PR, or transactional communication.
- Confirm that paid, sponsored, gifted or affiliate content is visibly disclosed in the language understood by the target audience.
- Confirm that Arabic text has been reviewed by a qualified Arabic speaker and that RTL design has not broken navigation, icons, price display, form flow or CTA hierarchy.
- Confirm that campaign screenshots, approvals, consent logs, creative versions, media plans, UTMs and performance reports are archived for auditability.

#### 3. Briefing template
A strong brief for Influencer marketing and creator economy in UAE/GCC should contain: campaign objective, commercial target, audience segment, emirate/geography, Arabic/English language requirements, offer, proof points, legal restrictions, brand tone, required assets, channel mix, budget range, landing destination, measurement plan, reporting cadence, approval owners and escalation path. The brief should state what cannot be claimed as clearly as what can be claimed.

#### 4. Measurement design
Before launch, define the KPI tree. At the top is the business KPI, such as qualified leads, booked consultations, revenue, repeat purchases, pipeline value or retention. The next level contains channel KPIs such as reach, impressions, CTR, CPC, CPM, engagement rate, video completion rate, form-start rate, WhatsApp-start rate, conversion rate, CPL, CPA, AOV, ROAS or LTV. The final level contains diagnostic indicators such as page speed, scroll depth, search query match, ad frequency, creative fatigue, unsubscribe rate, bounce rate, consent opt-in rate and sales-response time.

#### 5. Documentation workflow
For a professional-grade UAE marketing library, each campaign should produce a reusable knowledge asset. Archive the final brief, research notes, audience assumptions, approved copy, Arabic localization notes, creative files, landing-page screenshots, UTM naming table, consent evidence, platform configuration, launch checklist, daily monitoring notes, final report and lessons learned. This allows future teams to distinguish verified UAE market learning from assumptions.

#### 6. Common failure modes
The most common failure modes are launching English-only material for audiences who require Arabic trust signals, copying global campaigns without cultural adaptation, treating WhatsApp as an informal afterthought rather than a governed conversion channel, running paid media without a clean measurement architecture, treating influencer content as personal speech when it is advertising, using generic landing pages with weak local proof, making unsupported claims in regulated sectors, and optimizing for vanity metrics instead of qualified commercial outcomes.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no channel should be activated unless its role in the funnel is explicit, no claim should be published unless it is supportable, no data should be collected unless consent and retention are defined, no Arabic localization should be treated as mere translation, and no report should be accepted unless it explains what decision will change as a result of the data.

## Domain 08: Paid social advertising in UAE: Meta, TikTok, Snapchat, LinkedIn, X, audience targeting, creative testing, retargeting and platform policy constraints

### Paid Social Advertising in the UAE: 2026 Knowledge Library Shard

## Domain Scope: Paid Social Advertising in the UAE
Paid social advertising in the United Arab Emirates (UAE) is a high-velocity marketing domain characterized by one of the world's highest social media penetration rates, with over 99% of the population expected to be active on social platforms by 2026. The domain encompasses the strategic use of paid placements on Meta (Facebook, Instagram), TikTok, Snapchat, LinkedIn, and X (formerly Twitter) to drive full-funnel objectives.

### Typical Business Use Cases
*   **Real Estate & Luxury:** Lead generation for high-ticket property investments in Dubai and Abu Dhabi, often utilizing LinkedIn for HNWIs and Meta for broad international reach.
*   **E-commerce & Retail:** Rapid-fire conversion campaigns on TikTok and Snapchat, particularly during peak shopping windows like Ramadan, White Friday, and Dubai Shopping Festival (DSF).
*   **B2B Services:** Professional networking and account-based marketing (ABM) on LinkedIn to target decision-makers in free zones like DIFC and ADGM.
*   **Tourism & Hospitality:** Visual storytelling on Instagram and TikTok to attract international tourists and domestic "staycationers."

---

## UAE Legal, Regulatory, and Platform Rules

### 1. UAE Media Council Advertiser Permit (Effective Feb 1, 2026)
The UAE Media Council has introduced a mandatory regulatory framework for all advertising activities on digital platforms.
*   **Requirement:** Any individual or entity engaging in advertising on social media—whether for financial compensation, brand collaborations, or "gifted" products—must hold a valid **Advertiser Permit**.
*   **Licensing:** UAE citizens and residents must obtain a trade license for electronic media from relevant authorities (e.g., DED) before applying for the permit.
*   **Duration:** 1 year for residents (renewable); 3 months for visitors (must be applied for via a licensed UAE agency).
*   **Compliance:** The permit number must be clearly displayed on social media accounts.
*   **Source:** *Advertiser Permit – UAE Media Council, [[31]](#ref31)

### 2. UAE Personal Data Protection Law (PDPL)
Federal Decree-Law No. 45 of 2021 (PDPL) governs the processing of personal data for UAE residents.
*   **Retargeting Pixels:** IP addresses, browsing behavior, and device identifiers collected by Meta Pixels or TikTok Pixels are classified as personal data.
*   **Consent Standards:** Explicit, informed, and unambiguous consent is required. Loading tracking pixels without a Consent Management Platform (CMP) or cookie banner is a potential violation.
*   **Breach Notification:** Businesses must notify the UAE Data Office within 72 hours of discovering a data breach.
*   **Source:** *UAE PDPL Compliance for Digital Marketing 2025, [[32]](#ref32)

### 3. Content Standards and Prohibitions
Advertising content must adhere to the UAE's cultural and religious values (Federal Law No. 15 on Media Regulation).
*   **Prohibited Categories:** Alcohol, gambling, tobacco, pork products, and content offensive to Islamic values or the UAE government are strictly banned.
*   **Platform-Specific Restrictions:**
    *   **Snapchat:** Explicitly prohibits targeting ads that promote or reference alcohol to the UAE.
    *   **X (Twitter):** Permits lottery ads with strict restrictions but prohibits most other gambling content.
    *   **Meta:** Requires prior written permission for dating ads and online gambling (where permitted by local law, though generally restricted in UAE).
*   **Source:** *Snap Advertising Policies, [[33]](#ref33); X Ads policies, [[34]](#ref34)

### 4. Cybercrime Law (Federal Decree-Law No. 34 of 2021)
*   **Misleading Ads:** Article 48 penalizes the use of information networks to mislead consumers with fines between **AED 20,000 and AED 500,000**.
*   **Source:** *Federal Decree-Law No. (34) of 2021 On Countering Rumors and Cybercrimes, [[35]](#ref35)

---

## Core Frameworks and Strategy

### 1. Audience Segmentation in the UAE
The UAE's demographic mix (approx. 88% expats) requires a multi-layered targeting strategy.
*   **Expats vs. Nationals:** Source packets describe a very large expatriate majority and a smaller Emirati citizen population; verify the latest demographic estimates before using precise counts.
*   **Language:** Campaigns should ideally be dual-language. Arabic is essential for reaching locals and GCC expats, while English serves the broader international community.
*   **Source:** *United Arab Emirates (UAE) Population Statistics 2026 | GMI, [[36]](#ref36)

### 2. Channel Planning Matrix
| Platform | Primary UAE Use Case | Key Demographic |
| :--- | :--- | :--- |
| **Meta** | Broad reach, E-commerce, Lead Gen | Diverse Expats, Families |
| **TikTok** | Viral trends, Gen Z/Millennial engagement | Youth, Content Creators |
| **Snapchat** | High engagement with UAE Nationals | Emiratis, Khaleeji audience |
| **LinkedIn** | B2B, Recruitment, Professional Services | Decision-makers, Professionals |
| **X (Twitter)** | Real-time news, Government, Tech | News-seekers, Tech-savvy |

---

## Technical Tactics and Workflows

### 1. Creative Testing and Fatigue
Due to the relatively small geographic size of the UAE, ad frequency builds quickly, leading to "creative fatigue."
*   **Workflow:** Implement a "Weekly Creative Refresh" for high-spend campaigns.
*   **Tactic:** Use User-Generated Content (UGC) creators to produce scalable, authentic video assets for TikTok and Meta.

### 2. Advanced Attribution Compliance
To maintain tracking accuracy under PDPL:
*   **Google Consent Mode v2:** Adjusts tag behavior based on user consent; uses modeled data for non-consenting users.
*   **Meta Conversions API (CAPI):** Server-side tracking to bypass browser-based pixel limitations and improve data reliability.
*   **Source:** *UAE PDPL Compliance for Digital Marketing 2025, [[32]](#ref32)

---

## Measurement, KPIs, and Analytics

### 2026 Market Benchmarks
*   **Meta (Facebook/Instagram):** Median CTR of **2.19%** and median CPM of **$14.19** (early 2026 data).
*   **LinkedIn:** Average Cost Per Lead (CPL) reached **$94** in 2026, up from $87 in 2025. CPMs have risen by **38%** YoY due to increased competition.
*   **X (Twitter):** Ad reach equivalent to **25.0%** of the total population.
*   **Source:** *Facebook Ads Benchmarks 2026, [[10]](#ref10); LinkedIn Ads Benchmarks 2026, [[37]](#ref37)

---

## UAE Cultural Localization and Audience Notes

### 1. Ramadan and Eid Strategy
*   **Timing:** Screen time increases significantly after Iftar. Peak engagement occurs between **8:00 PM and 1:00 AM**.
*   **Creative:** Use symbols like the crescent moon, lanterns (Fanous), and dates. Focus on themes of family, charity, and reflection.
*   **Vertical Trends:** E-commerce peaks early in Ramadan; travel and finance apps build momentum toward Eid.
*   **Source:** *Ramadan 2026 social media marketing UAE, [[38]](#ref38)

### 2. Language Nuances
*   **Arabic Localization:** Avoid "Google Translate" Arabic. Use Modern Standard Arabic (MSA) for formal brands or the "White Dialect" (a mix of Gulf and Levantine) for more relatable, social-first content.

---

## Professional Practice and Checklists

### Campaign Launch Checklist (UAE)
1.  **[ ] Licensing:** Confirm the brand or influencer has a valid UAE Media Council Advertiser Permit.
2.  **[ ] PDPL Compliance:** Ensure the website has a functional CMP and Google Consent Mode v2 is active.
3.  **[ ] Content Audit:** Verify no prohibited items (alcohol, pork, etc.) are visible in creative assets.
4.  **[ ] Language Check:** Ensure Arabic copy is culturally nuanced and right-to-left (RTL) formatting is correct.
5.  **[ ] Targeting:** Exclude sensitive religious/political interests to avoid platform flagging.
6.  **[ ] Attribution:** Verify Meta CAPI and TikTok Events API are firing correctly.

---

## Sources

### Primary Sources
*   **UAE Media Council:** *Advertiser Permit*, [[2]](#ref2)
*   **UAE Government Portal:** *Data Protection Laws*, [[39]](#ref39)
*   **UAE Legislation:** *Federal Decree-Law No. (34) of 2021 On Countering Rumors and Cybercrimes*, [[40]](#ref40)
*   **Meta Transparency Center:** *Advertising Standards*, [[41]](#ref41)
*   **Snap Inc.:** *Snap Advertising Policies*, [[33]](#ref33)
*   **LinkedIn Legal:** *Advertising Policies*, [[42]](#ref42)

### Secondary Sources
*   **Global Media Insight (GMI):** *UAE Population Statistics 2026*, [[43]](#ref43)
*   **DataReportal:** *Digital 2026: The United Arab Emirates*, [[44]](#ref44)
*   **Imperium Global Media:** *UAE PDPL Compliance for Digital Marketing*, [[45]](#ref45)
*   **Digital Applied:** *LinkedIn Ads Benchmarks 2026*, [[46]](#ref46)
*   **Rule1.ai:** *Facebook Ads Benchmarks 2026*, [[10]](#ref10)

---

## Gaps and Verification Notes
*   **Live Data:** CPM and CPC benchmarks fluctuate monthly; Q4 2026 data will require fresh extraction closer to the date.
*   **Enforcement:** While the Advertiser Permit is mandated for Feb 2026, the strictness of enforcement for small-scale business owners (vs. influencers) is still being observed.
*   **TikTok UAE Policies:** Specific TikTok UAE prohibited content pages occasionally return 404 errors; verification via the general TikTok Business Help Center is recommended.

**Checklist Status Summary:**
*   Checklist Path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d997b61c/RESEARCH_CHECKLIST.md`
*   All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d997b61c/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d997b61c/TOOL_RESULTS.md`
- Research child tool results lines: `1519`
- Research child tool results bytes: `75313`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d997b61c/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Paid social advertising in UAE

#### 1. Strategic diagnosis questions
A senior UAE marketing practitioner should begin by documenting the commercial context before choosing tactics. The working file should answer the following questions in plain language: what business outcome must change, which UAE audience segment is being prioritized, which emirate or free-zone context matters, whether the campaign is Arabic-first, English-first or bilingual, which legal or platform obligations apply, which channel owns demand creation, which channel owns conversion, and which data source will be treated as the source of truth. If any of those answers are unknown, the campaign should be marked as incomplete rather than pushed into execution.

#### 2. UAE compliance control checklist
Use this checklist before approving any public-facing campaign, content calendar, landing page, creator collaboration, paid advertisement, email sequence, SMS blast, WhatsApp template, marketplace listing or lead-generation form:

- Confirm the responsible legal entity, trade licence context, advertiser or media-permit obligations, and the person accountable for approval.
- Confirm whether personal data is collected, the lawful basis used, the consent capture method, opt-out wording, privacy-policy link, retention period and deletion workflow.
- Confirm whether the asset includes religious, cultural, national-symbol, public-morals, child-safety, health, financial, real-estate, education or investment claims.
- Confirm whether the content is advertising, editorial, sponsorship, affiliate promotion, employee advocacy, user-generated content, PR, or transactional communication.
- Confirm that paid, sponsored, gifted or affiliate content is visibly disclosed in the language understood by the target audience.
- Confirm that Arabic text has been reviewed by a qualified Arabic speaker and that RTL design has not broken navigation, icons, price display, form flow or CTA hierarchy.
- Confirm that campaign screenshots, approvals, consent logs, creative versions, media plans, UTMs and performance reports are archived for auditability.

#### 3. Briefing template
A strong brief for Paid social advertising in UAE should contain: campaign objective, commercial target, audience segment, emirate/geography, Arabic/English language requirements, offer, proof points, legal restrictions, brand tone, required assets, channel mix, budget range, landing destination, measurement plan, reporting cadence, approval owners and escalation path. The brief should state what cannot be claimed as clearly as what can be claimed.

#### 4. Measurement design
Before launch, define the KPI tree. At the top is the business KPI, such as qualified leads, booked consultations, revenue, repeat purchases, pipeline value or retention. The next level contains channel KPIs such as reach, impressions, CTR, CPC, CPM, engagement rate, video completion rate, form-start rate, WhatsApp-start rate, conversion rate, CPL, CPA, AOV, ROAS or LTV. The final level contains diagnostic indicators such as page speed, scroll depth, search query match, ad frequency, creative fatigue, unsubscribe rate, bounce rate, consent opt-in rate and sales-response time.

#### 5. Documentation workflow
For a professional-grade UAE marketing library, each campaign should produce a reusable knowledge asset. Archive the final brief, research notes, audience assumptions, approved copy, Arabic localization notes, creative files, landing-page screenshots, UTM naming table, consent evidence, platform configuration, launch checklist, daily monitoring notes, final report and lessons learned. This allows future teams to distinguish verified UAE market learning from assumptions.

#### 6. Common failure modes
The most common failure modes are launching English-only material for audiences who require Arabic trust signals, copying global campaigns without cultural adaptation, treating WhatsApp as an informal afterthought rather than a governed conversion channel, running paid media without a clean measurement architecture, treating influencer content as personal speech when it is advertising, using generic landing pages with weak local proof, making unsupported claims in regulated sectors, and optimizing for vanity metrics instead of qualified commercial outcomes.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no channel should be activated unless its role in the funnel is explicit, no claim should be published unless it is supportable, no data should be collected unless consent and retention are defined, no Arabic localization should be treated as mere translation, and no report should be accepted unless it explains what decision will change as a result of the data.

## Domain 17: Video, YouTube and short-form content marketing in UAE: production workflows, hooks, platform SEO, creator formats, paid amplification and measurement

### Collector Report: Video, YouTube, and Short-Form Content Marketing in the UAE (July 2026)

This report provides a comprehensive overview of the video marketing landscape in the UAE, focusing on regulatory compliance, platform-specific statistics, production workflows, and cultural localization strategies.

#### 1. Domain Scope and UAE Relevance
Video marketing in the UAE is a primary driver of digital engagement, fueled by one of the world's highest smartphone penetration rates. As of 2026, social media user identities account for **112.3% of the population (11.5 million)**, with residents spending an average of **2 hours and 58 minutes daily** on social platforms.
*   **Typical Use Cases**: Luxury real estate tours (Dubai/Abu Dhabi), Ramadan brand storytelling, government service awareness, and influencer-led social commerce.
*   **Boundaries**: Includes long-form YouTube content, short-form (TikTok/Reels/Snapchat), and paid video amplification.

#### 2. UAE Legal, Regulatory, and Platform Rules
The regulatory environment for video content is strictly governed by federal laws and local authorities.
*   **UAE Media Council (UAEMC) Advertiser Permit**: Effective February 1, 2026, any individual (citizen, resident, or visitor) publishing advertising content online must obtain an **Advertiser Permit**. 
    *   *Cost*: Free for the first three years for UAE citizens and residents.
    *   *Requirement*: Must be linked to a valid UAE trade or freelance license.
    *   *Disclosure*: Permit numbers must be clearly displayed on social media accounts.
*   **TDRA Prohibited Content**: The Telecommunications and Digital Government Regulatory Authority (TDRA) enforces 19 prohibited content categories under the Internet Access Management Policy. Prohibited content includes:
    *   Contempt of religion or the Divine.
    *   Offenses against the UAE, its symbols, or public order.
    *   Promotion of gambling, tobacco, or illegal communication activities.
    *   Defamation and impersonation.
*   **Filming Permits**: 
    *   **Dubai**: Managed by the Dubai Film and TV Commission (DFTC). Commercial filming requires a permit; foreign crews must work with a UAE-licensed production partner.
    *   **Abu Dhabi**: Managed by the Abu Dhabi Film Commission (ADFC) and twofour54.
*   **Drone Regulations**: All drones must be registered via the **GCAA UAS Gateway**. Commercial aerial filming requires project-specific permits from the GCAA and local bodies (DCAA in Dubai). As of March 2026, recreational drone use remains suspended in Dubai.

#### 3. Core Frameworks and Strategy
*   **Hero-Hub-Help (HHH) Model**: Localized for the UAE market.
    *   *Hero*: Large-scale campaigns around national events (UAE National Day, Dubai Shopping Festival).
    *   *Hub*: Consistent short-form series (e.g., "Weekly Dubai Eats" or "Abu Dhabi Tech Trends").
    *   *Help*: Educational/How-to content in Arabic and English (e.g., "How to apply for a Golden Visa").
*   **Audience Segmentation**: 
    *   **Gen Z**: 56% use TikTok daily; prefer raw, unpolished "behind-the-scenes" content.
    *   **Expats vs. Nationals**: Content must balance Western-style aesthetics with Khaleeji cultural nuances.

#### 4. Technical Tactics and Workflows
*   **YouTube SEO (UAE Focus)**:
    *   *Keywords*: High-intent Arabic keywords (e.g., "أفضل مطاعم دبي" - Best Dubai Restaurants) and English equivalents.
    *   *Localization*: Use of `.ae` domains for linked sites and geo-tagging specific districts (DIFC, JLT, Saadiyat Island).
*   **Short-Form Hooks**: UAE audiences "judge content within the first 2 to 3 seconds." Effective hooks include "POV: You live in Dubai" or "Hidden gems in Sharjah."
*   **Production Workflow**:
    1.  Scripting (Bilingual: Arabic/English).
    2.  Permit Acquisition (UAEMC/DFTC).
    3.  Filming (Adhering to public decency laws).
    4.  Post-Production (Mobile-first vertical formats).

#### 5. Measurement, KPIs, and Analytics
*   **YouTube Ads Benchmarks (Q1 2026)**:
    *   **TrueView CPM**: $11.42 (Average).
    *   **Non-Skippable CPM**: $14.85.
    *   **Bumper Ads (6s) CPM**: $9.20.
    *   **Average CTR**: ~0.65%.
*   **Platform Reach**: TikTok leads in reach (142.7% penetration), followed by YouTube (80.3%) and Instagram (80.1%).

#### 6. UAE Cultural Localization and Audience Notes
*   **Bilingualism**: Mastery of bilingual content (scripts and captions switching between Arabic and English) is a major trend for 2026.
*   **Ramadan/Eid**: 20% YoY increase in search interest for "sustainability" during Ramadan. Brands are expected to showcase social responsibility.
*   **Visual Standards**: Avoid filming sensitive government buildings or individuals without consent (Federal Decree-Law No. 34 of 2021).

#### 7. Professional Practice and Checklists
*   **Pre-Filming Checklist**:
    *   [ ] Valid UAEMC Advertiser Permit?
    *   [ ] Trade/Freelance License active?
    *   [ ] Location permits secured (DFTC/ADFC)?
    *   [ ] Drone registered and flight permit approved?
    *   [ ] Content audited for 19 TDRA prohibited categories?

#### Sources
*   **UAE Media Council (UAEMC)**: Advertiser Permit Guidelines, [[47]](#ref47)
*   **DataReportal**: Digital 2026: The United Arab Emirates, [[44]](#ref44)
*   **Global Media Insight**: UAE Social Media Statistics 2024/2026, [[48]](#ref48)
*   **TDRA**: Internet Access Management Policy, [[49]](#ref49)
*   **GCAA**: UAS Gateway Drone Regulations, [[50]](#ref50)

#### Gaps and Verification Notes
*   **NMC vs. UAEMC**: The National Media Council (NMC) has transitioned to the UAE Media Council (UAEMC); some older documents still reference NMC standards.
*   **19 Standards List**: While the TDRA's 19 prohibited categories are well-documented, the UAEMC's specific "19 Advertising Standards" are often cited as a subset of the broader media law (Decree-Law 55/2023).
*   **Live Data**: Ad benchmarks (CPM/CTR) fluctuate; Q1 2026 figures should be re-verified quarterly.

**Checklist Status Summary**:
*   Checklist Path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d284a37b/RESEARCH_CHECKLIST.md`
*   All items marked **[Y]**.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d284a37b/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d284a37b/TOOL_RESULTS.md`
- Research child tool results lines: `2603`
- Research child tool results bytes: `146832`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d284a37b/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Video, YouTube and short-form content marketing in UAE

#### 1. Strategic diagnosis questions
A senior UAE marketing practitioner should begin by documenting the commercial context before choosing tactics. The working file should answer the following questions in plain language: what business outcome must change, which UAE audience segment is being prioritized, which emirate or free-zone context matters, whether the campaign is Arabic-first, English-first or bilingual, which legal or platform obligations apply, which channel owns demand creation, which channel owns conversion, and which data source will be treated as the source of truth. If any of those answers are unknown, the campaign should be marked as incomplete rather than pushed into execution.

#### 2. UAE compliance control checklist
Use this checklist before approving any public-facing campaign, content calendar, landing page, creator collaboration, paid advertisement, email sequence, SMS blast, WhatsApp template, marketplace listing or lead-generation form:

- Confirm the responsible legal entity, trade licence context, advertiser or media-permit obligations, and the person accountable for approval.
- Confirm whether personal data is collected, the lawful basis used, the consent capture method, opt-out wording, privacy-policy link, retention period and deletion workflow.
- Confirm whether the asset includes religious, cultural, national-symbol, public-morals, child-safety, health, financial, real-estate, education or investment claims.
- Confirm whether the content is advertising, editorial, sponsorship, affiliate promotion, employee advocacy, user-generated content, PR, or transactional communication.
- Confirm that paid, sponsored, gifted or affiliate content is visibly disclosed in the language understood by the target audience.
- Confirm that Arabic text has been reviewed by a qualified Arabic speaker and that RTL design has not broken navigation, icons, price display, form flow or CTA hierarchy.
- Confirm that campaign screenshots, approvals, consent logs, creative versions, media plans, UTMs and performance reports are archived for auditability.

#### 3. Briefing template
A strong brief for Video, YouTube and short-form content marketing in UAE should contain: campaign objective, commercial target, audience segment, emirate/geography, Arabic/English language requirements, offer, proof points, legal restrictions, brand tone, required assets, channel mix, budget range, landing destination, measurement plan, reporting cadence, approval owners and escalation path. The brief should state what cannot be claimed as clearly as what can be claimed.

#### 4. Measurement design
Before launch, define the KPI tree. At the top is the business KPI, such as qualified leads, booked consultations, revenue, repeat purchases, pipeline value or retention. The next level contains channel KPIs such as reach, impressions, CTR, CPC, CPM, engagement rate, video completion rate, form-start rate, WhatsApp-start rate, conversion rate, CPL, CPA, AOV, ROAS or LTV. The final level contains diagnostic indicators such as page speed, scroll depth, search query match, ad frequency, creative fatigue, unsubscribe rate, bounce rate, consent opt-in rate and sales-response time.

#### 5. Documentation workflow
For a professional-grade UAE marketing library, each campaign should produce a reusable knowledge asset. Archive the final brief, research notes, audience assumptions, approved copy, Arabic localization notes, creative files, landing-page screenshots, UTM naming table, consent evidence, platform configuration, launch checklist, daily monitoring notes, final report and lessons learned. This allows future teams to distinguish verified UAE market learning from assumptions.

#### 6. Common failure modes
The most common failure modes are launching English-only material for audiences who require Arabic trust signals, copying global campaigns without cultural adaptation, treating WhatsApp as an informal afterthought rather than a governed conversion channel, running paid media without a clean measurement architecture, treating influencer content as personal speech when it is advertising, using generic landing pages with weak local proof, making unsupported claims in regulated sectors, and optimizing for vanity metrics instead of qualified commercial outcomes.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no channel should be activated unless its role in the funnel is explicit, no claim should be published unless it is supportable, no data should be collected unless consent and retention are defined, no Arabic localization should be treated as mere translation, and no report should be accepted unless it explains what decision will change as a result of the data.


## Category Appendix: Social and Creator Production System

### Content pillar system
A UAE social program should balance authority, utility, social proof, culture, offer, community and entertainment. For each pillar, define the platform, format, hook type, proof point, CTA, disclosure need, Arabic/English versioning and moderation plan.

### Creator selection framework
Creators should be evaluated by audience fit, content quality, compliance readiness, disclosure behavior, brand safety, past sponsor density, comment quality, geographic relevance, language authenticity and performance evidence. Follower count alone should not decide selection.

### Video QA checklist
Before publishing video, verify hook clarity in the first seconds, safe use of music and footage, filming permissions where needed, modesty and cultural fit, visible disclosures, platform-safe claims, subtitles, Arabic/English accessibility, CTA clarity, landing destination and measurement tags.

## File-Level Verification Notes

- This file is based on source collector packets generated in July 2026.
- Do not treat third-party benchmark numbers, platform fee claims or social-media screenshots as permanent rules; verify them before budget approval or legal reliance.
- For regulated sectors such as real estate, healthcare, finance, education, insurance and investment promotions, obtain current sector-specific approval guidance before launch.

## References

<p id="ref1" class="ref_item"><a target="_blank" rel="noreferrer" href="https://datareportal.com/reports/digital-2025-united-arab-emirates">[1] datareportal.com</a></p>
<p id="ref2" class="ref_item"><a target="_blank" rel="noreferrer" href="https://uaemc.gov.ae/en/%D8%AA%D8%B5%D8%B1%D9%8A%D8%AD-%D9%85%D8%B9%D9%84%D9%86/">[2] uaemc.gov.ae</a></p>
<p id="ref3" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.instagram.com/reel/DUKTfBZiIuV/">[3] instagram.com</a></p>
<p id="ref4" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.uaeexperthub.com/uae-social-media-laws-and-fines/">[4] uaeexperthub.com</a></p>
<p id="ref5" class="ref_item"><a target="_blank" rel="noreferrer" href="https://tdra.gov.ae/en/about/tdra-sectors/information-and-digital-government/policy-and-programs-department/internet-guidelines">[5] tdra.gov.ae</a></p>
<p id="ref6" class="ref_item"><a target="_blank" rel="noreferrer" href="https://evokad.com/social-media-advertising-guide-2026/">[6] evokad.com</a></p>
<p id="ref7" class="ref_item"><a target="_blank" rel="noreferrer" href="https://stats.napoleoncat.com/social-media-users-in-united_arab_emirates/2026/">[7] stats.napoleoncat.com</a></p>
<p id="ref8" class="ref_item"><a target="_blank" rel="noreferrer" href="https://thehovi.com/blog/industry-guides/social-media-marketing-gcc-mena-guide-2026">[8] thehovi.com</a></p>
<p id="ref9" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.reddit.com/r/ecommercemarketing/comments/1r0ikst/social_media_community_management_best_practices/">[9] reddit.com</a></p>
<p id="ref10" class="ref_item"><a target="_blank" rel="noreferrer" href="https://rule1.ai/articles/facebook-ads-benchmarks">[10] rule1.ai</a></p>
<p id="ref11" class="ref_item"><a target="_blank" rel="noreferrer" href="https://umbrex.com/resources/ultimate-guide-to-company-analysis/ultimate-guide-to-marketing-analysis/share-of-voice-analysis/">[11] umbrex.com</a></p>
<p id="ref12" class="ref_item"><a target="_blank" rel="noreferrer" href="https://dmidigitalmarketing.com/ramadan-2026-a-marketing-strategy-guide-for-uae-brands/">[12] dmidigitalmarketing.com</a></p>
<p id="ref13" class="ref_item"><a target="_blank" rel="noreferrer" href="https://vybinex.com/blog/ramadan-marketing-strategy-uae-2026">[13] vybinex.com</a></p>
<p id="ref14" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.appsflyer.com/blog/measurement-analytics/ramadan-2026-gulf-strategy/">[14] appsflyer.com</a></p>
<p id="ref15" class="ref_item"><a target="_blank" rel="noreferrer" href="https://obapr.com/resources/crisis-management-playbook-for-middle-east-companies-2026-complete-guide/">[15] obapr.com</a></p>
<p id="ref16" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.village-justice.com/articles/licence-influenceur-aux-emirats-arabes-unis-2026-comprendre-respecter-les">[16] village-justice.com</a></p>
<p id="ref17" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.imfluence.ae/blogs/abu-dhabi-influencers-must-obtain-licenses-for-influencer-marketing-services">[17] imfluence.ae</a></p>
<p id="ref18" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.lexology.com/library/detail.aspx?g=fc922d9b-8ca9-4e93-9479-e644d512458e">[18] lexology.com</a></p>
<p id="ref19" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.dlapiperdataprotection.com/countries/uae-general/law.html">[19] dlapiperdataprotection.com</a></p>
<p id="ref20" class="ref_item"><a target="_blank" rel="noreferrer" href="https://influee.co/blog/influencer-whitelisting">[20] influee.co</a></p>
<p id="ref21" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.leadsie.com/blog/allowlist-whitelist-influencer-meta-ads">[21] leadsie.com</a></p>
<p id="ref22" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.tiktok.com/@sailawaymedia/video/7358989274110364974">[22] tiktok.com</a></p>
<p id="ref23" class="ref_item"><a target="_blank" rel="noreferrer" href="https://affiliate-program.amazon.ae/">[23] affiliate-program.amazon.ae</a></p>
<p id="ref24" class="ref_item"><a target="_blank" rel="noreferrer" href="https://affiliates.noon.com/">[24] affiliates.noon.com</a></p>
<p id="ref25" class="ref_item"><a target="_blank" rel="noreferrer" href="https://iqfluence.io/public/blog/social-media-benchmarks">[25] iqfluence.io</a></p>
<p id="ref26" class="ref_item"><a target="_blank" rel="noreferrer" href="https://blog.hootsuite.com/average-engagement-rate/">[26] blog.hootsuite.com</a></p>
<p id="ref27" class="ref_item"><a target="_blank" rel="noreferrer" href="https://campaignme.com/roadmap-for-ramadan-influencer-marketing/">[27] campaignme.com</a></p>
<p id="ref28" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/ramadan-uae-influencer-scene-vibes-views-giving-back-socialeyeme-ykpcf">[28] linkedin.com</a></p>
<p id="ref29" class="ref_item"><a target="_blank" rel="noreferrer" href="https://neolegal.ae/neolegal_creator">[29] neolegal.ae</a></p>
<p id="ref30" class="ref_item"><a target="_blank" rel="noreferrer" href="https://iqfluence.io/public/blog/cost-of-influencer-marketing">[30] iqfluence.io</a></p>
<p id="ref31" class="ref_item"><a target="_blank" rel="noreferrer" href="https://uaemc.gov.ae/en/%D8%AA%D8%B5%D8%B1%D9%8A%D8%AD-%D9%85%D8%B9%D9%84%D9%86/*">[31] uaemc.gov.ae</a></p>
<p id="ref32" class="ref_item"><a target="_blank" rel="noreferrer" href="https://imperiumglobalmedia.com/uae-pdpl-compliance-for-digital-marketing/*">[32] imperiumglobalmedia.com</a></p>
<p id="ref33" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.snap.com/ad-policies">[33] snap.com</a></p>
<p id="ref34" class="ref_item"><a target="_blank" rel="noreferrer" href="https://business.x.com/en/help/ads-policies*">[34] business.x.com</a></p>
<p id="ref35" class="ref_item"><a target="_blank" rel="noreferrer" href="https://assets.adgm.com/download/assets/Federal+DecreeLaw+No+34+of+2021+On+Countering+Rumors+and+Cybercrimes.pdf*">[35] assets.adgm.com</a></p>
<p id="ref36" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.globalmediainsight.com/blog/uae-population-statistics/*">[36] globalmediainsight.com</a></p>
<p id="ref37" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.digitalapplied.com/blog/linkedin-ads-benchmarks-2026-cpc-ctr-cvr-industry*">[37] digitalapplied.com</a></p>
<p id="ref38" class="ref_item"><a target="_blank" rel="noreferrer" href="https://nfinity8.com/uae-social-media-marketing-best-practices-ramadan-2026/*">[38] nfinity8.com</a></p>
<p id="ref39" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws">[39] u.ae</a></p>
<p id="ref40" class="ref_item"><a target="_blank" rel="noreferrer" href="https://assets.adgm.com/download/assets/Federal+DecreeLaw+No+34+of+2021+On+Countering+Rumors+and+Cybercrimes.pdf">[40] assets.adgm.com</a></p>
<p id="ref41" class="ref_item"><a target="_blank" rel="noreferrer" href="https://transparency.meta.com/policies/ad-standards/">[41] transparency.meta.com</a></p>
<p id="ref42" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.linkedin.com/legal/ads-policy">[42] linkedin.com</a></p>
<p id="ref43" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.globalmediainsight.com/blog/uae-population-statistics/">[43] globalmediainsight.com</a></p>
<p id="ref44" class="ref_item"><a target="_blank" rel="noreferrer" href="https://datareportal.com/reports/digital-2026-united-arab-emirates">[44] datareportal.com</a></p>
<p id="ref45" class="ref_item"><a target="_blank" rel="noreferrer" href="https://imperiumglobalmedia.com/uae-pdpl-compliance-for-digital-marketing/">[45] imperiumglobalmedia.com</a></p>
<p id="ref46" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.digitalapplied.com/blog/linkedin-ads-benchmarks-2026-cpc-ctr-cvr-industry">[46] digitalapplied.com</a></p>
<p id="ref47" class="ref_item"><a target="_blank" rel="noreferrer" href="https://uaemc.gov.ae/en/تصريح-معلن/">[47] uaemc.gov.ae</a></p>
<p id="ref48" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.globalmediainsight.com/blog/uae-social-media-statistics/">[48] globalmediainsight.com</a></p>
<p id="ref49" class="ref_item"><a target="_blank" rel="noreferrer" href="https://tdra.gov.ae/en/About/tdra-policies/internet-access-management-policy">[49] tdra.gov.ae</a></p>
<p id="ref50" class="ref_item"><a target="_blank" rel="noreferrer" href="https://uas.gcaa.gov.ae">[50] uas.gcaa.gov.ae</a></p>
