# Regulation, Governance, PR, Crisis Communications and Marketing Operations in the UAE

**Purpose.** The governance layer of UAE marketing: legal permissions, content standards, data protection, crisis communications, procurement, agency management, budgeting and professional competency. This file is one part of a broader UAE marketing knowledge library designed for senior marketers, agency leads, founders, communications teams and operators who need a source-backed operating reference.

**How to use this file.** Start with the domain chapters for source-backed concepts and UAE-specific constraints, then use the practice appendices as implementation checklists. Treat regulatory, platform and pricing items as verification-sensitive because rules and platform policies can change.

## Category Coverage

- **Domain 01:** UAE marketing legal and regulatory framework: media law, advertising standards, consumer protection, PDPL, influencer licensing and platform obligations
- **Domain 14:** Public relations, corporate communications and crisis communications in UAE: media relations, press releases, reputation, government/cultural sensitivity
- **Domain 18:** Marketing operations, budgeting, agency management and professional competency: briefs, scopes, retainers, procurement, KPIs, certifications and career pathways


## Domain 01: UAE marketing legal and regulatory framework: media law, advertising standards, consumer protection, PDPL, influencer licensing and platform obligations

This collector report provides a comprehensive overview of the UAE's marketing legal and regulatory framework as of July 2026. It covers the primary laws, influencer licensing requirements, advertising standards, and data protection rules essential for professional marketing practice in the UAE.

### UAE Marketing Legal and Regulatory Framework

## Domain Scope and UAE Relevance
The marketing legal and regulatory domain in the UAE encompasses the rules governing how brands, agencies, and individuals communicate promotional messages to the public. In the UAE's highly digitalized economy, this framework is critical for maintaining social harmony, protecting consumer rights, and ensuring data privacy. 

**Typical Business Use Cases:**
- **Influencer Campaigns:** Navigating the mandatory licensing for social media promotions.
- **Data-Driven Marketing:** Ensuring compliance with the Federal Personal Data Protection Law (PDPL) for email and SMS campaigns.
- **Brand Positioning:** Aligning creative content with UAE cultural and religious values to avoid legal penalties.
- **E-commerce:** Complying with consumer protection laws regarding transparent pricing and advertising.

**Boundaries:**
The framework applies to all promotional activities conducted within the UAE (mainland and free zones) and those targeting UAE residents from abroad. It excludes purely private communications but includes any content that can be perceived as promotional, even if "gifted" or unpaid.

## UAE Legal, Regulatory, and Platform Rules

### 1. Primary Regulators
- **UAE Media Council (UAEMC):** The central authority for media licensing, content standards, and influencer permits. It now carries the central federal media-regulatory role; use current UAE Media Council sources for live licensing requirements.
- **Telecommunications and Digital Government Regulatory Authority (TDRA):** Regulates electronic communications, including SMS marketing and spam.
- **Ministry of Economy:** Oversees consumer protection and competition laws.
- **UAE Data Office:** The regulator for the Personal Data Protection Law (PDPL).

### 2. Key Laws and Regulations
- **Federal Decree-Law No. 55 of 2023 on Media Regulation:** The foundational law for all media activities, including digital and social media.
- **Cabinet Resolution No. 23 of 2017 Regarding Media Content:** Sets the 20 national standards for media and advertising content.
- **Federal Decree-Law No. 45 of 2021 (PDPL):** Regulates the processing of personal data for marketing purposes.
- **Federal Law No. 15 of 2020 on Consumer Protection:** Prohibits misleading advertisements and mandates the use of Arabic in marketing.

### 3. Influencer Licensing (Advertiser Permit)
As of **February 1, 2026**, all individuals engaging in advertising activities on digital platforms must hold a valid **Advertiser Permit** issued by the UAE Media Council.
- **Scope:** Covers paid ads, brand collaborations, sponsored posts, and "gifted" products.
- **Cost:** The permit is **free for the first 3 years** for UAE citizens and residents. For others, costs vary based on the trade license setup (approx. AED 1,250 - 5,000).
- **Requirement:** Influencers must first obtain a **Trade License** or Freelance Permit before applying for the Advertiser Permit.
- **Penalties:** Fines for non-compliance range from **AED 3,000 to AED 10,000**, with potential account suspension.
> "Effective February 1, 2026, the UAE Media Council has mandated that all people engaging in advertising activities on digital platforms must hold a valid Advertiser Permit." — UAE Media Council, [[1]](#ref1)

### 4. Media Content Standards (The 20 Points)
Advertisements must comply with 20 national standards, including:
1. Respecting the Divine Entity and Islamic beliefs.
2. Respecting the State's governance system and symbols.
3. Respecting the cultural heritage and national identity of the UAE.
4. Avoiding content that harms the State's foreign relations.
5. Not spreading rumors or misleading news.
6. Respecting the culture, identity, and values of the UAE.
7. Taking into account the **Age Rating System** (G, PG, PG13, PG15, 15+, 18+).
8. Respecting children's rights.

### 5. Data Privacy and Consent (PDPL)
- **Consent:** Marketing communications require explicit, clear, and revocable consent from the data subject.
- **Right to Object:** Individuals have the right to stop the processing of their data for direct marketing (Article 27).
- **Spam Regulation:** TDRA mandates that SMS marketing must include an "opt-out" mechanism (e.g., "Ball D" to 1666).

## Core Frameworks and Strategy

### Compliance-First Strategy
In the UAE, legal compliance is not a secondary check but a core strategic pillar.
- **Risk Assessment:** Marketers must audit every campaign against the 20 Content Standards.
- **Licensing Audit:** Brands must verify that every influencer they partner with holds both a Trade License and an Advertiser Permit.
- **Language Strategy:** Mandating Arabic in all consumer-facing data and advertising per Article 26 of the Consumer Protection Law.

### Channel Planning
- **SMS/Email:** Must be anchored in a verified opt-in database with clear unsubscribe paths.
- **Social Media:** Requires disclosure of "Paid Partnership" or "Ad" tags, even for gifted items.
- **Gaming/Gambling:** Gaming, lottery, betting and prize-promotion advertising should be treated as high-risk and verified against current UAE regulator and Google Ads rules before launch.

## Technical Tactics and Workflows

### Influencer Partnership Workflow
1. **Verification:** Check the influencer's Advertiser Permit number.
2. **Contracting:** Include clauses mandating compliance with UAE Media Council standards.
3. **Disclosure:** Ensure the influencer uses platform-native disclosure tools (e.g., Instagram's "Paid Partnership" tag).
4. **Content Review:** Pre-approve content to ensure no religious or cultural sensitivities are breached.

### SMS Marketing Compliance
- **Sender ID:** Must be registered with TDRA through a licensed telecom provider (Etisalat or Du).
- **Timing:** Marketing SMS should generally be sent between 9:00 AM and 9:00 PM to avoid being classified as intrusive.
- **Opt-out:** Every message must contain a clear instruction to unsubscribe.

## Measurement, KPIs, and Analytics

### Compliance KPIs
- **Permit Verification Rate:** % of partners with valid licenses.
- **Disclosure Compliance:** % of posts correctly tagged as "Ad" or "Paid Partnership."
- **Opt-out Rate:** Number of unsubscribes per campaign (monitored for spam risk).
- **Regulatory Inquiries:** Number of flags or notices received from UAEMC or TDRA.

### Performance Benchmarks
- **Arabic vs. English Engagement:** Measuring the impact of localized content on different demographic segments.
- **Ramadan Engagement Spikes:** Tracking the 20-40% increase in social media usage during the holy month.

## UAE Cultural Localization and Audience Notes

### Religious and Cultural Sensitivities
- **Islam:** No content should disrespect Islamic values. Avoid imagery of pigs, alcohol (unless specifically permitted in restricted contexts), or immodest clothing.
- **National Symbols:** The UAE Flag, National Anthem, and Rulers must be treated with the utmost respect. Commercial use of the flag requires specific approvals.
- **Ramadan:** Marketing shifts to themes of charity, family, and reflection. Advertising for food and drink is restricted during fasting hours in public spaces.

### Audience Segmentation
- **Emirati Nationals:** Prefer high-quality Arabic content, luxury positioning, and themes of national pride.
- **Expat Communities:** Highly diverse; requires English-first or multi-lingual strategies (Tagalog, Hindi, Urdu) depending on the target segment.

## Professional Practice and Checklists

### Campaign Launch Checklist
- [ ] Does the content respect the 20 Media Content Standards?
- [ ] Is the Advertiser Permit for all influencers verified?
- [ ] Is there an Arabic version of the advertisement (mandatory for consumer protection)?
- [ ] Has the data been collected via explicit consent (PDPL)?
- [ ] Does the SMS campaign include an opt-out mechanism?
- [ ] Is the content age-rated if applicable?

### Vendor Management
- Agencies must provide proof of their own media licenses.
- Contracts should indemnify the brand against regulatory fines caused by vendor non-compliance.

## Source Links
- **UAE Media Council - Media Content Standards:** [[[2]](#ref2)]([[2]](#ref2))
- **UAE Government - Data Protection Laws:** [[[3]](#ref3)]([[3]](#ref3))
- **UAE Government - Consumer Protection:** [[[4]](#ref4)]([[4]](#ref4))
- **TDRA - Unsolicited Electronic Communications:** [[[5]](#ref5)]([[5]](#ref5))
- **Google Ads Policy - Gambling in UAE:** [[[6]](#ref6)]([[6]](#ref6))

## Gaps and Verification Notes
- **Executive Regulations for PDPL:** While the law is in effect, specific executive regulations for certain sectors are still being updated; marketers should monitor the UAE Data Office for new circulars.
- **Influencer Permit Costs for Visitors:** While resident costs are clear, the exact fee structure for short-term visitor permits via agencies can vary by agency.
- **AI in Advertising:** New guidelines regarding AI-generated content and deepfakes in advertising are expected from the Media Council in late 2026.

### Checklist Status Summary
- Checklist path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/ad891ae2/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/ad891ae2/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/ad891ae2/TOOL_RESULTS.md`
- Research child tool results lines: `2641`
- Research child tool results bytes: `129992`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/ad891ae2/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for UAE marketing legal and regulatory framework

#### 1. Strategic diagnosis questions
A senior UAE marketing practitioner should begin by documenting the commercial context before choosing tactics. The working file should answer the following questions in plain language: what business outcome must change, which UAE audience segment is being prioritized, which emirate or free-zone context matters, whether the campaign is Arabic-first, English-first or bilingual, which legal or platform obligations apply, which channel owns demand creation, which channel owns conversion, and which data source will be treated as the source of truth. If any of those answers are unknown, the campaign should be marked as incomplete rather than pushed into execution.

#### 2. UAE compliance control checklist
Use this checklist before approving any public-facing campaign, content calendar, landing page, creator collaboration, paid advertisement, email sequence, SMS blast, WhatsApp template, marketplace listing or lead-generation form:

- Confirm the responsible legal entity, trade licence context, advertiser or media-permit obligations, and the person accountable for approval.
- Confirm whether personal data is collected, the lawful basis used, the consent capture method, opt-out wording, privacy-policy link, retention period and deletion workflow.
- Confirm whether the asset includes religious, cultural, national-symbol, public-morals, child-safety, health, financial, real-estate, education or investment claims.
- Confirm whether the content is advertising, editorial, sponsorship, affiliate promotion, employee advocacy, user-generated content, PR, or transactional communication.
- Confirm that paid, sponsored, gifted or affiliate content is visibly disclosed in the language understood by the target audience.
- Confirm that Arabic text has been reviewed by a qualified Arabic speaker and that RTL design has not broken navigation, icons, price display, form flow or CTA hierarchy.
- Confirm that campaign screenshots, approvals, consent logs, creative versions, media plans, UTMs and performance reports are archived for auditability.

#### 3. Briefing template
A strong brief for UAE marketing legal and regulatory framework should contain: campaign objective, commercial target, audience segment, emirate/geography, Arabic/English language requirements, offer, proof points, legal restrictions, brand tone, required assets, channel mix, budget range, landing destination, measurement plan, reporting cadence, approval owners and escalation path. The brief should state what cannot be claimed as clearly as what can be claimed.

#### 4. Measurement design
Before launch, define the KPI tree. At the top is the business KPI, such as qualified leads, booked consultations, revenue, repeat purchases, pipeline value or retention. The next level contains channel KPIs such as reach, impressions, CTR, CPC, CPM, engagement rate, video completion rate, form-start rate, WhatsApp-start rate, conversion rate, CPL, CPA, AOV, ROAS or LTV. The final level contains diagnostic indicators such as page speed, scroll depth, search query match, ad frequency, creative fatigue, unsubscribe rate, bounce rate, consent opt-in rate and sales-response time.

#### 5. Documentation workflow
For a professional-grade UAE marketing library, each campaign should produce a reusable knowledge asset. Archive the final brief, research notes, audience assumptions, approved copy, Arabic localization notes, creative files, landing-page screenshots, UTM naming table, consent evidence, platform configuration, launch checklist, daily monitoring notes, final report and lessons learned. This allows future teams to distinguish verified UAE market learning from assumptions.

#### 6. Common failure modes
The most common failure modes are launching English-only material for audiences who require Arabic trust signals, copying global campaigns without cultural adaptation, treating WhatsApp as an informal afterthought rather than a governed conversion channel, running paid media without a clean measurement architecture, treating influencer content as personal speech when it is advertising, using generic landing pages with weak local proof, making unsupported claims in regulated sectors, and optimizing for vanity metrics instead of qualified commercial outcomes.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no channel should be activated unless its role in the funnel is explicit, no claim should be published unless it is supportable, no data should be collected unless consent and retention are defined, no Arabic localization should be treated as mere translation, and no report should be accepted unless it explains what decision will change as a result of the data.

## Domain 14: Public relations, corporate communications and crisis communications in UAE: media relations, press releases, reputation, government/cultural sensitivity

### Public Relations, Corporate Communications, and Crisis Communications in the UAE

This research report covers the regulatory, strategic, and cultural landscape of Public Relations (PR) and Corporate Communications in the United Arab Emirates as of July 2026. It incorporates the latest legislative updates, including Federal Decree-Law No. 55 of 2023 and Cabinet Resolution No. 42 of 2025.

## Domain Scope
Public Relations in the UAE is a highly regulated professional domain that bridges corporate reputation management with national strategic narratives. It encompasses media relations, government communications, crisis management, and corporate social responsibility (CSR).
- **UAE Relevance**: PR is central to the UAE’s "soft power" strategy and economic diversification (Operation 300bn). It is used by government entities to communicate national progress and by the private sector to navigate a multicultural market.
- **Business Use Cases**: IPO communications (e.g., ADX/DFM listings), crisis mitigation during regional instability or environmental events, and cultural localization for multinational brands.
- **Boundaries**: PR is distinct from advertising but increasingly overlaps with "Advertiser Permits" for influencer-led PR campaigns. It is strictly governed by media content standards that prohibit content harmful to national unity or religious values.

## UAE Legal, Regulatory, and Platform Rules
The UAE media landscape underwent a major overhaul with the enforcement of new laws in 2024 and 2025.

### Primary Regulators
- **UAE Media Council (UAEMC)**: The federal authority responsible for media legislation, licensing, and content standards.
- **National Emergency Crisis and Disasters Management Authority (NCEMA)**: Oversees communication protocols during national emergencies.
- **Media Regulatory Office (MRO)**: Manages operational licensing and media-related free zones.

### Key Legislation
- **Federal Decree-Law No. 55 of 2023 on Media Regulation**: The foundational law regulating all media activities, including digital platforms and PR agencies. It mandates that all media individuals and institutions comply with national standards (Source: UAE Media Council, [[7]](#ref7)).
- **Cabinet Resolution No. 42 of 2025**: Outlines administrative violations and penalties. Serious violations of media content standards can result in fines up to **AED 1 million** (Source: Clyde & Co, [[8]](#ref8)).
- **Federal Decree-Law No. 34 of 2021 (Cybercrimes Law)**: Strictly prohibits the spread of rumors, "fake news," or content that harms the state's reputation (Source: UAE Government Portal, [[9]](#ref9)).

### Licensing and Permits
- **PR Agency Licensing**: Agencies must obtain a trade license from the relevant Department of Economic Development (DED) or Free Zone authority, plus a media license from the UAE Media Council.
- **Advertiser Permit (2026 compliance requirement)**: Any individual (including PR professionals or influencers) publishing promotional content online must hold a valid Advertiser Permit.
  - **Cost**: Free for 3 years for UAE citizens/residents; requires a trade license.
  - **Validity**: 1 year for residents; 3 months for visitors (Source: UAE Media Council, [[10]](#ref10)).

## Core Frameworks and Strategy
### The UAE Model in Crisis Media Management
NCEMA and the UAE Government Media Office utilize a proactive framework for crisis communication:
1. **Frontline Tool**: Communication is treated as a frontline response tool, not a support function.
2. **Centralized Narrative**: Coordination through the "Government Communication Network" to ensure a unified message across federal entities.
3. **Proactive Misinformation Containment**: Using AI-driven tools to detect and counter rumors before they escalate (Source: Campaign Middle East, [[11]](#ref11)).

### Audience Segmentation
- **Emirati Nationals**: Focus on national pride, heritage, and "Vision 2031" alignment.
- **Expat Professionals**: Focus on ease of business, safety, and lifestyle.
- **International Investors**: Focus on regulatory transparency and economic stability.

## Technical Tactics and Workflows
### Media Relations and WAM Submission
The **Emirates News Agency (WAM)** is the primary channel for official announcements.
- **Workflow**: PR agencies must register with WAM to submit press releases. Content is often submitted in both Arabic and English to ensure maximum reach across the 19 languages WAM supports (Source: WAM, [[12]](#ref12)).
- **WAM Editor**: A digital tool allowing journalists and agencies to publish and manage stories remotely (Source: UAE Government Portal, [[13]](#ref13)).

### Press Release Standards
- **Inverted Pyramid**: Essential for UAE journalists who often face high volumes of content.
- **Bilingual Strategy**: Simultaneous release in high-quality Arabic (Modern Standard) and English is mandatory for Tier-1 media coverage.

## Measurement, KPIs, and Analytics
The UAE PR industry follows the **Barcelona Principles 3.0**, as promoted by the Middle East Public Relations Association (MEPRA).
- **Key KPIs**:
  - **Share of Voice (SOV)**: Comparison against competitors in local Arabic and English titles.
  - **Sentiment Analysis**: Specifically tuned for Khaleeji Arabic nuances and sarcasm, which standard global tools often misinterpret (Source: AI Taggers, [[14]](#ref14)).
  - **Message Resonance**: Tracking the adoption of specific "Strategic Narratives" (e.g., sustainability during COP28 legacy projects).
- **Avoidance of AVE**: MEPRA explicitly discourages Advertising Value Equivalency (AVE) in favor of outcome-based metrics (Source: MEPRA, [[15]](#ref15)).

## UAE Cultural Localization and Audience Notes
### Naming Conventions and Protocol
PR professionals must adhere to strict protocol for addressing leadership:
- **President**: "His Highness Sheikh Mohamed bin Zayed Al Nahyan, President of the United Arab Emirates."
- **Vice President/Ruler of Dubai**: "His Highness Sheikh Mohammed bin Rashid Al Maktoum."
- **Ministers**: Often addressed as "His Excellency" (H.E.).
- **Naming Order**: Use the full name in the first mention; never use just the first name for leadership (Source: UAE Embassy, [[16]](#ref16)).

### Cultural Sensitivities
- **Religious Holidays**: PR activity should pivot to community and charity themes during Ramadan. Avoid "hard sell" tactics.
- **Visual Content**: Must respect local dress codes and avoid imagery that could be perceived as offensive to Islamic values.

## Professional Practice and Checklists
### Media Training Checklist for UAE Executives
- [ ] **Protocol Briefing**: Ensure the spokesperson knows the correct titles for UAE leaders.
- [ ] **Legal Awareness**: Briefing on the Cybercrimes Law to avoid accidental "rumor-mongering."
- [ ] **Language Prep**: If the executive is non-Arabic speaking, ensure a high-quality translator is present for Arabic media.
- [ ] **National Agenda Alignment**: Can the announcement be linked to UAE's 2031 or 2071 goals?

### Reputation Risk Control
- **Pre-approval**: All media content must be vetted against the **Media Content Standards** (Source: UAE Media Council, [[2]](#ref2)).
- **Crisis Manual**: Must include a direct contact list for NCEMA and the relevant Emirate's Media Office (e.g., Dubai Media Office).

## Sources
- **UAE Media Council**: Media Legislation and Content Standards, [[7]](#ref7)
- **UAE Government Portal**: Media Regulation and Cybercrimes Law, [[9]](#ref9)
- **Clyde & Co**: Analysis of Cabinet Resolution No. 42 of 2025, [[8]](#ref8)
- **MEPRA**: Measurement and Evaluation Standards, [[15]](#ref15)
- **WAM (Emirates News Agency)**: Agency Profile and Services, [[12]](#ref12)
- **Campaign Middle East**: UAE Government Media Office Guidelines, [[11]](#ref11)

## Gaps and Verification Notes
- **Specific Fine Amounts**: While the maximum fine is AED 1 million, the specific "Table No. 2" of Cabinet Resolution No. 42 of 2025 (listing exact fines for each violation type) is often only available in the full Arabic Gazette or through legal subscription services.
- **WAM Portal Registration**: The exact technical URL for the PR agency registration portal is often gated behind a login; agencies typically contact `wamnews@eim.ae` for initial setup.
- **2026 Advertiser Permit Enforcement**: The deadline is January 31, 2026. Live monitoring of enforcement actions after this date is recommended for future updates.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a06f337/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a06f337/TOOL_RESULTS.md`
- Research child tool results lines: `1498`
- Research child tool results bytes: `60854`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a06f337/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Public relations, corporate communications and crisis communications in UAE

#### 1. Strategic diagnosis questions
A senior UAE marketing practitioner should begin by documenting the commercial context before choosing tactics. The working file should answer the following questions in plain language: what business outcome must change, which UAE audience segment is being prioritized, which emirate or free-zone context matters, whether the campaign is Arabic-first, English-first or bilingual, which legal or platform obligations apply, which channel owns demand creation, which channel owns conversion, and which data source will be treated as the source of truth. If any of those answers are unknown, the campaign should be marked as incomplete rather than pushed into execution.

#### 2. UAE compliance control checklist
Use this checklist before approving any public-facing campaign, content calendar, landing page, creator collaboration, paid advertisement, email sequence, SMS blast, WhatsApp template, marketplace listing or lead-generation form:

- Confirm the responsible legal entity, trade licence context, advertiser or media-permit obligations, and the person accountable for approval.
- Confirm whether personal data is collected, the lawful basis used, the consent capture method, opt-out wording, privacy-policy link, retention period and deletion workflow.
- Confirm whether the asset includes religious, cultural, national-symbol, public-morals, child-safety, health, financial, real-estate, education or investment claims.
- Confirm whether the content is advertising, editorial, sponsorship, affiliate promotion, employee advocacy, user-generated content, PR, or transactional communication.
- Confirm that paid, sponsored, gifted or affiliate content is visibly disclosed in the language understood by the target audience.
- Confirm that Arabic text has been reviewed by a qualified Arabic speaker and that RTL design has not broken navigation, icons, price display, form flow or CTA hierarchy.
- Confirm that campaign screenshots, approvals, consent logs, creative versions, media plans, UTMs and performance reports are archived for auditability.

#### 3. Briefing template
A strong brief for Public relations, corporate communications and crisis communications in UAE should contain: campaign objective, commercial target, audience segment, emirate/geography, Arabic/English language requirements, offer, proof points, legal restrictions, brand tone, required assets, channel mix, budget range, landing destination, measurement plan, reporting cadence, approval owners and escalation path. The brief should state what cannot be claimed as clearly as what can be claimed.

#### 4. Measurement design
Before launch, define the KPI tree. At the top is the business KPI, such as qualified leads, booked consultations, revenue, repeat purchases, pipeline value or retention. The next level contains channel KPIs such as reach, impressions, CTR, CPC, CPM, engagement rate, video completion rate, form-start rate, WhatsApp-start rate, conversion rate, CPL, CPA, AOV, ROAS or LTV. The final level contains diagnostic indicators such as page speed, scroll depth, search query match, ad frequency, creative fatigue, unsubscribe rate, bounce rate, consent opt-in rate and sales-response time.

#### 5. Documentation workflow
For a professional-grade UAE marketing library, each campaign should produce a reusable knowledge asset. Archive the final brief, research notes, audience assumptions, approved copy, Arabic localization notes, creative files, landing-page screenshots, UTM naming table, consent evidence, platform configuration, launch checklist, daily monitoring notes, final report and lessons learned. This allows future teams to distinguish verified UAE market learning from assumptions.

#### 6. Common failure modes
The most common failure modes are launching English-only material for audiences who require Arabic trust signals, copying global campaigns without cultural adaptation, treating WhatsApp as an informal afterthought rather than a governed conversion channel, running paid media without a clean measurement architecture, treating influencer content as personal speech when it is advertising, using generic landing pages with weak local proof, making unsupported claims in regulated sectors, and optimizing for vanity metrics instead of qualified commercial outcomes.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no channel should be activated unless its role in the funnel is explicit, no claim should be published unless it is supportable, no data should be collected unless consent and retention are defined, no Arabic localization should be treated as mere translation, and no report should be accepted unless it explains what decision will change as a result of the data.

## Domain 18: Marketing operations, budgeting, agency management and professional competency: briefs, scopes, retainers, procurement, KPIs, certifications and career pathways

### Marketing Operations, Budgeting, and Professional Competency in the UAE (July 2026)

This research covers the operational, financial, and professional standards for marketing in the United Arab Emirates, focusing on agency management, procurement, budgeting, and career pathways as of July 2026.

## Domain Scope and UAE Relevance
Marketing Operations (MOps) in the UAE has evolved from a support function into a strategic pillar that manages the intersection of technology, data, and creative execution. In the UAE's hyper-competitive market, MOps is critical for navigating the dual-language (Arabic/English) landscape and ensuring compliance with rapidly evolving media regulations.

- **Typical Business Use Cases**: Managing multi-agency rosters for government entities (e.g., Dubai Economy and Tourism), optimizing MarTech stacks for e-commerce (e.g., Noon, Amazon.ae), and ensuring Emiratization compliance in marketing departments.
- **Boundaries**: MOps covers the "how" of marketing—process, technology, and people—distinct from the "what" (creative/content) and "where" (media buying).

## UAE Legal, Regulatory, and Platform Rules

### 1. UAE Media Council Advertiser Permit (Mandatory 2026)
Effective **February 1, 2026**, the UAE Media Council mandates that all individuals and entities engaging in digital advertising must hold a valid **Advertiser Permit**.
- **Scope**: Applies to paid and unpaid promotions on social media, blogs, and websites.
- **Cost**: AED 1,000 per year for non-citizens; **free of charge for three years** for UAE citizens and residents as a support measure (Source: UAE Media Council, [[10]](#ref10)).
- **Penalty**: Non-compliance can result in fines up to **AED 1 million** (Source: DIAC, [[17]](#ref17)).

### 2. Public Procurement Laws
Government marketing contracts are governed by **Federal Decree-Law No. 11 of 2023** on Federal Government Procurement.
- **Methods**: Tenders can be public, limited, or sole-sourced for urgent needs.
- **Local Presence**: Vendors must have a legal presence in the UAE and be pre-qualified on the Ministry of Finance's digital procurement portal.
- **Dubai Specific**: Law No. 12 of 2020 governs contracts and warehouse management for the Dubai Government (Source: Lexology, [[18]](#ref18)).

### 3. Corporate Tax and VAT
- **Corporate Tax**: A **9%** tax applies to taxable income exceeding **AED 375,000**.
- **Small Business Relief (SBR)**: Businesses with revenue below **AED 3 million** can elect for SBR, treating taxable income as zero for the period, though registration and filing remain mandatory (Source: Ain Finance, [[19]](#ref19)).
- **VAT**: Standard **5%** VAT applies to marketing services. Marketing expenses are deductible only if incurred "wholly and exclusively" for the business (Source: Reyson, [[20]](#ref20)).

## Core Frameworks and Strategy

### Marketing Budgeting Models
- **Revenue-Based**: UAE companies typically allocate **10–15% of annual revenue** to marketing.
- **Digital Shift**: **60–80%** of the total marketing budget is now dedicated to digital channels in 2026 (Source: Skills Heaven, [[21]](#ref21)).
- **Zero-Based Budgeting (ZBB)**: Increasingly used by UAE government entities to justify every dirham of spend against specific KPIs rather than historical benchmarks.

### Agency Management Models
- **Retainer-Based**: Monthly retainers for legitimate agency work in the UAE range from **AED 5,500 ($1,500) to AED 36,700 ($10,000)** for SMEs, and **AED 90,000+ ($25,000+)** for enterprise engagements (Source: Digital Applied, [[22]](#ref22)).
- **Hybrid Models**: Combining a base retainer with performance-based bonuses linked to conversion or lead quality is the standard for 2026.

## Technical Tactics and Workflows

### 1. The UAE Marketing Brief
A standard UAE-compliant brief must include:
- **Language Requirements**: Explicitly stating the ratio of Arabic to English content.
- **Compliance Check**: Verification of the agency's and influencers' Advertiser Permits.
- **Data Privacy**: Adherence to the UAE Personal Data Protection Law (PDPL).

### 2. Statement of Work (SOW) and Scopes
- **Scope Creep Control**: UAE agencies are increasingly using "Points-Based" scopes where clients buy a monthly capacity of points rather than fixed deliverables, allowing for flexibility in fast-moving social trends.
- **MarTech Integration**: SOWs now frequently include "AI-Augmentation" clauses, defining how AI tools will be used for content generation and data analysis.

## Measurement, KPIs, and Analytics

### UAE-Specific Benchmarks
- **Bilingual Performance**: Campaigns targeting both Arabic and English speakers consistently show higher ROI in the UAE (Source: Skills Heaven, [[23]](#ref23)).
- **Customer Lifetime Value (CLV)**: A primary KPI for UAE luxury and real estate sectors, where high acquisition costs (CAC) necessitate long-term retention strategies (Source: Salesforce, [[24]](#ref24)).

### Attribution Models
- **AI-Driven Attribution**: By 2026, traditional multi-touch attribution is being replaced by AI models that account for offline-to-online conversions, critical for the UAE's mall-centric retail culture (Source: LinkedIn, [[25]](#ref25)).

## UAE Cultural Localization and Audience Notes
- **Ramadan/Eid Cycles**: Marketing operations must plan for "Night Economy" shifts during Ramadan, where peak engagement occurs between 9 PM and 3 AM.
- **Emirate Differences**: Dubai focuses on international tourism and luxury; Abu Dhabi emphasizes government initiatives and cultural heritage; Northern Emirates (Sharjah, RAK) are hubs for family-oriented and industrial marketing.
- **Language Nuance**: Modern Standard Arabic (MSA) is used for formal government communication, while Khaleeji dialect is preferred for high-engagement social media content targeting locals.

## Professional Practice and Career Pathways

### 1. Emiratization (Nafis Program)
- **Targets**: Private sector companies with 50+ employees must reach a **10% Emiratization target** by December 2026.
- **Penalties**: Failure to meet targets results in fines of **AED 10,000 per month** per missing Emirati in 2026 (Source: Envoy Global, [[26]](#ref26)).
- **Salary Floor**: A minimum salary of **AED 6,000** per month for Emirati employees is effective as of January 1, 2026 (Source: Adecco, [[27]](#ref27)).

### 2. Certifications and Salaries
- **Recognized Certifications**: Digital Marketing Institute (DMI), Chartered Institute of Marketing (CIM), and American Marketing Association (AMA) are the gold standards for UAE hiring.
- **Salary Trends**: 2026 salary guides show a premium for "Marketing Engineers" who can integrate AI and MarTech platforms.
- **Salary Ranges (Monthly)**:
    - Marketing Manager: AED 25,000 – AED 45,000
    - Head of Marketing: AED 50,000 – AED 85,000
    - (Source: Cooper Fitch 2026 Salary Guide, [[28]](#ref28))

## Professional Practice Checklists

### Agency Onboarding Checklist
- [ ] Verify UAE Trade License and Media Council Advertiser Permit.
- [ ] Confirm VAT registration and FTA compliance.
- [ ] Audit data handling processes against UAE PDPL.
- [ ] Establish bilingual workflow (Arabic/English) and approval hierarchy.
- [ ] Define KPI dashboard and reporting frequency (Weekly/Monthly).

### Marketing Audit Checklist
- [ ] Review MarTech stack for redundant subscriptions.
- [ ] Assess Emiratization status against Nafis 2026 targets.
- [ ] Evaluate content for cultural sensitivity (Ramadan/National Day).
- [ ] Check Advertiser Permit status for all active influencers.

## Sources

### Primary Sources
- **UAE Media Council**: Advertiser Permit Requirements, [[10]](#ref10)
- **UAE Government Portal (U.AE)**: Emiratization in the Private Sector, [[29]](#ref29)
- **Ministry of Finance**: Federal Procurement Law, [[30]](#ref30)
- **Federal Tax Authority (FTA)**: Corporate Tax and VAT Guidelines, [[31]](#ref31)

### Secondary Sources
- **Cooper Fitch**: 2026 UAE Salary Guide, [[28]](#ref28)
- **Hays**: GCC Salary Guide 2026, [[32]](#ref32)
- **IAB MENA**: Digital Adspend and Standards, [[33]](#ref33)
- **Lexology**: UAE Public Procurement Q&A, [[18]](#ref18)
- **Skills Heaven**: Digital Marketing Budget Planning UAE, [[21]](#ref21)

## Gaps and Verification Notes
- **Specific Permit Fees**: While the Advertiser Permit is currently free for residents for 3 years, the exact fee structure for corporate entities after the initial period needs verification as 2026 progresses.
- **MarTech Pricing**: Localized pricing for major MarTech platforms (HubSpot, Salesforce) in AED often fluctuates based on exchange rates; direct quotes are recommended for budgeting.
- **Emiratization in Free Zones**: While currently exempt, there are ongoing discussions about extending Nafis targets to certain free zones; this requires monthly monitoring.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/b2796695/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/b2796695/TOOL_RESULTS.md`
- Research child tool results lines: `1308`
- Research child tool results bytes: `58709`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/b2796695/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>

### Deep Practice Appendix: Senior Practitioner Playbook for Marketing operations, budgeting, agency management and professional competency

#### 1. Strategic diagnosis questions
A senior UAE marketing practitioner should begin by documenting the commercial context before choosing tactics. The working file should answer the following questions in plain language: what business outcome must change, which UAE audience segment is being prioritized, which emirate or free-zone context matters, whether the campaign is Arabic-first, English-first or bilingual, which legal or platform obligations apply, which channel owns demand creation, which channel owns conversion, and which data source will be treated as the source of truth. If any of those answers are unknown, the campaign should be marked as incomplete rather than pushed into execution.

#### 2. UAE compliance control checklist
Use this checklist before approving any public-facing campaign, content calendar, landing page, creator collaboration, paid advertisement, email sequence, SMS blast, WhatsApp template, marketplace listing or lead-generation form:

- Confirm the responsible legal entity, trade licence context, advertiser or media-permit obligations, and the person accountable for approval.
- Confirm whether personal data is collected, the lawful basis used, the consent capture method, opt-out wording, privacy-policy link, retention period and deletion workflow.
- Confirm whether the asset includes religious, cultural, national-symbol, public-morals, child-safety, health, financial, real-estate, education or investment claims.
- Confirm whether the content is advertising, editorial, sponsorship, affiliate promotion, employee advocacy, user-generated content, PR, or transactional communication.
- Confirm that paid, sponsored, gifted or affiliate content is visibly disclosed in the language understood by the target audience.
- Confirm that Arabic text has been reviewed by a qualified Arabic speaker and that RTL design has not broken navigation, icons, price display, form flow or CTA hierarchy.
- Confirm that campaign screenshots, approvals, consent logs, creative versions, media plans, UTMs and performance reports are archived for auditability.

#### 3. Briefing template
A strong brief for Marketing operations, budgeting, agency management and professional competency should contain: campaign objective, commercial target, audience segment, emirate/geography, Arabic/English language requirements, offer, proof points, legal restrictions, brand tone, required assets, channel mix, budget range, landing destination, measurement plan, reporting cadence, approval owners and escalation path. The brief should state what cannot be claimed as clearly as what can be claimed.

#### 4. Measurement design
Before launch, define the KPI tree. At the top is the business KPI, such as qualified leads, booked consultations, revenue, repeat purchases, pipeline value or retention. The next level contains channel KPIs such as reach, impressions, CTR, CPC, CPM, engagement rate, video completion rate, form-start rate, WhatsApp-start rate, conversion rate, CPL, CPA, AOV, ROAS or LTV. The final level contains diagnostic indicators such as page speed, scroll depth, search query match, ad frequency, creative fatigue, unsubscribe rate, bounce rate, consent opt-in rate and sales-response time.

#### 5. Documentation workflow
For a professional-grade UAE marketing library, each campaign should produce a reusable knowledge asset. Archive the final brief, research notes, audience assumptions, approved copy, Arabic localization notes, creative files, landing-page screenshots, UTM naming table, consent evidence, platform configuration, launch checklist, daily monitoring notes, final report and lessons learned. This allows future teams to distinguish verified UAE market learning from assumptions.

#### 6. Common failure modes
The most common failure modes are launching English-only material for audiences who require Arabic trust signals, copying global campaigns without cultural adaptation, treating WhatsApp as an informal afterthought rather than a governed conversion channel, running paid media without a clean measurement architecture, treating influencer content as personal speech when it is advertising, using generic landing pages with weak local proof, making unsupported claims in regulated sectors, and optimizing for vanity metrics instead of qualified commercial outcomes.

#### 7. Expert operating standard
A senior expert should apply a simple operating rule: no channel should be activated unless its role in the funnel is explicit, no claim should be published unless it is supportable, no data should be collected unless consent and retention are defined, no Arabic localization should be treated as mere translation, and no report should be accepted unless it explains what decision will change as a result of the data.


## Category Appendix: Governance System for UAE Marketing Teams

### Marketing risk register model
Create a living risk register with rows for legal compliance, media-content standards, personal-data processing, agency/vendor risk, platform account risk, influencer or partner risk, reputational risk, crisis escalation, financial controls, procurement controls, brand consistency and evidence retention. Each risk should have an owner, severity rating, mitigation step, evidence location and review date.

### Agency and vendor governance
UAE marketing teams often rely on agencies, freelancers, creators, production houses, media buyers and MarTech vendors. The client remains responsible for brand and compliance outcomes even when execution is outsourced. A professional scope of work should specify deliverables, review rounds, usage rights, media buying transparency, reporting format, data access, confidentiality, indemnity for non-compliant assets, crisis support, termination rights and handover obligations.

### Crisis communication operating rhythm
For crisis scenarios, create a war-room structure with four workstreams: fact finding, stakeholder communication, public statement drafting and monitoring. The first public message should acknowledge awareness, avoid speculation, confirm that facts are being verified, and define the next update window. The internal log should preserve every material decision and source of evidence.

## File-Level Verification Notes

- This file is based on source collector packets generated in July 2026.
- Do not treat third-party benchmark numbers, platform fee claims or social-media screenshots as permanent rules; verify them before budget approval or legal reliance.
- For regulated sectors such as real estate, healthcare, finance, education, insurance and investment promotions, obtain current sector-specific approval guidance before launch.

## References

<p id="ref1" class="ref_item"><a target="_blank" rel="noreferrer" href="https://uaemc.gov.ae/en/">[1] uaemc.gov.ae</a></p>
<p id="ref2" class="ref_item"><a target="_blank" rel="noreferrer" href="https://uaemc.gov.ae/en/media-content-standards/">[2] uaemc.gov.ae</a></p>
<p id="ref3" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws">[3] u.ae</a></p>
<p id="ref4" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/economy/consumer-protection">[4] u.ae</a></p>
<p id="ref5" class="ref_item"><a target="_blank" rel="noreferrer" href="https://tdra.gov.ae/en/Services/Unsolicited-Electronic-Communications-Spam-Regulation">[5] tdra.gov.ae</a></p>
<p id="ref6" class="ref_item"><a target="_blank" rel="noreferrer" href="https://support.google.com/adspolicy/answer/16856189?hl=en">[6] support.google.com</a></p>
<p id="ref7" class="ref_item"><a target="_blank" rel="noreferrer" href="https://uaemc.gov.ae/en/media-legislation/">[7] uaemc.gov.ae</a></p>
<p id="ref8" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.clydeco.com/en/insights/2025/05/uae-media-regulations-framework">[8] clydeco.com</a></p>
<p id="ref9" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/media/media-in-the-uae/media-regulation">[9] u.ae</a></p>
<p id="ref10" class="ref_item"><a target="_blank" rel="noreferrer" href="https://uaemc.gov.ae/en/%D8%AA%D8%B5%D8%B1%D9%8A%D8%AD-%D9%85%D8%B9%D9%84%D9%86/">[10] uaemc.gov.ae</a></p>
<p id="ref11" class="ref_item"><a target="_blank" rel="noreferrer" href="https://campaignme.com/uae-government-media-office-launches-guide-for-government-media-content/">[11] campaignme.com</a></p>
<p id="ref12" class="ref_item"><a target="_blank" rel="noreferrer" href="https://oananews.org/agencies/WAM">[12] oananews.org</a></p>
<p id="ref13" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/media/media-in-the-uae/media-facilities-and-events">[13] u.ae</a></p>
<p id="ref14" class="ref_item"><a target="_blank" rel="noreferrer" href="https://aitaggers.com.au/blog/arabic-sentiment-analysis-guide">[14] aitaggers.com.au</a></p>
<p id="ref15" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.mepra.org/topics/measurement-evaluation/">[15] mepra.org</a></p>
<p id="ref16" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.uae-embassy.org/discover-uae/governance/about-uae-president-sheikh-mohamed-bin-zayed">[16] uae-embassy.org</a></p>
<p id="ref17" class="ref_item"><a target="_blank" rel="noreferrer" href="https://diac.ae/blog/start-digital-marketing-agency-dubai-uae/">[17] diac.ae</a></p>
<p id="ref18" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.lexology.com/library/detail.aspx?g=fb4e8792-decc-4513-a583-7ee1eca68308">[18] lexology.com</a></p>
<p id="ref19" class="ref_item"><a target="_blank" rel="noreferrer" href="https://ainfinance.com/BlogsDetail/uae-corporate-tax-compliance-for-marketing-agencies-blog">[19] ainfinance.com</a></p>
<p id="ref20" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.reyson.ae/understanding-corporate-tax-deductible-expenses">[20] reyson.ae</a></p>
<p id="ref21" class="ref_item"><a target="_blank" rel="noreferrer" href="https://skillsheaven.org/digital-marketing-budget-planning-for-uae-companies/">[21] skillsheaven.org</a></p>
<p id="ref22" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.digitalapplied.com/blog/digital-marketing-pricing-2026-agency-costs">[22] digitalapplied.com</a></p>
<p id="ref23" class="ref_item"><a target="_blank" rel="noreferrer" href="https://skillsheaven.org/email-marketing-kpis-that-drive-sales/">[23] skillsheaven.org</a></p>
<p id="ref24" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.salesforce.com/eu/blog/customer-service-kpis-uae/">[24] salesforce.com</a></p>
<p id="ref25" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/darrellalfonso_marketing-martech-marketingoperations-activity-7399102458507161600-re9k">[25] linkedin.com</a></p>
<p id="ref26" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.envoyglobal.com/insight/understanding-the-united-arab-emirates-emiratisation-workforce-policy/">[26] envoyglobal.com</a></p>
<p id="ref27" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.adecco.com/en-ae/resources/article/Emiratization-2026-What-Private-Sector-Companies-Must-Do-Right-Now">[27] adecco.com</a></p>
<p id="ref28" class="ref_item"><a target="_blank" rel="noreferrer" href="https://cooperfitch.ae/2026-salary-guide-uae/">[28] cooperfitch.ae</a></p>
<p id="ref29" class="ref_item"><a target="_blank" rel="noreferrer" href="https://u.ae/en/information-and-services/jobs/employment-in-the-private-sector/emiratis-employment-in-private-sector">[29] u.ae</a></p>
<p id="ref30" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.mof.gov.ae/">[30] mof.gov.ae</a></p>
<p id="ref31" class="ref_item"><a target="_blank" rel="noreferrer" href="https://tax.gov.ae/">[31] tax.gov.ae</a></p>
<p id="ref32" class="ref_item"><a target="_blank" rel="noreferrer" href="https://www.hays.ae/salary-guide">[32] hays.ae</a></p>
<p id="ref33" class="ref_item"><a target="_blank" rel="noreferrer" href="https://iabmena.com/">[33] iabmena.com</a></p>
