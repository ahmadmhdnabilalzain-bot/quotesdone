# Source Packet 11: Email, SMS and WhatsApp marketing in UAE: consent, deliverability, segmentation, automation, lifecycle campaigns and telecom/platform constraints

# Email, SMS, and WhatsApp Marketing in the UAE: Research Report

This report details the regulatory, technical, and strategic landscape for messaging-based marketing in the United Arab Emirates as of July 2026.

## 1. Domain Scope
Messaging marketing in the UAE is a high-penetration, mobile-first domain characterized by some of the world's highest smartphone and social messaging usage rates.
- **UAE Relevance**: WhatsApp penetration exceeds 90% of the population, making it the primary channel for both personal and business communication (ARN IT, https://arnit.ae/whatsapp-business-api-uae-sme-guide-2026/).
- **Typical Business Use Cases**:
    - **E-commerce**: Order updates, last-mile delivery tracking (Noon, Amazon.ae), and abandoned cart recovery.
    - **Banking & Fintech**: OTPs (One-Time Passwords), transaction alerts, and customer support via WhatsApp.
    - **Retail & Real Estate**: Promotional broadcasts, appointment reminders, and lead generation via Click-to-WhatsApp ads.
- **Boundaries**: The domain is strictly bifurcated into **Transactional** (service-related) and **Promotional** (marketing-related) communications, each governed by different timing and consent rules under the TDRA.

## 2. UAE Legal, Regulatory, and Platform Rules
The UAE maintains a strict regulatory environment to combat spam and protect consumer privacy.

### A. TDRA Regulations (SMS & Telecom)
The **Telecommunications and Digital Government Regulatory Authority (TDRA)** governs all electronic communications with a "UAE Link."
- **Unsolicited Electronic Communications Regulatory Policy (v1.1, June 2022)**: Mandates that all marketing messages require prior explicit consent (TDRA, https://tdra.gov.ae/-/media/About/regulations-and-ruling/EN/cellular-phone-spam-regulatory-policy-English.ashx).
- **SMS Timing Restrictions**: Promotional SMS may only be sent between **7:00 AM and 9:00 PM GST**. Sending outside these hours is a violation (D7 Networks, https://d7networks.com/blog/the-regulations-for-sending-sms-in-uae/).
- **Sender ID Requirements**: All promotional SMS Sender IDs for local UAE companies must begin with the prefix **"AD-"** (e.g., AD-BrandName). Transactional messages do not require this prefix (VFirst, https://www.vfirst.me/post/navigating-the-uaes-sms-compliance-landscape).
- **International Restrictions**: International senders are **prohibited** from sending promotional SMS to UAE recipients. Only transactional traffic (OTPs, alerts) is permitted for international routes (D7 Networks, https://d7networks.com/blog/the-regulations-for-sending-sms-in-uae/).

### B. UAE Personal Data Protection Law (PDPL)
**Federal Decree-Law No. 45 of 2021** is the primary data privacy framework.
- **Consent (Article 6)**: Consent must be "clear, simple, unambiguous and accessible." The controller must be able to prove consent was obtained (Armingaud Avocat, https://armingaud-avocat.fr/en/federal-decree-law-no-45-of-2021-on-personal-data-protection/).
- **Right to Stop Processing (Article 17)**: Data subjects have the right to object to processing for direct marketing purposes, including profiling related to such marketing (Armingaud Avocat, https://armingaud-avocat.fr/en/federal-decree-law-no-45-of-2021-on-personal-data-protection/).

### C. WhatsApp Business API Policies
- **Official Channels**: Businesses must use an authorized Meta Business Solution Provider (BSP) to remain compliant with TDRA rules.
- **Voice/Video Call Ban**: While text and media are permitted, WhatsApp voice and video calls remain restricted in the UAE due to TDRA VoIP regulations (SleekFlow, https://sleekflow.io/blog/how-to-use-whatsapp-web-in-the-uae-setup-restrictions-and-business-options-1).

## 3. Core Frameworks and Strategy
### A. Channel Planning
Marketers in the UAE typically use a multi-layered messaging strategy:
1. **Email**: Used for long-form content, newsletters, and formal documentation.
2. **SMS**: Reserved for urgent, time-sensitive alerts and high-impact promotional "blasts" within the 7 AM - 9 PM window.
3. **WhatsApp**: Used for interactive engagement, customer support, and high-conversion lifecycle campaigns.

### B. Audience Segmentation
- **Expats vs. Nationals**: Segmentation by language (Arabic/English) is critical.
- **Behavioral**: Segmenting by "Last Interaction" is vital for WhatsApp to avoid being flagged as spam by users, which can lead to account suspension by Meta.

## 4. Technical Tactics and Workflows
### A. SMS Workflows
- **Opt-in**: Only one opt-in request message may be sent via SMS. If no reply is received within a month, a second (and final) request can be sent (VFirst, https://www.vfirst.me/post/navigating-the-uaes-sms-compliance-landscape).
- **Opt-out**: Users can block all promotional SMS by sending **"BALL" to 7726**. To block a specific sender, users send "SenderID B" to 7726 (TDRA, https://tdra.gov.ae/en/initiatives/marketing-short-message-service).

### B. WhatsApp Automation
- **Click-to-WhatsApp Ads (CTWA)**: These ads on Facebook/Instagram bypass landing pages, leading users directly into a WhatsApp chat. In 2026, CTWA is noted for delivering significantly lower cost-per-lead compared to traditional forms (GetKanal, https://getkanal.com/blog/click-to-whatsapp-ads-benchmarks-2026).
- **Lifecycle Campaigns**: Automated "Welcome" sequences and "Order Confirmed" messages are standard for UAE retailers like Noon and Amazon.ae.

### C. Email Deliverability
- **Authentication**: SPF, DKIM, and DMARC are mandatory for UAE businesses to avoid being blocked by Etisalat and du's aggressive security filters (AEserver, https://www.aeserver.com/protecting-your-inbox-spam-free-email/).
- **ISP Filtering**: Etisalat uses a proxy-based filtering system (`proxy.etisalat.ae`) that can redirect or block domains associated with high spam scores (Cloudflare Community, https://community.cloudflare.com/t/website-not-loading-from-uae/351550).

## 5. Measurement, KPIs, and Analytics
### A. Benchmarks (UAE/Regional 2026)
- **SMS Open Rates**: Consistently between **90% and 98%**, with 81% of recipients reading the message within 5 minutes (MessageFlow, https://messageflow.com/blog/sms-marketing-benchmarks/).
- **WhatsApp Open Rates**: Range from **58% to 70%**, with a Click-Through Rate (CTR) of approximately 15% (LinkedIn, https://www.linkedin.com/posts/dotdigital_sorrymark-activity-7419695599060430848-Ow-M).
- **Email Open Rates**: Average around **20-25%** for the region, though highly dependent on industry (Insider One, https://insiderone.com/email-marketing-benchmarks/).

### B. WhatsApp Pricing Model (2026)
Meta's per-message pricing in the UAE:
- **Marketing**: AED 1.20 – 1.45 per message.
- **Utility**: AED 0.15 – 0.20 per message.
- **Authentication (OTP)**: AED 0.30 – 0.40 per message.
- **Service**: Free within a 24-hour customer-initiated window (ARN IT, https://arnit.ae/whatsapp-business-api-uae-sme-guide-2026/).

## 6. UAE Cultural Localization and Audience Notes
- **Language**: Bilingual (Arabic/English) content is the standard. Promotional SMS often includes both versions in a single message or segments by user preference.
- **Ramadan Timing**: Marketers are advised to "mute" promotional broadcasts during fasting hours (dawn to dusk) and focus on the "Iftar" to "Suhoor" window (approx. 7 PM - 3 AM), though SMS must still respect the 9 PM TDRA cutoff (Nxtaa, https://nxtaa.com/blog/uae-sms-guidelines).
- **Religious Sensitivity**: Content must avoid non-Muslim religious festivals and any patriotic or political themes unless explicitly authorized (VFirst, https://www.vfirst.me/post/navigating-the-uaes-sms-compliance-landscape).

## 7. Professional Practice and Checklists
### A. Campaign Planning Checklist
- [ ] **Consent Audit**: Ensure all recipients have opted-in via a verifiable method (Article 6 PDPL).
- [ ] **Timing Check**: Schedule promotional SMS only between 07:00 and 21:00 GST.
- [ ] **Sender ID**: Verify the "AD-" prefix is active for promotional SMS.
- [ ] **Opt-out Mechanism**: Ensure "BALL to 7726" or a similar free opt-out is mentioned.
- [ ] **Authentication**: Confirm SPF/DKIM/DMARC records are valid for email domains.
- [ ] **WhatsApp Templates**: Pre-approve all marketing templates with Meta/BSP.

### B. Risk Control
- **Avoid "Free" Claims**: TDRA and UAE Cybercrimes Law updates flag deceptive "Free forever" claims if they are trial-only (Nxtaa, https://nxtaa.com/blog/uae-sms-guidelines).
- **Data Residency**: While the PDPL allows for cross-border data transfer under certain conditions, sensitive sectors (Gov, Health) often require local data residency.

## 8. Sources
### Primary Sources
- **TDRA (Telecommunications and Digital Government Regulatory Authority)**: *Unsolicited Electronic Communications Regulatory Policy v1.1*, https://tdra.gov.ae/-/media/About/regulations-and-ruling/EN/cellular-phone-spam-regulatory-policy-English.ashx
- **UAE Government (PDPL)**: *Federal Decree-Law No. 45 of 2021 on Personal Data Protection*, https://armingaud-avocat.fr/en/federal-decree-law-no-45-of-2021-on-personal-data-protection/
- **TDRA Initiative Page**: *Marketing Short Message Service*, https://tdra.gov.ae/en/initiatives/marketing-short-message-service

### Secondary Sources
- **ARN Innovation Technology**: *WhatsApp Business API for UAE SMEs: Complete 2026 Guide*, https://arnit.ae/whatsapp-business-api-uae-sme-guide-2026/
- **D7 Networks**: *The regulations for sending SMS in UAE*, https://d7networks.com/blog/the-regulations-for-sending-sms-in-uae/
- **VFirst**: *Navigating the UAE's SMS Compliance Landscape*, https://www.vfirst.me/post/navigating-the-uaes-sms-compliance-landscape
- **AEserver**: *Email Spam Protection for UAE Business*, https://www.aeserver.com/protecting-your-inbox-spam-free-email/
- **Nxtaa**: *UAE SMS Guidelines 2026*, https://nxtaa.com/blog/uae-sms-guidelines
- **GetKanal**: *Click-to-WhatsApp Ads Benchmarks 2026*, https://getkanal.com/blog/click-to-whatsapp-ads-benchmarks-2026

## 9. Gaps and Verification Notes
- **Email Blacklists**: No evidence of a centralized "UAE-only" email blacklist was found; however, Etisalat and du use proprietary algorithmic filters that are not publicly documented in detail.
- **Telemarketing SMS**: New 2024/2026 regulations regarding telemarketing (voice) are increasingly being applied to SMS for financial services; specific "prior approval" workflows for SMS-based financial telemarketing need further verification as they evolve.
- **WhatsApp Bidding Model**: The "max-price bidding model" for WhatsApp marketing messages mentioned by some sources is an emerging feature for 2026 and its exact impact on UAE rates is still being benchmarked.

---
**Checklist Status Summary**:
- [Y] Research TDRA regulations on SMS marketing and unsolicited communications
- [Y] Research UAE PDPL (Federal Decree-Law No. 45 of 2021) requirements for marketing consent
- [Y] Research WhatsApp Business API policies and UAE-specific use cases (e.g., Noon, banks)
- [Y] Research email deliverability and ISP constraints in the UAE (Etisalat, du)
- [Y] Research cultural localization for messaging (Ramadan, Arabic/English, timing)
- [Y] Collect KPIs and benchmarks for UAE messaging channels
- [Y] Identify professional practices and checklists for UAE marketers

Checklist file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/752acfc6/RESEARCH_CHECKLIST.md` updated and verified.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/752acfc6/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/752acfc6/TOOL_RESULTS.md`
- Research child tool results lines: `2000`
- Research child tool results bytes: `117150`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/752acfc6/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
