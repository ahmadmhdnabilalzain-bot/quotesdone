# Source Packet 14: Public relations, corporate communications and crisis communications in UAE: media relations, press releases, reputation, government/cultural sensitivity

# Public Relations, Corporate Communications, and Crisis Communications in the UAE

This research report covers the regulatory, strategic, and cultural landscape of Public Relations (PR) and Corporate Communications in the United Arab Emirates as of July 2026. It incorporates the latest legislative updates, including Federal Decree-Law No. 55 of 2023 and Cabinet Resolution No. 42 of 2025.

## Domain Scope
Public Relations in the UAE is a highly regulated professional domain that bridges corporate reputation management with national strategic narratives. It encompasses media relations, government communications, crisis management, and corporate social responsibility (CSR).
- **UAE Relevance**: PR is central to the UAE’s "soft power" strategy and economic diversification (Operation 300bn). It is used by government entities to communicate national progress and by the private sector to navigate a multicultural market.
- **Business Use Cases**: IPO communications (e.g., ADX/DFM listings), crisis mitigation during regional instability or environmental events, and cultural localization for multinational brands.
- **Boundaries**: PR is distinct from advertising but increasingly overlaps with "Advertiser Permits" for influencer-led PR campaigns. It is strictly governed by media content standards that prohibit content harmful to national unity or religious values.

## UAE Legal, Regulatory, and Platform Rules
The UAE media landscape underwent a major overhaul with the enforcement of new laws in 2024 and 2025.

### Primary Regulators
- **UAE Media Council (UAEMC)**: The federal authority responsible for media legislation, licensing, and content standards.
- **National Emergency Crisis and Disasters Management Authority (NCEMA)**: Oversees communication protocols during national emergencies.
- **Media Regulatory Office (MRO)**: Manages operational licensing and media-related free zones.

### Key Legislation
- **Federal Decree-Law No. 55 of 2023 on Media Regulation**: The foundational law regulating all media activities, including digital platforms and PR agencies. It mandates that all media individuals and institutions comply with national standards (Source: UAE Media Council, https://uaemc.gov.ae/en/media-legislation/).
- **Cabinet Resolution No. 42 of 2025**: Outlines administrative violations and penalties. Serious violations of media content standards can result in fines up to **AED 1 million** (Source: Clyde & Co, https://www.clydeco.com/en/insights/2025/05/uae-media-regulations-framework).
- **Federal Decree-Law No. 34 of 2021 (Cybercrimes Law)**: Strictly prohibits the spread of rumors, "fake news," or content that harms the state's reputation (Source: UAE Government Portal, https://u.ae/en/media/media-in-the-uae/media-regulation).

### Licensing and Permits
- **PR Agency Licensing**: Agencies must obtain a trade license from the relevant Department of Economic Development (DED) or Free Zone authority, plus a media license from the UAE Media Council.
- **Advertiser Permit (Mandatory by Jan 31, 2026)**: Any individual (including PR professionals or influencers) publishing promotional content online must hold a valid Advertiser Permit.
  - **Cost**: Free for 3 years for UAE citizens/residents; requires a trade license.
  - **Validity**: 1 year for residents; 3 months for visitors (Source: UAE Media Council, https://uaemc.gov.ae/en/%D8%AA%D8%B5%D8%B1%D9%8A%D8%AD-%D9%85%D8%B9%D9%84%D9%86/).

## Core Frameworks and Strategy
### The UAE Model in Crisis Media Management
NCEMA and the UAE Government Media Office utilize a proactive framework for crisis communication:
1. **Frontline Tool**: Communication is treated as a frontline response tool, not a support function.
2. **Centralized Narrative**: Coordination through the "Government Communication Network" to ensure a unified message across federal entities.
3. **Proactive Misinformation Containment**: Using AI-driven tools to detect and counter rumors before they escalate (Source: Campaign Middle East, https://campaignme.com/uae-government-media-office-launches-guide-for-government-media-content/).

### Audience Segmentation
- **Emirati Nationals**: Focus on national pride, heritage, and "Vision 2031" alignment.
- **Expat Professionals**: Focus on ease of business, safety, and lifestyle.
- **International Investors**: Focus on regulatory transparency and economic stability.

## Technical Tactics and Workflows
### Media Relations and WAM Submission
The **Emirates News Agency (WAM)** is the primary channel for official announcements.
- **Workflow**: PR agencies must register with WAM to submit press releases. Content is often submitted in both Arabic and English to ensure maximum reach across the 19 languages WAM supports (Source: WAM, https://oananews.org/agencies/WAM).
- **WAM Editor**: A digital tool allowing journalists and agencies to publish and manage stories remotely (Source: UAE Government Portal, https://u.ae/en/media/media-in-the-uae/media-facilities-and-events).

### Press Release Standards
- **Inverted Pyramid**: Essential for UAE journalists who often face high volumes of content.
- **Bilingual Strategy**: Simultaneous release in high-quality Arabic (Modern Standard) and English is mandatory for Tier-1 media coverage.

## Measurement, KPIs, and Analytics
The UAE PR industry follows the **Barcelona Principles 3.0**, as promoted by the Middle East Public Relations Association (MEPRA).
- **Key KPIs**:
  - **Share of Voice (SOV)**: Comparison against competitors in local Arabic and English titles.
  - **Sentiment Analysis**: Specifically tuned for Khaleeji Arabic nuances and sarcasm, which standard global tools often misinterpret (Source: AI Taggers, https://aitaggers.com.au/blog/arabic-sentiment-analysis-guide).
  - **Message Resonance**: Tracking the adoption of specific "Strategic Narratives" (e.g., sustainability during COP28 legacy projects).
- **Avoidance of AVE**: MEPRA explicitly discourages Advertising Value Equivalency (AVE) in favor of outcome-based metrics (Source: MEPRA, https://www.mepra.org/topics/measurement-evaluation/).

## UAE Cultural Localization and Audience Notes
### Naming Conventions and Protocol
PR professionals must adhere to strict protocol for addressing leadership:
- **President**: "His Highness Sheikh Mohamed bin Zayed Al Nahyan, President of the United Arab Emirates."
- **Vice President/Ruler of Dubai**: "His Highness Sheikh Mohammed bin Rashid Al Maktoum."
- **Ministers**: Often addressed as "His Excellency" (H.E.).
- **Naming Order**: Use the full name in the first mention; never use just the first name for leadership (Source: UAE Embassy, https://www.uae-embassy.org/discover-uae/governance/about-uae-president-sheikh-mohamed-bin-zayed).

### Cultural Sensitivities
- **Religious Holidays**: PR activity should pivot to community and charity themes during Ramadan. Avoid "hard sell" tactics.
- **Visual Content**: Must respect local dress codes and avoid imagery that could be perceived as offensive to Islamic values.

## Professional Practice and Checklists
### Media Training Checklist for UAE Executives
- [ ] **Protocol Briefing**: Ensure the spokesperson knows the correct titles for UAE leaders.
- [ ] **Legal Awareness**: Briefing on the Cybercrimes Law to avoid accidental "rumor-mongering."
- [ ] **Language Prep**: If the executive is non-Arabic speaking, ensure a high-quality translator is present for Arabic media.
- [ ] **National Agenda Alignment**: Can the announcement be linked to UAE's 2031 or 2071 goals?

### Reputation Risk Control
- **Pre-approval**: All media content must be vetted against the **Media Content Standards** (Source: UAE Media Council, https://uaemc.gov.ae/en/media-content-standards/).
- **Crisis Manual**: Must include a direct contact list for NCEMA and the relevant Emirate's Media Office (e.g., Dubai Media Office).

## Sources
- **UAE Media Council**: Media Legislation and Content Standards, https://uaemc.gov.ae/en/media-legislation/
- **UAE Government Portal**: Media Regulation and Cybercrimes Law, https://u.ae/en/media/media-in-the-uae/media-regulation
- **Clyde & Co**: Analysis of Cabinet Resolution No. 42 of 2025, https://www.clydeco.com/en/insights/2025/05/uae-media-regulations-framework
- **MEPRA**: Measurement and Evaluation Standards, https://www.mepra.org/topics/measurement-evaluation/
- **WAM (Emirates News Agency)**: Agency Profile and Services, https://oananews.org/agencies/WAM
- **Campaign Middle East**: UAE Government Media Office Guidelines, https://campaignme.com/uae-government-media-office-launches-guide-for-government-media-content/

## Gaps and Verification Notes
- **Specific Fine Amounts**: While the maximum fine is AED 1 million, the specific "Table No. 2" of Cabinet Resolution No. 42 of 2025 (listing exact fines for each violation type) is often only available in the full Arabic Gazette or through legal subscription services.
- **WAM Portal Registration**: The exact technical URL for the PR agency registration portal is often gated behind a login; agencies typically contact `wamnews@eim.ae` for initial setup.
- **2026 Advertiser Permit Enforcement**: The deadline is January 31, 2026. Live monitoring of enforcement actions after this date is recommended for future updates.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a06f337/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a06f337/TOOL_RESULTS.md`
- Research child tool results lines: `1498`
- Research child tool results bytes: `60854`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/4a06f337/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
