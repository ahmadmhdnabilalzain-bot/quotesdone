# UAE Marketing Knowledge Library — Coverage Map
This map freezes the structure for the UAE-focused marketing, digital marketing, SEO and social media knowledge library. It is built from `wide_research/uae_marketing_domains.json` and the per-domain packets in `UAE_Marketing_Library_sources/`.
## Category Files
### 01_Regulation_Governance_and_Marketing_Operations.md
**Title:** Regulation, Governance, PR, Crisis Communications and Marketing Operations in the UAE

**Coverage:** The governance layer of UAE marketing: legal permissions, content standards, data protection, crisis communications, procurement, agency management, budgeting and professional competency.
- Domain 01: UAE marketing legal and regulatory framework: media law, advertising standards, consumer protection, PDPL, influencer licensing and platform obligations — source packet `01_UAE_marketing_legal_and_regulatory_framework_media_law_advertising_standards_con.md`
- Domain 14: Public relations, corporate communications and crisis communications in UAE: media relations, press releases, reputation, government/cultural sensitivity — source packet `14_Public_relations_corporate_communications_and_crisis_communications_in_UAE_media.md`
- Domain 18: Marketing operations, budgeting, agency management and professional competency: briefs, scopes, retainers, procurement, KPIs, certifications and career pathways — source packet `18_Marketing_operations_budgeting_agency_management_and_professional_competency_bri.md`

### 02_Strategy_Brand_Content_and_Localization.md
**Title:** Strategy, Brand, Content Marketing, Copywriting and Cultural Localization in the UAE

**Coverage:** The strategic and cultural layer: market segmentation, brand positioning, bilingual content, Arabic/English localization, consumer psychology, Ramadan/Eid timing and multicultural messaging.
- Domain 02: UAE digital marketing strategy and growth frameworks: funnels, positioning, customer segmentation, GTM, budgeting and channel planning — source packet `02_UAE_digital_marketing_strategy_and_growth_frameworks_funnels_positioning_custome.md`
- Domain 04: Content marketing and copywriting in the UAE: content strategy, editorial planning, localization, Arabic/English tone, brand storytelling and compliance — source packet `04_Content_marketing_and_copywriting_in_the_UAE_content_strategy_editorial_planning.md`
- Domain 15: Brand strategy, consumer psychology and cultural localization in UAE: multicultural audiences, Arabic/English messaging, luxury, tourism, family and Ramadan marketing — source packet `15_Brand_strategy_consumer_psychology_and_cultural_localization_in_UAE_multicultura.md`

### 03_SEO_Paid_Search_and_Conversion_Optimization.md
**Title:** SEO, Paid Search, Landing Pages and Conversion Optimization in the UAE

**Coverage:** Search and post-click performance: technical SEO, local SEO, Arabic SEO, Google Ads, landing pages, forms, WhatsApp-first funnels, trust signals and conversion measurement.
- Domain 03: SEO in the UAE: technical SEO, local SEO, Arabic SEO, multilingual search, E-E-A-T, schema and search-market behavior — source packet `03_SEO_in_the_UAE_technical_SEO_local_SEO_Arabic_SEO_multilingual_search_E_E_A_T_sc.md`
- Domain 07: Paid search and Google Ads in UAE: keyword strategy, campaign structure, local intent, measurement, quality score, landing pages and compliance — source packet `07_Paid_search_and_Google_Ads_in_UAE_keyword_strategy_campaign_structure_local_inte.md`
- Domain 10: Conversion rate optimization and landing pages: UAE-specific trust signals, forms, funnels, lead generation, A/B testing and UX principles — source packet `10_Conversion_rate_optimization_and_landing_pages_UAE_specific_trust_signals_forms_.md`

### 04_Social_Influencer_Paid_Social_and_Video_Marketing.md
**Title:** Social Media, Influencer, Paid Social, Video and YouTube Marketing in the UAE

**Coverage:** The social and video layer: platform roles, creator marketing, paid social, content formats, YouTube, short-form video, disclosure, filming permits and community workflows.
- Domain 05: Social media strategy in the UAE: Instagram, TikTok, Snapchat, LinkedIn, X, Facebook, platform roles, content formats and community management — source packet `05_Social_media_strategy_in_the_UAE_Instagram_TikTok_Snapchat_LinkedIn_X_Facebook_p.md`
- Domain 06: Influencer marketing and creator economy in UAE/GCC: licensing, paid partnerships, contracts, pricing models, disclosure, whitelisting and measurement — source packet `06_Influencer_marketing_and_creator_economy_in_UAE_GCC_licensing_paid_partnerships_.md`
- Domain 08: Paid social advertising in UAE: Meta, TikTok, Snapchat, LinkedIn, X, audience targeting, creative testing, retargeting and platform policy constraints — source packet `08_Paid_social_advertising_in_UAE_Meta_TikTok_Snapchat_LinkedIn_X_audience_targetin.md`
- Domain 17: Video, YouTube and short-form content marketing in UAE: production workflows, hooks, platform SEO, creator formats, paid amplification and measurement — source packet `17_Video_YouTube_and_short_form_content_marketing_in_UAE_production_workflows_hooks.md`

### 05_Analytics_MarTech_Automation_and_Direct_Messaging.md
**Title:** Analytics, MarTech, Marketing Automation, Email, SMS and WhatsApp Marketing in the UAE

**Coverage:** The data and lifecycle layer: GA4, GTM, pixels, UTM governance, attribution, CRM, CDP, marketing automation, consent, deliverability, SMS and WhatsApp workflows.
- Domain 09: Analytics, tracking and marketing measurement: GA4, GTM, pixels, UTM governance, attribution, dashboards, KPIs, privacy and consent — source packet `09_Analytics_tracking_and_marketing_measurement_GA4_GTM_pixels_UTM_governance_attri.md`
- Domain 11: Email, SMS and WhatsApp marketing in UAE: consent, deliverability, segmentation, automation, lifecycle campaigns and telecom/platform constraints — source packet `11_Email_SMS_and_WhatsApp_marketing_in_UAE_consent_deliverability_segmentation_auto.md`
- Domain 16: Marketing technology and automation in UAE: CRM, CDP, marketing automation, AI tools, lead scoring, data governance and MarTech stack design — source packet `16_Marketing_technology_and_automation_in_UAE_CRM_CDP_marketing_automation_AI_tools.md`

### 06_Ecommerce_Marketplaces_B2B_and_LinkedIn_Growth.md
**Title:** E-Commerce, Marketplaces, B2B Marketing and LinkedIn Growth in the UAE

**Coverage:** Commercial growth channels: Amazon.ae, Noon, Shopify/D2C, marketplace retail media, B2B lead generation, ABM, event-led growth and LinkedIn strategy.
- Domain 12: E-commerce and marketplace marketing in UAE: Amazon.ae, Noon, Shopify, D2C, performance marketing, merchandising, CRO and retention — source packet `12_E_commerce_and_marketplace_marketing_in_UAE_Amazon_ae_Noon_Shopify_D2C_performan.md`
- Domain 13: B2B marketing and LinkedIn strategy in UAE: lead generation, account-based marketing, events, sales enablement and professional services — source packet `13_B2B_marketing_and_LinkedIn_strategy_in_UAE_lead_generation_account_based_marketi.md`

## Source Coverage Notes

- Source packets preserve the collector outputs, including URLs and gap notes.
- Final category files convert raw source URLs into clickable Markdown citation markers and include file-level References sections.
- Claims that collector packets marked as uncertain should be treated as verification targets before being used in high-risk legal, regulated-sector, or paid-media commitments.
