# Source Packet 1: UAE marketing legal and regulatory framework: media law, advertising standards, consumer protection, PDPL, influencer licensing and platform obligations

This collector report provides a comprehensive overview of the UAE's marketing legal and regulatory framework as of July 2026. It covers the primary laws, influencer licensing requirements, advertising standards, and data protection rules essential for professional marketing practice in the UAE.

# UAE Marketing Legal and Regulatory Framework

## Domain Scope and UAE Relevance
The marketing legal and regulatory domain in the UAE encompasses the rules governing how brands, agencies, and individuals communicate promotional messages to the public. In the UAE's highly digitalized economy, this framework is critical for maintaining social harmony, protecting consumer rights, and ensuring data privacy. 

**Typical Business Use Cases:**
- **Influencer Campaigns:** Navigating the mandatory licensing for social media promotions.
- **Data-Driven Marketing:** Ensuring compliance with the Federal Personal Data Protection Law (PDPL) for email and SMS campaigns.
- **Brand Positioning:** Aligning creative content with UAE cultural and religious values to avoid legal penalties.
- **E-commerce:** Complying with consumer protection laws regarding transparent pricing and advertising.

**Boundaries:**
The framework applies to all promotional activities conducted within the UAE (mainland and free zones) and those targeting UAE residents from abroad. It excludes purely private communications but includes any content that can be perceived as promotional, even if "gifted" or unpaid.

## UAE Legal, Regulatory, and Platform Rules

### 1. Primary Regulators
- **UAE Media Council (UAEMC):** The central authority for media licensing, content standards, and influencer permits. It replaced the National Media Council (NMC).
- **Telecommunications and Digital Government Regulatory Authority (TDRA):** Regulates electronic communications, including SMS marketing and spam.
- **Ministry of Economy:** Oversees consumer protection and competition laws.
- **UAE Data Office:** The regulator for the Personal Data Protection Law (PDPL).

### 2. Key Laws and Regulations
- **Federal Decree-Law No. 55 of 2023 on Media Regulation:** The foundational law for all media activities, including digital and social media.
- **Cabinet Resolution No. 23 of 2017 Regarding Media Content:** Sets the 20 national standards for media and advertising content.
- **Federal Decree-Law No. 45 of 2021 (PDPL):** Regulates the processing of personal data for marketing purposes.
- **Federal Law No. 15 of 2020 on Consumer Protection:** Prohibits misleading advertisements and mandates the use of Arabic in marketing.

### 3. Influencer Licensing (Advertiser Permit)
As of **February 1, 2026**, all individuals engaging in advertising activities on digital platforms must hold a valid **Advertiser Permit** issued by the UAE Media Council.
- **Scope:** Covers paid ads, brand collaborations, sponsored posts, and "gifted" products.
- **Cost:** The permit is **free for the first 3 years** for UAE citizens and residents. For others, costs vary based on the trade license setup (approx. AED 1,250 - 5,000).
- **Requirement:** Influencers must first obtain a **Trade License** or Freelance Permit before applying for the Advertiser Permit.
- **Penalties:** Fines for non-compliance range from **AED 3,000 to AED 10,000**, with potential account suspension.
> "Effective February 1, 2026, the UAE Media Council has mandated that all people engaging in advertising activities on digital platforms must hold a valid Advertiser Permit." — UAE Media Council, https://uaemc.gov.ae/en/

### 4. Media Content Standards (The 20 Points)
Advertisements must comply with 20 national standards, including:
1. Respecting the Divine Entity and Islamic beliefs.
2. Respecting the State's governance system and symbols.
3. Respecting the cultural heritage and national identity of the UAE.
4. Avoiding content that harms the State's foreign relations.
5. Not spreading rumors or misleading news.
6. Respecting the culture, identity, and values of the UAE.
7. Taking into account the **Age Rating System** (G, PG, PG13, PG15, 15+, 18+).
8. Respecting children's rights.

### 5. Data Privacy and Consent (PDPL)
- **Consent:** Marketing communications require explicit, clear, and revocable consent from the data subject.
- **Right to Object:** Individuals have the right to stop the processing of their data for direct marketing (Article 27).
- **Spam Regulation:** TDRA mandates that SMS marketing must include an "opt-out" mechanism (e.g., "Ball D" to 1666).

## Core Frameworks and Strategy

### Compliance-First Strategy
In the UAE, legal compliance is not a secondary check but a core strategic pillar.
- **Risk Assessment:** Marketers must audit every campaign against the 20 Content Standards.
- **Licensing Audit:** Brands must verify that every influencer they partner with holds both a Trade License and an Advertiser Permit.
- **Language Strategy:** Mandating Arabic in all consumer-facing data and advertising per Article 26 of the Consumer Protection Law.

### Channel Planning
- **SMS/Email:** Must be anchored in a verified opt-in database with clear unsubscribe paths.
- **Social Media:** Requires disclosure of "Paid Partnership" or "Ad" tags, even for gifted items.
- **Gaming/Gambling:** As of March 2026, Google Ads allows authorized entities (licensed by GCGRA) to advertise internet gaming in the UAE, subject to strict certification.

## Technical Tactics and Workflows

### Influencer Partnership Workflow
1. **Verification:** Check the influencer's Advertiser Permit number.
2. **Contracting:** Include clauses mandating compliance with UAE Media Council standards.
3. **Disclosure:** Ensure the influencer uses platform-native disclosure tools (e.g., Instagram's "Paid Partnership" tag).
4. **Content Review:** Pre-approve content to ensure no religious or cultural sensitivities are breached.

### SMS Marketing Compliance
- **Sender ID:** Must be registered with TDRA through a licensed telecom provider (Etisalat or Du).
- **Timing:** Marketing SMS should generally be sent between 9:00 AM and 9:00 PM to avoid being classified as intrusive.
- **Opt-out:** Every message must contain a clear instruction to unsubscribe.

## Measurement, KPIs, and Analytics

### Compliance KPIs
- **Permit Verification Rate:** % of partners with valid licenses.
- **Disclosure Compliance:** % of posts correctly tagged as "Ad" or "Paid Partnership."
- **Opt-out Rate:** Number of unsubscribes per campaign (monitored for spam risk).
- **Regulatory Inquiries:** Number of flags or notices received from UAEMC or TDRA.

### Performance Benchmarks
- **Arabic vs. English Engagement:** Measuring the impact of localized content on different demographic segments.
- **Ramadan Engagement Spikes:** Tracking the 20-40% increase in social media usage during the holy month.

## UAE Cultural Localization and Audience Notes

### Religious and Cultural Sensitivities
- **Islam:** No content should disrespect Islamic values. Avoid imagery of pigs, alcohol (unless specifically permitted in restricted contexts), or immodest clothing.
- **National Symbols:** The UAE Flag, National Anthem, and Rulers must be treated with the utmost respect. Commercial use of the flag requires specific approvals.
- **Ramadan:** Marketing shifts to themes of charity, family, and reflection. Advertising for food and drink is restricted during fasting hours in public spaces.

### Audience Segmentation
- **Emirati Nationals:** Prefer high-quality Arabic content, luxury positioning, and themes of national pride.
- **Expat Communities:** Highly diverse; requires English-first or multi-lingual strategies (Tagalog, Hindi, Urdu) depending on the target segment.

## Professional Practice and Checklists

### Campaign Launch Checklist
- [ ] Does the content respect the 20 Media Content Standards?
- [ ] Is the Advertiser Permit for all influencers verified?
- [ ] Is there an Arabic version of the advertisement (mandatory for consumer protection)?
- [ ] Has the data been collected via explicit consent (PDPL)?
- [ ] Does the SMS campaign include an opt-out mechanism?
- [ ] Is the content age-rated if applicable?

### Vendor Management
- Agencies must provide proof of their own media licenses.
- Contracts should indemnify the brand against regulatory fines caused by vendor non-compliance.

## Source Links
- **UAE Media Council - Media Content Standards:** [https://uaemc.gov.ae/en/media-content-standards/](https://uaemc.gov.ae/en/media-content-standards/)
- **UAE Government - Data Protection Laws:** [https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws](https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws)
- **UAE Government - Consumer Protection:** [https://u.ae/en/about-the-uae/economy/consumer-protection](https://u.ae/en/about-the-uae/economy/consumer-protection)
- **TDRA - Unsolicited Electronic Communications:** [https://tdra.gov.ae/en/Services/Unsolicited-Electronic-Communications-Spam-Regulation](https://tdra.gov.ae/en/Services/Unsolicited-Electronic-Communications-Spam-Regulation)
- **Google Ads Policy - Gambling in UAE:** [https://support.google.com/adspolicy/answer/16856189?hl=en](https://support.google.com/adspolicy/answer/16856189?hl=en)

## Gaps and Verification Notes
- **Executive Regulations for PDPL:** While the law is in effect, specific executive regulations for certain sectors are still being updated; marketers should monitor the UAE Data Office for new circulars.
- **Influencer Permit Costs for Visitors:** While resident costs are clear, the exact fee structure for short-term visitor permits via agencies can vary by agency.
- **AI in Advertising:** New guidelines regarding AI-generated content and deepfakes in advertising are expected from the Media Council in late 2026.

### Checklist Status Summary
- Checklist path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/ad891ae2/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/ad891ae2/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/ad891ae2/TOOL_RESULTS.md`
- Research child tool results lines: `2641`
- Research child tool results bytes: `129992`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/ad891ae2/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
