# Source Packet 17: Video, YouTube and short-form content marketing in UAE: production workflows, hooks, platform SEO, creator formats, paid amplification and measurement

### Collector Report: Video, YouTube, and Short-Form Content Marketing in the UAE (July 2026)

This report provides a comprehensive overview of the video marketing landscape in the UAE, focusing on regulatory compliance, platform-specific statistics, production workflows, and cultural localization strategies.

#### 1. Domain Scope and UAE Relevance
Video marketing in the UAE is a primary driver of digital engagement, fueled by one of the world's highest smartphone penetration rates. As of 2026, social media user identities account for **112.3% of the population (11.5 million)**, with residents spending an average of **2 hours and 58 minutes daily** on social platforms.
*   **Typical Use Cases**: Luxury real estate tours (Dubai/Abu Dhabi), Ramadan brand storytelling, government service awareness, and influencer-led social commerce.
*   **Boundaries**: Includes long-form YouTube content, short-form (TikTok/Reels/Snapchat), and paid video amplification.

#### 2. UAE Legal, Regulatory, and Platform Rules
The regulatory environment for video content is strictly governed by federal laws and local authorities.
*   **UAE Media Council (UAEMC) Advertiser Permit**: Effective February 1, 2026, any individual (citizen, resident, or visitor) publishing advertising content online must obtain an **Advertiser Permit**. 
    *   *Cost*: Free for the first three years for UAE citizens and residents.
    *   *Requirement*: Must be linked to a valid UAE trade or freelance license.
    *   *Disclosure*: Permit numbers must be clearly displayed on social media accounts.
*   **TDRA Prohibited Content**: The Telecommunications and Digital Government Regulatory Authority (TDRA) enforces 19 prohibited content categories under the Internet Access Management Policy. Prohibited content includes:
    *   Contempt of religion or the Divine.
    *   Offenses against the UAE, its symbols, or public order.
    *   Promotion of gambling, tobacco, or illegal communication activities.
    *   Defamation and impersonation.
*   **Filming Permits**: 
    *   **Dubai**: Managed by the Dubai Film and TV Commission (DFTC). Commercial filming requires a permit; foreign crews must work with a UAE-licensed production partner.
    *   **Abu Dhabi**: Managed by the Abu Dhabi Film Commission (ADFC) and twofour54.
*   **Drone Regulations**: All drones must be registered via the **GCAA UAS Gateway**. Commercial aerial filming requires project-specific permits from the GCAA and local bodies (DCAA in Dubai). As of March 2026, recreational drone use remains suspended in Dubai.

#### 3. Core Frameworks and Strategy
*   **Hero-Hub-Help (HHH) Model**: Localized for the UAE market.
    *   *Hero*: Large-scale campaigns around national events (UAE National Day, Dubai Shopping Festival).
    *   *Hub*: Consistent short-form series (e.g., "Weekly Dubai Eats" or "Abu Dhabi Tech Trends").
    *   *Help*: Educational/How-to content in Arabic and English (e.g., "How to apply for a Golden Visa").
*   **Audience Segmentation**: 
    *   **Gen Z**: 56% use TikTok daily; prefer raw, unpolished "behind-the-scenes" content.
    *   **Expats vs. Nationals**: Content must balance Western-style aesthetics with Khaleeji cultural nuances.

#### 4. Technical Tactics and Workflows
*   **YouTube SEO (UAE Focus)**:
    *   *Keywords*: High-intent Arabic keywords (e.g., "أفضل مطاعم دبي" - Best Dubai Restaurants) and English equivalents.
    *   *Localization*: Use of `.ae` domains for linked sites and geo-tagging specific districts (DIFC, JLT, Saadiyat Island).
*   **Short-Form Hooks**: UAE audiences "judge content within the first 2 to 3 seconds." Effective hooks include "POV: You live in Dubai" or "Hidden gems in Sharjah."
*   **Production Workflow**:
    1.  Scripting (Bilingual: Arabic/English).
    2.  Permit Acquisition (UAEMC/DFTC).
    3.  Filming (Adhering to public decency laws).
    4.  Post-Production (Mobile-first vertical formats).

#### 5. Measurement, KPIs, and Analytics
*   **YouTube Ads Benchmarks (Q1 2026)**:
    *   **TrueView CPM**: $11.42 (Average).
    *   **Non-Skippable CPM**: $14.85.
    *   **Bumper Ads (6s) CPM**: $9.20.
    *   **Average CTR**: ~0.65%.
*   **Platform Reach**: TikTok leads in reach (142.7% penetration), followed by YouTube (80.3%) and Instagram (80.1%).

#### 6. UAE Cultural Localization and Audience Notes
*   **Bilingualism**: Mastery of bilingual content (scripts and captions switching between Arabic and English) is a major trend for 2026.
*   **Ramadan/Eid**: 20% YoY increase in search interest for "sustainability" during Ramadan. Brands are expected to showcase social responsibility.
*   **Visual Standards**: Avoid filming sensitive government buildings or individuals without consent (Federal Decree-Law No. 34 of 2021).

#### 7. Professional Practice and Checklists
*   **Pre-Filming Checklist**:
    *   [ ] Valid UAEMC Advertiser Permit?
    *   [ ] Trade/Freelance License active?
    *   [ ] Location permits secured (DFTC/ADFC)?
    *   [ ] Drone registered and flight permit approved?
    *   [ ] Content audited for 19 TDRA prohibited categories?

#### Sources
*   **UAE Media Council (UAEMC)**: Advertiser Permit Guidelines, https://uaemc.gov.ae/en/تصريح-معلن/
*   **DataReportal**: Digital 2026: The United Arab Emirates, https://datareportal.com/reports/digital-2026-united-arab-emirates
*   **Global Media Insight**: UAE Social Media Statistics 2024/2026, https://www.globalmediainsight.com/blog/uae-social-media-statistics/
*   **TDRA**: Internet Access Management Policy, https://tdra.gov.ae/en/About/tdra-policies/internet-access-management-policy
*   **GCAA**: UAS Gateway Drone Regulations, https://uas.gcaa.gov.ae

#### Gaps and Verification Notes
*   **NMC vs. UAEMC**: The National Media Council (NMC) has transitioned to the UAE Media Council (UAEMC); some older documents still reference NMC standards.
*   **19 Standards List**: While the TDRA's 19 prohibited categories are well-documented, the UAEMC's specific "19 Advertising Standards" are often cited as a subset of the broader media law (Decree-Law 55/2023).
*   **Live Data**: Ad benchmarks (CPM/CTR) fluctuate; Q1 2026 figures should be re-verified quarterly.

**Checklist Status Summary**:
*   Checklist Path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d284a37b/RESEARCH_CHECKLIST.md`
*   All items marked **[Y]**.

---

Research child artifacts:
- Research child summary file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d284a37b/RESEARCH_SUMMARY.md`
- Downstream handoff hint: This collector report has been saved to the summary file above. When delegating a downstream task that needs this research, include that file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
- Research child tool results file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d284a37b/TOOL_RESULTS.md`
- Research child tool results lines: `2603`
- Research child tool results bytes: `146832`

<system-reminder>
[RESEARCH_CHILD_SUMMARY_HANDOFF_HINT]
This collector report has been saved to `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/d284a37b/RESEARCH_SUMMARY.md`. When delegating a downstream task that needs this research, include this file path in the delegated instructions and tell the child to read it as source material before synthesis or artifact production.
</system-reminder>

<system-reminder>
[RESEARCH_CHILD_TOOL_RESULTS_REVIEW]
The collector report is a summary. When exact evidence, URLs, conflicts, missing fields, or raw tool outputs matter, use `grep`/`read` on the research child tool results file above before factual synthesis or artifact production.
</system-reminder>
