# MEP Engineering: HVAC, Electrical, Plumbing, Fire and Life Safety, and BIM in the UAE

This chapter covers the full mechanical, electrical, plumbing, and fire engineering landscape for UAE projects, integrating authority requirements, design standards, technical calculations, commissioning, and BIM/digital coordination. [[1]](#ref1)[[2]](#ref2)

## 1. Mechanical HVAC Engineering

# Source Packet 10: Mechanical HVAC engineering: ventilation, cooling loads, district cooling, ASHRAE, Dubai/Abu Dhabi requirements, equipment rooms and commissioning

**Research topic:** Mechanical HVAC engineering: ventilation, cooling loads, district cooling, ASHRAE, Dubai/Abu Dhabi requirements, equipment rooms and commissioning

**Report title:** Collector Report: Mechanical HVAC Engineering (UAE)

# Collector Report: Mechanical HVAC Engineering (UAE)

This report provides a comprehensive collection of source-backed engineering knowledge for Mechanical HVAC systems in the United Arab Emirates, focusing on regulatory compliance, technical design parameters, district cooling, and commissioning workflows.

## 1. Executive Summary
The HVAC sector in the UAE is governed by stringent energy efficiency and safety regulations due to the extreme desert climate. Key developments in 2026 include the widespread adoption of the **Abu Dhabi Cooling Load Manual (CLM)** to combat system oversizing and the enforcement of the **Dubai Building Code (DBC) 2021**. District cooling remains the primary utility for high-density developments, regulated by the **RSB Dubai** to ensure high Delta T performance and sustainable water use.

## 2. Coverage Table

| Dimension | Status | Evidence Source | Key Findings |
| :--- | :--- | :--- | :--- |
| **Domain Scope** | Covered | Dubai Building Code (2021) | Focus on cooling, ventilation, and smoke control for high-rise and mixed-use. |
| **Authorities & Workflow** | Covered | DM, DMT, Trakhees, Civil Defense | Multi-stage approval: Concept -> Detailed Design -> NOC -> Inspection -> Completion. |
| **Codes & Standards** | Covered | DBC, ADIMC, UAE Fire Code, ASHRAE | DBC 2021, ADIMC 2013/2021, UAE Fire Code 2018, ASHRAE 62.1/90.1. |
| **Technical Design** | Covered | DM Health Facility Guidelines, AD CLM | Outdoor: 46°C DB / 29°C WB. Fresh Air: 34°C DB / 32°C WB. |
| **District Cooling** | Covered | RSB Dubai, South Energy Guidelines | Mandatory 9°C Delta T; 2-way valves only; ETS room technical specs. |
| **Ventilation & IAQ** | Covered | ASHRAE 62.1, Al Sa'fat | Minimum ventilation rates per occupancy; CO2 monitoring for high-density. |
| **Equipment Rooms** | Covered | DBC Part H, ADIMC | Clearances (min 1m), drainage (1 drain/144 sqft), and ventilation requirements. |
| **Commissioning** | Covered | DM Building Control, BSRIA/CIBSE | TAB (Testing, Adjusting, Balancing) is mandatory for completion certificates. |
| **Climate & Durability** | Covered | UAE Fire Code, Al Sa'fat | High humidity (latent load), dust filtration (MERV 13+), and corrosion protection. |

## 3. Technical Design Content

### 3.1 Outdoor and Indoor Design Conditions
Designers must adhere to emirate-specific weather data to prevent oversizing, a major focus of the 2026 Abu Dhabi Cooling Load Manual.
- **Dubai (DM Requirements):**
  - **Cooling Load Calculation:** 46°C Dry Bulb (DB), 29°C Wet Bulb (WB).
  - **Fresh Air Intake:** 34°C DB, 32°C WB.
  - *Source:* DHA Health Facility Guidelines (Mechanical HVAC), )%20Engineering%20Design [[3]](#ref3)
- **Abu Dhabi (CLM 2026):**
  - The **Abu Dhabi Cooling Load Manual (CLM)** aims to reduce AC oversizing by 25-35%, potentially saving AED 560 million annually in equipment costs.
  - *Source:* Abu Dhabi Media Office [[4]](#ref4)

### 3.2 District Cooling & Energy Transfer Stations (ETS)
District cooling is mandatory in many Dubai/Abu Dhabi zones. The **Regulatory and Supervisory Bureau (RSB)** sets the technical standards.
- **Delta T Management:** A minimum Delta T (temperature difference between supply and return) of **9°C** is typically required. Failure to maintain this results in "Low Delta T" penalties.
- **Valve Requirements:** Three-way bypass valves are strictly prohibited; only **two-way modulating valves** are allowed to maintain high return temperatures.
- **ETS Room Specs:** Must include Plate Heat Exchangers (PHEX) with a 1°C approach temperature, energy meters, and dedicated BMS integration.
- *Source:* RSB Dubai Efficient Cooling, ; South Energy ETS Guidelines [[5]](#ref5)[[6]](#ref6)

### 3.3 Ventilation and Smoke Control
- **IAQ Standards:** Systems must comply with **ASHRAE 62.1**. For high-occupancy areas, Demand Controlled Ventilation (DCV) using CO2 sensors is required by **Al Sa'fat** (Dubai Green Building System).
- **Smoke Management:** The **UAE Fire and Life Safety Code (2018)** mandates mechanical smoke extraction for atriums, corridors, and basements. Pressurization is required for fire stairs and lift shafts.
- *Source:* UAE Fire and Life Safety Code of Practice [[7]](#ref7)

## 4. UAE Authorities and Approval Workflow

### 4.1 Dubai Municipality (DM) / Trakhees
1. **Concept Stage:** Submission of MEP concept report and sustainability (Al Sa'fat) strategy.
2. **Detailed Design:** Submission of cooling load calculations (HAP/Trace), ventilation schedules, and P&IDs.
3. **NOCs:** Required from DEWA (power/water) and District Cooling providers (Empower/Emicool).
4. **Execution:** Regular site inspections by DM Building Control.
5. **Completion:** Submission of TAB reports and O&M manuals for the Completion Certificate.
- *Source:* Dubai Municipality Building Permit Procedures [[8]](#ref8)

### 4.2 Abu Dhabi (DMT / ADM)
- Projects must comply with the **Abu Dhabi International Mechanical Code (ADIMC)** and **Estidama Pearl Rating System**.
- **Estidama:** HVAC systems must meet minimum Energy Performance (RE-R1) and IAQ (IDP-R1) requirements.
- *Source:* Abu Dhabi DMT Building Permits [[9]](#ref9)

## 5. Construction, Testing, and Commissioning

### 5.1 Equipment Room Requirements
- **Clearances:** Minimum 1000mm clearance around major equipment (Chillers, AHUs) for maintenance.
- **Drainage:** At least one sanitary floor drain for every **144 square feet** in equipment rooms.
- **Plinths:** Equipment must be mounted on concrete plinths at least 100mm-150mm high.
- *Source:* Dubai Building Code Part H; ADIMC Section 306.

### 5.2 Commissioning (Cx) and TAB
- **TAB (Testing, Adjusting, and Balancing):** Mandatory for all air and water systems. Reports must be certified by an independent third-party agency.
- **Handover:** O&M manuals must include as-built drawings, equipment schedules, warranty certificates, and the final TAB report.
- *Source:* HVAC Testing & Commissioning Guide UAE [[10]](#ref10)

## 6. Professional Practice and Checklists

### 6.1 Design Review Checklist
- [ ] Verify outdoor design conditions match DM/ADM requirements (46°C DB).
- [ ] Ensure Sensible Heat Ratio (SHR) accounts for high latent loads in coastal areas.
- [ ] Confirm no 3-way valves are used in District Cooling circuits.
- [ ] Check that MERV 13 filters are specified for AHUs (Al Sa'fat/Estidama).
- [ ] Validate smoke damper locations against Fire & Life Safety drawings.

### 6.2 Common Mistakes in UAE HVAC Design
- **Oversizing:** Using "rule of thumb" (e.g., 1 TR per 150 sqft) instead of detailed HAP calculations, leading to humidity issues and high energy bills.
- **Inadequate Latent Cooling:** Failing to account for extreme humidity (32°C WB) during fresh air treatment.
- **Poor ETS Design:** Low Delta T due to incorrect PHEX selection or bypasses.

## 7. Gaps and Verification Notes
- **ADIMC 2021 Adoption:** While ADIMC 2013 is the widely cited base, verification is needed on the full enforcement of the 2021 version across all Abu Dhabi municipalities as of July 2026.
- **Refrigerant Phase-out:** Specific UAE-wide timelines for the phase-out of HFCs (like R-410A) in favor of low-GWP alternatives (R-32, R-454B) are evolving; check latest MOCCAE circulars.

## 8. Checklist Status Summary
Checklist file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/e51031c0/RESEARCH_CHECKLIST.md`
- [Y] All items completed.

## 9. Sources
- **Dubai Building Code (2021) [[2]](#ref2)
- **UAE Fire and Life Safety Code (2018) [[7]](#ref7)
- **Abu Dhabi Cooling Load Manual (2026) [[4]](#ref4)
- **RSB Dubai District Cooling Regulations [[5]](#ref5)
- **South Energy ETS Guidelines [[6]](#ref6)
- **DHA Health Facility Guidelines (HVAC):** )%20Engineering%20Design [[3]](#ref3)

---


## 2. Electrical Power Engineering

# Source Packet 15: Electrical power engineering: DEWA/ADDC/Etihad Water requirements, LV/MV design, earthing, lighting, emergency power, IEC/BS standards

**Research topic:** Electrical power engineering: DEWA/ADDC/Etihad Water requirements, LV/MV design, earthing, lighting, emergency power, IEC/BS standards

**Report title:** Electrical Power Engineering: UAE Regulations and Design Standards

# Electrical Power Engineering: UAE Regulations and Design Standards

This research report provides a comprehensive overview of electrical power engineering requirements in the United Arab Emirates, focusing on the regulations of the Dubai Electricity and Water Authority (DEWA), Abu Dhabi Distribution Company (ADDC) / Department of Energy (DoE), and Etihad Water and Electricity (EtihadWE). It covers Low Voltage (LV) and Medium Voltage (MV) design, earthing, lighting, emergency power, and compliance with international standards (IEC/BS).

---

### 1. Domain Scope
Electrical power engineering in the UAE encompasses the design, installation, and maintenance of electrical systems for residential, commercial, industrial, and infrastructure projects. The domain is strictly regulated by emirate-level utility authorities to ensure safety, reliability, and efficiency in a region characterized by extreme climatic conditions.

*   **UAE Relevance**: High demand for cooling (HVAC) and rapid urban development make electrical infrastructure critical.
*   **Typical Projects**: High-rise towers, luxury villas, industrial warehouses, data centers, and large-scale infrastructure (airports, metros).
*   **Boundaries**: Covers everything from the utility intake point (MV/LV) to the final point of use (sockets, lighting, machinery).

---

### 2. UAE Authorities and Approval Workflow
Electrical works in the UAE require multi-stage approvals from local utility providers and civil defense authorities.

#### Key Authorities
*   **Dubai**: Dubai Electricity and Water Authority (DEWA), Dubai Municipality (DM), Trakhees (for free zones).
*   **Abu Dhabi**: Department of Energy (DoE), Abu Dhabi Distribution Company (ADDC), Al Ain Distribution Company (AADC).
*   **Northern Emirates**: Etihad Water and Electricity (EtihadWE) - formerly FEWA.
*   **Federal**: UAE Civil Defense (for fire and life safety systems).

#### Approval Sequence
1.  **NOC (No Objection Certificate)**: Obtained during the design phase to ensure the proposed load can be met by the existing grid.
2.  **Load Schedule & Shop Drawing Approval**: Submission of detailed electrical drawings, load schedules, and single-line diagrams (SLD) to the utility authority.
3.  **Technical Approval**: Review of equipment specifications (transformers, switchgear, cables).
4.  **Site Inspection**: Authorities inspect the installation (earthing, containment, DB dressing) before energization.
5.  **Testing & Commissioning**: Final verification of protection settings and insulation resistance.
6.  **Connection & Metering**: Installation of meters and energization of the premises.

> "All electrical installations and equipment installed therein, shall be subject to DEWA’s inspection, testing and final approval before connecting the electric supply." — DEWA Regulations for Electrical Installations 2017 [[11]](#ref11)

---

### 3. Core Codes and Standards
UAE electrical design is a hybrid of local regulations and international standards, primarily British Standards (BS) and International Electrotechnical Commission (IEC) codes.

*   **Local Regulations**:
    *   **DEWA Regulations for Electrical Installations (2017 Edition)**: The primary code for Dubai.
    *   **Abu Dhabi Electricity Wiring Regulations (2020)**: Issued by the DoE for Abu Dhabi.
    *   **Dubai Building Code (2021)**: Part G (Utilities) provides unified design criteria.
    *   **UAE Fire and Life Safety Code of Practice (2018)**: Governs emergency lighting and power.
*   **International Standards**:
    *   **BS 7671**: Requirements for Electrical Installations (IET Wiring Regulations).
    *   **IEC 60364**: Low-voltage electrical installations.
    *   **IEC 60947**: Low-voltage switchgear and controlgear.

---

### 4. Technical Design Content

#### Supply Parameters
*   **Voltage**: 400V (3-phase) / 230V (Single-phase), +10% to -6% tolerance.
*   **Frequency**: 50 Hz.
*   **Fault Level**: Typically 31.5kA or 40kA for 1 second (subject to authority confirmation).

#### Load Calculations and Diversity
Designers must use approved diversity factors for different building types.
*   **Lighting**: 100% of connected load.
*   **Power Sockets**: Diversity applied based on the number of points (e.g., first 10A at 100%, remainder at 40% for domestic).
*   **AC Units**: 100% of the largest unit + diversity for others.

#### Voltage Drop Limits
*   **Lighting Circuits**: ≤ 3%.
*   **Power/Other Circuits**: ≤ 5%.
*   **Total (from Transformer)**: ≤ 6%.
> "The resulting voltage drop in the circuit should be checked... Lighting: ≤ 3%, Power: ≤ 5%." — UAE Electrical Standards & Regulations Guide [[12]](#ref12)

#### Power Factor Correction (PFC)
*   **DEWA**: Minimum 0.9 lagging. Penalties apply for lower values.
*   **ADDC**: 0.9 to Unity (Recommended 0.95).
> "DEWA: 0.9 to 0.95 (Recommended: 0.95, encourages up to 0.98)." — LinkedIn: Muhammad Sohail [[13]](#ref13)

#### Earthing and Bonding
*   **DEWA**: Mandates **TN-S** system. Main earth electrode resistance must be **< 1 Ohm**.
*   **ADDC**: Allows **TN-S** and **TT** systems. Earth electrode resistance must be **< 10 Ohm**.
> "DEWA requires a TN-S configuration... and mandates an earth electrode resistance maximum of 1 Ohm. ADDC requires a combination of TN-S and TT... maximum of 10 Ohm." — LinkedIn: Fozan Hameed [[14]](#ref14)

---

### 5. Construction Supervision, Testing, and Commissioning
Site execution must strictly follow approved shop drawings and authority circulars.

*   **Cable Installation**: Use of LSZH (Low Smoke Zero Halogen) cables is mandatory for indoor installations.
*   **Containment**: Galvanized Iron (GI) conduits/trays for exposed areas; PVC for concealed.
*   **Testing Points**:
    *   **Insulation Resistance (IR)**: Minimum 0.5 MΩ (typically > 100 MΩ in practice).
    *   **Continuity Test**: For all protective conductors.
    *   **RCD Trip Test**: Verification of 30mA trip for life safety circuits.
    *   **Earth Resistance**: Measured using the Fall-of-Potential method.

---

### 6. UAE Climate, Durability, and Sustainability

#### Climate Adaptation
*   **Ambient Temperature**: Design ambient is **50°C** for outdoor equipment.
*   **Derating**: Cables and switchgear must be derated for high ambient temperatures and grouping.
*   **IP Ratings**: Minimum IP55 for outdoor equipment; IP65/66 for areas exposed to direct washdown or heavy dust.
*   **Corrosion**: Use of 316L Stainless Steel or specialized coatings in coastal areas (e.g., Dubai Marina, Abu Dhabi Corniche).

#### Sustainability (Green Buildings)
*   **Dubai (Al Sa'fat)**: Limits Lighting Power Density (LPD).
    *   Offices: ~10-12 W/m².
    *   Retail: ~15-18 W/m².
*   **Abu Dhabi (Estidama)**: Pearl Rating System requires energy-efficient lighting and sub-metering for loads > 100kW.

---

### 7. Professional Practice and Checklists

#### Design Review Checklist
*   [ ] Verify voltage drop for the longest circuit run.
*   [ ] Ensure discrimination/coordination between upstream and downstream breakers.
*   [ ] Check RCD protection (30mA for sockets/water heaters, 100/300mA for general power).
*   [ ] Confirm transformer room ventilation and access as per utility standards.
*   [ ] Verify emergency lighting duration (3 hours) and lux levels (10.8 lux avg for egress).

#### Emergency Lighting Requirements
*   **Duration**: 3 hours (180 minutes) minimum.
*   **Illumination**: 10.8 lux average for egress paths; 1 lux minimum along the centerline of corridors.
> "The UAE Fire and Life Safety Code mandates a minimum 3-hour (180 minute) emergency lighting duration... Escape Routes: Minimum 1 lux along the centerline." — LinkedIn: Adel Alani [[15]](#ref15)

---

### Sources

#### Primary Sources
*   **DEWA Regulations for Electrical Installations (2017) [[11]](#ref11)
*   **Abu Dhabi Electricity Wiring Regulations (2020) [[16]](#ref16)
*   **Dubai Building Code (2021) [[17]](#ref17)
*   **UAE Fire and Life Safety Code of Practice (2018) [[7]](#ref7)

#### Secondary Sources
*   **UAE Electrical Standards & Regulations Guide (Scribd) [[12]](#ref12)
*   **LinkedIn Technical Articles (Fozan Hameed, Adel Alani)**: Cited for specific earthing and emergency lighting interpretations.

---

### Gaps and Verification Notes
*   **EtihadWE Specifics**: While EtihadWE follows FEWA legacy codes, specific 2024 circulars for Northern Emirates are often issued via internal portals; verification of the latest "Green Building" requirements for Ras Al Khaimah/Fujairah is recommended.
*   **MV Design**: Detailed MV protection settings (IDMT curves) are typically project-specific and require direct coordination with utility engineers during the "Protection Study" phase.
*   **Paywalled Standards**: IEC and BS standards are referenced but full text requires purchase; design values are based on local authority interpretations of these standards.

---


## 3. Plumbing, Drainage, and Water Supply

# Source Packet 13: Plumbing, drainage and water supply engineering: potable water, sanitary drainage, stormwater, pumps, tanks, irrigation, authority rules and international plumbing standards

**Research topic:** Plumbing, drainage and water supply engineering: potable water, sanitary drainage, stormwater, pumps, tanks, irrigation, authority rules and international plumbing standards

**Report title:** UAE Plumbing, Drainage, and Water Supply Engineering Research Report

# UAE Plumbing, Drainage, and Water Supply Engineering Research Report

This report provides a comprehensive collection of source-backed engineering knowledge for the UAE plumbing, drainage, and water supply domain, covering Dubai and Abu Dhabi specifically.

## 1. Domain Scope and UAE Relevance
Plumbing and drainage engineering in the UAE encompasses the design, installation, and maintenance of potable water supply, sanitary drainage, stormwater management, and irrigation systems. Given the UAE's arid climate and rapid urban development, water conservation and efficient drainage are critical.
- **Typical Projects**: High-rise residential and commercial towers, luxury villas, industrial facilities, and large-scale infrastructure projects (e.g., Dubai South, Abu Dhabi Yas Island).
- **Boundaries**: The scope includes internal building systems (from the point of entry/exit) and external plot-level infrastructure up to the authority connection point (F.I.C - Final Inspection Chamber for drainage, or the water meter for supply).

## 2. UAE Authorities and Approval Workflow
The approval process is strictly governed by local utility and municipal authorities.

### Dubai Authorities
- **DEWA (Dubai Electricity and Water Authority)**: Governs potable water supply, meter installations, and water storage requirements.
- **Dubai Municipality (DM)**: Oversees building drainage, sewerage, and irrigation systems.
- **Trakhees / Dubai South**: Authorities for specific free zones with their own variations of the building code.

### Abu Dhabi Authorities
- **ADDC (Abu Dhabi Distribution Company) / AADC (Al Ain Distribution Company)**: Govern water supply and metering.
- **DMT (Department of Municipalities and Transport) / ADM (Abu Dhabi Municipality)**: Oversee drainage and building permits.

### Approval Sequence (Typical)
1.  **NOC for Design**: Submission of plumbing and drainage layouts to DEWA/DM or ADDC/ADM for initial "No Objection Certificate."
    > "The application mandates specific, up-to-date documentation: The Affection Plan (Site Plan) issued by Dubai Municipality (DM) or the relevant free zone authority." — Elecwatts GCC [[18]](#ref18)
2.  **Building Permit**: Obtained from the Municipality after NOCs are secured.
3.  **Inspections**: Periodic site inspections by authority engineers (e.g., pressure tests for water lines, water-tightness tests for manholes).
4.  **Completion Certificate & Connection**: Final inspection followed by the release of the water meter and connection to the public sewer/storm network.

## 3. Core Codes and Standards
UAE engineering practice relies on a mix of local codes and international standards.

### Local Codes
- **Dubai Building Code (DBC) 2021**: The primary unified code for Dubai. Part G (Utilities) covers plumbing and drainage.
- **Abu Dhabi International Plumbing Code (ADIPC) 2013**: Based on the International Plumbing Code (IPC) 2009, with local amendments.
- **UAE Fire and Life Safety Code of Practice (2018)**: Critical for fire water storage and pump requirements.

### International Standards
- **IPC (International Plumbing Code)**: Widely used as the base for UAE codes.
- **UPC (Uniform Plumbing Code)**: Often referenced for conservative pipe sizing.
- **BS EN Standards**: Used for material specifications (e.g., BS EN 1329 for uPVC drainage).

## 4. Technical Design Content

### Potable Water Supply
- **Daily Water Demand**:
    - Residential: 135–180 Liters/person/day.
    - Offices: 45 Liters/person/day.
    - Hotels/Restaurants: 70 Liters/seat/day.
    > "Residential: 135–180 L/person·day, Offices: 45 L/person·day." — Abhishek Mohite, LinkedIn [[19]](#ref19)
- **Storage Tank Sizing**:
    - Standard buildings require a 24-hour reserve.
    - Labor accommodations require a 48-hour reserve.
    - Underground Tank (UGT) typically holds 50-100% of daily demand; Overhead Tank (OHT) holds the remainder.
- **Pump Selection**:
    - Configuration: 1 Duty + 1 Standby (minimum).
    - Transfer pumps move water from UGT to OHT; Booster pumps maintain pressure for top floors.

### Sanitary Drainage
- **Pipe Slopes**:
    - 100mm diameter: 1:60 minimum.
    - 150mm diameter: 1:90 minimum.
    - 200mm diameter: 1:120 minimum.
    > "Slopes for horizontal runs shall be as follows: FOR 100 MM - 1:60, FOR 150 MM - 1:90." — DM Drainage Regulation [[20]](#ref20)
- **Manholes**:
    - Maximum distance between manholes: 15 meters for villas/buildings.
    - Venting: Required for the first and last manholes of a line.

### Stormwater Drainage
- **Design Return Period**: Typically 1-in-25 years for building plots in Dubai.
- **Attenuation**: Due to limited public network capacity, many plots require attenuation tanks to store runoff and release it at a controlled rate.
    > "A 2-hectare commercial site in Dubai... typically needs 1,500 to 2,500 cubic metres for a 1-in-25 year event." — Aqua Rainwater [[21]](#ref21)

## 5. Construction, Testing, and Commissioning
- **Pipe Protection**: Underground pipes must have at least 600mm cover or be encased in concrete (150mm thick) if shallower.
- **Testing**:
    - **Water Supply**: Hydrostatic pressure test at 1.5 times the working pressure (minimum 10 bar) for 24 hours.
    - **Drainage**: Water test (filling the system and checking for drops in level) or air test.
- **Commissioning**: Disinfection of water tanks and piping using chlorine (typically 50 ppm for 24 hours) is mandatory before handover.

## 6. UAE Climate, Durability, and Sustainability

### Climate and Durability
- **Heat**: Water in tanks can reach high temperatures; insulation or chillers are often required for potable water.
- **Legionella Control**: High ambient temperatures increase risk.
    - Hot water must be stored at ≥60°C and return at ≥55°C.
    > "Hot water storage must be ≥60 °C at the heater. Return hot water in circulation lines must be ≥55 °C." — Hussain, LinkedIn [[22]](#ref22)

### Sustainability
- **Al Sa'fat (Dubai)**: Mandates water-efficient fixtures (e.g., WC ≤ 6L/flush, Showers ≤ 9.5L/min).
- **Estidama (Abu Dhabi)**: Uses the Pearl Rating System to enforce water reduction through low-flow fixtures and greywater recycling for irrigation.

## 7. Professional Practice and Checklists

### Design Review Checklist
- [ ] Verify daily demand against DBC Table H.6.
- [ ] Ensure dual compartments for all water tanks (for maintenance).
- [ ] Check for 2-meter clearance between water and electrical service points.
- [ ] Confirm manhole venting and spacing (max 15m).
- [ ] Ensure no drainage pipes run through electrical rooms or substations.

### Common Mistakes
- **Inadequate Freeboard**: Failing to provide 200-300mm freeboard in water tanks.
- **Direct Connections**: Connecting floor traps directly to other floor traps (prohibited).
- **Sump Pump Errors**: Failing to provide a "wet" connection to rainwater sumps to maintain the trap seal.

## 8. Gaps and Verification Notes
- **Stormwater Updates**: Dubai Municipality issued new Stormwater Design Guidelines in January 2025; specific discharge limits for new districts should be verified per project.
- **ADIPC 2013**: While still the reference, many consultants follow the latest IPC (2021/2024) for best practices where local code is silent.

## Sources
- **Dubai Building Code (DBC) 2021 [[2]](#ref2)
- **Dubai Municipality Drainage Regulations [[20]](#ref20)
- **DEWA Circulars & Regulations [[1]](#ref1)
- **UAE Fire and Life Safety Code of Practice (2018) [[7]](#ref7)
- **Legionella Control Guidelines (DM-HSD-GU44) [[23]](#ref23)
- **Stormwater Management GCC Guide [[21]](#ref21)

**Checklist Status**: All items completed. File path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/964a85b5/RESEARCH_CHECKLIST.md`

---


## 4. Fire and Life Safety Engineering

# Source Packet 9: Fire and life safety engineering: UAE Fire and Life Safety Code, Civil Defense approvals, NFPA, alarms, sprinklers, smoke control, egress and special occupancies

**Research topic:** Fire and life safety engineering: UAE Fire and Life Safety Code, Civil Defense approvals, NFPA, alarms, sprinklers, smoke control, egress and special occupancies

**Report title:** Fire and Life Safety Engineering: UAE Knowledge Library Shard

# Fire and Life Safety Engineering: UAE Knowledge Library Shard

This document provides a comprehensive technical overview of Fire and Life Safety (FLS) engineering in the United Arab Emirates, focusing on the **UAE Fire and Life Safety Code of Practice (2018)**, Civil Defense approval workflows, and technical design criteria for active and passive fire protection systems.

---

## 1. Domain Scope
Fire and Life Safety engineering in the UAE is a critical discipline mandated for all built environments to protect life, property, and the environment. The domain encompasses the design, installation, and maintenance of systems that detect, contain, and extinguish fires while ensuring safe occupant egress.

*   **UAE Relevance**: The UAE has one of the world's highest concentrations of high-rise and super high-rise buildings, necessitating stringent fire safety regulations.
*   **Typical Projects**: Residential towers, commercial malls, industrial warehouses, infrastructure (tunnels/airports), and "Super High-Rise" buildings (habitable height >90m).
*   **Boundaries**: Intersects with Architectural (egress/compartmentation), MEP (sprinklers/alarms/smoke control), and Structural (fireproofing) engineering.

---

## 2. UAE Authorities and Approval Workflow
The **Directorate General of Civil Defense** (under the Ministry of Interior) is the primary Authority Having Jurisdiction (AHJ). Each emirate has its own command (e.g., Dubai Civil Defense - DCD, Abu Dhabi Civil Defense Authority - ADCDA).

### 2.1. Approval Sequence
1.  **Initial Approval (Engineering Drawing Approval)**:
    *   Submission of FLS Strategy Report and Drawings (Architectural, Sprinkler, Alarm, Smoke Management).
    *   "Engineering Drawing approvals ensuring compliance with DCD regulations." — Dubai Civil Defence [[24]](#ref24)
2.  **Specialist Accreditations**:
    *   Abu Dhabi recently launched a "mandatory accreditation initiative for engineering consultancy offices... in the field of Fire Protection and Life Safety Engineering." — ADCDA [[25]](#ref25)
3.  **Installation & NOCs**:
    *   Installation must be by DCD-approved contractors using DCD-approved materials (UL/FM listed).
4.  **Final Inspection & Completion Certificate**:
    *   Requires a "6-page application typed in Arabic," trade licenses, and certificates for all FLS equipment. — Fitout Approvals [[26]](#ref26)
    *   **Hassantuk**: Mandatory registration for 24/7 smart monitoring of fire alarm systems.

---

## 3. Core Codes and Standards
*   **Primary Code**: **UAE Fire and Life Safety Code of Practice (2018 Edition)**. This is the "Bible" for FLS in the UAE.
*   **International Standards (Referenced)**:
    *   **NFPA 13**: Installation of Sprinkler Systems.
    *   **NFPA 72**: National Fire Alarm and Signaling Code.
    *   **NFPA 92**: Standard for Smoke Control Systems.
    *   **NFPA 101**: Life Safety Code (for egress principles).
    *   **NFPA 20**: Standard for the Installation of Stationary Pumps for Fire Protection.

---

## 4. Technical Design Content

### 4.1. Fire Detection and Alarm Systems (NFPA 72 / UAE Code Ch. 8)
*   **Spacing**: Smoke detectors typically follow a 9.1m radius spacing in open areas. — Cactus GGT [[27]](#ref27)
*   **Hassantuk Integration**: All fire alarm control panels (FACP) must be connected to the Hassantuk system for direct transmission of alarms to Civil Defense.
*   **Audibility**: Minimum 75 dBA or 15 dBA above ambient noise levels in sleeping areas.

### 4.2. Fire Suppression Systems (NFPA 13 / UAE Code Ch. 9)
*   **Sprinkler Density**: 
    *   Light Hazard: 0.10 gpm/ft² over 1500 ft².
    *   Ordinary Hazard (Group 1): 0.15 gpm/ft² over 1500 ft².
*   **Water Supply Duration**: 
    *   Light Hazard: 30–60 minutes.
    *   Ordinary Hazard: 60–90 minutes.
    *   High Hazard: 120 minutes.
*   **Testing**: "Hydrostatic Test: 200 psi (13.8 bar) for 2 hours." — Ramesh Babu [[28]](#ref28)

### 4.3. Means of Egress (UAE Code Ch. 7)
*   **Travel Distance**:
    *   Dead-end corridors: Generally limited to 6m (sprinklered) or 3m (non-sprinklered) in high-risk areas, though some occupancies allow up to 15m.
    *   Common path of travel: Typically 23m to 30m depending on occupancy.
*   **Exit Width**: Calculated based on 5mm per person for stairs and 4mm per person for level components (ramps/doors).

### 4.4. Smoke Management (NFPA 92 / UAE Code Ch. 10)
*   **Staircase Pressurization**: "Pressure differential: 50 Pa (between staircase and adjacent area)." — Hussain N. [[29]](#ref29)
*   **Door Force**: Opening force must not exceed 60 N to ensure accessibility during pressurization.

---

## 5. Special Occupancies: Super High-Rise (>90m)
Buildings over 90m in habitable height require enhanced measures:
*   **Refuge Floors**: Mandatory at intervals. "First refuge area shall be provided at or immediately above 24 m height. Thereafter, refuge area shall be provided at every 15 m interval [or every 20 floors depending on specific occupancy]." — Kazi Hasanul Haque [[30]](#ref30)
*   **Fire Lifts**: Required for buildings >23m. Must have a 2-hour fire-rated shaft and dedicated power.
*   **Voice Evacuation**: Mandatory for high-rise buildings to provide clear instructions during emergencies.

---

## 6. UAE Climate, Durability, and Safety Notes
*   **Heat & Humidity**: Outdoor equipment (fire hydrants, cabinets) must be UV-stabilized and corrosion-resistant. High ambient temperatures (50°C) require derating of electrical components for fire pumps.
*   **Dust/Sand**: Smoke detectors in semi-outdoor areas (parking) often require dust-compensation or the use of heat detectors to prevent false alarms.
*   **Corrosion**: Proximity to the coast necessitates the use of galvanized or epoxy-coated piping for fire networks to prevent premature failure.

---

## 7. Construction Supervision and Commissioning
*   **Material Approval**: All FLS materials must have a "Certificate of Compliance" (CoC) from a DCD-approved laboratory.
*   **Interface Testing**: A critical step where the Fire Alarm system is tested against the "Cause and Effect Matrix" (e.g., alarm triggers lift homing, fan start/stop, and magnetic door release).
*   **Handover**: Requires a maintenance contract with a DCD-approved company for at least one year.

---

## 8. Professional Practice and Checklists
### 8.1. Design Review Checklist
*   [ ] Verify travel distances against Table 7.1 of the UAE Fire Code.
*   [ ] Ensure all fire-rated walls are continuous from slab to slab.
*   [ ] Check that fire pump capacity meets the most hydraulically demanding area.
*   [ ] Confirm Hassantuk connection points are identified.

### 8.2. Common Mistakes
*   Using non-UL/FM listed components for fire systems.
*   Inadequate clearance around sprinkler heads (minimum 450mm).
*   Failing to provide fire dampers where ducts penetrate fire-rated compartments.

---

## Sources

### Primary Sources
*   **UAE Fire and Life Safety Code of Practice (2018)**, Abu Dhabi Civil Defense Authority (ADCDA) Digital Library [[7]](#ref7)
*   **Dubai Civil Defense (DCD) Portal**, Engineering Services and Regulations [[24]](#ref24)
*   **Abu Dhabi Civil Defense Authority (ADCDA)**, Official Website and Services [[25]](#ref25)

### Secondary/Technical Sources
*   **Cactus GGT**, UAE Workplace Fire Safety Checklist 2026 [[27]](#ref27)
*   **LinkedIn Technical Articles**:
    *   Hussain N., Staircase Pressurization Systems in UAE [[29]](#ref29)
    *   Kazi Hasanul Haque, Refuge Floor Requirements [[30]](#ref30)
    *   Ramesh Babu, NFPA and Civil Defence Standards for Sprinklers [[28]](#ref28)
*   **BSB Group**, Fire Safety Masterclass: Super High-Rise Buildings [[31]](#ref31)

---

## Gaps and Verification Notes
*   **2024/2026 Updates**: While the 2018 Code is the current published standard, Civil Defense often issues "Circulars" for specific new requirements (e.g., EV charging in parking). These circulars are often not in the main PDF and require verification via the DCD/ADCDA e-services portal.
*   **Fee Structures**: Specific approval fees are subject to change and vary by project size/type; these should be verified at the time of submission.
*   **Paywalled Standards**: Detailed NFPA standards (13, 72, 92) require a subscription for full text access, though the UAE Code summarizes the key local deviations.

---


## 5. MEP Coordination, BIM, and Commissioning

# Source Packet 12: MEP coordination, BIM, digital engineering and commissioning: BIM standards, clash coordination, testing, balancing, handover, O&M, FM integration

**Research topic:** MEP coordination, BIM, digital engineering and commissioning: BIM standards, clash coordination, testing, balancing, handover, O&M, FM integration

**Report title:** MEP Coordination, BIM, Digital Engineering, and Commissioning: UAE Engineering Shard

# MEP Coordination, BIM, Digital Engineering, and Commissioning: UAE Engineering Shard

## 1. Domain Scope
In the UAE construction sector, MEP (Mechanical, Electrical, and Plumbing) coordination and Digital Engineering represent the critical integration layer between design intent and physical execution. This domain encompasses the lifecycle management of building information, from 3D clash detection and spatial coordination to the systematic testing, balancing, and commissioning (T&C) of systems to ensure they meet the UAE's rigorous performance and sustainability standards.

Typical projects in the UAE—ranging from super-tall skyscrapers like the Burj Khalifa to massive infrastructure developments like the Etihad Rail—rely on Building Information Modeling (BIM) to manage the extreme complexity of MEP systems. The scope includes:
- **MEP Coordination:** Spatial arrangement of ducts, pipes, and cable trays to avoid conflicts with structural elements and other services.
- **Digital Engineering:** The use of BIM for automated code compliance, quantity take-offs, and 4D/5D scheduling.
- **Commissioning (Cx):** The process of verifying that all building systems (HVAC, Fire, Electrical, Plumbing) perform according to the Owner’s Project Requirements (OPR) and UAE regulations.
- **FM Integration:** The transition of digital assets (As-Built BIM, COBie data) into Facilities Management systems for long-term operations.

## 2. UAE Authorities and Approval Workflow
The UAE has pioneered the integration of BIM into the regulatory approval process, particularly in Dubai and Abu Dhabi.

### 2.1 Dubai Municipality (DM) BIM Mandate
Dubai Municipality has issued several circulars mandating BIM for specific project types to enhance coordination and reduce construction waste.
- **Circular 196 (2013):** First introduced BIM requirements for buildings over 40 floors or 300,000 sq. ft.
- **Circular 207 (2015):** Expanded the mandate to include buildings over 20 floors, government projects, and specialized facilities like hospitals and universities.
- **2024/2026 Updates:** As of April 1, 2026, mandatory BIM submission for architectural and structural designs applies to buildings with 12 floors or more, or those with a Built-Up Area (BUA) of 15,000 sq. m or more. Resubmission is required for modifications involving additional floors or an area increase of 1,500 sq. m. — *Dubai Municipality Circular No. (9-1-3) of 2026, LinkedIn/Ar Saif.*

### 2.2 Abu Dhabi Department of Municipalities and Transport (DMT)
Abu Dhabi utilizes the **DMT BIM Manual** for infrastructure and building projects. Submissions must comply with specific naming conventions, coordinate systems (typically UTM/WGS84), and file formats (IFC and native Revit/Civil 3D).
- **e-Submission:** BIM models are submitted through the "Meqta" or "BIM e-Submission" portals for automated and manual review against the Abu Dhabi International Building Code.

### 2.3 Trakhees and Free Zone Authorities
Authorities like Trakhees (PCFC) and Dubai Development Authority (DDA) require 3D MEP coordination drawings as part of the Building Permit (BP) and Fit-out Permit applications. Trakhees specifically emphasizes 3D clash detection reports for complex industrial and commercial projects in JAFZA and Dubai Maritime City.

### 2.4 UAE Civil Defense (UCD)
UCD requires witnessing the commissioning of all fire and life safety systems. The workflow includes:
1. **Installation Inspection:** Verification of UCD-approved materials.
2. **Functional Testing:** Testing of fire pumps, sprinklers, and smoke management systems.
3. **Integrated Testing:** Verification of the fire alarm interface with HVAC (fan shutdown), elevators (homing), and access control (door release).

## 3. Core Codes and Standards
### 3.1 International Standards
- **ISO 19650-1 & 2:** The international standard for information management using BIM. It defines the Common Data Environment (CDE) and the roles of the Appointing Party and Lead Appointed Party.
- **ASHRAE Guideline 0 & 1.1:** For the commissioning process and HVAC system commissioning.
- **BSRIA BG 29/2021 & BG 6/2018:** Standards for pre-commission cleaning of pipework and design framework for building services.
- **CIBSE Commissioning Codes:** Including Code A (Air Distribution), Code W (Water Distribution), and Code M (Management).

### 3.2 UAE-Specific Codes
- **Dubai Building Code (DBC) 2021:** Unifies design requirements across Dubai, including digital engineering and MEP integration.
- **UAE Fire and Life Safety Code of Practice:** Mandates specific commissioning and maintenance intervals for safety systems.
- **Estidama Pearl Rating System (Abu Dhabi):** Requires "Fundamental Commissioning" (IDP-R1) as a mandatory credit to ensure energy efficiency and system performance.

## 4. Technical Design and Coordination
### 4.1 BIM Levels and LOD
In the UAE, MEP projects typically follow **LOD (Level of Development) 300** for design and **LOD 400** for construction/fabrication.
- **LOD 300:** Systems are modeled with accurate size, shape, and location for coordination.
- **LOD 400:** Includes fabrication-level detail, such as hangers, supports, and specific manufacturer data.

### 4.2 Clash Detection Workflow
Effective MEP coordination in the UAE follows a tiered clash detection strategy:
1. **Hard Clashes:** Physical intersections (e.g., a 400mm duct passing through a structural beam).
2. **Soft/Clearance Clashes:** Violations of maintenance access or insulation space (e.g., a cable tray blocking access to a VAV box).
3. **Workflow Clashes:** Sequencing issues (e.g., installing a large chiller before the plant room walls are completed).
> "BIM submission for a building permit will include BIM models in IFC format... The IFC files exported from BIM authoring tools should only include information essential for permitting purposes." — *LinkedIn/Fahdah [[32]](#ref32)

### 4.3 Testing, Adjusting, and Balancing (TAB)
TAB is the core of MEP commissioning.
- **Air Balancing:** Ensuring the Actual Airflow (CFM/L/s) at each grille is within ±10% of the Design Airflow.
- **Water Balancing:** Adjusting flow rates in chilled water circuits using Double Regulating Valves (DRVs) or Pressure Independent Control Valves (PICVs).
- **Tolerances:** UAE projects typically follow BSRIA/CIBSE tolerances, where air systems are balanced to +10%/-5% and water systems to ±10%.

## 5. Construction Supervision and Commissioning
### 5.1 Commissioning Authority (CxA)
For Estidama or LEED-certified projects in the UAE, an independent Commissioning Authority (CxA) is required. The CxA reviews the **Commissioning Plan**, witnesses key tests, and compiles the **Final Commissioning Report**.

### 5.2 Handover Documentation
The handover package in the UAE typically includes:
- **As-Built Drawings:** Reflecting the final site installation.
- **O&M Manuals:** Operation and Maintenance instructions for all equipment.
- **Asset Register:** A list of all maintainable assets (pumps, fans, DBs) with serial numbers and warranty dates.
- **COBie (Construction Operations Building information exchange):** A spreadsheet-based data format used to transfer BIM data into FM software.

## 6. UAE Climate, Durability, and Sustainability
### 6.1 Extreme Heat and Humidity
- **Condensation Management:** High humidity in coastal cities like Dubai and Abu Dhabi requires meticulous insulation of chilled water pipes and ducts. Any gap in the vapor barrier leads to rapid condensation and mold growth.
- **De-rating of Equipment:** Electrical components (transformers, switchgear) must be de-rated for ambient temperatures that can exceed 50°C.

### 6.2 Dust and Sand
- **Filtration:** HVAC systems require multi-stage filtration (Pre-filters + Bag filters) to handle high dust loads. Commissioning must verify that pressure drops across filters are within design limits.
- **Sensor Protection:** Outdoor sensors (Lux sensors, CO2 sensors) must be IP-rated and protected from sand ingress.

### 6.3 Sustainability (Estidama/Al Sa'fat)
- **Water Conservation:** Commissioning of greywater recycling systems and high-efficiency irrigation is critical for meeting UAE sustainability targets.
- **Energy Monitoring:** Verification of the Building Management System (BMS) and energy meters is mandatory to ensure the building operates within its designed energy budget.

## 7. Professional Practice and Checklists
### 7.1 MEP Coordination Checklist
- [ ] Verify structural clearances for all major duct crossings.
- [ ] Ensure 100mm minimum clearance between services for insulation and maintenance.
- [ ] Check that all valves and dampers are accessible via access panels.
- [ ] Coordinate drainage slopes (typically 1:50 or 1:100) with other services.
- [ ] Verify that cable trays do not run directly under water pipes.

### 7.2 Commissioning Readiness Checklist
- [ ] All static testing (pressure tests, insulation resistance) completed and signed off.
- [ ] Power available and permanent water connection established.
- [ ] BMS head-end operational and point-to-point testing completed.
- [ ] Manufacturer’s start-up reports available for major equipment (Chillers, AHUs).

## 8. Sources
- **Dubai Municipality:** Circular 207 (2015) and Circular (9-1-3) of 2026 regarding BIM Mandates. []() [[33]](#ref33)
- **Abu Dhabi DMT:** Estidama Pearl Building Rating System v1.0. []() [[34]](#ref34)
- **Dubai Building Code 2021:** Unified design and digital engineering standards. []() [[35]](#ref35)
- **LinkedIn/Fahdah:** Dubai's Mandatory BIM Submission for Building Permits. []() [[36]](#ref36)
- **Core Emirates:** O&M Handover documentation production services. []() [[37]](#ref37)
- **Trent Technical Services:** HVAC Testing & Balancing standards (BSRIA/CIBSE). []() [[38]](#ref38)

## 9. Gaps and Verification Notes
- **Specific Fees:** BIM submission fees for automated code checking are not publicly detailed and vary by project scale; verification with DM/DDA is required during the permit application.
- **Software Versions:** While IFC is the standard, specific versions (IFC 2x3 vs IFC 4) accepted by the DM portal should be verified against the latest "Build in Dubai" technical guidelines.
- **Civil Defense Witnessing Fees:** UCD inspection fees are subject to periodic updates and should be verified via the MOI/Civil Defense smart portal.

---


## 6. MEP Design Review Checklist

### MEP integrated design review

1. **HVAC cooling load** — Confirm outdoor design conditions (46°C DB / 29°C WB for Dubai), internal gains, occupancy schedule, façade U-values and SHGC match approved architectural drawings.
2. **Duct/pipe sizing** — Verify velocity, pressure drop, balancing strategy and district cooling ETS connection parameters.
3. **Electrical load schedule** — Check connected load, demand factor, diversity, fault level (40 kA for Dubai), cable sizing, voltage drop limits (<5% end-to-end) and earthing system (TN-S standard for DEWA).
4. **Plumbing storage** — Confirm 24-hour demand storage for potable water, separate suction/overhead tanks, minimum 2-metre separation from sewage tanks, and DEWA metering position.
5. **Fire suppression** — Verify sprinkler density vs hazard classification (NFPA 13), fire water tank capacity = flow × duration, pump duty/standby/jockey set, and Civil Defense submission package.
6. **Egress and smoke control** — Confirm travel distances, corridor widths, staircase pressurisation levels, atrium exhaust rates (min 6 ACH below 600,000 ft³), and voice evacuation interface.
7. **BIM model coordination** — Check for clashes in structure, ductwork, pipework, cable trays, and equipment rooms; confirm COBie data for all assets; verify device naming to BDNS schema.
8. **Commissioning plan** — Confirm TAB contractor appointment, CIBSE Commissioning Codes reference, DM/DCD/DEWA inspection sequence, and O&M manual scope.


## Expert Appendix: Field Control, Design Review, and Authority Coordination Templates

### Template A: Design Review Checklist Framework
A senior engineering design review should confirm: design basis and load assumptions are documented; code edition and amendment dates are stated; all UAE authority requirements have been addressed by reference; specialist sub-consultant inputs are incorporated and coordinated; sustainability compliance (Al Sa'fat or Estidama as applicable) is addressed; fire and life safety interfaces are resolved; and the drawing set matches calculations and specifications. Any deviation from code requires a written technical justification.

### Template B: Authority Submission Package
Before submitting to any UAE authority, confirm: the submitting consultant firm holds a valid practising card/approval for the project emirate; drawings are in the required format and coordinate system; all NOCs from upstream authorities are attached; calculations are signed by a registered engineer; the BIM model (if mandated under DM Circular 9-1-3/2026 or Abu Dhabi DMT requirements) is attached in the required format; and fees or bonds have been paid. Incomplete packages are returned without review in most Dubai and Abu Dhabi portals.

### Template C: Site Supervision and Inspection Record
For each Witness or Hold point on the ITP, the site supervisor should confirm: the work activity matches the approved shop drawing; material has a valid test certificate or Material Approval Request (MAR); pre-activity conditions (compaction, formwork, earthing, cleanliness) are met; work execution matches approved method statement; post-activity tests are conducted and recorded; Non-Conformance Reports are raised immediately for failures; and the record is signed, dated, and uploaded to the document management system.

### Template D: Commissioning and Handover Record
The commissioning package should include: signed Commissioning Manager appointment; pre-commissioning mechanical completion certificates; equipment startup records with measured versus specified values; functional test sheets for all systems; cause-and-effect matrix testing records for life-safety interfaces; Training records for the building operator; Operating and Maintenance manuals with as-built BIM model; and a Defect Tracking Register. In Dubai, DEWA/DCD and DM will conduct their own independent inspections before issuing the Completion Certificate.

### Template E: Professional Risk Register for UAE Engineering Projects
Key project risks to track: BIM submission readiness; NOC expiry dates and renewal sequences; Specialist material lead times (high-performance concrete, specialist glazing, medical gas equipment); Third-party inspection availability; Civil Defense comments on fire systems; Authority variations discovered late in design; Structural peer review findings; Geotechnical report limitations; Weather restrictions on concrete pours; Power supply sequencing for DEWA connection; District Cooling provider connection timing; and Snagging management strategy for Completion Certificate.


## Extended Technical Reference: MEP Engineering Deep Dive

### HVAC Psychrometric Analysis for UAE Climate
UAE outdoor conditions create extreme cooling demand. Key psychrometric parameters for Dubai:
- **Summer design: 46°C DB / 29°C WB** → Specific enthalpy ≈ 90–95 kJ/kg; humidity ratio ≈ 19–21 g/kg.
- **Cooling coil apparatus dew point (ADP):** Target 11–13°C for dehumidification; bypass factor 0.08–0.15 typical.
- **Sensible heat ratio (SHR):** Office buildings typically 0.80–0.90; high-occupancy spaces (lobbies, auditoriums) can drop to 0.60–0.70 requiring dedicated outdoor air systems (DOAS).
- **District Cooling (DC) supply temperature:** Typically 5–7°C from the provider; building secondary delta-T must reach at least 8°C for efficient operation; ETS plate heat exchanger selected for 5°C primary/secondary approach temperature.
- **Chiller COP:** For standalone chillers >350 kW, minimum EER of 3.0 (ASHRAE 90.1 baseline); VSD-equipped centrifugal chillers achieve IPLV/NPLV of 6.0–9.0.

### Electrical Load Calculation Method (Dubai DEWA)
DEWA Regulations 2017 specify:
- **Demand factor for LV distribution:** Use DEWA Table values based on building type; residential units typically 50–80% diversity.
- **Power factor:** Must not fall below 0.90 lagging at the point of supply; capacitor banks or VSD drives used for correction.
- **Harmonics:** Total Harmonic Distortion (THD-I) must not exceed 5% at the PCC (point of common coupling) for buildings with significant non-linear loads (UPS, VFDs, LED drivers).
- **Standby generator sizing:** Size for 100% of life-safety loads + 80% of critical loads; diesel generator starting dip must not reduce bus voltage below 80% Vn for more than 3 seconds.
- **Short-circuit withstand:** All equipment must have a rated short-circuit withstand capacity ≥ 40 kA (rms symmetrical) for equipment within DEWA substations; internal LV panel ratings verified per IEC 61439-1/2.

### Plumbing System Pressure Zones
For high-rise buildings, the water supply system is divided into pressure zones to maintain between 1.5 and 4.5 bar at each fixture:
- **Zone break:** Typically every 10–15 storeys using a booster pump set and break tank, or pressure-reducing valves (PRVs) on downfeed systems.
- **PRV sizing:** Select PRV flow coefficient (Cv) for maximum flow at minimum upstream pressure minus static head; provide bypass and strainer.
- **Domestic hot water (DHW):** Centralised heat exchanger with recirculation loop; insulate all hot pipes; design recirculation to maintain 60°C at all dead-legs within 15 seconds flow; Legionella risk assessment required for hotels and healthcare.
- **Grease trap sizing:** Per BS EN 1825 / PDI G101; kitchen flow rate multiplied by retention time (typically 15–25 min); interceptor must be accessible and serviced every 3 months.

### Fire Detection and Alarm System Design Depths
- **Analogue addressable (preferred):** Each detector/call point has a unique address; allows real-time status, drift compensation, and cause-and-effect programming.
- **Linear heat detection:** Used in cable trays, tunnels, transformer rooms, and concealed spaces; response temperature 68°C or 88°C depending on ambient.
- **Aspirating smoke detection (ASD / VESDA):** Mandatory in clean rooms, data centres, heritage spaces, and concealed roof voids above critical assets; response time < 30 seconds at ASD sensitivity.
- **Cause and effect matrix:** Every input (detector, call point, flow switch, tamper switch) must be mapped to every output (alarm, door release, damper close, fan shutdown, lift recall, voice evacuation zone); Civil Defense verify this matrix during final inspection.


## References

<p id="ref1" class="ref_item">[1] dewa.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dewa.gov.ae/en/builder/useful-tools/dewa-circulars">https://www.dewa.gov.ae/en/builder/useful-tools/dewa-circulars</a></p>
<p id="ref2" class="ref_item">[2] dda.gov.ae <a target="_blank" rel="noreferrer" href="https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf">https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf</a></p>
<p id="ref3" class="ref_item">[3] services.dha.gov.ae <a target="_blank" rel="noreferrer" href="https://services.dha.gov.ae/tahpi-app/HealthFacilityGuidelines/Guidelines/FileContent/Preview/DHAHFG/Part%20E_2%20-%20Mechanical%20(HVAC">https://services.dha.gov.ae/tahpi-app/HealthFacilityGuidelines/Guidelines/FileContent/Preview/DHAHFG/Part%20E_2%20-%20Mechanical%20(HVAC</a></p>
<p id="ref4" class="ref_item">[4] mediaoffice.abudhabi <a target="_blank" rel="noreferrer" href="https://www.mediaoffice.abudhabi/en/energy/abu-dhabi-department-of-energy-launches-cooling-load-manual-to-enhance-energy-efficiency-and-sustainable-building-design/">https://www.mediaoffice.abudhabi/en/energy/abu-dhabi-department-of-energy-launches-cooling-load-manual-to-enhance-energy-efficiency-and-sustainable-building-design/</a></p>
<p id="ref5" class="ref_item">[5] rsbdubai.gov.ae <a target="_blank" rel="noreferrer" href="https://rsbdubai.gov.ae/en/regulating-efficient-cooling">https://rsbdubai.gov.ae/en/regulating-efficient-cooling</a></p>
<p id="ref6" class="ref_item">[6] southenergy.ae <a target="_blank" rel="noreferrer" href="https://www.southenergy.ae/wp-content/uploads/2022/01/DC-01-District-Cooling-ETS-Guidelines-.pdf">https://www.southenergy.ae/wp-content/uploads/2022/01/DC-01-District-Cooling-ETS-Guidelines-.pdf</a></p>
<p id="ref7" class="ref_item">[7] adcda.gov.ae <a target="_blank" rel="noreferrer" href="https://www.adcda.gov.ae/-/media/Project/ADCDA/ADCDA/Digital-Library/UAE-Fire-and-Life-Safety-Code-of-Practice.pdf">https://www.adcda.gov.ae/-/media/Project/ADCDA/ADCDA/Digital-Library/UAE-Fire-and-Life-Safety-Code-of-Practice.pdf</a></p>
<p id="ref8" class="ref_item">[8] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/building-permit-steps/">https://www.dm.gov.ae/municipality-business/building-permit-steps/</a></p>
<p id="ref9" class="ref_item">[9] pages.dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://pages.dmt.gov.ae/en/Classification-Requirements">https://pages.dmt.gov.ae/en/Classification-Requirements</a></p>
<p id="ref10" class="ref_item">[10] scribd.com <a target="_blank" rel="noreferrer" href="https://www.scribd.com/document/736509581/old-statement">https://www.scribd.com/document/736509581/old-statement</a></p>
<p id="ref11" class="ref_item">[11] electricalwikipedia.wordpress.com <a target="_blank" rel="noreferrer" href="https://electricalwikipedia.wordpress.com/wp-content/uploads/2018/05/dewa-regulations-for-electrical-installations-2017-edition.pdf">https://electricalwikipedia.wordpress.com/wp-content/uploads/2018/05/dewa-regulations-for-electrical-installations-2017-edition.pdf</a></p>
<p id="ref12" class="ref_item">[12] scribd.com <a target="_blank" rel="noreferrer" href="https://www.scribd.com/document/971444758/01-100-Questions">https://www.scribd.com/document/971444758/01-100-Questions</a></p>
<p id="ref13" class="ref_item">[13] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/muhammad-sohail-68a875178_dewa-vs-addc-regulations-for-electrical-activity-7347134505620594688-RCHS">https://www.linkedin.com/posts/muhammad-sohail-68a875178_dewa-vs-addc-regulations-for-electrical-activity-7347134505620594688-RCHS</a></p>
<p id="ref14" class="ref_item">[14] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/fozan-hameed-2418b219_what-earthing-systems-are-recommended-for-activity-7408222890287849472-jFvH">https://www.linkedin.com/posts/fozan-hameed-2418b219_what-earthing-systems-are-recommended-for-activity-7408222890287849472-jFvH</a></p>
<p id="ref15" class="ref_item">[15] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/guide-emergency-lighting-from-code-compliance-adel-alani-iatrf">https://www.linkedin.com/pulse/guide-emergency-lighting-from-code-compliance-adel-alani-iatrf</a></p>
<p id="ref16" class="ref_item">[16] doe.gov.ae <a target="_blank" rel="noreferrer" href="https://www.doe.gov.ae/-/media/Project/DOE/Department-Of-Energy/Media-Center-Publications/EWR-2020-EN-V8-B-Online.pdf">https://www.doe.gov.ae/-/media/Project/DOE/Department-Of-Energy/Media-Center-Publications/EWR-2020-EN-V8-B-Online.pdf</a></p>
<p id="ref17" class="ref_item">[17] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/wp-content/uploads/2021/11/Dubai-Building-Code-2021-Edition.pdf">https://www.dm.gov.ae/wp-content/uploads/2021/11/Dubai-Building-Code-2021-Edition.pdf</a></p>
<p id="ref18" class="ref_item">[18] elecwattsgcc.com <a target="_blank" rel="noreferrer" href="https://elecwattsgcc.com/blog/dewa-approval-process-guide/">https://elecwattsgcc.com/blog/dewa-approval-process-guide/</a></p>
<p id="ref19" class="ref_item">[19] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/abhishek-mohite-9325211a6_dubaimunicipality-drainagedesign-mep-activity-7373348341792997376-F0mb">https://www.linkedin.com/posts/abhishek-mohite-9325211a6_dubaimunicipality-drainagedesign-mep-activity-7373348341792997376-F0mb</a></p>
<p id="ref20" class="ref_item">[20] scribd.com <a target="_blank" rel="noreferrer" href="https://www.scribd.com/document/467716577/DM-Drainage-Regulation-Full">https://www.scribd.com/document/467716577/DM-Drainage-Regulation-Full</a></p>
<p id="ref21" class="ref_item">[21] aquarainwater.com <a target="_blank" rel="noreferrer" href="https://aquarainwater.com/stormwater-management-gcc-guide/">https://aquarainwater.com/stormwater-management-gcc-guide/</a></p>
<p id="ref22" class="ref_item">[22] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/legionella-control-water-supply-engineering-designing-hussain-nfc8f">https://www.linkedin.com/pulse/legionella-control-water-supply-engineering-designing-hussain-nfc8f</a></p>
<p id="ref23" class="ref_item">[23] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/wp-content/uploads/2022/11/DM-HSD-GU44-LCWS2_Technical-Guidelines-for-Legionella-Control-in-Water-System_V3.pdf">https://www.dm.gov.ae/wp-content/uploads/2022/11/DM-HSD-GU44-LCWS2_Technical-Guidelines-for-Legionella-Control-in-Water-System_V3.pdf</a></p>
<p id="ref24" class="ref_item">[24] dcd.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dcd.gov.ae/portal/">https://www.dcd.gov.ae/portal/</a></p>
<p id="ref25" class="ref_item">[25] adcda.gov.ae <a target="_blank" rel="noreferrer" href="https://www.adcda.gov.ae/en">https://www.adcda.gov.ae/en</a></p>
<p id="ref26" class="ref_item">[26] instagram.com <a target="_blank" rel="noreferrer" href="https://www.instagram.com/reel/C-MmDe5NiBH/">https://www.instagram.com/reel/C-MmDe5NiBH/</a></p>
<p id="ref27" class="ref_item">[27] cactusggt.com <a target="_blank" rel="noreferrer" href="https://cactusggt.com/uae-workplace-fire-safety-checklist-2026/">https://cactusggt.com/uae-workplace-fire-safety-checklist-2026/</a></p>
<p id="ref28" class="ref_item">[28] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/ramesh-babu-siddavatam_firesafety-nfpa-civildefence-activity-7367061495370694656-cQaG">https://www.linkedin.com/posts/ramesh-babu-siddavatam_firesafety-nfpa-civildefence-activity-7367061495370694656-cQaG</a></p>
<p id="ref29" class="ref_item">[29] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/staircase-pressurization-systems-uae-high-rises-why-50-hussain-nqvuf">https://www.linkedin.com/pulse/staircase-pressurization-systems-uae-high-rises-why-50-hussain-nqvuf</a></p>
<p id="ref30" class="ref_item">[30] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/kazi-hasanul-haque-322683145_refuge-floor-not-just-a-code-requirement-activity-7432846627914252288-B2H-">https://www.linkedin.com/posts/kazi-hasanul-haque-322683145_refuge-floor-not-just-a-code-requirement-activity-7432846627914252288-B2H-</a></p>
<p id="ref31" class="ref_item">[31] bsbgroup.com <a target="_blank" rel="noreferrer" href="https://bsbgroup.com/blog/fire-safety-masterclass-chapter-three-super-high-rise-buildings">https://bsbgroup.com/blog/fire-safety-masterclass-chapter-three-super-high-rise-buildings</a></p>
<p id="ref32" class="ref_item">[32] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/dubais-mandatory-bim-submission-building-permits-your-fahdah-qofwf*">https://www.linkedin.com/pulse/dubais-mandatory-bim-submission-building-permits-your-fahdah-qofwf*</a></p>
<p id="ref33" class="ref_item">[33] mepmiddleeast.com <a target="_blank" rel="noreferrer" href="https://www.mepmiddleeast.com/business/article-34893-revealed-dubai-municipalitys-updated-bim-mandate">https://www.mepmiddleeast.com/business/article-34893-revealed-dubai-municipalitys-updated-bim-mandate</a></p>
<p id="ref34" class="ref_item">[34] dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dmt.gov.ae/">https://www.dmt.gov.ae/</a></p>
<p id="ref35" class="ref_item">[35] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/planning-and-construction/dubai-building-code-2/">https://www.dm.gov.ae/municipality-business/planning-and-construction/dubai-building-code-2/</a></p>
<p id="ref36" class="ref_item">[36] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/dubais-mandatory-bim-submission-building-permits-your-fahdah-qofwf">https://www.linkedin.com/pulse/dubais-mandatory-bim-submission-building-permits-your-fahdah-qofwf</a></p>
<p id="ref37" class="ref_item">[37] core-group.me <a target="_blank" rel="noreferrer" href="https://core-group.me/ommhandover-documentationproduction/">https://core-group.me/ommhandover-documentationproduction/</a></p>
<p id="ref38" class="ref_item">[38] sites.google.com <a target="_blank" rel="noreferrer" href="https://sites.google.com/view/trenttechnicalservices/services/hvac-testing-balancing">https://sites.google.com/view/trenttechnicalservices/services/hvac-testing-balancing</a></p>
