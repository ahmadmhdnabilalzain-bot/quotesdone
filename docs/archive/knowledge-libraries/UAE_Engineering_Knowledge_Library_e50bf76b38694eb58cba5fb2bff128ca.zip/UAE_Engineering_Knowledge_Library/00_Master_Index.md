# UAE Engineering Knowledge Library — Master Index

This library is a UAE-focused professional engineering reference covering civil, structural, geotechnical, MEP, fire and life safety, roads, infrastructure, environmental, sustainability, HSE, materials, facade, marine, oil and gas, industrial process, specialist building services, project management, contracts, and professional practice. Source material was collected from UAE authority portals, building codes, and authoritative international standards in July 2026.

## Library Files

- **[Civil, Structural, and Geotechnical Engineering in the UAE](./01_Civil_Structural_and_Geotechnical_Engineering.md)** — `01_Civil_Structural_and_Geotechnical_Engineering.md` — 50,157 characters.
- **[MEP Engineering: HVAC, Electrical, Plumbing, Fire and Life Safety, and BIM in the UAE](./02_MEP_HVAC_Electrical_Plumbing_Fire_and_BIM.md)** — `02_MEP_HVAC_Electrical_Plumbing_Fire_and_BIM.md` — 64,870 characters.
- **[Roads, Transportation, Water, Wastewater, and Urban Infrastructure Engineering in the UAE](./03_Roads_Transport_and_Infrastructure_Engineering.md)** — `03_Roads_Transport_and_Infrastructure_Engineering.md` — 38,955 characters.
- **[Environmental, Sustainability, HSE, and Materials Engineering in the UAE](./04_Environmental_Sustainability_HSE_and_Materials.md)** — `04_Environmental_Sustainability_HSE_and_Materials.md` — 48,158 characters.
- **[Facade Engineering, Marine and Coastal Engineering, and Oil, Gas and Industrial Process Engineering in the UAE](./05_Facade_Marine_and_Oil_Gas_Industrial_Engineering.md)** — `05_Facade_Marine_and_Oil_Gas_Industrial_Engineering.md` — 48,129 characters.
- **[Specialist Building Services, Project Management, Contracts, and Professional Practice in the UAE](./06_Specialist_Services_Project_Management_and_Contracts.md)** — `06_Specialist_Services_Project_Management_and_Contracts.md` — 45,746 characters.

## How to Use This Library

1. Start with the file matching your engineering discipline or the project phase you are working on.
2. Use the checklists and design-parameter tables as working-paper prompts and review aids — not as a substitute for the applicable code, standard, or authority requirement.
3. Every numerical threshold, regulatory rule, and approval requirement listed here should be verified against the current published source before design sign-off, permit submission, or site instruction.
4. UAE authority requirements change frequently. DM circulars, DEWA/ADDC amendments, and Civil Defense code updates should be checked at the project start and confirmed at key design milestones.
5. Structural, fire, and geotechnical items require sign-off by a registered engineer holding the applicable practicing card for the project emirate.

## Regulator and Authority Quick Reference

| Authority | Jurisdiction | Primary Role |
| --- | --- | --- |
| Dubai Municipality (DM) | Dubai mainland | Building permits, sustainability, site safety, materials |
| Trakhees (PCFC) | Dubai free zones (JAFZA, Palm, etc.) | Building permits, EHS, industrial |
| Dubai Development Authority (DDA) | Dubai special zones | Building permits |
| Dubai Civil Defense (DCD) | All Dubai | Fire and life safety approvals |
| DEWA | Dubai | Electricity and water connection, inspections |
| RTA | Dubai | Roads, traffic, transport |
| Abu Dhabi DMT | Abu Dhabi, Al Ain, Al Dhafra | Building permits, infrastructure, BIM mandate |
| Abu Dhabi Civil Defense (ADCDA) | Abu Dhabi | Fire and life safety approvals |
| ADDC / AADC | Abu Dhabi | Electricity and water connection |
| Abu Dhabi SWS (formerly ADSSC) | Abu Dhabi | Sewerage and recycled water |
| EAD | Abu Dhabi | Environmental Impact Assessment |
| Ministry of Human Resources (MOHRE) | Federal | Labour, OHS, midday break |
| UAE Civil Defense | Federal (all emirates) | Fire and life safety code |
| ADNOC | Abu Dhabi oil and gas sector | Process, offshore, industrial engineering |

**Total library depth: 263,392 characters across 6 category files.**