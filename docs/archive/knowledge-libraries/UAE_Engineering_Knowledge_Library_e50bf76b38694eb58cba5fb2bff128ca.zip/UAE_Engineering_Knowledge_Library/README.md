# UAE Engineering Knowledge Library

UAE-focused professional engineering reference library.

## Files

- `00_Master_Index.md` — 4,018 characters
- `01_Civil_Structural_and_Geotechnical_Engineering.md` — 50,157 characters
- `02_MEP_HVAC_Electrical_Plumbing_Fire_and_BIM.md` — 64,870 characters
- `03_Roads_Transport_and_Infrastructure_Engineering.md` — 38,955 characters
- `04_Environmental_Sustainability_HSE_and_Materials.md` — 48,158 characters
- `05_Facade_Marine_and_Oil_Gas_Industrial_Engineering.md` — 48,129 characters
- `06_Specialist_Services_Project_Management_and_Contracts.md` — 45,746 characters

Total characters: 300,033
