# Civil, Structural, and Geotechnical Engineering in the UAE

This chapter covers the regulatory foundations, structural design principles, geotechnical requirements, and construction quality standards for civil and structural engineering in the UAE. It serves as a professional reference for designers, structural engineers, geotechnical consultants, and site engineers working under UAE municipal codes. [[1]](#ref1)[[2]](#ref2)

## 1. UAE Regulatory Architecture

The UAE building-permit system is decentralised by emirate. Two primary codes govern the majority of UAE construction: the **Dubai Building Code (DBC) 2021** for Dubai and the **Abu Dhabi International Building Code (ADIBC)** for Abu Dhabi, Al Ain, and Al Dhafra. Free zones operate under their own authorities (Trakhees, Dubai Development Authority, ADGM) that apply the DBC or equivalent standards. [[1]](#ref1)[[3]](#ref3)

| Emirate | Primary Authority | Core Building Code | Digital Portal / BIM Mandate |
| --- | --- | --- | --- |
| Dubai | Dubai Municipality (DM) / Trakhees / DDA | DBC 2021; ASCE 7-16; ACI 318; AISC 360 | Building Permit via DM portal; BIM mandatory for G+12 or ≥15,000 m² BUA from April 2026 [[4]](#ref4) |
| Abu Dhabi | Department of Municipalities and Transport (DMT) | ADIBC (IBC-based); ASCE 7-05 amendments; ACI 318M-08 | MePS/TAMM portal; Binaa AI model check from late 2025 [[5]](#ref5) |
| Northern Emirates | Relevant emirate municipality | DBC or ADIBC as adopted locally | Emirate-specific portals |

## 2. Source Research: Civil Engineering and Building Regulation Foundations

# Source Packet 11: Civil engineering and UAE building regulation foundations: Dubai Building Code, Abu Dhabi codes, municipality approvals, general design process

**Research topic:** Civil engineering and UAE building regulation foundations: Dubai Building Code, Abu Dhabi codes, municipality approvals, general design process

**Report title:** Civil Engineering and UAE Building Regulation Foundations

# Civil Engineering and UAE Building Regulation Foundations

This document provides a comprehensive overview of the civil engineering foundations and building regulations in the United Arab Emirates (UAE), focusing on Dubai and Abu Dhabi. It covers the regulatory landscape, approval workflows, core codes, technical design principles, and construction supervision requirements as of July 2026.

## Domain Scope and UAE Relevance

Civil engineering in the UAE is a cornerstone of the nation's rapid urban development and economic diversification. The domain encompasses the design, construction, and maintenance of the physical and naturally built environment, including buildings, roads, bridges, and water systems.

- **Typical Projects**: High-rise residential and commercial towers, luxury villas, industrial warehouses, infrastructure (RTA/ITC projects), and large-scale master developments (e.g., Dubai South, Yas Island).
- **Boundaries**: The scope is defined by emirate-specific jurisdictions (Dubai Municipality, Abu Dhabi DMT) and federal oversight (Ministry of Energy and Infrastructure). It integrates international standards (ACI, AISC, IBC) with local amendments to suit the UAE's unique environmental and regulatory context.

## UAE Authorities and Approval Workflow

The approval process in the UAE is highly digitized and follows a sequential path from concept to completion.

### Dubai Authorities and Workflow
- **Dubai Municipality (DM)**: The primary authority for Dubai mainland.
- **Trakhees (PCFC)**: Authority for special development zones and free zones (e.g., JAFZA, DP World).
- **Dubai Development Authority (DDA)**: Oversees developments in specific zones like Dubai Internet City and Media City.
- **Dubai Civil Defense (DCD)**: Responsible for fire and life safety approvals.

**Standard Workflow (Dubai)**:
1.  **NOCs (No Objection Certificates)**: Obtaining clearances from utility providers (DEWA, Etisalat/du) and master developers.
2.  **Concept/Schematic Design Approval**: Preliminary review of the building's massing and use.
3.  **Detailed Design/Building Permit**: Full technical review of architectural, structural, and MEP drawings.
    - *BIM Mandate*: As per **Circular 9-1-3/2026**, BIM submission is mandatory for buildings with 12+ floors or 15,000+ sqm BUA, effective April 1, 2026. — *Dubai Municipality [[6]](#ref6)
4.  **Construction Phase**: Periodic inspections by DM/Trakhees engineers.
5.  **Completion Certificate (BCC)**: Final inspection to ensure the building matches approved plans before occupancy.

### Abu Dhabi Authorities and Workflow
- **Department of Municipalities and Transport (DMT)**: Oversees Abu Dhabi, Al Ain, and Al Dhafra.
- **TAMM Portal**: The unified digital platform for all government services, including building permits.
- **MePS (Municipal Electronic Permitting System)**: The technical portal for permit submissions.

**Standard Workflow (Abu Dhabi)**:
1.  **Site Plan & NOCs**: Obtaining the site plan from DMT and NOCs from ADDC (water/electricity) and ITC (transport).
2.  **Architectural & Structural Approval**: Review against ADIBC standards.
3.  **Building Permit Issuance**: Granted after all technical reviews and fee payments.
4.  **Occupancy Certificate**: Issued after final inspections and Civil Defense clearance. — *TAMM [[7]](#ref7)

## Core Codes and Standards

The UAE utilizes a mix of local codes and international standards.

- **Dubai Building Code (DBC) 2021**: A unified code that replaces previous municipality regulations. It is organized into Parts A-K, covering General, Structure, Architecture, Utilities, etc. — *Dubai Building Code 2021 [[8]](#ref8)
- **Abu Dhabi International Building Code (ADIBC)**: Based on the 2009 International Building Code (IBC) with local amendments. — *DMT [[9]](#ref9)
- **UAE Fire and Life Safety Code of Practice (2018)**: The definitive guide for fire safety across all emirates. — *Dubai Civil Defense [[10]](#ref10)
- **International Standards**:
    - **ACI 318**: For reinforced concrete design.
    - **AISC 360**: For structural steel design.
    - **ASCE 7**: For minimum design loads (wind and seismic).

## Technical Design Content

### Structural Design Principles
- **Wind Loads**: Critical for high-rises. Design wind speed is typically based on a 50-year return period.
    - > "In any event, the design wind load for Buildings and steel structures must not be less than one kilonewton per square metre (1kN/m²)." — *Administrative Resolution No. (37) of 2021, )%20of%202021%20Amending%20the%20Bylaw%20Concerning.html [[2]](#ref2)
    - Wind tunnel testing is mandatory for buildings > 120m or irregular shapes.
- **Seismic Loads**: The UAE is generally classified as Zone 2A (moderate seismicity) under the Uniform Building Code (UBC) or equivalent IBC categories.
- **Concrete Strength**: Minimum characteristic strength for structural elements is typically 25-35 MPa, with higher grades (60-80 MPa) used in high-rise columns.

### Architectural Standards
- **Accessibility**: Must comply with the **Dubai Universal Design Code**.
- **Egress**: Minimum corridor widths and travel distances are strictly governed by the UAE Fire and Life Safety Code.

## Construction Supervision, Testing, and Commissioning

Supervision is a legal requirement for the Consultant of Record.

- **QA/QC Framework**: Projects must have a Project Quality Plan (PQP) and Inspection & Test Plans (ITP).
- **Key Inspections**:
    - **Excavation & Shoring**: Verification of soil stability and tie-back tension.
    - **Foundation/Raft**: Rebar check and concrete pour witnessing.
    - **Structural Frame**: Verticality checks and cube testing (7-day and 28-day results).
- **Testing**:
    - **Non-Destructive Testing (NDT)**: Ultrasonic pulse velocity or Schmidt hammer for hardened concrete.
    - **Soil Testing**: Mandatory before design (typically 3-5 boreholes for standard plots).
- **Commissioning**: MEP systems (HVAC, Fire Fighting, Alarms) must undergo rigorous testing before the BCC is issued.

## UAE Climate, Durability, and Sustainability

### Climate and Durability
- **Corrosion**: The high saline environment and humidity lead to rapid chloride-induced reinforcement corrosion.
    - *Requirement*: Increased concrete cover (typically 50-75mm for foundations) and the use of Fusion Bonded Epoxy (FBE) coated rebar or GRP liners.
- **Heat**: Ambient temperatures can reach 50°C. Concrete pouring often requires ice-cooled water to keep the mix temperature below 32°C.
- **Dust/Sand**: Affects mechanical systems and requires specific filtration and maintenance protocols.

### Sustainability
- **Dubai (Al Sa'fat 2.0)**: Mandatory green building rating system. All new buildings must achieve at least "Silver" Sa'fa. — *Dubai Municipality [[11]](#ref11)
- **Abu Dhabi (Estidama)**: Uses the Pearl Rating System (PRS). Government buildings require 2 Pearls; private buildings require 1 Pearl. — *DMT [[12]](#ref12)

## Professional Practice and Checklists

### Senior Engineer Design Review Checklist
- [ ] Verify wind tunnel report integration into structural model.
- [ ] Check compliance with Al Sa'fat/Estidama mandatory credits.
- [ ] Ensure all utility NOCs are valid and conditions are met in drawings.
- [ ] Confirm fire-rated partitions match the DCD-approved fire strategy.
- [ ] Review concrete mix design for durability (w/c ratio, cement type).

### Common Mistakes
- **Inconsistent Drawings**: Discrepancies between architectural and structural sets leading to site delays.
- **NOC Expiry**: Failing to renew utility NOCs before permit submission.
- **Cover Depth**: Insufficient concrete cover in coastal areas leading to early-stage spalling.

## Sources

### Primary Sources
- **Dubai Municipality (DM)**: [Dubai Building Code 2021]() [[13]](#ref13)
- **Abu Dhabi Department of Municipalities and Transport (DMT)**: [ADIBC 2013]() [[14]](#ref14)
- **Dubai Civil Defense (DCD)**: [UAE Fire and Life Safety Code 2018]() [[15]](#ref15)
- **Dubai Legal Portal**: [Administrative Resolution No. (37) of 2021]()%20of%202021%20Amending%20the%20Bylaw%20Concerning.html) [[2]](#ref2)
- **TAMM Abu Dhabi**: [Construction Process Guidelines]() [[16]](#ref16)

### Secondary Sources
- **LinkedIn/Industry Updates**: [Dubai BIM Mandate 2026]() [[17]](#ref17)
- **Scribd/Slideshare**: [Dubai Municipality Approval Flowchart]() [[18]](#ref18)

## Gaps and Verification Notes
- **2026 Code Updates**: While the DBC 2021 is the current foundation, specific circulars (like the 2026 BIM mandate) modify its application. Engineers must check the DM/DMT portals for the latest circulars weekly.
- **Paywalled Standards**: International codes like ACI 318 and AISC 360 are referenced but require separate purchase for full technical details.
- **Authority Differences**: Free zone authorities (Trakhees, DDA) have slight variations in submission formats and fee structures compared to DM.

---


## 3. Source Research: Structural Engineering

# Source Packet 17: Structural engineering: loads, concrete, steel, masonry, foundations, seismic/wind, UAE and international standards

**Research topic:** Structural engineering: loads, concrete, steel, masonry, foundations, seismic/wind, UAE and international standards

**Report title:** Structural engineering: loads, concrete, steel, masonry, foundations, seismic/wind, UAE and international standards

### Structural Engineering: UAE Knowledge Library Shard (a3589229)

#### 1. Domain Scope
Structural engineering in the United Arab Emirates (UAE) is a critical discipline focused on ensuring the safety, stability, and durability of the built environment in a region characterized by extreme heat, high humidity, and aggressive soil conditions. The scope ranges from low-rise residential villas to super-tall skyscrapers (e.g., Burj Khalifa) and massive infrastructure projects like the Dubai Metro and Abu Dhabi's Etihad Rail. Structural engineers must navigate a complex landscape of local regulations (Dubai Building Code, ADIBC) and international standards (ASCE, ACI, Eurocodes) to deliver resilient designs.

#### 2. UAE Authorities and Approval Workflow
The structural approval process is governed by local municipalities and development authorities.

*   **Dubai Municipality (DM):** The primary authority for the Emirate of Dubai.
    *   **NOC for Soil Investigation:** Before any design, a No Objection Certificate (NOC) must be obtained to conduct soil testing.
    *   **Structural Design Review:** Engineers submit structural drawings, calculations, and geotechnical reports via the Building Permit System (BPS).
    *   **Building Permit:** Issued after the technical review confirms compliance with the Dubai Building Code (DBC).
    *   **Inspections:** Mandatory site inspections are required at key stages: Foundation (excavation/blinding), Steel Reinforcement (slabs/columns), and Final Completion — *Dubai Municipality, . [[19]](#ref19)
*   **Trakhees (PCFC):** Authority for free zones and special development zones (e.g., JAFZA, Dubai World). They follow a similar workflow but use their own online portal and technical guidelines.
*   **Abu Dhabi Department of Municipalities and Transport (DMT):** Oversees approvals in Abu Dhabi through the Meqta portal, enforcing the Abu Dhabi International Building Code (ADIBC).
*   **UAE Civil Defense:** Reviews structural fire protection, ensuring that structural elements meet the required fire-resistance ratings (FRR) per the UAE Fire and Life Safety Code.

#### 3. Core Codes and Standards
*   **Dubai Building Code (DBC) 2021:** The unified code for Dubai. Part F (Structure) is the primary reference for structural design — *Dubai Municipality, . [[20]](#ref20)
*   **Abu Dhabi International Building Code (ADIBC):** Based on the 2009 International Building Code (IBC) with local amendments for the Abu Dhabi context — *SK Ghosh Associates, . [[3]](#ref3)
*   **International Standards:**
    *   **ASCE 7-16/7-22:** Minimum Design Loads for Buildings and Other Structures (Wind and Seismic).
    *   **ACI 318M:** Building Code Requirements for Structural Concrete (Metric).
    *   **AISC 360:** Specification for Structural Steel Buildings.
    *   **BS EN 1992 (Eurocode 2):** Widely used for concrete durability and crack control design.

#### 4. Technical Design Content
##### 4.1 Wind Loads
*   **Design Wind Speed:** Dubai Municipality defines the design wind speed as a **3-second gust speed of 38 m/s** at a reference height of 10m above ground (50-year return period) — *Aqua Energy Expo, . [[21]](#ref21)
*   **Wind Tunnel Testing:** Mandatory for buildings exceeding **120 meters** in height or those with irregular/non-traditional shapes to accurately determine dynamic wind effects — *Dubai Administrative Resolution No. 37 of 2021*.
*   **Minimum Pressure:** The design wind load for buildings and steel structures must not be less than **1.0 kN/m²** — *Dubai Administrative Resolution No. 37 of 2021*.

##### 4.2 Seismic Loads
*   **Seismic Parameters:** Dubai is typically classified under Seismic Design Category C or D. Mapped spectral response acceleration parameters used in research for tall buildings in Dubai are approximately **Ss = 0.935g** and **S1 = 0.365g** — *American University of Sharjah, . [[22]](#ref22)
*   **Damping:** The damping coefficient for concrete structures is typically taken as **5%**, while for steel structures, it may be lower (e.g., 2-3%) depending on the connection type.

##### 4.3 Concrete and Steel Materials
*   **Concrete Grades:** Common structural grades include **C40/50** (40 MPa cylinder / 50 MPa cube strength) for foundations and vertical elements, and **C30/37** for slabs.
*   **Green Cement:** **DM Circular 225** mandates the use of supplementary cementitious materials (SCMs) like Ground Granulated Blast-furnace Slag (GGBS) or Fly Ash to improve durability and reduce the carbon footprint — *Dubai Municipality Circular 225*.
*   **Reinforcement Steel:** The standard reinforcement is **BS 4449 Grade 500B** (Yield strength 500 MPa) or **ASTM A615 Grade 60** (420 MPa). Grade 500B is preferred for its higher strength and ductility — *Dana Steel, . [[23]](#ref23)

##### 4.4 Foundations and Geotechnical
*   **Boreholes:** For villas, at least one borehole is required. For larger areas, boreholes should be on a **60m grid**. The depth must extend below the zone of influence, typically at least **8 meters** — *Dubai Administrative Resolution No. 37 of 2021*.
*   **Piling:** High-rise structures utilize deep foundations (piles). Testing requirements include:
    *   **Preliminary Test Pile (PTP):** To verify design assumptions.
    *   **Working Pile Tests:** Static and dynamic load tests on a percentage of production piles.
    *   **Pile Integrity Test (PIT):** To detect structural defects in the pile shaft — *Facebook Structural Engineers Group, . [[24]](#ref24)

#### 5. Construction Supervision, Testing, and Commissioning
*   **Quality Control:** Continuous monitoring of concrete pouring, including slump tests and temperature monitoring (maximum core temperature typically limited to **70°C**).
*   **Cube Testing:** Samples are taken for every 50-100 m³ of concrete to verify compressive strength at 7 and 28 days.
*   **NDT Testing:** If cube results are low, Non-Destructive Testing (NDT) such as Schmidt Hammer or Core Cutting is performed to verify the in-situ strength.
*   **Steel Inspection:** Verification of bar diameters, spacing, and lap lengths against approved structural drawings before casting.

#### 6. UAE Climate, Durability, and Sustainability
*   **Corrosion Mitigation:** The UAE's coastal environment is highly corrosive.
    *   **Concrete Cover:** Foundations require a minimum cover of **50-75mm** to protect against chloride and sulphate attack.
    *   **Sulphate Resisting Cement (SRC):** Mandatory for all concrete in contact with soil.
    *   **Epoxy Coating:** Often specified for reinforcement in aggressive zones.
*   **Sustainability Rating Systems:**
    *   **Al Sa'fat (Dubai):** A mandatory green building rating system. All new buildings must achieve at least the **Bronze** level — *Dubai Municipality, . [[11]](#ref11)
    *   **Estidama (Abu Dhabi):** Uses the Pearl Rating System (PRS). Government buildings must achieve a minimum of **2 Pearls**, while private buildings require **1 Pearl** — *OnGreening, . [[25]](#ref25)

#### 7. Professional Practice and Checklists
*   **Design Review Checklist:**
    *   [ ] Confirm wind tunnel report integration for tall buildings.
    *   [ ] Verify seismic design category and importance factor.
    *   [ ] Check deflection and drift limits (e.g., H/500 for wind drift).
    *   [ ] Ensure thermal loads are accounted for in long-span structures.
*   **Common Mistakes:**
    *   Failure to account for the "P-Delta" effect in slender high-rise columns.
    *   Inadequate consideration of dewatering effects on neighboring structures.
    *   Incorrect application of live load reductions for multi-story buildings.

#### 8. Sources
*   **Primary Sources:**
    *   Dubai Building Code 2021 [[26]](#ref26)
    *   Dubai Administrative Resolution No. 37 of 2021, )%20of%202021%20Amending%20the%20Bylaw%20Concerning.html [[2]](#ref2)
    *   Abu Dhabi International Building Code (ADIBC) [[5]](#ref5)
    *   Dubai Municipality Circular 225 (Green Cement) [[27]](#ref27)
*   **Secondary Sources:**
    *   Structural Design Guidelines (Aqua Energy) [[28]](#ref28)
    *   Dana Steel Rebar Standards [[29]](#ref29)
    *   Estidama Pearl Rating System Guide [[30]](#ref30)

#### 9. Gaps and Verification Notes
*   **Gaps:** Detailed seismic hazard maps for the Northern Emirates (Sharjah, Ajman, etc.) are less publicly accessible than those for Dubai and Abu Dhabi.
*   **Verification:** Structural engineers must always verify the latest circulars on the **Dubai Municipality (DM)** and **Abu Dhabi DMT** websites, as local amendments to international codes are frequent.

***

**Checklist Status Summary:**
Checklist file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/a3589229/RESEARCH_CHECKLIST.md`
All items marked `[Y]`.

---


## 4. Source Research: Geotechnical Engineering

# Source Packet 4: Geotechnical engineering: site investigation, soil reports, shoring, piles, dewatering, excavation and UAE approval practice

**Research topic:** Geotechnical engineering: site investigation, soil reports, shoring, piles, dewatering, excavation and UAE approval practice

**Report title:** Geotechnical Engineering: UAE Practice and Standards

# Geotechnical Engineering: UAE Practice and Standards

Geotechnical engineering in the United Arab Emirates (UAE) is a critical discipline driven by the region's unique geological conditions—characterized by coastal carbonate sands, weak sedimentary rocks (calcarenite and siltstone), and highly saline groundwater—and the prevalence of high-rise structures with deep basements.

### 1. Domain Scope and UAE Relevance
Geotechnical engineering in the UAE encompasses site investigation, foundation design (shallow and deep), earth-retaining structures (shoring), dewatering, and ground improvement. Its relevance is paramount due to:
*   **High-Rise Foundations:** Dubai and Abu Dhabi host some of the world's tallest buildings, requiring sophisticated piling systems anchored into weak rock strata.
*   **Deep Excavations:** Urban density necessitates multi-level basements (often 3–6 levels), requiring robust shoring and dewatering systems to manage high water tables.
*   **Coastal Geology:** Much of the development occurs on reclaimed land or near the shoreline, where "Sabkha" (saline evaporite) soils and liquefaction risks are prevalent.
*   **Infrastructure:** Extensive tunneling (e.g., Dubai Metro) and maritime structures (e.g., Jebel Ali Port) rely on specialized geotechnical assessments.

### 2. UAE Authorities and Approval Workflow
Geotechnical works are strictly regulated by municipal and free-zone authorities. The approval process is typically a prerequisite for structural and building permits.

#### Key Authorities
*   **Dubai Municipality (DM):** The primary regulator for Dubai.
*   **Abu Dhabi Department of Municipalities and Transport (DMT) / Abu Dhabi City Municipality (ADM):** Regulates the capital.
*   **Trakhees (PCFC):** Authority for special development zones (e.g., Palm Jumeirah, JAFZA).
*   **Dubai Development Authority (DDA):** Regulates zones like Dubai Internet City and Media City.

#### Approval Workflow (Dubai Example)
1.  **Soil Investigation Permit:** Before drilling, a consultant must obtain a permit from the municipality.
2.  **Geotechnical Investigation:** Conducted by a DM-accredited laboratory.
3.  **Soil Report Approval:** The final report must be uploaded to the authority portal (e.g., Dubai's "Build in Dubai" or Abu Dhabi's "SmarHub").
    *   > "For building less than G+12 one borehole per 750 m2 - minimum 3 boreholes." — DM Circular 350 [[31]](#ref31)
4.  **Shoring and Piling Permit:** Separate from the main building permit. Requires submission of design calculations, drawings, and a dewatering plan.
5.  **NOCs (No Objection Certificates):** Required from utility providers (DEWA, Etisalat, RTA) if the excavation or shoring anchors impact public right-of-way or existing services.

### 3. Core Codes and Standards
UAE practice blends local regulations with international standards, primarily Eurocodes and American standards.

*   **Dubai Building Code (DBC) 2021:** Part G (Geotechnical) provides the unified design requirements for Dubai.
*   **Abu Dhabi International Building Code (ADIBC):** Based on the International Building Code (IBC), adapted for Abu Dhabi.
*   **TR-509 (Abu Dhabi):** "Manual for Geotechnical Investigation and Geotechnical Design" (2021 Edition) is the definitive technical guide for the capital.
*   **UAE Fire and Life Safety Code of Practice:** Relevant for shoring materials and basement safety.
*   **International Standards:**
    *   **BS EN 1997 (Eurocode 7):** Widely used for geotechnical design.
    *   **ASTM D1586:** Standard for Standard Penetration Test (SPT).
    *   **ACI 318:** For the design of concrete piles and retaining walls.

### 4. Technical Design Content

#### Soil Investigation Requirements
The number and depth of boreholes are strictly mandated based on building height and plot area.
*   **Borehole Density:** For high-rise buildings (G+12 and above), at least one borehole per 750 m² is required, with a minimum of five boreholes per project.
*   **Borehole Depth:** Typically must extend 5–10 meters into competent rock or 1.5 to 3 times the foundation width.
    *   > "For high-rise Buildings (G+12), at least one borehole must be dug for each seven hundred and fifty square metres (750 m²), with a minimum of five (5) [boreholes]." — Administrative Resolution No. (37) of 2021, )%20of%202021%20Amending%20the%20Bylaw%20Concerning.html [[2]](#ref2)

#### Piling Design
Piles in the UAE are predominantly bored cast-in-situ piles.
*   **Factor of Safety (FoS):** A minimum FoS of 2.5 is required for pile design unless extensive testing is performed.
*   **Skin Friction and End Bearing:** In Dubai's weak rock (calcarenite/sandstone), skin friction is the primary load-carrying mechanism. Typical ultimate skin friction values range from 200 kPa to 800 kPa depending on the Unconfined Compressive Strength (UCS) of the rock.
*   **Concrete Cover:** A minimum clear cover of 75 mm is mandated for piles to protect against aggressive groundwater.
    *   > "Dubai Municipality requires a minimum pile concrete clear cover of 75 mm, ensuring durability and protection of reinforcement." — DM Regulations Practice [[32]](#ref32)

#### Shoring Systems
Common systems used for deep excavations:
*   **Secant Pile Walls:** Overlapping piles providing both structural support and a water-tight barrier. Preferred for deep basements with high water tables.
*   **Contiguous Pile Walls:** Piles placed close together but not overlapping. Requires separate dewatering or grouting to manage water ingress.
*   **Soldier Piles (H-Beams):** Used for shallower excavations or where groundwater is not a major concern.
*   **Diaphragm Walls:** Reinforced concrete walls cast in deep trenches; used for very deep or critical infrastructure projects.

#### Dewatering
*   **Permits:** A dewatering permit is required from the municipality.
*   **Discharge:** Water is typically discharged into the sea or the municipal storm-water network, subject to water quality testing (pH, TDS, TSS).
    *   > "Abu Dhabi (EAD) Discharge to marine waters: pH: 6.5 – 8.5; Temperature increase: Max +1°C above ambient." — Navigating Water Regulations in the UAE [[33]](#ref33)

### 5. Construction Supervision, Testing, and Commissioning
Geotechnical works require rigorous QA/QC and third-party testing.

*   **Pile Testing:**
    *   **Static Load Test (SLT):** The gold standard; usually performed on 1% of production piles or on sacrificial "test piles" before construction.
    *   **Dynamic Load Test (DLT):** A faster alternative to SLT, often used for a larger percentage of piles.
    *   **Pile Integrity Test (PIT):** Low-strain sonic echo test to check for cracks or necking in the pile shaft.
    *   **Cross-hole Sonic Logging (CSL):** Used for large-diameter piles to ensure concrete quality across the entire section.
*   **Shoring Monitoring:**
    *   **Inclinometers:** Installed in shoring walls to monitor lateral deflection.
    *   **Piezometers:** To monitor groundwater levels outside the excavation.
    *   **Ground Settlement Markers:** To monitor impact on neighboring structures and roads.

### 6. UAE Climate, Durability, and Sustainability
*   **Sabkha Soils:** High salt content (chlorides and sulfates) leads to rapid corrosion of steel and degradation of concrete. Sulfate-resisting cement (Type V) and epoxy-coated reinforcement are standard.
*   **Groundwater Rise:** A long-term phenomenon in cities like Dubai due to irrigation and sea-level rise, requiring basements to be designed for full hydrostatic uplift.
*   **Heat Impact:** High ambient temperatures (up to 50°C) require specialized concrete mixes with retarders and ice-cooling during casting to prevent thermal cracking.
*   **Sustainability:** Use of Ground Granulated Blast-furnace Slag (GGBS) or Fly Ash in concrete mixes is encouraged by "Al Sa'fat" (Dubai) and "Estidama" (Abu Dhabi) to reduce carbon footprint and improve durability.

### 7. Professional Practice and Checklists
Senior engineers focus on risk mitigation and authority coordination.

**Design Review Checklist:**
*   [ ] Does the soil report meet the minimum borehole count and depth per DM/ADM circulars?
*   [ ] Are the seismic parameters (PGA, Site Class) consistent with the latest UAE seismic maps?
*   [ ] Has the shoring design accounted for surcharge loads from neighboring buildings and heavy machinery?
*   [ ] Is the dewatering system capacity sufficient for the predicted seepage rates?
*   [ ] Are the pile settlement calculations within the allowable limits for the superstructure?

**Common Mistakes:**
*   Underestimating the impact of shoring anchors on neighboring plots (requires legal agreements).
*   Inadequate rock socketing in piles due to misinterpretation of weak rock layers.
*   Failure to account for the "group effect" in closely spaced pile foundations.

### 8. Sources

#### Primary Sources
*   **Dubai Municipality:** *Administrative Resolution No. (37) of 2021 Amending the Bylaw Concerning Building Requirements and Specifications*. [Link]()%20of%202021%20Amending%20the%20Bylaw%20Concerning.html) [[2]](#ref2)
*   **Dubai Development Authority (DDA):** *Circular 350: Amended Process - Soil Report Review*. [Link]() [[31]](#ref31)
*   **Abu Dhabi DMT:** *TR-509-2: Ground Investigation and Geotechnical Design*. (Referenced via Scribd/DMT portal).
*   **Dubai Municipality:** *Code of Construction Safety Practice*. [Link]() [[34]](#ref34)

#### Secondary Sources
*   **Terrasearch Gulf:** *Geotechnical Investigation UAE: Complete Guide (2025)*. [Link]() [[35]](#ref35)
*   **Shoring.ae:** *Types of Shoring in Construction for Dubai & UAE Projects*. [Link]() [[36]](#ref36)
*   **LinkedIn Engineering Insights:** *Navigating Water Regulations in the UAE*. [Link]() [[33]](#ref33)

### 9. Gaps and Verification Notes
*   **Specific Rock Parameters:** While general UCS-based correlations exist for Dubai rock, site-specific values vary significantly. Verification via pressuremeter tests or O-cell tests is recommended for major projects.
*   **Abu Dhabi TR-509 Full Access:** Detailed design charts in TR-509 are often restricted to registered consultants; verification of the latest 2021 amendments for specific infrastructure types is advised.
*   **Dewatering Discharge Fees:** Fees for discharging into the municipal network are subject to frequent updates by DM/ADSSC and should be verified at the time of permit application.

***

**Checklist Status Summary:**
*   Checklist file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/3fb04209/RESEARCH_CHECKLIST.md`
*   All items marked `[Y]`.

---


## 5. Structural Design Manual

### Structural design submission checklist

1. **Design basis memo** — State applicable code edition, risk category, load combinations, material specifications, exposure classes, and durability requirements.
2. **Geotechnical data** — Reference the approved soil investigation report; state assumed bearing capacity, pile type, pile depth and pile load test requirement.
3. **Load calculations** — Gravity loads (dead, superimposed dead, live), wind (ASCE 7 method with UAE wind maps), seismic (site class, spectral parameters), and any special loads (vibration, explosion, impact).
4. **Structural analysis** — Column/wall/slab/beam design with code check summaries, deflection and drift verification, and connection design for steel frames.
5. **Durability schedule** — Concrete cover, w/c ratio, cement type/GGBS/Fly Ash replacement, maximum chloride and sulfate content per exposure class.
6. **Foundation package** — Foundation type selection, bearing/pile capacity calculations, settlement analysis, factor of safety, and ITP for construction control.
7. **Drawing set review** — Check title block, revision cloud, dimensions, reinforcement bar marks, cover dimensions, splice details, connection details, embedded items, and coordination with MEP openings.


## 6. Geotechnical and Foundation Field Control

### Site investigation and foundation construction checklist

1. **Borehole permit** — Obtain drilling permit from DM/DMT before mobilisation; confirm number, layout, and depth comply with Administrative Resolution 37/2021 requirements.
2. **Shoring design approval** — Submit shoring calculations and drawings; confirm maximum lateral displacement limit (40 mm for Trakhees) and minimum surcharge loads.
3. **Piling records** — Record pile ID, diameter, toe level, concrete volume, integrity test result, and static or dynamic load test as required.
4. **Dewatering permit** — Obtain permit for groundwater discharge; confirm discharge quality, route, and monitoring frequency with authority.
5. **Foundation inspection** — Authority inspection before concrete pour; confirm dimensions, reinforcement, cover, cleanliness, and any blinding concrete as required.


## Expert Appendix: Field Control, Design Review, and Authority Coordination Templates

### Template A: Design Review Checklist Framework
A senior engineering design review should confirm: design basis and load assumptions are documented; code edition and amendment dates are stated; all UAE authority requirements have been addressed by reference; specialist sub-consultant inputs are incorporated and coordinated; sustainability compliance (Al Sa'fat or Estidama as applicable) is addressed; fire and life safety interfaces are resolved; and the drawing set matches calculations and specifications. Any deviation from code requires a written technical justification.

### Template B: Authority Submission Package
Before submitting to any UAE authority, confirm: the submitting consultant firm holds a valid practising card/approval for the project emirate; drawings are in the required format and coordinate system; all NOCs from upstream authorities are attached; calculations are signed by a registered engineer; the BIM model (if mandated under DM Circular 9-1-3/2026 or Abu Dhabi DMT requirements) is attached in the required format; and fees or bonds have been paid. Incomplete packages are returned without review in most Dubai and Abu Dhabi portals.

### Template C: Site Supervision and Inspection Record
For each Witness or Hold point on the ITP, the site supervisor should confirm: the work activity matches the approved shop drawing; material has a valid test certificate or Material Approval Request (MAR); pre-activity conditions (compaction, formwork, earthing, cleanliness) are met; work execution matches approved method statement; post-activity tests are conducted and recorded; Non-Conformance Reports are raised immediately for failures; and the record is signed, dated, and uploaded to the document management system.

### Template D: Commissioning and Handover Record
The commissioning package should include: signed Commissioning Manager appointment; pre-commissioning mechanical completion certificates; equipment startup records with measured versus specified values; functional test sheets for all systems; cause-and-effect matrix testing records for life-safety interfaces; Training records for the building operator; Operating and Maintenance manuals with as-built BIM model; and a Defect Tracking Register. In Dubai, DEWA/DCD and DM will conduct their own independent inspections before issuing the Completion Certificate.

### Template E: Professional Risk Register for UAE Engineering Projects
Key project risks to track: BIM submission readiness; NOC expiry dates and renewal sequences; Specialist material lead times (high-performance concrete, specialist glazing, medical gas equipment); Third-party inspection availability; Civil Defense comments on fire systems; Authority variations discovered late in design; Structural peer review findings; Geotechnical report limitations; Weather restrictions on concrete pours; Power supply sequencing for DEWA connection; District Cooling provider connection timing; and Snagging management strategy for Completion Certificate.


## Extended Technical Reference: Structural Engineering in the UAE

### Reinforced Concrete Design Parameters
Structural engineers in the UAE work primarily to ACI 318 (referenced by DBC 2021) or Eurocode 2 (EN 1992) depending on client preference and project type. Key practical parameters:

- **Characteristic concrete strength (f'c):** Typically C32/40 (fck=32 MPa) for suspended slabs and columns; C40/50 for transfer plates; C50/60 for high-rise cores and mat foundations.
- **Reinforcement yield strength (fy):** Grade 500 MPa (high ductility class B or C per BS 4449:2005) is the UAE industry standard. Grade 460 is still encountered in older projects.
- **Minimum slab thickness for deflection (ACI 318 Table 9.3.1.1):** Flat plate one-way: L/20; Two-way flat plate: L/30 (deflection-controlled spans).
- **Column axial load ratio:** Typically limited to 0.40–0.55 of Ag × f'c to maintain ductility in seismic design categories.
- **Coupling beam aspect ratio:** Diagonally reinforced coupling beams (preferred per ACI 318-19 Section 18.10.7) where ln/h < 2.0 in coupled shear wall systems.

### Seismic Design in UAE Practice
The UAE is a low-to-moderate seismic region. Design parameters per DBC 2021 / ASCE 7-16 for Dubai:
- Risk Category II buildings: Ss ≈ 0.25g (0.2-second spectral acceleration), S1 ≈ 0.10g (1-second).
- Site Class D (stiff soil, Vs30 180–360 m/s) is common for coastal fill areas, requiring amplification factors.
- Seismic Design Category B or C is typical; Category D is triggered for specific occupancies or higher ground motions.
- Special Moment Frames (SMF) and Special Shear Walls are required for taller structures in SDC D.
- Site-specific probabilistic seismic hazard analysis (PSHA) is required for critical facilities, dams, and buildings over 73 m in Abu Dhabi.

### Foundation Design Decision Matrix
| Site condition | Preferred foundation | Key design check |
|---|---|---|
| Dense sand/gravel, SPT N>30 | Raft or spread footings | Bearing capacity, differential settlement |
| Loose sand, SPT N<15 | Driven piles or ground improvement | Liquefaction potential, pile negative skin friction |
| Sabkha/salt flat | Replacement or deep piles bypassing sabkha | Expansion on wetting, sulfate-resistant cement |
| Rock (mudstone, limestone) | Bored piles or rock anchors | Rock socket bond, core recovery (RQD) |
| High water table, deep basement | Secant pile wall + slab, dewatering | Heave, flotation check, dewatering discharge permit |

### Pile Design and Testing Requirements
For bored cast-in-place piles in Dubai:
- **Preliminary pile test:** 1.5× working load, bi-directional (Osterberg cell) or top-down static test; minimum 1 per pile type per project.
- **Working pile test:** 1.0× working load; minimum 2% of total piles or 5 piles, whichever is greater.
- **Integrity testing:** Sonic integrity test (SIT) or cross-hole sonic logging (CSL) on 100% of piles >600 mm diameter.
- **Concrete cube test:** 3 cubes per 50 m³ poured; design strength typically C40–C50.
- **Shaft resistance:** Alpha-method for cohesive soils; beta-method or SPT-based correlations for sandy soils and rock sockets.

### Structural Steel Design
AISC 360 (LRFD method) is the primary reference for structural steel in DBC 2021. Eurocodes are accepted for specialty bridges and infrastructure.
- **Connection design:** All connections must be designed and detailed; AISC Prequalified Connections (AISC 358) are accepted for Special Moment Frames.
- **Corrosion protection:** ISO 12944 C5-M or C5-I system for coastal and marine exposure; minimum DFT (dry film thickness) per manufacturer's coating system specification.
- **Fire protection:** Passive fire protection (intumescent paint, boarding, spray) sized for required fire resistance rating; steelwork in car parks with natural ventilation may qualify for unprotected in certain codes.
- **Welding:** All structural welds require Weld Procedure Specifications (WPS) and Procedure Qualification Records (PQR) per AWS D1.1; Trakhees specifically requires this by name.


## References

<p id="ref1" class="ref_item">[1] dda.gov.ae <a target="_blank" rel="noreferrer" href="https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf">https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf</a></p>
<p id="ref2" class="ref_item">[2] dlp.dubai.gov.ae <a target="_blank" rel="noreferrer" href="https://dlp.dubai.gov.ae/Legislation%20Reference/2021/Administrative%20Resolution%20No.%20(37">https://dlp.dubai.gov.ae/Legislation%20Reference/2021/Administrative%20Resolution%20No.%20(37</a></p>
<p id="ref3" class="ref_item">[3] skghoshassociates.com <a target="_blank" rel="noreferrer" href="https://www.skghoshassociates.com/blog/2013-abu-dhabi-international-building-code-becomes-mandatory-on-oct-1-2014/*">https://www.skghoshassociates.com/blog/2013-abu-dhabi-international-building-code-becomes-mandatory-on-oct-1-2014/*</a></p>
<p id="ref4" class="ref_item">[4] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/al-safat-dubai-green-building-system/">https://www.dm.gov.ae/municipality-business/al-safat-dubai-green-building-system/</a></p>
<p id="ref5" class="ref_item">[5] dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dmt.gov.ae/">https://www.dmt.gov.ae/</a></p>
<p id="ref6" class="ref_item">[6] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/building-planning-circulars-2/*">https://www.dm.gov.ae/building-planning-circulars-2/*</a></p>
<p id="ref7" class="ref_item">[7] tamm.abudhabi <a target="_blank" rel="noreferrer" href="https://www.tamm.abudhabi/en/articles/construction-process-guidelines*">https://www.tamm.abudhabi/en/articles/construction-process-guidelines*</a></p>
<p id="ref8" class="ref_item">[8] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://dm.gov.ae/wp-content/uploads/2021/12/Dubai%20Building%20Code_English_2021%20Edition_compressed.pdf*">https://dm.gov.ae/wp-content/uploads/2021/12/Dubai%20Building%20Code_English_2021%20Edition_compressed.pdf*</a></p>
<p id="ref9" class="ref_item">[9] dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dmt.gov.ae/-/media/Project/DMT/DMT/Codes/ADIBC_2013_bookmarked.pdf*">https://www.dmt.gov.ae/-/media/Project/DMT/DMT/Codes/ADIBC_2013_bookmarked.pdf*</a></p>
<p id="ref10" class="ref_item">[10] dcd.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dcd.gov.ae/portal/preventive-safety/uae-fire-and-life-safety-code-of-practice.jsp*">https://www.dcd.gov.ae/portal/preventive-safety/uae-fire-and-life-safety-code-of-practice.jsp*</a></p>
<p id="ref11" class="ref_item">[11] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/al-safat-dubai-green-building-system/*">https://www.dm.gov.ae/municipality-business/al-safat-dubai-green-building-system/*</a></p>
<p id="ref12" class="ref_item">[12] dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dmt.gov.ae/-/media/Project/DMT/DMT/E-Library/0001-Manuals/PRRS/PRRS-Version-10.pdf*">https://www.dmt.gov.ae/-/media/Project/DMT/DMT/E-Library/0001-Manuals/PRRS/PRRS-Version-10.pdf*</a></p>
<p id="ref13" class="ref_item">[13] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://dm.gov.ae/wp-content/uploads/2021/12/Dubai%20Building%20Code_English_2021%20Edition_compressed.pdf">https://dm.gov.ae/wp-content/uploads/2021/12/Dubai%20Building%20Code_English_2021%20Edition_compressed.pdf</a></p>
<p id="ref14" class="ref_item">[14] dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dmt.gov.ae/-/media/Project/DMT/DMT/Codes/ADIBC_2013_bookmarked.pdf">https://www.dmt.gov.ae/-/media/Project/DMT/DMT/Codes/ADIBC_2013_bookmarked.pdf</a></p>
<p id="ref15" class="ref_item">[15] dcd.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dcd.gov.ae/portal/preventive-safety/uae-fire-and-life-safety-code-of-practice.jsp">https://www.dcd.gov.ae/portal/preventive-safety/uae-fire-and-life-safety-code-of-practice.jsp</a></p>
<p id="ref16" class="ref_item">[16] tamm.abudhabi <a target="_blank" rel="noreferrer" href="https://www.tamm.abudhabi/en/articles/construction-process-guidelines">https://www.tamm.abudhabi/en/articles/construction-process-guidelines</a></p>
<p id="ref17" class="ref_item">[17] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/ar-saif_dubai-dm-bim-activity-7424676985165074432-xH4M">https://www.linkedin.com/posts/ar-saif_dubai-dm-bim-activity-7424676985165074432-xH4M</a></p>
<p id="ref18" class="ref_item">[18] es.scribd.com <a target="_blank" rel="noreferrer" href="https://es.scribd.com/document/72785636/20090810-ST-DM-Approval-Process-Flowchart">https://es.scribd.com/document/72785636/20090810-ST-DM-Approval-Process-Flowchart</a></p>
<p id="ref19" class="ref_item">[19] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/building-permit-steps/*">https://www.dm.gov.ae/municipality-business/building-permit-steps/*</a></p>
<p id="ref20" class="ref_item">[20] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/planning-and-construction/dubai-building-code-2/*">https://www.dm.gov.ae/municipality-business/planning-and-construction/dubai-building-code-2/*</a></p>
<p id="ref21" class="ref_item">[21] kh.aquaenergyexpo.com <a target="_blank" rel="noreferrer" href="https://kh.aquaenergyexpo.com/wp-content/uploads/2023/08/Structure.pdf*">https://kh.aquaenergyexpo.com/wp-content/uploads/2023/08/Structure.pdf*</a></p>
<p id="ref22" class="ref_item">[22] repository.aus.edu <a target="_blank" rel="noreferrer" href="https://repository.aus.edu/server/api/core/bitstreams/7b31b981-f6c4-4fdb-a864-10186b742a4f/content*">https://repository.aus.edu/server/api/core/bitstreams/7b31b981-f6c4-4fdb-a864-10186b742a4f/content*</a></p>
<p id="ref23" class="ref_item">[23] danasteeluae.com <a target="_blank" rel="noreferrer" href="https://danasteeluae.com/_rebar-bs-4449/*">https://danasteeluae.com/_rebar-bs-4449/*</a></p>
<p id="ref24" class="ref_item">[24] facebook.com <a target="_blank" rel="noreferrer" href="https://www.facebook.com/groups/414560619475304/posts/1867738904157461/*">https://www.facebook.com/groups/414560619475304/posts/1867738904157461/*</a></p>
<p id="ref25" class="ref_item">[25] ongreening.com <a target="_blank" rel="noreferrer" href="https://ongreening.com/estidama-rating-system-5-minute-guide/*">https://ongreening.com/estidama-rating-system-5-minute-guide/*</a></p>
<p id="ref26" class="ref_item">[26] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/planning-and-construction/dubai-building-code-2/">https://www.dm.gov.ae/municipality-business/planning-and-construction/dubai-building-code-2/</a></p>
<p id="ref27" class="ref_item">[27] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/wp-content/uploads/2020/11/Circular-225-Attachment.pdf">https://www.dm.gov.ae/wp-content/uploads/2020/11/Circular-225-Attachment.pdf</a></p>
<p id="ref28" class="ref_item">[28] kh.aquaenergyexpo.com <a target="_blank" rel="noreferrer" href="https://kh.aquaenergyexpo.com/wp-content/uploads/2023/08/Structure.pdf">https://kh.aquaenergyexpo.com/wp-content/uploads/2023/08/Structure.pdf</a></p>
<p id="ref29" class="ref_item">[29] danasteeluae.com <a target="_blank" rel="noreferrer" href="https://danasteeluae.com/_rebar-bs-4449/">https://danasteeluae.com/_rebar-bs-4449/</a></p>
<p id="ref30" class="ref_item">[30] ongreening.com <a target="_blank" rel="noreferrer" href="https://ongreening.com/estidama-rating-system-5-minute-guide/">https://ongreening.com/estidama-rating-system-5-minute-guide/</a></p>
<p id="ref31" class="ref_item">[31] dda.gov.ae <a target="_blank" rel="noreferrer" href="https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/General/DDA_PDF/PD_PDF/03-Construction/Others/C-02-SOIL-REPORT-REVIEW/Circular-350-Amended-Process-Soil-Report-Review.pdf">https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/General/DDA_PDF/PD_PDF/03-Construction/Others/C-02-SOIL-REPORT-REVIEW/Circular-350-Amended-Process-Soil-Report-Review.pdf</a></p>
<p id="ref32" class="ref_item">[32] studocu.com <a target="_blank" rel="noreferrer" href="https://www.studocu.com/row/quiz/dubai-municipality-piling-and-shoring-regulations-practice-quiz/12971541">https://www.studocu.com/row/quiz/dubai-municipality-piling-and-shoring-regulations-practice-quiz/12971541</a></p>
<p id="ref33" class="ref_item">[33] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/navigating-water-regulations-uae-key-standards-ahmed-khaled-cmrp--flbof">https://www.linkedin.com/pulse/navigating-water-regulations-uae-key-standards-ahmed-khaled-cmrp--flbof</a></p>
<p id="ref34" class="ref_item">[34] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/wp-content/uploads/2022/04/code_of_safety_EN.pdf">https://www.dm.gov.ae/wp-content/uploads/2022/04/code_of_safety_EN.pdf</a></p>
<p id="ref35" class="ref_item">[35] terrasearchgulf.com <a target="_blank" rel="noreferrer" href="https://terrasearchgulf.com/geotechnical-investigation-uae/">https://terrasearchgulf.com/geotechnical-investigation-uae/</a></p>
<p id="ref36" class="ref_item">[36] shoring.ae <a target="_blank" rel="noreferrer" href="https://shoring.ae/blog/types-of-shoring/">https://shoring.ae/blog/types-of-shoring/</a></p>
