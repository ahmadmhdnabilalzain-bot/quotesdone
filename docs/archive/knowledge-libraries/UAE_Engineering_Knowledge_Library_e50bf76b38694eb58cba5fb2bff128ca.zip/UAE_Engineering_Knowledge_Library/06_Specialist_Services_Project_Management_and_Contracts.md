# Specialist Building Services, Project Management, Contracts, and Professional Practice in the UAE

This chapter covers specialist building services engineering (medical gas, vertical transportation, public health), engineering project management, FIDIC contracts, authority coordination, and UAE professional licensing. [[1]](#ref1)[[2]](#ref2)

## 1. Public Health, Medical Gas, and Specialist Building Services

# Source Packet 3: Public health, medical gas and specialist building services engineering: healthcare, laboratories, kitchens, gas systems, lifts/escalators and vertical transportation

**Research topic:** Public health, medical gas and specialist building services engineering: healthcare, laboratories, kitchens, gas systems, lifts/escalators and vertical transportation

**Report title:** Public Health, Medical Gas, and Specialist Building Services Engineering (UAE)

# Public Health, Medical Gas, and Specialist Building Services Engineering (UAE)

This research report covers the specialist engineering domains of public health (medical gas, laboratories, kitchens), fuel gas systems (LPG/SNG), and vertical transportation (lifts/escalators) within the UAE context. It focuses on regulatory compliance, design principles, and authority-specific workflows for Dubai and Abu Dhabi.

## 1. Domain Scope and UAE Relevance

The specialist services domain in the UAE is characterized by high-density urban developments, world-class healthcare infrastructure, and stringent safety regulations.

*   **Medical Gas Systems (MGS):** Essential life-support infrastructure for hospitals and clinics. In the UAE, these systems are strictly regulated by health authorities (DHA/DOH) to ensure the continuous supply of medical-grade oxygen, nitrous oxide, medical air, and vacuum.
*   **Commercial Kitchens:** Found in the UAE's extensive hospitality and F&B sectors. Design focuses on food safety (HACCP), grease management, and high-capacity ventilation to handle heavy cooking loads.
*   **Fuel Gas Systems (LPG/SNG):** Centralized gas networks are standard in UAE high-rises and commercial malls. These systems are high-risk and fall under the direct jurisdiction of the UAE Civil Defense.
*   **Vertical Transportation (VT):** Given the UAE's verticality (e.g., Burj Khalifa), VT engineering is a core discipline. It encompasses traffic analysis for high-rise efficiency, fire-fighting lifts, and accessibility compliance.

## 2. UAE Authorities and Approval Workflow

Approvals for specialist services are multi-tiered, involving both technical MEP review and life-safety clearance.

### 2.1 Medical Gas Systems
*   **Authorities:** Dubai Health Authority (DHA), Abu Dhabi Department of Health (DOH).
*   **Workflow:**
    1.  **Preliminary Design:** Submission of MGS layouts and schematic diagrams to DHA/DOH for "Health Facility Briefing" approval.
    2.  **NOC for Fit-out:** Obtaining a No Objection Certificate (NOC) from the health authority before commencing installation.
    3.  **Third-Party Inspection:** Systems must be tested and certified by an independent specialist before the final authority inspection.
    4.  **Final Licensing:** DHA/DOH inspection of the plant room (Oxygen manifold, Vacuum pumps) and ward-level alarm panels.

### 2.2 Commercial Kitchens
*   **Authorities:** Dubai Municipality (DM) Food Safety Department, Abu Dhabi Agriculture and Food Safety Authority (ADAFSA).
*   **Workflow:**
    1.  **Layout Approval:** Submission of the kitchen layout showing "unidirectional flow" (Receiving → Storage → Prep → Cooking → Serving → Washing) to prevent cross-contamination.
    2.  **Grease Trap Approval:** DM/ADDC requires sizing calculations for grease traps based on the number of meals or fixture units.
    3.  **Ventilation Clearance:** Civil Defense approval for kitchen hood fire suppression systems (Ansul or equivalent).

### 2.3 Fuel Gas Systems (LPG/SNG)
*   **Authorities:** UAE Civil Defense (DCD/ADCD), Dubai Municipality, and gas providers (e.g., Emirates Gas, SERGAS).
*   **Workflow:**
    1.  **Gas NOC:** Submission of gas pipe routing and tank location plans to Civil Defense.
    2.  **Installation:** Must be performed by a Civil Defense-approved gas contractor.
    3.  **Pressure Testing:** Witnessed by the gas provider and Civil Defense inspector.
    4.  **Final Connection:** Issuance of a "Completion Certificate" followed by gas charging.

### 2.4 Vertical Transportation
*   **Authorities:** Dubai Municipality (DM), Abu Dhabi Department of Municipalities and Transport (DMT).
*   **Workflow:**
    1.  **Traffic Analysis:** Submission of a "Vertical Transportation Analysis Report" during the building permit stage to justify the number and speed of lifts.
    2.  **Installation Permit:** Obtained via the main building permit.
    3.  **Third-Party Certification:** Annual inspection by a DM/DMT-approved third-party agency (e.g., TUV, Bureau Veritas) is mandatory for operational permits.

## 3. Core Codes and Standards

UAE engineering practice relies on a blend of local codes and international standards.

| Service | UAE Code | International Standard |
| :--- | :--- | :--- |
| **Medical Gas** | DHA Health Facility Guidelines | HTM 02-01 (UK), NFPA 99 (USA), ISO 7396 |
| **Kitchens** | DM Food Safety Manual | NFPA 96 (Ventilation), BS EN 1825 (Grease Traps) |
| **Fuel Gas** | UAE Fire & Life Safety Code | NFPA 54 (Fuel Gas), NFPA 58 (LPG) |
| **Lifts/Escalators** | Dubai Building Code (Part D) | EN 81-20/50 (EU), ASME A17.1 (USA) |
| **Laboratories** | Dubai Science Park Guidelines | ASHRAE 110 (Fume Hoods), NFPA 45 |

> "The design will be based on the requirements of HTM-02-01 or NFPA-99 tailored for healthcare facilities in the Emirate of Dubai under the jurisdiction of DHA." — DHA Health Facility Guidelines, ) [[3]](#ref3)

## 4. Technical Design Content

### 4.1 Medical Gas Sizing
Designers must calculate the "Design Flow Rate" for each gas.
*   **HTM 02-01 Method:** Uses "Flow Units" assigned to each terminal unit (outlet), similar to fixture units in plumbing.
*   **NFPA 99 Method:** Uses "Diversity Factors" based on the type of room (e.g., ICU vs. General Ward).
*   **Key Formula:** $Q_{design} = \sum (Q_{outlet} \times n \times Diversity Factor)$

### 4.2 Kitchen Ventilation
The primary goal is the capture and containment of grease-laden vapors.
*   **Airflow Calculation:** $Q = A \times V$
    *   $Q$ = Airflow in CFM or m³/s.
    *   $A$ = Hood face area (ft² or m²).
    *   $V$ = Capture velocity (typically 0.38 m/s to 0.76 m/s depending on equipment type).
*   **Duct Velocity:** Minimum 1,500 fpm (7.6 m/s) to prevent grease settlement, though NFPA 96 allows as low as 500 fpm for variable speed systems.

### 4.3 Gas Pipe Sizing (LPG/SNG)
*   **Low Pressure (< 1 psi):** Spitzglass Formula is commonly used.
    *   $Q = 3550 \times k \times \sqrt{\frac{h}{L \times SG}}$
    *   Where $h$ is pressure drop (in. WC), $L$ is length, and $SG$ is specific gravity (1.5 for LPG, 0.6 for Natural Gas).
*   **Safety Interlocks:** UAE Civil Defense requires gas detectors to be interlocked with a solenoid valve at the building entry and the kitchen hood fire suppression system.

### 4.4 Vertical Transportation Traffic Analysis
*   **Handling Capacity (HC5):** The percentage of the building population the system can transport in 5 minutes.
    *   Office: 12-15%
    *   Residential: 5-8%
*   **Average Waiting Time (AWT):** Target < 30 seconds for offices, < 60 seconds for residential.

## 5. Construction, Testing, and Commissioning

### 5.1 Medical Gas Testing
*   **Cross-Connection Test:** Ensuring no gas is mixed (e.g., Oxygen coming out of a Nitrous Oxide outlet).
*   **Particulate Test:** Blowing high-pressure Nitrogen through the pipes to remove debris.
*   **24-Hour Pressure Test:** System must hold 1.5x working pressure with zero drop.

### 5.2 Lift Commissioning
*   **Safety Gear Test:** Ensuring the mechanical brake stops the car during an overspeed condition.
*   **Fireman’s Lift Operation:** Verifying the lift returns to the designated floor upon fire alarm activation and allows manual control for firefighters.

## 6. UAE Climate, Durability, and Safety Notes

*   **Ambient Temperature (50°C+):**
    *   **LPG Tanks:** Must be shaded to prevent excessive pressure buildup. Pressure Relief Valves (PRV) must be rated for UAE peak temperatures.
    *   **Lift Machine Rooms:** Must be air-conditioned (typically 20-25°C). High ambient temperatures lead to frequent "Controller Overheat" faults in lift systems.
*   **Corrosion (Salinity):**
    *   Kitchen exhaust fans and VT components located near the coast (e.g., Dubai Marina, Abu Dhabi Corniche) must use Grade 316 stainless steel or specialized anti-corrosion coatings.
*   **Sustainability (Al Sa'fat / Estidama):**
    *   Requirement for energy-efficient lift motors (VF drives) and LED lighting with sleep modes.
    *   Kitchens must use high-efficiency hoods with "Demand Controlled Kitchen Ventilation" (DCKV) to reduce AC load.

## 7. Professional Practice and Checklists

### 7.1 Design Review Checklist
*   [ ] Medical gas zone valves are located outside the rooms they serve for emergency access.
*   [ ] Kitchen grease traps are located in accessible areas for vacuum tanker cleaning (not under heavy equipment).
*   [ ] Gas solenoid valves are "Normally Closed" type, failing safe during power loss.
*   [ ] Lift lobbies meet the minimum "Stretcher Lift" dimensions (typically 1200mm x 2300mm) for healthcare and high-rise residential.

### 7.2 Common Mistakes
*   **Undersized Makeup Air:** Kitchen exhaust fans failing to capture smoke because there isn't enough fresh air entering the kitchen.
*   **Medical Gas Alarm Visibility:** Placing alarm panels in locations not constantly monitored by staff (e.g., behind a door).
*   **LPG Separation Distances:** Placing gas tanks too close to building openings or electrical equipment, violating UAE Civil Defense spacing rules.

## 8. Sources

### Primary Sources
*   **DHA Health Facility Guidelines (Part E):** [Medical Gas System Design]()) [[3]](#ref3)
*   **Dubai Building Code (2021):** [Vertical Transportation Section]() [[4]](#ref4)
*   **UAE Fire and Life Safety Code of Practice (2018):** Chapter on Gas Systems and Firefighting Lifts.
*   **Health Technical Memorandum (HTM) 02-01:** [Medical Gas Pipeline Systems]() [[5]](#ref5)

### Secondary Sources
*   **NFPA 99:** Health Care Facilities Code.
*   **NFPA 96:** Standard for Ventilation Control and Fire Protection of Commercial Cooking Operations.
*   **CIBSE Guide D:** Transportation Systems in Buildings.

## 9. Gaps and Verification Notes

*   **Specific Laboratory Gas Standards:** While general guidelines exist, specific "Specialty Gas" (e.g., Argon, Hydrogen) requirements for UAE research labs often default to manufacturer-specific standards; local authority-specific checklists for these are less publicized.
*   **SNG vs. LPG:** Differences in authority requirements for Synthetic Natural Gas (SNG) vs. LPG in Abu Dhabi (ADDC) vs. Dubai (Emirates Gas) should be verified per project location as infrastructure varies.
*   **Third-Party VT Inspectors:** The list of approved third-party agencies for lift inspections is updated annually by DM/DMT and should be verified on their respective portals.

***

**Checklist Status Summary:**
- [Y] All dimensions covered.
- [Y] Inline citations provided.
- [Y] UAE-specific climate and authority notes included.
- [Y] Checklist file updated at `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/8bf7c8d8/RESEARCH_CHECKLIST.md`.

---


## 2. Engineering Project Management, Contracts, and Professional Practice

# Source Packet 2: Engineering project management, contracts, claims and professional practice in the UAE: consultants, contractors, supervision, FIDIC, permits, engineer licensing and authority coordination

**Research topic:** Engineering project management, contracts, claims and professional practice in the UAE: consultants, contractors, supervision, FIDIC, permits, engineer licensing and authority coordination

**Report title:** Engineering Project Management, Contracts, and Professional Practice in the UAE

# Engineering Project Management, Contracts, and Professional Practice in the UAE

This research covers the regulatory, contractual, and professional framework for engineering in the United Arab Emirates, with a focus on the 2025-2026 legislative updates, including the New UAE Civil Code and the restructured engineering licensing tiers in Abu Dhabi.

## 1. Domain Scope: Engineering Management & Practice in the UAE
The engineering project management and professional practice domain in the UAE encompasses the lifecycle of construction and infrastructure projects, from licensing and design approvals to contract administration and handover. 

*   **UAE Relevance:** The sector is characterized by high-speed "fast-track" delivery, multi-authority coordination (e.g., Municipality, Civil Defense, Utilities), and a legal framework rooted in Civil Law (Sharia-influenced) rather than Common Law.
*   **Typical Projects:** High-rise residential/commercial towers, large-scale infrastructure (RTA/ITC), energy plants (ADNOC/DEWA), and free-zone developments (DP World, ADGM).
*   **Boundaries:** This domain focuses on the *process* and *legal* aspects of engineering—licensing, permits, FIDIC administration, and liability—rather than specific technical calculations for structural or MEP systems.

## 2. UAE Authorities and Approval Workflow
Project approvals in the UAE are decentralized by Emirate, with specific digital platforms for submission.

### Dubai Authority Workflow (Dubai Municipality & DDA)
1.  **NOC Collection:** Before design submission, No Objection Certificates (NOCs) must be obtained from utilities (DEWA), telecommunications (Etisalat/du), and transport (RTA).
2.  **Design Submission:** Applications are submitted via the **Dubai Building Permit System**.
3.  **Permit Issuance:** Following technical review against the **Dubai Building Code (DBC)**.
4.  **Inspections:** Mandatory structural inspections at key stages:
    *   Shoring and Excavation.
    *   Foundation/Footing (before casting).
    *   Slabs (Ground, Typical, Roof).
5.  **Completion:** Issuance of the **Building Completion Certificate (BCC)** after final inspections by DM and UAE Civil Defense.
    *   *Source:* Dubai Municipality Building Permit Steps [[6]](#ref6)

### Abu Dhabi Authority Workflow (DMT & TAMM)
1.  **Binaa Platform:** Abu Dhabi uses the AI-powered **Binaa** platform for construction permits.
2.  **Meersat/TAMM:** Integration of mainland and free-zone (ADGM) permits under a unified framework.
3.  **Minor Works Streamlining:** As of August 2025, contractors can directly secure approvals for minor works (extensions <25 sqm, non-structural mods) without full consultant dossiers.
    *   *Source:* DMT Unveils Streamlined Permit Process [[7]](#ref7)

## 3. Core Codes and Standards
*   **Federal Decree-Law No. 25 of 2025 (New Civil Code):** Effective June 1, 2026, replacing the 1985 Code. It governs all *Muqawala* (construction) contracts.
*   **Dubai Building Code (DBC):** The primary technical standard for Dubai.
*   **UAE Fire and Life Safety Code of Practice:** Mandatory for all projects, regulated by Civil Defense.
*   **FIDIC 1999 (Red/Yellow Books):** The de facto standard for contract forms, though heavily modified by "Particular Conditions."
*   **Eurocode 7:** Specifically cited by Dubai Municipality for soil testing and foundation depth requirements (e.g., borehole depth 2.5–3x foundation width).
    *   *Source:* Administrative Resolution No. (37) of 2021, )%20of%202021%20Amending%20the%20Bylaw%20Concerning.html [[8]](#ref8)

## 4. Technical Design Content: Licensing & Professional Tiers
Engineering practice is strictly regulated through professional licensing.

### Abu Dhabi's New 4-Tier System (Admin Decision 113/2025)
Introduced in 2025, this merit-based system requires exams and Professional Development Units (PDUs):
1.  **Intern Engineer:** Graduates with <3 years experience.
2.  **Practitioner Engineer:** Minimum 3 years experience + exam.
3.  **Professional Engineer:** Advanced competency + PDUs.
4.  **Expert Engineer:** Highest tier, requiring significant experience and specialist accreditation.
    *   *Source:* DMT New Engineers Professional Grades [[9]](#ref9)

### Dubai Licensing (Circular 133/2005)
*   **Engineer Card:** Mandatory for all engineers to sign off on drawings or supervise sites.
*   **Society of Engineers (SOE) UAE:** Membership is a prerequisite for municipality registration. Requirements include attested degrees and equivalency from the Ministry of Education (MOE).
    *   *Source:* Dubai Municipality Consultants and Contractors Licensing Standards [[10]](#ref10)

## 5. Construction Supervision, Testing, and Commissioning
Supervision in the UAE is a legal responsibility of the "Consultant of Record."

*   **Structural Inspections:** Consultants must request DM inspection for footings and slabs *before* concrete casting.
*   **Occupancy Certificates:** Abu Dhabi's new program (2026) uses a three-stage compliance model, starting with a **Conditional Occupancy Certificate** focusing on fire safety and structural integrity.
*   **Testing:** Soil reports must be submitted by DM-accredited labs; shoring completion certificates are required before foundation works.
    *   *Source:* TAMM Technical Site Inspection [[11]](#ref11)

## 6. UAE Climate, Durability, and Liability Notes
### Decennial Liability (Articles 880-883)
The UAE imposes a mandatory 10-year liability for structural collapse or major defects.
*   **Joint Liability:** The architect/engineer and the contractor are jointly liable for 10 years from handover.
*   **Claim Window:** Under the New Civil Code, claims must be filed within **3 years** of the collapse or discovery of the defect.
*   **Mandatory Nature:** Any contractual clause attempting to limit or waive decennial liability is void under UAE law.
    *   *Source:* UAE Decennial Liability 2026 [[12]](#ref12)

### Hardship and Price Adjustments (New Civil Code)
*   **Article 224:** General hardship provision allowing courts to rescind or adjust contracts in exceptional, unforeseeable circumstances.
*   **Article 829:** A new *Muqawala*-specific provision empowering judges to extend completion periods or increase remuneration to restore contractual balance.
    *   *Source:* Hardship and Lump-Sum Price Adjustments [[13]](#ref13)

## 7. Professional Practice and Checklists
### Senior Engineer Design Review Checklist
- [ ] Verify SOE membership and Municipality Card validity for all signing engineers.
- [ ] Confirm NOCs from all relevant utilities (DEWA/ADDC, RTA/ITC, Civil Defense).
- [ ] Check compliance with the latest Dubai Building Code or Abu Dhabi International Building Code.
- [ ] Ensure decennial liability insurance is in place for the consultancy.
- [ ] Review FIDIC Particular Conditions for Article 390 (Liquidated Damages) compliance.

### Common Mistakes in UAE Practice
*   **Notice Periods:** Failing to adhere to FIDIC 28-day notice periods for claims (though UAE courts sometimes provide relief under "Good Faith" principles).
*   **Liquidated Damages:** Assuming LD caps are absolute; Article 390 allows UAE courts to increase or decrease LDs to match actual loss.
*   **Attestation:** Delaying the MOE degree equivalency process, which can take months and block engineer registration.

## 8. Source Links
### Primary Sources
*   **Dubai Municipality (DM):** [Building Permit Procedures]() [[6]](#ref6)
*   **Department of Municipalities and Transport (DMT) Abu Dhabi:** [New Engineering Grades 113/2025]() [[9]](#ref9)
*   **UAE Society of Engineers (SOE):** [Membership Portal]() [[1]](#ref1)
*   **Dubai Legislation Portal:** [Administrative Resolution 37/2021]()%20of%202021%20Amending%20the%20Bylaw%20Concerning.html) [[8]](#ref8)

### Secondary/Expert Analysis
*   **Charles Russell Speechlys:** [New UAE Civil Code Articles 224 & 829]() [[13]](#ref13)
*   **Kayrouz & Associates:** [Decennial Liability 2026 Guide]() [[12]](#ref12)

## 9. Gaps and Verification Notes
*   **PDU Specifics:** The exact number of Professional Development Units (PDUs) required for each DMT grade (Practitioner to Expert) is not yet fully detailed in public circulars and requires verification via the TAMM portal.
*   **Article 829 Excludability:** There is ongoing legal debate on whether the new *Muqawala* hardship provision (Article 829) can be contractually excluded, as it lacks the "void" language of the general Article 224.
*   **Exam Syllabi:** Specific syllabi for the new DMT engineering exams are not public and are typically provided to applicants upon registration.

**Checklist Status:**
- Runtime checklist path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/938b4c14/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---


## 3. Professional Licensing and Engineer Registration

| Jurisdiction | Licensing Pathway | Key Requirement |
| --- | --- | --- |
| Dubai Municipality (DM) | Society of Engineers UAE (SOE) membership + DM card exam | G+1 / G+4 / G+12 / Unlimited categories; card required to sign drawings and supervise sites [[1]](#ref1) |
| Abu Dhabi DMT | Engineers Licensing System (EPLS) on TAMM portal | Minimum 3 years experience; practicing license tied to firm registration [[14]](#ref14) |
| Trakhees / DDA | Trakhees accredited consultant list | Firm accreditation required; individual engineer experience verified |
| SOE UAE Membership | Attested engineering degree + experience record | National professional body membership; required for municipality card in most emirates [[1]](#ref1) |


## 4. FIDIC Contract Framework in UAE Practice

| Form | Common UAE application | Practical note |
| --- | --- | --- |
| FIDIC Red Book 1999 | Employer-designed works; most widely used UAE contract form[[2]](#ref2) | Engineer administers; Particular Conditions amend UAE law conflicts |
| FIDIC Yellow Book 1999 | Design-and-build; contractor responsible for design | Used for MEP turnkey, fit-out, and specialist packages |
| FIDIC Silver Book 1999 | EPC/Turnkey; contractor carries risk | Common in oil & gas, infrastructure concessions |
| FIDIC 2017 Editions | Gaining traction but often heavily amended | 2017 DAB replaced by dispute avoidance/adjudication board |


## 5. Project Lifecycle and Authority Coordination Checklist

### Project lifecycle authority coordination checklist

1. **Pre-design (NOC round 1)** — DEWA/ADDC utility capacity NOC; RTA traffic NOC; Etisalat/du telecoms NOC; Civil Defense initial comments; municipality area planning clearance.
2. **Concept design** — Municipality schematic approval; Al Sa'fat/Estidama preliminary registration; specialist NOCs (DGCX, aviation, heritage zone if applicable).
3. **Detailed design** — Building permit application: upload drawings, calculations, BIM model (if required), structural and MEP approvals, and Civil Defense fire drawings.
4. **Construction** — Foundation inspection; structural slab inspections; MEP rough-in inspections; DEWA/ADDC substation and network inspections; periodic municipality safety inspections.
5. **Completion** — Civil Defense final test and completion certificate; DEWA/ADDC permanent connection; DM/DMT Completion Certificate; NOC from municipality for occupancy; utility meter activation.
6. **Post-completion** — As-built drawings submission; O&M manuals; BIM model as-built (if BIM-mandated project); 10-year decennial liability period for structural engineer and contractor under Civil Code.


## 6. Technical Notes — Medical Gas and Vertical Transportation

| System | Key Requirement | Standard / Authority |
| --- | --- | --- |
| Medical oxygen | >99.5% purity; primary + secondary + emergency/reserve source; tested to HTM 02-01 / NFPA 99 | DHA HFG Part E_7 (Dubai)[[3]](#ref3) |
| Medical air (4 bar) | Oil-free; dew point ≤-46°C; bacteria-filter mandatory | DOH Abu Dhabi / DHA guidelines |
| Surgical air (7 bar) | Separate supply from medical air; pressure-regulated at manifold | HTM 02-01 / NFPA 99 |
| Vacuum (AGSS) | Anaesthetic gas scavenging mandatory in all OR/procedure rooms | HTM 02-01 |
| Fire lift | Mandatory buildings >15 m occupied floor; EN 81-72 or ASME A17.1 | DBC Part D[[4]](#ref4) |
| Lift capacity | One lift minimum per 4 storeys; max walking distance to lobby 45 m | DBC / ADIBC |


## Expert Appendix: Field Control, Design Review, and Authority Coordination Templates

### Template A: Design Review Checklist Framework
A senior engineering design review should confirm: design basis and load assumptions are documented; code edition and amendment dates are stated; all UAE authority requirements have been addressed by reference; specialist sub-consultant inputs are incorporated and coordinated; sustainability compliance (Al Sa'fat or Estidama as applicable) is addressed; fire and life safety interfaces are resolved; and the drawing set matches calculations and specifications. Any deviation from code requires a written technical justification.

### Template B: Authority Submission Package
Before submitting to any UAE authority, confirm: the submitting consultant firm holds a valid practising card/approval for the project emirate; drawings are in the required format and coordinate system; all NOCs from upstream authorities are attached; calculations are signed by a registered engineer; the BIM model (if mandated under DM Circular 9-1-3/2026 or Abu Dhabi DMT requirements) is attached in the required format; and fees or bonds have been paid. Incomplete packages are returned without review in most Dubai and Abu Dhabi portals.

### Template C: Site Supervision and Inspection Record
For each Witness or Hold point on the ITP, the site supervisor should confirm: the work activity matches the approved shop drawing; material has a valid test certificate or Material Approval Request (MAR); pre-activity conditions (compaction, formwork, earthing, cleanliness) are met; work execution matches approved method statement; post-activity tests are conducted and recorded; Non-Conformance Reports are raised immediately for failures; and the record is signed, dated, and uploaded to the document management system.

### Template D: Commissioning and Handover Record
The commissioning package should include: signed Commissioning Manager appointment; pre-commissioning mechanical completion certificates; equipment startup records with measured versus specified values; functional test sheets for all systems; cause-and-effect matrix testing records for life-safety interfaces; Training records for the building operator; Operating and Maintenance manuals with as-built BIM model; and a Defect Tracking Register. In Dubai, DEWA/DCD and DM will conduct their own independent inspections before issuing the Completion Certificate.

### Template E: Professional Risk Register for UAE Engineering Projects
Key project risks to track: BIM submission readiness; NOC expiry dates and renewal sequences; Specialist material lead times (high-performance concrete, specialist glazing, medical gas equipment); Third-party inspection availability; Civil Defense comments on fire systems; Authority variations discovered late in design; Structural peer review findings; Geotechnical report limitations; Weather restrictions on concrete pours; Power supply sequencing for DEWA connection; District Cooling provider connection timing; and Snagging management strategy for Completion Certificate.

## Deep Practice Appendix: UAE Engineering Field Reference Library

### A. Concrete pour control in UAE climate
Fresh concrete must not exceed 32°C at the time of pouring per Dubai Municipality requirements. Practical controls include: scheduling pours at night or early morning during summer; pre-cooling aggregates and water; using liquid nitrogen injection for very large pours; covering trucks and placing time limits from batching plant to pour; using ice as part of mix water; insulating formwork if mass concrete; and monitoring temperature with embedded thermocouples for pours exceeding 500 mm thickness where heat-of-hydration crack risk exists.

### B. UAE wind loading practice for tall buildings
The Dubai Building Code 2021 references ASCE 7-16 for wind design. For buildings exceeding 120 m height or irregular floor plates, a specialist wind tunnel study is mandatory. The study typically includes: mean wind speed profile; turbulence intensity profile; pressure distribution across facade panels and corners; base shear and overturning moment for structural frame; floor acceleration for occupant comfort under dynamic wind; and glass/cladding pressure coefficients. Wind consultants use a Boundary Layer Wind Tunnel (BLWT) and provide client-specific pressure maps that override ASCE 7 simplified charts.

### C. UAE fire safety critical defect list
Before Civil Defense final inspection, teams should resolve: non-rated compartmentation penetrations (every hole in a fire wall must be fire-stopped to FM 4991 or UL-listed system); sprinkler heads within 450 mm of a luminaire; missing fire-rated ductwork collars; staircase pressurisation system functional test incomplete; fire pump power supply not on dedicated circuit; fire alarm panel not in approved location; exit sign luminance below code minimum; door-closer adjustment needed on fire doors; emergency lighting duration below 3-hour requirement; and missing fire-rated access panels for active system valves.

### D. DEWA final inspection readiness checklist
Before requesting DEWA final inspection for electricity connection: all MDB/SMDB/DB boards installed, labeled, and secured; all cable connections terminated and insulation resistance tested; earth electrode installed, measured, and result ≤1 ohm; all circuits identified, protected, and balanced within 10% between phases; emergency power circuits segregated and labeled; RCDs tested; cable trunking/trays fully supported and bonded; substation ventilation confirmed; and as-built single line diagram reflects installed equipment.

### E. Geotechnical risk register for UAE projects
Common geotechnical risks in UAE: (1) Sabkha — expansive salt-rich soils that lose bearing capacity when wetted; mitigate by removal and replacement or ground improvement; (2) Gypsiferous soils — dissolution creates voids under foundations; test sulfate content and use sulfate-resistant cement; (3) Loose sand over the water table — liquefaction risk in seismic events; assess and improve if Vs30 < 180 m/s; (4) High groundwater — dewatering impacts on adjacent structures; pre-construction settlement monitoring required; (5) Coral limestone (caprock) — variable quality; carry out borehole core quality designation (RQD) and end-bearing verification for piles; (6) Contaminated land — former industrial or oil storage sites; Phase 1 and Phase 2 assessment before construction.

### F. UAE project documentation matrix
For all UAE engineering projects, the following documentation set should be maintained: Design Brief + Basis of Design memo; Approved shop drawings register; Material Approval Request (MAR) log; Inspection and Test Plan (ITP) with sign-off sheets; Non-Conformance Report (NCR) register; Request for Information (RFI) log; Authority submission log with NOC expiry tracking; As-built drawing issue record; Commissioning test sheets; O&M manual receipt confirmation; and Training attendance records. Completeness of this set is assessed during the Completion Certificate audit.


## Extended Technical Reference: UAE Project Management Practice

### FIDIC Contract Administration in UAE
The UAE Civil Code and Commercial Transactions Law apply to all UAE contracts. Key intersections with FIDIC:
- **FIDIC Sub-Clause 2.5 (Employer's Claims):** UAE law does not recognise time bars as strictly as FIDIC; UAE courts may allow late claims if the claimant can demonstrate entitlement. Particular Conditions often modify this Sub-Clause.
- **FIDIC Sub-Clause 8.4 (Extension of Time):** The Engineer must determine entitlement within 42 days; UAE practice often sees this provision triggered for adverse weather (sandstorm, rain stoppage), authority delays (NOC), and design changes.
- **Sub-Clause 20 Disputes:** FIDIC 1999 DAB (Dispute Adjudication Board) is often deleted or replaced by a Dispute Resolution Board (DRB) or referral directly to arbitration (DIAC — Dubai International Arbitration Centre, or ADCCAC — Abu Dhabi Centre for Conciliation and Arbitration).
- **Variation orders:** All variations must be instructed in writing; oral instructions must be confirmed within 7 days or they are not valid instructions under standard FIDIC.
- **Retention:** Typically 10% retained up to a limit of 5% of Contract Price; released 50% at Taking Over, 50% at end of Defects Notification Period (typically 1 year).

### UAE Decennial Liability
Under UAE Civil Code Article 880, designers and contractors are jointly liable for the structural safety of a building for 10 years after completion:
- **Scope:** Structural failures and defects that threaten the building's stability or safety; applies to structural engineer, architect, and main contractor.
- **Coverage:** Professional Indemnity (PI) insurance and Decennial Liability (DL) insurance are typically required by the employer; some authorities require proof of coverage before Completion Certificate.
- **Exclusions:** Normal wear and tear, owner modifications, and events of force majeure.
- **Practical impact:** Structural engineers should retain all design calculations, approval records, and site inspection reports for the full 10-year period plus legal dispute allowance.

### Construction Programme and Delay Analysis
Key elements of a UAE-compliant delay analysis:
- **Baseline programme:** Submitted and approved within the contract timeframe (typically 28 days from commencement); use Primavera P6 or MS Project; must show critical path, key milestones, and resource loading.
- **Programme updates:** Monthly updates required; baseline vs. as-built comparison for delay analysis.
- **Delay analysis methods:** Time Impact Analysis (TIA) or As-Planned vs. As-Built; TIA is preferred by DRBF and FIDIC guidance because it evaluates delays contemporaneously.
- **Concurrent delay:** UAE courts generally require the party claiming extension of time to prove their delay was the dominant cause; pure concurrent delay arguments are less successful than in English law.
- **Prolongation costs:** Documented against actual cost records; site establishment costs, supervision, equipment standing time, and head-office overhead (Hudson formula or Emden formula acceptable).

### Authority Coordination Master Schedule
For a typical Dubai mixed-use tower, the NOC and approval sequence is:
1. Concept design → DEWA capacity study (8–12 weeks); RTA traffic impact study (6–10 weeks); Civil Defense concept review (4–6 weeks).
2. Schematic design → DM schematic approval; DEWA NOC; RTA NOC; telecom NOCs.
3. Detailed design → DM Building Permit (target 2 working days for complete submission); DCD fire drawings approval (2–6 weeks).
4. Foundation → DM foundation inspection; geotechnical report approval.
5. Structure → DM structural inspection at slab levels.
6. MEP → DEWA substation inspection; DCD fire system inspection.
7. Completion → DCD Completion Certificate → DM Completion Certificate → DEWA permanent connection → OC issued.

Each step has typical elapsed times and potential delay risks that should be tracked in the project programme with float assigned.


## Extended Reference: Professional Practice and Claims

### Extension of Time — UAE Practice Notes
Under FIDIC contracts in the UAE, extensions of time claims must be submitted promptly and supported by contemporaneous records:
- **FIDIC Sub-Clause 20.1 notice:** Notice of intention to claim must be given within 28 days of the event giving rise to the claim; UAE courts have mixed records on enforcing this bar strictly.
- **Programme impact evidence:** Show delay event on approved baseline programme; demonstrate critical path impact using TIA methodology.
- **Authority delays as grounds:** Delays in obtaining NOC, municipality inspection, utility connection, or Civil Defense approval are generally accepted grounds for EOT if the contractor is not responsible.
- **Weather claims:** Exceptional adverse weather (defined in the Particular Conditions, typically with reference to a historical meteorological record) is an excusable delay; UAE sandstorms and heavy rain events qualify if they exceed the defined threshold.
- **Concurrent delay:** If contractor-caused and employer-caused delays run concurrently, the contractor is typically entitled to time only (not prolongation costs) unless the Particular Conditions state otherwise.

### Claims Preparation — Document Requirements
A well-prepared UAE construction claim includes:
1. **Narrative:** Factual description of the event, cause, and effect on the works; written in simple clear language.
2. **Programme analysis:** Baseline programme + delay event impact + revised programme showing critical path effect.
3. **Daily records:** Site diary entries, weather records, workforce and plant allocation sheets for the delay period.
4. **Correspondence:** Emails, RFIs, authority letters, variation instructions, and approval notifications that evidence the cause and the contractor's response.
5. **Quantification:** Build-up of time (days affected) and cost (if applicable) with supporting invoices, timesheets, and overhead allocation.
6. **Legal basis:** Reference to the applicable contract clause(s).

### UAE Contractor and Consultant Grade Classification
Dubai Municipality classifies contractors by grade (G1–G5, Unlimited) based on financial capacity and project experience. Key points:
- **Unlimited grade:** Required for buildings above G+12; requires minimum AED 50 million annual turnover and substantial project experience.
- **Specialist categories:** Separate licenses for piling, facade, MEP, and fit-out works; a general contractor cannot self-perform specialist works without the relevant sub-license.
- **Consultant grades:** Similar grading for consulting firms; the grade restricts the maximum building height and BUA the consultant can sign off on.
- **Engineer in charge:** An individual licensed engineer (DM card holder) must be named as Engineer in Charge for every permitted project; they carry personal professional liability.

### Commissioning and Handover Framework (UAE)
A comprehensive UAE commissioning programme structure:
- **Phase 1 (Pre-commissioning):** Confirm all systems are mechanically complete; leak tests; electrical insulation checks; equipment uncrating and alignment.
- **Phase 2 (Commissioning):** Systems started up individually; set-points adjusted; balancing of air and water distribution; initial functional tests.
- **Phase 3 (Integrated systems testing):** Fire and life safety cause-and-effect tests; BMS sequence of operations verification; emergency power switchover tests; evacuation alarm tests witnessed by Civil Defense.
- **Phase 4 (Performance testing):** Energy benchmarking; IAQ measurements; acoustic measurements; confirm sustainability credits where required.
- **Phase 5 (Handover):** O&M manual delivery; training records; as-built drawings; BIM model as-built; CAFM database population; spare parts handover; defects list agreement.

## Professional Quick Reference: Common UAE Engineering Thresholds

| Parameter | Value | Authority/Source |
|---|---|---|
| BIM mandate threshold (Dubai) | G+12 or ≥15,000 m² BUA | DM Circular 9-1-3/2026 |
| Boreholes for high-rise (Dubai) | Min 5; 1 per 750 m² | Admin Resolution 37/2021 |
| Max shoring lateral displacement (Trakhees) | 40 mm | Trakhees Grey Code |
| Wind tunnel test threshold | ≥120 m height or irregular plan | DBC 2021 |
| Max fresh concrete temperature at pour | 32°C | Dubai Municipality |
| Min concrete cover — foundations | 75 mm | DBC 2021 |
| Max w/c ratio — severe exposure | 0.40 | DBC 2021 / ACI 318 |
| DEWA earth electrode resistance | ≤1 Ohm | DEWA Regulations 2017 |
| Emergency lighting duration | 3 hours (180 min) | UAE Fire Code 2018 |
| Sprinkler smoke detector spacing | Max 9 m | UAE Fire Code |
| Fire lift mandatory above | 15 m occupied floor height | DBC Part D |
| Residential water demand | 250–350 L/capita/day | DEWA Water Planning Guidelines |
| Min self-cleansing sewer velocity | 0.75 m/s | ADSSC Design Guidelines |
| NFPA 285 cladding test | Required all combustible assemblies >2 storeys | UAE Civil Defense |
| Midday break period | 12:30–15:00, 15 Jun–15 Sep | MOHRE |
| Decennial liability period | 10 years post-completion | UAE Civil Code Article 880 |
| FIDIC EOT notice period | 28 days from triggering event | FIDIC Red Book Sub-Clause 20.1 |
| Traffic study threshold (Dubai RTA) | >100 vehicle trips/peak hour | RTA eNOC portal |
| Missing parking space fine (Abu Dhabi) | AED 50,000/space | ITC Abu Dhabi |
| Estidama mandatory minimum rating | 1 Pearl (government: 2 Pearls) | Abu Dhabi DMT |
| Al Sa'fat mandatory minimum rating | Silver Sa'fa | Dubai Municipality |
| ADNOC pressure vessel standard | AGES-SP-06-002 / ASME VIII | ADNOC Group Engineering Standards |
| Hazardous area cert UAE | ECAS-Ex Certificate required | MoIAT ECAS scheme |

## References

<p id="ref1" class="ref_item">[1] soeuae.ae <a target="_blank" rel="noreferrer" href="https://www.soeuae.ae/">https://www.soeuae.ae/</a></p>
<p id="ref2" class="ref_item">[2] daemuae.com <a target="_blank" rel="noreferrer" href="https://daemuae.com/daem-constructions/dcd-vs-dm-noc-in-dubai-whats-the-difference/">https://daemuae.com/daem-constructions/dcd-vs-dm-noc-in-dubai-whats-the-difference/</a></p>
<p id="ref3" class="ref_item">[3] services.dha.gov.ae <a target="_blank" rel="noreferrer" href="https://services.dha.gov.ae/tahpi-app/HealthFacilityGuidelines/Guidelines/FileContent/Preview/DHAHFG/Part%20E_7%20-%20Public%20Health%20-%20Medical%20Gas%20System%20Design%20(MGS">https://services.dha.gov.ae/tahpi-app/HealthFacilityGuidelines/Guidelines/FileContent/Preview/DHAHFG/Part%20E_7%20-%20Public%20Health%20-%20Medical%20Gas%20System%20Design%20(MGS</a></p>
<p id="ref4" class="ref_item">[4] dda.gov.ae <a target="_blank" rel="noreferrer" href="https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf">https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf</a></p>
<p id="ref5" class="ref_item">[5] england.nhs.uk <a target="_blank" rel="noreferrer" href="https://www.england.nhs.uk/wp-content/uploads/2021/05/HTM_02-01_Part_A.pdf">https://www.england.nhs.uk/wp-content/uploads/2021/05/HTM_02-01_Part_A.pdf</a></p>
<p id="ref6" class="ref_item">[6] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/building-permit-steps/">https://www.dm.gov.ae/municipality-business/building-permit-steps/</a></p>
<p id="ref7" class="ref_item">[7] dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dmt.gov.ae/en/Media-Centre/News/DMT-Unveils-Streamlined-Permit-Process-for-Minor-Works">https://www.dmt.gov.ae/en/Media-Centre/News/DMT-Unveils-Streamlined-Permit-Process-for-Minor-Works</a></p>
<p id="ref8" class="ref_item">[8] dlp.dubai.gov.ae <a target="_blank" rel="noreferrer" href="https://dlp.dubai.gov.ae/Legislation%20Reference/2021/Administrative%20Resolution%20No.%20(37">https://dlp.dubai.gov.ae/Legislation%20Reference/2021/Administrative%20Resolution%20No.%20(37</a></p>
<p id="ref9" class="ref_item">[9] dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dmt.gov.ae/en/Media-Centre/News/DMT-New-Engineers-Professional-Grades-and-Enhanced-Standards">https://www.dmt.gov.ae/en/Media-Centre/News/DMT-New-Engineers-Professional-Grades-and-Enhanced-Standards</a></p>
<p id="ref10" class="ref_item">[10] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/consultants-and-contractors-licensing-standards/">https://www.dm.gov.ae/municipality-business/consultants-and-contractors-licensing-standards/</a></p>
<p id="ref11" class="ref_item">[11] tamm.abudhabi <a target="_blank" rel="noreferrer" href="https://www.tamm.abudhabi/en/life-events/business/housing-construction/consultants-contractors/RequestforTechnicalSiteInspection">https://www.tamm.abudhabi/en/life-events/business/housing-construction/consultants-contractors/RequestforTechnicalSiteInspection</a></p>
<p id="ref12" class="ref_item">[12] kayrouzandassociates.com <a target="_blank" rel="noreferrer" href="https://www.kayrouzandassociates.com/insights/decennial-liability-uae-contractors-engineers-2026">https://www.kayrouzandassociates.com/insights/decennial-liability-uae-contractors-engineers-2026</a></p>
<p id="ref13" class="ref_item">[13] charlesrussellspeechlys.com <a target="_blank" rel="noreferrer" href="https://www.charlesrussellspeechlys.com/en/insights/expert-insights/construction-engineering-and-projects/2026/hardship-and-lump-sum-price-adjustments-under-the-new-uae-civil-code-articles-224-and-829/">https://www.charlesrussellspeechlys.com/en/insights/expert-insights/construction-engineering-and-projects/2026/hardship-and-lump-sum-price-adjustments-under-the-new-uae-civil-code-articles-224-and-829/</a></p>
<p id="ref14" class="ref_item">[14] dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dmt.gov.ae/">https://www.dmt.gov.ae/</a></p>
