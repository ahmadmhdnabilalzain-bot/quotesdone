# Roads, Transportation, Water, Wastewater, and Urban Infrastructure Engineering in the UAE

This chapter covers transportation engineering, urban roads, traffic studies, and municipal water/wastewater/stormwater infrastructure. These disciplines share authority interfaces, permit workflows, and design standards. [[1]](#ref1)

## 1. Transportation and Roads Engineering

# Source Packet 14: Transportation and roads engineering: RTA, ITC/DMT, road design, traffic impact studies, parking, access, signage and road safety

**Research topic:** Transportation and roads engineering: RTA, ITC/DMT, road design, traffic impact studies, parking, access, signage and road safety

**Report title:** Transportation and Roads Engineering in the UAE

# Transportation and Roads Engineering in the UAE

Transportation and roads engineering in the UAE is a critical domain governed by stringent local standards and international best practices. The sector is primarily managed by emirate-level authorities such as the **Roads and Transport Authority (RTA)** in Dubai and the **Integrated Transport Centre (ITC)** under the **Department of Municipalities and Transport (DMT)** in Abu Dhabi.

## 1. Domain Scope and UAE Relevance
The domain encompasses the planning, design, construction, and maintenance of road networks, bridges, tunnels, and public transport infrastructure. In the UAE, this field is characterized by rapid urban expansion, high vehicle ownership rates, and a focus on "smart city" integration. Typical projects range from internal community roads and parking facilities to multi-lane federal highways (e.g., E11 Sheikh Zayed Road) and complex interchanges.

## 2. UAE Authorities and Approval Workflow
The approval process is highly structured and digitalized through dedicated portals.

### Dubai (RTA)
*   **Authorities**: RTA (Roads Planning and Design Directorate), Dubai Municipality (for internal plot roads), and Free Zone authorities (e.g., DDA, Dubai South).
*   **Workflow**:
    1.  **Traffic Impact Study (TIS)**: Required for new developments to assess impact on the existing network.
    2.  **Preliminary Design NOC**: Submission of road layouts, access points, and parking through the **eNOC portal**.
    3.  **Final Design NOC**: Detailed engineering drawings including pavement design, drainage, and signage.
    4.  **Construction NOC**: Required before any site work begins.
    5.  **Completion Certificate**: Issued after final inspection and "As-Built" drawing approval.
*   **Source**: RTA eNOC Portal [[1]](#ref1)

### Abu Dhabi (ITC/DMT)
*   **Authorities**: ITC (Integrated Transport Centre) and DMT (Department of Municipalities and Transport).
*   **Workflow**:
    1.  **Transport Impact Study (TIS)**: Mandatory for all urban projects per Executive Council Resolution No. 13 of 2011.
    2.  **Circulation Plan (CP)**: For smaller projects.
    3.  **NOC for Infrastructure**: Obtained through the DMT "Tamm" portal.
*   **Source**: ITC Abu Dhabi TIS Manual [[2]](#ref2)

## 3. Core Codes and Standards
UAE engineering practice relies on a mix of local manuals and international standards (AASHTO, UK Design Manual for Roads and Bridges).

*   **Dubai**:
    *   **RTA Road Design Manual**: Primary guide for geometric design.
    *   **Dubai Building Code (2021)**: Section B (Architecture) and Section G (Transportation) for parking and internal roads.
    *   **Dubai Trip Generation and Parking Rates Manual**: For TIS calculations.
*   **Abu Dhabi**:
    *   **Abu Dhabi Urban Street Design Manual (USDM)**: Focuses on "Complete Streets" and pedestrian-first design.
    *   **Abu Dhabi Road Structures Design Manual**.
*   **Federal**:
    *   **UAE Ministry of Energy and Infrastructure (MOEI)**: Standards for federal highways connecting emirates.
*   **Source**: Dubai Building Code 2021 [[3]](#ref3)

## 4. Technical Design Content

### Traffic Impact Study (TIS) Thresholds
Studies are categorized based on the number of trips generated during the peak hour:

| Study Level | Dubai (RTA/DDA) Threshold | Abu Dhabi (ITC) Threshold |
| :--- | :--- | :--- |
| **Circulation Plan / L1** | 100 - 500 trips/hr | < 100 trips/hr |
| **TIS / L2** | 500 - 1,500 trips/hr | 100 - 2,500 trips/hr |
| **TMP / L3** | > 1,500 trips/hr | > 2,500 trips/hr |

*   **Software**: Standard tools include **SIDRA** (intersections), **Synchro/SimTraffic** (corridors), and **PTV VISSIM** (microsimulation for complex interchanges).
*   **Source**: DDA TIS Circular, ; ITC TIS Manual [[4]](#ref4)[[2]](#ref2)

### Geometric Design Parameters (Abu Dhabi USDM)
*   **Lane Widths**:
    *   Standard: 3.65 m (Highways/Boulevards).
    *   Urban Streets: 3.0 m to 3.3 m (to encourage lower speeds).
*   **Design Speeds**:
    *   Boulevards: 60–80 km/h.
    *   Avenues: 40–60 km/h.
    *   Streets: 20–40 km/h.
*   **Gradients**: Maximum 1:20 (5%) for pedestrian routes; road ramps typically max 10-12% with transitions.
*   **Source**: Abu Dhabi Urban Street Design Manual [[5]](#ref5)

### Parking Standards (Dubai Building Code)
*   **Dimensions**: Standard bay 2.5 m x 5.0 m; Accessible bay 3.6 m x 6.0 m (including 1.1 m side clearance).
*   **Ratios**:
    *   Residential (1BR): 1 bay per unit.
    *   Residential (2BR): 2 bays per unit.
    *   Office: 1 bay per 50-75 sq.m GFA (varies by zone).
*   **Source**: Dubai Building Code 2021 [[3]](#ref3)

## 5. Construction, Testing, and Commissioning
*   **Subgrade/Pavement**: Compaction testing (Proctor test), California Bearing Ratio (CBR) > 15% for subgrade.
*   **Asphalt**: Marshall Stability and Flow tests; Bitumen extraction and gradation.
*   **Road Safety Audit (RSA)**: Mandatory at four stages:
    1.  Stage 1: Completion of Preliminary Design.
    2.  Stage 2: Completion of Detailed Design.
    3.  Stage 3: Completion of Construction (Pre-opening).
    4.  Stage 4: Post-opening monitoring (12 months).
*   **Source**: Abu Dhabi Road Safety Audit Manual [[6]](#ref6)

## 6. UAE Climate, Durability, and Safety
*   **Heat/UV**: High-grade polymer-modified bitumen (PMB) is used to prevent rutting at temperatures exceeding 50°C.
*   **Sand/Dust**: Roadside design includes "sand-trapping" verges and specific drainage details to prevent sand accumulation on the traveled way.
*   **Signage Colors**:
    *   **Green**: Major destinations and highways (E-routes).
    *   **Blue**: Local roads and services (D-routes).
    *   **Brown**: Tourist attractions and landmarks.
    *   **White**: Local street names and information.
*   **Source**: UAE Road Signs Guide [[7]](#ref7)

## 7. Professional Practice and Checklists
Senior engineers focus on **Access Management** (minimizing driveways on major roads) and **Swept Path Analysis** (using AutoTURN) to ensure fire trucks and buses can navigate junctions.

**Design Review Checklist**:
*   [ ] TIS approved by RTA/ITC?
*   [ ] Sight distances (SSD/ISD) verified for all junctions?
*   [ ] Parking ratios meet Dubai Building Code/ITC requirements?
*   [ ] Swept path analysis for 12m/18m buses and fire trucks?
*   [ ] Drainage discharge points coordinated with DEWA/ADDC?

## Sources
1.  **RTA Dubai eNOC Portal [[1]](#ref1)
2.  **ITC Abu Dhabi TIS Manual [[2]](#ref2)
3.  **Dubai Building Code 2021 [[3]](#ref3)
4.  **Abu Dhabi Urban Street Design Manual (USDM) [[5]](#ref5)
5.  **DDA TIS Circular [[4]](#ref4)
6.  **UAE Road Signs (Wikipedia/RTA) [[7]](#ref7)

## Gaps and Verification Notes
*   **RTA Road Design Manual**: The full 600+ page manual is often restricted to registered consultants; specific lane width tables for Dubai-specific "D-routes" should be verified against the latest TR-514 version.
*   **Fee Structures**: RTA and ITC fees for TIS review and NOC issuance are subject to change and should be verified on the respective portals at the time of application.
*   **2024 Updates**: Abu Dhabi ITC launched new TIS guidelines in early 2024; practitioners must ensure they are using the latest "Transport Impact Studies Guidelines 2024".

**Checklist Status**:
*   Checklist file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/a630fbb0/RESEARCH_CHECKLIST.md`
*   All items marked `[Y]`.

---


## 2. Water, Wastewater, and Stormwater Infrastructure Engineering

# Source Packet 16: Water, wastewater and stormwater infrastructure engineering: networks, pumping stations, treatment, drainage, flood resilience, utilities coordination

**Research topic:** Water, wastewater and stormwater infrastructure engineering: networks, pumping stations, treatment, drainage, flood resilience, utilities coordination

**Report title:** Collector Report: Water, Wastewater, and Stormwater Infrastructure Engineering (UAE)

# Collector Report: Water, Wastewater, and Stormwater Infrastructure Engineering (UAE)

This report provides a comprehensive collection of source-backed engineering knowledge for water, wastewater, and stormwater infrastructure in the UAE, focusing on Dubai and Abu Dhabi.

## 1. Domain Scope and UAE Relevance
The domain encompasses the planning, design, construction, and operation of "wet utilities" essential for urban development in the UAE's arid but rapidly developing environment.
- **Sewerage Networks**: Gravity and pressure systems for domestic and industrial wastewater.
- **Stormwater & Drainage**: Systems designed to manage intense, short-duration rainfall events and prevent urban flooding.
- **Potable Water**: Transmission and distribution networks ensuring 24/7 supply in a desert climate.
- **Recycled Water (TSE)**: Treated Sewage Effluent used for irrigation and industrial cooling, a critical component of the UAE's circular economy.
- **Typical Projects**: Master-planned communities (e.g., Dubai South, Yas Island), high-rise utility connections, and major trunk infrastructure (e.g., Dubai's Deep Tunnel Stormwater System).

## 2. UAE Authorities and Approval Workflow
Infrastructure projects require multi-stage approvals from local utilities and municipalities.

### Dubai Authorities
- **Dubai Municipality (DM)**: Oversees sewerage, drainage, and irrigation networks.
- **DEWA (Dubai Electricity and Water Authority)**: Manages potable water transmission and distribution.
- **RTA (Roads and Transport Authority)**: Coordinates utility corridors within the Right of Way (ROW).

### Abu Dhabi Authorities
- **TAQA Water Solutions (formerly SWS/ADSSC)**: Sole entity for wastewater collection, treatment, and reuse.
- **DMT (Department of Municipalities and Transport)**: Oversees stormwater and sub-soil drainage.
- **ADDC / AADC**: Manage potable water distribution.

### Approval Sequence (Typical)
1. **Information NOC**: Preliminary check of existing services and master plan alignment.
2. **Design NOC**: Detailed design review (hydraulic models, drawings, calculations).
3. **Construction NOC**: Permit to commence site works, often requiring RTA coordination for road crossings.
4. **Connection NOC**: Final approval to link the internal network to the public grid.
> "The process applies to Ma’alem Dubai water application after registration... Forward Project with comments to EW... Issuance of Master Plan Approval Letter." — DEWA [[8]](#ref8)

## 3. Core Codes and Standards
- **Dubai Building Code (DBC) 2021**: Part G (Utilities) covers internal and plot-level water and drainage.
- **DM Sewerage & Drainage Design Criteria**: The primary manual for Dubai infrastructure (DS-185).
- **ADSSC/SWS Design Guidelines**: Sections 1-10 cover sewerage, recycled water, and standard drawings.
- **WA-726-1 (Abu Dhabi)**: DMT Stormwater & Subsoil Drainage Systems Design Manual (2020).
- **International Standards**: BS EN 752 (Drainage), ACI 350 (Environmental Structures), NFPA 24 (Fire Water), and ISO standards for pipe materials.

## 4. Technical Design Content

### Sewerage Design Parameters
- **Peak Factor (Dubai)**: Often calculated as $DPF = 4.25 \times P^{-0.1}$ (where P is population in thousands).
- **Flow Velocity**: Minimum self-cleansing velocity of 0.75 m/s; maximum 3.0 m/s to prevent erosion.
- **Manning’s n**: 0.013 for plastic pipes (uPVC, GRP, HDPE); 0.015 for concrete.
- **Pipe Materials**: GRP (Glass Reinforced Plastic) for large diameters; uPVC for smaller gravity sewers; DI (Ductile Iron) for pressure mains.

### Stormwater Design Parameters
- **Return Periods**:
    - **Minor System**: 5–10 years (preventing nuisance flooding).
    - **Major System**: 50–100 years (protecting life and property).
- **Rainfall Intensity**: Intense storms can exceed 100mm/hour despite low annual averages (~94mm).
- **Methodology**: Rational Method ($Q = CIA/360$) for catchments < 200 ha; Hydrograph methods for larger areas.
> "The DM Stormwater Guidelines (2025 edition) adopt an integrated urban drainage approach that combines minor system drainage (return period 10 years) with major system flood routing (return period 50–100 years)." — DM Stormwater Management [[9]](#ref9)

### Potable Water Design
- **Consumption Rates**: 200–300 L/capita/day for hotel guests; 60–100 L/capita/day for commercial users.
- **Fire Flow**: Minimum 500 gpm for residential; 1,000 gpm for others, at 20 psi residual pressure.
- **Storage**: Customers must provide 24 hours of average demand storage on-site.
> "DEWA’s water transmission system consists of pipelines with diameters ranging from 600 mm to 1200 mm... Approved pipe materials: Glass fibre Reinforced Epoxy (GRE) PN10." — Potable Water Network Design Criteria [[10]](#ref10)

## 5. Construction, Testing, and Commissioning
- **Hydrostatic Testing**: Water mains tested at 1.5x working pressure for 24 hours.
- **CCTV Inspection**: Mandatory for all new sewerage and drainage lines to check for debris, sags, or joint failures before handover.
- **Disinfection**: Potable lines must be chlorinated and flushed; water quality samples must pass lab tests (TBC/E.coli).
- **Infiltration/Exfiltration**: Gravity sewers tested using air or water to ensure watertightness.

## 6. UAE Climate, Durability, and Sustainability
- **Corrosion Control**: High soil salinity and sulfate levels require GRP/HDPE or DI with polyethylene sleeving and cathodic protection.
- **Flood Resilience**: Increasing focus on Sustainable Urban Drainage Systems (SuDS) like soakaways and permeable paving to manage runoff.
- **TSE Quality**: Maximum BOD limits for irrigation: 10 mg/L (unrestricted) to 30 mg/L (restricted).
> "According to the UAE Municipality standards the maximum limit for BOD in restricted irrigation water is 30 mg/L, and for unrestricted irrigation it is 10 mg/L." — Almasa Environmental [[11]](#ref11)

## 7. Professional Practice and Checklists
- **Utilities Coordination**: Essential to maintain minimum clearances (typically 300mm vertical, 1000mm horizontal) between wet and dry utilities.
- **Design Review Checklist**:
    - [ ] Hydraulic model results within velocity/pressure limits.
    - [ ] Manhole spacing (max 50-100m depending on diameter).
    - [ ] Cover depth (min 1.2m in roads).
    - [ ] Air valves and washouts at high/low points of pressure mains.

## 8. Gaps and Verification Notes
- **Gaps**: Specific 2024/2025 fee schedules for NOCs are often updated via circulars and may not be in the main manuals.
- **Verification**: Confirm the latest "Tasreef" project discharge limits with DM for specific catchments in Dubai.
- **Conflicts**: Minor differences exist between DM and ADSSC regarding Manning's n values for specific pipe linings; always use the local authority's preferred value.

## Sources
- **DEWA**: Water Transmission Planning Guidelines (2023) [[8]](#ref8)
- **Dubai Municipality**: Sewerage and Drainage Guidelines (2025 Draft/Circulars) [[12]](#ref12)
- **SWS Holding (Abu Dhabi)**: Sewerage System Design Guidelines [[13]](#ref13)
- **DMT Abu Dhabi**: WA-726-1 Stormwater Design Manual [[14]](#ref14)
- **Dubai Building Code**: 2021 Edition [[3]](#ref3)

**Checklist Status**: All items marked [Y] in `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/1c0c3f03/RESEARCH_CHECKLIST.md`.

---


## 3. Key Design Formulas and Criteria

| Parameter | Value | Source / Authority |
| --- | --- | --- |
| Road design speed | Arterial: 80–120 km/h; Collector: 60–80 km/h; Local: 30–50 km/h | RTA Road Design Manual / Abu Dhabi USDM |
| Standard lane width | 3.65 m arterial; 3.5 m collector; 3.0–3.5 m local | RTA / USDM |
| Parking bay | 2.5 m × 5.5 m standard; 3.6 m wide disabled bay | DM / DMT |
| Drainage return period | 1:10 yr minor roads; 1:25–50 yr major highways/tunnels | IDF curve per emirate |
| Bitumen penetration | 60/70 or 40/50 grade for high-temperature stability | DM roads specification |
| Compaction (asphalt) | Minimum 97% Marshall density | DM / DMT QA requirement |
| Water demand (residential) | 250–350 L/capita/day (DEWA reference)[[8]](#ref8) | DEWA Water Planning Guidelines |
| Sewerage flow (Abu Dhabi) | High-rise: 210 L/Head/Day; peaking factor per Babbitt formula | ADSSC Design Guidelines Section 3 [[15]](#ref15) |
| Min water pressure | 1.0 Bar internal; 1.5 Bar at connection point | DEWA supply standard |
| Manhole spacing | 20 m building connections; up to 100 m trunk sewer | ADSSC / DM standard |


## 4. Authority Submission Matrix — Infrastructure Projects

| Submission type | Responsible authority | Key trigger / requirement |
| --- | --- | --- |
| Traffic Impact Study | RTA (Dubai) / ITC-DMT (Abu Dhabi) | ≥100 vehicle trips/peak hour for Dubai; tiered CP/TIS/TMP for Abu Dhabi |
| Road Access/ROW Permit | RTA eNOC portal | All physical works within Dubai ROW; reinstatement bond required |
| Water Demand Approval | DEWA (Dubai) via Ma'alem Portal | Master plan and demand calculations; 24-hour storage mandatory |
| Design + Construction NOC | DM/DMT + DEWA/ADDC + RTA | Multi-agency coordination for infrastructure corridors |
| Sewer/Drainage Connection | DM (Dubai) / Abu Dhabi SWS | Inspection stages: underground first-fix, pressure test, final |


## 5. Professional Checklist — Infrastructure Design Package

### Roads and infrastructure design package checklist

1. **Traffic study** — Calibrate base model, confirm peak hour volumes, check LOS, model development scenarios, and address mitigation measures.
2. **Geometric design** — Horizontal and vertical alignment, sight distance, super-elevation, drainage cross-falls, pavement structure, kerb radii, and access visibility splays.
3. **Pavement design** — CBR-based pavement structure, bitumen grade selection, surface course mix design for UAE temperatures.
4. **Drainage design** — IDF curve selection, catchment delineation, rational method or computer model, pipe sizing, inspection chamber schedule, and outfall arrangement.
5. **Water network** — Demand calculation, hydraulic model, pipe material (HDPE/DI), pressure zones, storage sizing, fire-flow reserve, and valve/meter schedule.
6. **Sewer network** — Population/flow projection, gravity pipe sizing, manhole schedule, pump station head calculations, pipe material selection, and test requirements.


## Expert Appendix: Field Control, Design Review, and Authority Coordination Templates

### Template A: Design Review Checklist Framework
A senior engineering design review should confirm: design basis and load assumptions are documented; code edition and amendment dates are stated; all UAE authority requirements have been addressed by reference; specialist sub-consultant inputs are incorporated and coordinated; sustainability compliance (Al Sa'fat or Estidama as applicable) is addressed; fire and life safety interfaces are resolved; and the drawing set matches calculations and specifications. Any deviation from code requires a written technical justification.

### Template B: Authority Submission Package
Before submitting to any UAE authority, confirm: the submitting consultant firm holds a valid practising card/approval for the project emirate; drawings are in the required format and coordinate system; all NOCs from upstream authorities are attached; calculations are signed by a registered engineer; the BIM model (if mandated under DM Circular 9-1-3/2026 or Abu Dhabi DMT requirements) is attached in the required format; and fees or bonds have been paid. Incomplete packages are returned without review in most Dubai and Abu Dhabi portals.

### Template C: Site Supervision and Inspection Record
For each Witness or Hold point on the ITP, the site supervisor should confirm: the work activity matches the approved shop drawing; material has a valid test certificate or Material Approval Request (MAR); pre-activity conditions (compaction, formwork, earthing, cleanliness) are met; work execution matches approved method statement; post-activity tests are conducted and recorded; Non-Conformance Reports are raised immediately for failures; and the record is signed, dated, and uploaded to the document management system.

### Template D: Commissioning and Handover Record
The commissioning package should include: signed Commissioning Manager appointment; pre-commissioning mechanical completion certificates; equipment startup records with measured versus specified values; functional test sheets for all systems; cause-and-effect matrix testing records for life-safety interfaces; Training records for the building operator; Operating and Maintenance manuals with as-built BIM model; and a Defect Tracking Register. In Dubai, DEWA/DCD and DM will conduct their own independent inspections before issuing the Completion Certificate.

### Template E: Professional Risk Register for UAE Engineering Projects
Key project risks to track: BIM submission readiness; NOC expiry dates and renewal sequences; Specialist material lead times (high-performance concrete, specialist glazing, medical gas equipment); Third-party inspection availability; Civil Defense comments on fire systems; Authority variations discovered late in design; Structural peer review findings; Geotechnical report limitations; Weather restrictions on concrete pours; Power supply sequencing for DEWA connection; District Cooling provider connection timing; and Snagging management strategy for Completion Certificate.

## Deep Practice Appendix: UAE Engineering Field Reference Library

### A. Concrete pour control in UAE climate
Fresh concrete must not exceed 32°C at the time of pouring per Dubai Municipality requirements. Practical controls include: scheduling pours at night or early morning during summer; pre-cooling aggregates and water; using liquid nitrogen injection for very large pours; covering trucks and placing time limits from batching plant to pour; using ice as part of mix water; insulating formwork if mass concrete; and monitoring temperature with embedded thermocouples for pours exceeding 500 mm thickness where heat-of-hydration crack risk exists.

### B. UAE wind loading practice for tall buildings
The Dubai Building Code 2021 references ASCE 7-16 for wind design. For buildings exceeding 120 m height or irregular floor plates, a specialist wind tunnel study is mandatory. The study typically includes: mean wind speed profile; turbulence intensity profile; pressure distribution across facade panels and corners; base shear and overturning moment for structural frame; floor acceleration for occupant comfort under dynamic wind; and glass/cladding pressure coefficients. Wind consultants use a Boundary Layer Wind Tunnel (BLWT) and provide client-specific pressure maps that override ASCE 7 simplified charts.

### C. UAE fire safety critical defect list
Before Civil Defense final inspection, teams should resolve: non-rated compartmentation penetrations (every hole in a fire wall must be fire-stopped to FM 4991 or UL-listed system); sprinkler heads within 450 mm of a luminaire; missing fire-rated ductwork collars; staircase pressurisation system functional test incomplete; fire pump power supply not on dedicated circuit; fire alarm panel not in approved location; exit sign luminance below code minimum; door-closer adjustment needed on fire doors; emergency lighting duration below 3-hour requirement; and missing fire-rated access panels for active system valves.

### D. DEWA final inspection readiness checklist
Before requesting DEWA final inspection for electricity connection: all MDB/SMDB/DB boards installed, labeled, and secured; all cable connections terminated and insulation resistance tested; earth electrode installed, measured, and result ≤1 ohm; all circuits identified, protected, and balanced within 10% between phases; emergency power circuits segregated and labeled; RCDs tested; cable trunking/trays fully supported and bonded; substation ventilation confirmed; and as-built single line diagram reflects installed equipment.

### E. Geotechnical risk register for UAE projects
Common geotechnical risks in UAE: (1) Sabkha — expansive salt-rich soils that lose bearing capacity when wetted; mitigate by removal and replacement or ground improvement; (2) Gypsiferous soils — dissolution creates voids under foundations; test sulfate content and use sulfate-resistant cement; (3) Loose sand over the water table — liquefaction risk in seismic events; assess and improve if Vs30 < 180 m/s; (4) High groundwater — dewatering impacts on adjacent structures; pre-construction settlement monitoring required; (5) Coral limestone (caprock) — variable quality; carry out borehole core quality designation (RQD) and end-bearing verification for piles; (6) Contaminated land — former industrial or oil storage sites; Phase 1 and Phase 2 assessment before construction.

### F. UAE project documentation matrix
For all UAE engineering projects, the following documentation set should be maintained: Design Brief + Basis of Design memo; Approved shop drawings register; Material Approval Request (MAR) log; Inspection and Test Plan (ITP) with sign-off sheets; Non-Conformance Report (NCR) register; Request for Information (RFI) log; Authority submission log with NOC expiry tracking; As-built drawing issue record; Commissioning test sheets; O&M manual receipt confirmation; and Training attendance records. Completeness of this set is assessed during the Completion Certificate audit.


## Extended Technical Reference: Roads, Pavement, and Infrastructure

### Pavement Structural Design
UAE road pavement design follows a mechanistic-empirical approach with UAE-specific traffic and climate adjustments:
- **Subgrade CBR:** Minimum 15% for local roads, 30% for arterials. Subgrade improvement (lime or cement stabilisation) is common in coastal areas with low-CBR sabkha or fill material.
- **Pavement structure (typical arterial):** 60 mm AC wearing course + 60 mm AC binder course + 150 mm AC base course + 200 mm granular sub-base + 300 mm selected fill/subgrade improvement.
- **Rutting resistance:** Modified bitumen (SBS polymer-modified) is commonly specified for heavily trafficked areas, roundabout approaches, bus lanes, and areas prone to standing water.
- **Reflective cracking:** Geosynthetic interlayer (e.g., paving fabric or grid) specified over existing cracked pavement where milling is not practical.
- **Surface temperature:** UAE road surface temperatures exceed 60°C in summer; Marshall stability test at 60°C is the QC benchmark.

### Traffic Impact Study (TIS) Methodology
RTA Dubai and ITC Abu Dhabi require TIS studies following a structured process:
1. **Trip generation:** ITE Trip Generation Manual (latest edition) or local calibrated rates; categories include residential, retail, office, hotel, and mixed-use.
2. **Trip distribution:** Gravity model or manual assignment based on local road hierarchy.
3. **Traffic assignment:** Balanced assignment to surrounding network intersections.
4. **Level of Service (LOS):** HCM (Highway Capacity Manual) methodology; LOS D is maximum acceptable for most Dubai/Abu Dhabi intersections; LOS E/F triggers mitigation.
5. **Mitigation measures:** Additional lanes, signal timing changes, access consolidation, roundabout conversion, or new roads; cost responsibility confirmed with authority.

### Stormwater Design — UAE Specific Challenges
UAE rainfall is infrequent but high-intensity (convective storms, 30–80 mm/hour in extreme events). Design guidance:
- **Minor system (1:10 year):** Kerb and channel + underground pipes; pipe sized using Manning's equation with n = 0.013 for concrete pipes.
- **Major system (1:50 to 1:100 year):** Roads function as overland flow channels; check freeboard to building entry thresholds; tunnels and underpasses require full 1:100 year plus climate-change uplift.
- **SUDS:** Sustainable Urban Drainage Systems (bioswales, permeable paving, retention basins) are encouraged under Estidama and newer Abu Dhabi guidelines; applicable to large master-planned communities.
- **Inlet design:** UAE desert dust blocks conventional inlet grates; specify self-cleaning inlet types with large open areas; include silt traps upstream of networks.


## Extended Reference: Water and Sewer Network Design

### Sewer Network Hydraulic Design
Key hydraulic parameters for gravity sewer design in UAE per ADSSC / Abu Dhabi SWS and Dubai Municipality:
- **Minimum self-cleansing velocity:** 0.75 m/s at peak dry weather flow to prevent sedimentation.
- **Maximum pipe velocity:** 3.0 m/s to prevent erosion of GRP/HDPE pipe internal surface.
- **Minimum pipe diameter:** 200 mm for public gravity sewers; 150 mm for private connections.
- **Manning n values:** 0.011 for GRP/HDPE; 0.013 for concrete; 0.015 for VC/clay.
- **Minimum cover:** 1.0 m to crown under roads; 0.6 m under landscaping and non-traffic areas.
- **Maximum depth before pumping:** 6–8 m economic depth for gravity sewers; below this, pumping stations more economic.
- **Babbitt peaking factor formula:** PF = 18 / (4 + √P) where P = population in thousands; used for populations under 500,000.
- **Diurnal variation:** Peak flow typically 2.5–3.0 × average dry weather flow for residential areas.

### Water Network Design — Hydraulic Model Calibration
DEWA and ADDC require hydraulic models to be calibrated before new connections are approved:
- **Calibration targets:** Flow accuracy ±5% for trunk mains; pressure accuracy ±0.5 bar at calibration nodes.
- **Model software:** WaterGEMS, EPANET, or equivalent; steady-state and extended-period simulation required.
- **Fire flow analysis:** Fire demand superimposed on peak hourly flow; minimum residual pressure 1.0 bar at hydrant location during combined demand.
- **Water age:** Maximum 3 days water age in the distribution network to maintain disinfectant residual; dead-end flushing programme required where age exceeds limit.

### Pumping Station Design Criteria
For sewage and water pumping stations:
- **Wet well sizing:** 10–15 minutes detention time at peak flow; minimum 3 minutes above pump-off level.
- **Pump selection:** Duty + standby arrangement as minimum; duty + duty + standby for stations serving >200 units.
- **Rising main velocity:** 0.9–3.0 m/s; minimum 0.9 m/s to prevent solids deposition; maximum 3.0 m/s to limit water hammer.
- **Water hammer analysis:** Required for rising mains longer than 100 m or with significant elevation changes; air valves, surge vessels, or slow-closing valves used for mitigation.
- **Emergency storage:** Minimum 2-hour storage capacity in wet well for stations without backup generator; 4-hour preferred for trunk stations.
- **Generator:** Automatic start standby generator required for all pumping stations; changeover time ≤30 seconds.

### Environmental Impact Assessment (EIA) — Infrastructure Projects
UAE infrastructure EIA follows a structured process per EAD (Abu Dhabi) or DM/MOCCAE (Dubai/Federal):
1. **Screening/scoping:** Determine if full EIA is required; identify key environmental receptors (air, noise, water, ecology, cultural heritage, traffic).
2. **Baseline surveys:** Ambient air quality, noise levels, groundwater, soil contamination, ecological surveys (flora, fauna, protected species); survey period minimum 1 seasonal cycle for ecological work.
3. **Impact prediction:** Quantitative modelling for air dispersion (Gaussian plume), noise (ISO 9613), groundwater drawdown (analytical or numerical), and traffic generation.
4. **Mitigation measures:** Design-in measures preferred (e.g., route alignment to avoid sensitive receptors) over end-of-pipe controls (barriers, filters).
5. **Environmental Management Plan (EMP):** Construction phase EMP (CEMP) and operational phase EMP submitted with EIA.
6. **Monitoring programme:** Agreed performance indicators, monitoring frequency, and reporting to authority during construction and first year of operation.

### UAE Authority Fee Reference (Roads — Approximate)
| Service | Authority | Approximate fee |
|---|---|---|
| Traffic circulation plan (<100 trips/hr) | ITC Abu Dhabi | AED 1,000 |
| Traffic impact study (100–2,500 trips/hr) | ITC Abu Dhabi | AED 12,500 + AED 1/trip |
| Transport master plan (>2,500 trips/hr) | ITC Abu Dhabi | Project-specific |
| Missing parking space charge | ITC Abu Dhabi | AED 50,000/space |
| ROW permit (road cutting) | RTA Dubai | Bond-based; reinstated to original standard |


## Professional Quick Reference: Common UAE Engineering Thresholds

| Parameter | Value | Authority/Source |
|---|---|---|
| BIM mandate threshold (Dubai) | G+12 or ≥15,000 m² BUA | DM Circular 9-1-3/2026 |
| Boreholes for high-rise (Dubai) | Min 5; 1 per 750 m² | Admin Resolution 37/2021 |
| Max shoring lateral displacement (Trakhees) | 40 mm | Trakhees Grey Code |
| Wind tunnel test threshold | ≥120 m height or irregular plan | DBC 2021 |
| Max fresh concrete temperature at pour | 32°C | Dubai Municipality |
| Min concrete cover — foundations | 75 mm | DBC 2021 |
| Max w/c ratio — severe exposure | 0.40 | DBC 2021 / ACI 318 |
| DEWA earth electrode resistance | ≤1 Ohm | DEWA Regulations 2017 |
| Emergency lighting duration | 3 hours (180 min) | UAE Fire Code 2018 |
| Sprinkler smoke detector spacing | Max 9 m | UAE Fire Code |
| Fire lift mandatory above | 15 m occupied floor height | DBC Part D |
| Residential water demand | 250–350 L/capita/day | DEWA Water Planning Guidelines |
| Min self-cleansing sewer velocity | 0.75 m/s | ADSSC Design Guidelines |
| NFPA 285 cladding test | Required all combustible assemblies >2 storeys | UAE Civil Defense |
| Midday break period | 12:30–15:00, 15 Jun–15 Sep | MOHRE |
| Decennial liability period | 10 years post-completion | UAE Civil Code Article 880 |
| FIDIC EOT notice period | 28 days from triggering event | FIDIC Red Book Sub-Clause 20.1 |
| Traffic study threshold (Dubai RTA) | >100 vehicle trips/peak hour | RTA eNOC portal |
| Missing parking space fine (Abu Dhabi) | AED 50,000/space | ITC Abu Dhabi |
| Estidama mandatory minimum rating | 1 Pearl (government: 2 Pearls) | Abu Dhabi DMT |
| Al Sa'fat mandatory minimum rating | Silver Sa'fa | Dubai Municipality |
| ADNOC pressure vessel standard | AGES-SP-06-002 / ASME VIII | ADNOC Group Engineering Standards |
| Hazardous area cert UAE | ECAS-Ex Certificate required | MoIAT ECAS scheme |

## References

<p id="ref1" class="ref_item">[1] rta.ae <a target="_blank" rel="noreferrer" href="https://www.rta.ae/wps/portal/rta/ae/home/rta-services/service-details?serviceId=313">https://www.rta.ae/wps/portal/rta/ae/home/rta-services/service-details?serviceId=313</a></p>
<p id="ref2" class="ref_item">[2] admobility.gov.ae <a target="_blank" rel="noreferrer" href="https://admobility.gov.ae/-/media/project/dot/itc/files/e-library/tis--english.pdf">https://admobility.gov.ae/-/media/project/dot/itc/files/e-library/tis--english.pdf</a></p>
<p id="ref3" class="ref_item">[3] dda.gov.ae <a target="_blank" rel="noreferrer" href="https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf">https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf</a></p>
<p id="ref4" class="ref_item">[4] dda.gov.ae <a target="_blank" rel="noreferrer" href="https://dda.gov.ae/-/media/4A63A5118AA14A5DA26EB17B2CBD0EF5.pdf">https://dda.gov.ae/-/media/4A63A5118AA14A5DA26EB17B2CBD0EF5.pdf</a></p>
<p id="ref5" class="ref_item">[5] vtpi.org <a target="_blank" rel="noreferrer" href="https://vtpi.org/Abu_Daubi_Street_Design_Manual.pdf">https://vtpi.org/Abu_Daubi_Street_Design_Manual.pdf</a></p>
<p id="ref6" class="ref_item">[6] scribd.com <a target="_blank" rel="noreferrer" href="https://www.scribd.com/document/645724343/Road-Safety-Audit-Manual">https://www.scribd.com/document/645724343/Road-Safety-Audit-Manual</a></p>
<p id="ref7" class="ref_item">[7] en.wikipedia.org <a target="_blank" rel="noreferrer" href="https://en.wikipedia.org/wiki/Road_signs_in_the_United_Arab_Emirates">https://en.wikipedia.org/wiki/Road_signs_in_the_United_Arab_Emirates</a></p>
<p id="ref8" class="ref_item">[8] dewa.gov.ae <a target="_blank" rel="noreferrer" href="https://dewa.gov.ae/-/media/WT-Planning-Guidelines-for-Dev-Proj--Update-2023.ashx">https://dewa.gov.ae/-/media/WT-Planning-Guidelines-for-Dev-Proj--Update-2023.ashx</a></p>
<p id="ref9" class="ref_item">[9] scribd.com <a target="_blank" rel="noreferrer" href="https://www.scribd.com/document/1042391578/DM-Stormwater-Management">https://www.scribd.com/document/1042391578/DM-Stormwater-Management</a></p>
<p id="ref10" class="ref_item">[10] scribd.com <a target="_blank" rel="noreferrer" href="https://www.scribd.com/document/769058881/Potable-Water-Network-Design-Criteria">https://www.scribd.com/document/769058881/Potable-Water-Network-Design-Criteria</a></p>
<p id="ref11" class="ref_item">[11] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/pulse/understanding-bod-tse-water-standards-almasa-enviromental-ipm6f">https://www.linkedin.com/pulse/understanding-bod-tse-water-standards-almasa-enviromental-ipm6f</a></p>
<p id="ref12" class="ref_item">[12] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/wp-content/uploads/2025/01/comp-DM_Sewerage-Guidelines-F.24.01.25.pdf">https://www.dm.gov.ae/wp-content/uploads/2025/01/comp-DM_Sewerage-Guidelines-F.24.01.25.pdf</a></p>
<p id="ref13" class="ref_item">[13] kh.aquaenergyexpo.com <a target="_blank" rel="noreferrer" href="https://kh.aquaenergyexpo.com/wp-content/uploads/2022/10/Abu-Dhabi-Sewerage-System-Design-Guideline.pdf">https://kh.aquaenergyexpo.com/wp-content/uploads/2022/10/Abu-Dhabi-Sewerage-System-Design-Guideline.pdf</a></p>
<p id="ref14" class="ref_item">[14] scribd.com <a target="_blank" rel="noreferrer" href="https://www.scribd.com/document/709472227/WA-726-1">https://www.scribd.com/document/709472227/WA-726-1</a></p>
<p id="ref15" class="ref_item">[15] daemuae.com <a target="_blank" rel="noreferrer" href="https://daemuae.com/daem-constructions/dcd-vs-dm-noc-in-dubai-whats-the-difference/">https://daemuae.com/daem-constructions/dcd-vs-dm-noc-in-dubai-whats-the-difference/</a></p>
