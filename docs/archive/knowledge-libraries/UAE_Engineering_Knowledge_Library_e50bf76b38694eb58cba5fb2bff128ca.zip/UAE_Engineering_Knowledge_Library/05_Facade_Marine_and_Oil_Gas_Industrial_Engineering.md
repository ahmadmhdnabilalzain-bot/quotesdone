# Facade Engineering, Marine and Coastal Engineering, and Oil, Gas and Industrial Process Engineering in the UAE

This chapter covers three specialist engineering domains critical to the UAE built environment: building facade and envelope engineering, marine and coastal infrastructure, and oil, gas and industrial process engineering. [[1]](#ref1)

## 1. Facade, Building Envelope, and Architectural Engineering

# Source Packet 1: Facade, building envelope and architectural engineering: cladding, glazing, thermal performance, waterproofing, fire spread, wind, maintenance and UAE climate risks

**Research topic:** Facade, building envelope and architectural engineering: cladding, glazing, thermal performance, waterproofing, fire spread, wind, maintenance and UAE climate risks

**Report title:** Facade, Building Envelope, and Architectural Engineering in the UAE

# Facade, Building Envelope, and Architectural Engineering in the UAE

This document provides a comprehensive overview of facade engineering and building envelope design within the United Arab Emirates (UAE), focusing on regulatory requirements, technical standards, and climate-specific considerations as of July 2026.

## Domain Scope
Facade engineering in the UAE encompasses the design, analysis, and construction of the building envelope, which serves as the primary barrier between the interior environment and the extreme Middle Eastern climate. The domain includes:
*   **Cladding Systems:** Aluminum Composite Panels (ACP), Natural Stone, Glass Fiber Reinforced Concrete (GFRC), and High-Pressure Laminates (HPL).
*   **Glazing and Fenestration:** Curtain wall systems (stick and unitized), skylights, and window-wall assemblies.
*   **Thermal Performance:** Management of heat gain through high-performance insulation and solar control coatings.
*   **Building Physics:** Air tightness, vapor control, and acoustic performance.
*   **Structural Integrity:** Resistance to high wind loads and seismic activity.
*   **Fire Safety:** Prevention of vertical and horizontal fire spread through non-combustible materials and cavity barriers.
*   **Maintenance:** Integration of Building Maintenance Units (BMU) for cleaning and repair.

Typical projects range from low-rise residential villas to iconic super-tall skyscrapers like the Burj Khalifa, each requiring specific engineering strategies to manage the UAE's unique environmental stressors.

## UAE Authorities and Approval Workflow
The approval process for facades is multi-tiered, involving both municipal and federal authorities to ensure structural safety, energy efficiency, and fire protection.

### Key Authorities
*   **Dubai Municipality (DM):** Oversees building permits, structural design, and sustainability compliance (Al Sa'fat) in Dubai.
*   **Abu Dhabi Department of Municipalities and Transport (DMT) / Abu Dhabi City Municipality (ADM):** Regulates building codes and Estidama compliance in the capital.
*   **UAE Civil Defense (DCD):** Federal authority responsible for fire and life safety approvals, specifically cladding material certification and fire-stop designs.
*   **Trakhees (PCFC):** Authority for free zones and special development zones in Dubai (e.g., JAFZA, DP World).
*   **Dubai South / Dubai Development Authority (DDA):** Specific jurisdictions with their own planning and design guidelines.

### Approval Sequence
1.  **Initial Design / Concept NOC:** Submission of facade concepts to the relevant municipality for planning approval.
2.  **Civil Defense (DCD) Preliminary Approval:** Review of cladding materials, fire-rated assemblies, and emergency access.
    > "A DCD NOC is required both during the design review stage for fire and life safety approval and again at project completion (civil defence certificate) before occupancy-related clearances can be obtained." — DCD vs DM NOC in Dubai [[2]](#ref2)
3.  **Structural and Thermal Submission:** Detailed calculations for wind loads and U-values submitted to DM/ADM.
4.  **Building Permit:** Issued by the Municipality after all NOCs (including DCD) are secured.
5.  **Material Submittal & Mock-up Approval:** On-site or laboratory testing of facade mock-ups (CWCT/ASTM) before mass production.
6.  **Final Inspection & Completion Certificate:** Conducted by DCD and the Municipality to verify as-built compliance.

## Core Codes and Standards
Facade design in the UAE is governed by a mix of local regulations and international standards.

### Local Regulations
*   **Dubai Building Code (DBC) 2021:** The unified code for all building design in Dubai, replacing previous circulars.
*   **UAE Fire and Life Safety Code of Practice (2018/Updated):** The definitive guide for cladding fire performance and material testing.
*   **Al Sa'fat – Dubai Green Building System:** Mandatory sustainability requirements for all new buildings in Dubai.
*   **Abu Dhabi International Building Code (ADIBC):** Based on the International Building Code (IBC), tailored for Abu Dhabi.
*   **Estidama Pearl Rating System:** Abu Dhabi's mandatory sustainability framework.

### International Standards
*   **ASTM (American Society for Testing and Materials):** Used for material properties and water/air leakage testing (e.g., ASTM E283, E331).
*   **NFPA 285:** Standard Fire Test Method for Evaluation of Fire Propagation Characteristics of Exterior Wall Assemblies.
*   **CWCT (Centre for Window and Cladding Technology):** UK-based standards frequently used for curtain wall testing in the UAE.
*   **BS/EN Standards:** British and European standards for structural glass (BS EN 12150) and aluminum (BS EN 755).

## Technical Design Content
### Thermal Performance Requirements
The UAE's extreme heat necessitates strict thermal transmittance (U-value) and Solar Heat Gain Coefficient (SHGC) limits.

| Element | Dubai (Al Sa'fat Silver) | Abu Dhabi (Estidama) |
| :--- | :--- | :--- |
| **Exterior Walls** | Max 0.57 W/m²K | Max 0.32 W/m²K |
| **Roof** | Max 0.30 W/m²K | Max 0.14 - 0.25 W/m²K |
| **Glazing (U-value)** | Max 2.0 W/m²K | Max 1.7 - 1.9 W/m²K |
| **Glazing (SHGC)** | Max 0.25 | Max 0.22 - 0.25 |

> "Roof/ceiling: maximum U-value of 0.30 W/m²K; Glazing: maximum U-value of 2.0 W/m²K; Solar Heat Gain Coefficient (SHGC) maximum 0.25" — Al Sa'fat 2.0 Dubai 2026 [[3]](#ref3)

### Wind Engineering
Wind loads are a critical design factor due to the height of UAE structures and the potential for sandstorms.
*   **Minimum Design Pressure:** 1.0 kN/m² for all buildings and steel structures (Administrative Resolution No. 37 of 2021).
*   **Wind Tunnel Testing Threshold:** 
    *   Mandatory for buildings with a height of **120 meters** or more.
    *   Mandatory for **irregularly shaped buildings** (curves, sharp edges) regardless of height.
    > "Wind loads will be calculated based on the wind tunnel model for Buildings with a height of one hundred and twenty (120) metres above ground level for regular shaped Buildings." — Administrative Resolution No. (37) of 2021, )%20of%202021%20Amending%20the%20Bylaw%20Concerning.pdf [[4]](#ref4)

### Air Tightness
*   **Infiltration Limit:** Must not exceed **5 m³/h/m²** at a pressure difference of 50 Pascals (Pa) under Al Sa'fat.
    > "Infiltration/exfiltration should not exceed 5 m³/h/m² at a pressure difference of 50 Pascals (Pa)." — Al Sa'fat: Dubai's green building rating system [[5]](#ref5)

## Construction Supervision, Testing, and Commissioning
### Fire Testing (NFPA 285)
The UAE Fire Code mandates that entire wall assemblies (not just individual components) must pass the NFPA 285 test to ensure fire does not spread vertically through the cladding.
*   **Pass Criteria:** Flames must not occur in the second-story test room or beyond the intersection of the test wall and sidewalls.
*   **Material Certification:** All cladding materials must be listed in the DCD approved materials directory.

### Performance Mock-Up (PMU) Testing
For large-scale projects, a full-scale mock-up is tested in a laboratory for:
*   **Air Infiltration (ASTM E283):** Measuring air leakage through the system.
*   **Static Water Penetration (ASTM E331):** Checking for leaks under constant pressure.
*   **Dynamic Water Penetration (AAMA 501.1):** Simulating wind-driven rain using an aircraft engine or large fan.
*   **Structural Performance (ASTM E330):** Verifying the system can withstand design wind pressures.

### Site Inspections
*   **Water Hose Testing (AAMA 501.2):** Conducted on-site to verify the installation of joints and gaskets.
*   **Pull-out Tests:** For facade anchors and fixings to ensure structural capacity in concrete or steel.

## UAE Climate, Durability, and Sustainability Notes
### Climate Risks
*   **Extreme Heat:** Ambient temperatures exceeding 50°C can cause significant thermal expansion in aluminum profiles (up to 2mm per meter).
*   **High Humidity & Corrosion:** Coastal locations (e.g., Dubai Marina, Abu Dhabi Corniche) require high-grade anodizing or PVDF coatings (Class 2 or 3) to prevent salt-spray corrosion.
*   **Sand and Dust:** Fine sand particles can abrade glass surfaces and clog drainage channels in curtain walls. Self-cleaning coatings or frequent maintenance cycles are required.
*   **UV Degradation:** Intense solar radiation can degrade sealants and gaskets, leading to premature failure of the building envelope's air and water seals.

### Sustainability (Al Sa'fat & Estidama)
*   **Thermal Bridging:** Designers must use thermal breaks in aluminum frames and intermittent brackets for cladding to minimize heat transfer.
*   **Reflectivity:** Glazing must balance high light transmission with low solar heat gain to reduce cooling loads while maintaining occupant comfort.

## Professional Practice and Checklists
### Design Review Checklist
*   [ ] Verify U-values and SHGC against Al Sa'fat/Estidama requirements.
*   [ ] Ensure all cladding materials have valid DCD certificates.
*   [ ] Check for continuous thermal insulation and minimal thermal bridging at slab edges.
*   [ ] Confirm wind tunnel report recommendations are integrated into the structural design.
*   [ ] Review BMU access and reach for all facade areas.

### Common Mistakes
*   **Inadequate Fire Stopping:** Failing to install cavity barriers at every floor level and around openings.
*   **Ignoring Thermal Expansion:** Not providing sufficient expansion joints in long runs of cladding or curtain wall.
*   **Poor Drainage Design:** Blocked or undersized weep holes leading to water accumulation inside the system.
*   **Material Incompatibility:** Using dissimilar metals (e.g., aluminum and galvanized steel) without isolation, leading to galvanic corrosion.

## Gaps and Verification Notes
*   **Al Sa'fat 2.0 Specifics:** While general U-values are known, specific 2026 updates to the "Platinum" rating requirements should be verified with the latest DM circulars.
*   **Seismic Requirements:** Facade seismic drift requirements vary by Emirate and building height; specific local amendments to ASCE 7 should be checked.
*   **Paywalled Standards:** Full text of CWCT and certain ASTM standards require purchase for exact testing protocols.

## Sources
*   **Dubai Building Code (DBC) 2021 [[6]](#ref6)
*   **Dubai Municipality - Al Sa'fat [[7]](#ref7)
*   **Administrative Resolution No. (37) of 2021 (Wind Loads):** )%20of%202021%20Amending%20the%20Bylaw%20Concerning.pdf [[4]](#ref4)
*   **UAE Fire and Life Safety Code of Practice [[8]](#ref8)
*   **Abu Dhabi Department of Municipalities and Transport (DMT) [[9]](#ref9)
*   **NFPA 285 Testing Standards [[10]](#ref10)
*   **Al Sa'fat 2.0 Compliance Guide [[3]](#ref3)

---


## 2. Marine, Coastal, and Offshore Engineering

# Source Packet 18: Marine, coastal and offshore engineering in the UAE: ports, seawalls, dredging, corrosion, coastal processes, offshore structures and approvals

**Research topic:** Marine, coastal and offshore engineering in the UAE: ports, seawalls, dredging, corrosion, coastal processes, offshore structures and approvals

**Report title:** Marine, Coastal and Offshore Engineering in the UAE

# Marine, Coastal and Offshore Engineering in the UAE

## Domain Scope
Marine, coastal, and offshore engineering in the UAE is a critical discipline driven by the nation's extensive coastline (approx. 1,318 km) and its reliance on maritime trade, offshore energy, and coastal tourism. The domain encompasses the design and construction of ports (e.g., Jebel Ali, Khalifa Port), coastal protection structures (seawalls, breakwaters, revetments), dredging and land reclamation (e.g., Palm Jumeirah, World Islands), and offshore oil and gas infrastructure (jackets, platforms, subsea pipelines). Typical projects range from small-scale marina developments to massive offshore field expansions and artificial island creation.

## UAE Authorities and Approval Workflow
The approval process for marine works is emirate-specific and involves multiple layers of environmental and technical No Objection Certificates (NOCs).

### Dubai
*   **Dubai Municipality (DM) - Coastal Management Section:** Primary authority for coastal zone management. Projects require a "NOC for Major Coastal Structures or Construction Works," which involves a two-stage process: "Design Stage" (initial approval) and "Construction Stage." — *Build In Dubai [[11]](#ref11)
*   **Trakhees (PCFC):** Authority for projects within DP World, Nakheel, and Dubai South jurisdictions. Requires Marine NOCs for dredging, seawalls, and quay walls. Submission requirements include DM-approved survey station data and overall control point layouts. — *Trakhees [[12]](#ref12)

### Abu Dhabi
*   **Department of Municipalities and Transport (DMT) / Abu Dhabi Maritime:** The primary custodian of Abu Dhabi's waterways. It regulates maritime infrastructure through the "Abu Dhabi Guideline for Maritime Infrastructure." — *Abu Dhabi Maritime [[13]](#ref13)
*   **Environment Agency - Abu Dhabi (EAD):** Regulates the environmental impact of marine works, particularly dredging and reclamation. Requires an Environmental Impact Assessment (EIA) and a specific "Dredging and Reclamation Permit." — *EAD [[14]](#ref14)
*   **ADNOC:** For offshore energy projects, ADNOC acts as the primary regulator for its concessions, following internal standards such as AGES-SP-10-002 for offshore steel structures. — *ADNOC [[15]](#ref15)

## Core Codes and Standards
*   **Abu Dhabi Design Code for Maritime Infrastructure:** Sets minimum mandatory requirements for jetties, waterways, seawalls, and boat ramps. — *Abu Dhabi Maritime [[16]](#ref16)
*   **Dubai Coastal Zone Management Guidelines (TG-02):** Technical manual for infrastructure development in Dubai's coastal zones. — *Dubai Municipality [[17]](#ref17)
*   **UAE Fire and Life Safety Code of Practice:** Chapter 13 includes requirements for marine terminals and offshore structures, referencing NFPA 307. — *Abu Dhabi Civil Defence [[18]](#ref18)
*   **International Standards:** BS 6349 (Maritime Works), ISO 19900 (Offshore Structures), and API RP 2A (Fixed Offshore Platforms) are standard references in UAE practice.

## Technical Design Content
### Wave and Water Level Criteria
*   **Return Periods:** For permanent maritime structures in Abu Dhabi, a minimum return period equal to twice the design working life is typically required for wind and wave events. — *Abu Dhabi Maritime Design Code*
*   **Dubai Wave Data:** Extreme wave analysis for the Dubai coast indicates that the 100-year return period significant wave height ($H_s$) ranges from **4.10 to 4.84 meters**. — *MDPI Hydrology [[19]](#ref19)
*   **Water Levels:** Future sea-level rise projections for Jebel Ali (by 2058) estimate 1:100 return period water levels at **2.71 mCD**. — *Academic Journals [[20]](#ref20)

### Offshore Structures (ADNOC)
*   **Steel Grades:** Commonly uses S235, S275, and S355 carbon steel. Higher grades (S420/S460) require specific approval and fatigue life accounting.
*   **Fatigue Life:** Design must account for cyclic wave loading, particularly for jackets and piles. — *ADNOC AGES-SP-10-002*

## Construction Supervision, Testing, and Commissioning
*   **Dredging Monitoring:** Real-time turbidity monitoring is mandatory. For the Jebel Ali expansion, a threshold of **29 NTU** was specified at 1000m down current from the dredging location. — *VLIZ [[21]](#ref21)
*   **Silt Curtains:** Required to contain suspended solids. Design must account for water velocity to prevent "lifting" of the curtain. — *USACE/EPA Guidelines*
*   **Cathodic Protection:** Offshore structures utilize either sacrificial anodes (Aluminium/Zinc) or Impressed Current Cathodic Protection (ICCP). ICCP anodes typically have a design life of **15 years**. — *Evac/Cathelco [[22]](#ref22)

## UAE Climate, Durability, and Sustainability
*   **Corrosion:** Chloride-induced corrosion is the primary threat. Concrete mix designs for marine environments typically require **50% GGBS, 25% Fly Ash, or 8% Silica Fume** to enhance resistance. — *Abu Dhabi Maritime Design Code*
*   **Concrete Cover:** Minimum cover depths often exceed **75mm** for splash zone exposure to ensure a 50-year design life.
*   **Sustainability:** Projects must align with "Al Sa'fat" (Dubai) or "Estidama" (Abu Dhabi) requirements, focusing on minimizing impact on seagrass beds and coral reefs.

## Professional Practice and Checklists
*   **Design Review:** Senior engineers focus on "intent, constraints, and trade-offs" rather than just geometry. Key risks include missing underground utilities in bathymetric surveys and ignoring constructability (e.g., crane reach for offshore modules). — *LinkedIn/UGCE [[23]](#ref23)
*   **Risk Management:** Includes modeling of longshore sediment transport (typically SW to NE along the Dubai coast) to prevent unintended erosion or siltation at adjacent properties.

## Sources
*   **Abu Dhabi Maritime Design Code [[24]](#ref24)
*   **Dubai Municipality Environmental Guidelines [[25]](#ref25)
*   **ADNOC Offshore Steel Specification [[26]](#ref26)
*   **MDPI Extreme Wave Analysis (Dubai) [[27]](#ref27)
*   **UAE Fire and Life Safety Code [[28]](#ref28)

## Gaps and Verification Notes
*   **Fee Schedules:** Specific permit fees for marine works are often updated annually and require direct portal access for current values.
*   **Proprietary ADNOC Specs:** While AGES-SP-10-002 was accessed, more detailed sub-specifications (e.g., SP-1030 for design) are often restricted to registered contractors.
*   **Local Bathymetry:** Exact bathymetric data for specific plots is proprietary to the developer and authority (DM/DMT).

---


## 3. Oil, Gas, Industrial, and Process Engineering

# Source Packet 6: Oil, gas, industrial and process engineering in the UAE: ADNOC, hazardous areas, process safety, pressure vessels, piping, E&I, HAZOP and codes

**Research topic:** Oil, gas, industrial and process engineering in the UAE: ADNOC, hazardous areas, process safety, pressure vessels, piping, E&I, HAZOP and codes

**Report title:** Oil, Gas, Industrial and Process Engineering in the UAE

# Oil, Gas, Industrial and Process Engineering in the UAE

This report provides a comprehensive overview of the oil, gas, and industrial engineering landscape in the UAE, focusing on regulatory frameworks, technical standards, and UAE-specific design considerations as of July 2026.

## 1. Domain Scope and UAE Relevance
The oil, gas, and industrial engineering domain in the UAE is the backbone of the national economy, encompassing upstream (exploration and production), midstream (transportation and storage), and downstream (refining and petrochemicals) sectors.

*   **UAE Relevance**: The UAE holds approximately 10% of the world's proven oil reserves and the seventh-largest natural gas reserves. Engineering in this sector is critical for maintaining the UAE's position as a global energy leader and supporting the "Operation 300bn" strategy to increase the industrial sector's contribution to the GDP.
*   **Typical Projects**:
    *   Offshore and onshore oil/gas field developments (e.g., Hail and Ghasha sour gas projects).
    *   Refinery expansions and petrochemical complexes (e.g., Borouge).
    *   Industrial manufacturing plants in zones like KIZAD and ICAD.
    *   Extensive pipeline networks for domestic gas distribution and export.
*   **Boundaries**: This domain overlaps with civil (foundations/structures), MEP (utilities), and environmental engineering, but is distinguished by its focus on high-pressure systems, hazardous materials, and process safety.

## 2. UAE Authorities and Approval Workflow
Engineering projects in this sector must navigate a multi-tiered approval process involving federal and local entities.

### Key Authorities
*   **ADNOC (Abu Dhabi National Oil Company)**: The primary authority for oil and gas activities in Abu Dhabi. It sets the "ADNOC Group Engineering Standards" (AGES).
*   **SNOC (Sharjah National Oil Corporation)**: Custodian of Sharjah’s oil and gas assets. — SNOC [[29]](#ref29)
*   **ENOC (Emirates National Oil Company)**: Key player in Dubai’s downstream and retail sector.
*   **Ministry of Energy and Infrastructure (MOEI)**: Federal oversight of energy and industrial policies.
*   **UAE Civil Defense**: Mandatory approval for fire and life safety, particularly for hazardous material storage and process plants.
*   **Trakhees (PCFC)**: Authority for industrial building permits in Dubai’s free zones and special development zones. — Trakhees [[30]](#ref30)

### Approval Workflow (ADNOC Value Assurance Process - VAP)
ADNOC utilizes a "Value Assurance Process" (VAP) with five distinct stage gates to ensure project viability and risk management:
1.  **Gate 1: Concept Stage**: Evaluation of technical feasibility and initial risk quantification.
2.  **Gate 2: Definition Stage**: Evaluation of qualification requests and validation of technical feasibility.
3.  **Gate 3: Execution Readiness Stage**: Finalizing design and procurement plans before full sanction.
4.  **Gate 4: Execution Stage**: Construction and commissioning.
5.  **Gate 5: Benefits Realization Stage**: Post-handover performance monitoring.
> "The VAP typically includes five gate stages... Concept Stage, Definition Stage, Execution Readiness Stage, Execution Stage, and Benefits Realization Stage." — LinkedIn (Atul Srivastava) [[31]](#ref31)

## 3. Core Codes and Standards
The UAE relies on a combination of proprietary corporate standards and international codes.

### ADNOC Group Engineering Standards (AGES)
ADNOC has transitioned from older "ADNOC Technical Specifications" (ATS) to the unified "AGES" framework.
*   **AGES-SP-06-002**: Pressure Vessel Specification (based on ASME Sec VIII). — ADNOC [[1]](#ref1)
*   **AGES-SP-09-001**: Piping Basis of Design (based on ASME B31.3). — ADNOC [[32]](#ref32)
*   **AGES-SP-10-001**: Welding and NDT Specification. — Slideshare (ADNOC) [[33]](#ref33)
*   **AGES-SP-07-001**: Cathodic Protection Specification.
*   **AGES-PH-08-002**: Flare & Blowdown Philosophy.

### International Standards
*   **ASME (American Society of Mechanical Engineers)**: Section VIII (Pressure Vessels), B31.3 (Process Piping), B31.4/B31.8 (Pipelines).
*   **API (American Petroleum Institute)**: API 610 (Centrifugal Pumps), API 650 (Storage Tanks), API 520/521 (Pressure Relieving Systems).
*   **IEC (International Electrotechnical Commission)**: IEC 60079 series for Hazardous Area Classification.
*   **NFPA (National Fire Protection Association)**: NFPA 30 (Flammable and Combustible Liquids Code), NFPA 70 (NEC).

## 4. Technical Design Content

### Pressure Vessels and Piping
*   **Design Basis**: Pressure vessels must be constructed in accordance with ASME Section VIII Division 1 or 2.
*   **Material Selection**: Carbon steel with a corrosion allowance is the default. Sour service (H2S) requires compliance with NACE MR0175/ISO 15156.
*   **Piping**: ASME B31.3 is the primary code for process piping. Underground piping in carbon steel must be externally coated and protected by cathodic protection. — ADNOC AGES-SP-09-001 [[34]](#ref34)

### Hazardous Area Classification (HAC)
*   **Standards**: IEC 60079-10-1 (Gas) and IEC 60079-10-2 (Dust).
*   **Zones**:
    *   **Zone 0**: Explosive atmosphere present continuously.
    *   **Zone 1**: Explosive atmosphere likely to occur in normal operation.
    *   **Zone 2**: Explosive atmosphere not likely to occur, or only for short periods.
*   **Equipment**: Must be ATEX or IECEx certified.

### Process Safety (HAZOP)
*   **Methodology**: A structured 6-step process to identify hazards and operability problems.
*   **Requirement**: Formal HAZOP studies are mandatory for all ADNOC projects and are required for Civil Defense and insurance audits. — Velosi Asset Integrity [[35]](#ref35)

## 5. Construction, Testing, and Commissioning
*   **Welding and NDT**: Must follow AGES-SP-10-001. 100% Radiographic Testing (RT) or Ultrasonic Testing (UT) is often required for critical process lines.
*   **Hydrostatic Testing**: Typically performed at 1.5 times the design pressure for piping (ASME B31.3) and 1.3 times for pressure vessels (ASME Sec VIII Div 1).
*   **Commissioning**: Governed by AGES-SP-13-001. Includes Pre-commissioning (cold testing), Commissioning (hot testing), and Performance Testing.
*   **Handover**: Requires a comprehensive "As-Built" documentation package and a "Completion Certificate" from the relevant authority (e.g., Dubai Municipality or ADNOC).

## 6. UAE Climate, Durability, and Safety Notes
The UAE's harsh environment significantly impacts industrial engineering design.

*   **Extreme Heat**: Surface temperatures of static equipment exposed to direct sunlight can reach **85°C**. — ADNOC Electrical Engineering Design Guide [[36]](#ref36)
*   **Wind Loads**: Design wind speed is typically **175 km/hr** (3-second gust) for industrial structures. — ADNOC Electrical Engineering Design Guide [[36]](#ref36)
*   **Corrosion**: The atmosphere is regarded as "dusty, sulfurous, saliferous and corrosive." High humidity (up to 95%) and salt-laden air necessitate advanced coating systems and cathodic protection.
*   **Seismic**: UAE is generally classified as Seismic Design Category A or B, but critical industrial facilities often design for Category C parameters to ensure resilience.
*   **H2S Safety**: High H2S (sour gas) concentrations in many UAE fields require stringent material selection (NACE) and advanced gas detection/emergency response systems.

## 7. Professional Practice and Checklists
Senior engineers focus on "Value Engineering" and "Integrity Management."

### Design Review Checklist
*   [ ] Verify compliance with latest AGES revisions (many updated June 2025).
*   [ ] Confirm Hazardous Area Classification (HAC) drawings match equipment specifications.
*   [ ] Ensure Material Selection Report accounts for sour service and UAE corrosion rates.
*   [ ] Check that flare/relief systems are sized for worst-case scenarios (e.g., fire or power failure).
*   [ ] Validate that all 3rd party crossings (pipelines/cables) have valid NOCs.

### Risk Management
*   **HAZID/HAZOP**: Conducted at Concept and FEED stages.
*   **SIL (Safety Integrity Level)**: Assessment for Safety Instrumented Systems (SIS) to ensure target risk reduction.
*   **PHSER (Project Health, Safety and Environmental Review)**: Conducted at various VAP gates.

## 8. Sources
### Primary Sources
*   **ADNOC Engineering Standards (AGES)**:  (and various direct PDF links cited above). [[37]](#ref37)
*   **UAE Fire and Life Safety Code of Practice (2018) [[28]](#ref28)
*   **Dubai Municipality Building Permits [[38]](#ref38)

### Secondary Sources
*   **Velosi Asset Integrity (HAZOP/VAP) [[39]](#ref39)
*   **LinkedIn Technical Articles (Atul Srivastava, Nartu Hara Prasad Patra)**: Cited for VAP and AGES updates.

## 9. Gaps and Verification Notes
*   **AGES Access**: Full AGES documents are often restricted to registered ADNOC vendors/contractors; public versions are limited.
*   **Specific Corrosion Rates**: While "high" corrosion is noted, exact mm/year rates for specific UAE offshore zones are typically project-specific and found in proprietary Material Selection Reports.
*   **Fee Structures**: Authority fees for NOCs and permits (e.g., Trakhees) are subject to frequent change and should be verified via the official portals at the time of application.
*   **Verification Recommended**: Confirm the latest revision of AGES-SP-07-001 (Cathodic Protection) as it is a high-activity area for updates.

**Checklist Status Summary**:
*   Checklist Path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/50da19b9/RESEARCH_CHECKLIST.md`
*   All items marked `[Y]`.

---


## 4. Facade Thermal Performance Summary

| Parameter | Dubai (DBC 2021) | Abu Dhabi (ADIBC/Estidama) | Notes |
| --- | --- | --- | --- |
| External walls (U-value) | 0.57 W/m²K | 0.32 W/m²K | Varies 0.48–0.57 W/m²K[[2]](#ref2) |
| Roofs (U-value) | 0.30 W/m²K | 0.17–0.25 W/m²K | — |
| Glazing (SHGC) | 0.22–0.40 | 0.25–0.30 | — |
| Min design wind pressure | 1 kN/m² | 1 kN/m² | DBC 2021 / ADIBC |
| Wind tunnel threshold | ≥120 m height or irregular | ≥120 m or irregular | DBC 2021[[6]](#ref6) |


## 5. Key ADNOC and Process Engineering Standards

| Domain | ADNOC Standard | International Reference | Key Technical Point |
| --- | --- | --- | --- |
| Pressure vessel design | AGES-SP-06-002 | ASME Section VIII Div 1 & 2 | Design pressure, cyclic service, CRA lining |
| Process piping | AGES-SP-09-001 | ASME B31.3 | Wall thickness: t = PD / [2(SEW + PY)] |
| Hazardous area classification | AGES / IEC 60079-10-1 | IEC 60079 series | Zone 0/1/2 gas; Zone 20/21/22 dust; ECAS-Ex certification [[2]](#ref2) |
| Safety instrumented systems | AGES-SP-04-004 | IEC 61508/61511 | SIL assessment; HAZOP + LOPA required |
| Offshore steel structures | AGES-SP-11-001 | ISO 19902 / NORSOK | Cathodic protection; splash-zone corrosion allowance |
| Subsea pipelines | AGES-SP-10-002 | DNV-ST-F101 | Wall thickness, buckle propagation, CP design |


## 6. Facade, Cladding, and Fire Safety Checklist

### Facade engineering compliance checklist

1. **DCD material approval** — Every cladding material/assembly must have a Certificate of Compliance (CoC) from a DCD-approved laboratory before installation.
2. **Thermal calculations** — Submit U-value and SHGC calculations against DBC/ADIBC requirements; provide energy model if Al Sa'fat or Estidama requires it.
3. **Wind pressure test** — If building ≥120 m or irregular, commission wind tunnel test; submit report for structural and glazing design.
4. **NFPA 285 compliance** — All combustible cladding assemblies must pass NFPA 285 fire propagation test; include test certificate in submission.
5. **Water-tightness testing** — ASTM E1105 field test at representative panel; also AAMA 501.2 for installed glazing systems.
6. **BMU/access strategy** — Confirm Building Maintenance Unit design, anchor points, rope access zones, and load points with structural engineer.


## Expert Appendix: Field Control, Design Review, and Authority Coordination Templates

### Template A: Design Review Checklist Framework
A senior engineering design review should confirm: design basis and load assumptions are documented; code edition and amendment dates are stated; all UAE authority requirements have been addressed by reference; specialist sub-consultant inputs are incorporated and coordinated; sustainability compliance (Al Sa'fat or Estidama as applicable) is addressed; fire and life safety interfaces are resolved; and the drawing set matches calculations and specifications. Any deviation from code requires a written technical justification.

### Template B: Authority Submission Package
Before submitting to any UAE authority, confirm: the submitting consultant firm holds a valid practising card/approval for the project emirate; drawings are in the required format and coordinate system; all NOCs from upstream authorities are attached; calculations are signed by a registered engineer; the BIM model (if mandated under DM Circular 9-1-3/2026 or Abu Dhabi DMT requirements) is attached in the required format; and fees or bonds have been paid. Incomplete packages are returned without review in most Dubai and Abu Dhabi portals.

### Template C: Site Supervision and Inspection Record
For each Witness or Hold point on the ITP, the site supervisor should confirm: the work activity matches the approved shop drawing; material has a valid test certificate or Material Approval Request (MAR); pre-activity conditions (compaction, formwork, earthing, cleanliness) are met; work execution matches approved method statement; post-activity tests are conducted and recorded; Non-Conformance Reports are raised immediately for failures; and the record is signed, dated, and uploaded to the document management system.

### Template D: Commissioning and Handover Record
The commissioning package should include: signed Commissioning Manager appointment; pre-commissioning mechanical completion certificates; equipment startup records with measured versus specified values; functional test sheets for all systems; cause-and-effect matrix testing records for life-safety interfaces; Training records for the building operator; Operating and Maintenance manuals with as-built BIM model; and a Defect Tracking Register. In Dubai, DEWA/DCD and DM will conduct their own independent inspections before issuing the Completion Certificate.

### Template E: Professional Risk Register for UAE Engineering Projects
Key project risks to track: BIM submission readiness; NOC expiry dates and renewal sequences; Specialist material lead times (high-performance concrete, specialist glazing, medical gas equipment); Third-party inspection availability; Civil Defense comments on fire systems; Authority variations discovered late in design; Structural peer review findings; Geotechnical report limitations; Weather restrictions on concrete pours; Power supply sequencing for DEWA connection; District Cooling provider connection timing; and Snagging management strategy for Completion Certificate.


## Extended Technical Reference: Facade Systems and Marine Structures

### Curtain Wall System Types and Selection
UAE high-rise facades typically use one of four curtain wall systems:
- **Unitised (stick-built replaced by factory units):** Most common for tall buildings >50 m; each unit is a complete panel assembled off-site; faster installation and better quality control; requires careful tolerance management between structure and facade.
- **Stick system:** Installed mullion by mullion and transom by transom on-site; better for irregular geometry; slower and more quality risk.
- **Structural silicone glazing (SSG):** Glass is bonded to aluminium frame using structural silicone; no mechanical retention visible from outside; requires strict UV resistance and silicone compatibility testing.
- **Double skin facade (DSF):** Outer skin + air cavity + inner skin; reduces solar gain; increases natural ventilation options; higher capital cost; fire compartmentation inside cavity must be verified.

### Cladding Fire Safety — UAE Requirements
Following high-profile UAE tower fires, cladding fire safety is one of the most scrutinised areas:
- **NFPA 285 test:** Required for any combustible material in exterior wall assemblies above the first two storeys; the test verifies the assembly (not just the material) does not propagate fire vertically.
- **Civil Defense Certificate of Compliance (CoC):** Each assembly system (substrate + insulation + cladding + adhesive + sealant) must have a CoC from a DCD-approved testing laboratory; individual material certificates are not sufficient.
- **ACM (Aluminium Composite Material):** Must use fire-retardant (FR) core, not PE core, for buildings above two storeys; FR core has limiting oxygen index ≥35% per UAE Civil Defense directive.
- **Inspection during installation:** Civil Defense or third-party inspector verifies the installed system matches the tested and approved assembly; changes to any component require re-testing or re-certification.

### Marine Structure Design for Arabian Gulf
Key engineering challenges specific to the Arabian Gulf:
- **Salinity:** Arabian Gulf salinity is 40–45 ppt (compared to 35 ppt global average); highly corrosive; concrete must have minimum cover 75 mm in tidal/splash zone; sacrificial anode or impressed current cathodic protection (ICCP) for steel.
- **Water temperature:** 15–35°C surface; affects marine growth, cathodic protection consumption, and concrete curing.
- **Tidal range:** 0.5–2.0 m; define LAT (Lowest Astronomical Tide) as datum for marine structure levels; splash zone extends from -1.0 m to +3.0 m relative to MSL.
- **Wave climate:** Gulf fetch-limited; Hs 1-year ≈ 2–4 m; Hs 100-year ≈ 4–7 m at offshore locations; near-shore coastal structures use locally calibrated wave data.
- **Dredging and reclamation:** EIA must address seabed impacts, turbidity plume, noise, fisheries, coral and seagrass habitats; EAD or DM Coastal Management Section review is mandatory.


## References

<p id="ref1" class="ref_item">[1] adnoc.ae <a target="_blank" rel="noreferrer" href="https://www.adnoc.ae/-/media/adnoc-v2/files/specs/2021/engineering-standards-and-specifications-october14th/pressure-vessel-specification.ashx">https://www.adnoc.ae/-/media/adnoc-v2/files/specs/2021/engineering-standards-and-specifications-october14th/pressure-vessel-specification.ashx</a></p>
<p id="ref2" class="ref_item">[2] daemuae.com <a target="_blank" rel="noreferrer" href="https://daemuae.com/daem-constructions/dcd-vs-dm-noc-in-dubai-whats-the-difference/">https://daemuae.com/daem-constructions/dcd-vs-dm-noc-in-dubai-whats-the-difference/</a></p>
<p id="ref3" class="ref_item">[3] daralnaseeb.com <a target="_blank" rel="noreferrer" href="https://daralnaseeb.com/blog/al-safat-2-green-building-requirements-dubai-2026">https://daralnaseeb.com/blog/al-safat-2-green-building-requirements-dubai-2026</a></p>
<p id="ref4" class="ref_item">[4] dlp.dubai.gov.ae <a target="_blank" rel="noreferrer" href="https://dlp.dubai.gov.ae/Legislation%20Reference/2021/Administrative%20Resolution%20No.%20(37">https://dlp.dubai.gov.ae/Legislation%20Reference/2021/Administrative%20Resolution%20No.%20(37</a></p>
<p id="ref5" class="ref_item">[5] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/gurdiishsingh_the-%F0%9D%90%80%F0%9D%90%A5-%F0%9D%90%92%F0%9D%90%9A%F0%9D%90%9F%F0%9D%90%9A%F0%9D%90%AD-%F0%9D%90%AB%F0%9D%90%9E%F0%9D%90%A0%F0%9D%90%AE%F0%9D%90%A5%F0%9D%90%9A%F0%9D%90%AD%F0%9D%90%A2%F0%9D%90%A8%F0%9D%90%A7-activity-7383316214720139264-iA3F">https://www.linkedin.com/posts/gurdiishsingh_the-%F0%9D%90%80%F0%9D%90%A5-%F0%9D%90%92%F0%9D%90%9A%F0%9D%90%9F%F0%9D%90%9A%F0%9D%90%AD-%F0%9D%90%AB%F0%9D%90%9E%F0%9D%90%A0%F0%9D%90%AE%F0%9D%90%A5%F0%9D%90%9A%F0%9D%90%AD%F0%9D%90%A2%F0%9D%90%A8%F0%9D%90%A7-activity-7383316214720139264-iA3F</a></p>
<p id="ref6" class="ref_item">[6] dda.gov.ae <a target="_blank" rel="noreferrer" href="https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf">https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf</a></p>
<p id="ref7" class="ref_item">[7] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/al-safat-dubai-green-building-system/">https://www.dm.gov.ae/municipality-business/al-safat-dubai-green-building-system/</a></p>
<p id="ref8" class="ref_item">[8] dcd.gov.ae <a target="_blank" rel="noreferrer" href="https://dcd.gov.ae/portal/preventive-safety/uae-fire-and-life-safety-code-of-practice.jsp">https://dcd.gov.ae/portal/preventive-safety/uae-fire-and-life-safety-code-of-practice.jsp</a></p>
<p id="ref9" class="ref_item">[9] dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dmt.gov.ae/">https://www.dmt.gov.ae/</a></p>
<p id="ref10" class="ref_item">[10] wfmmedia.com <a target="_blank" rel="noreferrer" href="https://wfmmedia.com/nfpa-285-test-method-and-its-2019-revision/">https://wfmmedia.com/nfpa-285-test-method-and-its-2019-revision/</a></p>
<p id="ref11" class="ref_item">[11] buildindubai.gov.ae <a target="_blank" rel="noreferrer" href="https://buildindubai.gov.ae/services*">https://buildindubai.gov.ae/services*</a></p>
<p id="ref12" class="ref_item">[12] pcfc.ae <a target="_blank" rel="noreferrer" href="https://pcfc.ae/en/Service%20Documents/TRK-CED-PL-CF05c,%20Marine%20Demarcation%20Application%20Form.pdf*">https://pcfc.ae/en/Service%20Documents/TRK-CED-PL-CF05c,%20Marine%20Demarcation%20Application%20Form.pdf*</a></p>
<p id="ref13" class="ref_item">[13] admaritime.ae <a target="_blank" rel="noreferrer" href="https://www.admaritime.ae/our-services/*">https://www.admaritime.ae/our-services/*</a></p>
<p id="ref14" class="ref_item">[14] ead.gov.ae <a target="_blank" rel="noreferrer" href="https://www.ead.gov.ae/en*">https://www.ead.gov.ae/en*</a></p>
<p id="ref15" class="ref_item">[15] adnoc.ae <a target="_blank" rel="noreferrer" href="https://www.adnoc.ae/-/media/adnoc-v2/files/specs/2021/engineering-standards-and-specifications-october14th/offshore-steel-structures-specification.ashx*">https://www.adnoc.ae/-/media/adnoc-v2/files/specs/2021/engineering-standards-and-specifications-october14th/offshore-steel-structures-specification.ashx*</a></p>
<p id="ref16" class="ref_item">[16] admaritime.ae <a target="_blank" rel="noreferrer" href="https://www.admaritime.ae/wp-content/uploads/2023/02/Design_Code_Maritime_Infrastructure_0713.pdf*">https://www.admaritime.ae/wp-content/uploads/2023/02/Design_Code_Maritime_Infrastructure_0713.pdf*</a></p>
<p id="ref17" class="ref_item">[17] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/environment-sustainability-technical-guidelines/*">https://www.dm.gov.ae/municipality-business/environment-sustainability-technical-guidelines/*</a></p>
<p id="ref18" class="ref_item">[18] adcda.gov.ae <a target="_blank" rel="noreferrer" href="https://www.adcda.gov.ae/-/media/Project/ADCDA/ADCDA/Digital-Library/UAE-Fire-and-Life-Safety-Code-of-Practice.pdf*">https://www.adcda.gov.ae/-/media/Project/ADCDA/ADCDA/Digital-Library/UAE-Fire-and-Life-Safety-Code-of-Practice.pdf*</a></p>
<p id="ref19" class="ref_item">[19] mdpi.com <a target="_blank" rel="noreferrer" href="https://www.mdpi.com/2306-5338/9/8/144*">https://www.mdpi.com/2306-5338/9/8/144*</a></p>
<p id="ref20" class="ref_item">[20] academicjournals.org <a target="_blank" rel="noreferrer" href="https://academicjournals.org/journal/JOMS/article-full-text-pdf/33C80EB61280*">https://academicjournals.org/journal/JOMS/article-full-text-pdf/33C80EB61280*</a></p>
<p id="ref21" class="ref_item">[21] vliz.be <a target="_blank" rel="noreferrer" href="https://www.vliz.be/imisdocs/publications/113444.pdf*">https://www.vliz.be/imisdocs/publications/113444.pdf*</a></p>
<p id="ref22" class="ref_item">[22] evac.com <a target="_blank" rel="noreferrer" href="https://evac.com/article/what-is-a-sacrificial-anode-and-why-iccp-systems-are-a-better-solution/*">https://evac.com/article/what-is-a-sacrificial-anode-and-why-iccp-systems-are-a-better-solution/*</a></p>
<p id="ref23" class="ref_item">[23] ugceconsultants.com <a target="_blank" rel="noreferrer" href="https://ugceconsultants.com/5-engineering-design-mistakes/*">https://ugceconsultants.com/5-engineering-design-mistakes/*</a></p>
<p id="ref24" class="ref_item">[24] admaritime.ae <a target="_blank" rel="noreferrer" href="https://www.admaritime.ae/wp-content/uploads/2023/02/Design_Code_Maritime_Infrastructure_0713.pdf">https://www.admaritime.ae/wp-content/uploads/2023/02/Design_Code_Maritime_Infrastructure_0713.pdf</a></p>
<p id="ref25" class="ref_item">[25] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/environment-sustainability-technical-guidelines/">https://www.dm.gov.ae/municipality-business/environment-sustainability-technical-guidelines/</a></p>
<p id="ref26" class="ref_item">[26] adnoc.ae <a target="_blank" rel="noreferrer" href="https://www.adnoc.ae/-/media/adnoc-v2/files/specs/2021/engineering-standards-and-specifications-october14th/offshore-steel-structures-specification.ashx">https://www.adnoc.ae/-/media/adnoc-v2/files/specs/2021/engineering-standards-and-specifications-october14th/offshore-steel-structures-specification.ashx</a></p>
<p id="ref27" class="ref_item">[27] mdpi.com <a target="_blank" rel="noreferrer" href="https://www.mdpi.com/2306-5338/9/8/144">https://www.mdpi.com/2306-5338/9/8/144</a></p>
<p id="ref28" class="ref_item">[28] adcda.gov.ae <a target="_blank" rel="noreferrer" href="https://www.adcda.gov.ae/-/media/Project/ADCDA/ADCDA/Digital-Library/UAE-Fire-and-Life-Safety-Code-of-Practice.pdf">https://www.adcda.gov.ae/-/media/Project/ADCDA/ADCDA/Digital-Library/UAE-Fire-and-Life-Safety-Code-of-Practice.pdf</a></p>
<p id="ref29" class="ref_item">[29] snoc.ae <a target="_blank" rel="noreferrer" href="https://www.snoc.ae/">https://www.snoc.ae/</a></p>
<p id="ref30" class="ref_item">[30] accreditation.trakhees.ae <a target="_blank" rel="noreferrer" href="https://accreditation.trakhees.ae/">https://accreditation.trakhees.ae/</a></p>
<p id="ref31" class="ref_item">[31] linkedin.com <a target="_blank" rel="noreferrer" href="https://www.linkedin.com/posts/atulsrivastava_the-value-assurance-process-vap-gate-stages-activity-7040032281742196736-h4XQ">https://www.linkedin.com/posts/atulsrivastava_the-value-assurance-process-vap-gate-stages-activity-7040032281742196736-h4XQ</a></p>
<p id="ref32" class="ref_item">[32] adnoc.ae <a target="_blank" rel="noreferrer" href="https://www.adnoc.ae/-/media/adnoc-v2/files/specs/2021/engineering-standards-and-specifications-october14th/piping-basis-of-design.ashx">https://www.adnoc.ae/-/media/adnoc-v2/files/specs/2021/engineering-standards-and-specifications-october14th/piping-basis-of-design.ashx</a></p>
<p id="ref33" class="ref_item">[33] slideshare.net <a target="_blank" rel="noreferrer" href="https://www.slideshare.net/slideshow/adnoc-welding-and-nde-specification-requirement-pdf/284793420">https://www.slideshare.net/slideshow/adnoc-welding-and-nde-specification-requirement-pdf/284793420</a></p>
<p id="ref34" class="ref_item">[34] coursehero.com <a target="_blank" rel="noreferrer" href="https://www.coursehero.com/file/p3ot9uai/AGES-SP-09-001-Rev-No-1-Page-78-of-116-ADNOC-Classification-Public-provide-for/">https://www.coursehero.com/file/p3ot9uai/AGES-SP-09-001-Rev-No-1-Page-78-of-116-ADNOC-Classification-Public-provide-for/</a></p>
<p id="ref35" class="ref_item">[35] velosiaims.com <a target="_blank" rel="noreferrer" href="https://velosiaims.com/hazop-the-structured-approach-to-your-industrial-process-safety-needs/">https://velosiaims.com/hazop-the-structured-approach-to-your-industrial-process-safety-needs/</a></p>
<p id="ref36" class="ref_item">[36] adnoc.ae <a target="_blank" rel="noreferrer" href="https://www.adnoc.ae/-/media/adnoc-v2/files/specs/2021/engineering-standards-and-specifications-october14th/electrical-engineering-design-guide.ashx">https://www.adnoc.ae/-/media/adnoc-v2/files/specs/2021/engineering-standards-and-specifications-october14th/electrical-engineering-design-guide.ashx</a></p>
<p id="ref37" class="ref_item">[37] adnoc.ae <a target="_blank" rel="noreferrer" href="https://www.adnoc.ae/en/adnoc-murban/documents-and-downloads">https://www.adnoc.ae/en/adnoc-murban/documents-and-downloads</a></p>
<p id="ref38" class="ref_item">[38] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/building-permit-steps/">https://www.dm.gov.ae/municipality-business/building-permit-steps/</a></p>
<p id="ref39" class="ref_item">[39] velosiaims.com <a target="_blank" rel="noreferrer" href="https://velosiaims.com/">https://velosiaims.com/</a></p>
