# Environmental, Sustainability, HSE, and Materials Engineering in the UAE

This chapter covers sustainability rating systems, environmental impact assessment, construction HSE, occupational safety, and materials engineering including QA/QC — the four interlocking compliance pillars that run across all UAE engineering projects. [[1]](#ref1)[[2]](#ref2)

## 1. Environmental and Sustainability Engineering

# Source Packet 5: Environmental, sustainability and energy engineering: Estidama, Al Sa'fat, green building, energy efficiency, waste, EIA, climate adaptation and carbon

**Research topic:** Environmental, sustainability and energy engineering: Estidama, Al Sa'fat, green building, energy efficiency, waste, EIA, climate adaptation and carbon

**Report title:** Environmental, Sustainability, and Energy Engineering: UAE Knowledge Library

# Environmental, Sustainability, and Energy Engineering: UAE Knowledge Library

## Domain Scope
Environmental and sustainability engineering in the UAE focuses on the integration of ecological preservation, resource efficiency, and climate resilience into the built environment. Given the UAE's hyper-arid climate, extreme summer temperatures (exceeding 50°C), and high humidity, the domain is primarily concerned with **Resourceful Energy** (cooling efficiency), **Precious Water** (desalination and recycling), and **Climate Adaptation**.

Typical projects include:
- **Green Building Certification**: Mandatory compliance with Estidama (Abu Dhabi) and Al Sa'fat (Dubai).
- **Environmental Impact Assessments (EIA)**: Required for infrastructure, industrial, and large-scale development projects to mitigate impacts on marine and desert ecosystems.
- **Net Zero Initiatives**: Aligning building operations with the **UAE Net Zero by 2050 Strategic Initiative**, which targets a 70% reduction in the carbon footprint of power generation by 2050. — *UAE Government [[3]](#ref3)

## UAE Authorities and Approval Workflow
Sustainability approvals are integrated into the building permit process across the emirates.

### Abu Dhabi: Department of Municipalities and Transport (DMT) & EAD
- **Estidama Pearl Rating System (PRS)**: Managed by DMT.
  - **Design Phase**: A Pearl Qualified Professional (PQP) must submit a Pearl Rating Design Submission to obtain a **Pearl Design Rating (PDR)**, which is a prerequisite for a building permit.
  - **Construction Phase**: Regular audits ensure design commitments are met, leading to a **Pearl Construction Rating (PCR)** required for the Completion Certificate.
  - **Operational Phase**: Requires 2 years of data and 80% occupancy for a **Pearl Operational Rating (POR)**. — *Stonehaven [[4]](#ref4)
- **Environment Agency – Abu Dhabi (EAD)**: Issues Environmental Clearances (EC) for projects based on EIA reports.

### Dubai: Dubai Municipality (DM)
- **Al Sa'fat – Dubai Green Building System**:
  - **Silver Sa'fa**: Mandatory for all new buildings since October 2020.
  - **Golden/Platinum Sa'fa**: Optional higher tiers for enhanced performance.
  - **Workflow**: Compliance is checked during the Building Permit (Design) and Building Completion (Inspection) stages. — *Dubai Municipality [[5]](#ref5)
- **Environmental Planning and Studies Section (EPSS)**: Manages the EIA process in Dubai. Projects are categorized into:
  - **Category A**: Major industrial/infrastructure (Full EIAR required).
  - **Category B**: Medium impact (EIA Summary required).
  - **Category C**: Light impact (Checklist only). — *WKC Group [[6]](#ref6)

## Core Codes and Standards
- **Dubai Building Code (DBC) 2021**: Integrates Al Sa'fat requirements.
- **Estidama Pearl Building Rating System (PBRS) v1.0**: The primary code for Abu Dhabi.
- **UAE Fire and Life Safety Code of Practice**: Relevant for material selection (flammability vs. sustainability).
- **International Standards**: ASHRAE 90.1 (Energy), LEED v4.1 (often used as a voluntary benchmark), and ISO 14001 (Environmental Management).

## Technical Design Content
### Energy Efficiency & Building Envelope
The UAE climate necessitates strict thermal performance to reduce cooling loads.
- **U-Values (Thermal Transmittance)**:
  - **Al Sa'fat (Silver)**: External walls max **0.57 W/m²K**, Roof max **0.30 W/m²K**, Glazing max **2.0 W/m²K**. — *Dar Al Naseeb [[7]](#ref7)
  - **Estidama (1 Pearl)**: External walls max **0.32 W/m²K**, Roof max **0.14 W/m²K**, Glazing max **2.2 W/m²K**. — *AESG [[8]](#ref8)
- **Lighting Power Density (LPD)**: Mandatory limits on W/m² to reduce internal heat gain.
- **Solar Heat Gain Coefficient (SHGC)**: Critical for glazing to block infrared radiation while allowing visible light.

### Water Conservation
- **Indoor Water**: Mandatory use of low-flow fixtures (e.g., faucets < 6 L/min, dual-flush toilets).
- **Outdoor Water**: Estidama requires a **37% reduction** in water usage compared to a baseline, often achieved through xeriscaping (native plants like Ghaf trees) and greywater recycling. — *Stonehaven [[4]](#ref4)

### Waste Management
- **Construction Waste**: Mandatory Construction Environmental Management Plan (CEMP).
- **Diversion Targets**: Estidama targets diverting **65% of construction waste** from landfills. — *Stonehaven [[4]](#ref4)

## Construction Supervision, Testing, and Commissioning
- **Commissioning (Cx)**: Independent commissioning agent (ICA) is often required for Estidama (2+ Pearls) to verify HVAC, lighting controls, and water systems.
- **Testing**:
  - **Blower Door Test**: To check building envelope airtightness.
  - **Air Quality Testing**: Pre-occupancy flush-out or testing for VOCs and Formaldehyde.
- **CEMP Monitoring**: Monthly reports on fuel consumption, dust control, and waste segregation on-site.

## UAE Climate, Durability, and Sustainability Notes
- **Heat Island Effect**: Use of high-SRI (Solar Reflectance Index) materials for roofs and hardscapes to reduce local temperature rise.
- **Dust and Sand**: Impact on PV panel efficiency (requires automated cleaning) and HVAC filtration (MERV 13+ recommended).
- **Corrosion**: High salinity in coastal areas requires durable, non-corrosive sustainable materials.
- **Net Zero 2050**: The UAE is the first MENA nation to commit to Net Zero, driving a shift toward **Building Integrated Photovoltaics (BIPV)** and **Electric Vehicle (EV) charging** infrastructure (now mandatory in Al Sa'fat Silver). — *UAE Government [[3]](#ref3)

## Professional Practice and Checklists
### Senior Engineer Design Review Checklist
- [ ] **Envelope**: Do U-values meet the specific Emirate's mandatory minimum?
- [ ] **Glazing**: Is the SHGC optimized for the specific orientation (North vs. South)?
- [ ] **Water**: Are greywater systems integrated for cooling tower makeup or irrigation?
- [ ] **Materials**: Does 50% of timber have FSC/PEFC certification? (Estidama requirement).
- [ ] **Documentation**: Is the PQP involved in all design progress meetings?

## Sources
- **Dubai Municipality (Al Sa'fat) [[2]](#ref2)
- **Stonehaven (Estidama Deciphered) [[9]](#ref9)
- **UAE Government (Net Zero 2050) [[10]](#ref10)
- **WKC Group (Dubai EIA Guidance) [[11]](#ref11)
- **AESG (Thermal Performance) [[12]](#ref12)
- **Dar Al Naseeb (Al Sa'fat 2026) [[13]](#ref13)

## Gaps and Verification Notes
- **Al Sa'fat 2.0 (2026)**: While some sources mention 2026 updates, the official Dubai Municipality portal still references the 2020 version as the primary active code. Verification of the exact "2026" version's enforcement date is recommended.
- **Paywalled Standards**: Specific ASHRAE and ISO standards mentioned are paywalled; design values are cited from UAE-specific summaries.
- **Authority Differences**: Northern Emirates (Sharjah, Ajman, etc.) often follow the **UAE Green Building Code** (federal) or specific local variants like Sharjah's "Barjeel," which requires separate verification for projects in those regions.

**Checklist Status Summary**:
- Runtime checklist path: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/58683eaa/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---


## 2. Construction HSE and Occupational Safety Engineering

# Source Packet 8: Construction HSE and occupational safety engineering: UAE safety laws, OSHAD/Abu Dhabi OSH, Dubai Municipality, site safety, lifting, scaffolding, confined spaces

**Research topic:** Construction HSE and occupational safety engineering: UAE safety laws, OSHAD/Abu Dhabi OSH, Dubai Municipality, site safety, lifting, scaffolding, confined spaces

**Report title:** Construction HSE and Occupational Safety Engineering in the UAE

# Construction HSE and Occupational Safety Engineering in the UAE

## Domain Scope
Construction HSE (Health, Safety, and Environment) and Occupational Safety Engineering in the UAE encompass the systematic management of risks to protect workers, the public, and the environment during construction activities. This domain is critical due to the UAE's high-density urban development, extreme climatic conditions, and a diverse multinational workforce.

- **UAE Relevance**: The UAE has transitioned from basic safety guidelines to a robust, internationally aligned regulatory framework (e.g., ADOSH-SF, Dubai Municipality Code).
- **Typical Projects**: High-rise buildings, infrastructure (bridges, tunnels), industrial plants (ADNOC), and large-scale residential developments (Dubai South).
- **Boundaries**: Covers site safety, structural integrity of temporary works (scaffolding), mechanical safety (lifting), environmental protection (waste/dust), and occupational health (heat stress, noise).

## UAE Authorities and Approval Workflow
Safety management in the UAE is governed by both federal laws and emirate-specific authorities.

### 1. Federal Authorities
- **Ministry of Human Resources and Emiratisation (MoHRE)**: Enforces federal labor laws, including the "Midday Break" and general occupational health requirements.
- **Ministry of Energy and Infrastructure (MoEI)**: Oversees safety standards for federal infrastructure projects.

### 2. Local Authorities
- **Abu Dhabi**: 
  - **Abu Dhabi Public Health Centre (ADPHC)**: Manages the Abu Dhabi Occupational Safety and Health System Framework (ADOSH-SF).
  - **Department of Municipalities and Transport (DMT)**: Oversees site-specific safety approvals.
- **Dubai**:
  - **Dubai Municipality (DM)**: The primary regulator via the Building Department.
  - **Trakhees (PCFC)**: Regulates safety in "Special Development Zones" (e.g., JAFZA, Dubai Maritime City).
  - **Dubai South**: Specific authority for the Al Maktoum International Airport area.
- **UAE Civil Defense**: Approves fire safety plans and conducts site inspections for fire life safety compliance.

### 3. Approval Workflow
1. **NOC for Construction**: Obtained from DM or Trakhees before site mobilization. Requires a preliminary HSE Plan.
2. **HSE Plan Submission**: A comprehensive Health, Safety, and Environment Management Plan (HSEMP) must be submitted and approved.
3. **Permit to Work (PTW)**: Daily or task-specific permits for high-risk activities (Hot Work, Confined Space, Lifting).
4. **Site Inspections**: Authorities conduct periodic (often unannounced) inspections. DM conducted over 35,000 visits in 2023 alone. — *Dubai Municipality [[14]](#ref14)
5. **Completion Certificate**: Final safety clearance required for the Building Completion Certificate (BCC).

## Core Codes and Standards
### UAE Regulations
- **Federal Decree-Law No. 33 of 2021**: The "UAE Labour Law," Article 13 and 36 mandate employers to provide a safe work environment. — *UAE Legislation [[15]](#ref15)
- **ADOSH-SF (Abu Dhabi)**: A comprehensive framework with 54+ Codes of Practice (CoP).
  - **CoP 34.0**: Safe Use of Lifting Equipment.
  - **CoP 26.0**: Scaffolding.
  - **CoP 27.0**: Confined Spaces.
- **Dubai Municipality Code of Construction Safety Practice (2022/2026)**: The definitive guide for Dubai construction sites.
- **UAE Fire and Life Safety Code of Practice**: Managed by Civil Defense.

### International Standards (Used in UAE)
- **ISO 45001**: Occupational Health and Safety Management Systems.
- **BS EN 12811**: Scaffolding performance requirements.
- **NFPA Standards**: For fire safety during construction.
- **OSHA (US)**: Often referenced for technical limits (e.g., 29 CFR 1926).

## Technical Design Content
### 1. Lifting Operations (ADOSH CoP 34.0)
- **Roles**: 
  - **Appointed Person (AP)**: Responsible for the lifting plan. Must have 5+ years of experience. — *ADOSH CoP 34.0 [[16]](#ref16)
  - **Lifting Supervisor**: Oversees the execution on-site.
  - **Slinger/Signaller (Rigger)**: Directs the operator.
- **Lifting Plan**: Mandatory for all lifts. Must include crane capacity at specific radii, load weight, and rigging configuration.
- **Wind Speed Limits**: 
  - Tower Cranes: Operations must cease if wind speeds exceed **38–45 mph (61–72 kph)**. — *Scarlet Tech [[17]](#ref17)
  - Mobile Cranes: Typically stop at **22 mph (35 kph)**.

### 2. Scaffolding (ADOSH CoP 26.0 / DM Code)
- **Safety Factor**: Scaffolds must support their own weight and at least **4 times** the maximum intended load. — *OSHA 1926.451 (referenced in UAE) [[18]](#ref18)
- **Inspection**: Must be inspected by a competent person every **7 days** or after adverse weather.
- **Scafftag System**: Green (Safe), Yellow (Under Construction), Red (Unsafe).

### 3. Confined Spaces (ADOSH CoP 27.0)
- **Atmospheric Limits**:
  - **Oxygen (O2)**: 19.5% to 23.5%. — *Industrial Scientific [[19]](#ref19)
  - **Flammable Gases**: < 10% of Lower Explosive Limit (LEL).
  - **Toxic Gases**: H2S < 10 ppm, CO < 35 ppm (typical 8-hour TWA).
- **Rescue Plan**: A dedicated rescue team and equipment (tripod, winch, SCBA) must be on standby.

## Construction Supervision, Testing, and Commissioning
- **Third-Party Inspection (TPI)**: All lifting equipment and accessories (slings, shackles) must be certified by a DM/ADOSH-approved third-party agency every 6 or 12 months.
- **Load Testing**: Static and dynamic load tests required for cranes after installation or major repair.
- **Gas Testing**: Continuous monitoring required for confined space entry.
- **Scaffold Handover**: A "Certificate of Fitness" must be issued by the scaffolding supervisor before use.

## UAE Climate, Durability, Safety, and Sustainability Notes
### 1. Heat Stress and Midday Break
- **Midday Break**: Mandatory work ban for outdoor activities from **June 15 to September 15**, between **12:30 PM and 3:00 PM**. — *MoHRE [[20]](#ref20)
- **WBGT Index**: If the Wet Bulb Globe Temperature exceeds **32.1°C**, outdoor work must stop. — *Gulf Sustain [[21]](#ref21)

### 2. Dust and Wind
- **Dust Suppression**: Mandatory use of water spraying or enclosures to prevent PM10 pollution.
- **Wind Monitoring**: Anemometers are mandatory on all tower cranes.

### 3. Corrosion
- **Durability**: Scaffolding and lifting components must be galvanized or treated to withstand high humidity and salinity (coastal areas).

## Professional Practice and Checklists
### Senior Engineer's Design Review Checklist
- [ ] Is the HSE Plan site-specific and approved by the relevant authority?
- [ ] Are all high-risk activities covered by a Method Statement and Risk Assessment (RAMS)?
- [ ] Does the lifting plan account for underground utilities and soil bearing capacity?
- [ ] Are exclusion zones clearly defined for lifting and work-at-height?
- [ ] Is there a valid Civil Defense NOC for site offices and storage?

### Common Mistakes
- **Generic RAMS**: Using a template that doesn't reflect actual site hazards.
- **Inadequate Ground Support**: Placing crane outriggers on uncompacted soil or over manholes.
- **Communication Gaps**: Lack of multi-lingual safety inductions for a diverse workforce.

## Gaps and Verification Notes
- **Trakhees 2026 Updates**: While general guidelines are available, specific 2026 technical amendments for Trakhees should be verified via their digital portal (login required).
- **Dubai Building Code (DBC) Integration**: The DBC 2021/2026 focuses on design; site safety remains primarily under the DM Code of Safety Practice.
- **Paywalled Standards**: Specific BS EN or ISO standards for scaffolding components require purchase for full technical compliance.

## Sources
### Primary Sources
- **UAE Federal Decree-Law No. 33 of 2021 [[22]](#ref22)
- **ADOSH-SF CoP 34.0 (Lifting) [[23]](#ref23)
- **ADOSH-SF CoP 26.0 (Scaffolding) [[24]](#ref24)
- **ADOSH-SF CoP 27.0 (Confined Spaces) [[25]](#ref25)
- **MoHRE Midday Break Policy [[26]](#ref26)
- **Dubai Municipality Safety Campaign [[27]](#ref27)

### Secondary Sources
- **Scarlet Tech (Crane Wind Limits) [[28]](#ref28)
- **Industrial Scientific (Gas Levels) [[29]](#ref29)
- **Gulf Sustain (Heat Stress) [[30]](#ref30)

---


## 3. Materials Engineering and QA/QC

# Source Packet 7: Materials engineering and QA/QC: concrete, steel, asphalt, testing labs, inspections, submittals, ITPs, durability in UAE climate

**Research topic:** Materials engineering and QA/QC: concrete, steel, asphalt, testing labs, inspections, submittals, ITPs, durability in UAE climate

**Report title:** Materials Engineering and QA/QC in the UAE Construction Industry

# Materials Engineering and QA/QC in the UAE Construction Industry

## Domain Scope
Materials engineering in the United Arab Emirates (UAE) is a critical discipline focused on the selection, testing, and quality assurance of construction materials to ensure structural integrity and longevity in one of the world's most challenging environments. The scope encompasses the entire lifecycle of materials—from mix design and factory production to site delivery, placement, and long-term durability monitoring.

Typical projects range from high-rise iconic towers (e.g., Burj Khalifa) and massive infrastructure networks (RTA roads, Etihad Rail) to specialized marine structures and industrial facilities. The primary materials of focus are **reinforced concrete**, **structural steel**, and **asphaltic pavements**, all of which must be engineered to withstand extreme ambient temperatures (up to 50°C+), high humidity, and high salinity in both soil and air.

## UAE Authorities and Approval Workflow
The regulatory landscape is divided between federal standards and emirate-specific municipal requirements.

### Key Authorities
*   **Dubai Municipality (DM):** The primary regulator for Dubai, specifically through the **Dubai Central Laboratory (DCL)** for material testing and certification.
*   **Department of Municipalities and Transport (DMT) - Abu Dhabi:** Oversees building and infrastructure materials through the Abu Dhabi City Municipality (ADM) and Al Ain/Al Dhafra municipalities.
*   **Ministry of Energy and Infrastructure (MOEI):** Sets federal standards for national infrastructure and federal buildings.
*   **Roads and Transport Authority (RTA) - Dubai:** Governs asphalt and road-related materials.
*   **Trakhees (PCFC):** Authority for special zones (JAFZA, Dubai World) with specific QA/QC requirements.

### Approval Workflow
1.  **Material Submittal (MAR):** The Contractor submits a Material Approval Request (MAR) to the Consultant. This must include:
    *   Technical Data Sheets (TDS) and Material Safety Data Sheets (MSDS).
    *   Valid **DCL Product Conformity Certificate** (mandatory for steel, concrete blocks, and insulation in Dubai).
    *   Previous test reports from accredited third-party labs.
    *   Compliance statement against project specifications and UAE codes.
2.  **Factory Audit/Inspection:** For major materials like ready-mix concrete or structural steel, the Consultant and sometimes the Authority (DM/DCL) conduct factory audits to verify production quality control.
3.  **Trial Mixes/Mock-ups:** Concrete trial mixes and asphalt job mix formulas (JMF) must be verified in the presence of the Consultant and tested in an approved lab.
4.  **Site Inspection (RFI):** Upon delivery, a Request for Inspection (RFI) is raised. Materials are checked for damage, batch numbers, and delivery tickets.
5.  **Testing:** Samples are taken on-site (e.g., concrete cubes, steel rebars) and sent to an independent, ISO 17025 accredited laboratory.

## Core Codes and Standards
UAE engineering practice relies on a hybrid of local codes and international standards:

*   **Dubai Building Code (DBC) 2021:** The unified code for Dubai, replacing previous circulars. It mandates specific durability parameters for concrete.
*   **Abu Dhabi International Building Code (ADIBC):** Based on the International Building Code (IBC), with local amendments for climate.
*   **UAE Fire and Life Safety Code of Practice:** Critical for cladding and insulation material fire ratings.
*   **International Standards:**
    *   **Concrete:** ASTM C39 (Compressive Strength), BS EN 206, BS 8500 (Durability).
    *   **Steel:** BS 4449 (Rebar), ASTM A615, BS EN 10025 (Structural Steel).
    *   **Asphalt:** ASTM D1559 (Marshall), AASHTO standards for Superpave.

## Technical Design Content

### Concrete Mix Design and Durability
In the UAE, concrete is designed for "Exposure Classes" defined by the DBC 2021.
*   **Green Cement Requirements (DM Circular 225):** To enhance durability and sustainability, DM mandates the use of Supplementary Cementitious Materials (SCMs):
    *   **GGBS (Ground Granulated Blast-furnace Slag):** Typically 66% to 80% replacement of OPC for foundations to resist sulfate and chloride attack.
    *   **PFA (Pulverized Fuel Ash/Fly Ash):** 25% to 40% replacement.
    *   **Micro Silica (Silica Fume):** 7% to 10% for high-strength, low-permeability concrete.
*   **Durability Limits:**
    *   **Water Permeability (DIN 1048):** Maximum 10mm penetration for substructures.
    *   **Rapid Chloride Permeability Test (RCPT - ASTM C1202):** Typically < 1000 Coulombs for 50-year design life; < 600 Coulombs for 100-year life.
    *   **Water Absorption (BS 1881-122):** Maximum 2% to 3%.

### Steel Reinforcement
*   **Grades:** Standard grade is **Grade 500B or 500C** (BS 4449).
*   **Testing:** Tensile strength, yield strength (min 500 MPa), and elongation are mandatory. Bend and re-bend tests ensure ductility for seismic loads.
*   **Protection:** Fusion Bonded Epoxy Coating (FBEC) is often used for substructures, though modern high-performance concrete (HPC) with SCMs is increasingly preferred over coated rebar.

### Asphalt Pavements
*   **Mix Types:**
    *   **Base Course:** Large aggregate (Gabbro), high stability.
    *   **Binder Course:** Intermediate layer.
    *   **Wearing Course:** High-quality Gabbro aggregate with modified bitumen (PMB) to resist rutting at high temperatures.
*   **Marshall Criteria (RTA Standards):**
    *   **Stability:** Minimum 1000 kg (9.8 kN) for heavy traffic.
    *   **Flow:** 2 mm to 4 mm.
    *   **Air Voids:** 3% to 5%.

## Construction Supervision, Testing, and Commissioning

### Inspection and Test Plans (ITP)
The ITP is the "roadmap" for QA/QC, defining:
*   **Hold Points (H):** Work cannot proceed without Consultant approval (e.g., pre-concreting inspection).
*   **Witness Points (W):** Consultant must be notified to witness the activity (e.g., cube casting).
*   **Review Points (R):** Consultant reviews documentation (e.g., test reports).

### Site QA/QC Procedures
*   **Concrete Pouring:** Slump test and temperature check (max 32°C per DM regulations) are mandatory for every truck. Cubes are cast (typically 1 set per 50m³ or per day) for 7 and 28-day strength testing.
*   **Non-Conformance Reports (NCR):** Issued when materials or workmanship fail to meet standards. Remediation (e.g., core testing, structural strengthening) must be approved by the Consultant and sometimes the Authority.

## UAE Climate, Durability, and Sustainability

### The "Gulf Environment" Challenge
*   **Chloride Attack:** High airborne salinity leads to rapid corrosion of reinforcement.
*   **Sulfate Attack:** High sulfate content in groundwater attacks the concrete matrix.
*   **Thermal Cracking:** Large temperature differentials between day and night, and heat of hydration in mass concrete, require strict thermal control plans (max core temp 70°C, max differential 20°C).

### Sustainability (Al Sa'fat / Estidama)
*   **Recycled Content:** Use of recycled aggregates in non-structural applications is encouraged.
*   **Regional Materials:** Sourcing materials within 800km to reduce carbon footprint.
*   **Low-VOC Materials:** Mandatory for indoor air quality.

## Professional Practice and Checklists

### Senior Engineer's Material Submittal Checklist
- [ ] Is the manufacturer DCL certified (for Dubai projects)?
- [ ] Does the mix design meet the specific Exposure Class in the DBC?
- [ ] Are the SCM percentages (GGBS/PFA) within DM Circular 225 limits?
- [ ] Is the third-party lab ISO 17025 accredited for the specific tests required?
- [ ] Does the steel mill certificate match the heat number on the delivered rebars?

### Common Mistakes
*   **Temperature Overages:** Allowing concrete pouring above 32°C, leading to plastic shrinkage cracks.
*   **Inadequate Curing:** Failing to maintain wet curing for the mandatory 7 days, critical in the UAE's low-humidity environment.
*   **Water Addition:** Adding water to concrete trucks on-site to "improve workability," which destroys the water/cement ratio and durability.

## Source Links
### Primary Sources
*   **Dubai Building Code 2021:** []() [[31]](#ref31)
*   **Dubai Municipality - DCL Product Certification:** []() [[32]](#ref32)
*   **Abu Dhabi DMT - ADIBC:** []() [[33]](#ref33)
*   **DM Circular 225 (Green Cement):** []() [[34]](#ref34)

### Secondary Sources
*   **NRMCA Dubai Ready-Mixed Concrete EPD:** []() [[35]](#ref35)
*   **Asphalt Testing in UAE (Terrasearch):** []() [[36]](#ref36)

## Gaps and Verification Notes
*   **RTA Standard Specifications:** The full RTA Standard Specifications for Road and Bridge Construction is often a controlled document; specific Marshall values for the latest "Superpave" implementations in Dubai should be verified against the latest project-specific RTA manuals.
*   **Fee Schedules:** DCL testing fees are subject to frequent updates via DM circulars and should be verified on the DM portal for current budgeting.
*   **Circular 225 Updates:** While Circular 225 is the baseline, newer "Al Sa'fat" versions (2020+) may have introduced more stringent carbon-counting requirements for concrete.

---
**Checklist Status Summary:**
- Checklist file: `/data/workspace/019f4636-87f2-76f3-9ef8-992dacac6848/research/005ea761/RESEARCH_CHECKLIST.md`
- All items marked `[Y]`.

---


## 4. Sustainability Performance Matrix

| Parameter | Dubai (Al Sa'fat / DBC) | Abu Dhabi (Estidama / ADIBC) |
| --- | --- | --- |
| Exterior walls (U-value) | 0.57 W/m²K (DBC) | 0.32 W/m²K (Estidama) |
| Roofs (U-value) | 0.30 W/m²K (DBC) | 0.17–0.25 W/m²K (Estidama) |
| Glazing (SHGC) | 0.22–0.40 (DBC) | 0.25–0.30 (Estidama) |
| Showerheads | ≤9.0 L/min | ≤9.0 L/min |
| Faucets (private) | ≤5.0 L/min | ≤5.0 L/min |
| Dual-flush WC | 6/3 L per flush | 6/3 L per flush |
| Lighting Power Density (office) | Max 9.0 W/m² | Per ASHRAE 90.1 / Estidama |
| Renewable energy | Estidama RE-1: ≥1% on-site | Al Sa'fat: points for PV system |


## 5. Concrete and Steel QA Parameters

| Parameter | Value | Source / Authority |
| --- | --- | --- |
| Max w/c ratio | 0.40 (reinforced in soil/sea exposure) | DBC 2021 / ACI 318 |
| Min cement content | 370–400 kg/m³ severe exposure | DBC 2021 |
| GGBS replacement | Up to 70% | Dubai / Abu Dhabi practice |
| Fly ash replacement | Up to 35% | Dubai / Abu Dhabi practice |
| Fresh concrete temperature | ≤32°C at pour (Dubai Municipality) | DM requirement |
| Concrete cover — foundations | 75 mm minimum | DBC 2021 |
| Concrete cover — columns/beams | 40–50 mm (exposure-dependent) | DBC 2021 |
| Steel grade | Grade 500B/C (seismic ductility) | BS 4449:2005 |
| Asphalt compaction | ≥97% Marshall density | DM roads requirement |
| Asphalt lay temperature | 135–165°C | Standard industry practice |


## 6. HSE Control Checklist

### Construction site HSE control checklist

1. **NOC and HSE plan** — Submit Safety and Health Construction Management Plan (OSH-CMP) aligned with OSHAD-SF (Abu Dhabi) or DM Code of Construction Safety Practice before site mobilisation.
2. **Lifting operations** — Every lift requires a lifting plan; tower crane installation requires municipality permit and CAA approval near airports; all equipment certified by approved TPI body.
3. **Scaffolding** — Designed to BS EN 12811-1; inspected before use and after weather events; tagging system (green/red) and edge-protection mandatory.
4. **Heat protection** — Enforce mandatory midday break (15 June – 15 September, 12:30–15:00) per MOHRE requirements; provide cool rest areas, water, and shade.
5. **Excavation safety** — Permit to enter, atmospheric testing, shoring certification, dewatering check, edge barriers, and daily inspection log.
6. **Fire prevention** — Site fire plan per UAE Fire Code; storage of flammables, hot work permit, fire extinguisher distribution, and Civil Defense access maintained.


## Expert Appendix: Field Control, Design Review, and Authority Coordination Templates

### Template A: Design Review Checklist Framework
A senior engineering design review should confirm: design basis and load assumptions are documented; code edition and amendment dates are stated; all UAE authority requirements have been addressed by reference; specialist sub-consultant inputs are incorporated and coordinated; sustainability compliance (Al Sa'fat or Estidama as applicable) is addressed; fire and life safety interfaces are resolved; and the drawing set matches calculations and specifications. Any deviation from code requires a written technical justification.

### Template B: Authority Submission Package
Before submitting to any UAE authority, confirm: the submitting consultant firm holds a valid practising card/approval for the project emirate; drawings are in the required format and coordinate system; all NOCs from upstream authorities are attached; calculations are signed by a registered engineer; the BIM model (if mandated under DM Circular 9-1-3/2026 or Abu Dhabi DMT requirements) is attached in the required format; and fees or bonds have been paid. Incomplete packages are returned without review in most Dubai and Abu Dhabi portals.

### Template C: Site Supervision and Inspection Record
For each Witness or Hold point on the ITP, the site supervisor should confirm: the work activity matches the approved shop drawing; material has a valid test certificate or Material Approval Request (MAR); pre-activity conditions (compaction, formwork, earthing, cleanliness) are met; work execution matches approved method statement; post-activity tests are conducted and recorded; Non-Conformance Reports are raised immediately for failures; and the record is signed, dated, and uploaded to the document management system.

### Template D: Commissioning and Handover Record
The commissioning package should include: signed Commissioning Manager appointment; pre-commissioning mechanical completion certificates; equipment startup records with measured versus specified values; functional test sheets for all systems; cause-and-effect matrix testing records for life-safety interfaces; Training records for the building operator; Operating and Maintenance manuals with as-built BIM model; and a Defect Tracking Register. In Dubai, DEWA/DCD and DM will conduct their own independent inspections before issuing the Completion Certificate.

### Template E: Professional Risk Register for UAE Engineering Projects
Key project risks to track: BIM submission readiness; NOC expiry dates and renewal sequences; Specialist material lead times (high-performance concrete, specialist glazing, medical gas equipment); Third-party inspection availability; Civil Defense comments on fire systems; Authority variations discovered late in design; Structural peer review findings; Geotechnical report limitations; Weather restrictions on concrete pours; Power supply sequencing for DEWA connection; District Cooling provider connection timing; and Snagging management strategy for Completion Certificate.

## Additional Field Notes: Estidama, Al Sa'fat, and Environmental Practice

### Estidama Pearl Rating — Mandatory Credits
Every project in Abu Dhabi must achieve at least 1 Pearl. The mandatory credits include: Energy Efficiency (RE credits); Water Efficiency (IDP and WE credits); Indoor Environment Quality (IEQ credits); Site Management (SM credits); and Materials credits. Government-funded projects must achieve 2 Pearls. The credit documentation is submitted at design stage for the Design Rating, and then as-built for the Construction Rating. Failure to maintain Pearl status can prevent the Completion Certificate.

### Al Sa'fat Silver — Mandatory Credits
Every new building in Dubai under Dubai Municipality jurisdiction must achieve at least Silver Sa'fa under the Al Sa'fat system, which replaced the 2010 Green Building Regulations. The mandatory elements include compliance with DBC energy and water efficiency requirements, construction waste management plan, and building commissioning plan. Gold and Platinum ratings attract additional credits for renewable energy, rainwater harvesting, green roofs, cool roofs, and occupant monitoring systems.

### EIA Screening in Dubai
Dubai Municipality categorises projects into: Category A (screening only, no full EIA required); Category B (Summary EIA); and Category C (Full EIA with public consultation). Triggers for a Full EIA include: industrial facilities, quarries, landfills, major infrastructure, and projects within or near environmentally sensitive areas. The EIA must be reviewed and approved before the building permit is issued.

### Construction Waste Management
Both Al Sa'fat and Estidama require a Construction Waste Management Plan. The plan must set diversion targets (typically 75%+ from landfill), track waste types, demonstrate sorting on site, and provide disposal/recycling certificates. The main waste streams in UAE construction are: concrete rubble, steel scrap, packaging, gypsum board offcuts, and timber formwork.


## Extended Technical Reference: HSE and Materials Field Practice

### UAE Midday Break Regulation
The UAE Ministry of Human Resources and Emiratisation (MOHRE) mandates a midday work ban from **12:30 to 15:00** daily during the period **15 June to 15 September** for outdoor workers. Key compliance requirements:
- Contractors must post the ban notice on site in Arabic and English.
- Workers found outside during banned hours expose the employer to fines starting at AED 5,000 per worker per incident.
- Covered rest areas, cool drinking water, and shade must be provided regardless of the ban period.
- Heat stress first-aid arrangements (oral rehydration salts, cool water, trained first-aider) must be in place at all times during summer.

### Inspection and Test Plan (ITP) Structure
A UAE-compliant ITP defines three levels of control for every work activity:
- **H — Hold point:** Work cannot proceed beyond this stage without the Consultant/Authority inspector being physically present and signing off. Examples: pre-pour concrete inspection, pile integrity test, Civil Defense commissioning test.
- **W — Witness point:** Inspector is notified and should attend; if they do not attend within the agreed notice period (typically 24–48 hours), work may proceed with a recorded waiver. Examples: structural steel weld inspection, pressure testing.
- **R — Review point:** Inspector reviews the test record or document after the fact; does not attend. Examples: material delivery certificate, laboratory cube results.

### UAE Concrete Mix Design and Durability
A typical Class 2 (moderate exposure, building substructure) concrete mix for UAE:
- Cement type: SRPC (sulfate-resisting Portland cement) or OPC + 50% GGBS or 25% PFA.
- Maximum w/c ratio: 0.45.
- Minimum cementitious content: 360 kg/m³.
- Target characteristic strength: C35/45 (35 MPa cylinder / 45 MPa cube).
- Maximum chloride content: 0.20% by mass of cement for reinforced concrete.
- Maximum aggregate size: 20 mm (structural); 10 mm for dense reinforcement cages.
- Workability: S3 slump class (100–150 mm) or equivalent flow for pumpable mixes.
- Admixtures: Superplasticiser to achieve target workability at low w/c; retarder for summer pours to extend workability window.

### Inspection Checklist — Reinforced Concrete Pour
1. Approved concrete mix design and delivery note verified.
2. Fresh concrete temperature ≤32°C checked on first truck.
3. Slump test recorded.
4. Formwork and falsework inspected: correct dimensions, props plumb, wedges tight, release agent applied.
5. Reinforcement: bar marks match drawing; cover blocks in position; laps at approved positions; no mud or oil on bars.
6. Embedments: MEP sleeves, anchor bolts, drain outlets in correct position.
7. Authority inspector present or Hold point waived in writing.
8. Cube specimens: 6 cubes taken per 50 m³ (3 for 7-day, 3 for 28-day), properly labelled and stored.
9. Curing: wet hessian and polythene sheeting applied within 1 hour of pour completion; kept wet for 7 days minimum; curing compound not used on construction joints.
10. NCR raised immediately if any parameter out of specification.


## References

<p id="ref1" class="ref_item">[1] dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dmt.gov.ae/">https://www.dmt.gov.ae/</a></p>
<p id="ref2" class="ref_item">[2] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/al-safat-dubai-green-building-system/">https://www.dm.gov.ae/municipality-business/al-safat-dubai-green-building-system/</a></p>
<p id="ref3" class="ref_item">[3] u.ae <a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/strategies-initiatives-and-awards/strategies-plans-and-visions/environment-and-energy/the-uae-net-zero-2050-strategy*">https://u.ae/en/about-the-uae/strategies-initiatives-and-awards/strategies-plans-and-visions/environment-and-energy/the-uae-net-zero-2050-strategy*</a></p>
<p id="ref4" class="ref_item">[4] stonehaven.ae <a target="_blank" rel="noreferrer" href="https://www.stonehaven.ae/insights/stonehaven-deciphers-estidama-pearl-rating*">https://www.stonehaven.ae/insights/stonehaven-deciphers-estidama-pearl-rating*</a></p>
<p id="ref5" class="ref_item">[5] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/al-safat-dubai-green-building-system/*">https://www.dm.gov.ae/municipality-business/al-safat-dubai-green-building-system/*</a></p>
<p id="ref6" class="ref_item">[6] wkcgroup.com <a target="_blank" rel="noreferrer" href="https://www.wkcgroup.com/wp-content/uploads/2023/04/Guidance-on-the-Environmental-Clearance-Requirements-for-Development-Infrastructure-and-Industrial-Projects-in-the-Emirate-of-Dubai.pdf*">https://www.wkcgroup.com/wp-content/uploads/2023/04/Guidance-on-the-Environmental-Clearance-Requirements-for-Development-Infrastructure-and-Industrial-Projects-in-the-Emirate-of-Dubai.pdf*</a></p>
<p id="ref7" class="ref_item">[7] daralnaseeb.com <a target="_blank" rel="noreferrer" href="https://daralnaseeb.com/blog/al-safat-2-green-building-requirements-dubai-2026*">https://daralnaseeb.com/blog/al-safat-2-green-building-requirements-dubai-2026*</a></p>
<p id="ref8" class="ref_item">[8] aesg.com <a target="_blank" rel="noreferrer" href="https://aesg.com/perspective/the-impact-of-external-shading-windows-glazing-and-frame-on-thermal-performance-of-residential-house-in-abu-dhabi/*">https://aesg.com/perspective/the-impact-of-external-shading-windows-glazing-and-frame-on-thermal-performance-of-residential-house-in-abu-dhabi/*</a></p>
<p id="ref9" class="ref_item">[9] stonehaven.ae <a target="_blank" rel="noreferrer" href="https://www.stonehaven.ae/insights/stonehaven-deciphers-estidama-pearl-rating">https://www.stonehaven.ae/insights/stonehaven-deciphers-estidama-pearl-rating</a></p>
<p id="ref10" class="ref_item">[10] u.ae <a target="_blank" rel="noreferrer" href="https://u.ae/en/about-the-uae/strategies-initiatives-and-awards/strategies-plans-and-visions/environment-and-energy/the-uae-net-zero-2050-strategy">https://u.ae/en/about-the-uae/strategies-initiatives-and-awards/strategies-plans-and-visions/environment-and-energy/the-uae-net-zero-2050-strategy</a></p>
<p id="ref11" class="ref_item">[11] wkcgroup.com <a target="_blank" rel="noreferrer" href="https://www.wkcgroup.com/wp-content/uploads/2023/04/Guidance-on-the-Environmental-Clearance-Requirements-for-Development-Infrastructure-and-Industrial-Projects-in-the-Emirate-of-Dubai.pdf">https://www.wkcgroup.com/wp-content/uploads/2023/04/Guidance-on-the-Environmental-Clearance-Requirements-for-Development-Infrastructure-and-Industrial-Projects-in-the-Emirate-of-Dubai.pdf</a></p>
<p id="ref12" class="ref_item">[12] aesg.com <a target="_blank" rel="noreferrer" href="https://aesg.com/perspective/the-impact-of-external-shading-windows-glazing-and-frame-on-thermal-performance-of-residential-house-in-abu-dhabi/">https://aesg.com/perspective/the-impact-of-external-shading-windows-glazing-and-frame-on-thermal-performance-of-residential-house-in-abu-dhabi/</a></p>
<p id="ref13" class="ref_item">[13] daralnaseeb.com <a target="_blank" rel="noreferrer" href="https://daralnaseeb.com/blog/al-safat-2-green-building-requirements-dubai-2026">https://daralnaseeb.com/blog/al-safat-2-green-building-requirements-dubai-2026</a></p>
<p id="ref14" class="ref_item">[14] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/dubai-municipality-launches-comprehensive-safety-campaign-for-construction-sites-across-emirate/*">https://www.dm.gov.ae/dubai-municipality-launches-comprehensive-safety-campaign-for-construction-sites-across-emirate/*</a></p>
<p id="ref15" class="ref_item">[15] uaelegislation.gov.ae <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1541/download*">https://uaelegislation.gov.ae/en/legislations/1541/download*</a></p>
<p id="ref16" class="ref_item">[16] adphc.gov.ae <a target="_blank" rel="noreferrer" href="https://www.adphc.gov.ae/-/media/Project/ADPHC/ADPHC/PDF/OSHAD-SF/Codes-of-Practise/34---Safe-Use-of-Lifting-Eng.pdf*">https://www.adphc.gov.ae/-/media/Project/ADPHC/ADPHC/PDF/OSHAD-SF/Codes-of-Practise/34---Safe-Use-of-Lifting-Eng.pdf*</a></p>
<p id="ref17" class="ref_item">[17] scarlet-tech.com <a target="_blank" rel="noreferrer" href="https://scarlet-tech.com/crane-wind-speed-limit/*">https://scarlet-tech.com/crane-wind-speed-limit/*</a></p>
<p id="ref18" class="ref_item">[18] osha.gov <a target="_blank" rel="noreferrer" href="http://www.osha.gov/laws-regs/regulations/standardnumber/1926/1926.451*">http://www.osha.gov/laws-regs/regulations/standardnumber/1926/1926.451*</a></p>
<p id="ref19" class="ref_item">[19] indsci.com <a target="_blank" rel="noreferrer" href="https://www.indsci.com/en/blog/acceptable-and-dangerous-gas-levels-in-confined-spaces*">https://www.indsci.com/en/blog/acceptable-and-dangerous-gas-levels-in-confined-spaces*</a></p>
<p id="ref20" class="ref_item">[20] mohre.gov.ae <a target="_blank" rel="noreferrer" href="https://www.mohre.gov.ae/en/guidance-and-awareness-portal-new/the-midday-break*">https://www.mohre.gov.ae/en/guidance-and-awareness-portal-new/the-midday-break*</a></p>
<p id="ref21" class="ref_item">[21] gulfsustain.org <a target="_blank" rel="noreferrer" href="https://gulfsustain.org/insights/understanding-gcc-laws-heat-stress-recruitment-fees-and-migration-agreements*">https://gulfsustain.org/insights/understanding-gcc-laws-heat-stress-recruitment-fees-and-migration-agreements*</a></p>
<p id="ref22" class="ref_item">[22] uaelegislation.gov.ae <a target="_blank" rel="noreferrer" href="https://uaelegislation.gov.ae/en/legislations/1541/download">https://uaelegislation.gov.ae/en/legislations/1541/download</a></p>
<p id="ref23" class="ref_item">[23] adphc.gov.ae <a target="_blank" rel="noreferrer" href="https://www.adphc.gov.ae/-/media/Project/ADPHC/ADPHC/PDF/OSHAD-SF/Codes-of-Practise/34---Safe-Use-of-Lifting-Eng.pdf">https://www.adphc.gov.ae/-/media/Project/ADPHC/ADPHC/PDF/OSHAD-SF/Codes-of-Practise/34---Safe-Use-of-Lifting-Eng.pdf</a></p>
<p id="ref24" class="ref_item">[24] adphc.gov.ae <a target="_blank" rel="noreferrer" href="https://www.adphc.gov.ae/-/media/Project/ADPHC/ADPHC/PDF/OSHAD-SF/Codes-of-Practise/26---Scaffolding--Eng.pdf">https://www.adphc.gov.ae/-/media/Project/ADPHC/ADPHC/PDF/OSHAD-SF/Codes-of-Practise/26---Scaffolding--Eng.pdf</a></p>
<p id="ref25" class="ref_item">[25] adphc.gov.ae <a target="_blank" rel="noreferrer" href="https://www.adphc.gov.ae/-/media/Project/ADPHC/ADPHC/PDF/OSHAD-SF/Codes-of-Practise/27---Confined-Spaces--Eng-Updated.pdf">https://www.adphc.gov.ae/-/media/Project/ADPHC/ADPHC/PDF/OSHAD-SF/Codes-of-Practise/27---Confined-Spaces--Eng-Updated.pdf</a></p>
<p id="ref26" class="ref_item">[26] mohre.gov.ae <a target="_blank" rel="noreferrer" href="https://www.mohre.gov.ae/en/guidance-and-awareness-portal-new/the-midday-break">https://www.mohre.gov.ae/en/guidance-and-awareness-portal-new/the-midday-break</a></p>
<p id="ref27" class="ref_item">[27] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/dubai-municipality-launches-comprehensive-safety-campaign-for-construction-sites-across-emirate/">https://www.dm.gov.ae/dubai-municipality-launches-comprehensive-safety-campaign-for-construction-sites-across-emirate/</a></p>
<p id="ref28" class="ref_item">[28] scarlet-tech.com <a target="_blank" rel="noreferrer" href="https://scarlet-tech.com/crane-wind-speed-limit/">https://scarlet-tech.com/crane-wind-speed-limit/</a></p>
<p id="ref29" class="ref_item">[29] indsci.com <a target="_blank" rel="noreferrer" href="https://www.indsci.com/en/blog/acceptable-and-dangerous-gas-levels-in-confined-spaces">https://www.indsci.com/en/blog/acceptable-and-dangerous-gas-levels-in-confined-spaces</a></p>
<p id="ref30" class="ref_item">[30] gulfsustain.org <a target="_blank" rel="noreferrer" href="https://gulfsustain.org/insights/understanding-gcc-laws-heat-stress-recruitment-fees-and-migration-agreements">https://gulfsustain.org/insights/understanding-gcc-laws-heat-stress-recruitment-fees-and-migration-agreements</a></p>
<p id="ref31" class="ref_item">[31] dda.gov.ae <a target="_blank" rel="noreferrer" href="https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf">https://dda.gov.ae/-/media/Project/TECOM/Media/DDA/Planning-and-development/Design/pdf/Dubai-Building-Code_English_2021-Edition.pdf</a></p>
<p id="ref32" class="ref_item">[32] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/municipality-business/product-certification/">https://www.dm.gov.ae/municipality-business/product-certification/</a></p>
<p id="ref33" class="ref_item">[33] dmt.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dmt.gov.ae/-/media/Project/DMT/DMT/Codes/ADIBC_2013_bookmarked.pdf">https://www.dmt.gov.ae/-/media/Project/DMT/DMT/Codes/ADIBC_2013_bookmarked.pdf</a></p>
<p id="ref34" class="ref_item">[34] dm.gov.ae <a target="_blank" rel="noreferrer" href="https://www.dm.gov.ae/wp-content/uploads/2020/11/Circular-225-Attachment.pdf">https://www.dm.gov.ae/wp-content/uploads/2020/11/Circular-225-Attachment.pdf</a></p>
<p id="ref35" class="ref_item">[35] nrmca.org <a target="_blank" rel="noreferrer" href="https://www.nrmca.org/wp-content/uploads/2019/10/Dubai_IW_EPD20171009.pdf">https://www.nrmca.org/wp-content/uploads/2019/10/Dubai_IW_EPD20171009.pdf</a></p>
<p id="ref36" class="ref_item">[36] terrasearchgulf.com <a target="_blank" rel="noreferrer" href="https://terrasearchgulf.com/asphalt-testing-in-uae-how-quality-control-keeps-roads-safe-and-long-lasting/">https://terrasearchgulf.com/asphalt-testing-in-uae-how-quality-control-keeps-roads-safe-and-long-lasting/</a></p>
