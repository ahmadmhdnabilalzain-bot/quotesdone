# QuotesDone Knowledge Corpus — Category 15

## Hospitality Supplies

**Arabic working title:** مستلزمات الضيافة
**Version:** 2026.07.31
**Status:** research-complete production draft; not SME approved
**Subcategories:** 4

## Runtime purpose

This corpus supports customer-language routing, adaptive qualification, supplier eligibility, document extraction, UAE source retrieval, comparable RFQ generation, risk control and escalation for Hospitality Supplies. The large master file is for human audit. Runtime systems should use the atomic JSONL records, deterministic questions/rules and internal retrieval rather than placing this entire file in a model prompt.


# 1. Hotel amenities

**Arabic draft:** متطلبات Hotel amenities
**Slug:** `hotel-amenities`
**Aliases:** Hotel amenities

## Industry

### Industry scope — Hotel amenities

Hotel amenities is treated as a distinct procurement route within Hospitality Supplies. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers food, catering, hospitality operations, equipment, hygiene, production capacity and service delivery. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-015-hotel-amenities-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH

```json
{
  "category": "Hospitality Supplies",
  "subcategory": "Hotel amenities",
  "profile": "food",
  "aliases": [
    "Hotel amenities"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Hotel amenities

A normal UAE sourcing workflow for Hotel amenities moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-015-hotel-amenities-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH, UAE-CONSUMER-PROTECTION

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Hotel amenities

Customers may describe Hotel amenities through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-015-hotel-amenities-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Hotel amenities

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-015-hotel-amenities-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Hotel amenities product or service

The primary deliverable requested within Hotel amenities; exact type, quantity, performance, scope and acceptance must be normalized. For Hotel amenities, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-hotel-amenities-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Hotel amenities",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Hotel amenities

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Hotel amenities, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-hotel-amenities-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Hotel amenities",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Hotel amenities

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Hotel amenities, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-hotel-amenities-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Hotel amenities",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Hotel amenities

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Hotel amenities, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-hotel-amenities-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Hotel amenities",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Hotel amenities

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Hotel amenities, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-hotel-amenities-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Hotel amenities",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Hotel amenities

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Hotel amenities, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-hotel-amenities-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Hotel amenities",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Hotel amenities

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Hotel amenities, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-hotel-amenities-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Hotel amenities",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Hotel amenities

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Hotel amenities, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-hotel-amenities-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Hotel amenities",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Hotel Category And Brand Standard scope component

Hotel Category And Brand Standard is a recurring scope component for Hotel amenities. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-hotel-amenities-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "hotel category and brand standard",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Room/Outlet Count scope component

Room/Outlet Count is a recurring scope component for Hotel amenities. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-hotel-amenities-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "room/outlet count",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Consumable Usage scope component

Consumable Usage is a recurring scope component for Hotel amenities. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-hotel-amenities-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "consumable usage",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Fabric/Finish Durability scope component

Fabric/Finish Durability is a recurring scope component for Hotel amenities. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-hotel-amenities-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "fabric/finish durability",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Laundry/Housekeeping Interface scope component

Laundry/Housekeeping Interface is a recurring scope component for Hotel amenities. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-hotel-amenities-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "laundry/housekeeping interface",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Packaging And Replenishment scope component

Packaging And Replenishment is a recurring scope component for Hotel amenities. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-hotel-amenities-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "packaging and replenishment",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Sample Approval scope component

Sample Approval is a recurring scope component for Hotel amenities. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-hotel-amenities-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "sample approval",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: menu/product scope

For Hotel amenities, menu/product scope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "menu/product scope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: production or service capacity

For Hotel amenities, production or service capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "production or service capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: food-contact materials

For Hotel amenities, food-contact materials must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "food-contact materials",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: temperature control

For Hotel amenities, temperature control must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "temperature control",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: hygiene zoning

For Hotel amenities, hygiene zoning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "hygiene zoning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: utilities and drainage

For Hotel amenities, utilities and drainage must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "utilities and drainage",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: allergen and dietary controls

For Hotel amenities, allergen and dietary controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "allergen and dietary controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: packaging and shelf life

For Hotel amenities, packaging and shelf life must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "packaging and shelf life",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: cleaning and sanitation

For Hotel amenities, cleaning and sanitation must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "cleaning and sanitation",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: maintenance and calibration

For Hotel amenities, maintenance and calibration must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "maintenance and calibration",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: hotel category and brand standard

For Hotel amenities, hotel category and brand standard must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "hotel category and brand standard",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: room/outlet count

For Hotel amenities, room/outlet count must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "room/outlet count",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: consumable usage

For Hotel amenities, consumable usage must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "consumable usage",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: fabric/finish durability

For Hotel amenities, fabric/finish durability must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "fabric/finish durability",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: laundry/housekeeping interface

For Hotel amenities, laundry/housekeeping interface must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "laundry/housekeeping interface",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: packaging and replenishment

For Hotel amenities, packaging and replenishment must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "packaging and replenishment",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: sample approval

For Hotel amenities, sample approval must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-hotel-amenities-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "sample approval",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: licensed food establishment

A licensed food establishment may be relevant to Hotel amenities depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-hotel-amenities-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "licensed food establishment",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: manufacturer

A manufacturer may be relevant to Hotel amenities depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-hotel-amenities-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Hotel amenities depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-hotel-amenities-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: commercial kitchen contractor

A commercial kitchen contractor may be relevant to Hotel amenities depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-hotel-amenities-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "commercial kitchen contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: catering operator

A catering operator may be relevant to Hotel amenities depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-hotel-amenities-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "catering operator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: hospitality service provider

A hospitality service provider may be relevant to Hotel amenities depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-hotel-amenities-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "hospitality service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — licensed food establishment

This supplier type can participate in Hotel amenities only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-hotel-amenities-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "licensed food establishment",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — manufacturer

This supplier type can participate in Hotel amenities only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-hotel-amenities-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Hotel amenities only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-hotel-amenities-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — commercial kitchen contractor

This supplier type can participate in Hotel amenities only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-hotel-amenities-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "commercial kitchen contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — catering operator

This supplier type can participate in Hotel amenities only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-hotel-amenities-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "catering operator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — hospitality service provider

This supplier type can participate in Hotel amenities only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-hotel-amenities-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "hospitality service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance provider

This supplier type can participate in Hotel amenities only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-hotel-amenities-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — testing/certification provider

This supplier type can participate in Hotel amenities only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-hotel-amenities-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "testing/certification provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — licensed food establishment

Before routing a Hotel amenities inquiry to a licensed food establishment, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-hotel-amenities-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "licensed food establishment",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — manufacturer

Before routing a Hotel amenities inquiry to a manufacturer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-hotel-amenities-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "manufacturer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Hotel amenities inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-hotel-amenities-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — commercial kitchen contractor

Before routing a Hotel amenities inquiry to a commercial kitchen contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-hotel-amenities-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "commercial kitchen contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — catering operator

Before routing a Hotel amenities inquiry to a catering operator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-hotel-amenities-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "catering operator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — hospitality service provider

Before routing a Hotel amenities inquiry to a hospitality service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-hotel-amenities-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "hospitality service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance provider

Before routing a Hotel amenities inquiry to a maintenance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-hotel-amenities-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "maintenance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — testing/certification provider

Before routing a Hotel amenities inquiry to a testing/certification provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-hotel-amenities-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "testing/certification provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Hotel amenities should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-hotel-amenities-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Hotel amenities should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-hotel-amenities-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Hotel amenities should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-hotel-amenities-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Hotel amenities should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-hotel-amenities-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Hotel amenities should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-hotel-amenities-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Hotel amenities should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-hotel-amenities-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Hotel amenities should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-hotel-amenities-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Hotel amenities should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-hotel-amenities-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Hotel amenities should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-hotel-amenities-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Hotel amenities should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-hotel-amenities-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Menu Or Product List

Menu Or Product List may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "menu-or-product-list",
  "document_name": "menu or product list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Capacity Schedule

Capacity Schedule may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "capacity-schedule",
  "document_name": "capacity schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Kitchen/Production Layout

Kitchen/Production Layout may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "kitchen-production-layout",
  "document_name": "kitchen/production layout",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Utility Schedule

Utility Schedule may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "utility-schedule",
  "document_name": "utility schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Food-Safety Plan

Food-Safety Plan may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "food-safety-plan",
  "document_name": "food-safety plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Haccp Records

Haccp Records may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "haccp-records",
  "document_name": "HACCP records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Allergen Matrix

Allergen Matrix may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "allergen-matrix",
  "document_name": "allergen matrix",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Halal Evidence

Halal Evidence may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "halal-evidence",
  "document_name": "halal evidence",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Temperature Records

Temperature Records may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "temperature-records",
  "document_name": "temperature records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Licence/Permit

Licence/Permit may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "licence-permit",
  "document_name": "licence/permit",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Cleaning Plan

Cleaning Plan may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "cleaning-plan",
  "document_name": "cleaning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Maintenance/Calibration Records

Maintenance/Calibration Records may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "maintenance-calibration-records",
  "document_name": "maintenance/calibration records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quotation Scope Matrix

Quotation Scope Matrix may provide or verify information needed for Hotel amenities. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-hotel-amenities-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quotation-scope-matrix",
  "document_name": "quotation scope matrix",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Dubai Municipality Food Safety Publications and Food Code

For Hotel amenities, consult Dubai Municipality Food Safety Publications and Food Code when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-hotel-amenities-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-FOOD

```json
{
  "source_id": "UAE-DM-FOOD",
  "publisher": "Dubai Municipality",
  "source_type": "government_food_safety_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Abu Dhabi Food Safety and Agriculture Authority Requirements

For Hotel amenities, consult Abu Dhabi Food Safety and Agriculture Authority Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-hotel-amenities-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADAFSA

```json
{
  "source_id": "UAE-ADAFSA",
  "publisher": "ADAFSA",
  "source_type": "government_food_agriculture_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Municipality Public Health and Safety Services

For Hotel amenities, consult Dubai Municipality Public Health and Safety Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-hotel-amenities-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-PUBLIC-HEALTH

```json
{
  "source_id": "UAE-DM-PUBLIC-HEALTH",
  "publisher": "Dubai Municipality",
  "source_type": "government_health_safety_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Consumer Protection Legislation

For Hotel amenities, consult UAE Consumer Protection Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-hotel-amenities-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION

```json
{
  "source_id": "UAE-CONSUMER-PROTECTION",
  "publisher": "UAE Legislation / Ministry of Economy",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Industrial, Standards, Conformity and Quality Services

For Hotel amenities, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-hotel-amenities-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Hotel amenities, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-hotel-amenities-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Hotel amenities. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-hotel-amenities-commercial_pricing-cost_driver-0089`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Hotel amenities. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-hotel-amenities-commercial_pricing-cost_driver-0091`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Hotel amenities. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-hotel-amenities-commercial_pricing-cost_driver-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Hotel amenities. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-hotel-amenities-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Hotel amenities. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-hotel-amenities-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Hotel amenities. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-hotel-amenities-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Hotel amenities. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-hotel-amenities-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Hotel amenities. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-hotel-amenities-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Hotel amenities. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-hotel-amenities-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Hotel amenities. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-hotel-amenities-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-hotel-amenities-customer_tradeoffs-tradeoff-0090`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-hotel-amenities-customer_tradeoffs-tradeoff-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-hotel-amenities-customer_tradeoffs-tradeoff-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-hotel-amenities-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-hotel-amenities-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-hotel-amenities-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-hotel-amenities-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-hotel-amenities-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-hotel-amenities-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-hotel-amenities-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Hotel amenities, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-hotel-amenities-risk-risk_control-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Hotel amenities, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-hotel-amenities-risk-risk_control-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Hotel amenities, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-hotel-amenities-risk-risk_control-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Hotel amenities, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-hotel-amenities-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Hotel amenities, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-hotel-amenities-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Hotel amenities, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-hotel-amenities-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Hotel amenities, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-hotel-amenities-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Hotel amenities, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-hotel-amenities-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Hotel amenities, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-hotel-amenities-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Hotel amenities, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-hotel-amenities-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Hotel amenities, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-hotel-amenities-best_practices-qualification_best_practice-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Hotel amenities, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-hotel-amenities-best_practices-qualification_best_practice-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Hotel amenities, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-hotel-amenities-best_practices-qualification_best_practice-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Hotel amenities, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-hotel-amenities-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Hotel amenities, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-hotel-amenities-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Hotel amenities, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-hotel-amenities-best_practices-qualification_best_practice-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Hotel amenities; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-hotel-amenities-troubleshooting-recovery_guidance-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Hotel amenities; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-hotel-amenities-troubleshooting-recovery_guidance-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Hotel amenities; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-hotel-amenities-troubleshooting-recovery_guidance-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Hotel amenities; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-hotel-amenities-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Hotel amenities; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-hotel-amenities-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Hotel amenities; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-hotel-amenities-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Hotel amenities; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-hotel-amenities-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Hotel amenities; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-hotel-amenities-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What food, beverage, menu, production process or hospitality service is required?

Ask in plain language: What food, beverage, menu, production process or hospitality service is required? Arabic draft: ما الطعام أو الشراب أو القائمة أو عملية الإنتاج أو خدمة الضيافة المطلوبة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-menu-product-scope",
  "question_en": "What food, beverage, menu, production process or hospitality service is required?",
  "question_ar": "ما الطعام أو الشراب أو القائمة أو عملية الإنتاج أو خدمة الضيافة المطلوبة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "menu-product-scope",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What food, beverage, menu, production process or hospitality service is required? is missing

When the normalized field menu-product-scope is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-menu-product-scope",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "menu-product-scope",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-menu-product-scope"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What daily, hourly, batch, guest or outlet capacity is required?

Ask in plain language: What daily, hourly, batch, guest or outlet capacity is required? Arabic draft: ما السعة اليومية أو بالساعة أو لكل دفعة أو عدد الضيوف أو المنافذ؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-capacity-volume",
  "question_en": "What daily, hourly, batch, guest or outlet capacity is required?",
  "question_ar": "ما السعة اليومية أو بالساعة أو لكل دفعة أو عدد الضيوف أو المنافذ؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-volume",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What daily, hourly, batch, guest or outlet capacity is required? is missing

When the normalized field capacity-volume is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-capacity-volume",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-volume",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-capacity-volume"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What food-safety, hygiene, allergen, halal and traceability controls apply?

Ask in plain language: What food-safety, hygiene, allergen, halal and traceability controls apply? Arabic draft: ما ضوابط سلامة الغذاء والنظافة والحساسية والحلال والتتبع المطلوبة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-food-safety",
  "question_en": "What food-safety, hygiene, allergen, halal and traceability controls apply?",
  "question_ar": "ما ضوابط سلامة الغذاء والنظافة والحساسية والحلال والتتبع المطلوبة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "food-safety",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What food-safety, hygiene, allergen, halal and traceability controls apply? is missing

When the normalized field food-safety is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-food-safety",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "food-safety",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-food-safety"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What cooking, chilling, freezing, holding, transport or display temperatures apply?

Ask in plain language: What cooking, chilling, freezing, holding, transport or display temperatures apply? Arabic draft: ما درجات الطهي أو التبريد أو التجميد أو الحفظ أو النقل أو العرض؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-temperature-chain",
  "question_en": "What cooking, chilling, freezing, holding, transport or display temperatures apply?",
  "question_ar": "ما درجات الطهي أو التبريد أو التجميد أو الحفظ أو النقل أو العرض؟",
  "expected_answer_type": "table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "temperature-chain",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available?

Ask in plain language: What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available? Arabic draft: ما التخطيط والطاقة والغاز والماء والصرف والتهوية والشفط المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-utilities-layout",
  "question_en": "What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available?",
  "question_ar": "ما التخطيط والطاقة والغاز والماء والصرف والتهوية والشفط المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-layout",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available? is missing

When the normalized field utilities-layout is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-utilities-layout",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-layout",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-utilities-layout"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation?

Ask in plain language: Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation? Arabic draft: هل النطاق توريد أو إيجار أو خدمة مدارة أو موظفين أو تركيب أو صيانة أو تشغيل كامل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-service-model",
  "question_en": "Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation?",
  "question_ar": "هل النطاق توريد أو إيجار أو خدمة مدارة أو موظفين أو تركيب أو صيانة أو تشغيل كامل؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "service-model",
  "order": 180,
  "confidence_contribution": 0.03
}
```

### Ask when Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation? is missing

When the normalized field service-model is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-service-model",
  "priority": 982,
  "when": {
    "all": [
      {
        "field": "service-model",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-service-model"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which municipality, food authority, venue or event approvals are required?

Ask in plain language: Which municipality, food authority, venue or event approvals are required? Arabic draft: ما موافقات البلدية أو جهة الغذاء أو المكان أو الفعالية المطلوبة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-licences-approvals",
  "question_en": "Which municipality, food authority, venue or event approvals are required?",
  "question_ar": "ما موافقات البلدية أو جهة الغذاء أو المكان أو الفعالية المطلوبة؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "licences-approvals",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### Please clarify the hotel category and brand standard requirements for Hotel amenities.

Ask in plain language: Please clarify the hotel category and brand standard requirements for Hotel amenities. Arabic draft: يرجى توضيح متطلبات hotel category and brand standard الخاصة بـ Hotel amenities. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-facet-01",
  "question_en": "Please clarify the hotel category and brand standard requirements for Hotel amenities.",
  "question_ar": "يرجى توضيح متطلبات hotel category and brand standard الخاصة بـ Hotel amenities.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the hotel category and brand standard requirements for Hotel amenities. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-facet-01",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the room/outlet count requirements for Hotel amenities.

Ask in plain language: Please clarify the room/outlet count requirements for Hotel amenities. Arabic draft: يرجى توضيح متطلبات room/outlet count الخاصة بـ Hotel amenities. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-facet-02",
  "question_en": "Please clarify the room/outlet count requirements for Hotel amenities.",
  "question_ar": "يرجى توضيح متطلبات room/outlet count الخاصة بـ Hotel amenities.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the room/outlet count requirements for Hotel amenities. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-facet-02",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the consumable usage requirements for Hotel amenities.

Ask in plain language: Please clarify the consumable usage requirements for Hotel amenities. Arabic draft: يرجى توضيح متطلبات consumable usage الخاصة بـ Hotel amenities. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-facet-03",
  "question_en": "Please clarify the consumable usage requirements for Hotel amenities.",
  "question_ar": "يرجى توضيح متطلبات consumable usage الخاصة بـ Hotel amenities.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the consumable usage requirements for Hotel amenities. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-facet-03",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the fabric/finish durability requirements for Hotel amenities.

Ask in plain language: Please clarify the fabric/finish durability requirements for Hotel amenities. Arabic draft: يرجى توضيح متطلبات fabric/finish durability الخاصة بـ Hotel amenities. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-facet-04",
  "question_en": "Please clarify the fabric/finish durability requirements for Hotel amenities.",
  "question_ar": "يرجى توضيح متطلبات fabric/finish durability الخاصة بـ Hotel amenities.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 230,
  "confidence_contribution": 0.012
}
```

### Please clarify the laundry/housekeeping interface requirements for Hotel amenities.

Ask in plain language: Please clarify the laundry/housekeeping interface requirements for Hotel amenities. Arabic draft: يرجى توضيح متطلبات laundry/housekeeping interface الخاصة بـ Hotel amenities. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-facet-05",
  "question_en": "Please clarify the laundry/housekeeping interface requirements for Hotel amenities.",
  "question_ar": "يرجى توضيح متطلبات laundry/housekeeping interface الخاصة بـ Hotel amenities.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the packaging and replenishment requirements for Hotel amenities.

Ask in plain language: Please clarify the packaging and replenishment requirements for Hotel amenities. Arabic draft: يرجى توضيح متطلبات packaging and replenishment الخاصة بـ Hotel amenities. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-facet-06",
  "question_en": "Please clarify the packaging and replenishment requirements for Hotel amenities.",
  "question_ar": "يرجى توضيح متطلبات packaging and replenishment الخاصة بـ Hotel amenities.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the sample approval requirements for Hotel amenities.

Ask in plain language: Please clarify the sample approval requirements for Hotel amenities. Arabic draft: يرجى توضيح متطلبات sample approval الخاصة بـ Hotel amenities. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-facet-07",
  "question_en": "Please clarify the sample approval requirements for Hotel amenities.",
  "question_ar": "يرجى توضيح متطلبات sample approval الخاصة بـ Hotel amenities.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Which exact Hotel amenities product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Hotel amenities product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Hotel amenities التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-exact-subtype",
  "question_en": "Which exact Hotel amenities product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Hotel amenities التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 270,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Hotel amenities product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-ask-exact-subtype",
  "priority": 973,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-hotel-amenities-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Hotel amenities are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Hotel amenities are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Hotel amenities التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-unknowns",
  "question_en": "Which details about Hotel amenities are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Hotel amenities التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 280,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Hotel amenities?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Hotel amenities? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Hotel amenities؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-hotel-amenities-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Hotel amenities?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Hotel amenities؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Hotel amenities, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Hotel amenities, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Hotel amenities, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Hotel amenities, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0182`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH, UAE-CONSUMER-PROTECTION, UAE-MOIAT, ISO-STANDARDS

```json
{
  "rule_id": "R-015-hotel-amenities-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-DM-FOOD",
        "UAE-ADAFSA",
        "UAE-DM-PUBLIC-HEALTH",
        "UAE-CONSUMER-PROTECTION",
        "UAE-MOIAT",
        "ISO-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Hotel amenities, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Hotel amenities, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Hotel amenities, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Hotel amenities, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-hotel-amenities-inquiry_qualification-decision_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-hotel-amenities-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Hotel amenities, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-hotel-amenities-validation-validation_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-hotel-amenities-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Hotel amenities, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-hotel-amenities-validation-validation_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-hotel-amenities-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Hotel amenities, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-hotel-amenities-validation-validation_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-hotel-amenities-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Hotel amenities, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-hotel-amenities-validation-validation_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-hotel-amenities-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Hotel amenities, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-hotel-amenities-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-hotel-amenities-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Hotel amenities, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-hotel-amenities-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-hotel-amenities-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Hotel amenities, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-hotel-amenities-validation-validation_rule-0193`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "validation_id": "V-015-hotel-amenities-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Hotel amenities, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-hotel-amenities-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-hotel-amenities-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Hotel amenities, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-hotel-amenities-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-hotel-amenities-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Hotel amenities, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-hotel-amenities-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-hotel-amenities-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Hotel amenities without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-hotel-amenities-scenario_test-scenario-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-hotel-amenities-001",
  "setup": "Customer asks informally for Hotel amenities without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Hotel amenities with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-hotel-amenities-scenario_test-scenario-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-hotel-amenities-002",
  "setup": "Customer requests price for Hotel amenities with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Hotel amenities. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-hotel-amenities-scenario_test-scenario-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-hotel-amenities-003",
  "setup": "Customer uploads a relevant schedule/specification for Hotel amenities.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Hotel amenities. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-hotel-amenities-scenario_test-scenario-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-hotel-amenities-004",
  "setup": "Customer message and uploaded document disagree on Hotel amenities.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Hotel amenities. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-hotel-amenities-scenario_test-scenario-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-hotel-amenities-005",
  "setup": "Supplier proposes a different product, provider or method for Hotel amenities.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Hotel amenities sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-hotel-amenities-scenario_test-scenario-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-hotel-amenities-006",
  "setup": "Customer needs Hotel amenities sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Hotel amenities needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-hotel-amenities-scenario_test-scenario-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-hotel-amenities-007",
  "setup": "The request for Hotel amenities needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Hotel amenities

English term: Hotel amenities. Arabic operational draft: متطلبات Hotel amenities. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Hotel amenities",
  "term_ar": "متطلبات Hotel amenities",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### hotel category and brand standard

English term: hotel category and brand standard. Arabic operational draft: متطلبات hotel category and brand standard. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "hotel category and brand standard",
  "term_ar": "متطلبات hotel category and brand standard",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### room/outlet count

English term: room/outlet count. Arabic operational draft: متطلبات room/outlet count. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "room/outlet count",
  "term_ar": "متطلبات room/outlet count",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### consumable usage

English term: consumable usage. Arabic operational draft: متطلبات consumable usage. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "consumable usage",
  "term_ar": "متطلبات consumable usage",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### fabric/finish durability

English term: fabric/finish durability. Arabic operational draft: متطلبات fabric/finish durability. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "fabric/finish durability",
  "term_ar": "متطلبات fabric/finish durability",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### laundry/housekeeping interface

English term: laundry/housekeeping interface. Arabic operational draft: متطلبات laundry/housekeeping interface. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "laundry/housekeeping interface",
  "term_ar": "متطلبات laundry/housekeeping interface",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### packaging and replenishment

English term: packaging and replenishment. Arabic operational draft: متطلبات packaging and replenishment. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "packaging and replenishment",
  "term_ar": "متطلبات packaging and replenishment",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```

### sample approval

English term: sample approval. Arabic operational draft: متطلبات sample approval. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-hotel-amenities-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "sample approval",
  "term_ar": "متطلبات sample approval",
  "canonical_subcategory": "hotel-amenities",
  "normalization_only": true
}
```


# 2. Housekeeping supplies

**Arabic draft:** متطلبات Housekeeping supplies
**Slug:** `housekeeping-supplies`
**Aliases:** Housekeeping supplies

## Industry

### Industry scope — Housekeeping supplies

Housekeeping supplies is treated as a distinct procurement route within Hospitality Supplies. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers food, catering, hospitality operations, equipment, hygiene, production capacity and service delivery. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-015-housekeeping-supplies-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH

```json
{
  "category": "Hospitality Supplies",
  "subcategory": "Housekeeping supplies",
  "profile": "food",
  "aliases": [
    "Housekeeping supplies"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Housekeeping supplies

A normal UAE sourcing workflow for Housekeeping supplies moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-015-housekeeping-supplies-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH, UAE-CONSUMER-PROTECTION

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Housekeeping supplies

Customers may describe Housekeeping supplies through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-015-housekeeping-supplies-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Housekeeping supplies

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-015-housekeeping-supplies-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Housekeeping supplies product or service

The primary deliverable requested within Housekeeping supplies; exact type, quantity, performance, scope and acceptance must be normalized. For Housekeeping supplies, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Housekeeping supplies",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Housekeeping supplies

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Housekeeping supplies, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Housekeeping supplies",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Housekeeping supplies

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Housekeeping supplies, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Housekeeping supplies",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Housekeeping supplies

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Housekeeping supplies, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Housekeeping supplies",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Housekeeping supplies

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Housekeeping supplies, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Housekeeping supplies",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Housekeeping supplies

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Housekeeping supplies, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Housekeeping supplies",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Housekeeping supplies

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Housekeeping supplies, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Housekeeping supplies",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Housekeeping supplies

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Housekeeping supplies, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Housekeeping supplies",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Hotel Category And Brand Standard scope component

Hotel Category And Brand Standard is a recurring scope component for Housekeeping supplies. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "hotel category and brand standard",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Room/Outlet Count scope component

Room/Outlet Count is a recurring scope component for Housekeeping supplies. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "room/outlet count",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Consumable Usage scope component

Consumable Usage is a recurring scope component for Housekeeping supplies. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "consumable usage",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Fabric/Finish Durability scope component

Fabric/Finish Durability is a recurring scope component for Housekeeping supplies. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "fabric/finish durability",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Laundry/Housekeeping Interface scope component

Laundry/Housekeeping Interface is a recurring scope component for Housekeeping supplies. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "laundry/housekeeping interface",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Packaging And Replenishment scope component

Packaging And Replenishment is a recurring scope component for Housekeeping supplies. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "packaging and replenishment",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Sample Approval scope component

Sample Approval is a recurring scope component for Housekeeping supplies. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-housekeeping-supplies-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "sample approval",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: menu/product scope

For Housekeeping supplies, menu/product scope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "menu/product scope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: production or service capacity

For Housekeeping supplies, production or service capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "production or service capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: food-contact materials

For Housekeeping supplies, food-contact materials must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "food-contact materials",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: temperature control

For Housekeeping supplies, temperature control must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "temperature control",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: hygiene zoning

For Housekeeping supplies, hygiene zoning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "hygiene zoning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: utilities and drainage

For Housekeeping supplies, utilities and drainage must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "utilities and drainage",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: allergen and dietary controls

For Housekeeping supplies, allergen and dietary controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "allergen and dietary controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: packaging and shelf life

For Housekeeping supplies, packaging and shelf life must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "packaging and shelf life",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: cleaning and sanitation

For Housekeeping supplies, cleaning and sanitation must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "cleaning and sanitation",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: maintenance and calibration

For Housekeeping supplies, maintenance and calibration must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "maintenance and calibration",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: hotel category and brand standard

For Housekeeping supplies, hotel category and brand standard must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "hotel category and brand standard",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: room/outlet count

For Housekeeping supplies, room/outlet count must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "room/outlet count",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: consumable usage

For Housekeeping supplies, consumable usage must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "consumable usage",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: fabric/finish durability

For Housekeeping supplies, fabric/finish durability must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "fabric/finish durability",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: laundry/housekeeping interface

For Housekeeping supplies, laundry/housekeeping interface must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "laundry/housekeeping interface",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: packaging and replenishment

For Housekeeping supplies, packaging and replenishment must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "packaging and replenishment",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: sample approval

For Housekeeping supplies, sample approval must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-housekeeping-supplies-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "sample approval",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: licensed food establishment

A licensed food establishment may be relevant to Housekeeping supplies depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-housekeeping-supplies-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "licensed food establishment",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: manufacturer

A manufacturer may be relevant to Housekeeping supplies depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-housekeeping-supplies-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Housekeeping supplies depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-housekeeping-supplies-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: commercial kitchen contractor

A commercial kitchen contractor may be relevant to Housekeeping supplies depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-housekeeping-supplies-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "commercial kitchen contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: catering operator

A catering operator may be relevant to Housekeeping supplies depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-housekeeping-supplies-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "catering operator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: hospitality service provider

A hospitality service provider may be relevant to Housekeeping supplies depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-housekeeping-supplies-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "hospitality service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — licensed food establishment

This supplier type can participate in Housekeeping supplies only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "licensed food establishment",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — manufacturer

This supplier type can participate in Housekeeping supplies only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Housekeeping supplies only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — commercial kitchen contractor

This supplier type can participate in Housekeeping supplies only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "commercial kitchen contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — catering operator

This supplier type can participate in Housekeeping supplies only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "catering operator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — hospitality service provider

This supplier type can participate in Housekeeping supplies only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "hospitality service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance provider

This supplier type can participate in Housekeeping supplies only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — testing/certification provider

This supplier type can participate in Housekeeping supplies only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "testing/certification provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — licensed food establishment

Before routing a Housekeeping supplies inquiry to a licensed food establishment, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "licensed food establishment",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — manufacturer

Before routing a Housekeeping supplies inquiry to a manufacturer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "manufacturer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Housekeeping supplies inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — commercial kitchen contractor

Before routing a Housekeeping supplies inquiry to a commercial kitchen contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "commercial kitchen contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — catering operator

Before routing a Housekeeping supplies inquiry to a catering operator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "catering operator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — hospitality service provider

Before routing a Housekeeping supplies inquiry to a hospitality service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "hospitality service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance provider

Before routing a Housekeeping supplies inquiry to a maintenance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "maintenance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — testing/certification provider

Before routing a Housekeeping supplies inquiry to a testing/certification provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-housekeeping-supplies-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "testing/certification provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Housekeeping supplies should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-housekeeping-supplies-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Housekeeping supplies should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-housekeeping-supplies-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Housekeeping supplies should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-housekeeping-supplies-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Housekeeping supplies should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-housekeeping-supplies-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Housekeeping supplies should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-housekeeping-supplies-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Housekeeping supplies should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-housekeeping-supplies-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Housekeeping supplies should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-housekeeping-supplies-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Housekeeping supplies should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-housekeeping-supplies-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Housekeeping supplies should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-housekeeping-supplies-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Housekeeping supplies should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-housekeeping-supplies-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Menu Or Product List

Menu Or Product List may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "menu-or-product-list",
  "document_name": "menu or product list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Capacity Schedule

Capacity Schedule may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "capacity-schedule",
  "document_name": "capacity schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Kitchen/Production Layout

Kitchen/Production Layout may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "kitchen-production-layout",
  "document_name": "kitchen/production layout",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Utility Schedule

Utility Schedule may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "utility-schedule",
  "document_name": "utility schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Food-Safety Plan

Food-Safety Plan may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "food-safety-plan",
  "document_name": "food-safety plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Haccp Records

Haccp Records may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "haccp-records",
  "document_name": "HACCP records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Allergen Matrix

Allergen Matrix may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "allergen-matrix",
  "document_name": "allergen matrix",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Halal Evidence

Halal Evidence may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "halal-evidence",
  "document_name": "halal evidence",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Temperature Records

Temperature Records may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "temperature-records",
  "document_name": "temperature records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Licence/Permit

Licence/Permit may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "licence-permit",
  "document_name": "licence/permit",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Cleaning Plan

Cleaning Plan may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "cleaning-plan",
  "document_name": "cleaning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Maintenance/Calibration Records

Maintenance/Calibration Records may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "maintenance-calibration-records",
  "document_name": "maintenance/calibration records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quotation Scope Matrix

Quotation Scope Matrix may provide or verify information needed for Housekeeping supplies. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-housekeeping-supplies-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quotation-scope-matrix",
  "document_name": "quotation scope matrix",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Dubai Municipality Food Safety Publications and Food Code

For Housekeeping supplies, consult Dubai Municipality Food Safety Publications and Food Code when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-housekeeping-supplies-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-FOOD

```json
{
  "source_id": "UAE-DM-FOOD",
  "publisher": "Dubai Municipality",
  "source_type": "government_food_safety_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Abu Dhabi Food Safety and Agriculture Authority Requirements

For Housekeeping supplies, consult Abu Dhabi Food Safety and Agriculture Authority Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-housekeeping-supplies-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADAFSA

```json
{
  "source_id": "UAE-ADAFSA",
  "publisher": "ADAFSA",
  "source_type": "government_food_agriculture_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Municipality Public Health and Safety Services

For Housekeeping supplies, consult Dubai Municipality Public Health and Safety Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-housekeeping-supplies-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-PUBLIC-HEALTH

```json
{
  "source_id": "UAE-DM-PUBLIC-HEALTH",
  "publisher": "Dubai Municipality",
  "source_type": "government_health_safety_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Consumer Protection Legislation

For Housekeeping supplies, consult UAE Consumer Protection Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-housekeeping-supplies-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION

```json
{
  "source_id": "UAE-CONSUMER-PROTECTION",
  "publisher": "UAE Legislation / Ministry of Economy",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Industrial, Standards, Conformity and Quality Services

For Housekeeping supplies, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-housekeeping-supplies-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Housekeeping supplies, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-housekeeping-supplies-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Housekeeping supplies. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-housekeeping-supplies-commercial_pricing-cost_driver-0089`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Housekeeping supplies. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-housekeeping-supplies-commercial_pricing-cost_driver-0091`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Housekeeping supplies. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-housekeeping-supplies-commercial_pricing-cost_driver-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Housekeeping supplies. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-housekeeping-supplies-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Housekeeping supplies. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-housekeeping-supplies-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Housekeeping supplies. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-housekeeping-supplies-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Housekeeping supplies. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-housekeeping-supplies-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Housekeeping supplies. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-housekeeping-supplies-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Housekeeping supplies. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-housekeeping-supplies-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Housekeeping supplies. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-housekeeping-supplies-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-customer_tradeoffs-tradeoff-0090`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-customer_tradeoffs-tradeoff-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-customer_tradeoffs-tradeoff-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Housekeeping supplies, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-housekeeping-supplies-risk-risk_control-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Housekeeping supplies, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-housekeeping-supplies-risk-risk_control-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Housekeeping supplies, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-housekeeping-supplies-risk-risk_control-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Housekeeping supplies, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-housekeeping-supplies-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Housekeeping supplies, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-housekeeping-supplies-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Housekeeping supplies, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-housekeeping-supplies-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Housekeeping supplies, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-housekeeping-supplies-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Housekeeping supplies, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-housekeeping-supplies-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Housekeeping supplies, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-housekeeping-supplies-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Housekeeping supplies, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-housekeeping-supplies-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Housekeeping supplies, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-housekeeping-supplies-best_practices-qualification_best_practice-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Housekeeping supplies, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-housekeeping-supplies-best_practices-qualification_best_practice-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Housekeeping supplies, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-housekeeping-supplies-best_practices-qualification_best_practice-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Housekeeping supplies, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-housekeeping-supplies-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Housekeeping supplies, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-housekeeping-supplies-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Housekeeping supplies, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-housekeeping-supplies-best_practices-qualification_best_practice-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Housekeeping supplies; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-housekeeping-supplies-troubleshooting-recovery_guidance-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Housekeeping supplies; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-housekeeping-supplies-troubleshooting-recovery_guidance-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Housekeeping supplies; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-housekeeping-supplies-troubleshooting-recovery_guidance-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Housekeeping supplies; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-housekeeping-supplies-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Housekeeping supplies; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-housekeeping-supplies-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Housekeeping supplies; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-housekeeping-supplies-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Housekeeping supplies; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-housekeeping-supplies-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Housekeeping supplies; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-housekeeping-supplies-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What food, beverage, menu, production process or hospitality service is required?

Ask in plain language: What food, beverage, menu, production process or hospitality service is required? Arabic draft: ما الطعام أو الشراب أو القائمة أو عملية الإنتاج أو خدمة الضيافة المطلوبة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-menu-product-scope",
  "question_en": "What food, beverage, menu, production process or hospitality service is required?",
  "question_ar": "ما الطعام أو الشراب أو القائمة أو عملية الإنتاج أو خدمة الضيافة المطلوبة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "menu-product-scope",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What food, beverage, menu, production process or hospitality service is required? is missing

When the normalized field menu-product-scope is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-menu-product-scope",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "menu-product-scope",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-menu-product-scope"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What daily, hourly, batch, guest or outlet capacity is required?

Ask in plain language: What daily, hourly, batch, guest or outlet capacity is required? Arabic draft: ما السعة اليومية أو بالساعة أو لكل دفعة أو عدد الضيوف أو المنافذ؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-capacity-volume",
  "question_en": "What daily, hourly, batch, guest or outlet capacity is required?",
  "question_ar": "ما السعة اليومية أو بالساعة أو لكل دفعة أو عدد الضيوف أو المنافذ؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-volume",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What daily, hourly, batch, guest or outlet capacity is required? is missing

When the normalized field capacity-volume is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-capacity-volume",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-volume",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-capacity-volume"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What food-safety, hygiene, allergen, halal and traceability controls apply?

Ask in plain language: What food-safety, hygiene, allergen, halal and traceability controls apply? Arabic draft: ما ضوابط سلامة الغذاء والنظافة والحساسية والحلال والتتبع المطلوبة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-food-safety",
  "question_en": "What food-safety, hygiene, allergen, halal and traceability controls apply?",
  "question_ar": "ما ضوابط سلامة الغذاء والنظافة والحساسية والحلال والتتبع المطلوبة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "food-safety",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What food-safety, hygiene, allergen, halal and traceability controls apply? is missing

When the normalized field food-safety is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-food-safety",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "food-safety",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-food-safety"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What cooking, chilling, freezing, holding, transport or display temperatures apply?

Ask in plain language: What cooking, chilling, freezing, holding, transport or display temperatures apply? Arabic draft: ما درجات الطهي أو التبريد أو التجميد أو الحفظ أو النقل أو العرض؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-temperature-chain",
  "question_en": "What cooking, chilling, freezing, holding, transport or display temperatures apply?",
  "question_ar": "ما درجات الطهي أو التبريد أو التجميد أو الحفظ أو النقل أو العرض؟",
  "expected_answer_type": "table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "temperature-chain",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available?

Ask in plain language: What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available? Arabic draft: ما التخطيط والطاقة والغاز والماء والصرف والتهوية والشفط المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-utilities-layout",
  "question_en": "What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available?",
  "question_ar": "ما التخطيط والطاقة والغاز والماء والصرف والتهوية والشفط المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-layout",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available? is missing

When the normalized field utilities-layout is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-utilities-layout",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-layout",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-utilities-layout"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation?

Ask in plain language: Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation? Arabic draft: هل النطاق توريد أو إيجار أو خدمة مدارة أو موظفين أو تركيب أو صيانة أو تشغيل كامل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-service-model",
  "question_en": "Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation?",
  "question_ar": "هل النطاق توريد أو إيجار أو خدمة مدارة أو موظفين أو تركيب أو صيانة أو تشغيل كامل؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "service-model",
  "order": 180,
  "confidence_contribution": 0.03
}
```

### Ask when Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation? is missing

When the normalized field service-model is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-service-model",
  "priority": 982,
  "when": {
    "all": [
      {
        "field": "service-model",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-service-model"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which municipality, food authority, venue or event approvals are required?

Ask in plain language: Which municipality, food authority, venue or event approvals are required? Arabic draft: ما موافقات البلدية أو جهة الغذاء أو المكان أو الفعالية المطلوبة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-licences-approvals",
  "question_en": "Which municipality, food authority, venue or event approvals are required?",
  "question_ar": "ما موافقات البلدية أو جهة الغذاء أو المكان أو الفعالية المطلوبة؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "licences-approvals",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### Please clarify the hotel category and brand standard requirements for Housekeeping supplies.

Ask in plain language: Please clarify the hotel category and brand standard requirements for Housekeeping supplies. Arabic draft: يرجى توضيح متطلبات hotel category and brand standard الخاصة بـ Housekeeping supplies. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-facet-01",
  "question_en": "Please clarify the hotel category and brand standard requirements for Housekeeping supplies.",
  "question_ar": "يرجى توضيح متطلبات hotel category and brand standard الخاصة بـ Housekeeping supplies.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the hotel category and brand standard requirements for Housekeeping supplies. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-facet-01",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the room/outlet count requirements for Housekeeping supplies.

Ask in plain language: Please clarify the room/outlet count requirements for Housekeeping supplies. Arabic draft: يرجى توضيح متطلبات room/outlet count الخاصة بـ Housekeeping supplies. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-facet-02",
  "question_en": "Please clarify the room/outlet count requirements for Housekeeping supplies.",
  "question_ar": "يرجى توضيح متطلبات room/outlet count الخاصة بـ Housekeeping supplies.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the room/outlet count requirements for Housekeeping supplies. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-facet-02",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the consumable usage requirements for Housekeeping supplies.

Ask in plain language: Please clarify the consumable usage requirements for Housekeeping supplies. Arabic draft: يرجى توضيح متطلبات consumable usage الخاصة بـ Housekeeping supplies. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-facet-03",
  "question_en": "Please clarify the consumable usage requirements for Housekeeping supplies.",
  "question_ar": "يرجى توضيح متطلبات consumable usage الخاصة بـ Housekeeping supplies.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the consumable usage requirements for Housekeeping supplies. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-facet-03",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the fabric/finish durability requirements for Housekeeping supplies.

Ask in plain language: Please clarify the fabric/finish durability requirements for Housekeeping supplies. Arabic draft: يرجى توضيح متطلبات fabric/finish durability الخاصة بـ Housekeeping supplies. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-facet-04",
  "question_en": "Please clarify the fabric/finish durability requirements for Housekeeping supplies.",
  "question_ar": "يرجى توضيح متطلبات fabric/finish durability الخاصة بـ Housekeeping supplies.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 230,
  "confidence_contribution": 0.012
}
```

### Please clarify the laundry/housekeeping interface requirements for Housekeeping supplies.

Ask in plain language: Please clarify the laundry/housekeeping interface requirements for Housekeeping supplies. Arabic draft: يرجى توضيح متطلبات laundry/housekeeping interface الخاصة بـ Housekeeping supplies. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-facet-05",
  "question_en": "Please clarify the laundry/housekeeping interface requirements for Housekeeping supplies.",
  "question_ar": "يرجى توضيح متطلبات laundry/housekeeping interface الخاصة بـ Housekeeping supplies.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the packaging and replenishment requirements for Housekeeping supplies.

Ask in plain language: Please clarify the packaging and replenishment requirements for Housekeeping supplies. Arabic draft: يرجى توضيح متطلبات packaging and replenishment الخاصة بـ Housekeeping supplies. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-facet-06",
  "question_en": "Please clarify the packaging and replenishment requirements for Housekeeping supplies.",
  "question_ar": "يرجى توضيح متطلبات packaging and replenishment الخاصة بـ Housekeeping supplies.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the sample approval requirements for Housekeeping supplies.

Ask in plain language: Please clarify the sample approval requirements for Housekeeping supplies. Arabic draft: يرجى توضيح متطلبات sample approval الخاصة بـ Housekeeping supplies. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-facet-07",
  "question_en": "Please clarify the sample approval requirements for Housekeeping supplies.",
  "question_ar": "يرجى توضيح متطلبات sample approval الخاصة بـ Housekeeping supplies.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Which exact Housekeeping supplies product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Housekeeping supplies product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Housekeeping supplies التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-exact-subtype",
  "question_en": "Which exact Housekeeping supplies product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Housekeeping supplies التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 270,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Housekeeping supplies product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-ask-exact-subtype",
  "priority": 973,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-housekeeping-supplies-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Housekeeping supplies are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Housekeeping supplies are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Housekeeping supplies التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-unknowns",
  "question_en": "Which details about Housekeeping supplies are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Housekeeping supplies التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 280,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Housekeeping supplies?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Housekeeping supplies? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Housekeeping supplies؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-housekeeping-supplies-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Housekeeping supplies?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Housekeeping supplies؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Housekeeping supplies, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Housekeeping supplies, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Housekeeping supplies, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Housekeeping supplies, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0182`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH, UAE-CONSUMER-PROTECTION, UAE-MOIAT, ISO-STANDARDS

```json
{
  "rule_id": "R-015-housekeeping-supplies-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-DM-FOOD",
        "UAE-ADAFSA",
        "UAE-DM-PUBLIC-HEALTH",
        "UAE-CONSUMER-PROTECTION",
        "UAE-MOIAT",
        "ISO-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Housekeeping supplies, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Housekeeping supplies, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Housekeeping supplies, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Housekeeping supplies, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-housekeeping-supplies-inquiry_qualification-decision_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-housekeeping-supplies-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Housekeeping supplies, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-validation-validation_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-housekeeping-supplies-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Housekeeping supplies, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-validation-validation_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-housekeeping-supplies-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Housekeeping supplies, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-validation-validation_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-housekeeping-supplies-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Housekeeping supplies, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-validation-validation_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-housekeeping-supplies-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Housekeeping supplies, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-housekeeping-supplies-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Housekeeping supplies, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-housekeeping-supplies-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Housekeeping supplies, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-validation-validation_rule-0193`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "validation_id": "V-015-housekeeping-supplies-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Housekeeping supplies, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-housekeeping-supplies-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Housekeeping supplies, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-housekeeping-supplies-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Housekeeping supplies, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-housekeeping-supplies-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-housekeeping-supplies-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Housekeeping supplies without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-housekeeping-supplies-scenario_test-scenario-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-housekeeping-supplies-001",
  "setup": "Customer asks informally for Housekeeping supplies without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Housekeeping supplies with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-housekeeping-supplies-scenario_test-scenario-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-housekeeping-supplies-002",
  "setup": "Customer requests price for Housekeeping supplies with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Housekeeping supplies. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-housekeeping-supplies-scenario_test-scenario-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-housekeeping-supplies-003",
  "setup": "Customer uploads a relevant schedule/specification for Housekeeping supplies.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Housekeeping supplies. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-housekeeping-supplies-scenario_test-scenario-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-housekeeping-supplies-004",
  "setup": "Customer message and uploaded document disagree on Housekeeping supplies.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Housekeeping supplies. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-housekeeping-supplies-scenario_test-scenario-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-housekeeping-supplies-005",
  "setup": "Supplier proposes a different product, provider or method for Housekeeping supplies.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Housekeeping supplies sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-housekeeping-supplies-scenario_test-scenario-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-housekeeping-supplies-006",
  "setup": "Customer needs Housekeeping supplies sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Housekeeping supplies needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-housekeeping-supplies-scenario_test-scenario-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-housekeeping-supplies-007",
  "setup": "The request for Housekeeping supplies needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Housekeeping supplies

English term: Housekeeping supplies. Arabic operational draft: متطلبات Housekeeping supplies. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Housekeeping supplies",
  "term_ar": "متطلبات Housekeeping supplies",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### hotel category and brand standard

English term: hotel category and brand standard. Arabic operational draft: متطلبات hotel category and brand standard. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "hotel category and brand standard",
  "term_ar": "متطلبات hotel category and brand standard",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### room/outlet count

English term: room/outlet count. Arabic operational draft: متطلبات room/outlet count. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "room/outlet count",
  "term_ar": "متطلبات room/outlet count",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### consumable usage

English term: consumable usage. Arabic operational draft: متطلبات consumable usage. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "consumable usage",
  "term_ar": "متطلبات consumable usage",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### fabric/finish durability

English term: fabric/finish durability. Arabic operational draft: متطلبات fabric/finish durability. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "fabric/finish durability",
  "term_ar": "متطلبات fabric/finish durability",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### laundry/housekeeping interface

English term: laundry/housekeeping interface. Arabic operational draft: متطلبات laundry/housekeeping interface. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "laundry/housekeeping interface",
  "term_ar": "متطلبات laundry/housekeeping interface",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### packaging and replenishment

English term: packaging and replenishment. Arabic operational draft: متطلبات packaging and replenishment. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "packaging and replenishment",
  "term_ar": "متطلبات packaging and replenishment",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```

### sample approval

English term: sample approval. Arabic operational draft: متطلبات sample approval. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-housekeeping-supplies-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "sample approval",
  "term_ar": "متطلبات sample approval",
  "canonical_subcategory": "housekeeping-supplies",
  "normalization_only": true
}
```


# 3. Commercial laundry equipment

**Arabic draft:** متطلبات Commercial laundry equipment
**Slug:** `commercial-laundry-equipment`
**Aliases:** Commercial laundry equipment, Commercial laundry, laundry equipment

## Industry

### Industry scope — Commercial laundry equipment

Commercial laundry equipment is treated as a distinct procurement route within Hospitality Supplies. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers food, catering, hospitality operations, equipment, hygiene, production capacity and service delivery. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH

```json
{
  "category": "Hospitality Supplies",
  "subcategory": "Commercial laundry equipment",
  "profile": "food",
  "aliases": [
    "Commercial laundry equipment",
    "Commercial laundry",
    "laundry equipment"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Commercial laundry equipment

A normal UAE sourcing workflow for Commercial laundry equipment moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH, UAE-CONSUMER-PROTECTION

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Commercial laundry equipment

Customers may describe Commercial laundry equipment through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-015-commercial-laundry-equipment-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Commercial laundry equipment

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-015-commercial-laundry-equipment-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Commercial laundry equipment product or service

The primary deliverable requested within Commercial laundry equipment; exact type, quantity, performance, scope and acceptance must be normalized. For Commercial laundry equipment, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Commercial laundry equipment",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Commercial laundry equipment

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Commercial laundry equipment, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Commercial laundry equipment",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Commercial laundry equipment

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Commercial laundry equipment, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Commercial laundry equipment",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Commercial laundry equipment

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Commercial laundry equipment, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Commercial laundry equipment",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Commercial laundry equipment

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Commercial laundry equipment, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Commercial laundry equipment",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Commercial laundry equipment

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Commercial laundry equipment, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Commercial laundry equipment",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Commercial laundry equipment

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Commercial laundry equipment, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Commercial laundry equipment",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Commercial laundry equipment

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Commercial laundry equipment, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Commercial laundry equipment",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Hotel Category And Brand Standard scope component

Hotel Category And Brand Standard is a recurring scope component for Commercial laundry equipment. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "hotel category and brand standard",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Room/Outlet Count scope component

Room/Outlet Count is a recurring scope component for Commercial laundry equipment. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "room/outlet count",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Consumable Usage scope component

Consumable Usage is a recurring scope component for Commercial laundry equipment. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "consumable usage",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Fabric/Finish Durability scope component

Fabric/Finish Durability is a recurring scope component for Commercial laundry equipment. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "fabric/finish durability",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Laundry/Housekeeping Interface scope component

Laundry/Housekeeping Interface is a recurring scope component for Commercial laundry equipment. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "laundry/housekeeping interface",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Packaging And Replenishment scope component

Packaging And Replenishment is a recurring scope component for Commercial laundry equipment. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "packaging and replenishment",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Sample Approval scope component

Sample Approval is a recurring scope component for Commercial laundry equipment. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "sample approval",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: menu/product scope

For Commercial laundry equipment, menu/product scope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "menu/product scope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: production or service capacity

For Commercial laundry equipment, production or service capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "production or service capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: food-contact materials

For Commercial laundry equipment, food-contact materials must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "food-contact materials",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: temperature control

For Commercial laundry equipment, temperature control must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "temperature control",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: hygiene zoning

For Commercial laundry equipment, hygiene zoning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "hygiene zoning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: utilities and drainage

For Commercial laundry equipment, utilities and drainage must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "utilities and drainage",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: allergen and dietary controls

For Commercial laundry equipment, allergen and dietary controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "allergen and dietary controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: packaging and shelf life

For Commercial laundry equipment, packaging and shelf life must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "packaging and shelf life",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: cleaning and sanitation

For Commercial laundry equipment, cleaning and sanitation must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "cleaning and sanitation",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: maintenance and calibration

For Commercial laundry equipment, maintenance and calibration must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "maintenance and calibration",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: hotel category and brand standard

For Commercial laundry equipment, hotel category and brand standard must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "hotel category and brand standard",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: room/outlet count

For Commercial laundry equipment, room/outlet count must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "room/outlet count",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: consumable usage

For Commercial laundry equipment, consumable usage must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "consumable usage",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: fabric/finish durability

For Commercial laundry equipment, fabric/finish durability must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "fabric/finish durability",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: laundry/housekeeping interface

For Commercial laundry equipment, laundry/housekeeping interface must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "laundry/housekeeping interface",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: packaging and replenishment

For Commercial laundry equipment, packaging and replenishment must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "packaging and replenishment",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: sample approval

For Commercial laundry equipment, sample approval must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-commercial-laundry-equipment-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "sample approval",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: licensed food establishment

A licensed food establishment may be relevant to Commercial laundry equipment depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-commercial-laundry-equipment-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "licensed food establishment",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: manufacturer

A manufacturer may be relevant to Commercial laundry equipment depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-commercial-laundry-equipment-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Commercial laundry equipment depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-commercial-laundry-equipment-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: commercial kitchen contractor

A commercial kitchen contractor may be relevant to Commercial laundry equipment depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-commercial-laundry-equipment-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "commercial kitchen contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: catering operator

A catering operator may be relevant to Commercial laundry equipment depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-commercial-laundry-equipment-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "catering operator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: hospitality service provider

A hospitality service provider may be relevant to Commercial laundry equipment depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-commercial-laundry-equipment-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "hospitality service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — licensed food establishment

This supplier type can participate in Commercial laundry equipment only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "licensed food establishment",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — manufacturer

This supplier type can participate in Commercial laundry equipment only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Commercial laundry equipment only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — commercial kitchen contractor

This supplier type can participate in Commercial laundry equipment only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "commercial kitchen contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — catering operator

This supplier type can participate in Commercial laundry equipment only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "catering operator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — hospitality service provider

This supplier type can participate in Commercial laundry equipment only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "hospitality service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance provider

This supplier type can participate in Commercial laundry equipment only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — testing/certification provider

This supplier type can participate in Commercial laundry equipment only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "testing/certification provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — licensed food establishment

Before routing a Commercial laundry equipment inquiry to a licensed food establishment, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "licensed food establishment",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — manufacturer

Before routing a Commercial laundry equipment inquiry to a manufacturer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "manufacturer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Commercial laundry equipment inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — commercial kitchen contractor

Before routing a Commercial laundry equipment inquiry to a commercial kitchen contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "commercial kitchen contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — catering operator

Before routing a Commercial laundry equipment inquiry to a catering operator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "catering operator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — hospitality service provider

Before routing a Commercial laundry equipment inquiry to a hospitality service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "hospitality service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance provider

Before routing a Commercial laundry equipment inquiry to a maintenance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "maintenance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — testing/certification provider

Before routing a Commercial laundry equipment inquiry to a testing/certification provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-commercial-laundry-equipment-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "testing/certification provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Commercial laundry equipment should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-commercial-laundry-equipment-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Commercial laundry equipment should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-commercial-laundry-equipment-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Commercial laundry equipment should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-commercial-laundry-equipment-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Commercial laundry equipment should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-commercial-laundry-equipment-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Commercial laundry equipment should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-commercial-laundry-equipment-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Commercial laundry equipment should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-commercial-laundry-equipment-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Commercial laundry equipment should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-commercial-laundry-equipment-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Commercial laundry equipment should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-commercial-laundry-equipment-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Commercial laundry equipment should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-commercial-laundry-equipment-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Commercial laundry equipment should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-commercial-laundry-equipment-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Menu Or Product List

Menu Or Product List may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "menu-or-product-list",
  "document_name": "menu or product list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Capacity Schedule

Capacity Schedule may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "capacity-schedule",
  "document_name": "capacity schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Kitchen/Production Layout

Kitchen/Production Layout may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "kitchen-production-layout",
  "document_name": "kitchen/production layout",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Utility Schedule

Utility Schedule may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "utility-schedule",
  "document_name": "utility schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Food-Safety Plan

Food-Safety Plan may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "food-safety-plan",
  "document_name": "food-safety plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Haccp Records

Haccp Records may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "haccp-records",
  "document_name": "HACCP records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Allergen Matrix

Allergen Matrix may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "allergen-matrix",
  "document_name": "allergen matrix",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Halal Evidence

Halal Evidence may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "halal-evidence",
  "document_name": "halal evidence",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Temperature Records

Temperature Records may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "temperature-records",
  "document_name": "temperature records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Licence/Permit

Licence/Permit may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "licence-permit",
  "document_name": "licence/permit",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Cleaning Plan

Cleaning Plan may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "cleaning-plan",
  "document_name": "cleaning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Maintenance/Calibration Records

Maintenance/Calibration Records may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "maintenance-calibration-records",
  "document_name": "maintenance/calibration records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quotation Scope Matrix

Quotation Scope Matrix may provide or verify information needed for Commercial laundry equipment. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-commercial-laundry-equipment-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quotation-scope-matrix",
  "document_name": "quotation scope matrix",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Dubai Municipality Food Safety Publications and Food Code

For Commercial laundry equipment, consult Dubai Municipality Food Safety Publications and Food Code when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-commercial-laundry-equipment-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-FOOD

```json
{
  "source_id": "UAE-DM-FOOD",
  "publisher": "Dubai Municipality",
  "source_type": "government_food_safety_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Abu Dhabi Food Safety and Agriculture Authority Requirements

For Commercial laundry equipment, consult Abu Dhabi Food Safety and Agriculture Authority Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-commercial-laundry-equipment-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADAFSA

```json
{
  "source_id": "UAE-ADAFSA",
  "publisher": "ADAFSA",
  "source_type": "government_food_agriculture_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Municipality Public Health and Safety Services

For Commercial laundry equipment, consult Dubai Municipality Public Health and Safety Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-commercial-laundry-equipment-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-PUBLIC-HEALTH

```json
{
  "source_id": "UAE-DM-PUBLIC-HEALTH",
  "publisher": "Dubai Municipality",
  "source_type": "government_health_safety_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Consumer Protection Legislation

For Commercial laundry equipment, consult UAE Consumer Protection Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-commercial-laundry-equipment-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION

```json
{
  "source_id": "UAE-CONSUMER-PROTECTION",
  "publisher": "UAE Legislation / Ministry of Economy",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Industrial, Standards, Conformity and Quality Services

For Commercial laundry equipment, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-commercial-laundry-equipment-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Commercial laundry equipment, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-commercial-laundry-equipment-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Commercial laundry equipment. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-commercial-laundry-equipment-commercial_pricing-cost_driver-0089`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Commercial laundry equipment. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-commercial-laundry-equipment-commercial_pricing-cost_driver-0091`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Commercial laundry equipment. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-commercial-laundry-equipment-commercial_pricing-cost_driver-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Commercial laundry equipment. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-commercial-laundry-equipment-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Commercial laundry equipment. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-commercial-laundry-equipment-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Commercial laundry equipment. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-commercial-laundry-equipment-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Commercial laundry equipment. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-commercial-laundry-equipment-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Commercial laundry equipment. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-commercial-laundry-equipment-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Commercial laundry equipment. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-commercial-laundry-equipment-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Commercial laundry equipment. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-commercial-laundry-equipment-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-customer_tradeoffs-tradeoff-0090`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-customer_tradeoffs-tradeoff-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-customer_tradeoffs-tradeoff-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Commercial laundry equipment, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-risk-risk_control-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Commercial laundry equipment, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-risk-risk_control-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Commercial laundry equipment, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-risk-risk_control-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Commercial laundry equipment, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Commercial laundry equipment, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Commercial laundry equipment, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Commercial laundry equipment, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Commercial laundry equipment, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Commercial laundry equipment, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Commercial laundry equipment, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-commercial-laundry-equipment-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Commercial laundry equipment, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-commercial-laundry-equipment-best_practices-qualification_best_practice-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Commercial laundry equipment, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-commercial-laundry-equipment-best_practices-qualification_best_practice-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Commercial laundry equipment, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-commercial-laundry-equipment-best_practices-qualification_best_practice-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Commercial laundry equipment, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-commercial-laundry-equipment-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Commercial laundry equipment, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-commercial-laundry-equipment-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Commercial laundry equipment, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-commercial-laundry-equipment-best_practices-qualification_best_practice-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Commercial laundry equipment; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-commercial-laundry-equipment-troubleshooting-recovery_guidance-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Commercial laundry equipment; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-commercial-laundry-equipment-troubleshooting-recovery_guidance-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Commercial laundry equipment; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-commercial-laundry-equipment-troubleshooting-recovery_guidance-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Commercial laundry equipment; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-commercial-laundry-equipment-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Commercial laundry equipment; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-commercial-laundry-equipment-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Commercial laundry equipment; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-commercial-laundry-equipment-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Commercial laundry equipment; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-commercial-laundry-equipment-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Commercial laundry equipment; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-commercial-laundry-equipment-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What food, beverage, menu, production process or hospitality service is required?

Ask in plain language: What food, beverage, menu, production process or hospitality service is required? Arabic draft: ما الطعام أو الشراب أو القائمة أو عملية الإنتاج أو خدمة الضيافة المطلوبة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-menu-product-scope",
  "question_en": "What food, beverage, menu, production process or hospitality service is required?",
  "question_ar": "ما الطعام أو الشراب أو القائمة أو عملية الإنتاج أو خدمة الضيافة المطلوبة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "menu-product-scope",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What food, beverage, menu, production process or hospitality service is required? is missing

When the normalized field menu-product-scope is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-menu-product-scope",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "menu-product-scope",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-menu-product-scope"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What daily, hourly, batch, guest or outlet capacity is required?

Ask in plain language: What daily, hourly, batch, guest or outlet capacity is required? Arabic draft: ما السعة اليومية أو بالساعة أو لكل دفعة أو عدد الضيوف أو المنافذ؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-capacity-volume",
  "question_en": "What daily, hourly, batch, guest or outlet capacity is required?",
  "question_ar": "ما السعة اليومية أو بالساعة أو لكل دفعة أو عدد الضيوف أو المنافذ؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-volume",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What daily, hourly, batch, guest or outlet capacity is required? is missing

When the normalized field capacity-volume is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-capacity-volume",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-volume",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-capacity-volume"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What food-safety, hygiene, allergen, halal and traceability controls apply?

Ask in plain language: What food-safety, hygiene, allergen, halal and traceability controls apply? Arabic draft: ما ضوابط سلامة الغذاء والنظافة والحساسية والحلال والتتبع المطلوبة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-food-safety",
  "question_en": "What food-safety, hygiene, allergen, halal and traceability controls apply?",
  "question_ar": "ما ضوابط سلامة الغذاء والنظافة والحساسية والحلال والتتبع المطلوبة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "food-safety",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What food-safety, hygiene, allergen, halal and traceability controls apply? is missing

When the normalized field food-safety is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-food-safety",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "food-safety",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-food-safety"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What cooking, chilling, freezing, holding, transport or display temperatures apply?

Ask in plain language: What cooking, chilling, freezing, holding, transport or display temperatures apply? Arabic draft: ما درجات الطهي أو التبريد أو التجميد أو الحفظ أو النقل أو العرض؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-temperature-chain",
  "question_en": "What cooking, chilling, freezing, holding, transport or display temperatures apply?",
  "question_ar": "ما درجات الطهي أو التبريد أو التجميد أو الحفظ أو النقل أو العرض؟",
  "expected_answer_type": "table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "temperature-chain",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available?

Ask in plain language: What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available? Arabic draft: ما التخطيط والطاقة والغاز والماء والصرف والتهوية والشفط المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-utilities-layout",
  "question_en": "What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available?",
  "question_ar": "ما التخطيط والطاقة والغاز والماء والصرف والتهوية والشفط المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-layout",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available? is missing

When the normalized field utilities-layout is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-utilities-layout",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-layout",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-utilities-layout"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation?

Ask in plain language: Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation? Arabic draft: هل النطاق توريد أو إيجار أو خدمة مدارة أو موظفين أو تركيب أو صيانة أو تشغيل كامل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-service-model",
  "question_en": "Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation?",
  "question_ar": "هل النطاق توريد أو إيجار أو خدمة مدارة أو موظفين أو تركيب أو صيانة أو تشغيل كامل؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "service-model",
  "order": 180,
  "confidence_contribution": 0.03
}
```

### Ask when Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation? is missing

When the normalized field service-model is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-service-model",
  "priority": 982,
  "when": {
    "all": [
      {
        "field": "service-model",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-service-model"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which municipality, food authority, venue or event approvals are required?

Ask in plain language: Which municipality, food authority, venue or event approvals are required? Arabic draft: ما موافقات البلدية أو جهة الغذاء أو المكان أو الفعالية المطلوبة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-licences-approvals",
  "question_en": "Which municipality, food authority, venue or event approvals are required?",
  "question_ar": "ما موافقات البلدية أو جهة الغذاء أو المكان أو الفعالية المطلوبة؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "licences-approvals",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### Please clarify the hotel category and brand standard requirements for Commercial laundry equipment.

Ask in plain language: Please clarify the hotel category and brand standard requirements for Commercial laundry equipment. Arabic draft: يرجى توضيح متطلبات hotel category and brand standard الخاصة بـ Commercial laundry equipment. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-facet-01",
  "question_en": "Please clarify the hotel category and brand standard requirements for Commercial laundry equipment.",
  "question_ar": "يرجى توضيح متطلبات hotel category and brand standard الخاصة بـ Commercial laundry equipment.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the hotel category and brand standard requirements for Commercial laundry equipment. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-facet-01",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the room/outlet count requirements for Commercial laundry equipment.

Ask in plain language: Please clarify the room/outlet count requirements for Commercial laundry equipment. Arabic draft: يرجى توضيح متطلبات room/outlet count الخاصة بـ Commercial laundry equipment. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-facet-02",
  "question_en": "Please clarify the room/outlet count requirements for Commercial laundry equipment.",
  "question_ar": "يرجى توضيح متطلبات room/outlet count الخاصة بـ Commercial laundry equipment.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the room/outlet count requirements for Commercial laundry equipment. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-facet-02",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the consumable usage requirements for Commercial laundry equipment.

Ask in plain language: Please clarify the consumable usage requirements for Commercial laundry equipment. Arabic draft: يرجى توضيح متطلبات consumable usage الخاصة بـ Commercial laundry equipment. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-facet-03",
  "question_en": "Please clarify the consumable usage requirements for Commercial laundry equipment.",
  "question_ar": "يرجى توضيح متطلبات consumable usage الخاصة بـ Commercial laundry equipment.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the consumable usage requirements for Commercial laundry equipment. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-facet-03",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the fabric/finish durability requirements for Commercial laundry equipment.

Ask in plain language: Please clarify the fabric/finish durability requirements for Commercial laundry equipment. Arabic draft: يرجى توضيح متطلبات fabric/finish durability الخاصة بـ Commercial laundry equipment. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-facet-04",
  "question_en": "Please clarify the fabric/finish durability requirements for Commercial laundry equipment.",
  "question_ar": "يرجى توضيح متطلبات fabric/finish durability الخاصة بـ Commercial laundry equipment.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 230,
  "confidence_contribution": 0.012
}
```

### Please clarify the laundry/housekeeping interface requirements for Commercial laundry equipment.

Ask in plain language: Please clarify the laundry/housekeeping interface requirements for Commercial laundry equipment. Arabic draft: يرجى توضيح متطلبات laundry/housekeeping interface الخاصة بـ Commercial laundry equipment. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-facet-05",
  "question_en": "Please clarify the laundry/housekeeping interface requirements for Commercial laundry equipment.",
  "question_ar": "يرجى توضيح متطلبات laundry/housekeeping interface الخاصة بـ Commercial laundry equipment.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the packaging and replenishment requirements for Commercial laundry equipment.

Ask in plain language: Please clarify the packaging and replenishment requirements for Commercial laundry equipment. Arabic draft: يرجى توضيح متطلبات packaging and replenishment الخاصة بـ Commercial laundry equipment. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-facet-06",
  "question_en": "Please clarify the packaging and replenishment requirements for Commercial laundry equipment.",
  "question_ar": "يرجى توضيح متطلبات packaging and replenishment الخاصة بـ Commercial laundry equipment.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the sample approval requirements for Commercial laundry equipment.

Ask in plain language: Please clarify the sample approval requirements for Commercial laundry equipment. Arabic draft: يرجى توضيح متطلبات sample approval الخاصة بـ Commercial laundry equipment. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-facet-07",
  "question_en": "Please clarify the sample approval requirements for Commercial laundry equipment.",
  "question_ar": "يرجى توضيح متطلبات sample approval الخاصة بـ Commercial laundry equipment.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Which exact Commercial laundry equipment product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Commercial laundry equipment product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Commercial laundry equipment التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-exact-subtype",
  "question_en": "Which exact Commercial laundry equipment product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Commercial laundry equipment التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 270,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Commercial laundry equipment product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-ask-exact-subtype",
  "priority": 973,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-commercial-laundry-equipment-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Commercial laundry equipment are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Commercial laundry equipment are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Commercial laundry equipment التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-unknowns",
  "question_en": "Which details about Commercial laundry equipment are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Commercial laundry equipment التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 280,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Commercial laundry equipment?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Commercial laundry equipment? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Commercial laundry equipment؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-commercial-laundry-equipment-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Commercial laundry equipment?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Commercial laundry equipment؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Commercial laundry equipment, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Commercial laundry equipment, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Commercial laundry equipment, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Commercial laundry equipment, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0182`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH, UAE-CONSUMER-PROTECTION, UAE-MOIAT, ISO-STANDARDS

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-DM-FOOD",
        "UAE-ADAFSA",
        "UAE-DM-PUBLIC-HEALTH",
        "UAE-CONSUMER-PROTECTION",
        "UAE-MOIAT",
        "ISO-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Commercial laundry equipment, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Commercial laundry equipment, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Commercial laundry equipment, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Commercial laundry equipment, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-commercial-laundry-equipment-inquiry_qualification-decision_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-commercial-laundry-equipment-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Commercial laundry equipment, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-validation-validation_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-commercial-laundry-equipment-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Commercial laundry equipment, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-validation-validation_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-commercial-laundry-equipment-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Commercial laundry equipment, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-validation-validation_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-commercial-laundry-equipment-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Commercial laundry equipment, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-validation-validation_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-commercial-laundry-equipment-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Commercial laundry equipment, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-commercial-laundry-equipment-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Commercial laundry equipment, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-commercial-laundry-equipment-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Commercial laundry equipment, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-validation-validation_rule-0193`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "validation_id": "V-015-commercial-laundry-equipment-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Commercial laundry equipment, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-commercial-laundry-equipment-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Commercial laundry equipment, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-commercial-laundry-equipment-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Commercial laundry equipment, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-commercial-laundry-equipment-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-commercial-laundry-equipment-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Commercial laundry equipment without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-commercial-laundry-equipment-scenario_test-scenario-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-commercial-laundry-equipment-001",
  "setup": "Customer asks informally for Commercial laundry equipment without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Commercial laundry equipment with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-commercial-laundry-equipment-scenario_test-scenario-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-commercial-laundry-equipment-002",
  "setup": "Customer requests price for Commercial laundry equipment with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Commercial laundry equipment. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-commercial-laundry-equipment-scenario_test-scenario-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-commercial-laundry-equipment-003",
  "setup": "Customer uploads a relevant schedule/specification for Commercial laundry equipment.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Commercial laundry equipment. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-commercial-laundry-equipment-scenario_test-scenario-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-commercial-laundry-equipment-004",
  "setup": "Customer message and uploaded document disagree on Commercial laundry equipment.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Commercial laundry equipment. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-commercial-laundry-equipment-scenario_test-scenario-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-commercial-laundry-equipment-005",
  "setup": "Supplier proposes a different product, provider or method for Commercial laundry equipment.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Commercial laundry equipment sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-commercial-laundry-equipment-scenario_test-scenario-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-commercial-laundry-equipment-006",
  "setup": "Customer needs Commercial laundry equipment sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Commercial laundry equipment needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-commercial-laundry-equipment-scenario_test-scenario-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-commercial-laundry-equipment-007",
  "setup": "The request for Commercial laundry equipment needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Commercial laundry equipment

English term: Commercial laundry equipment. Arabic operational draft: متطلبات Commercial laundry equipment. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Commercial laundry equipment",
  "term_ar": "متطلبات Commercial laundry equipment",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### hotel category and brand standard

English term: hotel category and brand standard. Arabic operational draft: متطلبات hotel category and brand standard. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "hotel category and brand standard",
  "term_ar": "متطلبات hotel category and brand standard",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### room/outlet count

English term: room/outlet count. Arabic operational draft: متطلبات room/outlet count. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "room/outlet count",
  "term_ar": "متطلبات room/outlet count",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### consumable usage

English term: consumable usage. Arabic operational draft: متطلبات consumable usage. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "consumable usage",
  "term_ar": "متطلبات consumable usage",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### fabric/finish durability

English term: fabric/finish durability. Arabic operational draft: متطلبات fabric/finish durability. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "fabric/finish durability",
  "term_ar": "متطلبات fabric/finish durability",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### laundry/housekeeping interface

English term: laundry/housekeeping interface. Arabic operational draft: متطلبات laundry/housekeeping interface. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "laundry/housekeeping interface",
  "term_ar": "متطلبات laundry/housekeeping interface",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### packaging and replenishment

English term: packaging and replenishment. Arabic operational draft: متطلبات packaging and replenishment. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "packaging and replenishment",
  "term_ar": "متطلبات packaging and replenishment",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```

### sample approval

English term: sample approval. Arabic operational draft: متطلبات sample approval. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-commercial-laundry-equipment-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "sample approval",
  "term_ar": "متطلبات sample approval",
  "canonical_subcategory": "commercial-laundry-equipment",
  "normalization_only": true
}
```


# 4. Tableware

**Arabic draft:** متطلبات Tableware
**Slug:** `tableware`
**Aliases:** Tableware

## Industry

### Industry scope — Tableware

Tableware is treated as a distinct procurement route within Hospitality Supplies. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers food, catering, hospitality operations, equipment, hygiene, production capacity and service delivery. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-015-tableware-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH

```json
{
  "category": "Hospitality Supplies",
  "subcategory": "Tableware",
  "profile": "food",
  "aliases": [
    "Tableware"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Tableware

A normal UAE sourcing workflow for Tableware moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-015-tableware-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH, UAE-CONSUMER-PROTECTION

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Tableware

Customers may describe Tableware through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-015-tableware-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Tableware

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-015-tableware-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Tableware product or service

The primary deliverable requested within Tableware; exact type, quantity, performance, scope and acceptance must be normalized. For Tableware, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-tableware-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Tableware",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Tableware

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Tableware, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-tableware-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Tableware",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Tableware

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Tableware, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-tableware-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Tableware",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Tableware

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Tableware, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-tableware-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Tableware",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Tableware

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Tableware, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-tableware-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Tableware",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Tableware

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Tableware, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-tableware-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Tableware",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Tableware

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Tableware, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-tableware-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Tableware",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Tableware

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Tableware, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-015-tableware-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Tableware",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Hotel Category And Brand Standard scope component

Hotel Category And Brand Standard is a recurring scope component for Tableware. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-tableware-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "hotel category and brand standard",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Room/Outlet Count scope component

Room/Outlet Count is a recurring scope component for Tableware. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-tableware-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "room/outlet count",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Consumable Usage scope component

Consumable Usage is a recurring scope component for Tableware. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-tableware-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "consumable usage",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Fabric/Finish Durability scope component

Fabric/Finish Durability is a recurring scope component for Tableware. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-tableware-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "fabric/finish durability",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Laundry/Housekeeping Interface scope component

Laundry/Housekeeping Interface is a recurring scope component for Tableware. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-tableware-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "laundry/housekeeping interface",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Packaging And Replenishment scope component

Packaging And Replenishment is a recurring scope component for Tableware. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-tableware-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "packaging and replenishment",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Sample Approval scope component

Sample Approval is a recurring scope component for Tableware. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-015-tableware-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "sample approval",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: menu/product scope

For Tableware, menu/product scope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "menu/product scope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: production or service capacity

For Tableware, production or service capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "production or service capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: food-contact materials

For Tableware, food-contact materials must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "food-contact materials",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: temperature control

For Tableware, temperature control must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "temperature control",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: hygiene zoning

For Tableware, hygiene zoning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "hygiene zoning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: utilities and drainage

For Tableware, utilities and drainage must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "utilities and drainage",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: allergen and dietary controls

For Tableware, allergen and dietary controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "allergen and dietary controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: packaging and shelf life

For Tableware, packaging and shelf life must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "packaging and shelf life",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: cleaning and sanitation

For Tableware, cleaning and sanitation must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "cleaning and sanitation",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: maintenance and calibration

For Tableware, maintenance and calibration must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "maintenance and calibration",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: hotel category and brand standard

For Tableware, hotel category and brand standard must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "hotel category and brand standard",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: room/outlet count

For Tableware, room/outlet count must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "room/outlet count",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: consumable usage

For Tableware, consumable usage must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "consumable usage",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: fabric/finish durability

For Tableware, fabric/finish durability must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "fabric/finish durability",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: laundry/housekeeping interface

For Tableware, laundry/housekeeping interface must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "laundry/housekeeping interface",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: packaging and replenishment

For Tableware, packaging and replenishment must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "packaging and replenishment",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: sample approval

For Tableware, sample approval must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-015-tableware-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "sample approval",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: licensed food establishment

A licensed food establishment may be relevant to Tableware depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-tableware-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "licensed food establishment",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: manufacturer

A manufacturer may be relevant to Tableware depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-tableware-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Tableware depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-tableware-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: commercial kitchen contractor

A commercial kitchen contractor may be relevant to Tableware depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-tableware-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "commercial kitchen contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: catering operator

A catering operator may be relevant to Tableware depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-tableware-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "catering operator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: hospitality service provider

A hospitality service provider may be relevant to Tableware depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-015-tableware-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "hospitality service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — licensed food establishment

This supplier type can participate in Tableware only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-tableware-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "licensed food establishment",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — manufacturer

This supplier type can participate in Tableware only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-tableware-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Tableware only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-tableware-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — commercial kitchen contractor

This supplier type can participate in Tableware only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-tableware-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "commercial kitchen contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — catering operator

This supplier type can participate in Tableware only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-tableware-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "catering operator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — hospitality service provider

This supplier type can participate in Tableware only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-tableware-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "hospitality service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance provider

This supplier type can participate in Tableware only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-tableware-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — testing/certification provider

This supplier type can participate in Tableware only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-015-tableware-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "testing/certification provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — licensed food establishment

Before routing a Tableware inquiry to a licensed food establishment, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-tableware-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "licensed food establishment",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — manufacturer

Before routing a Tableware inquiry to a manufacturer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-tableware-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "manufacturer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Tableware inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-tableware-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — commercial kitchen contractor

Before routing a Tableware inquiry to a commercial kitchen contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-tableware-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "commercial kitchen contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — catering operator

Before routing a Tableware inquiry to a catering operator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-tableware-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "catering operator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — hospitality service provider

Before routing a Tableware inquiry to a hospitality service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-tableware-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "hospitality service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance provider

Before routing a Tableware inquiry to a maintenance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-tableware-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "maintenance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — testing/certification provider

Before routing a Tableware inquiry to a testing/certification provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-015-tableware-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "supplier_type": "testing/certification provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Tableware should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-tableware-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Tableware should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-tableware-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Tableware should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-tableware-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Tableware should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-tableware-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Tableware should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-tableware-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Tableware should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-tableware-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Tableware should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-tableware-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Tableware should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-tableware-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Tableware should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-tableware-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Tableware should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-015-tableware-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Menu Or Product List

Menu Or Product List may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "menu-or-product-list",
  "document_name": "menu or product list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Capacity Schedule

Capacity Schedule may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "capacity-schedule",
  "document_name": "capacity schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Kitchen/Production Layout

Kitchen/Production Layout may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "kitchen-production-layout",
  "document_name": "kitchen/production layout",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Utility Schedule

Utility Schedule may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "utility-schedule",
  "document_name": "utility schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Food-Safety Plan

Food-Safety Plan may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "food-safety-plan",
  "document_name": "food-safety plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Haccp Records

Haccp Records may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "haccp-records",
  "document_name": "HACCP records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Allergen Matrix

Allergen Matrix may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "allergen-matrix",
  "document_name": "allergen matrix",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Halal Evidence

Halal Evidence may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "halal-evidence",
  "document_name": "halal evidence",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Temperature Records

Temperature Records may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "temperature-records",
  "document_name": "temperature records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Licence/Permit

Licence/Permit may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "licence-permit",
  "document_name": "licence/permit",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Cleaning Plan

Cleaning Plan may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "cleaning-plan",
  "document_name": "cleaning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Maintenance/Calibration Records

Maintenance/Calibration Records may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "maintenance-calibration-records",
  "document_name": "maintenance/calibration records",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quotation Scope Matrix

Quotation Scope Matrix may provide or verify information needed for Tableware. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-015-tableware-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quotation-scope-matrix",
  "document_name": "quotation scope matrix",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Dubai Municipality Food Safety Publications and Food Code

For Tableware, consult Dubai Municipality Food Safety Publications and Food Code when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-tableware-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-FOOD

```json
{
  "source_id": "UAE-DM-FOOD",
  "publisher": "Dubai Municipality",
  "source_type": "government_food_safety_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Abu Dhabi Food Safety and Agriculture Authority Requirements

For Tableware, consult Abu Dhabi Food Safety and Agriculture Authority Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-tableware-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADAFSA

```json
{
  "source_id": "UAE-ADAFSA",
  "publisher": "ADAFSA",
  "source_type": "government_food_agriculture_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Municipality Public Health and Safety Services

For Tableware, consult Dubai Municipality Public Health and Safety Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-tableware-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-PUBLIC-HEALTH

```json
{
  "source_id": "UAE-DM-PUBLIC-HEALTH",
  "publisher": "Dubai Municipality",
  "source_type": "government_health_safety_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Consumer Protection Legislation

For Tableware, consult UAE Consumer Protection Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-tableware-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION

```json
{
  "source_id": "UAE-CONSUMER-PROTECTION",
  "publisher": "UAE Legislation / Ministry of Economy",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Industrial, Standards, Conformity and Quality Services

For Tableware, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-tableware-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Tableware, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-015-tableware-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Tableware. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-tableware-commercial_pricing-cost_driver-0089`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Tableware. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-tableware-commercial_pricing-cost_driver-0091`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Tableware. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-tableware-commercial_pricing-cost_driver-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Tableware. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-tableware-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Tableware. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-tableware-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Tableware. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-tableware-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Tableware. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-tableware-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Tableware. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-tableware-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Tableware. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-tableware-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Tableware. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-015-tableware-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-tableware-customer_tradeoffs-tradeoff-0090`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-tableware-customer_tradeoffs-tradeoff-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-tableware-customer_tradeoffs-tradeoff-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-tableware-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-tableware-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-tableware-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-tableware-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-tableware-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-tableware-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-015-tableware-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Tableware, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-tableware-risk-risk_control-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Tableware, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-tableware-risk-risk_control-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Tableware, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-tableware-risk-risk_control-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Tableware, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-tableware-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Tableware, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-tableware-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Tableware, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-tableware-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Tableware, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-tableware-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Tableware, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-tableware-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Tableware, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-tableware-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Tableware, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-015-tableware-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Tableware, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-tableware-best_practices-qualification_best_practice-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Tableware, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-tableware-best_practices-qualification_best_practice-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Tableware, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-tableware-best_practices-qualification_best_practice-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Tableware, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-tableware-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Tableware, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-tableware-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Tableware, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-015-tableware-best_practices-qualification_best_practice-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Tableware; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-tableware-troubleshooting-recovery_guidance-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Tableware; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-tableware-troubleshooting-recovery_guidance-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Tableware; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-tableware-troubleshooting-recovery_guidance-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Tableware; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-tableware-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Tableware; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-tableware-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Tableware; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-tableware-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Tableware; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-tableware-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Tableware; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-015-tableware-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What food, beverage, menu, production process or hospitality service is required?

Ask in plain language: What food, beverage, menu, production process or hospitality service is required? Arabic draft: ما الطعام أو الشراب أو القائمة أو عملية الإنتاج أو خدمة الضيافة المطلوبة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-menu-product-scope",
  "question_en": "What food, beverage, menu, production process or hospitality service is required?",
  "question_ar": "ما الطعام أو الشراب أو القائمة أو عملية الإنتاج أو خدمة الضيافة المطلوبة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "menu-product-scope",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What food, beverage, menu, production process or hospitality service is required? is missing

When the normalized field menu-product-scope is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-menu-product-scope",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "menu-product-scope",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-menu-product-scope"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What daily, hourly, batch, guest or outlet capacity is required?

Ask in plain language: What daily, hourly, batch, guest or outlet capacity is required? Arabic draft: ما السعة اليومية أو بالساعة أو لكل دفعة أو عدد الضيوف أو المنافذ؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-capacity-volume",
  "question_en": "What daily, hourly, batch, guest or outlet capacity is required?",
  "question_ar": "ما السعة اليومية أو بالساعة أو لكل دفعة أو عدد الضيوف أو المنافذ؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-volume",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What daily, hourly, batch, guest or outlet capacity is required? is missing

When the normalized field capacity-volume is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-capacity-volume",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-volume",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-capacity-volume"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What food-safety, hygiene, allergen, halal and traceability controls apply?

Ask in plain language: What food-safety, hygiene, allergen, halal and traceability controls apply? Arabic draft: ما ضوابط سلامة الغذاء والنظافة والحساسية والحلال والتتبع المطلوبة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-food-safety",
  "question_en": "What food-safety, hygiene, allergen, halal and traceability controls apply?",
  "question_ar": "ما ضوابط سلامة الغذاء والنظافة والحساسية والحلال والتتبع المطلوبة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "food-safety",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What food-safety, hygiene, allergen, halal and traceability controls apply? is missing

When the normalized field food-safety is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-food-safety",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "food-safety",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-food-safety"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What cooking, chilling, freezing, holding, transport or display temperatures apply?

Ask in plain language: What cooking, chilling, freezing, holding, transport or display temperatures apply? Arabic draft: ما درجات الطهي أو التبريد أو التجميد أو الحفظ أو النقل أو العرض؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-temperature-chain",
  "question_en": "What cooking, chilling, freezing, holding, transport or display temperatures apply?",
  "question_ar": "ما درجات الطهي أو التبريد أو التجميد أو الحفظ أو النقل أو العرض؟",
  "expected_answer_type": "table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "temperature-chain",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available?

Ask in plain language: What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available? Arabic draft: ما التخطيط والطاقة والغاز والماء والصرف والتهوية والشفط المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-utilities-layout",
  "question_en": "What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available?",
  "question_ar": "ما التخطيط والطاقة والغاز والماء والصرف والتهوية والشفط المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-layout",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What kitchen/production layout, power, gas, water, drainage, ventilation and extraction are available? is missing

When the normalized field utilities-layout is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-utilities-layout",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-layout",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-utilities-layout"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation?

Ask in plain language: Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation? Arabic draft: هل النطاق توريد أو إيجار أو خدمة مدارة أو موظفين أو تركيب أو صيانة أو تشغيل كامل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-service-model",
  "question_en": "Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation?",
  "question_ar": "هل النطاق توريد أو إيجار أو خدمة مدارة أو موظفين أو تركيب أو صيانة أو تشغيل كامل؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "service-model",
  "order": 180,
  "confidence_contribution": 0.03
}
```

### Ask when Is the scope supply, rental, managed service, staffing, installation, maintenance or full operation? is missing

When the normalized field service-model is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-service-model",
  "priority": 982,
  "when": {
    "all": [
      {
        "field": "service-model",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-service-model"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which municipality, food authority, venue or event approvals are required?

Ask in plain language: Which municipality, food authority, venue or event approvals are required? Arabic draft: ما موافقات البلدية أو جهة الغذاء أو المكان أو الفعالية المطلوبة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-licences-approvals",
  "question_en": "Which municipality, food authority, venue or event approvals are required?",
  "question_ar": "ما موافقات البلدية أو جهة الغذاء أو المكان أو الفعالية المطلوبة؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "licences-approvals",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### Please clarify the hotel category and brand standard requirements for Tableware.

Ask in plain language: Please clarify the hotel category and brand standard requirements for Tableware. Arabic draft: يرجى توضيح متطلبات hotel category and brand standard الخاصة بـ Tableware. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-facet-01",
  "question_en": "Please clarify the hotel category and brand standard requirements for Tableware.",
  "question_ar": "يرجى توضيح متطلبات hotel category and brand standard الخاصة بـ Tableware.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the hotel category and brand standard requirements for Tableware. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-facet-01",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the room/outlet count requirements for Tableware.

Ask in plain language: Please clarify the room/outlet count requirements for Tableware. Arabic draft: يرجى توضيح متطلبات room/outlet count الخاصة بـ Tableware. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-facet-02",
  "question_en": "Please clarify the room/outlet count requirements for Tableware.",
  "question_ar": "يرجى توضيح متطلبات room/outlet count الخاصة بـ Tableware.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the room/outlet count requirements for Tableware. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-facet-02",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the consumable usage requirements for Tableware.

Ask in plain language: Please clarify the consumable usage requirements for Tableware. Arabic draft: يرجى توضيح متطلبات consumable usage الخاصة بـ Tableware. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-facet-03",
  "question_en": "Please clarify the consumable usage requirements for Tableware.",
  "question_ar": "يرجى توضيح متطلبات consumable usage الخاصة بـ Tableware.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the consumable usage requirements for Tableware. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-facet-03",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the fabric/finish durability requirements for Tableware.

Ask in plain language: Please clarify the fabric/finish durability requirements for Tableware. Arabic draft: يرجى توضيح متطلبات fabric/finish durability الخاصة بـ Tableware. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-facet-04",
  "question_en": "Please clarify the fabric/finish durability requirements for Tableware.",
  "question_ar": "يرجى توضيح متطلبات fabric/finish durability الخاصة بـ Tableware.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 230,
  "confidence_contribution": 0.012
}
```

### Please clarify the laundry/housekeeping interface requirements for Tableware.

Ask in plain language: Please clarify the laundry/housekeeping interface requirements for Tableware. Arabic draft: يرجى توضيح متطلبات laundry/housekeeping interface الخاصة بـ Tableware. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-facet-05",
  "question_en": "Please clarify the laundry/housekeeping interface requirements for Tableware.",
  "question_ar": "يرجى توضيح متطلبات laundry/housekeeping interface الخاصة بـ Tableware.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the packaging and replenishment requirements for Tableware.

Ask in plain language: Please clarify the packaging and replenishment requirements for Tableware. Arabic draft: يرجى توضيح متطلبات packaging and replenishment الخاصة بـ Tableware. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-facet-06",
  "question_en": "Please clarify the packaging and replenishment requirements for Tableware.",
  "question_ar": "يرجى توضيح متطلبات packaging and replenishment الخاصة بـ Tableware.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the sample approval requirements for Tableware.

Ask in plain language: Please clarify the sample approval requirements for Tableware. Arabic draft: يرجى توضيح متطلبات sample approval الخاصة بـ Tableware. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-facet-07",
  "question_en": "Please clarify the sample approval requirements for Tableware.",
  "question_ar": "يرجى توضيح متطلبات sample approval الخاصة بـ Tableware.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Which exact Tableware product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Tableware product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Tableware التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-exact-subtype",
  "question_en": "Which exact Tableware product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Tableware التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 270,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Tableware product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-ask-exact-subtype",
  "priority": 973,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-015-tableware-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Tableware are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Tableware are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Tableware التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-unknowns",
  "question_en": "Which details about Tableware are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Tableware التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 280,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Tableware?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Tableware? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Tableware؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-015-tableware-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Tableware?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Tableware؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Tableware, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Tableware, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Tableware, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Tableware, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0182`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA, UAE-DM-PUBLIC-HEALTH, UAE-CONSUMER-PROTECTION, UAE-MOIAT, ISO-STANDARDS

```json
{
  "rule_id": "R-015-tableware-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-DM-FOOD",
        "UAE-ADAFSA",
        "UAE-DM-PUBLIC-HEALTH",
        "UAE-CONSUMER-PROTECTION",
        "UAE-MOIAT",
        "ISO-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Tableware, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Tableware, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Tableware, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Tableware, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-015-tableware-inquiry_qualification-decision_rule-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-015-tableware-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Tableware, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-tableware-validation-validation_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-tableware-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Tableware, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-tableware-validation-validation_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-tableware-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Tableware, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-tableware-validation-validation_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-tableware-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Tableware, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-tableware-validation-validation_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-tableware-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Tableware, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-tableware-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-tableware-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Tableware, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-tableware-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-tableware-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Tableware, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-tableware-validation-validation_rule-0193`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-DM-FOOD, UAE-ADAFSA

```json
{
  "validation_id": "V-015-tableware-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Tableware, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-tableware-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-tableware-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Tableware, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-tableware-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-tableware-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Tableware, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-015-tableware-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-015-tableware-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Tableware without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-tableware-scenario_test-scenario-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-tableware-001",
  "setup": "Customer asks informally for Tableware without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Tableware with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-tableware-scenario_test-scenario-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-tableware-002",
  "setup": "Customer requests price for Tableware with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Tableware. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-tableware-scenario_test-scenario-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-tableware-003",
  "setup": "Customer uploads a relevant schedule/specification for Tableware.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Tableware. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-tableware-scenario_test-scenario-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-tableware-004",
  "setup": "Customer message and uploaded document disagree on Tableware.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Tableware. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-tableware-scenario_test-scenario-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-tableware-005",
  "setup": "Supplier proposes a different product, provider or method for Tableware.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Tableware sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-tableware-scenario_test-scenario-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-tableware-006",
  "setup": "Customer needs Tableware sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Tableware needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-015-tableware-scenario_test-scenario-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-015-tableware-007",
  "setup": "The request for Tableware needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Tableware

English term: Tableware. Arabic operational draft: متطلبات Tableware. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Tableware",
  "term_ar": "متطلبات Tableware",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### hotel category and brand standard

English term: hotel category and brand standard. Arabic operational draft: متطلبات hotel category and brand standard. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "hotel category and brand standard",
  "term_ar": "متطلبات hotel category and brand standard",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### room/outlet count

English term: room/outlet count. Arabic operational draft: متطلبات room/outlet count. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "room/outlet count",
  "term_ar": "متطلبات room/outlet count",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### consumable usage

English term: consumable usage. Arabic operational draft: متطلبات consumable usage. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "consumable usage",
  "term_ar": "متطلبات consumable usage",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### fabric/finish durability

English term: fabric/finish durability. Arabic operational draft: متطلبات fabric/finish durability. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "fabric/finish durability",
  "term_ar": "متطلبات fabric/finish durability",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### laundry/housekeeping interface

English term: laundry/housekeeping interface. Arabic operational draft: متطلبات laundry/housekeeping interface. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "laundry/housekeeping interface",
  "term_ar": "متطلبات laundry/housekeeping interface",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### packaging and replenishment

English term: packaging and replenishment. Arabic operational draft: متطلبات packaging and replenishment. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "packaging and replenishment",
  "term_ar": "متطلبات packaging and replenishment",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```

### sample approval

English term: sample approval. Arabic operational draft: متطلبات sample approval. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-015-tableware-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "sample approval",
  "term_ar": "متطلبات sample approval",
  "canonical_subcategory": "tableware",
  "normalization_only": true
}
```
