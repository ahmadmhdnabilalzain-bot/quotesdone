# QuotesDone Category 52 Knowledge Package

**Category:** Beauty, Wellness & Personal Care
**Subcategories:** 5
**Status:** production draft; not SME-approved

Use the numbered JSONL files for programmatic ingestion. `02_category_master.md` is a human-audit view and must not be inserted into every model prompt. Deterministic question, decision-rule and validation files reduce model use.
