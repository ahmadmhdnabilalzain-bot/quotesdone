# Government Tenders & Procurement Support — Complete Knowledge Master

**Package:** QD-KB-064-government-tenders-and-procurement-support-v2026.07.31  
**Arabic:** المناقصات الحكومية ودعم المشتريات  
**Status:** production draft; not SME/regulatory approved  
**Subcategories:** 4

> This is the human-audit view. Runtime must use atomic JSONL records, deterministic questions/rules and selective retrieval rather than loading this entire file into a prompt.


# 01. Tender consultants / مستشارو المناقصات

**Aliases:** Tender consultants

## industry — Industry scope — Tender consultants

Tender consultants sits within Government Tenders & Procurement Support and covers government tender, bid, prequalification and vendor-registration support where portal rules, eligibility, mandatory documents, deadlines, compliance matrices, bid securities and controlled submission determine validity. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Tender consultants","aliases_en":["Tender consultants"],"aliases_ar":["مستشارو المناقصات"],"sequence":1}`

## industry — UAE procurement workflow — Tender consultants

A typical UAE procurement path for Tender consultants moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Tender consultants","aliases_en":["Tender consultants"],"aliases_ar":["مستشارو المناقصات"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Tender consultants

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include lead consultant, bid manager, technical writer, commercial estimator, legal reviewer, document controller. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Tender consultants","aliases_en":["Tender consultants"],"aliases_ar":["مستشارو المناقصات"],"sequence":3}`

## industry — Scope boundaries and escalation — Tender consultants

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Tender consultants. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Tender consultants","aliases_en":["Tender consultants"],"aliases_ar":["مستشارو المناقصات"],"sequence":4}`

## products_services — tender advisory

tender advisory is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"tender advisory","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — bid-management service

bid-management service is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"bid-management service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — opportunity screening

opportunity screening is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"opportunity screening","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — prequalification package

prequalification package is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"prequalification package","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — vendor registration

vendor registration is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"vendor registration","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — portal registration

portal registration is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"portal registration","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — compliance matrix

compliance matrix is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"compliance matrix","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — technical proposal

technical proposal is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"technical proposal","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — commercial proposal

commercial proposal is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"commercial proposal","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — bid-security coordination

bid-security coordination is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"bid-security coordination","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — consortium/JV support

consortium/JV support is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"consortium/JV support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — clarification management

clarification management is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"clarification management","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — submission management

submission management is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"submission management","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — post-bid support

post-bid support is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"post-bid support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — contract-award handover

contract-award handover is a product or service family relevant to Tender consultants. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"contract-award handover","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — procuring entity and portal

Technical topic: procuring entity and portal. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"procuring entity and portal","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — tender reference

Technical topic: tender reference. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"tender reference","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — submission deadline

Technical topic: submission deadline. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"submission deadline","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — eligibility criteria

Technical topic: eligibility criteria. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"eligibility criteria","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — supplier registration status

Technical topic: supplier registration status. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"supplier registration status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — scope and lots

Technical topic: scope and lots. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"scope and lots","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — mandatory forms

Technical topic: mandatory forms. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"mandatory forms","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — technical compliance

Technical topic: technical compliance. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"technical compliance","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — commercial pricing format

Technical topic: commercial pricing format. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"commercial pricing format","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — bid bond/security

Technical topic: bid bond/security. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"bid bond/security","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — local content/SME requirements

Technical topic: local content/SME requirements. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"local content/SME requirements","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — consortium/JV structure

Technical topic: consortium/JV structure. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"consortium/JV structure","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — clarifications/addenda

Technical topic: clarifications/addenda. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"clarifications/addenda","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — document legalization

Technical topic: document legalization. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"document legalization","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — electronic submission

Technical topic: electronic submission. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"electronic submission","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — conflict and confidentiality

Technical topic: conflict and confidentiality. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"conflict and confidentiality","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — award/contract conditions

Technical topic: award/contract conditions. For Tender consultants, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"award/contract conditions","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — government-tender consultant

government-tender consultant is a supplier-market role or example for Tender consultants; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"government-tender consultant","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — bid-management firm

bid-management firm is a supplier-market role or example for Tender consultants; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"bid-management firm","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — prequalification specialist

prequalification specialist is a supplier-market role or example for Tender consultants; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"prequalification specialist","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — vendor-registration adviser

vendor-registration adviser is a supplier-market role or example for Tender consultants; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"vendor-registration adviser","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — technical proposal team

technical proposal team is a supplier-market role or example for Tender consultants; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"technical proposal team","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — public-procurement legal adviser

public-procurement legal adviser is a supplier-market role or example for Tender consultants; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"public-procurement legal adviser","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — lead consultant

Supplier type: lead consultant. In Tender consultants, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"lead consultant","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — lead consultant

Eligibility gate 1 for a lead consultant responding to Tender consultants: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"lead consultant","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — bid manager

Supplier type: bid manager. In Tender consultants, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"bid manager","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — bid manager

Eligibility gate 2 for a bid manager responding to Tender consultants: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"bid manager","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — technical writer

Supplier type: technical writer. In Tender consultants, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"technical writer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — technical writer

Eligibility gate 3 for a technical writer responding to Tender consultants: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"technical writer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — commercial estimator

Supplier type: commercial estimator. In Tender consultants, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"commercial estimator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — commercial estimator

Eligibility gate 4 for a commercial estimator responding to Tender consultants: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"commercial estimator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — legal reviewer

Supplier type: legal reviewer. In Tender consultants, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"legal reviewer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — legal reviewer

Eligibility gate 5 for a legal reviewer responding to Tender consultants: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"legal reviewer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — document controller

Supplier type: document controller. In Tender consultants, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"document controller","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — document controller

Eligibility gate 6 for a document controller responding to Tender consultants: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"document controller","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — portal administrator

Supplier type: portal administrator. In Tender consultants, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"portal administrator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — portal administrator

Eligibility gate 7 for a portal administrator responding to Tender consultants: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"portal administrator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — subject-matter specialist

Supplier type: subject-matter specialist. In Tender consultants, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"subject-matter specialist","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — subject-matter specialist

Eligibility gate 8 for a subject-matter specialist responding to Tender consultants: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"subject-matter specialist","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — entity/tender reference

Quotation requirement: entity/tender reference. Every supplier response for Tender consultants should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"entity_tender_reference","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — scope and lots

Quotation requirement: scope and lots. Every supplier response for Tender consultants should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"scope_and_lots","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — eligibility/PQ

Quotation requirement: eligibility/PQ. Every supplier response for Tender consultants should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"eligibility_pq","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — mandatory documents

Quotation requirement: mandatory documents. Every supplier response for Tender consultants should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"mandatory_documents","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — technical response

Quotation requirement: technical response. Every supplier response for Tender consultants should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"technical_response","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — commercial template

Quotation requirement: commercial template. Every supplier response for Tender consultants should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"commercial_template","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — security/guarantee

Quotation requirement: security/guarantee. Every supplier response for Tender consultants should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"security_guarantee","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — portal/deadline

Quotation requirement: portal/deadline. Every supplier response for Tender consultants should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"portal_deadline","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — clarifications/addenda

Quotation requirement: clarifications/addenda. Every supplier response for Tender consultants should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"clarifications_addenda","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — submission and audit trail

Quotation requirement: submission and audit trail. Every supplier response for Tender consultants should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"submission_and_audit_trail","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — tender notice

Document: tender notice. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"tender_notice","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — instructions to bidders

Document: instructions to bidders. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"instructions_to_bidders","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — scope/specification

Document: scope/specification. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"scope_specification","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — eligibility criteria

Document: eligibility criteria. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"eligibility_criteria","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — prequalification questionnaire

Document: prequalification questionnaire. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"prequalification_questionnaire","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — mandatory forms

Document: mandatory forms. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"mandatory_forms","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — technical schedules

Document: technical schedules. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"technical_schedules","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — pricing schedule

Document: pricing schedule. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"pricing_schedule","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — bid-security wording

Document: bid-security wording. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"bid_security_wording","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — addenda/clarifications

Document: addenda/clarifications. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"addenda_clarifications","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — company legal documents

Document: company legal documents. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"company_legal_documents","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — experience/references

Document: experience/references. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"experience_references","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — submission checklist

Document: submission checklist. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"submission_checklist","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — portal receipt/audit trail

Document: portal receipt/audit trail. For Tender consultants, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"portal_receipt_audit_trail","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — UAE Federal Procurement Operations and Digital Procurement Platform

Source activation for Tender consultants: UAE Federal Procurement Operations and Digital Procurement Platform (UAE Ministry of Finance). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registry, catalogue, tender and federal procurement requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT
- Structured data: `{"source_id":"UAE-MOF-PROCUREMENT","publisher":"UAE Ministry of Finance","url":"https://mof.gov.ae/government-procurement-operations/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Dubai Government eSupply Procurement Portal

Source activation for Tender consultants: Dubai Government eSupply Procurement Portal (Government of Dubai). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify registration, opportunity, submission and portal instructions for each tender.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DUBAI-ESUPPLY
- Structured data: `{"source_id":"UAE-DUBAI-ESUPPLY","publisher":"Government of Dubai","url":"https://esupply.dubai.gov.ae/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Abu Dhabi Government Procurement Gate

Source activation for Tender consultants: Abu Dhabi Government Procurement Gate (Government of Abu Dhabi). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registration, tender, prequalification and current portal requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-ADGPG
- Structured data: `{"source_id":"UAE-ADGPG","publisher":"Government of Abu Dhabi","url":"https://www.adgpg.gov.ae/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Tender consultants: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Tender consultants: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — ISO Standards Catalogue

Source activation for Tender consultants: ISO Standards Catalogue (International Organization for Standardization). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Do not reproduce paid standards; use licensed current editions and approved summaries.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: ISO-STANDARDS
- Structured data: `{"source_id":"ISO-STANDARDS","publisher":"International Organization for Standardization","url":"https://www.iso.org/standards.html","source_type":"paid_standard_reference","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Tender consultants: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Federal Procurement Operations and Digital Procurement Platform

Source activation for Tender consultants: UAE Federal Procurement Operations and Digital Procurement Platform (UAE Ministry of Finance). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registry, catalogue, tender and federal procurement requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT
- Structured data: `{"source_id":"UAE-MOF-PROCUREMENT","publisher":"UAE Ministry of Finance","url":"https://mof.gov.ae/government-procurement-operations/","source_type":"government_procurement_portal","live_verification":true}`

## inquiry_qualification — Entity/Tender

Ask: Which government entity, procurement portal and tender reference are involved? Arabic: يرجى توضيح entity/tender بالنسبة إلى مستشارو المناقصات. Reason: entity/tender is required to make Tender consultants quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-domain_1","question_en":"Which government entity, procurement portal and tender reference are involved?","question_ar":"يرجى توضيح entity/tender بالنسبة إلى مستشارو المناقصات.","internal_label_en":"entity/tender","internal_label_ar":"متطلب مستشارو المناقصات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Scope/Eligibility

Ask: What scope, lot structure, eligibility, classification and supplier-registration requirements apply? Arabic: يرجى توضيح scope/eligibility بالنسبة إلى مستشارو المناقصات. Reason: scope/eligibility is required to make Tender consultants quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-domain_2","question_en":"What scope, lot structure, eligibility, classification and supplier-registration requirements apply?","question_ar":"يرجى توضيح scope/eligibility بالنسبة إلى مستشارو المناقصات.","internal_label_en":"scope/eligibility","internal_label_ar":"متطلب مستشارو المناقصات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Mandatory Documents

Ask: What mandatory legal, financial, technical, experience and authorization documents are required? Arabic: يرجى توضيح mandatory documents بالنسبة إلى مستشارو المناقصات. Reason: mandatory documents is required to make Tender consultants quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-domain_3","question_en":"What mandatory legal, financial, technical, experience and authorization documents are required?","question_ar":"يرجى توضيح mandatory documents بالنسبة إلى مستشارو المناقصات.","internal_label_en":"mandatory documents","internal_label_ar":"متطلب مستشارو المناقصات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Technical Response

Ask: What technical schedules, method, staffing, compliance matrix and deviations must be completed? Arabic: يرجى توضيح technical response بالنسبة إلى مستشارو المناقصات. Reason: technical response is required to make Tender consultants quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-domain_4","question_en":"What technical schedules, method, staffing, compliance matrix and deviations must be completed?","question_ar":"يرجى توضيح technical response بالنسبة إلى مستشارو المناقصات.","internal_label_en":"technical response","internal_label_ar":"متطلب مستشارو المناقصات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Commercial/Security

Ask: What pricing template, bid bond, guarantee, tax, local-content or commercial conditions apply? Arabic: يرجى توضيح commercial/security بالنسبة إلى مستشارو المناقصات. Reason: commercial/security is required to make Tender consultants quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-domain_5","question_en":"What pricing template, bid bond, guarantee, tax, local-content or commercial conditions apply?","question_ar":"يرجى توضيح commercial/security بالنسبة إلى مستشارو المناقصات.","internal_label_en":"commercial/security","internal_label_ar":"متطلب مستشارو المناقصات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Clarifications/Structure

Ask: What clarifications, addenda, site visits, consortium/JV and conflict rules apply? Arabic: يرجى توضيح clarifications/structure بالنسبة إلى مستشارو المناقصات. Reason: clarifications/structure is required to make Tender consultants quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-domain_6","question_en":"What clarifications, addenda, site visits, consortium/JV and conflict rules apply?","question_ar":"يرجى توضيح clarifications/structure بالنسبة إلى مستشارو المناقصات.","internal_label_en":"clarifications/structure","internal_label_ar":"متطلب مستشارو المناقصات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Submission/Control

Ask: What submission deadline, portal method, signatures, encryption, audit trail and post-submission support are required? Arabic: يرجى توضيح submission/control بالنسبة إلى مستشارو المناقصات. Reason: submission/control is required to make Tender consultants quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-domain_7","question_en":"What submission deadline, portal method, signatures, encryption, audit trail and post-submission support are required?","question_ar":"يرجى توضيح submission/control بالنسبة إلى مستشارو المناقصات.","internal_label_en":"submission/control","internal_label_ar":"متطلب مستشارو المناقصات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Tender consultants quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Tender consultants quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Tender consultants quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Tender consultants quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Tender consultants quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Tender consultants quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Tender consultants quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Tender consultants quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Tender consultants quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Tender consultants quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Tender consultants quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Tender consultants quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Tender consultants quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Tender consultants quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Tender consultants quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Tender consultants quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Tender consultants quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Tender consultants quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Tender consultants quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Tender consultants quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Tender consultants quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Tender consultants quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-tender-consultants-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Tender consultants, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-tender-consultants-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-tender-consultants-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Tender consultants; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-tender-consultants-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Tender consultants; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-tender-consultants-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Tender consultants; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-tender-consultants-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Tender consultants; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-tender-consultants-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Tender consultants; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-tender-consultants-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Tender consultants: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-tender-consultants-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Tender consultants: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-tender-consultants-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Tender consultants: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-tender-consultants-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Tender consultants: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-tender-consultants-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Tender consultants: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-tender-consultants-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Tender consultants: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-tender-consultants-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Tender consultants: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-tender-consultants-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Tender consultants: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-tender-consultants-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Tender consultants: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-tender-consultants-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Tender consultants: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-tender-consultants-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — tender size/complexity

Cost driver: tender size/complexity. This factor can materially change a Tender consultants quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"tender size/complexity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — number of lots/forms

Cost driver: number of lots/forms. This factor can materially change a Tender consultants quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"number of lots/forms","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — technical writing and estimating

Cost driver: technical writing and estimating. This factor can materially change a Tender consultants quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"technical writing and estimating","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — legalization and securities

Cost driver: legalization and securities. This factor can materially change a Tender consultants quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"legalization and securities","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — portal/deadline urgency

Cost driver: portal/deadline urgency. This factor can materially change a Tender consultants quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"portal/deadline urgency","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — consortium and stakeholder coordination

Cost driver: consortium and stakeholder coordination. This factor can materially change a Tender consultants quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"consortium and stakeholder coordination","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Tender consultants quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Tender consultants quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Tender consultants quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Tender consultants quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Tender consultants: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Tender consultants: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Tender consultants: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Tender consultants: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Tender consultants: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Tender consultants: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Tender consultants: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Tender consultants: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Tender consultants: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Tender consultants: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — missed deadline

Risk: missed deadline. For Tender consultants, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"missed deadline","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — mandatory document omitted

Risk: mandatory document omitted. For Tender consultants, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"mandatory document omitted","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — noncompliant template

Risk: noncompliant template. For Tender consultants, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"noncompliant template","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — invalid security

Risk: invalid security. For Tender consultants, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"invalid security","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — unauthorized signature

Risk: unauthorized signature. For Tender consultants, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"unauthorized signature","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — untracked addendum or portal failure

Risk: untracked addendum or portal failure. For Tender consultants, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"untracked addendum or portal failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Tender consultants, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Tender consultants, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Tender consultants, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Tender consultants, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Tender consultants: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Tender consultants: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Tender consultants: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Tender consultants: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Tender consultants: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Tender consultants: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Tender consultants, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Tender consultants, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Tender consultants, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Tender consultants, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Tender consultants, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Tender consultants, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Tender consultants, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Tender consultants, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Tender consultants: vague public request. Input: I need help with Tender consultants but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-tender-consultants-01","input":{"message":"I need help with Tender consultants but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Tender consultants: minimum quote-ready request. Input: Customer requests Tender consultants and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-tender-consultants-02","input":{"message":"Customer requests Tender consultants and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Tender consultants: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-tender-consultants-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Tender consultants: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-tender-consultants-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Tender consultants: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-tender-consultants-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Tender consultants: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-tender-consultants-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Tender consultants: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-tender-consultants-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — RFP

English term: RFP. Arabic operational label: مصطلح RFP ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"RFP","term_ar":"مصطلح RFP ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — RFQ

English term: RFQ. Arabic operational label: مصطلح RFQ ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"RFQ","term_ar":"مصطلح RFQ ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — ITT

English term: ITT. Arabic operational label: مصطلح ITT ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"ITT","term_ar":"مصطلح ITT ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — EOI

English term: EOI. Arabic operational label: مصطلح EOI ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"EOI","term_ar":"مصطلح EOI ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — prequalification

English term: prequalification. Arabic operational label: مصطلح prequalification ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"prequalification","term_ar":"مصطلح prequalification ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — vendor registration

English term: vendor registration. Arabic operational label: مصطلح vendor registration ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"vendor registration","term_ar":"مصطلح vendor registration ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — bid bond

English term: bid bond. Arabic operational label: مصطلح bid bond ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"bid bond","term_ar":"مصطلح bid bond ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — performance guarantee

English term: performance guarantee. Arabic operational label: مصطلح performance guarantee ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"performance guarantee","term_ar":"مصطلح performance guarantee ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — addendum

English term: addendum. Arabic operational label: مصطلح addendum ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"addendum","term_ar":"مصطلح addendum ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — clarification

English term: clarification. Arabic operational label: مصطلح clarification ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"clarification","term_ar":"مصطلح clarification ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — technical proposal

English term: technical proposal. Arabic operational label: مصطلح technical proposal ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical proposal","term_ar":"مصطلح technical proposal ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — commercial proposal

English term: commercial proposal. Arabic operational label: مصطلح commercial proposal ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"commercial proposal","term_ar":"مصطلح commercial proposal ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — portal submission

English term: portal submission. Arabic operational label: مصطلح portal submission ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"portal submission","term_ar":"مصطلح portal submission ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — submission deadline

English term: submission deadline. Arabic operational label: مصطلح submission deadline ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"submission deadline","term_ar":"مصطلح submission deadline ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — audit trail

English term: audit trail. Arabic operational label: مصطلح audit trail ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"audit trail","term_ar":"مصطلح audit trail ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"tender-consultants","normalization_only":true}`

## glossary — technical requirement

English term: technical requirement. Arabic operational label: مصطلح technical requirement ضمن مستشارو المناقصات. Use this pair for customer-language normalization, routing and supplier-facing output for Tender consultants. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-tender-consultants-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical requirement","term_ar":"مصطلح technical requirement ضمن مستشارو المناقصات","canonical_subcategory":"tender-consultants","normalization_only":true}`


# 02. Bid management / إدارة العطاءات

**Aliases:** Bid management

## industry — Industry scope — Bid management

Bid management sits within Government Tenders & Procurement Support and covers government tender, bid, prequalification and vendor-registration support where portal rules, eligibility, mandatory documents, deadlines, compliance matrices, bid securities and controlled submission determine validity. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Bid management","aliases_en":["Bid management"],"aliases_ar":["إدارة العطاءات"],"sequence":1}`

## industry — UAE procurement workflow — Bid management

A typical UAE procurement path for Bid management moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Bid management","aliases_en":["Bid management"],"aliases_ar":["إدارة العطاءات"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Bid management

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include lead consultant, bid manager, technical writer, commercial estimator, legal reviewer, document controller. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Bid management","aliases_en":["Bid management"],"aliases_ar":["إدارة العطاءات"],"sequence":3}`

## industry — Scope boundaries and escalation — Bid management

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Bid management. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Bid management","aliases_en":["Bid management"],"aliases_ar":["إدارة العطاءات"],"sequence":4}`

## products_services — tender advisory

tender advisory is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"tender advisory","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — bid-management service

bid-management service is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"bid-management service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — opportunity screening

opportunity screening is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"opportunity screening","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — prequalification package

prequalification package is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"prequalification package","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — vendor registration

vendor registration is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"vendor registration","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — portal registration

portal registration is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"portal registration","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — compliance matrix

compliance matrix is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"compliance matrix","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — technical proposal

technical proposal is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"technical proposal","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — commercial proposal

commercial proposal is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"commercial proposal","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — bid-security coordination

bid-security coordination is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"bid-security coordination","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — consortium/JV support

consortium/JV support is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"consortium/JV support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — clarification management

clarification management is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"clarification management","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — submission management

submission management is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"submission management","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — post-bid support

post-bid support is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"post-bid support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — contract-award handover

contract-award handover is a product or service family relevant to Bid management. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"contract-award handover","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — procuring entity and portal

Technical topic: procuring entity and portal. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"procuring entity and portal","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — tender reference

Technical topic: tender reference. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"tender reference","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — submission deadline

Technical topic: submission deadline. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"submission deadline","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — eligibility criteria

Technical topic: eligibility criteria. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"eligibility criteria","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — supplier registration status

Technical topic: supplier registration status. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"supplier registration status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — scope and lots

Technical topic: scope and lots. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"scope and lots","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — mandatory forms

Technical topic: mandatory forms. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"mandatory forms","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — technical compliance

Technical topic: technical compliance. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"technical compliance","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — commercial pricing format

Technical topic: commercial pricing format. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"commercial pricing format","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — bid bond/security

Technical topic: bid bond/security. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"bid bond/security","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — local content/SME requirements

Technical topic: local content/SME requirements. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"local content/SME requirements","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — consortium/JV structure

Technical topic: consortium/JV structure. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"consortium/JV structure","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — clarifications/addenda

Technical topic: clarifications/addenda. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"clarifications/addenda","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — document legalization

Technical topic: document legalization. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"document legalization","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — electronic submission

Technical topic: electronic submission. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"electronic submission","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — conflict and confidentiality

Technical topic: conflict and confidentiality. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"conflict and confidentiality","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — award/contract conditions

Technical topic: award/contract conditions. For Bid management, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"award/contract conditions","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — government-tender consultant

government-tender consultant is a supplier-market role or example for Bid management; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"government-tender consultant","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — bid-management firm

bid-management firm is a supplier-market role or example for Bid management; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"bid-management firm","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — prequalification specialist

prequalification specialist is a supplier-market role or example for Bid management; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"prequalification specialist","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — vendor-registration adviser

vendor-registration adviser is a supplier-market role or example for Bid management; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"vendor-registration adviser","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — technical proposal team

technical proposal team is a supplier-market role or example for Bid management; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"technical proposal team","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — public-procurement legal adviser

public-procurement legal adviser is a supplier-market role or example for Bid management; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"public-procurement legal adviser","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — lead consultant

Supplier type: lead consultant. In Bid management, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"lead consultant","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — lead consultant

Eligibility gate 1 for a lead consultant responding to Bid management: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"lead consultant","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — bid manager

Supplier type: bid manager. In Bid management, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"bid manager","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — bid manager

Eligibility gate 2 for a bid manager responding to Bid management: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"bid manager","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — technical writer

Supplier type: technical writer. In Bid management, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"technical writer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — technical writer

Eligibility gate 3 for a technical writer responding to Bid management: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"technical writer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — commercial estimator

Supplier type: commercial estimator. In Bid management, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"commercial estimator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — commercial estimator

Eligibility gate 4 for a commercial estimator responding to Bid management: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"commercial estimator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — legal reviewer

Supplier type: legal reviewer. In Bid management, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"legal reviewer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — legal reviewer

Eligibility gate 5 for a legal reviewer responding to Bid management: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"legal reviewer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — document controller

Supplier type: document controller. In Bid management, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"document controller","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — document controller

Eligibility gate 6 for a document controller responding to Bid management: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"document controller","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — portal administrator

Supplier type: portal administrator. In Bid management, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"portal administrator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — portal administrator

Eligibility gate 7 for a portal administrator responding to Bid management: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"portal administrator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — subject-matter specialist

Supplier type: subject-matter specialist. In Bid management, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"subject-matter specialist","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — subject-matter specialist

Eligibility gate 8 for a subject-matter specialist responding to Bid management: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"subject-matter specialist","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — entity/tender reference

Quotation requirement: entity/tender reference. Every supplier response for Bid management should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"entity_tender_reference","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — scope and lots

Quotation requirement: scope and lots. Every supplier response for Bid management should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"scope_and_lots","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — eligibility/PQ

Quotation requirement: eligibility/PQ. Every supplier response for Bid management should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"eligibility_pq","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — mandatory documents

Quotation requirement: mandatory documents. Every supplier response for Bid management should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"mandatory_documents","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — technical response

Quotation requirement: technical response. Every supplier response for Bid management should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"technical_response","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — commercial template

Quotation requirement: commercial template. Every supplier response for Bid management should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"commercial_template","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — security/guarantee

Quotation requirement: security/guarantee. Every supplier response for Bid management should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"security_guarantee","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — portal/deadline

Quotation requirement: portal/deadline. Every supplier response for Bid management should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"portal_deadline","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — clarifications/addenda

Quotation requirement: clarifications/addenda. Every supplier response for Bid management should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"clarifications_addenda","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — submission and audit trail

Quotation requirement: submission and audit trail. Every supplier response for Bid management should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"submission_and_audit_trail","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — tender notice

Document: tender notice. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"tender_notice","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — instructions to bidders

Document: instructions to bidders. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"instructions_to_bidders","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — scope/specification

Document: scope/specification. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"scope_specification","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — eligibility criteria

Document: eligibility criteria. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"eligibility_criteria","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — prequalification questionnaire

Document: prequalification questionnaire. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"prequalification_questionnaire","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — mandatory forms

Document: mandatory forms. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"mandatory_forms","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — technical schedules

Document: technical schedules. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"technical_schedules","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — pricing schedule

Document: pricing schedule. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"pricing_schedule","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — bid-security wording

Document: bid-security wording. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"bid_security_wording","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — addenda/clarifications

Document: addenda/clarifications. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"addenda_clarifications","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — company legal documents

Document: company legal documents. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"company_legal_documents","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — experience/references

Document: experience/references. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"experience_references","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — submission checklist

Document: submission checklist. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"submission_checklist","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — portal receipt/audit trail

Document: portal receipt/audit trail. For Bid management, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"portal_receipt_audit_trail","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — UAE Federal Procurement Operations and Digital Procurement Platform

Source activation for Bid management: UAE Federal Procurement Operations and Digital Procurement Platform (UAE Ministry of Finance). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registry, catalogue, tender and federal procurement requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT
- Structured data: `{"source_id":"UAE-MOF-PROCUREMENT","publisher":"UAE Ministry of Finance","url":"https://mof.gov.ae/government-procurement-operations/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Dubai Government eSupply Procurement Portal

Source activation for Bid management: Dubai Government eSupply Procurement Portal (Government of Dubai). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify registration, opportunity, submission and portal instructions for each tender.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DUBAI-ESUPPLY
- Structured data: `{"source_id":"UAE-DUBAI-ESUPPLY","publisher":"Government of Dubai","url":"https://esupply.dubai.gov.ae/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Abu Dhabi Government Procurement Gate

Source activation for Bid management: Abu Dhabi Government Procurement Gate (Government of Abu Dhabi). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registration, tender, prequalification and current portal requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-ADGPG
- Structured data: `{"source_id":"UAE-ADGPG","publisher":"Government of Abu Dhabi","url":"https://www.adgpg.gov.ae/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Bid management: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Bid management: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — ISO Standards Catalogue

Source activation for Bid management: ISO Standards Catalogue (International Organization for Standardization). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Do not reproduce paid standards; use licensed current editions and approved summaries.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: ISO-STANDARDS
- Structured data: `{"source_id":"ISO-STANDARDS","publisher":"International Organization for Standardization","url":"https://www.iso.org/standards.html","source_type":"paid_standard_reference","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Bid management: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Federal Procurement Operations and Digital Procurement Platform

Source activation for Bid management: UAE Federal Procurement Operations and Digital Procurement Platform (UAE Ministry of Finance). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registry, catalogue, tender and federal procurement requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT
- Structured data: `{"source_id":"UAE-MOF-PROCUREMENT","publisher":"UAE Ministry of Finance","url":"https://mof.gov.ae/government-procurement-operations/","source_type":"government_procurement_portal","live_verification":true}`

## inquiry_qualification — Entity/Tender

Ask: Which government entity, procurement portal and tender reference are involved? Arabic: يرجى توضيح entity/tender بالنسبة إلى إدارة العطاءات. Reason: entity/tender is required to make Bid management quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-domain_1","question_en":"Which government entity, procurement portal and tender reference are involved?","question_ar":"يرجى توضيح entity/tender بالنسبة إلى إدارة العطاءات.","internal_label_en":"entity/tender","internal_label_ar":"متطلب إدارة العطاءات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Scope/Eligibility

Ask: What scope, lot structure, eligibility, classification and supplier-registration requirements apply? Arabic: يرجى توضيح scope/eligibility بالنسبة إلى إدارة العطاءات. Reason: scope/eligibility is required to make Bid management quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-domain_2","question_en":"What scope, lot structure, eligibility, classification and supplier-registration requirements apply?","question_ar":"يرجى توضيح scope/eligibility بالنسبة إلى إدارة العطاءات.","internal_label_en":"scope/eligibility","internal_label_ar":"متطلب إدارة العطاءات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Mandatory Documents

Ask: What mandatory legal, financial, technical, experience and authorization documents are required? Arabic: يرجى توضيح mandatory documents بالنسبة إلى إدارة العطاءات. Reason: mandatory documents is required to make Bid management quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-domain_3","question_en":"What mandatory legal, financial, technical, experience and authorization documents are required?","question_ar":"يرجى توضيح mandatory documents بالنسبة إلى إدارة العطاءات.","internal_label_en":"mandatory documents","internal_label_ar":"متطلب إدارة العطاءات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Technical Response

Ask: What technical schedules, method, staffing, compliance matrix and deviations must be completed? Arabic: يرجى توضيح technical response بالنسبة إلى إدارة العطاءات. Reason: technical response is required to make Bid management quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-domain_4","question_en":"What technical schedules, method, staffing, compliance matrix and deviations must be completed?","question_ar":"يرجى توضيح technical response بالنسبة إلى إدارة العطاءات.","internal_label_en":"technical response","internal_label_ar":"متطلب إدارة العطاءات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Commercial/Security

Ask: What pricing template, bid bond, guarantee, tax, local-content or commercial conditions apply? Arabic: يرجى توضيح commercial/security بالنسبة إلى إدارة العطاءات. Reason: commercial/security is required to make Bid management quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-domain_5","question_en":"What pricing template, bid bond, guarantee, tax, local-content or commercial conditions apply?","question_ar":"يرجى توضيح commercial/security بالنسبة إلى إدارة العطاءات.","internal_label_en":"commercial/security","internal_label_ar":"متطلب إدارة العطاءات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Clarifications/Structure

Ask: What clarifications, addenda, site visits, consortium/JV and conflict rules apply? Arabic: يرجى توضيح clarifications/structure بالنسبة إلى إدارة العطاءات. Reason: clarifications/structure is required to make Bid management quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-domain_6","question_en":"What clarifications, addenda, site visits, consortium/JV and conflict rules apply?","question_ar":"يرجى توضيح clarifications/structure بالنسبة إلى إدارة العطاءات.","internal_label_en":"clarifications/structure","internal_label_ar":"متطلب إدارة العطاءات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Submission/Control

Ask: What submission deadline, portal method, signatures, encryption, audit trail and post-submission support are required? Arabic: يرجى توضيح submission/control بالنسبة إلى إدارة العطاءات. Reason: submission/control is required to make Bid management quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-domain_7","question_en":"What submission deadline, portal method, signatures, encryption, audit trail and post-submission support are required?","question_ar":"يرجى توضيح submission/control بالنسبة إلى إدارة العطاءات.","internal_label_en":"submission/control","internal_label_ar":"متطلب إدارة العطاءات","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Bid management quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Bid management quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Bid management quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Bid management quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Bid management quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Bid management quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Bid management quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Bid management quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Bid management quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Bid management quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Bid management quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Bid management quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Bid management quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Bid management quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Bid management quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Bid management quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Bid management quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Bid management quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Bid management quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Bid management quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Bid management quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Bid management quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-bid-management-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Bid management, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-bid-management-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-bid-management-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Bid management; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-bid-management-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Bid management; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-bid-management-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Bid management; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-bid-management-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Bid management; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-bid-management-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Bid management; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-bid-management-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Bid management: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-bid-management-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Bid management: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-bid-management-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Bid management: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-bid-management-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Bid management: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-bid-management-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Bid management: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-bid-management-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Bid management: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-bid-management-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Bid management: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-bid-management-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Bid management: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-bid-management-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Bid management: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-bid-management-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Bid management: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-bid-management-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — tender size/complexity

Cost driver: tender size/complexity. This factor can materially change a Bid management quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"tender size/complexity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — number of lots/forms

Cost driver: number of lots/forms. This factor can materially change a Bid management quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"number of lots/forms","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — technical writing and estimating

Cost driver: technical writing and estimating. This factor can materially change a Bid management quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"technical writing and estimating","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — legalization and securities

Cost driver: legalization and securities. This factor can materially change a Bid management quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"legalization and securities","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — portal/deadline urgency

Cost driver: portal/deadline urgency. This factor can materially change a Bid management quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"portal/deadline urgency","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — consortium and stakeholder coordination

Cost driver: consortium and stakeholder coordination. This factor can materially change a Bid management quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"consortium and stakeholder coordination","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Bid management quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Bid management quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Bid management quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Bid management quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Bid management: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Bid management: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Bid management: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Bid management: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Bid management: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Bid management: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Bid management: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Bid management: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Bid management: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Bid management: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — missed deadline

Risk: missed deadline. For Bid management, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"missed deadline","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — mandatory document omitted

Risk: mandatory document omitted. For Bid management, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"mandatory document omitted","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — noncompliant template

Risk: noncompliant template. For Bid management, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"noncompliant template","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — invalid security

Risk: invalid security. For Bid management, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"invalid security","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — unauthorized signature

Risk: unauthorized signature. For Bid management, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"unauthorized signature","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — untracked addendum or portal failure

Risk: untracked addendum or portal failure. For Bid management, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"untracked addendum or portal failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Bid management, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Bid management, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Bid management, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Bid management, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Bid management: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Bid management: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Bid management: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Bid management: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Bid management: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Bid management: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Bid management, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Bid management, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Bid management, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Bid management, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Bid management, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Bid management, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Bid management, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Bid management, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Bid management: vague public request. Input: I need help with Bid management but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-bid-management-01","input":{"message":"I need help with Bid management but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Bid management: minimum quote-ready request. Input: Customer requests Bid management and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-bid-management-02","input":{"message":"Customer requests Bid management and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Bid management: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-bid-management-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Bid management: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-bid-management-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Bid management: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-bid-management-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Bid management: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-bid-management-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Bid management: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-bid-management-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — RFP

English term: RFP. Arabic operational label: مصطلح RFP ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"RFP","term_ar":"مصطلح RFP ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — RFQ

English term: RFQ. Arabic operational label: مصطلح RFQ ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"RFQ","term_ar":"مصطلح RFQ ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — ITT

English term: ITT. Arabic operational label: مصطلح ITT ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"ITT","term_ar":"مصطلح ITT ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — EOI

English term: EOI. Arabic operational label: مصطلح EOI ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"EOI","term_ar":"مصطلح EOI ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — prequalification

English term: prequalification. Arabic operational label: مصطلح prequalification ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"prequalification","term_ar":"مصطلح prequalification ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — vendor registration

English term: vendor registration. Arabic operational label: مصطلح vendor registration ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"vendor registration","term_ar":"مصطلح vendor registration ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — bid bond

English term: bid bond. Arabic operational label: مصطلح bid bond ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"bid bond","term_ar":"مصطلح bid bond ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — performance guarantee

English term: performance guarantee. Arabic operational label: مصطلح performance guarantee ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"performance guarantee","term_ar":"مصطلح performance guarantee ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — addendum

English term: addendum. Arabic operational label: مصطلح addendum ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"addendum","term_ar":"مصطلح addendum ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — clarification

English term: clarification. Arabic operational label: مصطلح clarification ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"clarification","term_ar":"مصطلح clarification ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — technical proposal

English term: technical proposal. Arabic operational label: مصطلح technical proposal ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical proposal","term_ar":"مصطلح technical proposal ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — commercial proposal

English term: commercial proposal. Arabic operational label: مصطلح commercial proposal ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"commercial proposal","term_ar":"مصطلح commercial proposal ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — portal submission

English term: portal submission. Arabic operational label: مصطلح portal submission ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"portal submission","term_ar":"مصطلح portal submission ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — submission deadline

English term: submission deadline. Arabic operational label: مصطلح submission deadline ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"submission deadline","term_ar":"مصطلح submission deadline ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — audit trail

English term: audit trail. Arabic operational label: مصطلح audit trail ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"audit trail","term_ar":"مصطلح audit trail ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"bid-management","normalization_only":true}`

## glossary — technical requirement

English term: technical requirement. Arabic operational label: مصطلح technical requirement ضمن إدارة العطاءات. Use this pair for customer-language normalization, routing and supplier-facing output for Bid management. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-bid-management-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical requirement","term_ar":"مصطلح technical requirement ضمن إدارة العطاءات","canonical_subcategory":"bid-management","normalization_only":true}`


# 03. Prequalification / التأهيل المسبق

**Aliases:** Prequalification

## industry — Industry scope — Prequalification

Prequalification sits within Government Tenders & Procurement Support and covers government tender, bid, prequalification and vendor-registration support where portal rules, eligibility, mandatory documents, deadlines, compliance matrices, bid securities and controlled submission determine validity. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Prequalification","aliases_en":["Prequalification"],"aliases_ar":["التأهيل المسبق"],"sequence":1}`

## industry — UAE procurement workflow — Prequalification

A typical UAE procurement path for Prequalification moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Prequalification","aliases_en":["Prequalification"],"aliases_ar":["التأهيل المسبق"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Prequalification

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include lead consultant, bid manager, technical writer, commercial estimator, legal reviewer, document controller. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Prequalification","aliases_en":["Prequalification"],"aliases_ar":["التأهيل المسبق"],"sequence":3}`

## industry — Scope boundaries and escalation — Prequalification

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Prequalification. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Prequalification","aliases_en":["Prequalification"],"aliases_ar":["التأهيل المسبق"],"sequence":4}`

## products_services — tender advisory

tender advisory is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"tender advisory","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — bid-management service

bid-management service is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"bid-management service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — opportunity screening

opportunity screening is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"opportunity screening","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — prequalification package

prequalification package is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"prequalification package","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — vendor registration

vendor registration is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"vendor registration","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — portal registration

portal registration is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"portal registration","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — compliance matrix

compliance matrix is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"compliance matrix","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — technical proposal

technical proposal is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"technical proposal","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — commercial proposal

commercial proposal is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"commercial proposal","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — bid-security coordination

bid-security coordination is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"bid-security coordination","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — consortium/JV support

consortium/JV support is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"consortium/JV support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — clarification management

clarification management is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"clarification management","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — submission management

submission management is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"submission management","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — post-bid support

post-bid support is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"post-bid support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — contract-award handover

contract-award handover is a product or service family relevant to Prequalification. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"contract-award handover","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — procuring entity and portal

Technical topic: procuring entity and portal. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"procuring entity and portal","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — tender reference

Technical topic: tender reference. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"tender reference","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — submission deadline

Technical topic: submission deadline. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"submission deadline","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — eligibility criteria

Technical topic: eligibility criteria. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"eligibility criteria","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — supplier registration status

Technical topic: supplier registration status. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"supplier registration status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — scope and lots

Technical topic: scope and lots. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"scope and lots","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — mandatory forms

Technical topic: mandatory forms. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"mandatory forms","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — technical compliance

Technical topic: technical compliance. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"technical compliance","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — commercial pricing format

Technical topic: commercial pricing format. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"commercial pricing format","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — bid bond/security

Technical topic: bid bond/security. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"bid bond/security","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — local content/SME requirements

Technical topic: local content/SME requirements. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"local content/SME requirements","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — consortium/JV structure

Technical topic: consortium/JV structure. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"consortium/JV structure","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — clarifications/addenda

Technical topic: clarifications/addenda. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"clarifications/addenda","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — document legalization

Technical topic: document legalization. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"document legalization","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — electronic submission

Technical topic: electronic submission. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"electronic submission","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — conflict and confidentiality

Technical topic: conflict and confidentiality. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"conflict and confidentiality","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — award/contract conditions

Technical topic: award/contract conditions. For Prequalification, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"award/contract conditions","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — government-tender consultant

government-tender consultant is a supplier-market role or example for Prequalification; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"government-tender consultant","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — bid-management firm

bid-management firm is a supplier-market role or example for Prequalification; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"bid-management firm","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — prequalification specialist

prequalification specialist is a supplier-market role or example for Prequalification; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"prequalification specialist","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — vendor-registration adviser

vendor-registration adviser is a supplier-market role or example for Prequalification; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"vendor-registration adviser","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — technical proposal team

technical proposal team is a supplier-market role or example for Prequalification; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"technical proposal team","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — public-procurement legal adviser

public-procurement legal adviser is a supplier-market role or example for Prequalification; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"public-procurement legal adviser","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — lead consultant

Supplier type: lead consultant. In Prequalification, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"lead consultant","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — lead consultant

Eligibility gate 1 for a lead consultant responding to Prequalification: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"lead consultant","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — bid manager

Supplier type: bid manager. In Prequalification, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"bid manager","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — bid manager

Eligibility gate 2 for a bid manager responding to Prequalification: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"bid manager","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — technical writer

Supplier type: technical writer. In Prequalification, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"technical writer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — technical writer

Eligibility gate 3 for a technical writer responding to Prequalification: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"technical writer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — commercial estimator

Supplier type: commercial estimator. In Prequalification, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"commercial estimator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — commercial estimator

Eligibility gate 4 for a commercial estimator responding to Prequalification: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"commercial estimator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — legal reviewer

Supplier type: legal reviewer. In Prequalification, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"legal reviewer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — legal reviewer

Eligibility gate 5 for a legal reviewer responding to Prequalification: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"legal reviewer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — document controller

Supplier type: document controller. In Prequalification, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"document controller","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — document controller

Eligibility gate 6 for a document controller responding to Prequalification: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"document controller","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — portal administrator

Supplier type: portal administrator. In Prequalification, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"portal administrator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — portal administrator

Eligibility gate 7 for a portal administrator responding to Prequalification: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"portal administrator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — subject-matter specialist

Supplier type: subject-matter specialist. In Prequalification, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"subject-matter specialist","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — subject-matter specialist

Eligibility gate 8 for a subject-matter specialist responding to Prequalification: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"subject-matter specialist","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — entity/tender reference

Quotation requirement: entity/tender reference. Every supplier response for Prequalification should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"entity_tender_reference","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — scope and lots

Quotation requirement: scope and lots. Every supplier response for Prequalification should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"scope_and_lots","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — eligibility/PQ

Quotation requirement: eligibility/PQ. Every supplier response for Prequalification should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"eligibility_pq","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — mandatory documents

Quotation requirement: mandatory documents. Every supplier response for Prequalification should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"mandatory_documents","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — technical response

Quotation requirement: technical response. Every supplier response for Prequalification should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"technical_response","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — commercial template

Quotation requirement: commercial template. Every supplier response for Prequalification should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"commercial_template","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — security/guarantee

Quotation requirement: security/guarantee. Every supplier response for Prequalification should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"security_guarantee","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — portal/deadline

Quotation requirement: portal/deadline. Every supplier response for Prequalification should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"portal_deadline","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — clarifications/addenda

Quotation requirement: clarifications/addenda. Every supplier response for Prequalification should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"clarifications_addenda","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — submission and audit trail

Quotation requirement: submission and audit trail. Every supplier response for Prequalification should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"submission_and_audit_trail","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — tender notice

Document: tender notice. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"tender_notice","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — instructions to bidders

Document: instructions to bidders. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"instructions_to_bidders","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — scope/specification

Document: scope/specification. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"scope_specification","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — eligibility criteria

Document: eligibility criteria. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"eligibility_criteria","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — prequalification questionnaire

Document: prequalification questionnaire. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"prequalification_questionnaire","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — mandatory forms

Document: mandatory forms. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"mandatory_forms","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — technical schedules

Document: technical schedules. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"technical_schedules","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — pricing schedule

Document: pricing schedule. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"pricing_schedule","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — bid-security wording

Document: bid-security wording. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"bid_security_wording","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — addenda/clarifications

Document: addenda/clarifications. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"addenda_clarifications","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — company legal documents

Document: company legal documents. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"company_legal_documents","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — experience/references

Document: experience/references. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"experience_references","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — submission checklist

Document: submission checklist. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"submission_checklist","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — portal receipt/audit trail

Document: portal receipt/audit trail. For Prequalification, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"portal_receipt_audit_trail","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — UAE Federal Procurement Operations and Digital Procurement Platform

Source activation for Prequalification: UAE Federal Procurement Operations and Digital Procurement Platform (UAE Ministry of Finance). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registry, catalogue, tender and federal procurement requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT
- Structured data: `{"source_id":"UAE-MOF-PROCUREMENT","publisher":"UAE Ministry of Finance","url":"https://mof.gov.ae/government-procurement-operations/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Dubai Government eSupply Procurement Portal

Source activation for Prequalification: Dubai Government eSupply Procurement Portal (Government of Dubai). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify registration, opportunity, submission and portal instructions for each tender.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DUBAI-ESUPPLY
- Structured data: `{"source_id":"UAE-DUBAI-ESUPPLY","publisher":"Government of Dubai","url":"https://esupply.dubai.gov.ae/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Abu Dhabi Government Procurement Gate

Source activation for Prequalification: Abu Dhabi Government Procurement Gate (Government of Abu Dhabi). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registration, tender, prequalification and current portal requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-ADGPG
- Structured data: `{"source_id":"UAE-ADGPG","publisher":"Government of Abu Dhabi","url":"https://www.adgpg.gov.ae/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Prequalification: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Prequalification: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — ISO Standards Catalogue

Source activation for Prequalification: ISO Standards Catalogue (International Organization for Standardization). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Do not reproduce paid standards; use licensed current editions and approved summaries.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: ISO-STANDARDS
- Structured data: `{"source_id":"ISO-STANDARDS","publisher":"International Organization for Standardization","url":"https://www.iso.org/standards.html","source_type":"paid_standard_reference","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Prequalification: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Federal Procurement Operations and Digital Procurement Platform

Source activation for Prequalification: UAE Federal Procurement Operations and Digital Procurement Platform (UAE Ministry of Finance). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registry, catalogue, tender and federal procurement requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT
- Structured data: `{"source_id":"UAE-MOF-PROCUREMENT","publisher":"UAE Ministry of Finance","url":"https://mof.gov.ae/government-procurement-operations/","source_type":"government_procurement_portal","live_verification":true}`

## inquiry_qualification — Entity/Tender

Ask: Which government entity, procurement portal and tender reference are involved? Arabic: يرجى توضيح entity/tender بالنسبة إلى التأهيل المسبق. Reason: entity/tender is required to make Prequalification quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-domain_1","question_en":"Which government entity, procurement portal and tender reference are involved?","question_ar":"يرجى توضيح entity/tender بالنسبة إلى التأهيل المسبق.","internal_label_en":"entity/tender","internal_label_ar":"متطلب التأهيل المسبق","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Scope/Eligibility

Ask: What scope, lot structure, eligibility, classification and supplier-registration requirements apply? Arabic: يرجى توضيح scope/eligibility بالنسبة إلى التأهيل المسبق. Reason: scope/eligibility is required to make Prequalification quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-domain_2","question_en":"What scope, lot structure, eligibility, classification and supplier-registration requirements apply?","question_ar":"يرجى توضيح scope/eligibility بالنسبة إلى التأهيل المسبق.","internal_label_en":"scope/eligibility","internal_label_ar":"متطلب التأهيل المسبق","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Mandatory Documents

Ask: What mandatory legal, financial, technical, experience and authorization documents are required? Arabic: يرجى توضيح mandatory documents بالنسبة إلى التأهيل المسبق. Reason: mandatory documents is required to make Prequalification quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-domain_3","question_en":"What mandatory legal, financial, technical, experience and authorization documents are required?","question_ar":"يرجى توضيح mandatory documents بالنسبة إلى التأهيل المسبق.","internal_label_en":"mandatory documents","internal_label_ar":"متطلب التأهيل المسبق","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Technical Response

Ask: What technical schedules, method, staffing, compliance matrix and deviations must be completed? Arabic: يرجى توضيح technical response بالنسبة إلى التأهيل المسبق. Reason: technical response is required to make Prequalification quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-domain_4","question_en":"What technical schedules, method, staffing, compliance matrix and deviations must be completed?","question_ar":"يرجى توضيح technical response بالنسبة إلى التأهيل المسبق.","internal_label_en":"technical response","internal_label_ar":"متطلب التأهيل المسبق","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Commercial/Security

Ask: What pricing template, bid bond, guarantee, tax, local-content or commercial conditions apply? Arabic: يرجى توضيح commercial/security بالنسبة إلى التأهيل المسبق. Reason: commercial/security is required to make Prequalification quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-domain_5","question_en":"What pricing template, bid bond, guarantee, tax, local-content or commercial conditions apply?","question_ar":"يرجى توضيح commercial/security بالنسبة إلى التأهيل المسبق.","internal_label_en":"commercial/security","internal_label_ar":"متطلب التأهيل المسبق","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Clarifications/Structure

Ask: What clarifications, addenda, site visits, consortium/JV and conflict rules apply? Arabic: يرجى توضيح clarifications/structure بالنسبة إلى التأهيل المسبق. Reason: clarifications/structure is required to make Prequalification quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-domain_6","question_en":"What clarifications, addenda, site visits, consortium/JV and conflict rules apply?","question_ar":"يرجى توضيح clarifications/structure بالنسبة إلى التأهيل المسبق.","internal_label_en":"clarifications/structure","internal_label_ar":"متطلب التأهيل المسبق","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Submission/Control

Ask: What submission deadline, portal method, signatures, encryption, audit trail and post-submission support are required? Arabic: يرجى توضيح submission/control بالنسبة إلى التأهيل المسبق. Reason: submission/control is required to make Prequalification quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-domain_7","question_en":"What submission deadline, portal method, signatures, encryption, audit trail and post-submission support are required?","question_ar":"يرجى توضيح submission/control بالنسبة إلى التأهيل المسبق.","internal_label_en":"submission/control","internal_label_ar":"متطلب التأهيل المسبق","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Prequalification quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Prequalification quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Prequalification quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Prequalification quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Prequalification quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Prequalification quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Prequalification quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Prequalification quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Prequalification quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Prequalification quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Prequalification quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Prequalification quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Prequalification quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Prequalification quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Prequalification quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Prequalification quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Prequalification quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Prequalification quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Prequalification quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Prequalification quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Prequalification quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Prequalification quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-prequalification-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Prequalification, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-prequalification-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-prequalification-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Prequalification; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-prequalification-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Prequalification; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-prequalification-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Prequalification; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-prequalification-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Prequalification; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-prequalification-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Prequalification; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-prequalification-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Prequalification: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-prequalification-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Prequalification: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-prequalification-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Prequalification: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-prequalification-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Prequalification: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-prequalification-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Prequalification: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-prequalification-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Prequalification: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-prequalification-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Prequalification: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-prequalification-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Prequalification: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-prequalification-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Prequalification: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-prequalification-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Prequalification: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-prequalification-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — tender size/complexity

Cost driver: tender size/complexity. This factor can materially change a Prequalification quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"tender size/complexity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — number of lots/forms

Cost driver: number of lots/forms. This factor can materially change a Prequalification quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"number of lots/forms","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — technical writing and estimating

Cost driver: technical writing and estimating. This factor can materially change a Prequalification quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"technical writing and estimating","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — legalization and securities

Cost driver: legalization and securities. This factor can materially change a Prequalification quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"legalization and securities","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — portal/deadline urgency

Cost driver: portal/deadline urgency. This factor can materially change a Prequalification quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"portal/deadline urgency","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — consortium and stakeholder coordination

Cost driver: consortium and stakeholder coordination. This factor can materially change a Prequalification quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"consortium and stakeholder coordination","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Prequalification quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Prequalification quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Prequalification quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Prequalification quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Prequalification: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Prequalification: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Prequalification: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Prequalification: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Prequalification: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Prequalification: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Prequalification: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Prequalification: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Prequalification: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Prequalification: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — missed deadline

Risk: missed deadline. For Prequalification, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"missed deadline","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — mandatory document omitted

Risk: mandatory document omitted. For Prequalification, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"mandatory document omitted","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — noncompliant template

Risk: noncompliant template. For Prequalification, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"noncompliant template","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — invalid security

Risk: invalid security. For Prequalification, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"invalid security","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — unauthorized signature

Risk: unauthorized signature. For Prequalification, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"unauthorized signature","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — untracked addendum or portal failure

Risk: untracked addendum or portal failure. For Prequalification, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"untracked addendum or portal failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Prequalification, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Prequalification, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Prequalification, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Prequalification, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Prequalification: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Prequalification: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Prequalification: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Prequalification: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Prequalification: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Prequalification: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Prequalification, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Prequalification, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Prequalification, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Prequalification, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Prequalification, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Prequalification, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Prequalification, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Prequalification, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Prequalification: vague public request. Input: I need help with Prequalification but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-prequalification-01","input":{"message":"I need help with Prequalification but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Prequalification: minimum quote-ready request. Input: Customer requests Prequalification and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-prequalification-02","input":{"message":"Customer requests Prequalification and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Prequalification: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-prequalification-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Prequalification: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-prequalification-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Prequalification: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-prequalification-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Prequalification: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-prequalification-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Prequalification: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-prequalification-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — RFP

English term: RFP. Arabic operational label: مصطلح RFP ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"RFP","term_ar":"مصطلح RFP ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — RFQ

English term: RFQ. Arabic operational label: مصطلح RFQ ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"RFQ","term_ar":"مصطلح RFQ ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — ITT

English term: ITT. Arabic operational label: مصطلح ITT ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"ITT","term_ar":"مصطلح ITT ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — EOI

English term: EOI. Arabic operational label: مصطلح EOI ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"EOI","term_ar":"مصطلح EOI ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — prequalification

English term: prequalification. Arabic operational label: مصطلح prequalification ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"prequalification","term_ar":"مصطلح prequalification ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — vendor registration

English term: vendor registration. Arabic operational label: مصطلح vendor registration ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"vendor registration","term_ar":"مصطلح vendor registration ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — bid bond

English term: bid bond. Arabic operational label: مصطلح bid bond ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"bid bond","term_ar":"مصطلح bid bond ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — performance guarantee

English term: performance guarantee. Arabic operational label: مصطلح performance guarantee ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"performance guarantee","term_ar":"مصطلح performance guarantee ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — addendum

English term: addendum. Arabic operational label: مصطلح addendum ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"addendum","term_ar":"مصطلح addendum ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — clarification

English term: clarification. Arabic operational label: مصطلح clarification ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"clarification","term_ar":"مصطلح clarification ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — technical proposal

English term: technical proposal. Arabic operational label: مصطلح technical proposal ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical proposal","term_ar":"مصطلح technical proposal ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — commercial proposal

English term: commercial proposal. Arabic operational label: مصطلح commercial proposal ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"commercial proposal","term_ar":"مصطلح commercial proposal ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — portal submission

English term: portal submission. Arabic operational label: مصطلح portal submission ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"portal submission","term_ar":"مصطلح portal submission ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — submission deadline

English term: submission deadline. Arabic operational label: مصطلح submission deadline ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"submission deadline","term_ar":"مصطلح submission deadline ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — audit trail

English term: audit trail. Arabic operational label: مصطلح audit trail ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"audit trail","term_ar":"مصطلح audit trail ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"prequalification","normalization_only":true}`

## glossary — technical requirement

English term: technical requirement. Arabic operational label: مصطلح technical requirement ضمن التأهيل المسبق. Use this pair for customer-language normalization, routing and supplier-facing output for Prequalification. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-prequalification-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical requirement","term_ar":"مصطلح technical requirement ضمن التأهيل المسبق","canonical_subcategory":"prequalification","normalization_only":true}`


# 04. Vendor registration / تسجيل الموردين

**Aliases:** Vendor registration

## industry — Industry scope — Vendor registration

Vendor registration sits within Government Tenders & Procurement Support and covers government tender, bid, prequalification and vendor-registration support where portal rules, eligibility, mandatory documents, deadlines, compliance matrices, bid securities and controlled submission determine validity. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Vendor registration","aliases_en":["Vendor registration"],"aliases_ar":["تسجيل الموردين"],"sequence":1}`

## industry — UAE procurement workflow — Vendor registration

A typical UAE procurement path for Vendor registration moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Vendor registration","aliases_en":["Vendor registration"],"aliases_ar":["تسجيل الموردين"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Vendor registration

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include lead consultant, bid manager, technical writer, commercial estimator, legal reviewer, document controller. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Vendor registration","aliases_en":["Vendor registration"],"aliases_ar":["تسجيل الموردين"],"sequence":3}`

## industry — Scope boundaries and escalation — Vendor registration

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Vendor registration. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"subcategory":"Vendor registration","aliases_en":["Vendor registration"],"aliases_ar":["تسجيل الموردين"],"sequence":4}`

## products_services — tender advisory

tender advisory is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"tender advisory","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — bid-management service

bid-management service is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"bid-management service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — opportunity screening

opportunity screening is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"opportunity screening","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — prequalification package

prequalification package is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"prequalification package","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — vendor registration

vendor registration is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"vendor registration","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — portal registration

portal registration is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"portal registration","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — compliance matrix

compliance matrix is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"compliance matrix","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — technical proposal

technical proposal is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"technical proposal","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — commercial proposal

commercial proposal is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"commercial proposal","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — bid-security coordination

bid-security coordination is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"bid-security coordination","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — consortium/JV support

consortium/JV support is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"consortium/JV support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — clarification management

clarification management is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"clarification management","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — submission management

submission management is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"submission management","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — post-bid support

post-bid support is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"post-bid support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — contract-award handover

contract-award handover is a product or service family relevant to Vendor registration. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"family":"contract-award handover","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — procuring entity and portal

Technical topic: procuring entity and portal. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"procuring entity and portal","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — tender reference

Technical topic: tender reference. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"tender reference","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — submission deadline

Technical topic: submission deadline. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"submission deadline","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — eligibility criteria

Technical topic: eligibility criteria. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"eligibility criteria","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — supplier registration status

Technical topic: supplier registration status. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"supplier registration status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — scope and lots

Technical topic: scope and lots. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"scope and lots","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — mandatory forms

Technical topic: mandatory forms. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"mandatory forms","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — technical compliance

Technical topic: technical compliance. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"technical compliance","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — commercial pricing format

Technical topic: commercial pricing format. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"commercial pricing format","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — bid bond/security

Technical topic: bid bond/security. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"bid bond/security","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — local content/SME requirements

Technical topic: local content/SME requirements. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"local content/SME requirements","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — consortium/JV structure

Technical topic: consortium/JV structure. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"consortium/JV structure","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — clarifications/addenda

Technical topic: clarifications/addenda. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"clarifications/addenda","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — document legalization

Technical topic: document legalization. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"document legalization","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — electronic submission

Technical topic: electronic submission. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"electronic submission","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — conflict and confidentiality

Technical topic: conflict and confidentiality. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"conflict and confidentiality","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — award/contract conditions

Technical topic: award/contract conditions. For Vendor registration, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"topic":"award/contract conditions","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — government-tender consultant

government-tender consultant is a supplier-market role or example for Vendor registration; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"government-tender consultant","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — bid-management firm

bid-management firm is a supplier-market role or example for Vendor registration; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"bid-management firm","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — prequalification specialist

prequalification specialist is a supplier-market role or example for Vendor registration; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"prequalification specialist","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — vendor-registration adviser

vendor-registration adviser is a supplier-market role or example for Vendor registration; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"vendor-registration adviser","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — technical proposal team

technical proposal team is a supplier-market role or example for Vendor registration; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"technical proposal team","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — public-procurement legal adviser

public-procurement legal adviser is a supplier-market role or example for Vendor registration; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"public-procurement legal adviser","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — lead consultant

Supplier type: lead consultant. In Vendor registration, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"lead consultant","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — lead consultant

Eligibility gate 1 for a lead consultant responding to Vendor registration: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"lead consultant","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — bid manager

Supplier type: bid manager. In Vendor registration, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"bid manager","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — bid manager

Eligibility gate 2 for a bid manager responding to Vendor registration: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"bid manager","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — technical writer

Supplier type: technical writer. In Vendor registration, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"technical writer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — technical writer

Eligibility gate 3 for a technical writer responding to Vendor registration: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"technical writer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — commercial estimator

Supplier type: commercial estimator. In Vendor registration, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"commercial estimator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — commercial estimator

Eligibility gate 4 for a commercial estimator responding to Vendor registration: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"commercial estimator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — legal reviewer

Supplier type: legal reviewer. In Vendor registration, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"legal reviewer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — legal reviewer

Eligibility gate 5 for a legal reviewer responding to Vendor registration: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"legal reviewer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — document controller

Supplier type: document controller. In Vendor registration, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"document controller","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — document controller

Eligibility gate 6 for a document controller responding to Vendor registration: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"document controller","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — portal administrator

Supplier type: portal administrator. In Vendor registration, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"portal administrator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — portal administrator

Eligibility gate 7 for a portal administrator responding to Vendor registration: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"portal administrator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — subject-matter specialist

Supplier type: subject-matter specialist. In Vendor registration, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"supplier_type":"subject-matter specialist","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — subject-matter specialist

Eligibility gate 8 for a subject-matter specialist responding to Vendor registration: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"supplier_type":"subject-matter specialist","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — entity/tender reference

Quotation requirement: entity/tender reference. Every supplier response for Vendor registration should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"entity_tender_reference","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — scope and lots

Quotation requirement: scope and lots. Every supplier response for Vendor registration should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"scope_and_lots","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — eligibility/PQ

Quotation requirement: eligibility/PQ. Every supplier response for Vendor registration should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"eligibility_pq","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — mandatory documents

Quotation requirement: mandatory documents. Every supplier response for Vendor registration should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"mandatory_documents","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — technical response

Quotation requirement: technical response. Every supplier response for Vendor registration should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"technical_response","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — commercial template

Quotation requirement: commercial template. Every supplier response for Vendor registration should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"commercial_template","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — security/guarantee

Quotation requirement: security/guarantee. Every supplier response for Vendor registration should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"security_guarantee","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — portal/deadline

Quotation requirement: portal/deadline. Every supplier response for Vendor registration should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"portal_deadline","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — clarifications/addenda

Quotation requirement: clarifications/addenda. Every supplier response for Vendor registration should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"clarifications_addenda","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — submission and audit trail

Quotation requirement: submission and audit trail. Every supplier response for Vendor registration should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"quotation_field":"submission_and_audit_trail","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — tender notice

Document: tender notice. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"tender_notice","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — instructions to bidders

Document: instructions to bidders. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"instructions_to_bidders","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — scope/specification

Document: scope/specification. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"scope_specification","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — eligibility criteria

Document: eligibility criteria. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"eligibility_criteria","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — prequalification questionnaire

Document: prequalification questionnaire. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"prequalification_questionnaire","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — mandatory forms

Document: mandatory forms. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"mandatory_forms","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — technical schedules

Document: technical schedules. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"technical_schedules","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — pricing schedule

Document: pricing schedule. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"pricing_schedule","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — bid-security wording

Document: bid-security wording. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"bid_security_wording","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — addenda/clarifications

Document: addenda/clarifications. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"addenda_clarifications","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — company legal documents

Document: company legal documents. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"company_legal_documents","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — experience/references

Document: experience/references. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"experience_references","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — submission checklist

Document: submission checklist. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"submission_checklist","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — portal receipt/audit trail

Document: portal receipt/audit trail. For Vendor registration, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"document_type":"portal_receipt_audit_trail","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — UAE Federal Procurement Operations and Digital Procurement Platform

Source activation for Vendor registration: UAE Federal Procurement Operations and Digital Procurement Platform (UAE Ministry of Finance). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registry, catalogue, tender and federal procurement requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT
- Structured data: `{"source_id":"UAE-MOF-PROCUREMENT","publisher":"UAE Ministry of Finance","url":"https://mof.gov.ae/government-procurement-operations/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Dubai Government eSupply Procurement Portal

Source activation for Vendor registration: Dubai Government eSupply Procurement Portal (Government of Dubai). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify registration, opportunity, submission and portal instructions for each tender.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-DUBAI-ESUPPLY
- Structured data: `{"source_id":"UAE-DUBAI-ESUPPLY","publisher":"Government of Dubai","url":"https://esupply.dubai.gov.ae/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Abu Dhabi Government Procurement Gate

Source activation for Vendor registration: Abu Dhabi Government Procurement Gate (Government of Abu Dhabi). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registration, tender, prequalification and current portal requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-ADGPG
- Structured data: `{"source_id":"UAE-ADGPG","publisher":"Government of Abu Dhabi","url":"https://www.adgpg.gov.ae/","source_type":"government_procurement_portal","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Vendor registration: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Vendor registration: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — ISO Standards Catalogue

Source activation for Vendor registration: ISO Standards Catalogue (International Organization for Standardization). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Do not reproduce paid standards; use licensed current editions and approved summaries.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: ISO-STANDARDS
- Structured data: `{"source_id":"ISO-STANDARDS","publisher":"International Organization for Standardization","url":"https://www.iso.org/standards.html","source_type":"paid_standard_reference","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Vendor registration: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Federal Procurement Operations and Digital Procurement Platform

Source activation for Vendor registration: UAE Federal Procurement Operations and Digital Procurement Platform (UAE Ministry of Finance). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify supplier registry, catalogue, tender and federal procurement requirements.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT
- Structured data: `{"source_id":"UAE-MOF-PROCUREMENT","publisher":"UAE Ministry of Finance","url":"https://mof.gov.ae/government-procurement-operations/","source_type":"government_procurement_portal","live_verification":true}`

## inquiry_qualification — Entity/Tender

Ask: Which government entity, procurement portal and tender reference are involved? Arabic: يرجى توضيح entity/tender بالنسبة إلى تسجيل الموردين. Reason: entity/tender is required to make Vendor registration quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-domain_1","question_en":"Which government entity, procurement portal and tender reference are involved?","question_ar":"يرجى توضيح entity/tender بالنسبة إلى تسجيل الموردين.","internal_label_en":"entity/tender","internal_label_ar":"متطلب تسجيل الموردين","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Scope/Eligibility

Ask: What scope, lot structure, eligibility, classification and supplier-registration requirements apply? Arabic: يرجى توضيح scope/eligibility بالنسبة إلى تسجيل الموردين. Reason: scope/eligibility is required to make Vendor registration quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-domain_2","question_en":"What scope, lot structure, eligibility, classification and supplier-registration requirements apply?","question_ar":"يرجى توضيح scope/eligibility بالنسبة إلى تسجيل الموردين.","internal_label_en":"scope/eligibility","internal_label_ar":"متطلب تسجيل الموردين","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Mandatory Documents

Ask: What mandatory legal, financial, technical, experience and authorization documents are required? Arabic: يرجى توضيح mandatory documents بالنسبة إلى تسجيل الموردين. Reason: mandatory documents is required to make Vendor registration quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-domain_3","question_en":"What mandatory legal, financial, technical, experience and authorization documents are required?","question_ar":"يرجى توضيح mandatory documents بالنسبة إلى تسجيل الموردين.","internal_label_en":"mandatory documents","internal_label_ar":"متطلب تسجيل الموردين","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Technical Response

Ask: What technical schedules, method, staffing, compliance matrix and deviations must be completed? Arabic: يرجى توضيح technical response بالنسبة إلى تسجيل الموردين. Reason: technical response is required to make Vendor registration quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-domain_4","question_en":"What technical schedules, method, staffing, compliance matrix and deviations must be completed?","question_ar":"يرجى توضيح technical response بالنسبة إلى تسجيل الموردين.","internal_label_en":"technical response","internal_label_ar":"متطلب تسجيل الموردين","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Commercial/Security

Ask: What pricing template, bid bond, guarantee, tax, local-content or commercial conditions apply? Arabic: يرجى توضيح commercial/security بالنسبة إلى تسجيل الموردين. Reason: commercial/security is required to make Vendor registration quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-domain_5","question_en":"What pricing template, bid bond, guarantee, tax, local-content or commercial conditions apply?","question_ar":"يرجى توضيح commercial/security بالنسبة إلى تسجيل الموردين.","internal_label_en":"commercial/security","internal_label_ar":"متطلب تسجيل الموردين","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Clarifications/Structure

Ask: What clarifications, addenda, site visits, consortium/JV and conflict rules apply? Arabic: يرجى توضيح clarifications/structure بالنسبة إلى تسجيل الموردين. Reason: clarifications/structure is required to make Vendor registration quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-domain_6","question_en":"What clarifications, addenda, site visits, consortium/JV and conflict rules apply?","question_ar":"يرجى توضيح clarifications/structure بالنسبة إلى تسجيل الموردين.","internal_label_en":"clarifications/structure","internal_label_ar":"متطلب تسجيل الموردين","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Submission/Control

Ask: What submission deadline, portal method, signatures, encryption, audit trail and post-submission support are required? Arabic: يرجى توضيح submission/control بالنسبة إلى تسجيل الموردين. Reason: submission/control is required to make Vendor registration quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-domain_7","question_en":"What submission deadline, portal method, signatures, encryption, audit trail and post-submission support are required?","question_ar":"يرجى توضيح submission/control بالنسبة إلى تسجيل الموردين.","internal_label_en":"submission/control","internal_label_ar":"متطلب تسجيل الموردين","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Vendor registration quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Vendor registration quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Vendor registration quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Vendor registration quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Vendor registration quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Vendor registration quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Vendor registration quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Vendor registration quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Vendor registration quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Vendor registration quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Vendor registration quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Vendor registration quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Vendor registration quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Vendor registration quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Vendor registration quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Vendor registration quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Vendor registration quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Vendor registration quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Vendor registration quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Vendor registration quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Vendor registration quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Vendor registration quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"question_id":"q-vendor-registration-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["tender notice","instructions to bidders","scope/specification"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Vendor registration, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"rule_id":"rule-vendor-registration-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-vendor-registration-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Vendor registration; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-vendor-registration-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Vendor registration; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-vendor-registration-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Vendor registration; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-vendor-registration-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Vendor registration; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-vendor-registration-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Vendor registration; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"rule_id":"rule-vendor-registration-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Vendor registration: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-vendor-registration-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Vendor registration: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-vendor-registration-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Vendor registration: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-vendor-registration-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Vendor registration: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-vendor-registration-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Vendor registration: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-vendor-registration-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Vendor registration: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-vendor-registration-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Vendor registration: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-vendor-registration-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Vendor registration: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-vendor-registration-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Vendor registration: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-vendor-registration-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Vendor registration: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"validation_id":"validation-vendor-registration-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — tender size/complexity

Cost driver: tender size/complexity. This factor can materially change a Vendor registration quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"tender size/complexity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — number of lots/forms

Cost driver: number of lots/forms. This factor can materially change a Vendor registration quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"number of lots/forms","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — technical writing and estimating

Cost driver: technical writing and estimating. This factor can materially change a Vendor registration quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"technical writing and estimating","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — legalization and securities

Cost driver: legalization and securities. This factor can materially change a Vendor registration quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"legalization and securities","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — portal/deadline urgency

Cost driver: portal/deadline urgency. This factor can materially change a Vendor registration quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"portal/deadline urgency","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — consortium and stakeholder coordination

Cost driver: consortium and stakeholder coordination. This factor can materially change a Vendor registration quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"consortium and stakeholder coordination","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Vendor registration quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Vendor registration quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Vendor registration quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Vendor registration quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Vendor registration: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Vendor registration: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Vendor registration: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Vendor registration: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Vendor registration: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Vendor registration: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Vendor registration: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Vendor registration: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Vendor registration: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Vendor registration: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — missed deadline

Risk: missed deadline. For Vendor registration, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"missed deadline","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — mandatory document omitted

Risk: mandatory document omitted. For Vendor registration, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"mandatory document omitted","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — noncompliant template

Risk: noncompliant template. For Vendor registration, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"noncompliant template","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — invalid security

Risk: invalid security. For Vendor registration, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"invalid security","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — unauthorized signature

Risk: unauthorized signature. For Vendor registration, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"unauthorized signature","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — untracked addendum or portal failure

Risk: untracked addendum or portal failure. For Vendor registration, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"untracked addendum or portal failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Vendor registration, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Vendor registration, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Vendor registration, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Vendor registration, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Vendor registration: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Vendor registration: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Vendor registration: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Vendor registration: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Vendor registration: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Vendor registration: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Vendor registration, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Vendor registration, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Vendor registration, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Vendor registration, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Vendor registration, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Vendor registration, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Vendor registration, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Vendor registration, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Vendor registration: vague public request. Input: I need help with Vendor registration but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-vendor-registration-01","input":{"message":"I need help with Vendor registration but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Vendor registration: minimum quote-ready request. Input: Customer requests Vendor registration and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-vendor-registration-02","input":{"message":"Customer requests Vendor registration and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Vendor registration: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-vendor-registration-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Vendor registration: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-vendor-registration-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Vendor registration: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-vendor-registration-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Vendor registration: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-vendor-registration-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Vendor registration: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOF-PROCUREMENT, UAE-DUBAI-ESUPPLY, UAE-ADGPG, UAE-PDPL-45-2021
- Structured data: `{"scenario_id":"scenario-vendor-registration-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — RFP

English term: RFP. Arabic operational label: مصطلح RFP ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"RFP","term_ar":"مصطلح RFP ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — RFQ

English term: RFQ. Arabic operational label: مصطلح RFQ ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"RFQ","term_ar":"مصطلح RFQ ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — ITT

English term: ITT. Arabic operational label: مصطلح ITT ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"ITT","term_ar":"مصطلح ITT ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — EOI

English term: EOI. Arabic operational label: مصطلح EOI ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"EOI","term_ar":"مصطلح EOI ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — prequalification

English term: prequalification. Arabic operational label: مصطلح prequalification ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"prequalification","term_ar":"مصطلح prequalification ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — vendor registration

English term: vendor registration. Arabic operational label: مصطلح vendor registration ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"vendor registration","term_ar":"مصطلح vendor registration ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — bid bond

English term: bid bond. Arabic operational label: مصطلح bid bond ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"bid bond","term_ar":"مصطلح bid bond ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — performance guarantee

English term: performance guarantee. Arabic operational label: مصطلح performance guarantee ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"performance guarantee","term_ar":"مصطلح performance guarantee ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — addendum

English term: addendum. Arabic operational label: مصطلح addendum ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"addendum","term_ar":"مصطلح addendum ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — clarification

English term: clarification. Arabic operational label: مصطلح clarification ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"clarification","term_ar":"مصطلح clarification ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — technical proposal

English term: technical proposal. Arabic operational label: مصطلح technical proposal ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical proposal","term_ar":"مصطلح technical proposal ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — commercial proposal

English term: commercial proposal. Arabic operational label: مصطلح commercial proposal ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"commercial proposal","term_ar":"مصطلح commercial proposal ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — portal submission

English term: portal submission. Arabic operational label: مصطلح portal submission ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"portal submission","term_ar":"مصطلح portal submission ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — submission deadline

English term: submission deadline. Arabic operational label: مصطلح submission deadline ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"submission deadline","term_ar":"مصطلح submission deadline ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — audit trail

English term: audit trail. Arabic operational label: مصطلح audit trail ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"audit trail","term_ar":"مصطلح audit trail ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"vendor-registration","normalization_only":true}`

## glossary — technical requirement

English term: technical requirement. Arabic operational label: مصطلح technical requirement ضمن تسجيل الموردين. Use this pair for customer-language normalization, routing and supplier-facing output for Vendor registration. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-government-tenders-and-procurement-support-vendor-registration-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical requirement","term_ar":"مصطلح technical requirement ضمن تسجيل الموردين","canonical_subcategory":"vendor-registration","normalization_only":true}`

