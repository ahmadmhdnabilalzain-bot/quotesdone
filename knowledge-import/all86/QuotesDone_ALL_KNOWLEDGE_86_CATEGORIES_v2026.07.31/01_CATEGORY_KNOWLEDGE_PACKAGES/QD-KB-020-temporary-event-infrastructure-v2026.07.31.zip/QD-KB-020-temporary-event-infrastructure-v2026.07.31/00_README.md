# QuotesDone Category 20 Knowledge Package

**Category:** Temporary Event Infrastructure
**Subcategories:** 9
**Status:** production draft; not SME-approved

Use the numbered JSONL files for programmatic ingestion. `02_category_master.md` is a human-audit view and must not be inserted into every model prompt. The deterministic question, decision-rule and validation files are designed to reduce model use.
