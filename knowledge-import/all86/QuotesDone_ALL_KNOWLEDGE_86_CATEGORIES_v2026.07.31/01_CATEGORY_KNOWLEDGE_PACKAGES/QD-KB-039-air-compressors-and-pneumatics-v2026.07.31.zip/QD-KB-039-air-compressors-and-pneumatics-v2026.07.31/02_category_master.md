# QuotesDone Knowledge Corpus — Category 39

## Air Compressors & Pneumatics

**Arabic working title:** ضواغط الهواء والأنظمة الهوائية
**Version:** 2026.07.31
**Status:** research-complete production draft; not SME approved
**Subcategories:** 4

## Runtime purpose

This corpus supports customer-language routing, adaptive qualification, supplier eligibility, document extraction, UAE source retrieval, comparable RFQ generation, risk control and escalation for Air Compressors & Pneumatics. The large master file is for human audit. Runtime systems should use the atomic JSONL records, deterministic questions/rules and internal retrieval rather than placing this entire file in a model prompt.


# 1. Compressors

**Arabic draft:** متطلبات Compressors
**Slug:** `compressors`
**Aliases:** Compressors

## Industry

### Industry scope — Compressors

Compressors is treated as a distinct procurement route within Air Compressors & Pneumatics. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers industrial products, machinery, process systems, fabrication, logistics, maintenance and safety. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-039-compressors-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD

```json
{
  "category": "Air Compressors & Pneumatics",
  "subcategory": "Compressors",
  "profile": "industrial",
  "aliases": [
    "Compressors"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Compressors

A normal UAE sourcing workflow for Compressors moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-039-compressors-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Compressors

Customers may describe Compressors through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-039-compressors-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Compressors

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-039-compressors-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Compressors product or service

The primary deliverable requested within Compressors; exact type, quantity, performance, scope and acceptance must be normalized. For Compressors, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-compressors-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Compressors",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Compressors

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Compressors, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-compressors-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Compressors",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Compressors

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Compressors, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-compressors-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Compressors",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Compressors

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Compressors, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-compressors-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Compressors",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Compressors

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Compressors, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-compressors-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Compressors",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Compressors

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Compressors, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-compressors-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Compressors",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Compressors

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Compressors, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-compressors-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Compressors",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Compressors

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Compressors, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-compressors-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Compressors",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Air Demand/Profile scope component

Air Demand/Profile is a recurring scope component for Compressors. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-compressors-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "air demand/profile",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Pressure/Quality scope component

Pressure/Quality is a recurring scope component for Compressors. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-compressors-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "pressure/quality",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Compressor Technology scope component

Compressor Technology is a recurring scope component for Compressors. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-compressors-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "compressor technology",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Power/Cooling scope component

Power/Cooling is a recurring scope component for Compressors. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-compressors-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "power/cooling",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Receiver/Dryer/Filters scope component

Receiver/Dryer/Filters is a recurring scope component for Compressors. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-compressors-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "receiver/dryer/filters",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Controls scope component

Controls is a recurring scope component for Compressors. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-compressors-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "controls",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Maintenance scope component

Maintenance is a recurring scope component for Compressors. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-compressors-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "maintenance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: process or duty

For Compressors, process or duty must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "process or duty",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: capacity and operating envelope

For Compressors, capacity and operating envelope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "capacity and operating envelope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: materials and compatibility

For Compressors, materials and compatibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "materials and compatibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environment and hazardous classification

For Compressors, environment and hazardous classification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environment and hazardous classification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/utilities

For Compressors, power/utilities must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/utilities",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces and controls

For Compressors, interfaces and controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces and controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: quality and certification

For Compressors, quality and certification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "quality and certification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation and commissioning

For Compressors, installation and commissioning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation and commissioning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: spares and maintenance

For Compressors, spares and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "spares and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: logistics and lifecycle

For Compressors, logistics and lifecycle must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "logistics and lifecycle",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: air demand/profile

For Compressors, air demand/profile must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "air demand/profile",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: pressure/quality

For Compressors, pressure/quality must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "pressure/quality",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: compressor technology

For Compressors, compressor technology must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "compressor technology",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/cooling

For Compressors, power/cooling must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/cooling",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: receiver/dryer/filters

For Compressors, receiver/dryer/filters must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "receiver/dryer/filters",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: controls

For Compressors, controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: maintenance

For Compressors, maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-compressors-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer/OEM

A manufacturer/OEM may be relevant to Compressors depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-compressors-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer/OEM",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Compressors depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-compressors-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: industrial system integrator

A industrial system integrator may be relevant to Compressors depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-compressors-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "industrial system integrator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator/machine shop

A fabricator/machine shop may be relevant to Compressors depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-compressors-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator/machine shop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: EPC or specialist contractor

A EPC or specialist contractor may be relevant to Compressors depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-compressors-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "EPC or specialist contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: inspection/testing body

A inspection/testing body may be relevant to Compressors depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-compressors-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "inspection/testing body",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer/OEM

This supplier type can participate in Compressors only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-compressors-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer/OEM",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Compressors only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-compressors-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — industrial system integrator

This supplier type can participate in Compressors only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-compressors-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "industrial system integrator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator/machine shop

This supplier type can participate in Compressors only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-compressors-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator/machine shop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — EPC or specialist contractor

This supplier type can participate in Compressors only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-compressors-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "EPC or specialist contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — inspection/testing body

This supplier type can participate in Compressors only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-compressors-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "inspection/testing body",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — rental/service provider

This supplier type can participate in Compressors only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-compressors-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "rental/service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance and spare-parts provider

This supplier type can participate in Compressors only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-compressors-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer/OEM

Before routing a Compressors inquiry to a manufacturer/OEM, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-compressors-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "manufacturer/OEM",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Compressors inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-compressors-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — industrial system integrator

Before routing a Compressors inquiry to a industrial system integrator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-compressors-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "industrial system integrator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator/machine shop

Before routing a Compressors inquiry to a fabricator/machine shop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-compressors-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "fabricator/machine shop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — EPC or specialist contractor

Before routing a Compressors inquiry to a EPC or specialist contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-compressors-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "EPC or specialist contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — inspection/testing body

Before routing a Compressors inquiry to a inspection/testing body, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-compressors-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "inspection/testing body",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — rental/service provider

Before routing a Compressors inquiry to a rental/service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-compressors-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "rental/service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance and spare-parts provider

Before routing a Compressors inquiry to a maintenance and spare-parts provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-compressors-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Compressors should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-compressors-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Compressors should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-compressors-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Compressors should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-compressors-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Compressors should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-compressors-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Compressors should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-compressors-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Compressors should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-compressors-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Compressors should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-compressors-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Compressors should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-compressors-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Compressors should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-compressors-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Compressors should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-compressors-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Process/Duty Data Sheet

Process/Duty Data Sheet may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "process-duty-data-sheet",
  "document_name": "process/duty data sheet",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### P&Id Or Schematic

P&Id Or Schematic may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "p-and-id-or-schematic",
  "document_name": "P&ID or schematic",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Layout/General Arrangement

Layout/General Arrangement may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "layout-general-arrangement",
  "document_name": "layout/general arrangement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Hazardous Area Classification

Hazardous Area Classification may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "hazardous-area-classification",
  "document_name": "hazardous area classification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Single-Line/Control Diagram

Single-Line/Control Diagram may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "single-line-control-diagram",
  "document_name": "single-line/control diagram",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Interface List

Interface List may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "interface-list",
  "document_name": "interface list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quality Plan/Itp

Quality Plan/Itp may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quality-plan-itp",
  "document_name": "quality plan/ITP",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Certificates

Material Certificates may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-certificates",
  "document_name": "material certificates",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Reports

Inspection/Test Reports may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-reports",
  "document_name": "inspection/test reports",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement/Lifting Plan

Method Statement/Lifting Plan may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement-lifting-plan",
  "document_name": "method statement/lifting plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Commissioning Plan

Commissioning Plan may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "commissioning-plan",
  "document_name": "commissioning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Spares List

Spares List may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "spares-list",
  "document_name": "spares list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for Compressors. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-compressors-documents-document_requirement-0083`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Industrial, Standards, Conformity and Quality Services

For Compressors, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-compressors-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment, Climate and Agriculture Regulation

For Compressors, consult Environment, Climate and Agriculture Regulation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-compressors-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOCCAE

```json
{
  "source_id": "UAE-MOCCAE",
  "publisher": "Ministry of Climate Change and Environment",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment Agency Abu Dhabi Policies and Permits

For Compressors, consult Environment Agency Abu Dhabi Policies and Permits when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-compressors-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-EAD

```json
{
  "source_id": "UAE-EAD",
  "publisher": "Environment Agency Abu Dhabi",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ADNOC Supplier and In-Country Value Requirements

For Compressors, consult ADNOC Supplier and In-Country Value Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-compressors-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADNOC-SUPPLIER

```json
{
  "source_id": "UAE-ADNOC-SUPPLIER",
  "publisher": "ADNOC",
  "source_type": "state_enterprise_supplier_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Customs and Import/Export Guidance

For Compressors, consult UAE Customs and Import/Export Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-compressors-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CUSTOMS

```json
{
  "source_id": "UAE-CUSTOMS",
  "publisher": "Federal Authority for Identity, Citizenship, Customs and Port Security",
  "source_type": "government_customs_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Compressors, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-compressors-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### IEC Standards Catalogue

For Compressors, consult IEC Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-compressors-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: IEC-STANDARDS

```json
{
  "source_id": "IEC-STANDARDS",
  "publisher": "International Electrotechnical Commission",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For Compressors, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-compressors-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Compressors. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-compressors-commercial_pricing-cost_driver-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Compressors. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-compressors-commercial_pricing-cost_driver-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Compressors. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-compressors-commercial_pricing-cost_driver-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Compressors. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-compressors-commercial_pricing-cost_driver-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Compressors. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-compressors-commercial_pricing-cost_driver-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Compressors. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-compressors-commercial_pricing-cost_driver-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Compressors. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-compressors-commercial_pricing-cost_driver-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Compressors. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-compressors-commercial_pricing-cost_driver-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Compressors. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-compressors-commercial_pricing-cost_driver-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Compressors. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-compressors-commercial_pricing-cost_driver-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-compressors-customer_tradeoffs-tradeoff-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-compressors-customer_tradeoffs-tradeoff-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-compressors-customer_tradeoffs-tradeoff-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-compressors-customer_tradeoffs-tradeoff-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-compressors-customer_tradeoffs-tradeoff-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-compressors-customer_tradeoffs-tradeoff-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-compressors-customer_tradeoffs-tradeoff-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-compressors-customer_tradeoffs-tradeoff-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-compressors-customer_tradeoffs-tradeoff-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-compressors-customer_tradeoffs-tradeoff-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Compressors, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-compressors-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Compressors, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-compressors-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Compressors, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-compressors-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Compressors, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-compressors-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Compressors, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-compressors-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Compressors, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-compressors-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Compressors, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-compressors-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Compressors, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-compressors-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Compressors, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-compressors-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Compressors, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-compressors-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Compressors, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-compressors-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Compressors, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-compressors-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Compressors, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-compressors-best_practices-qualification_best_practice-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Compressors, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-compressors-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Compressors, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-compressors-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Compressors, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-compressors-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Compressors; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-compressors-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Compressors; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-compressors-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Compressors; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-compressors-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Compressors; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-compressors-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Compressors; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-compressors-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Compressors; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-compressors-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Compressors; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-compressors-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Compressors; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-compressors-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What process, duty, product, load, medium or operating objective applies?

Ask in plain language: What process, duty, product, load, medium or operating objective applies? Arabic draft: ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-process-duty",
  "question_en": "What process, duty, product, load, medium or operating objective applies?",
  "question_ar": "ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "process-duty",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What process, duty, product, load, medium or operating objective applies? is missing

When the normalized field process-duty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-process-duty",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "process-duty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-process-duty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What capacity, pressure, temperature, speed, load, accuracy or operating range is required?

Ask in plain language: What capacity, pressure, temperature, speed, load, accuracy or operating range is required? Arabic draft: ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-capacity-conditions",
  "question_en": "What capacity, pressure, temperature, speed, load, accuracy or operating range is required?",
  "question_ar": "ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟",
  "expected_answer_type": "structured_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-conditions",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What capacity, pressure, temperature, speed, load, accuracy or operating range is required? is missing

When the normalized field capacity-conditions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-capacity-conditions",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-conditions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-capacity-conditions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?

Ask in plain language: What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? Arabic draft: ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-materials-compatibility",
  "question_en": "What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?",
  "question_ar": "ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "materials-compatibility",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? is missing

When the normalized field materials-compatibility is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-materials-compatibility",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "materials-compatibility",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-materials-compatibility"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?

Ask in plain language: What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies? Arabic draft: ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-environment-hazard",
  "question_en": "What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?",
  "question_ar": "ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "environment-hazard",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?

Ask in plain language: What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? Arabic draft: ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-utilities-controls",
  "question_en": "What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?",
  "question_ar": "ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-controls",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? is missing

When the normalized field utilities-controls is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-utilities-controls",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-controls",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-utilities-controls"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What code, material certificate, test, inspection, traceability or third-party approval is required?

Ask in plain language: What code, material certificate, test, inspection, traceability or third-party approval is required? Arabic draft: ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-standards-certification",
  "question_en": "What code, material certificate, test, inspection, traceability or third-party approval is required?",
  "question_ar": "ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "standards-certification",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?

Ask in plain language: What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? Arabic draft: ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-installation-commissioning",
  "question_en": "What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?",
  "question_ar": "ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-commissioning",
  "order": 190,
  "confidence_contribution": 0.03
}
```

### Ask when What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? is missing

When the normalized field installation-commissioning is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-installation-commissioning",
  "priority": 981,
  "when": {
    "all": [
      {
        "field": "installation-commissioning",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-installation-commissioning"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What consumables, critical spares, maintenance interval, response time and lifecycle support are required?

Ask in plain language: What consumables, critical spares, maintenance interval, response time and lifecycle support are required? Arabic draft: ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-spares-service",
  "question_en": "What consumables, critical spares, maintenance interval, response time and lifecycle support are required?",
  "question_ar": "ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "spares-service",
  "order": 200,
  "confidence_contribution": 0.012
}
```

### Please clarify the air demand/profile requirements for Compressors.

Ask in plain language: Please clarify the air demand/profile requirements for Compressors. Arabic draft: يرجى توضيح متطلبات air demand/profile الخاصة بـ Compressors. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-facet-01",
  "question_en": "Please clarify the air demand/profile requirements for Compressors.",
  "question_ar": "يرجى توضيح متطلبات air demand/profile الخاصة بـ Compressors.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the air demand/profile requirements for Compressors. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the pressure/quality requirements for Compressors.

Ask in plain language: Please clarify the pressure/quality requirements for Compressors. Arabic draft: يرجى توضيح متطلبات pressure/quality الخاصة بـ Compressors. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-facet-02",
  "question_en": "Please clarify the pressure/quality requirements for Compressors.",
  "question_ar": "يرجى توضيح متطلبات pressure/quality الخاصة بـ Compressors.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the pressure/quality requirements for Compressors. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the compressor technology requirements for Compressors.

Ask in plain language: Please clarify the compressor technology requirements for Compressors. Arabic draft: يرجى توضيح متطلبات compressor technology الخاصة بـ Compressors. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-facet-03",
  "question_en": "Please clarify the compressor technology requirements for Compressors.",
  "question_ar": "يرجى توضيح متطلبات compressor technology الخاصة بـ Compressors.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the compressor technology requirements for Compressors. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the power/cooling requirements for Compressors.

Ask in plain language: Please clarify the power/cooling requirements for Compressors. Arabic draft: يرجى توضيح متطلبات power/cooling الخاصة بـ Compressors. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-facet-04",
  "question_en": "Please clarify the power/cooling requirements for Compressors.",
  "question_ar": "يرجى توضيح متطلبات power/cooling الخاصة بـ Compressors.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the receiver/dryer/filters requirements for Compressors.

Ask in plain language: Please clarify the receiver/dryer/filters requirements for Compressors. Arabic draft: يرجى توضيح متطلبات receiver/dryer/filters الخاصة بـ Compressors. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-facet-05",
  "question_en": "Please clarify the receiver/dryer/filters requirements for Compressors.",
  "question_ar": "يرجى توضيح متطلبات receiver/dryer/filters الخاصة بـ Compressors.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the controls requirements for Compressors.

Ask in plain language: Please clarify the controls requirements for Compressors. Arabic draft: يرجى توضيح متطلبات controls الخاصة بـ Compressors. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-facet-06",
  "question_en": "Please clarify the controls requirements for Compressors.",
  "question_ar": "يرجى توضيح متطلبات controls الخاصة بـ Compressors.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the maintenance requirements for Compressors.

Ask in plain language: Please clarify the maintenance requirements for Compressors. Arabic draft: يرجى توضيح متطلبات maintenance الخاصة بـ Compressors. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-facet-07",
  "question_en": "Please clarify the maintenance requirements for Compressors.",
  "question_ar": "يرجى توضيح متطلبات maintenance الخاصة بـ Compressors.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact Compressors product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Compressors product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Compressors التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-exact-subtype",
  "question_en": "Which exact Compressors product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Compressors التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Compressors product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-compressors-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Compressors are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Compressors are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Compressors التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-unknowns",
  "question_en": "Which details about Compressors are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Compressors التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Compressors?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Compressors? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Compressors؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-compressors-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Compressors?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Compressors؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Compressors, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Compressors, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Compressors, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Compressors, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0186`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER, UAE-CUSTOMS, ISO-STANDARDS, IEC-STANDARDS, ASTM-STANDARDS

```json
{
  "rule_id": "R-039-compressors-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-MOIAT",
        "UAE-MOCCAE",
        "UAE-EAD",
        "UAE-ADNOC-SUPPLIER",
        "UAE-CUSTOMS",
        "ISO-STANDARDS",
        "IEC-STANDARDS",
        "ASTM-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Compressors, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Compressors, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Compressors, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Compressors, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-compressors-inquiry_qualification-decision_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-compressors-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Compressors, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-compressors-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-compressors-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Compressors, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-compressors-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-compressors-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Compressors, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-compressors-validation-validation_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-compressors-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Compressors, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-compressors-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-compressors-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Compressors, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-compressors-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-compressors-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Compressors, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-compressors-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-compressors-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Compressors, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-compressors-validation-validation_rule-0197`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "validation_id": "V-039-compressors-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Compressors, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-compressors-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-compressors-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Compressors, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-compressors-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-compressors-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Compressors, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-compressors-validation-validation_rule-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-compressors-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Compressors without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-compressors-scenario_test-scenario-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-compressors-001",
  "setup": "Customer asks informally for Compressors without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Compressors with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-compressors-scenario_test-scenario-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-compressors-002",
  "setup": "Customer requests price for Compressors with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Compressors. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-compressors-scenario_test-scenario-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-compressors-003",
  "setup": "Customer uploads a relevant schedule/specification for Compressors.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Compressors. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-compressors-scenario_test-scenario-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-compressors-004",
  "setup": "Customer message and uploaded document disagree on Compressors.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Compressors. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-compressors-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-compressors-005",
  "setup": "Supplier proposes a different product, provider or method for Compressors.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Compressors sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-compressors-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-compressors-006",
  "setup": "Customer needs Compressors sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Compressors needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-compressors-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-compressors-007",
  "setup": "The request for Compressors needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Compressors

English term: Compressors. Arabic operational draft: متطلبات Compressors. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Compressors",
  "term_ar": "متطلبات Compressors",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### air demand/profile

English term: air demand/profile. Arabic operational draft: متطلبات air demand/profile. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "air demand/profile",
  "term_ar": "متطلبات air demand/profile",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### pressure/quality

English term: pressure/quality. Arabic operational draft: متطلبات pressure/quality. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "pressure/quality",
  "term_ar": "متطلبات pressure/quality",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### compressor technology

English term: compressor technology. Arabic operational draft: متطلبات compressor technology. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compressor technology",
  "term_ar": "متطلبات compressor technology",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### power/cooling

English term: power/cooling. Arabic operational draft: متطلبات power/cooling. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "power/cooling",
  "term_ar": "متطلبات power/cooling",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### receiver/dryer/filters

English term: receiver/dryer/filters. Arabic operational draft: متطلبات receiver/dryer/filters. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "receiver/dryer/filters",
  "term_ar": "متطلبات receiver/dryer/filters",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```

### controls

English term: controls. Arabic operational draft: متطلبات controls. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-compressors-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "controls",
  "term_ar": "متطلبات controls",
  "canonical_subcategory": "compressors",
  "normalization_only": true
}
```


# 2. Air treatment systems

**Arabic draft:** متطلبات Air treatment systems
**Slug:** `air-treatment-systems`
**Aliases:** Air treatment systems, Air treatment, treatment systems

## Industry

### Industry scope — Air treatment systems

Air treatment systems is treated as a distinct procurement route within Air Compressors & Pneumatics. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers industrial products, machinery, process systems, fabrication, logistics, maintenance and safety. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-039-air-treatment-systems-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD

```json
{
  "category": "Air Compressors & Pneumatics",
  "subcategory": "Air treatment systems",
  "profile": "industrial",
  "aliases": [
    "Air treatment systems",
    "Air treatment",
    "treatment systems"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Air treatment systems

A normal UAE sourcing workflow for Air treatment systems moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-039-air-treatment-systems-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Air treatment systems

Customers may describe Air treatment systems through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-039-air-treatment-systems-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Air treatment systems

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-039-air-treatment-systems-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Air treatment systems product or service

The primary deliverable requested within Air treatment systems; exact type, quantity, performance, scope and acceptance must be normalized. For Air treatment systems, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Air treatment systems",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Air treatment systems

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Air treatment systems, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Air treatment systems",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Air treatment systems

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Air treatment systems, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Air treatment systems",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Air treatment systems

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Air treatment systems, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Air treatment systems",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Air treatment systems

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Air treatment systems, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Air treatment systems",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Air treatment systems

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Air treatment systems, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Air treatment systems",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Air treatment systems

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Air treatment systems, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Air treatment systems",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Air treatment systems

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Air treatment systems, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Air treatment systems",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Air Demand/Profile scope component

Air Demand/Profile is a recurring scope component for Air treatment systems. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "air demand/profile",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Pressure/Quality scope component

Pressure/Quality is a recurring scope component for Air treatment systems. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "pressure/quality",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Compressor Technology scope component

Compressor Technology is a recurring scope component for Air treatment systems. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "compressor technology",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Power/Cooling scope component

Power/Cooling is a recurring scope component for Air treatment systems. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "power/cooling",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Receiver/Dryer/Filters scope component

Receiver/Dryer/Filters is a recurring scope component for Air treatment systems. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "receiver/dryer/filters",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Controls scope component

Controls is a recurring scope component for Air treatment systems. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "controls",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Maintenance scope component

Maintenance is a recurring scope component for Air treatment systems. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-treatment-systems-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "maintenance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: process or duty

For Air treatment systems, process or duty must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "process or duty",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: capacity and operating envelope

For Air treatment systems, capacity and operating envelope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "capacity and operating envelope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: materials and compatibility

For Air treatment systems, materials and compatibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "materials and compatibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environment and hazardous classification

For Air treatment systems, environment and hazardous classification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environment and hazardous classification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/utilities

For Air treatment systems, power/utilities must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/utilities",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces and controls

For Air treatment systems, interfaces and controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces and controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: quality and certification

For Air treatment systems, quality and certification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "quality and certification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation and commissioning

For Air treatment systems, installation and commissioning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation and commissioning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: spares and maintenance

For Air treatment systems, spares and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "spares and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: logistics and lifecycle

For Air treatment systems, logistics and lifecycle must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "logistics and lifecycle",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: air demand/profile

For Air treatment systems, air demand/profile must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "air demand/profile",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: pressure/quality

For Air treatment systems, pressure/quality must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "pressure/quality",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: compressor technology

For Air treatment systems, compressor technology must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "compressor technology",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/cooling

For Air treatment systems, power/cooling must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/cooling",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: receiver/dryer/filters

For Air treatment systems, receiver/dryer/filters must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "receiver/dryer/filters",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: controls

For Air treatment systems, controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: maintenance

For Air treatment systems, maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-treatment-systems-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer/OEM

A manufacturer/OEM may be relevant to Air treatment systems depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-treatment-systems-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer/OEM",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Air treatment systems depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-treatment-systems-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: industrial system integrator

A industrial system integrator may be relevant to Air treatment systems depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-treatment-systems-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "industrial system integrator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator/machine shop

A fabricator/machine shop may be relevant to Air treatment systems depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-treatment-systems-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator/machine shop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: EPC or specialist contractor

A EPC or specialist contractor may be relevant to Air treatment systems depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-treatment-systems-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "EPC or specialist contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: inspection/testing body

A inspection/testing body may be relevant to Air treatment systems depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-treatment-systems-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "inspection/testing body",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer/OEM

This supplier type can participate in Air treatment systems only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer/OEM",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Air treatment systems only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — industrial system integrator

This supplier type can participate in Air treatment systems only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "industrial system integrator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator/machine shop

This supplier type can participate in Air treatment systems only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator/machine shop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — EPC or specialist contractor

This supplier type can participate in Air treatment systems only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "EPC or specialist contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — inspection/testing body

This supplier type can participate in Air treatment systems only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "inspection/testing body",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — rental/service provider

This supplier type can participate in Air treatment systems only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "rental/service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance and spare-parts provider

This supplier type can participate in Air treatment systems only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer/OEM

Before routing a Air treatment systems inquiry to a manufacturer/OEM, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "manufacturer/OEM",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Air treatment systems inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — industrial system integrator

Before routing a Air treatment systems inquiry to a industrial system integrator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "industrial system integrator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator/machine shop

Before routing a Air treatment systems inquiry to a fabricator/machine shop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "fabricator/machine shop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — EPC or specialist contractor

Before routing a Air treatment systems inquiry to a EPC or specialist contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "EPC or specialist contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — inspection/testing body

Before routing a Air treatment systems inquiry to a inspection/testing body, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "inspection/testing body",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — rental/service provider

Before routing a Air treatment systems inquiry to a rental/service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "rental/service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance and spare-parts provider

Before routing a Air treatment systems inquiry to a maintenance and spare-parts provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-treatment-systems-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Air treatment systems should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-treatment-systems-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Air treatment systems should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-treatment-systems-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Air treatment systems should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-treatment-systems-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Air treatment systems should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-treatment-systems-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Air treatment systems should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-treatment-systems-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Air treatment systems should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-treatment-systems-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Air treatment systems should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-treatment-systems-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Air treatment systems should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-treatment-systems-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Air treatment systems should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-treatment-systems-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Air treatment systems should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-treatment-systems-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Process/Duty Data Sheet

Process/Duty Data Sheet may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "process-duty-data-sheet",
  "document_name": "process/duty data sheet",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### P&Id Or Schematic

P&Id Or Schematic may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "p-and-id-or-schematic",
  "document_name": "P&ID or schematic",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Layout/General Arrangement

Layout/General Arrangement may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "layout-general-arrangement",
  "document_name": "layout/general arrangement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Hazardous Area Classification

Hazardous Area Classification may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "hazardous-area-classification",
  "document_name": "hazardous area classification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Single-Line/Control Diagram

Single-Line/Control Diagram may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "single-line-control-diagram",
  "document_name": "single-line/control diagram",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Interface List

Interface List may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "interface-list",
  "document_name": "interface list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quality Plan/Itp

Quality Plan/Itp may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quality-plan-itp",
  "document_name": "quality plan/ITP",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Certificates

Material Certificates may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-certificates",
  "document_name": "material certificates",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Reports

Inspection/Test Reports may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-reports",
  "document_name": "inspection/test reports",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement/Lifting Plan

Method Statement/Lifting Plan may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement-lifting-plan",
  "document_name": "method statement/lifting plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Commissioning Plan

Commissioning Plan may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "commissioning-plan",
  "document_name": "commissioning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Spares List

Spares List may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "spares-list",
  "document_name": "spares list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for Air treatment systems. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-treatment-systems-documents-document_requirement-0083`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Industrial, Standards, Conformity and Quality Services

For Air treatment systems, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-treatment-systems-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment, Climate and Agriculture Regulation

For Air treatment systems, consult Environment, Climate and Agriculture Regulation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-treatment-systems-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOCCAE

```json
{
  "source_id": "UAE-MOCCAE",
  "publisher": "Ministry of Climate Change and Environment",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment Agency Abu Dhabi Policies and Permits

For Air treatment systems, consult Environment Agency Abu Dhabi Policies and Permits when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-treatment-systems-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-EAD

```json
{
  "source_id": "UAE-EAD",
  "publisher": "Environment Agency Abu Dhabi",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ADNOC Supplier and In-Country Value Requirements

For Air treatment systems, consult ADNOC Supplier and In-Country Value Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-treatment-systems-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADNOC-SUPPLIER

```json
{
  "source_id": "UAE-ADNOC-SUPPLIER",
  "publisher": "ADNOC",
  "source_type": "state_enterprise_supplier_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Customs and Import/Export Guidance

For Air treatment systems, consult UAE Customs and Import/Export Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-treatment-systems-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CUSTOMS

```json
{
  "source_id": "UAE-CUSTOMS",
  "publisher": "Federal Authority for Identity, Citizenship, Customs and Port Security",
  "source_type": "government_customs_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Air treatment systems, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-treatment-systems-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### IEC Standards Catalogue

For Air treatment systems, consult IEC Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-treatment-systems-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: IEC-STANDARDS

```json
{
  "source_id": "IEC-STANDARDS",
  "publisher": "International Electrotechnical Commission",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For Air treatment systems, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-treatment-systems-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Air treatment systems. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-treatment-systems-commercial_pricing-cost_driver-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Air treatment systems. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-treatment-systems-commercial_pricing-cost_driver-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Air treatment systems. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-treatment-systems-commercial_pricing-cost_driver-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Air treatment systems. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-treatment-systems-commercial_pricing-cost_driver-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Air treatment systems. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-treatment-systems-commercial_pricing-cost_driver-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Air treatment systems. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-treatment-systems-commercial_pricing-cost_driver-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Air treatment systems. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-treatment-systems-commercial_pricing-cost_driver-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Air treatment systems. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-treatment-systems-commercial_pricing-cost_driver-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Air treatment systems. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-treatment-systems-commercial_pricing-cost_driver-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Air treatment systems. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-treatment-systems-commercial_pricing-cost_driver-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-treatment-systems-customer_tradeoffs-tradeoff-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-treatment-systems-customer_tradeoffs-tradeoff-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-treatment-systems-customer_tradeoffs-tradeoff-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-treatment-systems-customer_tradeoffs-tradeoff-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-treatment-systems-customer_tradeoffs-tradeoff-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-treatment-systems-customer_tradeoffs-tradeoff-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-treatment-systems-customer_tradeoffs-tradeoff-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-treatment-systems-customer_tradeoffs-tradeoff-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-treatment-systems-customer_tradeoffs-tradeoff-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-treatment-systems-customer_tradeoffs-tradeoff-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Air treatment systems, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-treatment-systems-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Air treatment systems, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-treatment-systems-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Air treatment systems, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-treatment-systems-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Air treatment systems, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-treatment-systems-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Air treatment systems, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-treatment-systems-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Air treatment systems, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-treatment-systems-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Air treatment systems, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-treatment-systems-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Air treatment systems, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-treatment-systems-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Air treatment systems, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-treatment-systems-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Air treatment systems, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-treatment-systems-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Air treatment systems, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-treatment-systems-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Air treatment systems, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-treatment-systems-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Air treatment systems, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-treatment-systems-best_practices-qualification_best_practice-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Air treatment systems, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-treatment-systems-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Air treatment systems, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-treatment-systems-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Air treatment systems, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-treatment-systems-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Air treatment systems; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-treatment-systems-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Air treatment systems; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-treatment-systems-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Air treatment systems; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-treatment-systems-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Air treatment systems; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-treatment-systems-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Air treatment systems; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-treatment-systems-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Air treatment systems; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-treatment-systems-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Air treatment systems; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-treatment-systems-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Air treatment systems; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-treatment-systems-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What process, duty, product, load, medium or operating objective applies?

Ask in plain language: What process, duty, product, load, medium or operating objective applies? Arabic draft: ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-process-duty",
  "question_en": "What process, duty, product, load, medium or operating objective applies?",
  "question_ar": "ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "process-duty",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What process, duty, product, load, medium or operating objective applies? is missing

When the normalized field process-duty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-process-duty",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "process-duty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-process-duty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What capacity, pressure, temperature, speed, load, accuracy or operating range is required?

Ask in plain language: What capacity, pressure, temperature, speed, load, accuracy or operating range is required? Arabic draft: ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-capacity-conditions",
  "question_en": "What capacity, pressure, temperature, speed, load, accuracy or operating range is required?",
  "question_ar": "ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟",
  "expected_answer_type": "structured_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-conditions",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What capacity, pressure, temperature, speed, load, accuracy or operating range is required? is missing

When the normalized field capacity-conditions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-capacity-conditions",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-conditions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-capacity-conditions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?

Ask in plain language: What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? Arabic draft: ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-materials-compatibility",
  "question_en": "What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?",
  "question_ar": "ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "materials-compatibility",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? is missing

When the normalized field materials-compatibility is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-materials-compatibility",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "materials-compatibility",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-materials-compatibility"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?

Ask in plain language: What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies? Arabic draft: ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-environment-hazard",
  "question_en": "What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?",
  "question_ar": "ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "environment-hazard",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?

Ask in plain language: What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? Arabic draft: ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-utilities-controls",
  "question_en": "What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?",
  "question_ar": "ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-controls",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? is missing

When the normalized field utilities-controls is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-utilities-controls",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-controls",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-utilities-controls"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What code, material certificate, test, inspection, traceability or third-party approval is required?

Ask in plain language: What code, material certificate, test, inspection, traceability or third-party approval is required? Arabic draft: ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-standards-certification",
  "question_en": "What code, material certificate, test, inspection, traceability or third-party approval is required?",
  "question_ar": "ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "standards-certification",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?

Ask in plain language: What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? Arabic draft: ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-installation-commissioning",
  "question_en": "What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?",
  "question_ar": "ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-commissioning",
  "order": 190,
  "confidence_contribution": 0.03
}
```

### Ask when What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? is missing

When the normalized field installation-commissioning is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-installation-commissioning",
  "priority": 981,
  "when": {
    "all": [
      {
        "field": "installation-commissioning",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-installation-commissioning"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What consumables, critical spares, maintenance interval, response time and lifecycle support are required?

Ask in plain language: What consumables, critical spares, maintenance interval, response time and lifecycle support are required? Arabic draft: ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-spares-service",
  "question_en": "What consumables, critical spares, maintenance interval, response time and lifecycle support are required?",
  "question_ar": "ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "spares-service",
  "order": 200,
  "confidence_contribution": 0.012
}
```

### Please clarify the air demand/profile requirements for Air treatment systems.

Ask in plain language: Please clarify the air demand/profile requirements for Air treatment systems. Arabic draft: يرجى توضيح متطلبات air demand/profile الخاصة بـ Air treatment systems. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-facet-01",
  "question_en": "Please clarify the air demand/profile requirements for Air treatment systems.",
  "question_ar": "يرجى توضيح متطلبات air demand/profile الخاصة بـ Air treatment systems.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the air demand/profile requirements for Air treatment systems. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the pressure/quality requirements for Air treatment systems.

Ask in plain language: Please clarify the pressure/quality requirements for Air treatment systems. Arabic draft: يرجى توضيح متطلبات pressure/quality الخاصة بـ Air treatment systems. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-facet-02",
  "question_en": "Please clarify the pressure/quality requirements for Air treatment systems.",
  "question_ar": "يرجى توضيح متطلبات pressure/quality الخاصة بـ Air treatment systems.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the pressure/quality requirements for Air treatment systems. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the compressor technology requirements for Air treatment systems.

Ask in plain language: Please clarify the compressor technology requirements for Air treatment systems. Arabic draft: يرجى توضيح متطلبات compressor technology الخاصة بـ Air treatment systems. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-facet-03",
  "question_en": "Please clarify the compressor technology requirements for Air treatment systems.",
  "question_ar": "يرجى توضيح متطلبات compressor technology الخاصة بـ Air treatment systems.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the compressor technology requirements for Air treatment systems. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the power/cooling requirements for Air treatment systems.

Ask in plain language: Please clarify the power/cooling requirements for Air treatment systems. Arabic draft: يرجى توضيح متطلبات power/cooling الخاصة بـ Air treatment systems. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-facet-04",
  "question_en": "Please clarify the power/cooling requirements for Air treatment systems.",
  "question_ar": "يرجى توضيح متطلبات power/cooling الخاصة بـ Air treatment systems.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the receiver/dryer/filters requirements for Air treatment systems.

Ask in plain language: Please clarify the receiver/dryer/filters requirements for Air treatment systems. Arabic draft: يرجى توضيح متطلبات receiver/dryer/filters الخاصة بـ Air treatment systems. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-facet-05",
  "question_en": "Please clarify the receiver/dryer/filters requirements for Air treatment systems.",
  "question_ar": "يرجى توضيح متطلبات receiver/dryer/filters الخاصة بـ Air treatment systems.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the controls requirements for Air treatment systems.

Ask in plain language: Please clarify the controls requirements for Air treatment systems. Arabic draft: يرجى توضيح متطلبات controls الخاصة بـ Air treatment systems. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-facet-06",
  "question_en": "Please clarify the controls requirements for Air treatment systems.",
  "question_ar": "يرجى توضيح متطلبات controls الخاصة بـ Air treatment systems.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the maintenance requirements for Air treatment systems.

Ask in plain language: Please clarify the maintenance requirements for Air treatment systems. Arabic draft: يرجى توضيح متطلبات maintenance الخاصة بـ Air treatment systems. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-facet-07",
  "question_en": "Please clarify the maintenance requirements for Air treatment systems.",
  "question_ar": "يرجى توضيح متطلبات maintenance الخاصة بـ Air treatment systems.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact Air treatment systems product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Air treatment systems product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Air treatment systems التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-exact-subtype",
  "question_en": "Which exact Air treatment systems product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Air treatment systems التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Air treatment systems product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-treatment-systems-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Air treatment systems are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Air treatment systems are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Air treatment systems التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-unknowns",
  "question_en": "Which details about Air treatment systems are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Air treatment systems التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Air treatment systems?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Air treatment systems? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Air treatment systems؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-treatment-systems-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Air treatment systems?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Air treatment systems؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Air treatment systems, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Air treatment systems, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Air treatment systems, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Air treatment systems, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0186`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER, UAE-CUSTOMS, ISO-STANDARDS, IEC-STANDARDS, ASTM-STANDARDS

```json
{
  "rule_id": "R-039-air-treatment-systems-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-MOIAT",
        "UAE-MOCCAE",
        "UAE-EAD",
        "UAE-ADNOC-SUPPLIER",
        "UAE-CUSTOMS",
        "ISO-STANDARDS",
        "IEC-STANDARDS",
        "ASTM-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Air treatment systems, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Air treatment systems, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Air treatment systems, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Air treatment systems, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-treatment-systems-inquiry_qualification-decision_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-treatment-systems-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Air treatment systems, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-treatment-systems-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-treatment-systems-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Air treatment systems, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-treatment-systems-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-treatment-systems-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Air treatment systems, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-treatment-systems-validation-validation_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-treatment-systems-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Air treatment systems, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-treatment-systems-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-treatment-systems-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Air treatment systems, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-treatment-systems-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-treatment-systems-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Air treatment systems, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-treatment-systems-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-treatment-systems-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Air treatment systems, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-treatment-systems-validation-validation_rule-0197`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "validation_id": "V-039-air-treatment-systems-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Air treatment systems, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-treatment-systems-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-treatment-systems-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Air treatment systems, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-treatment-systems-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-treatment-systems-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Air treatment systems, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-treatment-systems-validation-validation_rule-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-treatment-systems-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Air treatment systems without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-treatment-systems-scenario_test-scenario-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-treatment-systems-001",
  "setup": "Customer asks informally for Air treatment systems without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Air treatment systems with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-treatment-systems-scenario_test-scenario-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-treatment-systems-002",
  "setup": "Customer requests price for Air treatment systems with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Air treatment systems. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-treatment-systems-scenario_test-scenario-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-treatment-systems-003",
  "setup": "Customer uploads a relevant schedule/specification for Air treatment systems.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Air treatment systems. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-treatment-systems-scenario_test-scenario-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-treatment-systems-004",
  "setup": "Customer message and uploaded document disagree on Air treatment systems.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Air treatment systems. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-treatment-systems-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-treatment-systems-005",
  "setup": "Supplier proposes a different product, provider or method for Air treatment systems.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Air treatment systems sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-treatment-systems-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-treatment-systems-006",
  "setup": "Customer needs Air treatment systems sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Air treatment systems needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-treatment-systems-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-treatment-systems-007",
  "setup": "The request for Air treatment systems needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Air treatment systems

English term: Air treatment systems. Arabic operational draft: متطلبات Air treatment systems. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Air treatment systems",
  "term_ar": "متطلبات Air treatment systems",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### air demand/profile

English term: air demand/profile. Arabic operational draft: متطلبات air demand/profile. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "air demand/profile",
  "term_ar": "متطلبات air demand/profile",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### pressure/quality

English term: pressure/quality. Arabic operational draft: متطلبات pressure/quality. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "pressure/quality",
  "term_ar": "متطلبات pressure/quality",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### compressor technology

English term: compressor technology. Arabic operational draft: متطلبات compressor technology. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compressor technology",
  "term_ar": "متطلبات compressor technology",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### power/cooling

English term: power/cooling. Arabic operational draft: متطلبات power/cooling. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "power/cooling",
  "term_ar": "متطلبات power/cooling",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### receiver/dryer/filters

English term: receiver/dryer/filters. Arabic operational draft: متطلبات receiver/dryer/filters. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "receiver/dryer/filters",
  "term_ar": "متطلبات receiver/dryer/filters",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```

### controls

English term: controls. Arabic operational draft: متطلبات controls. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-treatment-systems-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "controls",
  "term_ar": "متطلبات controls",
  "canonical_subcategory": "air-treatment-systems",
  "normalization_only": true
}
```


# 3. Pneumatic tools

**Arabic draft:** متطلبات Pneumatic tools
**Slug:** `pneumatic-tools`
**Aliases:** Pneumatic tools

## Industry

### Industry scope — Pneumatic tools

Pneumatic tools is treated as a distinct procurement route within Air Compressors & Pneumatics. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers industrial products, machinery, process systems, fabrication, logistics, maintenance and safety. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-039-pneumatic-tools-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD

```json
{
  "category": "Air Compressors & Pneumatics",
  "subcategory": "Pneumatic tools",
  "profile": "industrial",
  "aliases": [
    "Pneumatic tools"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Pneumatic tools

A normal UAE sourcing workflow for Pneumatic tools moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-039-pneumatic-tools-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Pneumatic tools

Customers may describe Pneumatic tools through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-039-pneumatic-tools-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Pneumatic tools

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-039-pneumatic-tools-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Pneumatic tools product or service

The primary deliverable requested within Pneumatic tools; exact type, quantity, performance, scope and acceptance must be normalized. For Pneumatic tools, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Pneumatic tools",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Pneumatic tools

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Pneumatic tools, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Pneumatic tools",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Pneumatic tools

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Pneumatic tools, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Pneumatic tools",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Pneumatic tools

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Pneumatic tools, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Pneumatic tools",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Pneumatic tools

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Pneumatic tools, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Pneumatic tools",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Pneumatic tools

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Pneumatic tools, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Pneumatic tools",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Pneumatic tools

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Pneumatic tools, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Pneumatic tools",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Pneumatic tools

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Pneumatic tools, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Pneumatic tools",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Air Demand/Profile scope component

Air Demand/Profile is a recurring scope component for Pneumatic tools. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "air demand/profile",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Pressure/Quality scope component

Pressure/Quality is a recurring scope component for Pneumatic tools. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "pressure/quality",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Compressor Technology scope component

Compressor Technology is a recurring scope component for Pneumatic tools. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "compressor technology",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Power/Cooling scope component

Power/Cooling is a recurring scope component for Pneumatic tools. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "power/cooling",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Receiver/Dryer/Filters scope component

Receiver/Dryer/Filters is a recurring scope component for Pneumatic tools. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "receiver/dryer/filters",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Controls scope component

Controls is a recurring scope component for Pneumatic tools. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "controls",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Maintenance scope component

Maintenance is a recurring scope component for Pneumatic tools. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-pneumatic-tools-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "maintenance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: process or duty

For Pneumatic tools, process or duty must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "process or duty",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: capacity and operating envelope

For Pneumatic tools, capacity and operating envelope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "capacity and operating envelope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: materials and compatibility

For Pneumatic tools, materials and compatibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "materials and compatibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environment and hazardous classification

For Pneumatic tools, environment and hazardous classification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environment and hazardous classification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/utilities

For Pneumatic tools, power/utilities must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/utilities",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces and controls

For Pneumatic tools, interfaces and controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces and controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: quality and certification

For Pneumatic tools, quality and certification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "quality and certification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation and commissioning

For Pneumatic tools, installation and commissioning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation and commissioning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: spares and maintenance

For Pneumatic tools, spares and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "spares and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: logistics and lifecycle

For Pneumatic tools, logistics and lifecycle must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "logistics and lifecycle",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: air demand/profile

For Pneumatic tools, air demand/profile must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "air demand/profile",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: pressure/quality

For Pneumatic tools, pressure/quality must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "pressure/quality",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: compressor technology

For Pneumatic tools, compressor technology must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "compressor technology",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/cooling

For Pneumatic tools, power/cooling must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/cooling",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: receiver/dryer/filters

For Pneumatic tools, receiver/dryer/filters must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "receiver/dryer/filters",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: controls

For Pneumatic tools, controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: maintenance

For Pneumatic tools, maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-pneumatic-tools-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer/OEM

A manufacturer/OEM may be relevant to Pneumatic tools depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-pneumatic-tools-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer/OEM",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Pneumatic tools depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-pneumatic-tools-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: industrial system integrator

A industrial system integrator may be relevant to Pneumatic tools depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-pneumatic-tools-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "industrial system integrator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator/machine shop

A fabricator/machine shop may be relevant to Pneumatic tools depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-pneumatic-tools-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator/machine shop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: EPC or specialist contractor

A EPC or specialist contractor may be relevant to Pneumatic tools depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-pneumatic-tools-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "EPC or specialist contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: inspection/testing body

A inspection/testing body may be relevant to Pneumatic tools depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-pneumatic-tools-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "inspection/testing body",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer/OEM

This supplier type can participate in Pneumatic tools only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer/OEM",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Pneumatic tools only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — industrial system integrator

This supplier type can participate in Pneumatic tools only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "industrial system integrator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator/machine shop

This supplier type can participate in Pneumatic tools only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator/machine shop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — EPC or specialist contractor

This supplier type can participate in Pneumatic tools only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "EPC or specialist contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — inspection/testing body

This supplier type can participate in Pneumatic tools only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "inspection/testing body",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — rental/service provider

This supplier type can participate in Pneumatic tools only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "rental/service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance and spare-parts provider

This supplier type can participate in Pneumatic tools only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer/OEM

Before routing a Pneumatic tools inquiry to a manufacturer/OEM, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "manufacturer/OEM",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Pneumatic tools inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — industrial system integrator

Before routing a Pneumatic tools inquiry to a industrial system integrator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "industrial system integrator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator/machine shop

Before routing a Pneumatic tools inquiry to a fabricator/machine shop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "fabricator/machine shop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — EPC or specialist contractor

Before routing a Pneumatic tools inquiry to a EPC or specialist contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "EPC or specialist contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — inspection/testing body

Before routing a Pneumatic tools inquiry to a inspection/testing body, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "inspection/testing body",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — rental/service provider

Before routing a Pneumatic tools inquiry to a rental/service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "rental/service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance and spare-parts provider

Before routing a Pneumatic tools inquiry to a maintenance and spare-parts provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-pneumatic-tools-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Pneumatic tools should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-pneumatic-tools-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Pneumatic tools should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-pneumatic-tools-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Pneumatic tools should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-pneumatic-tools-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Pneumatic tools should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-pneumatic-tools-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Pneumatic tools should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-pneumatic-tools-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Pneumatic tools should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-pneumatic-tools-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Pneumatic tools should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-pneumatic-tools-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Pneumatic tools should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-pneumatic-tools-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Pneumatic tools should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-pneumatic-tools-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Pneumatic tools should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-pneumatic-tools-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Process/Duty Data Sheet

Process/Duty Data Sheet may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "process-duty-data-sheet",
  "document_name": "process/duty data sheet",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### P&Id Or Schematic

P&Id Or Schematic may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "p-and-id-or-schematic",
  "document_name": "P&ID or schematic",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Layout/General Arrangement

Layout/General Arrangement may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "layout-general-arrangement",
  "document_name": "layout/general arrangement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Hazardous Area Classification

Hazardous Area Classification may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "hazardous-area-classification",
  "document_name": "hazardous area classification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Single-Line/Control Diagram

Single-Line/Control Diagram may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "single-line-control-diagram",
  "document_name": "single-line/control diagram",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Interface List

Interface List may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "interface-list",
  "document_name": "interface list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quality Plan/Itp

Quality Plan/Itp may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quality-plan-itp",
  "document_name": "quality plan/ITP",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Certificates

Material Certificates may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-certificates",
  "document_name": "material certificates",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Reports

Inspection/Test Reports may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-reports",
  "document_name": "inspection/test reports",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement/Lifting Plan

Method Statement/Lifting Plan may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement-lifting-plan",
  "document_name": "method statement/lifting plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Commissioning Plan

Commissioning Plan may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "commissioning-plan",
  "document_name": "commissioning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Spares List

Spares List may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "spares-list",
  "document_name": "spares list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for Pneumatic tools. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-pneumatic-tools-documents-document_requirement-0083`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Industrial, Standards, Conformity and Quality Services

For Pneumatic tools, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-pneumatic-tools-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment, Climate and Agriculture Regulation

For Pneumatic tools, consult Environment, Climate and Agriculture Regulation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-pneumatic-tools-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOCCAE

```json
{
  "source_id": "UAE-MOCCAE",
  "publisher": "Ministry of Climate Change and Environment",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment Agency Abu Dhabi Policies and Permits

For Pneumatic tools, consult Environment Agency Abu Dhabi Policies and Permits when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-pneumatic-tools-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-EAD

```json
{
  "source_id": "UAE-EAD",
  "publisher": "Environment Agency Abu Dhabi",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ADNOC Supplier and In-Country Value Requirements

For Pneumatic tools, consult ADNOC Supplier and In-Country Value Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-pneumatic-tools-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADNOC-SUPPLIER

```json
{
  "source_id": "UAE-ADNOC-SUPPLIER",
  "publisher": "ADNOC",
  "source_type": "state_enterprise_supplier_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Customs and Import/Export Guidance

For Pneumatic tools, consult UAE Customs and Import/Export Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-pneumatic-tools-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CUSTOMS

```json
{
  "source_id": "UAE-CUSTOMS",
  "publisher": "Federal Authority for Identity, Citizenship, Customs and Port Security",
  "source_type": "government_customs_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Pneumatic tools, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-pneumatic-tools-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### IEC Standards Catalogue

For Pneumatic tools, consult IEC Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-pneumatic-tools-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: IEC-STANDARDS

```json
{
  "source_id": "IEC-STANDARDS",
  "publisher": "International Electrotechnical Commission",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For Pneumatic tools, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-pneumatic-tools-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Pneumatic tools. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-pneumatic-tools-commercial_pricing-cost_driver-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Pneumatic tools. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-pneumatic-tools-commercial_pricing-cost_driver-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Pneumatic tools. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-pneumatic-tools-commercial_pricing-cost_driver-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Pneumatic tools. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-pneumatic-tools-commercial_pricing-cost_driver-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Pneumatic tools. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-pneumatic-tools-commercial_pricing-cost_driver-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Pneumatic tools. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-pneumatic-tools-commercial_pricing-cost_driver-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Pneumatic tools. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-pneumatic-tools-commercial_pricing-cost_driver-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Pneumatic tools. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-pneumatic-tools-commercial_pricing-cost_driver-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Pneumatic tools. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-pneumatic-tools-commercial_pricing-cost_driver-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Pneumatic tools. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-pneumatic-tools-commercial_pricing-cost_driver-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-pneumatic-tools-customer_tradeoffs-tradeoff-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-pneumatic-tools-customer_tradeoffs-tradeoff-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-pneumatic-tools-customer_tradeoffs-tradeoff-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-pneumatic-tools-customer_tradeoffs-tradeoff-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-pneumatic-tools-customer_tradeoffs-tradeoff-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-pneumatic-tools-customer_tradeoffs-tradeoff-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-pneumatic-tools-customer_tradeoffs-tradeoff-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-pneumatic-tools-customer_tradeoffs-tradeoff-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-pneumatic-tools-customer_tradeoffs-tradeoff-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-pneumatic-tools-customer_tradeoffs-tradeoff-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Pneumatic tools, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-pneumatic-tools-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Pneumatic tools, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-pneumatic-tools-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Pneumatic tools, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-pneumatic-tools-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Pneumatic tools, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-pneumatic-tools-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Pneumatic tools, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-pneumatic-tools-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Pneumatic tools, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-pneumatic-tools-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Pneumatic tools, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-pneumatic-tools-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Pneumatic tools, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-pneumatic-tools-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Pneumatic tools, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-pneumatic-tools-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Pneumatic tools, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-pneumatic-tools-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Pneumatic tools, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-pneumatic-tools-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Pneumatic tools, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-pneumatic-tools-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Pneumatic tools, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-pneumatic-tools-best_practices-qualification_best_practice-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Pneumatic tools, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-pneumatic-tools-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Pneumatic tools, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-pneumatic-tools-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Pneumatic tools, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-pneumatic-tools-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Pneumatic tools; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-pneumatic-tools-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Pneumatic tools; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-pneumatic-tools-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Pneumatic tools; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-pneumatic-tools-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Pneumatic tools; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-pneumatic-tools-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Pneumatic tools; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-pneumatic-tools-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Pneumatic tools; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-pneumatic-tools-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Pneumatic tools; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-pneumatic-tools-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Pneumatic tools; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-pneumatic-tools-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What process, duty, product, load, medium or operating objective applies?

Ask in plain language: What process, duty, product, load, medium or operating objective applies? Arabic draft: ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-process-duty",
  "question_en": "What process, duty, product, load, medium or operating objective applies?",
  "question_ar": "ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "process-duty",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What process, duty, product, load, medium or operating objective applies? is missing

When the normalized field process-duty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-process-duty",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "process-duty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-process-duty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What capacity, pressure, temperature, speed, load, accuracy or operating range is required?

Ask in plain language: What capacity, pressure, temperature, speed, load, accuracy or operating range is required? Arabic draft: ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-capacity-conditions",
  "question_en": "What capacity, pressure, temperature, speed, load, accuracy or operating range is required?",
  "question_ar": "ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟",
  "expected_answer_type": "structured_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-conditions",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What capacity, pressure, temperature, speed, load, accuracy or operating range is required? is missing

When the normalized field capacity-conditions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-capacity-conditions",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-conditions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-capacity-conditions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?

Ask in plain language: What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? Arabic draft: ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-materials-compatibility",
  "question_en": "What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?",
  "question_ar": "ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "materials-compatibility",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? is missing

When the normalized field materials-compatibility is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-materials-compatibility",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "materials-compatibility",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-materials-compatibility"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?

Ask in plain language: What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies? Arabic draft: ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-environment-hazard",
  "question_en": "What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?",
  "question_ar": "ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "environment-hazard",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?

Ask in plain language: What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? Arabic draft: ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-utilities-controls",
  "question_en": "What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?",
  "question_ar": "ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-controls",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? is missing

When the normalized field utilities-controls is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-utilities-controls",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-controls",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-utilities-controls"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What code, material certificate, test, inspection, traceability or third-party approval is required?

Ask in plain language: What code, material certificate, test, inspection, traceability or third-party approval is required? Arabic draft: ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-standards-certification",
  "question_en": "What code, material certificate, test, inspection, traceability or third-party approval is required?",
  "question_ar": "ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "standards-certification",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?

Ask in plain language: What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? Arabic draft: ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-installation-commissioning",
  "question_en": "What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?",
  "question_ar": "ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-commissioning",
  "order": 190,
  "confidence_contribution": 0.03
}
```

### Ask when What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? is missing

When the normalized field installation-commissioning is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-installation-commissioning",
  "priority": 981,
  "when": {
    "all": [
      {
        "field": "installation-commissioning",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-installation-commissioning"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What consumables, critical spares, maintenance interval, response time and lifecycle support are required?

Ask in plain language: What consumables, critical spares, maintenance interval, response time and lifecycle support are required? Arabic draft: ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-spares-service",
  "question_en": "What consumables, critical spares, maintenance interval, response time and lifecycle support are required?",
  "question_ar": "ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "spares-service",
  "order": 200,
  "confidence_contribution": 0.012
}
```

### Please clarify the air demand/profile requirements for Pneumatic tools.

Ask in plain language: Please clarify the air demand/profile requirements for Pneumatic tools. Arabic draft: يرجى توضيح متطلبات air demand/profile الخاصة بـ Pneumatic tools. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-facet-01",
  "question_en": "Please clarify the air demand/profile requirements for Pneumatic tools.",
  "question_ar": "يرجى توضيح متطلبات air demand/profile الخاصة بـ Pneumatic tools.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the air demand/profile requirements for Pneumatic tools. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the pressure/quality requirements for Pneumatic tools.

Ask in plain language: Please clarify the pressure/quality requirements for Pneumatic tools. Arabic draft: يرجى توضيح متطلبات pressure/quality الخاصة بـ Pneumatic tools. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-facet-02",
  "question_en": "Please clarify the pressure/quality requirements for Pneumatic tools.",
  "question_ar": "يرجى توضيح متطلبات pressure/quality الخاصة بـ Pneumatic tools.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the pressure/quality requirements for Pneumatic tools. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the compressor technology requirements for Pneumatic tools.

Ask in plain language: Please clarify the compressor technology requirements for Pneumatic tools. Arabic draft: يرجى توضيح متطلبات compressor technology الخاصة بـ Pneumatic tools. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-facet-03",
  "question_en": "Please clarify the compressor technology requirements for Pneumatic tools.",
  "question_ar": "يرجى توضيح متطلبات compressor technology الخاصة بـ Pneumatic tools.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the compressor technology requirements for Pneumatic tools. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the power/cooling requirements for Pneumatic tools.

Ask in plain language: Please clarify the power/cooling requirements for Pneumatic tools. Arabic draft: يرجى توضيح متطلبات power/cooling الخاصة بـ Pneumatic tools. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-facet-04",
  "question_en": "Please clarify the power/cooling requirements for Pneumatic tools.",
  "question_ar": "يرجى توضيح متطلبات power/cooling الخاصة بـ Pneumatic tools.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the receiver/dryer/filters requirements for Pneumatic tools.

Ask in plain language: Please clarify the receiver/dryer/filters requirements for Pneumatic tools. Arabic draft: يرجى توضيح متطلبات receiver/dryer/filters الخاصة بـ Pneumatic tools. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-facet-05",
  "question_en": "Please clarify the receiver/dryer/filters requirements for Pneumatic tools.",
  "question_ar": "يرجى توضيح متطلبات receiver/dryer/filters الخاصة بـ Pneumatic tools.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the controls requirements for Pneumatic tools.

Ask in plain language: Please clarify the controls requirements for Pneumatic tools. Arabic draft: يرجى توضيح متطلبات controls الخاصة بـ Pneumatic tools. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-facet-06",
  "question_en": "Please clarify the controls requirements for Pneumatic tools.",
  "question_ar": "يرجى توضيح متطلبات controls الخاصة بـ Pneumatic tools.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the maintenance requirements for Pneumatic tools.

Ask in plain language: Please clarify the maintenance requirements for Pneumatic tools. Arabic draft: يرجى توضيح متطلبات maintenance الخاصة بـ Pneumatic tools. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-facet-07",
  "question_en": "Please clarify the maintenance requirements for Pneumatic tools.",
  "question_ar": "يرجى توضيح متطلبات maintenance الخاصة بـ Pneumatic tools.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact Pneumatic tools product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Pneumatic tools product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Pneumatic tools التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-exact-subtype",
  "question_en": "Which exact Pneumatic tools product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Pneumatic tools التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Pneumatic tools product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-pneumatic-tools-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Pneumatic tools are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Pneumatic tools are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Pneumatic tools التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-unknowns",
  "question_en": "Which details about Pneumatic tools are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Pneumatic tools التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Pneumatic tools?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Pneumatic tools? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Pneumatic tools؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-pneumatic-tools-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Pneumatic tools?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Pneumatic tools؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Pneumatic tools, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Pneumatic tools, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Pneumatic tools, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Pneumatic tools, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0186`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER, UAE-CUSTOMS, ISO-STANDARDS, IEC-STANDARDS, ASTM-STANDARDS

```json
{
  "rule_id": "R-039-pneumatic-tools-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-MOIAT",
        "UAE-MOCCAE",
        "UAE-EAD",
        "UAE-ADNOC-SUPPLIER",
        "UAE-CUSTOMS",
        "ISO-STANDARDS",
        "IEC-STANDARDS",
        "ASTM-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Pneumatic tools, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Pneumatic tools, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Pneumatic tools, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Pneumatic tools, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-pneumatic-tools-inquiry_qualification-decision_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-pneumatic-tools-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Pneumatic tools, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-pneumatic-tools-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-pneumatic-tools-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Pneumatic tools, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-pneumatic-tools-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-pneumatic-tools-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Pneumatic tools, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-pneumatic-tools-validation-validation_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-pneumatic-tools-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Pneumatic tools, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-pneumatic-tools-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-pneumatic-tools-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Pneumatic tools, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-pneumatic-tools-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-pneumatic-tools-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Pneumatic tools, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-pneumatic-tools-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-pneumatic-tools-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Pneumatic tools, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-pneumatic-tools-validation-validation_rule-0197`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "validation_id": "V-039-pneumatic-tools-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Pneumatic tools, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-pneumatic-tools-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-pneumatic-tools-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Pneumatic tools, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-pneumatic-tools-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-pneumatic-tools-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Pneumatic tools, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-pneumatic-tools-validation-validation_rule-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-pneumatic-tools-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Pneumatic tools without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-pneumatic-tools-scenario_test-scenario-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-pneumatic-tools-001",
  "setup": "Customer asks informally for Pneumatic tools without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Pneumatic tools with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-pneumatic-tools-scenario_test-scenario-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-pneumatic-tools-002",
  "setup": "Customer requests price for Pneumatic tools with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Pneumatic tools. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-pneumatic-tools-scenario_test-scenario-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-pneumatic-tools-003",
  "setup": "Customer uploads a relevant schedule/specification for Pneumatic tools.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Pneumatic tools. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-pneumatic-tools-scenario_test-scenario-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-pneumatic-tools-004",
  "setup": "Customer message and uploaded document disagree on Pneumatic tools.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Pneumatic tools. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-pneumatic-tools-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-pneumatic-tools-005",
  "setup": "Supplier proposes a different product, provider or method for Pneumatic tools.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Pneumatic tools sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-pneumatic-tools-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-pneumatic-tools-006",
  "setup": "Customer needs Pneumatic tools sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Pneumatic tools needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-pneumatic-tools-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-pneumatic-tools-007",
  "setup": "The request for Pneumatic tools needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Pneumatic tools

English term: Pneumatic tools. Arabic operational draft: متطلبات Pneumatic tools. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Pneumatic tools",
  "term_ar": "متطلبات Pneumatic tools",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### air demand/profile

English term: air demand/profile. Arabic operational draft: متطلبات air demand/profile. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "air demand/profile",
  "term_ar": "متطلبات air demand/profile",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### pressure/quality

English term: pressure/quality. Arabic operational draft: متطلبات pressure/quality. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "pressure/quality",
  "term_ar": "متطلبات pressure/quality",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### compressor technology

English term: compressor technology. Arabic operational draft: متطلبات compressor technology. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compressor technology",
  "term_ar": "متطلبات compressor technology",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### power/cooling

English term: power/cooling. Arabic operational draft: متطلبات power/cooling. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "power/cooling",
  "term_ar": "متطلبات power/cooling",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### receiver/dryer/filters

English term: receiver/dryer/filters. Arabic operational draft: متطلبات receiver/dryer/filters. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "receiver/dryer/filters",
  "term_ar": "متطلبات receiver/dryer/filters",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```

### controls

English term: controls. Arabic operational draft: متطلبات controls. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-pneumatic-tools-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "controls",
  "term_ar": "متطلبات controls",
  "canonical_subcategory": "pneumatic-tools",
  "normalization_only": true
}
```


# 4. Air receivers

**Arabic draft:** متطلبات Air receivers
**Slug:** `air-receivers`
**Aliases:** Air receivers

## Industry

### Industry scope — Air receivers

Air receivers is treated as a distinct procurement route within Air Compressors & Pneumatics. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers industrial products, machinery, process systems, fabrication, logistics, maintenance and safety. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-039-air-receivers-industry-subcategory_overview-0001`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD

```json
{
  "category": "Air Compressors & Pneumatics",
  "subcategory": "Air receivers",
  "profile": "industrial",
  "aliases": [
    "Air receivers"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Air receivers

A normal UAE sourcing workflow for Air receivers moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-039-air-receivers-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Air receivers

Customers may describe Air receivers through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-039-air-receivers-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Air receivers

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-039-air-receivers-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Air receivers product or service

The primary deliverable requested within Air receivers; exact type, quantity, performance, scope and acceptance must be normalized. For Air receivers, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-receivers-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Air receivers",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Air receivers

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Air receivers, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-receivers-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Air receivers",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Air receivers

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Air receivers, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-receivers-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Air receivers",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Air receivers

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Air receivers, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-receivers-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Air receivers",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Air receivers

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Air receivers, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-receivers-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Air receivers",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Air receivers

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Air receivers, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-receivers-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Air receivers",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Air receivers

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Air receivers, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-receivers-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Air receivers",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Air receivers

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Air receivers, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-039-air-receivers-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Air receivers",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Air Demand/Profile scope component

Air Demand/Profile is a recurring scope component for Air receivers. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-receivers-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "air demand/profile",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Pressure/Quality scope component

Pressure/Quality is a recurring scope component for Air receivers. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-receivers-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "pressure/quality",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Compressor Technology scope component

Compressor Technology is a recurring scope component for Air receivers. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-receivers-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "compressor technology",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Power/Cooling scope component

Power/Cooling is a recurring scope component for Air receivers. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-receivers-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "power/cooling",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Receiver/Dryer/Filters scope component

Receiver/Dryer/Filters is a recurring scope component for Air receivers. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-receivers-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "receiver/dryer/filters",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Controls scope component

Controls is a recurring scope component for Air receivers. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-receivers-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "controls",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Maintenance scope component

Maintenance is a recurring scope component for Air receivers. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-039-air-receivers-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "maintenance",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: process or duty

For Air receivers, process or duty must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "process or duty",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: capacity and operating envelope

For Air receivers, capacity and operating envelope must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "capacity and operating envelope",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: materials and compatibility

For Air receivers, materials and compatibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "materials and compatibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: environment and hazardous classification

For Air receivers, environment and hazardous classification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "environment and hazardous classification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/utilities

For Air receivers, power/utilities must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/utilities",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: interfaces and controls

For Air receivers, interfaces and controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "interfaces and controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: quality and certification

For Air receivers, quality and certification must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "quality and certification",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: installation and commissioning

For Air receivers, installation and commissioning must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "installation and commissioning",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: spares and maintenance

For Air receivers, spares and maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "spares and maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: logistics and lifecycle

For Air receivers, logistics and lifecycle must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "logistics and lifecycle",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: air demand/profile

For Air receivers, air demand/profile must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "air demand/profile",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: pressure/quality

For Air receivers, pressure/quality must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "pressure/quality",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: compressor technology

For Air receivers, compressor technology must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "compressor technology",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: power/cooling

For Air receivers, power/cooling must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "power/cooling",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: receiver/dryer/filters

For Air receivers, receiver/dryer/filters must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "receiver/dryer/filters",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: controls

For Air receivers, controls must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "controls",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: maintenance

For Air receivers, maintenance must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-039-air-receivers-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "maintenance",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: manufacturer/OEM

A manufacturer/OEM may be relevant to Air receivers depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-receivers-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "manufacturer/OEM",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: authorized distributor

A authorized distributor may be relevant to Air receivers depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-receivers-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "authorized distributor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: industrial system integrator

A industrial system integrator may be relevant to Air receivers depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-receivers-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "industrial system integrator",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: fabricator/machine shop

A fabricator/machine shop may be relevant to Air receivers depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-receivers-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "fabricator/machine shop",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: EPC or specialist contractor

A EPC or specialist contractor may be relevant to Air receivers depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-receivers-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "EPC or specialist contractor",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: inspection/testing body

A inspection/testing body may be relevant to Air receivers depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-039-air-receivers-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "inspection/testing body",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — manufacturer/OEM

This supplier type can participate in Air receivers only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-receivers-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "manufacturer/OEM",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — authorized distributor

This supplier type can participate in Air receivers only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-receivers-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "authorized distributor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — industrial system integrator

This supplier type can participate in Air receivers only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-receivers-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "industrial system integrator",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — fabricator/machine shop

This supplier type can participate in Air receivers only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-receivers-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "fabricator/machine shop",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — EPC or specialist contractor

This supplier type can participate in Air receivers only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-receivers-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "EPC or specialist contractor",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — inspection/testing body

This supplier type can participate in Air receivers only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-receivers-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "inspection/testing body",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — rental/service provider

This supplier type can participate in Air receivers only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-receivers-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "rental/service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — maintenance and spare-parts provider

This supplier type can participate in Air receivers only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-039-air-receivers-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — manufacturer/OEM

Before routing a Air receivers inquiry to a manufacturer/OEM, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-receivers-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "manufacturer/OEM",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — authorized distributor

Before routing a Air receivers inquiry to a authorized distributor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-receivers-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "authorized distributor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — industrial system integrator

Before routing a Air receivers inquiry to a industrial system integrator, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-receivers-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "industrial system integrator",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — fabricator/machine shop

Before routing a Air receivers inquiry to a fabricator/machine shop, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-receivers-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "fabricator/machine shop",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — EPC or specialist contractor

Before routing a Air receivers inquiry to a EPC or specialist contractor, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-receivers-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "EPC or specialist contractor",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — inspection/testing body

Before routing a Air receivers inquiry to a inspection/testing body, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-receivers-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "inspection/testing body",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — rental/service provider

Before routing a Air receivers inquiry to a rental/service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-receivers-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "rental/service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — maintenance and spare-parts provider

Before routing a Air receivers inquiry to a maintenance and spare-parts provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-039-air-receivers-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "supplier_type": "maintenance and spare-parts provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Air receivers should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-receivers-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Air receivers should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-receivers-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Air receivers should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-receivers-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Air receivers should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-receivers-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Air receivers should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-receivers-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Air receivers should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-receivers-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Air receivers should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-receivers-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Air receivers should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-receivers-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Air receivers should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-receivers-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Air receivers should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-039-air-receivers-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Process/Duty Data Sheet

Process/Duty Data Sheet may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "process-duty-data-sheet",
  "document_name": "process/duty data sheet",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Equipment Schedule

Equipment Schedule may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "equipment-schedule",
  "document_name": "equipment schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### P&Id Or Schematic

P&Id Or Schematic may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "p-and-id-or-schematic",
  "document_name": "P&ID or schematic",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Layout/General Arrangement

Layout/General Arrangement may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "layout-general-arrangement",
  "document_name": "layout/general arrangement",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Specification

Material Specification may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-specification",
  "document_name": "material specification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Hazardous Area Classification

Hazardous Area Classification may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "hazardous-area-classification",
  "document_name": "hazardous area classification",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Single-Line/Control Diagram

Single-Line/Control Diagram may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "single-line-control-diagram",
  "document_name": "single-line/control diagram",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Interface List

Interface List may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "interface-list",
  "document_name": "interface list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Quality Plan/Itp

Quality Plan/Itp may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "quality-plan-itp",
  "document_name": "quality plan/ITP",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Material Certificates

Material Certificates may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "material-certificates",
  "document_name": "material certificates",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Inspection/Test Reports

Inspection/Test Reports may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "inspection-test-reports",
  "document_name": "inspection/test reports",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Method Statement/Lifting Plan

Method Statement/Lifting Plan may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "method-statement-lifting-plan",
  "document_name": "method statement/lifting plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Commissioning Plan

Commissioning Plan may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "commissioning-plan",
  "document_name": "commissioning plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Spares List

Spares List may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "spares-list",
  "document_name": "spares list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### O&M Manual

O&M Manual may provide or verify information needed for Air receivers. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-039-air-receivers-documents-document_requirement-0083`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "o-and-m-manual",
  "document_name": "O&M manual",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Industrial, Standards, Conformity and Quality Services

For Air receivers, consult Industrial, Standards, Conformity and Quality Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-receivers-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOIAT

```json
{
  "source_id": "UAE-MOIAT",
  "publisher": "Ministry of Industry and Advanced Technology",
  "source_type": "government_industry_standards_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment, Climate and Agriculture Regulation

For Air receivers, consult Environment, Climate and Agriculture Regulation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-receivers-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOCCAE

```json
{
  "source_id": "UAE-MOCCAE",
  "publisher": "Ministry of Climate Change and Environment",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Environment Agency Abu Dhabi Policies and Permits

For Air receivers, consult Environment Agency Abu Dhabi Policies and Permits when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-receivers-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-EAD

```json
{
  "source_id": "UAE-EAD",
  "publisher": "Environment Agency Abu Dhabi",
  "source_type": "government_environment_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ADNOC Supplier and In-Country Value Requirements

For Air receivers, consult ADNOC Supplier and In-Country Value Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-receivers-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ADNOC-SUPPLIER

```json
{
  "source_id": "UAE-ADNOC-SUPPLIER",
  "publisher": "ADNOC",
  "source_type": "state_enterprise_supplier_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Customs and Import/Export Guidance

For Air receivers, consult UAE Customs and Import/Export Guidance when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-receivers-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CUSTOMS

```json
{
  "source_id": "UAE-CUSTOMS",
  "publisher": "Federal Authority for Identity, Citizenship, Customs and Port Security",
  "source_type": "government_customs_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ISO Standards Catalogue

For Air receivers, consult ISO Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-receivers-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ISO-STANDARDS

```json
{
  "source_id": "ISO-STANDARDS",
  "publisher": "International Organization for Standardization",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### IEC Standards Catalogue

For Air receivers, consult IEC Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-receivers-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: IEC-STANDARDS

```json
{
  "source_id": "IEC-STANDARDS",
  "publisher": "International Electrotechnical Commission",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### ASTM Standards Catalogue

For Air receivers, consult ASTM Standards Catalogue when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-039-air-receivers-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: ASTM-STANDARDS

```json
{
  "source_id": "ASTM-STANDARDS",
  "publisher": "ASTM International",
  "source_type": "paid_standard_reference",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Air receivers. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-receivers-commercial_pricing-cost_driver-0092`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Air receivers. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-receivers-commercial_pricing-cost_driver-0094`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Air receivers. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-receivers-commercial_pricing-cost_driver-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Air receivers. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-receivers-commercial_pricing-cost_driver-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Air receivers. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-receivers-commercial_pricing-cost_driver-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Air receivers. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-receivers-commercial_pricing-cost_driver-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Air receivers. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-receivers-commercial_pricing-cost_driver-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Air receivers. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-receivers-commercial_pricing-cost_driver-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Air receivers. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-receivers-commercial_pricing-cost_driver-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Air receivers. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-039-air-receivers-commercial_pricing-cost_driver-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-receivers-customer_tradeoffs-tradeoff-0093`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-receivers-customer_tradeoffs-tradeoff-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-receivers-customer_tradeoffs-tradeoff-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-receivers-customer_tradeoffs-tradeoff-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-receivers-customer_tradeoffs-tradeoff-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-receivers-customer_tradeoffs-tradeoff-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-receivers-customer_tradeoffs-tradeoff-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-receivers-customer_tradeoffs-tradeoff-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-receivers-customer_tradeoffs-tradeoff-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-039-air-receivers-customer_tradeoffs-tradeoff-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Air receivers, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-receivers-risk-risk_control-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Air receivers, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-receivers-risk-risk_control-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Air receivers, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-receivers-risk-risk_control-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Air receivers, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-receivers-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Air receivers, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-receivers-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Air receivers, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-receivers-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Air receivers, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-receivers-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Air receivers, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-receivers-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Air receivers, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-receivers-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Air receivers, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-039-air-receivers-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Air receivers, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-receivers-best_practices-qualification_best_practice-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Air receivers, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-receivers-best_practices-qualification_best_practice-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Air receivers, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-receivers-best_practices-qualification_best_practice-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Air receivers, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-receivers-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Air receivers, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-receivers-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Air receivers, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-039-air-receivers-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Air receivers; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-receivers-troubleshooting-recovery_guidance-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Air receivers; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-receivers-troubleshooting-recovery_guidance-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Air receivers; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-receivers-troubleshooting-recovery_guidance-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Air receivers; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-receivers-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Air receivers; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-receivers-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Air receivers; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-receivers-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Air receivers; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-receivers-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Air receivers; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-039-air-receivers-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What process, duty, product, load, medium or operating objective applies?

Ask in plain language: What process, duty, product, load, medium or operating objective applies? Arabic draft: ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-process-duty",
  "question_en": "What process, duty, product, load, medium or operating objective applies?",
  "question_ar": "ما العملية أو المهمة أو المنتج أو الحمل أو الوسط أو الهدف التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "process-duty",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What process, duty, product, load, medium or operating objective applies? is missing

When the normalized field process-duty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-process-duty",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "process-duty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-process-duty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What capacity, pressure, temperature, speed, load, accuracy or operating range is required?

Ask in plain language: What capacity, pressure, temperature, speed, load, accuracy or operating range is required? Arabic draft: ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-capacity-conditions",
  "question_en": "What capacity, pressure, temperature, speed, load, accuracy or operating range is required?",
  "question_ar": "ما السعة أو الضغط أو الحرارة أو السرعة أو الحمل أو الدقة أو نطاق التشغيل؟",
  "expected_answer_type": "structured_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "capacity-conditions",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What capacity, pressure, temperature, speed, load, accuracy or operating range is required? is missing

When the normalized field capacity-conditions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-capacity-conditions",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "capacity-conditions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-capacity-conditions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?

Ask in plain language: What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? Arabic draft: ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-materials-compatibility",
  "question_en": "What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply?",
  "question_ar": "ما المواد والكيماويات والتآكل والتلوث والنظافة أو شروط التوافق؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "materials-compatibility",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What materials, chemicals, corrosion, contamination, cleanliness or compatibility conditions apply? is missing

When the normalized field materials-compatibility is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-materials-compatibility",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "materials-compatibility",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-materials-compatibility"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?

Ask in plain language: What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies? Arabic draft: ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-environment-hazard",
  "question_en": "What indoor/outdoor, marine, dust, heat, hazardous-area, hygiene or clean-environment classification applies?",
  "question_ar": "ما تصنيف الداخل أو الخارج أو البحري أو الغبار أو الحرارة أو المناطق الخطرة أو النظافة؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "environment-hazard",
  "order": 160,
  "confidence_contribution": 0.012
}
```

### What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?

Ask in plain language: What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? Arabic draft: ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-utilities-controls",
  "question_en": "What power, fuel, air, water, cooling, controls, communication and safety interfaces are available?",
  "question_ar": "ما الطاقة والوقود والهواء والماء والتبريد والتحكم والاتصال وواجهات السلامة المتاحة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "utilities-controls",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What power, fuel, air, water, cooling, controls, communication and safety interfaces are available? is missing

When the normalized field utilities-controls is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-utilities-controls",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "utilities-controls",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-utilities-controls"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What code, material certificate, test, inspection, traceability or third-party approval is required?

Ask in plain language: What code, material certificate, test, inspection, traceability or third-party approval is required? Arabic draft: ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-standards-certification",
  "question_en": "What code, material certificate, test, inspection, traceability or third-party approval is required?",
  "question_ar": "ما الكود أو شهادة المادة أو الاختبار أو الفحص أو التتبع أو اعتماد الطرف الثالث؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "standards-certification",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?

Ask in plain language: What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? Arabic draft: ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-installation-commissioning",
  "question_en": "What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required?",
  "question_ar": "ما الأساسات والرفع والإيقاف والربط والتركيب والتشغيل والتدريب المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "installation-commissioning",
  "order": 190,
  "confidence_contribution": 0.03
}
```

### Ask when What foundations, lifting, shutdown, tie-in, installation, commissioning and training scope is required? is missing

When the normalized field installation-commissioning is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-installation-commissioning",
  "priority": 981,
  "when": {
    "all": [
      {
        "field": "installation-commissioning",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-installation-commissioning"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What consumables, critical spares, maintenance interval, response time and lifecycle support are required?

Ask in plain language: What consumables, critical spares, maintenance interval, response time and lifecycle support are required? Arabic draft: ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-spares-service",
  "question_en": "What consumables, critical spares, maintenance interval, response time and lifecycle support are required?",
  "question_ar": "ما المستهلكات وقطع الغيار الحرجة وفترة الصيانة وزمن الاستجابة ودعم دورة الحياة؟",
  "expected_answer_type": "document_or_table",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "spares-service",
  "order": 200,
  "confidence_contribution": 0.012
}
```

### Please clarify the air demand/profile requirements for Air receivers.

Ask in plain language: Please clarify the air demand/profile requirements for Air receivers. Arabic draft: يرجى توضيح متطلبات air demand/profile الخاصة بـ Air receivers. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-facet-01",
  "question_en": "Please clarify the air demand/profile requirements for Air receivers.",
  "question_ar": "يرجى توضيح متطلبات air demand/profile الخاصة بـ Air receivers.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the air demand/profile requirements for Air receivers. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the pressure/quality requirements for Air receivers.

Ask in plain language: Please clarify the pressure/quality requirements for Air receivers. Arabic draft: يرجى توضيح متطلبات pressure/quality الخاصة بـ Air receivers. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-facet-02",
  "question_en": "Please clarify the pressure/quality requirements for Air receivers.",
  "question_ar": "يرجى توضيح متطلبات pressure/quality الخاصة بـ Air receivers.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the pressure/quality requirements for Air receivers. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the compressor technology requirements for Air receivers.

Ask in plain language: Please clarify the compressor technology requirements for Air receivers. Arabic draft: يرجى توضيح متطلبات compressor technology الخاصة بـ Air receivers. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-facet-03",
  "question_en": "Please clarify the compressor technology requirements for Air receivers.",
  "question_ar": "يرجى توضيح متطلبات compressor technology الخاصة بـ Air receivers.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the compressor technology requirements for Air receivers. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the power/cooling requirements for Air receivers.

Ask in plain language: Please clarify the power/cooling requirements for Air receivers. Arabic draft: يرجى توضيح متطلبات power/cooling الخاصة بـ Air receivers. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-facet-04",
  "question_en": "Please clarify the power/cooling requirements for Air receivers.",
  "question_ar": "يرجى توضيح متطلبات power/cooling الخاصة بـ Air receivers.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the receiver/dryer/filters requirements for Air receivers.

Ask in plain language: Please clarify the receiver/dryer/filters requirements for Air receivers. Arabic draft: يرجى توضيح متطلبات receiver/dryer/filters الخاصة بـ Air receivers. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-facet-05",
  "question_en": "Please clarify the receiver/dryer/filters requirements for Air receivers.",
  "question_ar": "يرجى توضيح متطلبات receiver/dryer/filters الخاصة بـ Air receivers.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the controls requirements for Air receivers.

Ask in plain language: Please clarify the controls requirements for Air receivers. Arabic draft: يرجى توضيح متطلبات controls الخاصة بـ Air receivers. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-facet-06",
  "question_en": "Please clarify the controls requirements for Air receivers.",
  "question_ar": "يرجى توضيح متطلبات controls الخاصة بـ Air receivers.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the maintenance requirements for Air receivers.

Ask in plain language: Please clarify the maintenance requirements for Air receivers. Arabic draft: يرجى توضيح متطلبات maintenance الخاصة بـ Air receivers. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-facet-07",
  "question_en": "Please clarify the maintenance requirements for Air receivers.",
  "question_ar": "يرجى توضيح متطلبات maintenance الخاصة بـ Air receivers.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact Air receivers product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Air receivers product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Air receivers التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-exact-subtype",
  "question_en": "Which exact Air receivers product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Air receivers التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Air receivers product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-039-air-receivers-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Air receivers are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Air receivers are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Air receivers التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-unknowns",
  "question_en": "Which details about Air receivers are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Air receivers التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Air receivers?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Air receivers? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Air receivers؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-039-air-receivers-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Air receivers?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Air receivers؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Air receivers, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Air receivers, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Air receivers, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Air receivers, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0186`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE, UAE-EAD, UAE-ADNOC-SUPPLIER, UAE-CUSTOMS, ISO-STANDARDS, IEC-STANDARDS, ASTM-STANDARDS

```json
{
  "rule_id": "R-039-air-receivers-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-MOIAT",
        "UAE-MOCCAE",
        "UAE-EAD",
        "UAE-ADNOC-SUPPLIER",
        "UAE-CUSTOMS",
        "ISO-STANDARDS",
        "IEC-STANDARDS",
        "ASTM-STANDARDS"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Air receivers, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Air receivers, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Air receivers, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Air receivers, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-039-air-receivers-inquiry_qualification-decision_rule-0190`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-039-air-receivers-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Air receivers, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-receivers-validation-validation_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-receivers-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Air receivers, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-receivers-validation-validation_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-receivers-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Air receivers, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-receivers-validation-validation_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-receivers-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Air receivers, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-receivers-validation-validation_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-receivers-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Air receivers, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-receivers-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-receivers-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Air receivers, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-receivers-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-receivers-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Air receivers, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-receivers-validation-validation_rule-0197`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-MOIAT, UAE-MOCCAE

```json
{
  "validation_id": "V-039-air-receivers-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Air receivers, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-receivers-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-receivers-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Air receivers, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-receivers-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-receivers-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Air receivers, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-039-air-receivers-validation-validation_rule-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-039-air-receivers-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Air receivers without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-receivers-scenario_test-scenario-0201`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-receivers-001",
  "setup": "Customer asks informally for Air receivers without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Air receivers with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-receivers-scenario_test-scenario-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-receivers-002",
  "setup": "Customer requests price for Air receivers with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Air receivers. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-receivers-scenario_test-scenario-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-receivers-003",
  "setup": "Customer uploads a relevant schedule/specification for Air receivers.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Air receivers. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-receivers-scenario_test-scenario-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-receivers-004",
  "setup": "Customer message and uploaded document disagree on Air receivers.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Air receivers. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-receivers-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-receivers-005",
  "setup": "Supplier proposes a different product, provider or method for Air receivers.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Air receivers sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-receivers-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-receivers-006",
  "setup": "Customer needs Air receivers sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Air receivers needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-039-air-receivers-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-039-air-receivers-007",
  "setup": "The request for Air receivers needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Air receivers

English term: Air receivers. Arabic operational draft: متطلبات Air receivers. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Air receivers",
  "term_ar": "متطلبات Air receivers",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### air demand/profile

English term: air demand/profile. Arabic operational draft: متطلبات air demand/profile. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "air demand/profile",
  "term_ar": "متطلبات air demand/profile",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### pressure/quality

English term: pressure/quality. Arabic operational draft: متطلبات pressure/quality. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "pressure/quality",
  "term_ar": "متطلبات pressure/quality",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### compressor technology

English term: compressor technology. Arabic operational draft: متطلبات compressor technology. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compressor technology",
  "term_ar": "متطلبات compressor technology",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### power/cooling

English term: power/cooling. Arabic operational draft: متطلبات power/cooling. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "power/cooling",
  "term_ar": "متطلبات power/cooling",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### receiver/dryer/filters

English term: receiver/dryer/filters. Arabic operational draft: متطلبات receiver/dryer/filters. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "receiver/dryer/filters",
  "term_ar": "متطلبات receiver/dryer/filters",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```

### controls

English term: controls. Arabic operational draft: متطلبات controls. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-039-air-receivers-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "controls",
  "term_ar": "متطلبات controls",
  "canonical_subcategory": "air-receivers",
  "normalization_only": true
}
```
