# Category 11 QA Report — Furniture, FF&E & Loose Items

**Build date:** 2026-07-31  
**Version:** 2026.07.31  
**Status:** research-complete production draft; **not SME approved**.

## Coverage

| Metric | Count |
|---|---:|
| Subcategories | 7 |
| Atomic records | 1,589 |
| Qualification questions | 203 |
| Decision rules | 161 |
| Validation rules | 70 |
| Scenario tests | 49 |
| Source records | 6 |
| Master characters | 1,623,052 |
| Master words | 185,943 |

## Automated checks

- JSON Schema validation: PASS for every atomic record.
- Duplicate record IDs: PASS.
- Source reference integrity: PASS.
- Every subcategory has industry, product/service, technical, supplier, quotation, document, regulation, inquiry, decision, validation, scenario and glossary records.
- Paid standards are referenced rather than reproduced.

## Module counts

```json
{
  "industry": 28,
  "products_services": 105,
  "technical": 119,
  "brands_manufacturers": 42,
  "supplier_ecosystem": 56,
  "supplier_eligibility": 56,
  "quotation": 70,
  "documents": 91,
  "uae_regulations": 42,
  "commercial_pricing": 70,
  "customer_tradeoffs": 70,
  "risk": 70,
  "best_practices": 42,
  "troubleshooting": 56,
  "inquiry_qualification": 364,
  "validation": 70,
  "scenario_test": 49,
  "glossary": 189
}
```

## Validation status

```json
{
  "source_verified": 133,
  "reviewed": 1414,
  "draft": 42
}
```

## Certification blockers

The open gaps in `20_gap_register.csv` remain mandatory. This package is designed for qualification and retrieval, not professional design, legal/tax/medical advice, authority approval or guaranteed market data.
