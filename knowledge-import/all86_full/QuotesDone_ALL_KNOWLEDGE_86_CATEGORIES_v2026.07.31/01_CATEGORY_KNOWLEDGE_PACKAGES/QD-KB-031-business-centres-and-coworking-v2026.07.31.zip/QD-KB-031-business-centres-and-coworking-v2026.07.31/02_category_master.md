# QuotesDone Knowledge Corpus — Category 31

## Business Centres & Coworking

**Arabic working title:** مراكز الأعمال والعمل المشترك
**Version:** 2026.07.31
**Status:** research-complete production draft; not SME approved
**Subcategories:** 4

## Runtime purpose

This corpus supports customer-language routing, adaptive qualification, supplier eligibility, document extraction, UAE source retrieval, comparable RFQ generation, risk control and escalation for Business Centres & Coworking. The large master file is for human audit. Runtime systems should use the atomic JSONL records, deterministic questions/rules and internal retrieval rather than placing this entire file in a model prompt.


# 1. Business centres

**Arabic draft:** متطلبات Business centres
**Slug:** `business-centres`
**Aliases:** Business centres

## Industry

### Industry scope — Business centres

Business centres is treated as a distinct procurement route within Business Centres & Coworking. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers regulated or advisory professional services, defined deliverables, evidence, responsibility and confidentiality. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-031-business-centres-industry-subcategory_overview-0001`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS

```json
{
  "category": "Business Centres & Coworking",
  "subcategory": "Business centres",
  "profile": "professional",
  "aliases": [
    "Business centres"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Business centres

A normal UAE sourcing workflow for Business centres moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-031-business-centres-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS, UAE-PDPL-45-2021

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Business centres

Customers may describe Business centres through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-031-business-centres-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Business centres

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-031-business-centres-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Business centres product or service

The primary deliverable requested within Business centres; exact type, quantity, performance, scope and acceptance must be normalized. For Business centres, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-business-centres-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Business centres",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Business centres

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Business centres, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-business-centres-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Business centres",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Business centres

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Business centres, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-business-centres-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Business centres",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Business centres

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Business centres, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-business-centres-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Business centres",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Business centres

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Business centres, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-business-centres-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Business centres",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Business centres

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Business centres, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-business-centres-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Business centres",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Business centres

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Business centres, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-business-centres-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Business centres",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Business centres

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Business centres, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-business-centres-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Business centres",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Location/Capacity scope component

Location/Capacity is a recurring scope component for Business centres. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-business-centres-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "location/capacity",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Workspace Type scope component

Workspace Type is a recurring scope component for Business centres. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-business-centres-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "workspace type",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Licence/Address Need scope component

Licence/Address Need is a recurring scope component for Business centres. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-business-centres-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "licence/address need",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Services/Meeting Rooms scope component

Services/Meeting Rooms is a recurring scope component for Business centres. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-business-centres-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "services/meeting rooms",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Access/Security scope component

Access/Security is a recurring scope component for Business centres. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-business-centres-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "access/security",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Commercial Terms scope component

Commercial Terms is a recurring scope component for Business centres. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-business-centres-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "commercial terms",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Support/Exit scope component

Support/Exit is a recurring scope component for Business centres. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-business-centres-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "support/exit",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: client/entity status

For Business centres, client/entity status must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "client/entity status",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: jurisdiction and regulator

For Business centres, jurisdiction and regulator must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "jurisdiction and regulator",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: problem and desired outcome

For Business centres, problem and desired outcome must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "problem and desired outcome",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: scope boundaries

For Business centres, scope boundaries must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "scope boundaries",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: inputs and evidence

For Business centres, inputs and evidence must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "inputs and evidence",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: methodology and standards

For Business centres, methodology and standards must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "methodology and standards",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: deliverables

For Business centres, deliverables must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "deliverables",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: timeline and dependencies

For Business centres, timeline and dependencies must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "timeline and dependencies",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: professional responsibility

For Business centres, professional responsibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "professional responsibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: fees and change control

For Business centres, fees and change control must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "fees and change control",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: location/capacity

For Business centres, location/capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "location/capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: workspace type

For Business centres, workspace type must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "workspace type",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: licence/address need

For Business centres, licence/address need must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "licence/address need",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: services/meeting rooms

For Business centres, services/meeting rooms must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "services/meeting rooms",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: access/security

For Business centres, access/security must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "access/security",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: commercial terms

For Business centres, commercial terms must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "commercial terms",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: support/exit

For Business centres, support/exit must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-business-centres-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "support/exit",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: licensed professional firm

A licensed professional firm may be relevant to Business centres depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-business-centres-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "licensed professional firm",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: specialist consultancy

A specialist consultancy may be relevant to Business centres depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-business-centres-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "specialist consultancy",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: registered agent or service provider

A registered agent or service provider may be relevant to Business centres depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-business-centres-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "registered agent or service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: independent expert

A independent expert may be relevant to Business centres depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-business-centres-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "independent expert",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: outsourced managed-service provider

A outsourced managed-service provider may be relevant to Business centres depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-business-centres-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "outsourced managed-service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: training provider

A training provider may be relevant to Business centres depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-business-centres-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "training provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — licensed professional firm

This supplier type can participate in Business centres only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-business-centres-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "licensed professional firm",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — specialist consultancy

This supplier type can participate in Business centres only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-business-centres-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "specialist consultancy",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — registered agent or service provider

This supplier type can participate in Business centres only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-business-centres-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "registered agent or service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — independent expert

This supplier type can participate in Business centres only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-business-centres-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "independent expert",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — outsourced managed-service provider

This supplier type can participate in Business centres only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-business-centres-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "outsourced managed-service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — training provider

This supplier type can participate in Business centres only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-business-centres-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "training provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — audit/assurance provider

This supplier type can participate in Business centres only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-business-centres-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "audit/assurance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — legal/compliance reviewer

This supplier type can participate in Business centres only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-business-centres-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "legal/compliance reviewer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — licensed professional firm

Before routing a Business centres inquiry to a licensed professional firm, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-business-centres-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "licensed professional firm",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — specialist consultancy

Before routing a Business centres inquiry to a specialist consultancy, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-business-centres-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "specialist consultancy",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — registered agent or service provider

Before routing a Business centres inquiry to a registered agent or service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-business-centres-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "registered agent or service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — independent expert

Before routing a Business centres inquiry to a independent expert, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-business-centres-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "independent expert",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — outsourced managed-service provider

Before routing a Business centres inquiry to a outsourced managed-service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-business-centres-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "outsourced managed-service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — training provider

Before routing a Business centres inquiry to a training provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-business-centres-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "training provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — audit/assurance provider

Before routing a Business centres inquiry to a audit/assurance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-business-centres-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "audit/assurance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — legal/compliance reviewer

Before routing a Business centres inquiry to a legal/compliance reviewer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-business-centres-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "legal/compliance reviewer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Business centres should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-business-centres-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Business centres should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-business-centres-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Business centres should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-business-centres-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Business centres should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-business-centres-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Business centres should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-business-centres-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Business centres should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-business-centres-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Business centres should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-business-centres-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Business centres should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-business-centres-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Business centres should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-business-centres-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Business centres should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-business-centres-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Client Brief

Client Brief may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "client-brief",
  "document_name": "client brief",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Entity/Licence Documents

Entity/Licence Documents may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "entity-licence-documents",
  "document_name": "entity/licence documents",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Engagement Letter

Engagement Letter may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "engagement-letter",
  "document_name": "engagement letter",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Scope And Deliverables Schedule

Scope And Deliverables Schedule may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "scope-and-deliverables-schedule",
  "document_name": "scope and deliverables schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Evidence/Data Request List

Evidence/Data Request List may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "evidence-data-request-list",
  "document_name": "evidence/data request list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Conflict Check

Conflict Check may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "conflict-check",
  "document_name": "conflict check",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Nda/Confidentiality Terms

Nda/Confidentiality Terms may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "nda-confidentiality-terms",
  "document_name": "NDA/confidentiality terms",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Methodology/Work Plan

Methodology/Work Plan may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "methodology-work-plan",
  "document_name": "methodology/work plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Milestone Schedule

Milestone Schedule may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "milestone-schedule",
  "document_name": "milestone schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Fee Proposal

Fee Proposal may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "fee-proposal",
  "document_name": "fee proposal",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Regulatory Correspondence

Regulatory Correspondence may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "regulatory-correspondence",
  "document_name": "regulatory correspondence",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Draft/Final Report

Draft/Final Report may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "draft-final-report",
  "document_name": "draft/final report",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Sign-Off/Acceptance

Sign-Off/Acceptance may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "sign-off-acceptance",
  "document_name": "sign-off/acceptance",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Change Request

Change Request may provide or verify information needed for Business centres. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-business-centres-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "change-request",
  "document_name": "change request",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Federal Decree-Law on Commercial Companies

For Business centres, consult Federal Decree-Law on Commercial Companies when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-COMMERCIAL-COMPANIES

```json
{
  "source_id": "UAE-COMMERCIAL-COMPANIES",
  "publisher": "UAE Legislation",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law No. 50 of 2022 on Commercial Transactions

For Business centres, consult Federal Decree-Law No. 50 of 2022 on Commercial Transactions when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "source_id": "UAE-COMMERCIAL-TRANSACTIONS",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law on Electronic Transactions and Trust Services

For Business centres, consult Federal Decree-Law on Electronic Transactions and Trust Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ELECTRONIC-TRANSACTIONS

```json
{
  "source_id": "UAE-ELECTRONIC-TRANSACTIONS",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

For Business centres, consult Federal Decree-Law No. 45 of 2021 on Protection of Personal Data when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021

```json
{
  "source_id": "UAE-PDPL-45-2021",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Consumer Protection Legislation

For Business centres, consult UAE Consumer Protection Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION

```json
{
  "source_id": "UAE-CONSUMER-PROTECTION",
  "publisher": "UAE Legislation / Ministry of Economy",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### MOHRE Services, Labour Guidance and Establishment Requirements

For Business centres, consult MOHRE Services, Labour Guidance and Establishment Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOHRE

```json
{
  "source_id": "UAE-MOHRE",
  "publisher": "Ministry of Human Resources and Emiratisation",
  "source_type": "government_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### VAT Guides and Legislation

For Business centres, consult VAT Guides and Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-FTA-VAT

```json
{
  "source_id": "UAE-FTA-VAT",
  "publisher": "Federal Tax Authority",
  "source_type": "tax_authority_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Corporate Tax Guides and Legislation

For Business centres, consult Corporate Tax Guides and Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-FTA-CT

```json
{
  "source_id": "UAE-FTA-CT",
  "publisher": "Federal Tax Authority",
  "source_type": "tax_authority_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Ministry of Justice Legal, Notary and Attestation Services

For Business centres, consult Ministry of Justice Legal, Notary and Attestation Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOJ

```json
{
  "source_id": "UAE-MOJ",
  "publisher": "UAE Ministry of Justice",
  "source_type": "government_legal_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Intellectual Property and Trademark Services

For Business centres, consult Intellectual Property and Trademark Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0092`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOE-IP

```json
{
  "source_id": "UAE-MOE-IP",
  "publisher": "UAE Ministry of Economy",
  "source_type": "government_ip_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Business and Event Licensing Services

For Business centres, consult Dubai Business and Event Licensing Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0093`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DET-EVENTS

```json
{
  "source_id": "UAE-DET-EVENTS",
  "publisher": "Dubai Department of Economy and Tourism",
  "source_type": "government_business_events_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Building Code 2021

For Business centres, consult Dubai Building Code 2021 when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-business-centres-uae_regulations-source_activation-0094`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-DBC-2021

```json
{
  "source_id": "UAE-DM-DBC-2021",
  "publisher": "Dubai Municipality",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Business centres. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-business-centres-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Business centres. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-business-centres-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Business centres. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-business-centres-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Business centres. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-business-centres-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Business centres. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-business-centres-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Business centres. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-business-centres-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Business centres. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-business-centres-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Business centres. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-business-centres-commercial_pricing-cost_driver-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Business centres. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-business-centres-commercial_pricing-cost_driver-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Business centres. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-business-centres-commercial_pricing-cost_driver-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-business-centres-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-business-centres-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-business-centres-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-business-centres-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-business-centres-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-business-centres-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-business-centres-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-business-centres-customer_tradeoffs-tradeoff-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-business-centres-customer_tradeoffs-tradeoff-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-business-centres-customer_tradeoffs-tradeoff-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Business centres, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-business-centres-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Business centres, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-business-centres-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Business centres, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-business-centres-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Business centres, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-business-centres-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Business centres, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-business-centres-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Business centres, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-business-centres-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Business centres, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-business-centres-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Business centres, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-business-centres-risk-risk_control-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Business centres, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-business-centres-risk-risk_control-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Business centres, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-business-centres-risk-risk_control-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Business centres, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-business-centres-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Business centres, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-business-centres-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Business centres, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-business-centres-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Business centres, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-business-centres-best_practices-qualification_best_practice-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Business centres, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-business-centres-best_practices-qualification_best_practice-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Business centres, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-business-centres-best_practices-qualification_best_practice-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Business centres; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-business-centres-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Business centres; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-business-centres-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Business centres; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-business-centres-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Business centres; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-business-centres-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Business centres; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-business-centres-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Business centres; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-business-centres-troubleshooting-recovery_guidance-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Business centres; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-business-centres-troubleshooting-recovery_guidance-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Business centres; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-business-centres-troubleshooting-recovery_guidance-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What client entity, ownership, licence, jurisdiction and operating activity are involved?

Ask in plain language: What client entity, ownership, licence, jurisdiction and operating activity are involved? Arabic draft: ما جهة العميل والملكية والترخيص والاختصاص والنشاط التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-client-entity",
  "question_en": "What client entity, ownership, licence, jurisdiction and operating activity are involved?",
  "question_ar": "ما جهة العميل والملكية والترخيص والاختصاص والنشاط التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "client-entity",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What client entity, ownership, licence, jurisdiction and operating activity are involved? is missing

When the normalized field client-entity is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-client-entity",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "client-entity",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-client-entity"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What decision, problem, transaction, compliance outcome or business objective is required?

Ask in plain language: What decision, problem, transaction, compliance outcome or business objective is required? Arabic draft: ما القرار أو المشكلة أو المعاملة أو نتيجة الامتثال أو الهدف التجاري المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-problem-outcome",
  "question_en": "What decision, problem, transaction, compliance outcome or business objective is required?",
  "question_ar": "ما القرار أو المشكلة أو المعاملة أو نتيجة الامتثال أو الهدف التجاري المطلوب؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "problem-outcome",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What decision, problem, transaction, compliance outcome or business objective is required? is missing

When the normalized field problem-outcome is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-problem-outcome",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "problem-outcome",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-problem-outcome"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What work is included, excluded, assumed or dependent on third parties?

Ask in plain language: What work is included, excluded, assumed or dependent on third parties? Arabic draft: ما الأعمال المشمولة والمستبعدة والافتراضات والاعتماد على أطراف أخرى؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-scope-exclusions",
  "question_en": "What work is included, excluded, assumed or dependent on third parties?",
  "question_ar": "ما الأعمال المشمولة والمستبعدة والافتراضات والاعتماد على أطراف أخرى؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-exclusions",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What work is included, excluded, assumed or dependent on third parties? is missing

When the normalized field scope-exclusions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-scope-exclusions",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "scope-exclusions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-scope-exclusions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What records, contracts, accounts, data, correspondence or evidence are available?

Ask in plain language: What records, contracts, accounts, data, correspondence or evidence are available? Arabic draft: ما السجلات أو العقود أو الحسابات أو البيانات أو المراسلات أو الأدلة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-records-evidence",
  "question_en": "What records, contracts, accounts, data, correspondence or evidence are available?",
  "question_ar": "ما السجلات أو العقود أو الحسابات أو البيانات أو المراسلات أو الأدلة المتاحة؟",
  "expected_answer_type": "document_list",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "records-evidence",
  "order": 160,
  "confidence_contribution": 0.03
}
```

### Ask when What records, contracts, accounts, data, correspondence or evidence are available? is missing

When the normalized field records-evidence is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-records-evidence",
  "priority": 984,
  "when": {
    "all": [
      {
        "field": "records-evidence",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-records-evidence"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What deliverables, language, format, review cycle and sign-off are required?

Ask in plain language: What deliverables, language, format, review cycle and sign-off are required? Arabic draft: ما المخرجات واللغة والصيغة ودورة المراجعة والتوقيع المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-deliverables-format",
  "question_en": "What deliverables, language, format, review cycle and sign-off are required?",
  "question_ar": "ما المخرجات واللغة والصيغة ودورة المراجعة والتوقيع المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "deliverables-format",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What deliverables, language, format, review cycle and sign-off are required? is missing

When the normalized field deliverables-format is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-deliverables-format",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "deliverables-format",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-deliverables-format"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which regulator, court, authority, bank, investor or deadline controls the work?

Ask in plain language: Which regulator, court, authority, bank, investor or deadline controls the work? Arabic draft: ما الجهة التنظيمية أو المحكمة أو السلطة أو البنك أو المستثمر أو الموعد الحاكم؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-regulator-deadline",
  "question_en": "Which regulator, court, authority, bank, investor or deadline controls the work?",
  "question_ar": "ما الجهة التنظيمية أو المحكمة أو السلطة أو البنك أو المستثمر أو الموعد الحاكم؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "regulator-deadline",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What conflict checks, confidentiality, privilege, data access and retention rules apply?

Ask in plain language: What conflict checks, confidentiality, privilege, data access and retention rules apply? Arabic draft: ما فحوص التعارض والسرية والامتياز والوصول للبيانات والاحتفاظ؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-conflict-confidentiality",
  "question_en": "What conflict checks, confidentiality, privilege, data access and retention rules apply?",
  "question_ar": "ما فحوص التعارض والسرية والامتياز والوصول للبيانات والاحتفاظ؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "conflict-confidentiality",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### What fee model, expenses, assumptions, milestones, retainer and change-control basis apply?

Ask in plain language: What fee model, expenses, assumptions, milestones, retainer and change-control basis apply? Arabic draft: ما نموذج الأتعاب والمصروفات والافتراضات والمراحل والدفعة والتغيير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-fee-model",
  "question_en": "What fee model, expenses, assumptions, milestones, retainer and change-control basis apply?",
  "question_ar": "ما نموذج الأتعاب والمصروفات والافتراضات والمراحل والدفعة والتغيير؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "fee-model",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when What fee model, expenses, assumptions, milestones, retainer and change-control basis apply? is missing

When the normalized field fee-model is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-fee-model",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "fee-model",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-fee-model"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the location/capacity requirements for Business centres.

Ask in plain language: Please clarify the location/capacity requirements for Business centres. Arabic draft: يرجى توضيح متطلبات location/capacity الخاصة بـ Business centres. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-facet-01",
  "question_en": "Please clarify the location/capacity requirements for Business centres.",
  "question_ar": "يرجى توضيح متطلبات location/capacity الخاصة بـ Business centres.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the location/capacity requirements for Business centres. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the workspace type requirements for Business centres.

Ask in plain language: Please clarify the workspace type requirements for Business centres. Arabic draft: يرجى توضيح متطلبات workspace type الخاصة بـ Business centres. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-facet-02",
  "question_en": "Please clarify the workspace type requirements for Business centres.",
  "question_ar": "يرجى توضيح متطلبات workspace type الخاصة بـ Business centres.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the workspace type requirements for Business centres. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the licence/address need requirements for Business centres.

Ask in plain language: Please clarify the licence/address need requirements for Business centres. Arabic draft: يرجى توضيح متطلبات licence/address need الخاصة بـ Business centres. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-facet-03",
  "question_en": "Please clarify the licence/address need requirements for Business centres.",
  "question_ar": "يرجى توضيح متطلبات licence/address need الخاصة بـ Business centres.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the licence/address need requirements for Business centres. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the services/meeting rooms requirements for Business centres.

Ask in plain language: Please clarify the services/meeting rooms requirements for Business centres. Arabic draft: يرجى توضيح متطلبات services/meeting rooms الخاصة بـ Business centres. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-facet-04",
  "question_en": "Please clarify the services/meeting rooms requirements for Business centres.",
  "question_ar": "يرجى توضيح متطلبات services/meeting rooms الخاصة بـ Business centres.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the access/security requirements for Business centres.

Ask in plain language: Please clarify the access/security requirements for Business centres. Arabic draft: يرجى توضيح متطلبات access/security الخاصة بـ Business centres. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-facet-05",
  "question_en": "Please clarify the access/security requirements for Business centres.",
  "question_ar": "يرجى توضيح متطلبات access/security الخاصة بـ Business centres.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the commercial terms requirements for Business centres.

Ask in plain language: Please clarify the commercial terms requirements for Business centres. Arabic draft: يرجى توضيح متطلبات commercial terms الخاصة بـ Business centres. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-facet-06",
  "question_en": "Please clarify the commercial terms requirements for Business centres.",
  "question_ar": "يرجى توضيح متطلبات commercial terms الخاصة بـ Business centres.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the support/exit requirements for Business centres.

Ask in plain language: Please clarify the support/exit requirements for Business centres. Arabic draft: يرجى توضيح متطلبات support/exit الخاصة بـ Business centres. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-facet-07",
  "question_en": "Please clarify the support/exit requirements for Business centres.",
  "question_ar": "يرجى توضيح متطلبات support/exit الخاصة بـ Business centres.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact Business centres product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Business centres product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Business centres التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-exact-subtype",
  "question_en": "Which exact Business centres product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Business centres التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Business centres product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-business-centres-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Business centres are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Business centres are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Business centres التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-unknowns",
  "question_en": "Which details about Business centres are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Business centres التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Business centres?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Business centres? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Business centres؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-qualification_question-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-business-centres-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Business centres?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Business centres؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Business centres, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Business centres, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Business centres, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Business centres, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0190`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION, UAE-MOHRE, UAE-FTA-VAT, UAE-FTA-CT, UAE-MOJ, UAE-MOE-IP, UAE-DET-EVENTS, UAE-DM-DBC-2021

```json
{
  "rule_id": "R-031-business-centres-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-COMMERCIAL-COMPANIES",
        "UAE-COMMERCIAL-TRANSACTIONS",
        "UAE-ELECTRONIC-TRANSACTIONS",
        "UAE-PDPL-45-2021",
        "UAE-CONSUMER-PROTECTION",
        "UAE-MOHRE",
        "UAE-FTA-VAT",
        "UAE-FTA-CT",
        "UAE-MOJ",
        "UAE-MOE-IP",
        "UAE-DET-EVENTS",
        "UAE-DM-DBC-2021"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Business centres, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Business centres, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Business centres, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Business centres, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-business-centres-inquiry_qualification-decision_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-business-centres-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Business centres, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-business-centres-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-business-centres-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Business centres, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-business-centres-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-business-centres-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Business centres, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-business-centres-validation-validation_rule-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-business-centres-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Business centres, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-business-centres-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-business-centres-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Business centres, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-business-centres-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-business-centres-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Business centres, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-business-centres-validation-validation_rule-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-business-centres-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Business centres, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-business-centres-validation-validation_rule-0201`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "validation_id": "V-031-business-centres-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Business centres, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-business-centres-validation-validation_rule-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-business-centres-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Business centres, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-business-centres-validation-validation_rule-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-business-centres-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Business centres, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-business-centres-validation-validation_rule-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-business-centres-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Business centres without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-business-centres-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-business-centres-001",
  "setup": "Customer asks informally for Business centres without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Business centres with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-business-centres-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-business-centres-002",
  "setup": "Customer requests price for Business centres with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Business centres. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-business-centres-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-business-centres-003",
  "setup": "Customer uploads a relevant schedule/specification for Business centres.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Business centres. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-business-centres-scenario_test-scenario-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-business-centres-004",
  "setup": "Customer message and uploaded document disagree on Business centres.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Business centres. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-business-centres-scenario_test-scenario-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-business-centres-005",
  "setup": "Supplier proposes a different product, provider or method for Business centres.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Business centres sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-business-centres-scenario_test-scenario-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-business-centres-006",
  "setup": "Customer needs Business centres sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Business centres needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-business-centres-scenario_test-scenario-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-business-centres-007",
  "setup": "The request for Business centres needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Business centres

English term: Business centres. Arabic operational draft: متطلبات Business centres. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Business centres",
  "term_ar": "متطلبات Business centres",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### location/capacity

English term: location/capacity. Arabic operational draft: متطلبات location/capacity. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "location/capacity",
  "term_ar": "متطلبات location/capacity",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### workspace type

English term: workspace type. Arabic operational draft: متطلبات workspace type. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "workspace type",
  "term_ar": "متطلبات workspace type",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### licence/address need

English term: licence/address need. Arabic operational draft: متطلبات licence/address need. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0234`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "licence/address need",
  "term_ar": "متطلبات licence/address need",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### services/meeting rooms

English term: services/meeting rooms. Arabic operational draft: متطلبات services/meeting rooms. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0235`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "services/meeting rooms",
  "term_ar": "متطلبات services/meeting rooms",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### access/security

English term: access/security. Arabic operational draft: متطلبات access/security. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0236`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "access/security",
  "term_ar": "متطلبات access/security",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### commercial terms

English term: commercial terms. Arabic operational draft: متطلبات commercial terms. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0237`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial terms",
  "term_ar": "متطلبات commercial terms",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```

### support/exit

English term: support/exit. Arabic operational draft: متطلبات support/exit. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-business-centres-glossary-bilingual_term-0238`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "support/exit",
  "term_ar": "متطلبات support/exit",
  "canonical_subcategory": "business-centres",
  "normalization_only": true
}
```


# 2. Coworking spaces

**Arabic draft:** متطلبات Coworking spaces
**Slug:** `coworking-spaces`
**Aliases:** Coworking spaces

## Industry

### Industry scope — Coworking spaces

Coworking spaces is treated as a distinct procurement route within Business Centres & Coworking. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers regulated or advisory professional services, defined deliverables, evidence, responsibility and confidentiality. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-031-coworking-spaces-industry-subcategory_overview-0001`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS

```json
{
  "category": "Business Centres & Coworking",
  "subcategory": "Coworking spaces",
  "profile": "professional",
  "aliases": [
    "Coworking spaces"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Coworking spaces

A normal UAE sourcing workflow for Coworking spaces moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-031-coworking-spaces-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS, UAE-PDPL-45-2021

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Coworking spaces

Customers may describe Coworking spaces through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-031-coworking-spaces-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Coworking spaces

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-031-coworking-spaces-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Coworking spaces product or service

The primary deliverable requested within Coworking spaces; exact type, quantity, performance, scope and acceptance must be normalized. For Coworking spaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-coworking-spaces-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Coworking spaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Coworking spaces

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Coworking spaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-coworking-spaces-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Coworking spaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Coworking spaces

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Coworking spaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-coworking-spaces-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Coworking spaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Coworking spaces

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Coworking spaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-coworking-spaces-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Coworking spaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Coworking spaces

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Coworking spaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-coworking-spaces-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Coworking spaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Coworking spaces

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Coworking spaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-coworking-spaces-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Coworking spaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Coworking spaces

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Coworking spaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-coworking-spaces-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Coworking spaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Coworking spaces

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Coworking spaces, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-coworking-spaces-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Coworking spaces",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Location/Capacity scope component

Location/Capacity is a recurring scope component for Coworking spaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-coworking-spaces-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "location/capacity",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Workspace Type scope component

Workspace Type is a recurring scope component for Coworking spaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-coworking-spaces-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "workspace type",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Licence/Address Need scope component

Licence/Address Need is a recurring scope component for Coworking spaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-coworking-spaces-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "licence/address need",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Services/Meeting Rooms scope component

Services/Meeting Rooms is a recurring scope component for Coworking spaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-coworking-spaces-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "services/meeting rooms",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Access/Security scope component

Access/Security is a recurring scope component for Coworking spaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-coworking-spaces-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "access/security",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Commercial Terms scope component

Commercial Terms is a recurring scope component for Coworking spaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-coworking-spaces-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "commercial terms",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Support/Exit scope component

Support/Exit is a recurring scope component for Coworking spaces. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-coworking-spaces-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "support/exit",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: client/entity status

For Coworking spaces, client/entity status must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "client/entity status",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: jurisdiction and regulator

For Coworking spaces, jurisdiction and regulator must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "jurisdiction and regulator",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: problem and desired outcome

For Coworking spaces, problem and desired outcome must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "problem and desired outcome",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: scope boundaries

For Coworking spaces, scope boundaries must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "scope boundaries",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: inputs and evidence

For Coworking spaces, inputs and evidence must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "inputs and evidence",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: methodology and standards

For Coworking spaces, methodology and standards must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "methodology and standards",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: deliverables

For Coworking spaces, deliverables must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "deliverables",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: timeline and dependencies

For Coworking spaces, timeline and dependencies must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "timeline and dependencies",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: professional responsibility

For Coworking spaces, professional responsibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "professional responsibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: fees and change control

For Coworking spaces, fees and change control must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "fees and change control",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: location/capacity

For Coworking spaces, location/capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "location/capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: workspace type

For Coworking spaces, workspace type must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "workspace type",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: licence/address need

For Coworking spaces, licence/address need must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "licence/address need",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: services/meeting rooms

For Coworking spaces, services/meeting rooms must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "services/meeting rooms",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: access/security

For Coworking spaces, access/security must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "access/security",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: commercial terms

For Coworking spaces, commercial terms must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "commercial terms",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: support/exit

For Coworking spaces, support/exit must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-coworking-spaces-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "support/exit",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: licensed professional firm

A licensed professional firm may be relevant to Coworking spaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-coworking-spaces-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "licensed professional firm",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: specialist consultancy

A specialist consultancy may be relevant to Coworking spaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-coworking-spaces-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "specialist consultancy",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: registered agent or service provider

A registered agent or service provider may be relevant to Coworking spaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-coworking-spaces-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "registered agent or service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: independent expert

A independent expert may be relevant to Coworking spaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-coworking-spaces-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "independent expert",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: outsourced managed-service provider

A outsourced managed-service provider may be relevant to Coworking spaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-coworking-spaces-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "outsourced managed-service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: training provider

A training provider may be relevant to Coworking spaces depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-coworking-spaces-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "training provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — licensed professional firm

This supplier type can participate in Coworking spaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-coworking-spaces-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "licensed professional firm",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — specialist consultancy

This supplier type can participate in Coworking spaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-coworking-spaces-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "specialist consultancy",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — registered agent or service provider

This supplier type can participate in Coworking spaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-coworking-spaces-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "registered agent or service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — independent expert

This supplier type can participate in Coworking spaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-coworking-spaces-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "independent expert",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — outsourced managed-service provider

This supplier type can participate in Coworking spaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-coworking-spaces-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "outsourced managed-service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — training provider

This supplier type can participate in Coworking spaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-coworking-spaces-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "training provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — audit/assurance provider

This supplier type can participate in Coworking spaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-coworking-spaces-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "audit/assurance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — legal/compliance reviewer

This supplier type can participate in Coworking spaces only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-coworking-spaces-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "legal/compliance reviewer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — licensed professional firm

Before routing a Coworking spaces inquiry to a licensed professional firm, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-coworking-spaces-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "licensed professional firm",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — specialist consultancy

Before routing a Coworking spaces inquiry to a specialist consultancy, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-coworking-spaces-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "specialist consultancy",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — registered agent or service provider

Before routing a Coworking spaces inquiry to a registered agent or service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-coworking-spaces-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "registered agent or service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — independent expert

Before routing a Coworking spaces inquiry to a independent expert, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-coworking-spaces-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "independent expert",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — outsourced managed-service provider

Before routing a Coworking spaces inquiry to a outsourced managed-service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-coworking-spaces-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "outsourced managed-service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — training provider

Before routing a Coworking spaces inquiry to a training provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-coworking-spaces-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "training provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — audit/assurance provider

Before routing a Coworking spaces inquiry to a audit/assurance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-coworking-spaces-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "audit/assurance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — legal/compliance reviewer

Before routing a Coworking spaces inquiry to a legal/compliance reviewer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-coworking-spaces-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "legal/compliance reviewer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Coworking spaces should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-coworking-spaces-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Coworking spaces should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-coworking-spaces-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Coworking spaces should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-coworking-spaces-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Coworking spaces should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-coworking-spaces-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Coworking spaces should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-coworking-spaces-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Coworking spaces should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-coworking-spaces-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Coworking spaces should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-coworking-spaces-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Coworking spaces should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-coworking-spaces-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Coworking spaces should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-coworking-spaces-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Coworking spaces should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-coworking-spaces-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Client Brief

Client Brief may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "client-brief",
  "document_name": "client brief",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Entity/Licence Documents

Entity/Licence Documents may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "entity-licence-documents",
  "document_name": "entity/licence documents",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Engagement Letter

Engagement Letter may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "engagement-letter",
  "document_name": "engagement letter",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Scope And Deliverables Schedule

Scope And Deliverables Schedule may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "scope-and-deliverables-schedule",
  "document_name": "scope and deliverables schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Evidence/Data Request List

Evidence/Data Request List may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "evidence-data-request-list",
  "document_name": "evidence/data request list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Conflict Check

Conflict Check may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "conflict-check",
  "document_name": "conflict check",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Nda/Confidentiality Terms

Nda/Confidentiality Terms may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "nda-confidentiality-terms",
  "document_name": "NDA/confidentiality terms",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Methodology/Work Plan

Methodology/Work Plan may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "methodology-work-plan",
  "document_name": "methodology/work plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Milestone Schedule

Milestone Schedule may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "milestone-schedule",
  "document_name": "milestone schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Fee Proposal

Fee Proposal may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "fee-proposal",
  "document_name": "fee proposal",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Regulatory Correspondence

Regulatory Correspondence may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "regulatory-correspondence",
  "document_name": "regulatory correspondence",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Draft/Final Report

Draft/Final Report may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "draft-final-report",
  "document_name": "draft/final report",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Sign-Off/Acceptance

Sign-Off/Acceptance may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "sign-off-acceptance",
  "document_name": "sign-off/acceptance",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Change Request

Change Request may provide or verify information needed for Coworking spaces. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-coworking-spaces-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "change-request",
  "document_name": "change request",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Federal Decree-Law on Commercial Companies

For Coworking spaces, consult Federal Decree-Law on Commercial Companies when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-COMMERCIAL-COMPANIES

```json
{
  "source_id": "UAE-COMMERCIAL-COMPANIES",
  "publisher": "UAE Legislation",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law No. 50 of 2022 on Commercial Transactions

For Coworking spaces, consult Federal Decree-Law No. 50 of 2022 on Commercial Transactions when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "source_id": "UAE-COMMERCIAL-TRANSACTIONS",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law on Electronic Transactions and Trust Services

For Coworking spaces, consult Federal Decree-Law on Electronic Transactions and Trust Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ELECTRONIC-TRANSACTIONS

```json
{
  "source_id": "UAE-ELECTRONIC-TRANSACTIONS",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

For Coworking spaces, consult Federal Decree-Law No. 45 of 2021 on Protection of Personal Data when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021

```json
{
  "source_id": "UAE-PDPL-45-2021",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Consumer Protection Legislation

For Coworking spaces, consult UAE Consumer Protection Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION

```json
{
  "source_id": "UAE-CONSUMER-PROTECTION",
  "publisher": "UAE Legislation / Ministry of Economy",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### MOHRE Services, Labour Guidance and Establishment Requirements

For Coworking spaces, consult MOHRE Services, Labour Guidance and Establishment Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOHRE

```json
{
  "source_id": "UAE-MOHRE",
  "publisher": "Ministry of Human Resources and Emiratisation",
  "source_type": "government_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### VAT Guides and Legislation

For Coworking spaces, consult VAT Guides and Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-FTA-VAT

```json
{
  "source_id": "UAE-FTA-VAT",
  "publisher": "Federal Tax Authority",
  "source_type": "tax_authority_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Corporate Tax Guides and Legislation

For Coworking spaces, consult Corporate Tax Guides and Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-FTA-CT

```json
{
  "source_id": "UAE-FTA-CT",
  "publisher": "Federal Tax Authority",
  "source_type": "tax_authority_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Ministry of Justice Legal, Notary and Attestation Services

For Coworking spaces, consult Ministry of Justice Legal, Notary and Attestation Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOJ

```json
{
  "source_id": "UAE-MOJ",
  "publisher": "UAE Ministry of Justice",
  "source_type": "government_legal_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Intellectual Property and Trademark Services

For Coworking spaces, consult Intellectual Property and Trademark Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0092`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOE-IP

```json
{
  "source_id": "UAE-MOE-IP",
  "publisher": "UAE Ministry of Economy",
  "source_type": "government_ip_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Business and Event Licensing Services

For Coworking spaces, consult Dubai Business and Event Licensing Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0093`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DET-EVENTS

```json
{
  "source_id": "UAE-DET-EVENTS",
  "publisher": "Dubai Department of Economy and Tourism",
  "source_type": "government_business_events_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Building Code 2021

For Coworking spaces, consult Dubai Building Code 2021 when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-coworking-spaces-uae_regulations-source_activation-0094`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-DBC-2021

```json
{
  "source_id": "UAE-DM-DBC-2021",
  "publisher": "Dubai Municipality",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Coworking spaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-coworking-spaces-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Coworking spaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-coworking-spaces-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Coworking spaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-coworking-spaces-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Coworking spaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-coworking-spaces-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Coworking spaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-coworking-spaces-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Coworking spaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-coworking-spaces-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Coworking spaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-coworking-spaces-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Coworking spaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-coworking-spaces-commercial_pricing-cost_driver-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Coworking spaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-coworking-spaces-commercial_pricing-cost_driver-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Coworking spaces. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-coworking-spaces-commercial_pricing-cost_driver-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-coworking-spaces-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-coworking-spaces-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-coworking-spaces-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-coworking-spaces-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-coworking-spaces-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-coworking-spaces-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-coworking-spaces-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-coworking-spaces-customer_tradeoffs-tradeoff-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-coworking-spaces-customer_tradeoffs-tradeoff-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-coworking-spaces-customer_tradeoffs-tradeoff-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Coworking spaces, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-coworking-spaces-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Coworking spaces, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-coworking-spaces-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Coworking spaces, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-coworking-spaces-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Coworking spaces, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-coworking-spaces-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Coworking spaces, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-coworking-spaces-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Coworking spaces, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-coworking-spaces-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Coworking spaces, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-coworking-spaces-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Coworking spaces, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-coworking-spaces-risk-risk_control-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Coworking spaces, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-coworking-spaces-risk-risk_control-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Coworking spaces, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-coworking-spaces-risk-risk_control-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Coworking spaces, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-coworking-spaces-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Coworking spaces, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-coworking-spaces-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Coworking spaces, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-coworking-spaces-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Coworking spaces, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-coworking-spaces-best_practices-qualification_best_practice-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Coworking spaces, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-coworking-spaces-best_practices-qualification_best_practice-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Coworking spaces, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-coworking-spaces-best_practices-qualification_best_practice-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Coworking spaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-coworking-spaces-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Coworking spaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-coworking-spaces-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Coworking spaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-coworking-spaces-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Coworking spaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-coworking-spaces-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Coworking spaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-coworking-spaces-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Coworking spaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-coworking-spaces-troubleshooting-recovery_guidance-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Coworking spaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-coworking-spaces-troubleshooting-recovery_guidance-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Coworking spaces; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-coworking-spaces-troubleshooting-recovery_guidance-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What client entity, ownership, licence, jurisdiction and operating activity are involved?

Ask in plain language: What client entity, ownership, licence, jurisdiction and operating activity are involved? Arabic draft: ما جهة العميل والملكية والترخيص والاختصاص والنشاط التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-client-entity",
  "question_en": "What client entity, ownership, licence, jurisdiction and operating activity are involved?",
  "question_ar": "ما جهة العميل والملكية والترخيص والاختصاص والنشاط التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "client-entity",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What client entity, ownership, licence, jurisdiction and operating activity are involved? is missing

When the normalized field client-entity is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-client-entity",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "client-entity",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-client-entity"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What decision, problem, transaction, compliance outcome or business objective is required?

Ask in plain language: What decision, problem, transaction, compliance outcome or business objective is required? Arabic draft: ما القرار أو المشكلة أو المعاملة أو نتيجة الامتثال أو الهدف التجاري المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-problem-outcome",
  "question_en": "What decision, problem, transaction, compliance outcome or business objective is required?",
  "question_ar": "ما القرار أو المشكلة أو المعاملة أو نتيجة الامتثال أو الهدف التجاري المطلوب؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "problem-outcome",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What decision, problem, transaction, compliance outcome or business objective is required? is missing

When the normalized field problem-outcome is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-problem-outcome",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "problem-outcome",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-problem-outcome"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What work is included, excluded, assumed or dependent on third parties?

Ask in plain language: What work is included, excluded, assumed or dependent on third parties? Arabic draft: ما الأعمال المشمولة والمستبعدة والافتراضات والاعتماد على أطراف أخرى؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-scope-exclusions",
  "question_en": "What work is included, excluded, assumed or dependent on third parties?",
  "question_ar": "ما الأعمال المشمولة والمستبعدة والافتراضات والاعتماد على أطراف أخرى؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-exclusions",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What work is included, excluded, assumed or dependent on third parties? is missing

When the normalized field scope-exclusions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-scope-exclusions",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "scope-exclusions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-scope-exclusions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What records, contracts, accounts, data, correspondence or evidence are available?

Ask in plain language: What records, contracts, accounts, data, correspondence or evidence are available? Arabic draft: ما السجلات أو العقود أو الحسابات أو البيانات أو المراسلات أو الأدلة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-records-evidence",
  "question_en": "What records, contracts, accounts, data, correspondence or evidence are available?",
  "question_ar": "ما السجلات أو العقود أو الحسابات أو البيانات أو المراسلات أو الأدلة المتاحة؟",
  "expected_answer_type": "document_list",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "records-evidence",
  "order": 160,
  "confidence_contribution": 0.03
}
```

### Ask when What records, contracts, accounts, data, correspondence or evidence are available? is missing

When the normalized field records-evidence is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-records-evidence",
  "priority": 984,
  "when": {
    "all": [
      {
        "field": "records-evidence",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-records-evidence"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What deliverables, language, format, review cycle and sign-off are required?

Ask in plain language: What deliverables, language, format, review cycle and sign-off are required? Arabic draft: ما المخرجات واللغة والصيغة ودورة المراجعة والتوقيع المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-deliverables-format",
  "question_en": "What deliverables, language, format, review cycle and sign-off are required?",
  "question_ar": "ما المخرجات واللغة والصيغة ودورة المراجعة والتوقيع المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "deliverables-format",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What deliverables, language, format, review cycle and sign-off are required? is missing

When the normalized field deliverables-format is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-deliverables-format",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "deliverables-format",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-deliverables-format"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which regulator, court, authority, bank, investor or deadline controls the work?

Ask in plain language: Which regulator, court, authority, bank, investor or deadline controls the work? Arabic draft: ما الجهة التنظيمية أو المحكمة أو السلطة أو البنك أو المستثمر أو الموعد الحاكم؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-regulator-deadline",
  "question_en": "Which regulator, court, authority, bank, investor or deadline controls the work?",
  "question_ar": "ما الجهة التنظيمية أو المحكمة أو السلطة أو البنك أو المستثمر أو الموعد الحاكم؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "regulator-deadline",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What conflict checks, confidentiality, privilege, data access and retention rules apply?

Ask in plain language: What conflict checks, confidentiality, privilege, data access and retention rules apply? Arabic draft: ما فحوص التعارض والسرية والامتياز والوصول للبيانات والاحتفاظ؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-conflict-confidentiality",
  "question_en": "What conflict checks, confidentiality, privilege, data access and retention rules apply?",
  "question_ar": "ما فحوص التعارض والسرية والامتياز والوصول للبيانات والاحتفاظ؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "conflict-confidentiality",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### What fee model, expenses, assumptions, milestones, retainer and change-control basis apply?

Ask in plain language: What fee model, expenses, assumptions, milestones, retainer and change-control basis apply? Arabic draft: ما نموذج الأتعاب والمصروفات والافتراضات والمراحل والدفعة والتغيير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-fee-model",
  "question_en": "What fee model, expenses, assumptions, milestones, retainer and change-control basis apply?",
  "question_ar": "ما نموذج الأتعاب والمصروفات والافتراضات والمراحل والدفعة والتغيير؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "fee-model",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when What fee model, expenses, assumptions, milestones, retainer and change-control basis apply? is missing

When the normalized field fee-model is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-fee-model",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "fee-model",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-fee-model"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the location/capacity requirements for Coworking spaces.

Ask in plain language: Please clarify the location/capacity requirements for Coworking spaces. Arabic draft: يرجى توضيح متطلبات location/capacity الخاصة بـ Coworking spaces. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-facet-01",
  "question_en": "Please clarify the location/capacity requirements for Coworking spaces.",
  "question_ar": "يرجى توضيح متطلبات location/capacity الخاصة بـ Coworking spaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the location/capacity requirements for Coworking spaces. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the workspace type requirements for Coworking spaces.

Ask in plain language: Please clarify the workspace type requirements for Coworking spaces. Arabic draft: يرجى توضيح متطلبات workspace type الخاصة بـ Coworking spaces. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-facet-02",
  "question_en": "Please clarify the workspace type requirements for Coworking spaces.",
  "question_ar": "يرجى توضيح متطلبات workspace type الخاصة بـ Coworking spaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the workspace type requirements for Coworking spaces. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the licence/address need requirements for Coworking spaces.

Ask in plain language: Please clarify the licence/address need requirements for Coworking spaces. Arabic draft: يرجى توضيح متطلبات licence/address need الخاصة بـ Coworking spaces. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-facet-03",
  "question_en": "Please clarify the licence/address need requirements for Coworking spaces.",
  "question_ar": "يرجى توضيح متطلبات licence/address need الخاصة بـ Coworking spaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the licence/address need requirements for Coworking spaces. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the services/meeting rooms requirements for Coworking spaces.

Ask in plain language: Please clarify the services/meeting rooms requirements for Coworking spaces. Arabic draft: يرجى توضيح متطلبات services/meeting rooms الخاصة بـ Coworking spaces. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-facet-04",
  "question_en": "Please clarify the services/meeting rooms requirements for Coworking spaces.",
  "question_ar": "يرجى توضيح متطلبات services/meeting rooms الخاصة بـ Coworking spaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the access/security requirements for Coworking spaces.

Ask in plain language: Please clarify the access/security requirements for Coworking spaces. Arabic draft: يرجى توضيح متطلبات access/security الخاصة بـ Coworking spaces. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-facet-05",
  "question_en": "Please clarify the access/security requirements for Coworking spaces.",
  "question_ar": "يرجى توضيح متطلبات access/security الخاصة بـ Coworking spaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the commercial terms requirements for Coworking spaces.

Ask in plain language: Please clarify the commercial terms requirements for Coworking spaces. Arabic draft: يرجى توضيح متطلبات commercial terms الخاصة بـ Coworking spaces. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-facet-06",
  "question_en": "Please clarify the commercial terms requirements for Coworking spaces.",
  "question_ar": "يرجى توضيح متطلبات commercial terms الخاصة بـ Coworking spaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the support/exit requirements for Coworking spaces.

Ask in plain language: Please clarify the support/exit requirements for Coworking spaces. Arabic draft: يرجى توضيح متطلبات support/exit الخاصة بـ Coworking spaces. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-facet-07",
  "question_en": "Please clarify the support/exit requirements for Coworking spaces.",
  "question_ar": "يرجى توضيح متطلبات support/exit الخاصة بـ Coworking spaces.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact Coworking spaces product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Coworking spaces product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Coworking spaces التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-exact-subtype",
  "question_en": "Which exact Coworking spaces product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Coworking spaces التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Coworking spaces product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-coworking-spaces-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Coworking spaces are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Coworking spaces are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Coworking spaces التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-unknowns",
  "question_en": "Which details about Coworking spaces are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Coworking spaces التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Coworking spaces?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Coworking spaces? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Coworking spaces؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-qualification_question-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-coworking-spaces-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Coworking spaces?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Coworking spaces؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Coworking spaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Coworking spaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Coworking spaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Coworking spaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0190`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION, UAE-MOHRE, UAE-FTA-VAT, UAE-FTA-CT, UAE-MOJ, UAE-MOE-IP, UAE-DET-EVENTS, UAE-DM-DBC-2021

```json
{
  "rule_id": "R-031-coworking-spaces-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-COMMERCIAL-COMPANIES",
        "UAE-COMMERCIAL-TRANSACTIONS",
        "UAE-ELECTRONIC-TRANSACTIONS",
        "UAE-PDPL-45-2021",
        "UAE-CONSUMER-PROTECTION",
        "UAE-MOHRE",
        "UAE-FTA-VAT",
        "UAE-FTA-CT",
        "UAE-MOJ",
        "UAE-MOE-IP",
        "UAE-DET-EVENTS",
        "UAE-DM-DBC-2021"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Coworking spaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Coworking spaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Coworking spaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Coworking spaces, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-coworking-spaces-inquiry_qualification-decision_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-coworking-spaces-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Coworking spaces, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-coworking-spaces-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-coworking-spaces-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Coworking spaces, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-coworking-spaces-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-coworking-spaces-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Coworking spaces, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-coworking-spaces-validation-validation_rule-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-coworking-spaces-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Coworking spaces, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-coworking-spaces-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-coworking-spaces-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Coworking spaces, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-coworking-spaces-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-coworking-spaces-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Coworking spaces, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-coworking-spaces-validation-validation_rule-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-coworking-spaces-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Coworking spaces, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-coworking-spaces-validation-validation_rule-0201`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "validation_id": "V-031-coworking-spaces-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Coworking spaces, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-coworking-spaces-validation-validation_rule-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-coworking-spaces-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Coworking spaces, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-coworking-spaces-validation-validation_rule-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-coworking-spaces-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Coworking spaces, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-coworking-spaces-validation-validation_rule-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-coworking-spaces-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Coworking spaces without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-coworking-spaces-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-coworking-spaces-001",
  "setup": "Customer asks informally for Coworking spaces without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Coworking spaces with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-coworking-spaces-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-coworking-spaces-002",
  "setup": "Customer requests price for Coworking spaces with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Coworking spaces. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-coworking-spaces-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-coworking-spaces-003",
  "setup": "Customer uploads a relevant schedule/specification for Coworking spaces.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Coworking spaces. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-coworking-spaces-scenario_test-scenario-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-coworking-spaces-004",
  "setup": "Customer message and uploaded document disagree on Coworking spaces.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Coworking spaces. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-coworking-spaces-scenario_test-scenario-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-coworking-spaces-005",
  "setup": "Supplier proposes a different product, provider or method for Coworking spaces.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Coworking spaces sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-coworking-spaces-scenario_test-scenario-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-coworking-spaces-006",
  "setup": "Customer needs Coworking spaces sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Coworking spaces needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-coworking-spaces-scenario_test-scenario-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-coworking-spaces-007",
  "setup": "The request for Coworking spaces needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Coworking spaces

English term: Coworking spaces. Arabic operational draft: متطلبات Coworking spaces. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Coworking spaces",
  "term_ar": "متطلبات Coworking spaces",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### location/capacity

English term: location/capacity. Arabic operational draft: متطلبات location/capacity. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "location/capacity",
  "term_ar": "متطلبات location/capacity",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### workspace type

English term: workspace type. Arabic operational draft: متطلبات workspace type. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "workspace type",
  "term_ar": "متطلبات workspace type",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### licence/address need

English term: licence/address need. Arabic operational draft: متطلبات licence/address need. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0234`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "licence/address need",
  "term_ar": "متطلبات licence/address need",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### services/meeting rooms

English term: services/meeting rooms. Arabic operational draft: متطلبات services/meeting rooms. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0235`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "services/meeting rooms",
  "term_ar": "متطلبات services/meeting rooms",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### access/security

English term: access/security. Arabic operational draft: متطلبات access/security. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0236`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "access/security",
  "term_ar": "متطلبات access/security",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### commercial terms

English term: commercial terms. Arabic operational draft: متطلبات commercial terms. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0237`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial terms",
  "term_ar": "متطلبات commercial terms",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```

### support/exit

English term: support/exit. Arabic operational draft: متطلبات support/exit. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-coworking-spaces-glossary-bilingual_term-0238`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "support/exit",
  "term_ar": "متطلبات support/exit",
  "canonical_subcategory": "coworking-spaces",
  "normalization_only": true
}
```


# 3. Serviced offices

**Arabic draft:** متطلبات Serviced offices
**Slug:** `serviced-offices`
**Aliases:** Serviced offices

## Industry

### Industry scope — Serviced offices

Serviced offices is treated as a distinct procurement route within Business Centres & Coworking. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers regulated or advisory professional services, defined deliverables, evidence, responsibility and confidentiality. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-031-serviced-offices-industry-subcategory_overview-0001`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS

```json
{
  "category": "Business Centres & Coworking",
  "subcategory": "Serviced offices",
  "profile": "professional",
  "aliases": [
    "Serviced offices"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Serviced offices

A normal UAE sourcing workflow for Serviced offices moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-031-serviced-offices-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS, UAE-PDPL-45-2021

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Serviced offices

Customers may describe Serviced offices through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-031-serviced-offices-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Serviced offices

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-031-serviced-offices-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Serviced offices product or service

The primary deliverable requested within Serviced offices; exact type, quantity, performance, scope and acceptance must be normalized. For Serviced offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-serviced-offices-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Serviced offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Serviced offices

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Serviced offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-serviced-offices-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Serviced offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Serviced offices

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Serviced offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-serviced-offices-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Serviced offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Serviced offices

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Serviced offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-serviced-offices-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Serviced offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Serviced offices

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Serviced offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-serviced-offices-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Serviced offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Serviced offices

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Serviced offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-serviced-offices-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Serviced offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Serviced offices

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Serviced offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-serviced-offices-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Serviced offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Serviced offices

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Serviced offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-serviced-offices-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Serviced offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Location/Capacity scope component

Location/Capacity is a recurring scope component for Serviced offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-serviced-offices-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "location/capacity",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Workspace Type scope component

Workspace Type is a recurring scope component for Serviced offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-serviced-offices-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "workspace type",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Licence/Address Need scope component

Licence/Address Need is a recurring scope component for Serviced offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-serviced-offices-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "licence/address need",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Services/Meeting Rooms scope component

Services/Meeting Rooms is a recurring scope component for Serviced offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-serviced-offices-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "services/meeting rooms",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Access/Security scope component

Access/Security is a recurring scope component for Serviced offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-serviced-offices-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "access/security",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Commercial Terms scope component

Commercial Terms is a recurring scope component for Serviced offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-serviced-offices-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "commercial terms",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Support/Exit scope component

Support/Exit is a recurring scope component for Serviced offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-serviced-offices-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "support/exit",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: client/entity status

For Serviced offices, client/entity status must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "client/entity status",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: jurisdiction and regulator

For Serviced offices, jurisdiction and regulator must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "jurisdiction and regulator",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: problem and desired outcome

For Serviced offices, problem and desired outcome must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "problem and desired outcome",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: scope boundaries

For Serviced offices, scope boundaries must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "scope boundaries",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: inputs and evidence

For Serviced offices, inputs and evidence must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "inputs and evidence",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: methodology and standards

For Serviced offices, methodology and standards must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "methodology and standards",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: deliverables

For Serviced offices, deliverables must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "deliverables",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: timeline and dependencies

For Serviced offices, timeline and dependencies must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "timeline and dependencies",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: professional responsibility

For Serviced offices, professional responsibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "professional responsibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: fees and change control

For Serviced offices, fees and change control must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "fees and change control",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: location/capacity

For Serviced offices, location/capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "location/capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: workspace type

For Serviced offices, workspace type must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "workspace type",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: licence/address need

For Serviced offices, licence/address need must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "licence/address need",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: services/meeting rooms

For Serviced offices, services/meeting rooms must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "services/meeting rooms",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: access/security

For Serviced offices, access/security must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "access/security",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: commercial terms

For Serviced offices, commercial terms must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "commercial terms",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: support/exit

For Serviced offices, support/exit must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-serviced-offices-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "support/exit",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: licensed professional firm

A licensed professional firm may be relevant to Serviced offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-serviced-offices-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "licensed professional firm",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: specialist consultancy

A specialist consultancy may be relevant to Serviced offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-serviced-offices-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "specialist consultancy",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: registered agent or service provider

A registered agent or service provider may be relevant to Serviced offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-serviced-offices-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "registered agent or service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: independent expert

A independent expert may be relevant to Serviced offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-serviced-offices-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "independent expert",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: outsourced managed-service provider

A outsourced managed-service provider may be relevant to Serviced offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-serviced-offices-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "outsourced managed-service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: training provider

A training provider may be relevant to Serviced offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-serviced-offices-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "training provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — licensed professional firm

This supplier type can participate in Serviced offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-serviced-offices-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "licensed professional firm",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — specialist consultancy

This supplier type can participate in Serviced offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-serviced-offices-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "specialist consultancy",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — registered agent or service provider

This supplier type can participate in Serviced offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-serviced-offices-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "registered agent or service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — independent expert

This supplier type can participate in Serviced offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-serviced-offices-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "independent expert",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — outsourced managed-service provider

This supplier type can participate in Serviced offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-serviced-offices-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "outsourced managed-service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — training provider

This supplier type can participate in Serviced offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-serviced-offices-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "training provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — audit/assurance provider

This supplier type can participate in Serviced offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-serviced-offices-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "audit/assurance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — legal/compliance reviewer

This supplier type can participate in Serviced offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-serviced-offices-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "legal/compliance reviewer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — licensed professional firm

Before routing a Serviced offices inquiry to a licensed professional firm, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-serviced-offices-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "licensed professional firm",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — specialist consultancy

Before routing a Serviced offices inquiry to a specialist consultancy, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-serviced-offices-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "specialist consultancy",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — registered agent or service provider

Before routing a Serviced offices inquiry to a registered agent or service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-serviced-offices-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "registered agent or service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — independent expert

Before routing a Serviced offices inquiry to a independent expert, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-serviced-offices-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "independent expert",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — outsourced managed-service provider

Before routing a Serviced offices inquiry to a outsourced managed-service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-serviced-offices-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "outsourced managed-service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — training provider

Before routing a Serviced offices inquiry to a training provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-serviced-offices-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "training provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — audit/assurance provider

Before routing a Serviced offices inquiry to a audit/assurance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-serviced-offices-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "audit/assurance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — legal/compliance reviewer

Before routing a Serviced offices inquiry to a legal/compliance reviewer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-serviced-offices-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "legal/compliance reviewer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Serviced offices should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-serviced-offices-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Serviced offices should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-serviced-offices-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Serviced offices should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-serviced-offices-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Serviced offices should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-serviced-offices-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Serviced offices should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-serviced-offices-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Serviced offices should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-serviced-offices-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Serviced offices should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-serviced-offices-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Serviced offices should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-serviced-offices-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Serviced offices should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-serviced-offices-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Serviced offices should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-serviced-offices-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Client Brief

Client Brief may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "client-brief",
  "document_name": "client brief",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Entity/Licence Documents

Entity/Licence Documents may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "entity-licence-documents",
  "document_name": "entity/licence documents",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Engagement Letter

Engagement Letter may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "engagement-letter",
  "document_name": "engagement letter",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Scope And Deliverables Schedule

Scope And Deliverables Schedule may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "scope-and-deliverables-schedule",
  "document_name": "scope and deliverables schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Evidence/Data Request List

Evidence/Data Request List may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "evidence-data-request-list",
  "document_name": "evidence/data request list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Conflict Check

Conflict Check may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "conflict-check",
  "document_name": "conflict check",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Nda/Confidentiality Terms

Nda/Confidentiality Terms may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "nda-confidentiality-terms",
  "document_name": "NDA/confidentiality terms",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Methodology/Work Plan

Methodology/Work Plan may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "methodology-work-plan",
  "document_name": "methodology/work plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Milestone Schedule

Milestone Schedule may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "milestone-schedule",
  "document_name": "milestone schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Fee Proposal

Fee Proposal may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "fee-proposal",
  "document_name": "fee proposal",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Regulatory Correspondence

Regulatory Correspondence may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "regulatory-correspondence",
  "document_name": "regulatory correspondence",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Draft/Final Report

Draft/Final Report may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "draft-final-report",
  "document_name": "draft/final report",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Sign-Off/Acceptance

Sign-Off/Acceptance may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "sign-off-acceptance",
  "document_name": "sign-off/acceptance",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Change Request

Change Request may provide or verify information needed for Serviced offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-serviced-offices-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "change-request",
  "document_name": "change request",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Federal Decree-Law on Commercial Companies

For Serviced offices, consult Federal Decree-Law on Commercial Companies when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-COMMERCIAL-COMPANIES

```json
{
  "source_id": "UAE-COMMERCIAL-COMPANIES",
  "publisher": "UAE Legislation",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law No. 50 of 2022 on Commercial Transactions

For Serviced offices, consult Federal Decree-Law No. 50 of 2022 on Commercial Transactions when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "source_id": "UAE-COMMERCIAL-TRANSACTIONS",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law on Electronic Transactions and Trust Services

For Serviced offices, consult Federal Decree-Law on Electronic Transactions and Trust Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ELECTRONIC-TRANSACTIONS

```json
{
  "source_id": "UAE-ELECTRONIC-TRANSACTIONS",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

For Serviced offices, consult Federal Decree-Law No. 45 of 2021 on Protection of Personal Data when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021

```json
{
  "source_id": "UAE-PDPL-45-2021",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Consumer Protection Legislation

For Serviced offices, consult UAE Consumer Protection Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION

```json
{
  "source_id": "UAE-CONSUMER-PROTECTION",
  "publisher": "UAE Legislation / Ministry of Economy",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### MOHRE Services, Labour Guidance and Establishment Requirements

For Serviced offices, consult MOHRE Services, Labour Guidance and Establishment Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOHRE

```json
{
  "source_id": "UAE-MOHRE",
  "publisher": "Ministry of Human Resources and Emiratisation",
  "source_type": "government_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### VAT Guides and Legislation

For Serviced offices, consult VAT Guides and Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-FTA-VAT

```json
{
  "source_id": "UAE-FTA-VAT",
  "publisher": "Federal Tax Authority",
  "source_type": "tax_authority_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Corporate Tax Guides and Legislation

For Serviced offices, consult Corporate Tax Guides and Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-FTA-CT

```json
{
  "source_id": "UAE-FTA-CT",
  "publisher": "Federal Tax Authority",
  "source_type": "tax_authority_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Ministry of Justice Legal, Notary and Attestation Services

For Serviced offices, consult Ministry of Justice Legal, Notary and Attestation Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOJ

```json
{
  "source_id": "UAE-MOJ",
  "publisher": "UAE Ministry of Justice",
  "source_type": "government_legal_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Intellectual Property and Trademark Services

For Serviced offices, consult Intellectual Property and Trademark Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0092`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOE-IP

```json
{
  "source_id": "UAE-MOE-IP",
  "publisher": "UAE Ministry of Economy",
  "source_type": "government_ip_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Business and Event Licensing Services

For Serviced offices, consult Dubai Business and Event Licensing Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0093`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DET-EVENTS

```json
{
  "source_id": "UAE-DET-EVENTS",
  "publisher": "Dubai Department of Economy and Tourism",
  "source_type": "government_business_events_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Building Code 2021

For Serviced offices, consult Dubai Building Code 2021 when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-serviced-offices-uae_regulations-source_activation-0094`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-DBC-2021

```json
{
  "source_id": "UAE-DM-DBC-2021",
  "publisher": "Dubai Municipality",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Serviced offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-serviced-offices-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Serviced offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-serviced-offices-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Serviced offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-serviced-offices-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Serviced offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-serviced-offices-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Serviced offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-serviced-offices-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Serviced offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-serviced-offices-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Serviced offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-serviced-offices-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Serviced offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-serviced-offices-commercial_pricing-cost_driver-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Serviced offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-serviced-offices-commercial_pricing-cost_driver-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Serviced offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-serviced-offices-commercial_pricing-cost_driver-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-serviced-offices-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-serviced-offices-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-serviced-offices-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-serviced-offices-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-serviced-offices-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-serviced-offices-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-serviced-offices-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-serviced-offices-customer_tradeoffs-tradeoff-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-serviced-offices-customer_tradeoffs-tradeoff-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-serviced-offices-customer_tradeoffs-tradeoff-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Serviced offices, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-serviced-offices-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Serviced offices, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-serviced-offices-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Serviced offices, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-serviced-offices-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Serviced offices, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-serviced-offices-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Serviced offices, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-serviced-offices-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Serviced offices, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-serviced-offices-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Serviced offices, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-serviced-offices-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Serviced offices, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-serviced-offices-risk-risk_control-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Serviced offices, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-serviced-offices-risk-risk_control-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Serviced offices, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-serviced-offices-risk-risk_control-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Serviced offices, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-serviced-offices-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Serviced offices, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-serviced-offices-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Serviced offices, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-serviced-offices-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Serviced offices, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-serviced-offices-best_practices-qualification_best_practice-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Serviced offices, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-serviced-offices-best_practices-qualification_best_practice-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Serviced offices, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-serviced-offices-best_practices-qualification_best_practice-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Serviced offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-serviced-offices-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Serviced offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-serviced-offices-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Serviced offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-serviced-offices-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Serviced offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-serviced-offices-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Serviced offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-serviced-offices-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Serviced offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-serviced-offices-troubleshooting-recovery_guidance-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Serviced offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-serviced-offices-troubleshooting-recovery_guidance-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Serviced offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-serviced-offices-troubleshooting-recovery_guidance-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What client entity, ownership, licence, jurisdiction and operating activity are involved?

Ask in plain language: What client entity, ownership, licence, jurisdiction and operating activity are involved? Arabic draft: ما جهة العميل والملكية والترخيص والاختصاص والنشاط التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-client-entity",
  "question_en": "What client entity, ownership, licence, jurisdiction and operating activity are involved?",
  "question_ar": "ما جهة العميل والملكية والترخيص والاختصاص والنشاط التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "client-entity",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What client entity, ownership, licence, jurisdiction and operating activity are involved? is missing

When the normalized field client-entity is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-client-entity",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "client-entity",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-client-entity"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What decision, problem, transaction, compliance outcome or business objective is required?

Ask in plain language: What decision, problem, transaction, compliance outcome or business objective is required? Arabic draft: ما القرار أو المشكلة أو المعاملة أو نتيجة الامتثال أو الهدف التجاري المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-problem-outcome",
  "question_en": "What decision, problem, transaction, compliance outcome or business objective is required?",
  "question_ar": "ما القرار أو المشكلة أو المعاملة أو نتيجة الامتثال أو الهدف التجاري المطلوب؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "problem-outcome",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What decision, problem, transaction, compliance outcome or business objective is required? is missing

When the normalized field problem-outcome is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-problem-outcome",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "problem-outcome",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-problem-outcome"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What work is included, excluded, assumed or dependent on third parties?

Ask in plain language: What work is included, excluded, assumed or dependent on third parties? Arabic draft: ما الأعمال المشمولة والمستبعدة والافتراضات والاعتماد على أطراف أخرى؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-scope-exclusions",
  "question_en": "What work is included, excluded, assumed or dependent on third parties?",
  "question_ar": "ما الأعمال المشمولة والمستبعدة والافتراضات والاعتماد على أطراف أخرى؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-exclusions",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What work is included, excluded, assumed or dependent on third parties? is missing

When the normalized field scope-exclusions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-scope-exclusions",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "scope-exclusions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-scope-exclusions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What records, contracts, accounts, data, correspondence or evidence are available?

Ask in plain language: What records, contracts, accounts, data, correspondence or evidence are available? Arabic draft: ما السجلات أو العقود أو الحسابات أو البيانات أو المراسلات أو الأدلة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-records-evidence",
  "question_en": "What records, contracts, accounts, data, correspondence or evidence are available?",
  "question_ar": "ما السجلات أو العقود أو الحسابات أو البيانات أو المراسلات أو الأدلة المتاحة؟",
  "expected_answer_type": "document_list",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "records-evidence",
  "order": 160,
  "confidence_contribution": 0.03
}
```

### Ask when What records, contracts, accounts, data, correspondence or evidence are available? is missing

When the normalized field records-evidence is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-records-evidence",
  "priority": 984,
  "when": {
    "all": [
      {
        "field": "records-evidence",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-records-evidence"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What deliverables, language, format, review cycle and sign-off are required?

Ask in plain language: What deliverables, language, format, review cycle and sign-off are required? Arabic draft: ما المخرجات واللغة والصيغة ودورة المراجعة والتوقيع المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-deliverables-format",
  "question_en": "What deliverables, language, format, review cycle and sign-off are required?",
  "question_ar": "ما المخرجات واللغة والصيغة ودورة المراجعة والتوقيع المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "deliverables-format",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What deliverables, language, format, review cycle and sign-off are required? is missing

When the normalized field deliverables-format is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-deliverables-format",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "deliverables-format",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-deliverables-format"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which regulator, court, authority, bank, investor or deadline controls the work?

Ask in plain language: Which regulator, court, authority, bank, investor or deadline controls the work? Arabic draft: ما الجهة التنظيمية أو المحكمة أو السلطة أو البنك أو المستثمر أو الموعد الحاكم؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-regulator-deadline",
  "question_en": "Which regulator, court, authority, bank, investor or deadline controls the work?",
  "question_ar": "ما الجهة التنظيمية أو المحكمة أو السلطة أو البنك أو المستثمر أو الموعد الحاكم؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "regulator-deadline",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What conflict checks, confidentiality, privilege, data access and retention rules apply?

Ask in plain language: What conflict checks, confidentiality, privilege, data access and retention rules apply? Arabic draft: ما فحوص التعارض والسرية والامتياز والوصول للبيانات والاحتفاظ؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-conflict-confidentiality",
  "question_en": "What conflict checks, confidentiality, privilege, data access and retention rules apply?",
  "question_ar": "ما فحوص التعارض والسرية والامتياز والوصول للبيانات والاحتفاظ؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "conflict-confidentiality",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### What fee model, expenses, assumptions, milestones, retainer and change-control basis apply?

Ask in plain language: What fee model, expenses, assumptions, milestones, retainer and change-control basis apply? Arabic draft: ما نموذج الأتعاب والمصروفات والافتراضات والمراحل والدفعة والتغيير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-fee-model",
  "question_en": "What fee model, expenses, assumptions, milestones, retainer and change-control basis apply?",
  "question_ar": "ما نموذج الأتعاب والمصروفات والافتراضات والمراحل والدفعة والتغيير؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "fee-model",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when What fee model, expenses, assumptions, milestones, retainer and change-control basis apply? is missing

When the normalized field fee-model is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-fee-model",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "fee-model",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-fee-model"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the location/capacity requirements for Serviced offices.

Ask in plain language: Please clarify the location/capacity requirements for Serviced offices. Arabic draft: يرجى توضيح متطلبات location/capacity الخاصة بـ Serviced offices. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-facet-01",
  "question_en": "Please clarify the location/capacity requirements for Serviced offices.",
  "question_ar": "يرجى توضيح متطلبات location/capacity الخاصة بـ Serviced offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the location/capacity requirements for Serviced offices. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the workspace type requirements for Serviced offices.

Ask in plain language: Please clarify the workspace type requirements for Serviced offices. Arabic draft: يرجى توضيح متطلبات workspace type الخاصة بـ Serviced offices. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-facet-02",
  "question_en": "Please clarify the workspace type requirements for Serviced offices.",
  "question_ar": "يرجى توضيح متطلبات workspace type الخاصة بـ Serviced offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the workspace type requirements for Serviced offices. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the licence/address need requirements for Serviced offices.

Ask in plain language: Please clarify the licence/address need requirements for Serviced offices. Arabic draft: يرجى توضيح متطلبات licence/address need الخاصة بـ Serviced offices. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-facet-03",
  "question_en": "Please clarify the licence/address need requirements for Serviced offices.",
  "question_ar": "يرجى توضيح متطلبات licence/address need الخاصة بـ Serviced offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the licence/address need requirements for Serviced offices. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the services/meeting rooms requirements for Serviced offices.

Ask in plain language: Please clarify the services/meeting rooms requirements for Serviced offices. Arabic draft: يرجى توضيح متطلبات services/meeting rooms الخاصة بـ Serviced offices. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-facet-04",
  "question_en": "Please clarify the services/meeting rooms requirements for Serviced offices.",
  "question_ar": "يرجى توضيح متطلبات services/meeting rooms الخاصة بـ Serviced offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the access/security requirements for Serviced offices.

Ask in plain language: Please clarify the access/security requirements for Serviced offices. Arabic draft: يرجى توضيح متطلبات access/security الخاصة بـ Serviced offices. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-facet-05",
  "question_en": "Please clarify the access/security requirements for Serviced offices.",
  "question_ar": "يرجى توضيح متطلبات access/security الخاصة بـ Serviced offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the commercial terms requirements for Serviced offices.

Ask in plain language: Please clarify the commercial terms requirements for Serviced offices. Arabic draft: يرجى توضيح متطلبات commercial terms الخاصة بـ Serviced offices. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-facet-06",
  "question_en": "Please clarify the commercial terms requirements for Serviced offices.",
  "question_ar": "يرجى توضيح متطلبات commercial terms الخاصة بـ Serviced offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the support/exit requirements for Serviced offices.

Ask in plain language: Please clarify the support/exit requirements for Serviced offices. Arabic draft: يرجى توضيح متطلبات support/exit الخاصة بـ Serviced offices. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-facet-07",
  "question_en": "Please clarify the support/exit requirements for Serviced offices.",
  "question_ar": "يرجى توضيح متطلبات support/exit الخاصة بـ Serviced offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact Serviced offices product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Serviced offices product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Serviced offices التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-exact-subtype",
  "question_en": "Which exact Serviced offices product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Serviced offices التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Serviced offices product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-serviced-offices-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Serviced offices are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Serviced offices are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Serviced offices التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-unknowns",
  "question_en": "Which details about Serviced offices are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Serviced offices التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Serviced offices?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Serviced offices? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Serviced offices؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-qualification_question-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-serviced-offices-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Serviced offices?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Serviced offices؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Serviced offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Serviced offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Serviced offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Serviced offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0190`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION, UAE-MOHRE, UAE-FTA-VAT, UAE-FTA-CT, UAE-MOJ, UAE-MOE-IP, UAE-DET-EVENTS, UAE-DM-DBC-2021

```json
{
  "rule_id": "R-031-serviced-offices-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-COMMERCIAL-COMPANIES",
        "UAE-COMMERCIAL-TRANSACTIONS",
        "UAE-ELECTRONIC-TRANSACTIONS",
        "UAE-PDPL-45-2021",
        "UAE-CONSUMER-PROTECTION",
        "UAE-MOHRE",
        "UAE-FTA-VAT",
        "UAE-FTA-CT",
        "UAE-MOJ",
        "UAE-MOE-IP",
        "UAE-DET-EVENTS",
        "UAE-DM-DBC-2021"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Serviced offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Serviced offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Serviced offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Serviced offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-serviced-offices-inquiry_qualification-decision_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-serviced-offices-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Serviced offices, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-serviced-offices-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-serviced-offices-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Serviced offices, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-serviced-offices-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-serviced-offices-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Serviced offices, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-serviced-offices-validation-validation_rule-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-serviced-offices-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Serviced offices, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-serviced-offices-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-serviced-offices-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Serviced offices, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-serviced-offices-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-serviced-offices-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Serviced offices, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-serviced-offices-validation-validation_rule-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-serviced-offices-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Serviced offices, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-serviced-offices-validation-validation_rule-0201`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "validation_id": "V-031-serviced-offices-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Serviced offices, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-serviced-offices-validation-validation_rule-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-serviced-offices-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Serviced offices, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-serviced-offices-validation-validation_rule-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-serviced-offices-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Serviced offices, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-serviced-offices-validation-validation_rule-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-serviced-offices-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Serviced offices without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-serviced-offices-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-serviced-offices-001",
  "setup": "Customer asks informally for Serviced offices without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Serviced offices with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-serviced-offices-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-serviced-offices-002",
  "setup": "Customer requests price for Serviced offices with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Serviced offices. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-serviced-offices-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-serviced-offices-003",
  "setup": "Customer uploads a relevant schedule/specification for Serviced offices.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Serviced offices. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-serviced-offices-scenario_test-scenario-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-serviced-offices-004",
  "setup": "Customer message and uploaded document disagree on Serviced offices.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Serviced offices. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-serviced-offices-scenario_test-scenario-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-serviced-offices-005",
  "setup": "Supplier proposes a different product, provider or method for Serviced offices.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Serviced offices sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-serviced-offices-scenario_test-scenario-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-serviced-offices-006",
  "setup": "Customer needs Serviced offices sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Serviced offices needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-serviced-offices-scenario_test-scenario-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-serviced-offices-007",
  "setup": "The request for Serviced offices needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Serviced offices

English term: Serviced offices. Arabic operational draft: متطلبات Serviced offices. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Serviced offices",
  "term_ar": "متطلبات Serviced offices",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### location/capacity

English term: location/capacity. Arabic operational draft: متطلبات location/capacity. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "location/capacity",
  "term_ar": "متطلبات location/capacity",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### workspace type

English term: workspace type. Arabic operational draft: متطلبات workspace type. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "workspace type",
  "term_ar": "متطلبات workspace type",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### licence/address need

English term: licence/address need. Arabic operational draft: متطلبات licence/address need. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0234`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "licence/address need",
  "term_ar": "متطلبات licence/address need",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### services/meeting rooms

English term: services/meeting rooms. Arabic operational draft: متطلبات services/meeting rooms. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0235`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "services/meeting rooms",
  "term_ar": "متطلبات services/meeting rooms",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### access/security

English term: access/security. Arabic operational draft: متطلبات access/security. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0236`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "access/security",
  "term_ar": "متطلبات access/security",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### commercial terms

English term: commercial terms. Arabic operational draft: متطلبات commercial terms. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0237`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial terms",
  "term_ar": "متطلبات commercial terms",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```

### support/exit

English term: support/exit. Arabic operational draft: متطلبات support/exit. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-serviced-offices-glossary-bilingual_term-0238`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "support/exit",
  "term_ar": "متطلبات support/exit",
  "canonical_subcategory": "serviced-offices",
  "normalization_only": true
}
```


# 4. Virtual offices

**Arabic draft:** متطلبات Virtual offices
**Slug:** `virtual-offices`
**Aliases:** Virtual offices

## Industry

### Industry scope — Virtual offices

Virtual offices is treated as a distinct procurement route within Business Centres & Coworking. The agent must first translate everyday customer language into the likely product, service or outcome, then confirm the exact scope before supplier matching. The route covers regulated or advisory professional services, defined deliverables, evidence, responsibility and confidentiality. It must distinguish a budget request from a final procurement request, preserve the customer’s original wording, and avoid treating a broad label as proof of a technical specification, legal conclusion, professional design or authority approval.

- Record ID: `QD-KB-031-virtual-offices-industry-subcategory_overview-0001`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS

```json
{
  "category": "Business Centres & Coworking",
  "subcategory": "Virtual offices",
  "profile": "professional",
  "aliases": [
    "Virtual offices"
  ],
  "authority_boundary": "qualification and procurement only"
}
```

### Typical UAE sourcing workflow — Virtual offices

A normal UAE sourcing workflow for Virtual offices moves from customer intent and jurisdiction to clarification, evidence collection, supplier eligibility, comparable RFQ issue, technical and commercial clarification, approval, award, delivery or implementation, acceptance, handover and support. Exact licensing, permit, regulator, free-zone, master-developer, authority and contract requirements depend on the activity and location. The platform should activate the relevant source set, but must never represent that a generic database rule equals project-specific approval.

- Record ID: `QD-KB-031-virtual-offices-industry-uae_market_workflow-0002`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS, UAE-PDPL-45-2021

```json
{
  "workflow": [
    "intent",
    "classification",
    "requirements",
    "documents",
    "eligibility",
    "RFQ",
    "clarification",
    "comparison",
    "award",
    "delivery/implementation",
    "acceptance",
    "support"
  ]
}
```

### Plain-language interpretation — Virtual offices

Customers may describe Virtual offices through symptoms, outcomes, brand names, partial terminology or informal examples. The router should map synonyms and intent to this route only when evidence supports it. When two routes remain plausible, ask one short non-technical clarification rather than forcing a category. Store the original text, normalized meaning, candidate routes and confidence separately so later corrections do not erase what the customer actually said.

- Record ID: `QD-KB-031-virtual-offices-industry-customer_language_normalization-0003`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "router_behavior": "rank candidates; ask one clarification below threshold",
  "preserve_original": true,
  "cross_category_allowed": true
}
```

### Authority and professional boundary — Virtual offices

The category agent may explain common choices, collect mandatory and optional information, identify missing documents, retrieve approved internal references, execute deterministic completeness rules and prepare a supplier-facing brief. It may not provide licensed engineering, legal, tax, medical, financial, architectural, safety or regulatory approval; sign designs; certify compliance; guarantee price or availability; or override an authority, consultant, clinician, auditor, lawyer or other qualified professional.

- Record ID: `QD-KB-031-virtual-offices-industry-agent_authority_boundary-0004`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "allowed": [
    "classify",
    "ask",
    "retrieve",
    "normalize",
    "validate",
    "compare",
    "escalate"
  ],
  "prohibited": [
    "professional signoff",
    "authority approval",
    "guaranteed outcome"
  ]
}
```

## Products Services

### Core Virtual offices product or service

The primary deliverable requested within Virtual offices; exact type, quantity, performance, scope and acceptance must be normalized. For Virtual offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-virtual-offices-products_services-product_service_family-0005`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "core_product_or_service",
  "subcategory": "Virtual offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Standard configuration for Virtual offices

Common off-the-shelf or standard service configuration; compare exact inclusions, limits, options and local support. For Virtual offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-virtual-offices-products_services-product_service_family-0006`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "standard_configuration",
  "subcategory": "Virtual offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Project-specific or customized Virtual offices

Custom dimensions, workflow, integration, design, fabrication or service configuration requiring project inputs and approval. For Virtual offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-virtual-offices-products_services-product_service_family-0007`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "project_specific_configuration",
  "subcategory": "Virtual offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Accessories, interfaces and enabling items for Virtual offices

Supporting accessories, consumables, connectors, licences, finishes, controls, packaging or interfaces often omitted from headline scope. For Virtual offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-virtual-offices-products_services-product_service_family-0008`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "accessories_interfaces",
  "subcategory": "Virtual offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Installation or implementation package for Virtual offices

Site, configuration, integration, migration, testing or mobilization work necessary to make the main deliverable operational. For Virtual offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-virtual-offices-products_services-product_service_family-0009`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "installation_implementation",
  "subcategory": "Virtual offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Testing, validation and acceptance for Virtual offices

Inspection, measurement, verification, sign-off and documentary evidence required before acceptance. For Virtual offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-virtual-offices-products_services-product_service_family-0010`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "testing_acceptance",
  "subcategory": "Virtual offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Maintenance, support and lifecycle service for Virtual offices

Warranty, preventive/corrective maintenance, consumables, spares, updates, helpdesk or response obligations. For Virtual offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-virtual-offices-products_services-product_service_family-0011`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "maintenance_support",
  "subcategory": "Virtual offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Training, documentation and handover for Virtual offices

User/admin/operator training, manuals, records, configuration, licences, certificates and final ownership transfer. For Virtual offices, the inquiry must state the exact requested outcome, quantity or usage metric, technical or professional basis, included accessories or activities, exclusions, acceptance method and lifecycle responsibility. A generic family name is only a routing aid and is never sufficient for final supplier dispatch without the mandatory qualification fields.

- Record ID: `QD-KB-031-virtual-offices-products_services-product_service_family-0012`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "family_key": "training_handover",
  "subcategory": "Virtual offices",
  "classification_only": true,
  "requires_exact_item": true
}
```

### Location/Capacity scope component

Location/Capacity is a recurring scope component for Virtual offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-virtual-offices-products_services-scope_component-0013`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "location/capacity",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Workspace Type scope component

Workspace Type is a recurring scope component for Virtual offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-virtual-offices-products_services-scope_component-0014`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "workspace type",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Licence/Address Need scope component

Licence/Address Need is a recurring scope component for Virtual offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-virtual-offices-products_services-scope_component-0015`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "licence/address need",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Services/Meeting Rooms scope component

Services/Meeting Rooms is a recurring scope component for Virtual offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-virtual-offices-products_services-scope_component-0016`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "services/meeting rooms",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Access/Security scope component

Access/Security is a recurring scope component for Virtual offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-virtual-offices-products_services-scope_component-0017`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "access/security",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Commercial Terms scope component

Commercial Terms is a recurring scope component for Virtual offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-virtual-offices-products_services-scope_component-0018`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "commercial terms",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

### Support/Exit scope component

Support/Exit is a recurring scope component for Virtual offices. The platform should capture whether it is included, excluded, customer-supplied, supplier-designed, third-party-controlled or subject to later approval. Suppliers must respond on the same basis so the quotation comparison does not hide differences inside assumptions or exclusions.

- Record ID: `QD-KB-031-virtual-offices-products_services-scope_component-0019`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "component": "support/exit",
  "scope_states": [
    "included",
    "excluded",
    "customer supplied",
    "supplier responsibility",
    "third-party responsibility",
    "pending approval"
  ]
}
```

## Technical

### Technical dimension: client/entity status

For Virtual offices, client/entity status must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0020`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "client/entity status",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: jurisdiction and regulator

For Virtual offices, jurisdiction and regulator must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0021`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "jurisdiction and regulator",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: problem and desired outcome

For Virtual offices, problem and desired outcome must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0022`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "problem and desired outcome",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: scope boundaries

For Virtual offices, scope boundaries must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0023`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "scope boundaries",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: inputs and evidence

For Virtual offices, inputs and evidence must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0024`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "inputs and evidence",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: methodology and standards

For Virtual offices, methodology and standards must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0025`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "methodology and standards",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: deliverables

For Virtual offices, deliverables must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0026`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "deliverables",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: timeline and dependencies

For Virtual offices, timeline and dependencies must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0027`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "timeline and dependencies",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: professional responsibility

For Virtual offices, professional responsibility must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0028`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "professional responsibility",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: fees and change control

For Virtual offices, fees and change control must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0029`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "fees and change control",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: location/capacity

For Virtual offices, location/capacity must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0030`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "location/capacity",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: workspace type

For Virtual offices, workspace type must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0031`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "workspace type",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: licence/address need

For Virtual offices, licence/address need must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0032`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "licence/address need",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: services/meeting rooms

For Virtual offices, services/meeting rooms must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0033`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "services/meeting rooms",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: access/security

For Virtual offices, access/security must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0034`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "access/security",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: commercial terms

For Virtual offices, commercial terms must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0035`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "commercial terms",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

### Technical dimension: support/exit

For Virtual offices, support/exit must be captured at the level needed to determine supplier eligibility, scope, deliverables, compatibility, performance, risk and price. The agent should retrieve the value from customer text or approved documents, preserve units and revisions, and distinguish confirmed facts from assumptions. If the value requires design, legal interpretation, medical judgment, financial advice or authority acceptance, the system records it as unresolved and escalates rather than inventing a value.

- Record ID: `QD-KB-031-virtual-offices-technical-technical_dimension-0036`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "dimension": "support/exit",
  "capture_states": [
    "confirmed",
    "document-derived",
    "customer-stated",
    "supplier assumption",
    "unknown",
    "conflict"
  ],
  "affects": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "risk",
    "acceptance"
  ]
}
```

## Brands Manufacturers

### Provider archetype: licensed professional firm

A licensed professional firm may be relevant to Virtual offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-virtual-offices-brands_manufacturers-provider_archetype-0037`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "licensed professional firm",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: specialist consultancy

A specialist consultancy may be relevant to Virtual offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-virtual-offices-brands_manufacturers-provider_archetype-0038`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "specialist consultancy",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: registered agent or service provider

A registered agent or service provider may be relevant to Virtual offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-virtual-offices-brands_manufacturers-provider_archetype-0039`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "registered agent or service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: independent expert

A independent expert may be relevant to Virtual offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-virtual-offices-brands_manufacturers-provider_archetype-0040`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "independent expert",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: outsourced managed-service provider

A outsourced managed-service provider may be relevant to Virtual offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-virtual-offices-brands_manufacturers-provider_archetype-0041`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "outsourced managed-service provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

### Provider archetype: training provider

A training provider may be relevant to Virtual offices depending on whether the scope is product supply, implementation, regulated professional service, integration, testing, rental, maintenance or managed operation. This is a market-navigation archetype, not an endorsement or proof of eligibility. The platform must verify the legal entity, UAE licence activity, authorization/accreditation, named personnel, relevant experience, insurance, current certificates and ability to deliver the exact requested scope.

- Record ID: `QD-KB-031-virtual-offices-brands_manufacturers-provider_archetype-0042`
- Status: `draft` | Confidence: `0.72` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "provider_type": "training provider",
  "endorsement": false,
  "eligibility_must_be_verified": true
}
```

## Supplier Ecosystem

### Supplier type — licensed professional firm

This supplier type can participate in Virtual offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-virtual-offices-supplier_ecosystem-supplier_type-0043`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "licensed professional firm",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — specialist consultancy

This supplier type can participate in Virtual offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-virtual-offices-supplier_ecosystem-supplier_type-0045`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "specialist consultancy",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — registered agent or service provider

This supplier type can participate in Virtual offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-virtual-offices-supplier_ecosystem-supplier_type-0047`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "registered agent or service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — independent expert

This supplier type can participate in Virtual offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-virtual-offices-supplier_ecosystem-supplier_type-0049`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "independent expert",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — outsourced managed-service provider

This supplier type can participate in Virtual offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-virtual-offices-supplier_ecosystem-supplier_type-0051`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "outsourced managed-service provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — training provider

This supplier type can participate in Virtual offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-virtual-offices-supplier_ecosystem-supplier_type-0053`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "training provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — audit/assurance provider

This supplier type can participate in Virtual offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-virtual-offices-supplier_ecosystem-supplier_type-0055`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "audit/assurance provider",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

### Supplier type — legal/compliance reviewer

This supplier type can participate in Virtual offices only when its licensed activity, authorizations, personnel, experience, geography, capacity and commercial scope match the inquiry. Supplier registration alone is not sufficient. The matching engine should use evidence-backed capabilities and should exclude suppliers whose profile, documents or service coverage do not support the requested work.

- Record ID: `QD-KB-031-virtual-offices-supplier_ecosystem-supplier_type-0057`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "supplier_type": "legal/compliance reviewer",
  "eligibility_fields": [
    "licence activity",
    "authorization/accreditation",
    "capability",
    "coverage",
    "capacity",
    "experience",
    "insurance",
    "response SLA"
  ]
}
```

## Supplier Eligibility

### Eligibility rule — licensed professional firm

Before routing a Virtual offices inquiry to a licensed professional firm, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-virtual-offices-supplier_eligibility-eligibility_rule-0044`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "licensed professional firm",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — specialist consultancy

Before routing a Virtual offices inquiry to a specialist consultancy, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-virtual-offices-supplier_eligibility-eligibility_rule-0046`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "specialist consultancy",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — registered agent or service provider

Before routing a Virtual offices inquiry to a registered agent or service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-virtual-offices-supplier_eligibility-eligibility_rule-0048`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "registered agent or service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — independent expert

Before routing a Virtual offices inquiry to a independent expert, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-virtual-offices-supplier_eligibility-eligibility_rule-0050`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "independent expert",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — outsourced managed-service provider

Before routing a Virtual offices inquiry to a outsourced managed-service provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-virtual-offices-supplier_eligibility-eligibility_rule-0052`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "outsourced managed-service provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — training provider

Before routing a Virtual offices inquiry to a training provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-virtual-offices-supplier_eligibility-eligibility_rule-0054`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "training provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — audit/assurance provider

Before routing a Virtual offices inquiry to a audit/assurance provider, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-virtual-offices-supplier_eligibility-eligibility_rule-0056`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "audit/assurance provider",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

### Eligibility rule — legal/compliance reviewer

Before routing a Virtual offices inquiry to a legal/compliance reviewer, verify that the supplier’s current UAE licence and category evidence cover the exact activity; required manufacturer, authority or professional authorizations are current; capacity and location match; mandatory documents are available; and no suspension, conflict or risk flag applies. If any critical evidence is missing, the supplier remains ineligible or conditionally eligible pending verification.

- Record ID: `QD-KB-031-virtual-offices-supplier_eligibility-eligibility_rule-0058`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "supplier_type": "legal/compliance reviewer",
  "critical_checks": [
    "licence",
    "authorization",
    "capability",
    "coverage",
    "capacity",
    "documents",
    "risk flags"
  ],
  "failure_action": "exclude_or_hold"
}
```

## Quotation

### Quotation requirement: scope basis

Every supplier quotation for Virtual offices should state its scope basis explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-virtual-offices-quotation-quotation_requirement-0059`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "scope basis",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: technical or service specification

Every supplier quotation for Virtual offices should state its technical or service specification explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-virtual-offices-quotation-quotation_requirement-0060`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "technical or service specification",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: quantity and unit

Every supplier quotation for Virtual offices should state its quantity and unit explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-virtual-offices-quotation-quotation_requirement-0061`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "quantity and unit",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: deliverables and milestones

Every supplier quotation for Virtual offices should state its deliverables and milestones explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-virtual-offices-quotation-quotation_requirement-0062`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "deliverables and milestones",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: inclusions and exclusions

Every supplier quotation for Virtual offices should state its inclusions and exclusions explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-virtual-offices-quotation-quotation_requirement-0063`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "inclusions and exclusions",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: assumptions and dependencies

Every supplier quotation for Virtual offices should state its assumptions and dependencies explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-virtual-offices-quotation-quotation_requirement-0064`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "assumptions and dependencies",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: approval and evidence

Every supplier quotation for Virtual offices should state its approval and evidence explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-virtual-offices-quotation-quotation_requirement-0065`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "approval and evidence",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: delivery or implementation schedule

Every supplier quotation for Virtual offices should state its delivery or implementation schedule explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-virtual-offices-quotation-quotation_requirement-0066`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "delivery or implementation schedule",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: testing and acceptance

Every supplier quotation for Virtual offices should state its testing and acceptance explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-virtual-offices-quotation-quotation_requirement-0067`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "testing and acceptance",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

### Quotation requirement: warranty/support/payment

Every supplier quotation for Virtual offices should state its warranty/support/payment explicitly and in a comparable field. The platform should not compare headline totals until quantities, units, currency, tax treatment, validity, delivery or service dates, technical basis, documents, responsibilities, exclusions and acceptance conditions are normalized. Unknown details must appear as visible assumptions rather than being silently interpreted by the agent.

- Record ID: `QD-KB-031-virtual-offices-quotation-quotation_requirement-0068`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "topic": "warranty/support/payment",
  "required_response": "explicit",
  "unknown_behavior": "visible assumption",
  "comparison_gate": true
}
```

## Documents

### Client Brief

Client Brief may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0069`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "client-brief",
  "document_name": "client brief",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Entity/Licence Documents

Entity/Licence Documents may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0070`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "entity-licence-documents",
  "document_name": "entity/licence documents",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Engagement Letter

Engagement Letter may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0071`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "engagement-letter",
  "document_name": "engagement letter",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Scope And Deliverables Schedule

Scope And Deliverables Schedule may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0072`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "scope-and-deliverables-schedule",
  "document_name": "scope and deliverables schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Evidence/Data Request List

Evidence/Data Request List may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0073`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "evidence-data-request-list",
  "document_name": "evidence/data request list",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Conflict Check

Conflict Check may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0074`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "conflict-check",
  "document_name": "conflict check",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Nda/Confidentiality Terms

Nda/Confidentiality Terms may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0075`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "nda-confidentiality-terms",
  "document_name": "NDA/confidentiality terms",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Methodology/Work Plan

Methodology/Work Plan may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0076`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "methodology-work-plan",
  "document_name": "methodology/work plan",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Milestone Schedule

Milestone Schedule may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0077`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "milestone-schedule",
  "document_name": "milestone schedule",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Fee Proposal

Fee Proposal may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0078`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "fee-proposal",
  "document_name": "fee proposal",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Regulatory Correspondence

Regulatory Correspondence may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0079`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "regulatory-correspondence",
  "document_name": "regulatory correspondence",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Draft/Final Report

Draft/Final Report may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0080`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "draft-final-report",
  "document_name": "draft/final report",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Sign-Off/Acceptance

Sign-Off/Acceptance may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0081`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "sign-off-acceptance",
  "document_name": "sign-off/acceptance",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

### Change Request

Change Request may provide or verify information needed for Virtual offices. The document-intelligence layer should classify the file, capture issuer, date, revision, language, validity and relevant fields, preserve the original, and record conflicts with customer statements or other documents. The file must not be treated as approved, current or applicable merely because it was uploaded.

- Record ID: `QD-KB-031-virtual-offices-documents-document_requirement-0082`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "document_key": "change-request",
  "document_name": "change request",
  "extract": [
    "issuer",
    "date",
    "revision",
    "scope",
    "quantities",
    "requirements",
    "exceptions",
    "approval status"
  ],
  "validation": [
    "file integrity",
    "revision",
    "applicability",
    "expiry if relevant"
  ]
}
```

## Uae Regulations

### Federal Decree-Law on Commercial Companies

For Virtual offices, consult Federal Decree-Law on Commercial Companies when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0083`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-COMMERCIAL-COMPANIES

```json
{
  "source_id": "UAE-COMMERCIAL-COMPANIES",
  "publisher": "UAE Legislation",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law No. 50 of 2022 on Commercial Transactions

For Virtual offices, consult Federal Decree-Law No. 50 of 2022 on Commercial Transactions when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0084`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "source_id": "UAE-COMMERCIAL-TRANSACTIONS",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law on Electronic Transactions and Trust Services

For Virtual offices, consult Federal Decree-Law on Electronic Transactions and Trust Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0085`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-ELECTRONIC-TRANSACTIONS

```json
{
  "source_id": "UAE-ELECTRONIC-TRANSACTIONS",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

For Virtual offices, consult Federal Decree-Law No. 45 of 2021 on Protection of Personal Data when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0086`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021

```json
{
  "source_id": "UAE-PDPL-45-2021",
  "publisher": "UAE Legislation",
  "source_type": "federal_law",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### UAE Consumer Protection Legislation

For Virtual offices, consult UAE Consumer Protection Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0087`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION

```json
{
  "source_id": "UAE-CONSUMER-PROTECTION",
  "publisher": "UAE Legislation / Ministry of Economy",
  "source_type": "federal_law_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### MOHRE Services, Labour Guidance and Establishment Requirements

For Virtual offices, consult MOHRE Services, Labour Guidance and Establishment Requirements when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0088`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOHRE

```json
{
  "source_id": "UAE-MOHRE",
  "publisher": "Ministry of Human Resources and Emiratisation",
  "source_type": "government_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### VAT Guides and Legislation

For Virtual offices, consult VAT Guides and Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0089`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-FTA-VAT

```json
{
  "source_id": "UAE-FTA-VAT",
  "publisher": "Federal Tax Authority",
  "source_type": "tax_authority_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Corporate Tax Guides and Legislation

For Virtual offices, consult Corporate Tax Guides and Legislation when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0090`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-FTA-CT

```json
{
  "source_id": "UAE-FTA-CT",
  "publisher": "Federal Tax Authority",
  "source_type": "tax_authority_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Ministry of Justice Legal, Notary and Attestation Services

For Virtual offices, consult Ministry of Justice Legal, Notary and Attestation Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0091`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOJ

```json
{
  "source_id": "UAE-MOJ",
  "publisher": "UAE Ministry of Justice",
  "source_type": "government_legal_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Intellectual Property and Trademark Services

For Virtual offices, consult Intellectual Property and Trademark Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0092`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-MOE-IP

```json
{
  "source_id": "UAE-MOE-IP",
  "publisher": "UAE Ministry of Economy",
  "source_type": "government_ip_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Business and Event Licensing Services

For Virtual offices, consult Dubai Business and Event Licensing Services when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0093`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DET-EVENTS

```json
{
  "source_id": "UAE-DET-EVENTS",
  "publisher": "Dubai Department of Economy and Tourism",
  "source_type": "government_business_events_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

### Dubai Building Code 2021

For Virtual offices, consult Dubai Building Code 2021 when the jurisdiction, activity or technical/professional scope makes it applicable. The runtime must retrieve only the relevant approved internal extract, record the source version and date, and identify any project-specific authority or regulator check. The agent must not infer that a general source grants a licence, product approval, permit, professional opinion or acceptance for the customer’s project.

- Record ID: `QD-KB-031-virtual-offices-uae_regulations-source_activation-0094`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2026-10-31`
- Sources: UAE-DM-DBC-2021

```json
{
  "source_id": "UAE-DM-DBC-2021",
  "publisher": "Dubai Municipality",
  "source_type": "government_code_portal",
  "activation": "conditional by jurisdiction and scope",
  "legal_effect": "reference only until verified"
}
```

## Commercial Pricing

### Cost driver: quantity/volume/duration and unit basis

Quantity/Volume/Duration And Unit Basis can materially affect the price or fee for Virtual offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-virtual-offices-commercial_pricing-cost_driver-0095`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "quantity/volume/duration and unit basis",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: technical or service performance

Technical Or Service Performance can materially affect the price or fee for Virtual offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-virtual-offices-commercial_pricing-cost_driver-0097`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "technical or service performance",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: brand/provider/accreditation constraints

Brand/Provider/Accreditation Constraints can materially affect the price or fee for Virtual offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-virtual-offices-commercial_pricing-cost_driver-0099`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "brand/provider/accreditation constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: customization and integration

Customization And Integration can materially affect the price or fee for Virtual offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-virtual-offices-commercial_pricing-cost_driver-0101`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "customization and integration",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: documents, approvals and professional input

Documents, Approvals And Professional Input can materially affect the price or fee for Virtual offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-virtual-offices-commercial_pricing-cost_driver-0103`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "documents, approvals and professional input",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: delivery or mobilization urgency

Delivery Or Mobilization Urgency can materially affect the price or fee for Virtual offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-virtual-offices-commercial_pricing-cost_driver-0105`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "delivery or mobilization urgency",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: site, logistics or access constraints

Site, Logistics Or Access Constraints can materially affect the price or fee for Virtual offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-virtual-offices-commercial_pricing-cost_driver-0107`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "site, logistics or access constraints",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: testing, acceptance and reporting

Testing, Acceptance And Reporting can materially affect the price or fee for Virtual offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-virtual-offices-commercial_pricing-cost_driver-0109`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "testing, acceptance and reporting",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: warranty, support and lifecycle

Warranty, Support And Lifecycle can materially affect the price or fee for Virtual offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-virtual-offices-commercial_pricing-cost_driver-0111`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "warranty, support and lifecycle",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

### Cost driver: currency, tax, payment and contract terms

Currency, Tax, Payment And Contract Terms can materially affect the price or fee for Virtual offices. The platform should capture the relevant field before comparison, but must not invent a market rate. When the driver is unknown, the RFQ should require suppliers to state the assumption, unit, validity period and impact of any change. Price learning should come from time-stamped normalized quotations and completed transactions, not static narrative estimates.

- Record ID: `QD-KB-031-virtual-offices-commercial_pricing-cost_driver-0113`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "driver": "currency, tax, payment and contract terms",
  "exact_price_prediction_allowed": false,
  "unknown_behavior": "supplier assumption required"
}
```

## Customer Tradeoffs

### Customer trade-off: quantity/volume/duration and unit basis

Choices relating to quantity/volume/duration and unit basis may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-virtual-offices-customer_tradeoffs-tradeoff-0096`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "quantity/volume/duration and unit basis",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: technical or service performance

Choices relating to technical or service performance may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-virtual-offices-customer_tradeoffs-tradeoff-0098`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "technical or service performance",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: brand/provider/accreditation constraints

Choices relating to brand/provider/accreditation constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-virtual-offices-customer_tradeoffs-tradeoff-0100`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "brand/provider/accreditation constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: customization and integration

Choices relating to customization and integration may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-virtual-offices-customer_tradeoffs-tradeoff-0102`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "customization and integration",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: documents, approvals and professional input

Choices relating to documents, approvals and professional input may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-virtual-offices-customer_tradeoffs-tradeoff-0104`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "documents, approvals and professional input",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: delivery or mobilization urgency

Choices relating to delivery or mobilization urgency may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-virtual-offices-customer_tradeoffs-tradeoff-0106`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "delivery or mobilization urgency",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: site, logistics or access constraints

Choices relating to site, logistics or access constraints may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-virtual-offices-customer_tradeoffs-tradeoff-0108`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "site, logistics or access constraints",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: testing, acceptance and reporting

Choices relating to testing, acceptance and reporting may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-virtual-offices-customer_tradeoffs-tradeoff-0110`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "testing, acceptance and reporting",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: warranty, support and lifecycle

Choices relating to warranty, support and lifecycle may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-virtual-offices-customer_tradeoffs-tradeoff-0112`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "warranty, support and lifecycle",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

### Customer trade-off: currency, tax, payment and contract terms

Choices relating to currency, tax, payment and contract terms may trade lower initial cost against quality, performance, speed, risk, support, flexibility or total lifecycle cost. The agent should explain the decision in neutral language, present comparable alternatives where allowed and disclose approval or compatibility risks. It should not select an option on behalf of the customer when professional judgment or material risk is involved.

- Record ID: `QD-KB-031-virtual-offices-customer_tradeoffs-tradeoff-0114`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "tradeoff": "currency, tax, payment and contract terms",
  "presentation": "neutral side-by-side",
  "automatic_selection": false
}
```

## Risk

### Risk: wrong subcategory or misunderstood intent

In Virtual offices, wrong subcategory or misunderstood intent can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-virtual-offices-risk-risk_control-0115`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "wrong subcategory or misunderstood intent",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: incomplete scope or quantity basis

In Virtual offices, incomplete scope or quantity basis can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-virtual-offices-risk-risk_control-0116`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "incomplete scope or quantity basis",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: conflicting customer text and documents

In Virtual offices, conflicting customer text and documents can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-virtual-offices-risk-risk_control-0117`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "conflicting customer text and documents",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: ineligible or unverified supplier

In Virtual offices, ineligible or unverified supplier can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-virtual-offices-risk-risk_control-0118`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "ineligible or unverified supplier",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unapproved substitute or provider

In Virtual offices, unapproved substitute or provider can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-virtual-offices-risk-risk_control-0119`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unapproved substitute or provider",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: missing regulatory or contractual requirement

In Virtual offices, missing regulatory or contractual requirement can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-virtual-offices-risk-risk_control-0120`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "missing regulatory or contractual requirement",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: hidden exclusions or recurring charges

In Virtual offices, hidden exclusions or recurring charges can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-virtual-offices-risk-risk_control-0121`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "hidden exclusions or recurring charges",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: unrealistic schedule

In Virtual offices, unrealistic schedule can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-virtual-offices-risk-risk_control-0122`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "unrealistic schedule",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: data/confidentiality exposure

In Virtual offices, data/confidentiality exposure can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-virtual-offices-risk-risk_control-0123`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "data/confidentiality exposure",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

### Risk: professional decision outside agent authority

In Virtual offices, professional decision outside agent authority can make the inquiry misleading, unsafe, non-compliant, commercially incomparable or impossible to deliver. The control is to preserve evidence, expose uncertainty, ask the relevant clarification, activate applicable sources, apply eligibility and completeness gates, and escalate unresolved professional or authority issues. The system must fail closed for privacy, safety, legal, regulated or compatibility-critical conditions.

- Record ID: `QD-KB-031-virtual-offices-risk-risk_control-0124`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "risk": "professional decision outside agent authority",
  "controls": [
    "preserve evidence",
    "clarify",
    "retrieve sources",
    "validate",
    "escalate",
    "fail closed where critical"
  ]
}
```

## Best Practices

### Best practice: classify before asking technical questions

For Virtual offices, the system should classify before asking technical questions. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-virtual-offices-best_practices-qualification_best_practice-0125`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "classify before asking technical questions",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: ask plain-language questions first

For Virtual offices, the system should ask plain-language questions first. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-virtual-offices-best_practices-qualification_best_practice-0126`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "ask plain-language questions first",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: reuse answers from documents

For Virtual offices, the system should reuse answers from documents. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-virtual-offices-best_practices-qualification_best_practice-0127`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "reuse answers from documents",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: show why each question matters

For Virtual offices, the system should show why each question matters. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-virtual-offices-best_practices-qualification_best_practice-0128`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "show why each question matters",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: separate mandatory from optional

For Virtual offices, the system should separate mandatory from optional. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-virtual-offices-best_practices-qualification_best_practice-0129`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "separate mandatory from optional",
  "adaptive": true,
  "customer_friendly": true
}
```

### Best practice: make supplier assumptions visible

For Virtual offices, the system should make supplier assumptions visible. The objective is not to interrogate the customer with every possible field, but to reach a quote-ready brief using the minimum adaptive sequence supported by evidence. Questions should be skipped when a trusted document already answers them, repeated only when conflict exists, and phrased in accessible English or Arabic while storing normalized values for suppliers.

- Record ID: `QD-KB-031-virtual-offices-best_practices-qualification_best_practice-0130`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "practice": "make supplier assumptions visible",
  "adaptive": true,
  "customer_friendly": true
}
```

## Troubleshooting

### Troubleshooting — Customer wording fits more than one category or subcategory.

Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed. This recovery path applies to Virtual offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-virtual-offices-troubleshooting-recovery_guidance-0131`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "unclear_intent",
  "problem": "Customer wording fits more than one category or subcategory.",
  "guidance": "Rank candidates, show the ambiguity internally, ask one outcome-based clarification and preserve cross-category scope when needed.",
  "audit_required": true
}
```

### Troubleshooting — Customer has no formal documents.

Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility. This recovery path applies to Virtual offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-virtual-offices-troubleshooting-recovery_guidance-0132`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "missing_documents",
  "problem": "Customer has no formal documents.",
  "guidance": "Collect minimum plain-language fields, label the brief budgetary or preliminary, and request documents only when they materially affect supplier pricing or eligibility.",
  "audit_required": true
}
```

### Troubleshooting — Uploaded files disagree with each other or the customer message.

Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts. This recovery path applies to Virtual offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-virtual-offices-troubleshooting-recovery_guidance-0133`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "conflicting_documents",
  "problem": "Uploaded files disagree with each other or the customer message.",
  "guidance": "Extract all conflicting values with revision references, ask which source governs, and prevent automatic dispatch for critical conflicts.",
  "audit_required": true
}
```

### Troubleshooting — Required date may be unrealistic.

Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk. This recovery path applies to Virtual offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-virtual-offices-troubleshooting-recovery_guidance-0134`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "urgent_request",
  "problem": "Required date may be unrealistic.",
  "guidance": "Verify stock/capacity, approval and mobilization lead times; request phased, temporary or alternative options and show schedule risk.",
  "audit_required": true
}
```

### Troubleshooting — Supplier proposes an alternative.

Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically. This recovery path applies to Virtual offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-virtual-offices-troubleshooting-recovery_guidance-0135`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "supplier_deviation",
  "problem": "Supplier proposes an alternative.",
  "guidance": "Require a compliance/deviation matrix, disclose impact on approval, performance, warranty and schedule, and never mark it equal automatically.",
  "audit_required": true
}
```

### Troubleshooting — Applicable regulator or requirement is uncertain.

Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review. This recovery path applies to Virtual offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-virtual-offices-troubleshooting-recovery_guidance-0136`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "regulatory_uncertainty",
  "problem": "Applicable regulator or requirement is uncertain.",
  "guidance": "Activate the likely source sets, hold the affected decision and escalate to qualified authority/legal/professional review.",
  "audit_required": true
}
```

### Troubleshooting — Files or messages contain personal, confidential or identifying data.

Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass. This recovery path applies to Virtual offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-virtual-offices-troubleshooting-recovery_guidance-0137`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "data_privacy",
  "problem": "Files or messages contain personal, confidential or identifying data.",
  "guidance": "Apply redaction/access controls, minimize supplier-visible data, retain source lineage and block dispatch until privacy checks pass.",
  "audit_required": true
}
```

### Troubleshooting — Supplier evidence, test, licence or certificate is expired or mismatched.

Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved. This recovery path applies to Virtual offices; log the trigger, evidence, action, owner and outcome so the system can learn without silently modifying approved regulated knowledge.

- Record ID: `QD-KB-031-virtual-offices-troubleshooting-recovery_guidance-0138`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "key": "quality_failure",
  "problem": "Supplier evidence, test, licence or certificate is expired or mismatched.",
  "guidance": "Request current exact-scope evidence, verify against a live registry where available and mark supplier/item ineligible until resolved.",
  "audit_required": true
}
```

## Inquiry Qualification

### Which emirate, free zone, master developer or authority governs the request?

Ask in plain language: Which emirate, free zone, master developer or authority governs the request? Arabic draft: ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0139`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-project-emirate",
  "question_en": "Which emirate, free zone, master developer or authority governs the request?",
  "question_ar": "ما الإمارة أو المنطقة الحرة أو المطور أو الجهة التي تحكم الطلب؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "project-emirate",
  "order": 10,
  "confidence_contribution": 0.03
}
```

### Ask when Which emirate, free zone, master developer or authority governs the request? is missing

When the normalized field project-emirate is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0140`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-project-emirate",
  "priority": 999,
  "when": {
    "all": [
      {
        "field": "project-emirate",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-project-emirate"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What site, client, facility, user group or operating context applies?

Ask in plain language: What site, client, facility, user group or operating context applies? Arabic draft: ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0141`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-site-or-client-context",
  "question_en": "What site, client, facility, user group or operating context applies?",
  "question_ar": "ما الموقع أو العميل أو المنشأة أو مجموعة المستخدمين أو السياق التشغيلي؟",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "site-or-client-context",
  "order": 20,
  "confidence_contribution": 0.03
}
```

### Ask when What site, client, facility, user group or operating context applies? is missing

When the normalized field site-or-client-context is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0142`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-site-or-client-context",
  "priority": 998,
  "when": {
    "all": [
      {
        "field": "site-or-client-context",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-site-or-client-context"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### In plain language, what outcome, product, service or problem should the supplier address?

Ask in plain language: In plain language, what outcome, product, service or problem should the supplier address? Arabic draft: بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0143`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-exact-need",
  "question_en": "In plain language, what outcome, product, service or problem should the supplier address?",
  "question_ar": "بلغة بسيطة، ما النتيجة أو المنتج أو الخدمة أو المشكلة التي يجب على المورد معالجتها؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-need",
  "order": 30,
  "confidence_contribution": 0.03
}
```

### Ask when In plain language, what outcome, product, service or problem should the supplier address? is missing

When the normalized field exact-need is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0144`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-exact-need",
  "priority": 997,
  "when": {
    "all": [
      {
        "field": "exact-need",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-exact-need"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?

Ask in plain language: Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? Arabic draft: هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0145`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-scope-mode",
  "question_en": "Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey?",
  "question_ar": "هل المطلوب توريد فقط أو توصيل أو تركيب أو تنفيذ أو خدمة مدارة أو صيانة أو تسليم مفتاح؟",
  "expected_answer_type": "multi_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-mode",
  "order": 40,
  "confidence_contribution": 0.03
}
```

### Ask when Is the requirement supply-only, delivery, installation, implementation, managed service, maintenance or full turnkey? is missing

When the normalized field scope-mode is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0146`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-scope-mode",
  "priority": 996,
  "when": {
    "all": [
      {
        "field": "scope-mode",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-scope-mode"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What quantity, capacity, duration, users, sites or commercial unit should suppliers price?

Ask in plain language: What quantity, capacity, duration, users, sites or commercial unit should suppliers price? Arabic draft: ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0147`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-quantity-unit",
  "question_en": "What quantity, capacity, duration, users, sites or commercial unit should suppliers price?",
  "question_ar": "ما الكمية أو السعة أو المدة أو المستخدمون أو المواقع أو الوحدة التجارية للتسعير؟",
  "expected_answer_type": "structured_number",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "quantity-unit",
  "order": 50,
  "confidence_contribution": 0.03
}
```

### Ask when What quantity, capacity, duration, users, sites or commercial unit should suppliers price? is missing

When the normalized field quantity-unit is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0148`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-quantity-unit",
  "priority": 995,
  "when": {
    "all": [
      {
        "field": "quantity-unit",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-quantity-unit"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What delivery, implementation, mobilisation or completion date is required?

Ask in plain language: What delivery, implementation, mobilisation or completion date is required? Arabic draft: ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0149`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-required-date",
  "question_en": "What delivery, implementation, mobilisation or completion date is required?",
  "question_ar": "ما تاريخ التوريد أو التنفيذ أو التعبئة أو الإنجاز المطلوب؟",
  "expected_answer_type": "date_or_period",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "required-date",
  "order": 60,
  "confidence_contribution": 0.03
}
```

### Ask when What delivery, implementation, mobilisation or completion date is required? is missing

When the normalized field required-date is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0150`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-required-date",
  "priority": 994,
  "when": {
    "all": [
      {
        "field": "required-date",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-required-date"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which drawings, specifications, schedules, contracts, policies or other documents govern?

Ask in plain language: Which drawings, specifications, schedules, contracts, policies or other documents govern? Arabic draft: ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0151`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-governing-documents",
  "question_en": "Which drawings, specifications, schedules, contracts, policies or other documents govern?",
  "question_ar": "ما المخططات أو المواصفات أو الجداول أو العقود أو السياسات أو المستندات الحاكمة؟",
  "expected_answer_type": "document_list",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "governing-documents",
  "order": 70,
  "confidence_contribution": 0.012
}
```

### Is there a named brand/provider, approved list, required accreditation or approved-equal policy?

Ask in plain language: Is there a named brand/provider, approved list, required accreditation or approved-equal policy? Arabic draft: هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0152`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-brand-or-provider-policy",
  "question_en": "Is there a named brand/provider, approved list, required accreditation or approved-equal policy?",
  "question_ar": "هل توجد علامة أو مزود محدد أو قائمة معتمدة أو اعتماد مطلوب أو سياسة بديل معتمد؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "brand-or-provider-policy",
  "order": 80,
  "confidence_contribution": 0.012
}
```

### Is there a budget range, currency, payment structure, quotation validity or contractual condition?

Ask in plain language: Is there a budget range, currency, payment structure, quotation validity or contractual condition? Arabic draft: هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0153`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-budget-and-commercial",
  "question_en": "Is there a budget range, currency, payment structure, quotation validity or contractual condition?",
  "question_ar": "هل توجد ميزانية أو عملة أو هيكل دفع أو مدة صلاحية أو شرط تعاقدي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "budget-and-commercial",
  "order": 90,
  "confidence_contribution": 0.012
}
```

### Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?

Ask in plain language: Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? Arabic draft: هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0154`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-existing-condition",
  "question_en": "Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement?",
  "question_ar": "هل الطلب جديد أو استبدال أو توسعة أو إصلاح أو ترحيل أو استمرار لترتيب قائم؟",
  "expected_answer_type": "single_select",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "existing-condition",
  "order": 100,
  "confidence_contribution": 0.03
}
```

### Ask when Is this a new requirement, replacement, expansion, repair, migration or continuation of an existing arrangement? is missing

When the normalized field existing-condition is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0155`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-existing-condition",
  "priority": 990,
  "when": {
    "all": [
      {
        "field": "existing-condition",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-existing-condition"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Are there confidentiality, anonymization, data, site-access or communication restrictions?

Ask in plain language: Are there confidentiality, anonymization, data, site-access or communication restrictions? Arabic draft: هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0156`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-contact-restrictions",
  "question_en": "Are there confidentiality, anonymization, data, site-access or communication restrictions?",
  "question_ar": "هل توجد قيود سرية أو إخفاء هوية أو بيانات أو وصول للموقع أو اتصال؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "contact-restrictions",
  "order": 110,
  "confidence_contribution": 0.012
}
```

### What acceptance, testing, reporting, warranty, support and handover are required?

Ask in plain language: What acceptance, testing, reporting, warranty, support and handover are required? Arabic draft: ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0157`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-acceptance-warranty",
  "question_en": "What acceptance, testing, reporting, warranty, support and handover are required?",
  "question_ar": "ما الاختبار والتقارير والضمان والدعم والتسليم المطلوب؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "acceptance-warranty",
  "order": 120,
  "confidence_contribution": 0.03
}
```

### Ask when What acceptance, testing, reporting, warranty, support and handover are required? is missing

When the normalized field acceptance-warranty is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0158`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-acceptance-warranty",
  "priority": 988,
  "when": {
    "all": [
      {
        "field": "acceptance-warranty",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-acceptance-warranty"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What client entity, ownership, licence, jurisdiction and operating activity are involved?

Ask in plain language: What client entity, ownership, licence, jurisdiction and operating activity are involved? Arabic draft: ما جهة العميل والملكية والترخيص والاختصاص والنشاط التشغيلي؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0159`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-client-entity",
  "question_en": "What client entity, ownership, licence, jurisdiction and operating activity are involved?",
  "question_ar": "ما جهة العميل والملكية والترخيص والاختصاص والنشاط التشغيلي؟",
  "expected_answer_type": "document_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "client-entity",
  "order": 130,
  "confidence_contribution": 0.03
}
```

### Ask when What client entity, ownership, licence, jurisdiction and operating activity are involved? is missing

When the normalized field client-entity is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0160`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-client-entity",
  "priority": 987,
  "when": {
    "all": [
      {
        "field": "client-entity",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-client-entity"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What decision, problem, transaction, compliance outcome or business objective is required?

Ask in plain language: What decision, problem, transaction, compliance outcome or business objective is required? Arabic draft: ما القرار أو المشكلة أو المعاملة أو نتيجة الامتثال أو الهدف التجاري المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0161`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-problem-outcome",
  "question_en": "What decision, problem, transaction, compliance outcome or business objective is required?",
  "question_ar": "ما القرار أو المشكلة أو المعاملة أو نتيجة الامتثال أو الهدف التجاري المطلوب؟",
  "expected_answer_type": "text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "problem-outcome",
  "order": 140,
  "confidence_contribution": 0.03
}
```

### Ask when What decision, problem, transaction, compliance outcome or business objective is required? is missing

When the normalized field problem-outcome is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0162`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-problem-outcome",
  "priority": 986,
  "when": {
    "all": [
      {
        "field": "problem-outcome",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-problem-outcome"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What work is included, excluded, assumed or dependent on third parties?

Ask in plain language: What work is included, excluded, assumed or dependent on third parties? Arabic draft: ما الأعمال المشمولة والمستبعدة والافتراضات والاعتماد على أطراف أخرى؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0163`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-scope-exclusions",
  "question_en": "What work is included, excluded, assumed or dependent on third parties?",
  "question_ar": "ما الأعمال المشمولة والمستبعدة والافتراضات والاعتماد على أطراف أخرى؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "scope-exclusions",
  "order": 150,
  "confidence_contribution": 0.03
}
```

### Ask when What work is included, excluded, assumed or dependent on third parties? is missing

When the normalized field scope-exclusions is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0164`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-scope-exclusions",
  "priority": 985,
  "when": {
    "all": [
      {
        "field": "scope-exclusions",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-scope-exclusions"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What records, contracts, accounts, data, correspondence or evidence are available?

Ask in plain language: What records, contracts, accounts, data, correspondence or evidence are available? Arabic draft: ما السجلات أو العقود أو الحسابات أو البيانات أو المراسلات أو الأدلة المتاحة؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0165`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-records-evidence",
  "question_en": "What records, contracts, accounts, data, correspondence or evidence are available?",
  "question_ar": "ما السجلات أو العقود أو الحسابات أو البيانات أو المراسلات أو الأدلة المتاحة؟",
  "expected_answer_type": "document_list",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "records-evidence",
  "order": 160,
  "confidence_contribution": 0.03
}
```

### Ask when What records, contracts, accounts, data, correspondence or evidence are available? is missing

When the normalized field records-evidence is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0166`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-records-evidence",
  "priority": 984,
  "when": {
    "all": [
      {
        "field": "records-evidence",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-records-evidence"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### What deliverables, language, format, review cycle and sign-off are required?

Ask in plain language: What deliverables, language, format, review cycle and sign-off are required? Arabic draft: ما المخرجات واللغة والصيغة ودورة المراجعة والتوقيع المطلوب؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0167`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-deliverables-format",
  "question_en": "What deliverables, language, format, review cycle and sign-off are required?",
  "question_ar": "ما المخرجات واللغة والصيغة ودورة المراجعة والتوقيع المطلوب؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "deliverables-format",
  "order": 170,
  "confidence_contribution": 0.03
}
```

### Ask when What deliverables, language, format, review cycle and sign-off are required? is missing

When the normalized field deliverables-format is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0168`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-deliverables-format",
  "priority": 983,
  "when": {
    "all": [
      {
        "field": "deliverables-format",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-deliverables-format"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which regulator, court, authority, bank, investor or deadline controls the work?

Ask in plain language: Which regulator, court, authority, bank, investor or deadline controls the work? Arabic draft: ما الجهة التنظيمية أو المحكمة أو السلطة أو البنك أو المستثمر أو الموعد الحاكم؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0169`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-regulator-deadline",
  "question_en": "Which regulator, court, authority, bank, investor or deadline controls the work?",
  "question_ar": "ما الجهة التنظيمية أو المحكمة أو السلطة أو البنك أو المستثمر أو الموعد الحاكم؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "regulator-deadline",
  "order": 180,
  "confidence_contribution": 0.012
}
```

### What conflict checks, confidentiality, privilege, data access and retention rules apply?

Ask in plain language: What conflict checks, confidentiality, privilege, data access and retention rules apply? Arabic draft: ما فحوص التعارض والسرية والامتياز والوصول للبيانات والاحتفاظ؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0170`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-conflict-confidentiality",
  "question_en": "What conflict checks, confidentiality, privilege, data access and retention rules apply?",
  "question_ar": "ما فحوص التعارض والسرية والامتياز والوصول للبيانات والاحتفاظ؟",
  "expected_answer_type": "document_or_text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "conflict-confidentiality",
  "order": 190,
  "confidence_contribution": 0.012
}
```

### What fee model, expenses, assumptions, milestones, retainer and change-control basis apply?

Ask in plain language: What fee model, expenses, assumptions, milestones, retainer and change-control basis apply? Arabic draft: ما نموذج الأتعاب والمصروفات والافتراضات والمراحل والدفعة والتغيير؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0171`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-fee-model",
  "question_en": "What fee model, expenses, assumptions, milestones, retainer and change-control basis apply?",
  "question_ar": "ما نموذج الأتعاب والمصروفات والافتراضات والمراحل والدفعة والتغيير؟",
  "expected_answer_type": "document_or_table",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "fee-model",
  "order": 200,
  "confidence_contribution": 0.03
}
```

### Ask when What fee model, expenses, assumptions, milestones, retainer and change-control basis apply? is missing

When the normalized field fee-model is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0172`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-fee-model",
  "priority": 980,
  "when": {
    "all": [
      {
        "field": "fee-model",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-fee-model"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the location/capacity requirements for Virtual offices.

Ask in plain language: Please clarify the location/capacity requirements for Virtual offices. Arabic draft: يرجى توضيح متطلبات location/capacity الخاصة بـ Virtual offices. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0173`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-facet-01",
  "question_en": "Please clarify the location/capacity requirements for Virtual offices.",
  "question_ar": "يرجى توضيح متطلبات location/capacity الخاصة بـ Virtual offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-01",
  "order": 210,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the location/capacity requirements for Virtual offices. is missing

When the normalized field facet-01 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0174`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-facet-01",
  "priority": 979,
  "when": {
    "all": [
      {
        "field": "facet-01",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-facet-01"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the workspace type requirements for Virtual offices.

Ask in plain language: Please clarify the workspace type requirements for Virtual offices. Arabic draft: يرجى توضيح متطلبات workspace type الخاصة بـ Virtual offices. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0175`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-facet-02",
  "question_en": "Please clarify the workspace type requirements for Virtual offices.",
  "question_ar": "يرجى توضيح متطلبات workspace type الخاصة بـ Virtual offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-02",
  "order": 220,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the workspace type requirements for Virtual offices. is missing

When the normalized field facet-02 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0176`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-facet-02",
  "priority": 978,
  "when": {
    "all": [
      {
        "field": "facet-02",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-facet-02"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the licence/address need requirements for Virtual offices.

Ask in plain language: Please clarify the licence/address need requirements for Virtual offices. Arabic draft: يرجى توضيح متطلبات licence/address need الخاصة بـ Virtual offices. This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0177`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-facet-03",
  "question_en": "Please clarify the licence/address need requirements for Virtual offices.",
  "question_ar": "يرجى توضيح متطلبات licence/address need الخاصة بـ Virtual offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-03",
  "order": 230,
  "confidence_contribution": 0.03
}
```

### Ask when Please clarify the licence/address need requirements for Virtual offices. is missing

When the normalized field facet-03 is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0178`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-facet-03",
  "priority": 977,
  "when": {
    "all": [
      {
        "field": "facet-03",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-facet-03"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Please clarify the services/meeting rooms requirements for Virtual offices.

Ask in plain language: Please clarify the services/meeting rooms requirements for Virtual offices. Arabic draft: يرجى توضيح متطلبات services/meeting rooms الخاصة بـ Virtual offices. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0179`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-facet-04",
  "question_en": "Please clarify the services/meeting rooms requirements for Virtual offices.",
  "question_ar": "يرجى توضيح متطلبات services/meeting rooms الخاصة بـ Virtual offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-04",
  "order": 240,
  "confidence_contribution": 0.012
}
```

### Please clarify the access/security requirements for Virtual offices.

Ask in plain language: Please clarify the access/security requirements for Virtual offices. Arabic draft: يرجى توضيح متطلبات access/security الخاصة بـ Virtual offices. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0180`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-facet-05",
  "question_en": "Please clarify the access/security requirements for Virtual offices.",
  "question_ar": "يرجى توضيح متطلبات access/security الخاصة بـ Virtual offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-05",
  "order": 250,
  "confidence_contribution": 0.012
}
```

### Please clarify the commercial terms requirements for Virtual offices.

Ask in plain language: Please clarify the commercial terms requirements for Virtual offices. Arabic draft: يرجى توضيح متطلبات commercial terms الخاصة بـ Virtual offices. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0181`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-facet-06",
  "question_en": "Please clarify the commercial terms requirements for Virtual offices.",
  "question_ar": "يرجى توضيح متطلبات commercial terms الخاصة بـ Virtual offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-06",
  "order": 260,
  "confidence_contribution": 0.012
}
```

### Please clarify the support/exit requirements for Virtual offices.

Ask in plain language: Please clarify the support/exit requirements for Virtual offices. Arabic draft: يرجى توضيح متطلبات support/exit الخاصة بـ Virtual offices. This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0182`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-facet-07",
  "question_en": "Please clarify the support/exit requirements for Virtual offices.",
  "question_ar": "يرجى توضيح متطلبات support/exit الخاصة بـ Virtual offices.",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "facet-07",
  "order": 270,
  "confidence_contribution": 0.012
}
```

### Which exact Virtual offices product, service, variant or outcome best matches your need?

Ask in plain language: Which exact Virtual offices product, service, variant or outcome best matches your need? Arabic draft: ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Virtual offices التي تطابق حاجتك؟ This field is mandatory. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0183`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-exact-subtype",
  "question_en": "Which exact Virtual offices product, service, variant or outcome best matches your need?",
  "question_ar": "ما المنتج أو الخدمة أو النوع أو النتيجة الدقيقة ضمن Virtual offices التي تطابق حاجتك؟",
  "expected_answer_type": "single_or_text",
  "mandatory": true,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "block_dispatch_and_ask",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "exact-subtype",
  "order": 280,
  "confidence_contribution": 0.03
}
```

### Ask when Which exact Virtual offices product, service, variant or outcome best matches your need? is missing

When the normalized field exact-subtype is missing, ask the linked approved question, set the inquiry status to needs_information and prevent supplier dispatch until an answer or governing document is available. Do not let a language model skip this rule because the customer sounds confident.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0184`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-ask-exact-subtype",
  "priority": 972,
  "when": {
    "all": [
      {
        "field": "exact-subtype",
        "operator": "is_missing"
      }
    ]
  },
  "then": [
    {
      "action": "ask_question",
      "question_id": "Q-031-virtual-offices-exact-subtype"
    },
    {
      "action": "set_status",
      "value": "needs_information"
    },
    {
      "action": "block_dispatch"
    }
  ]
}
```

### Which details about Virtual offices are still unknown and should suppliers assume or recommend?

Ask in plain language: Which details about Virtual offices are still unknown and should suppliers assume or recommend? Arabic draft: ما التفاصيل غير المعروفة في Virtual offices التي يجب على الموردين افتراضها أو التوصية بها؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0185`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-unknowns",
  "question_en": "Which details about Virtual offices are still unknown and should suppliers assume or recommend?",
  "question_ar": "ما التفاصيل غير المعروفة في Virtual offices التي يجب على الموردين افتراضها أو التوصية بها؟",
  "expected_answer_type": "text",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "unknowns",
  "order": 290,
  "confidence_contribution": 0.012
}
```

### Are alternatives allowed, and what must remain unchanged for Virtual offices?

Ask in plain language: Are alternatives allowed, and what must remain unchanged for Virtual offices? Arabic draft: هل البدائل مسموحة وما الذي يجب ألا يتغير في Virtual offices؟ This field is conditional or optional. It is needed to classify the request, identify supplier eligibility, normalize quotations and determine whether the inquiry is ready. Reuse a reliable answer already extracted from the customer message or documents. If the customer does not know, record unknown and either ask the supplier to state a visible assumption or block dispatch when the field is critical.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-qualification_question-0186`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "question_id": "Q-031-virtual-offices-alternatives",
  "question_en": "Are alternatives allowed, and what must remain unchanged for Virtual offices?",
  "question_ar": "هل البدائل مسموحة وما الذي يجب ألا يتغير في Virtual offices؟",
  "expected_answer_type": "text_or_document",
  "mandatory": false,
  "why_it_matters": "Required for routing, scope, eligibility, comparison or acceptance.",
  "missing_answer_behavior": "record_unknown_and_add_quote_assumption",
  "impact": [
    "routing",
    "scope",
    "eligibility",
    "price",
    "acceptance"
  ],
  "supplier_facing_field": "alternatives",
  "order": 300,
  "confidence_contribution": 0.012
}
```

### Low Routing Confidence

When {"field": "routing_confidence", "operator": "less_than", "value": 0.78} applies to Virtual offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0187`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-low-routing-confidence",
  "priority": 899,
  "when": {
    "all": [
      {
        "field": "routing_confidence",
        "operator": "less_than",
        "value": 0.78
      }
    ]
  },
  "then": [
    {
      "action": "ask_plain_language_clarification"
    },
    {
      "action": "preserve_candidate_routes"
    }
  ],
  "requires_human_review": false
}
```

### Multiple Routes

When {"field": "candidate_route_count", "operator": "greater_than", "value": 1} applies to Virtual offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0188`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-multiple-routes",
  "priority": 898,
  "when": {
    "all": [
      {
        "field": "candidate_route_count",
        "operator": "greater_than",
        "value": 1
      }
    ]
  },
  "then": [
    {
      "action": "ask_outcome_based_clarification"
    },
    {
      "action": "allow_multi_category_scope"
    }
  ],
  "requires_human_review": false
}
```

### Document Conflict

When {"field": "critical_document_conflict", "operator": "equals", "value": true} applies to Virtual offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0189`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-document-conflict",
  "priority": 897,
  "when": {
    "all": [
      {
        "field": "critical_document_conflict",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_dispatch"
    },
    {
      "action": "request_governing_revision"
    },
    {
      "action": "escalate"
    }
  ],
  "requires_human_review": true
}
```

### Regulated Scope

When {"field": "regulated_scope", "operator": "equals", "value": true} applies to Virtual offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0190`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS, UAE-ELECTRONIC-TRANSACTIONS, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION, UAE-MOHRE, UAE-FTA-VAT, UAE-FTA-CT, UAE-MOJ, UAE-MOE-IP, UAE-DET-EVENTS, UAE-DM-DBC-2021

```json
{
  "rule_id": "R-031-virtual-offices-regulated-scope",
  "priority": 896,
  "when": {
    "all": [
      {
        "field": "regulated_scope",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "activate_source_set",
      "source_ids": [
        "UAE-COMMERCIAL-COMPANIES",
        "UAE-COMMERCIAL-TRANSACTIONS",
        "UAE-ELECTRONIC-TRANSACTIONS",
        "UAE-PDPL-45-2021",
        "UAE-CONSUMER-PROTECTION",
        "UAE-MOHRE",
        "UAE-FTA-VAT",
        "UAE-FTA-CT",
        "UAE-MOJ",
        "UAE-MOE-IP",
        "UAE-DET-EVENTS",
        "UAE-DM-DBC-2021"
      ]
    },
    {
      "action": "require_current_approval_evidence"
    }
  ],
  "requires_human_review": false
}
```

### Approved Equal

When {"field": "brand_or_provider_policy", "operator": "contains", "value": "approved equal"} applies to Virtual offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0191`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-approved-equal",
  "priority": 895,
  "when": {
    "all": [
      {
        "field": "brand_or_provider_policy",
        "operator": "contains",
        "value": "approved equal"
      }
    ]
  },
  "then": [
    {
      "action": "require_compliance_matrix"
    },
    {
      "action": "require_deviation_disclosure"
    },
    {
      "action": "mark_approval_risk"
    }
  ],
  "requires_human_review": false
}
```

### Urgent Date

When {"field": "required_date", "operator": "within_days", "value": 14} applies to Virtual offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0192`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-urgent-date",
  "priority": 894,
  "when": {
    "all": [
      {
        "field": "required_date",
        "operator": "within_days",
        "value": 14
      }
    ]
  },
  "then": [
    {
      "action": "verify_stock_capacity_and_lead_time"
    },
    {
      "action": "request_phased_or_alternative_option"
    },
    {
      "action": "mark_schedule_risk"
    }
  ],
  "requires_human_review": false
}
```

### Personal Data

When {"field": "personal_or_confidential_data_detected", "operator": "equals", "value": true} applies to Virtual offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0193`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-personal-data",
  "priority": 893,
  "when": {
    "all": [
      {
        "field": "personal_or_confidential_data_detected",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "run_redaction_and_access_gate"
    },
    {
      "action": "block_supplier_visibility_until_pass"
    }
  ],
  "requires_human_review": false
}
```

### Professional Judgment

When {"field": "professional_judgment_required", "operator": "equals", "value": true} applies to Virtual offices, execute the listed deterministic actions. This rule controls workflow only; it does not replace professional judgment, authority acceptance or legal interpretation.

- Record ID: `QD-KB-031-virtual-offices-inquiry_qualification-decision_rule-0194`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "rule_id": "R-031-virtual-offices-professional-judgment",
  "priority": 892,
  "when": {
    "all": [
      {
        "field": "professional_judgment_required",
        "operator": "equals",
        "value": true
      }
    ]
  },
  "then": [
    {
      "action": "hold_automatic_decision"
    },
    {
      "action": "route_to_qualified_professional"
    }
  ],
  "requires_human_review": true
}
```

## Validation

### Validation — Route Confidence

For Virtual offices, routing confidence must meet threshold or clarification is required. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-virtual-offices-validation-validation_rule-0195`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-virtual-offices-route_confidence",
  "rule_text": "routing confidence must meet threshold or clarification is required",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Mandatory Fields

For Virtual offices, all mandatory fields must be answered or document-derived. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-virtual-offices-validation-validation_rule-0196`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-virtual-offices-mandatory_fields",
  "rule_text": "all mandatory fields must be answered or document-derived",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Quantity Unit

For Virtual offices, quantity/capacity/duration and unit must be normalized. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-virtual-offices-validation-validation_rule-0197`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-virtual-offices-quantity_unit",
  "rule_text": "quantity/capacity/duration and unit must be normalized",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Scope Boundaries

For Virtual offices, inclusions, exclusions and responsibility boundaries must be explicit. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-virtual-offices-validation-validation_rule-0198`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-virtual-offices-scope_boundaries",
  "rule_text": "inclusions, exclusions and responsibility boundaries must be explicit",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Document Revision

For Virtual offices, governing document revision and conflicts must be resolved. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-virtual-offices-validation-validation_rule-0199`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-virtual-offices-document_revision",
  "rule_text": "governing document revision and conflicts must be resolved",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Supplier Eligibility

For Virtual offices, supplier licence/capability/authorization must match. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-virtual-offices-validation-validation_rule-0200`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-virtual-offices-supplier_eligibility",
  "rule_text": "supplier licence/capability/authorization must match",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Regulatory Gate

For Virtual offices, applicable authority/source and evidence must be identified. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-virtual-offices-validation-validation_rule-0201`
- Status: `source_verified` | Confidence: `0.9` | Review after: `2027-01-31`
- Sources: UAE-COMMERCIAL-COMPANIES, UAE-COMMERCIAL-TRANSACTIONS

```json
{
  "validation_id": "V-031-virtual-offices-regulatory_gate",
  "rule_text": "applicable authority/source and evidence must be identified",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Commercial Comparability

For Virtual offices, currency, tax, validity, payment and schedule must be comparable. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-virtual-offices-validation-validation_rule-0202`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-virtual-offices-commercial_comparability",
  "rule_text": "currency, tax, validity, payment and schedule must be comparable",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "medium"
}
```

### Validation — Privacy Redaction

For Virtual offices, supplier-visible package must pass privacy/redaction controls. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-virtual-offices-validation-validation_rule-0203`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-virtual-offices-privacy_redaction",
  "rule_text": "supplier-visible package must pass privacy/redaction controls",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

### Validation — Professional Boundary

For Virtual offices, design/legal/medical/tax/financial approvals must remain outside autonomous authority. On failure, record the exact missing or conflicting evidence, request correction, block the affected decision or dispatch, and escalate where safety, privacy, regulated activity or professional responsibility is involved.

- Record ID: `QD-KB-031-virtual-offices-validation-validation_rule-0204`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "validation_id": "V-031-virtual-offices-professional_boundary",
  "rule_text": "design/legal/medical/tax/financial approvals must remain outside autonomous authority",
  "on_fail": [
    "flag_invalid",
    "request_correction",
    "block_affected_decision"
  ],
  "severity": "high"
}
```

## Scenario Test

### General public language

Setup: Customer asks informally for Virtual offices without technical wording. Expected behavior: Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-virtual-offices-scenario_test-scenario-0205`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-virtual-offices-001",
  "setup": "Customer asks informally for Virtual offices without technical wording.",
  "expected": "Router identifies likely route, asks one simple clarification and starts the minimum mandatory question flow.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Budget request with little evidence

Setup: Customer requests price for Virtual offices with no formal documents. Expected behavior: System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-virtual-offices-scenario_test-scenario-0206`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-virtual-offices-002",
  "setup": "Customer requests price for Virtual offices with no formal documents.",
  "expected": "System collects a minimum preliminary brief, labels assumptions and avoids claiming final technical/professional selection.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Attached document answers questions

Setup: Customer uploads a relevant schedule/specification for Virtual offices. Expected behavior: Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-virtual-offices-scenario_test-scenario-0207`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-virtual-offices-003",
  "setup": "Customer uploads a relevant schedule/specification for Virtual offices.",
  "expected": "Document layer extracts fields, cites the file/revision and skips already answered questions unless conflicts exist.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Conflicting evidence

Setup: Customer message and uploaded document disagree on Virtual offices. Expected behavior: System shows the conflict, asks which revision governs and blocks critical dispatch until resolved. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-virtual-offices-scenario_test-scenario-0208`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-virtual-offices-004",
  "setup": "Customer message and uploaded document disagree on Virtual offices.",
  "expected": "System shows the conflict, asks which revision governs and blocks critical dispatch until resolved.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Supplier proposes alternative

Setup: Supplier proposes a different product, provider or method for Virtual offices. Expected behavior: System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-virtual-offices-scenario_test-scenario-0209`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-virtual-offices-005",
  "setup": "Supplier proposes a different product, provider or method for Virtual offices.",
  "expected": "System requires compliance/deviation disclosure and does not mark the alternative equivalent automatically.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Urgent requirement

Setup: Customer needs Virtual offices sooner than normal sourcing/approval/implementation allows. Expected behavior: System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-virtual-offices-scenario_test-scenario-0210`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-virtual-offices-006",
  "setup": "Customer needs Virtual offices sooner than normal sourcing/approval/implementation allows.",
  "expected": "System verifies capacity and approvals, requests phased/temporary alternatives and marks schedule risk.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

### Regulated or professional issue

Setup: The request for Virtual offices needs authority, legal, medical, engineering, tax or other professional judgment. Expected behavior: System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person. The test passes only when the audit log records routing, evidence used, questions asked, rules fired, unresolved risks and final status without unsupported factual or professional claims.

- Record ID: `QD-KB-031-virtual-offices-scenario_test-scenario-0211`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "scenario_id": "T-031-virtual-offices-007",
  "setup": "The request for Virtual offices needs authority, legal, medical, engineering, tax or other professional judgment.",
  "expected": "System retrieves internal references, preserves facts and routes the decision to an appropriate qualified person.",
  "assertions": [
    "audit trail exists",
    "no unsupported claim",
    "correct route or clarification",
    "mandatory gate respected"
  ]
}
```

## Glossary

### Virtual offices

English term: Virtual offices. Arabic operational draft: متطلبات Virtual offices. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0212`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "Virtual offices",
  "term_ar": "متطلبات Virtual offices",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### scope of work

English term: scope of work. Arabic operational draft: نطاق العمل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0213`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "scope of work",
  "term_ar": "نطاق العمل",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### mandatory information

English term: mandatory information. Arabic operational draft: المعلومات الإلزامية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0214`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "mandatory information",
  "term_ar": "المعلومات الإلزامية",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### optional information

English term: optional information. Arabic operational draft: المعلومات الاختيارية. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0215`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "optional information",
  "term_ar": "المعلومات الاختيارية",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### quotation assumption

English term: quotation assumption. Arabic operational draft: افتراض عرض السعر. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0216`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "quotation assumption",
  "term_ar": "افتراض عرض السعر",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### exclusion

English term: exclusion. Arabic operational draft: استبعاد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0217`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "exclusion",
  "term_ar": "استبعاد",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### approved equal

English term: approved equal. Arabic operational draft: بديل معتمد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0218`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "approved equal",
  "term_ar": "بديل معتمد",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### compliance matrix

English term: compliance matrix. Arabic operational draft: جدول المطابقة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0219`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "compliance matrix",
  "term_ar": "جدول المطابقة",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### lead time

English term: lead time. Arabic operational draft: مدة التوريد أو التنفيذ. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0220`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "lead time",
  "term_ar": "مدة التوريد أو التنفيذ",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### service-level agreement

English term: service-level agreement. Arabic operational draft: اتفاقية مستوى الخدمة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0221`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "service-level agreement",
  "term_ar": "اتفاقية مستوى الخدمة",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### acceptance criteria

English term: acceptance criteria. Arabic operational draft: معايير القبول. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0222`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "acceptance criteria",
  "term_ar": "معايير القبول",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### warranty

English term: warranty. Arabic operational draft: الضمان. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0223`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "warranty",
  "term_ar": "الضمان",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### maintenance

English term: maintenance. Arabic operational draft: الصيانة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0224`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "maintenance",
  "term_ar": "الصيانة",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### authority approval

English term: authority approval. Arabic operational draft: موافقة الجهة المختصة. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0225`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "authority approval",
  "term_ar": "موافقة الجهة المختصة",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### supplier eligibility

English term: supplier eligibility. Arabic operational draft: أهلية المورد. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0226`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "supplier eligibility",
  "term_ar": "أهلية المورد",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### customer clarification

English term: customer clarification. Arabic operational draft: استيضاح العميل. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0227`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "customer clarification",
  "term_ar": "استيضاح العميل",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### technical deviation

English term: technical deviation. Arabic operational draft: انحراف فني. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0228`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "technical deviation",
  "term_ar": "انحراف فني",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### commercial deviation

English term: commercial deviation. Arabic operational draft: انحراف تجاري. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0229`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial deviation",
  "term_ar": "انحراف تجاري",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### document revision

English term: document revision. Arabic operational draft: إصدار المستند. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0230`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "document revision",
  "term_ar": "إصدار المستند",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### handover

English term: handover. Arabic operational draft: التسليم النهائي. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0231`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "handover",
  "term_ar": "التسليم النهائي",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### location/capacity

English term: location/capacity. Arabic operational draft: متطلبات location/capacity. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0232`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "location/capacity",
  "term_ar": "متطلبات location/capacity",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### workspace type

English term: workspace type. Arabic operational draft: متطلبات workspace type. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0233`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "workspace type",
  "term_ar": "متطلبات workspace type",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### licence/address need

English term: licence/address need. Arabic operational draft: متطلبات licence/address need. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0234`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "licence/address need",
  "term_ar": "متطلبات licence/address need",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### services/meeting rooms

English term: services/meeting rooms. Arabic operational draft: متطلبات services/meeting rooms. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0235`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "services/meeting rooms",
  "term_ar": "متطلبات services/meeting rooms",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### access/security

English term: access/security. Arabic operational draft: متطلبات access/security. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0236`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "access/security",
  "term_ar": "متطلبات access/security",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### commercial terms

English term: commercial terms. Arabic operational draft: متطلبات commercial terms. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0237`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "commercial terms",
  "term_ar": "متطلبات commercial terms",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```

### support/exit

English term: support/exit. Arabic operational draft: متطلبات support/exit. Use this pair for customer-language normalization and supplier-facing output. Preserve the customer’s original wording and map it to the canonical field; a synonym does not prove an exact grade, model, licence, professional conclusion or approval.

- Record ID: `QD-KB-031-virtual-offices-glossary-bilingual_term-0238`
- Status: `reviewed` | Confidence: `0.84` | Review after: `2027-01-31`
- Sources: none / internal operational rule

```json
{
  "term_en": "support/exit",
  "term_ar": "متطلبات support/exit",
  "canonical_subcategory": "virtual-offices",
  "normalization_only": true
}
```
