# Claude / Supabase Ingestion — Category 23

1. Import `19_source_registry.csv` and `03_taxonomy.json` first.
2. Stream JSONL files from disk in batches; do not paste them into the Claude conversation.
3. Upsert by stable record/question/rule/validation/scenario ID and preserve package version.
4. Store narrative records in searchable knowledge tables; embed asynchronously only where retrieval benefits.
5. Store qualification questions, decision rules and validations in deterministic relational tables.
6. Do not let a language model override an applicable approved rule.
7. Keep `draft`, `reviewed` and `source_verified` states unchanged until SME/regulatory review.
8. Run every scenario in `18_scenarios_tests.jsonl` after staging import.
9. Map live categories by stable slug and allow many-to-many cross-category routing.
10. Report remaining OpenRouter calls where internal retrieval or deterministic rules apply.
