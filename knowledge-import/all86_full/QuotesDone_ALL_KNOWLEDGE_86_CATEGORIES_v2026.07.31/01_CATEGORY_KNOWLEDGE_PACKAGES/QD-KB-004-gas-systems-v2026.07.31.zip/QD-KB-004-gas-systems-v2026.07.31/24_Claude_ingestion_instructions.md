# Claude / Supabase Ingestion Instructions — Category 04

## Objective

Ingest Category 04 without placing the entire master file in prompts. Supabase and deterministic rules should be the operational brain; a language model should only parse customer language, extract uncertain document fields, phrase approved questions and handle low-confidence exceptions.

## Required sequence

1. Reconcile package slugs with the live production taxonomy; preserve package stable IDs in a mapping table.
2. Create or confirm versioned tables for categories, subcategories, sources, knowledge records, questions, rules, validations, scenario tests and ingestion runs.
3. Validate atomic records against `25_knowledge_record_schema.json`.
4. Upsert `19_source_registry.csv` before records so every source ID resolves.
5. Upsert taxonomy, then the JSONL files in numerical order.
6. Do not activate rules whose `requires_human_review` is true or whose `normalization_status` is not complete.
7. Generate embeddings only for narrative records. Query deterministic questions, validations and rules using SQL/JSON conditions.
8. Keep customer answers, extracted document values and system-derived values separately sourced and versioned.
9. Implement a fail-closed supplier-dispatch gate: every supplier-visible artifact must have passed redaction and every mandatory field/critical validation must be satisfied.
10. Execute all records in `18_scenarios_tests.jsonl` after ingestion and produce pass/fail evidence.

## Recommended runtime retrieval

Filter by `category_slug`, `subcategory_slug`, active jurisdiction, product family, workflow stage, missing field and current document context. Return only the required records. Do not use `02_category_master.md` as runtime context.

## Required ingestion report

Return inserted, updated, unchanged, duplicate, rejected and quarantined counts by file; missing source IDs; unresolved taxonomy mappings; activated vs review-pending rules; schema failures; scenario-test results; embedding counts; and estimated token reduction versus the current OpenRouter path.

## Safety and authority

The corpus does not authorize Claude to invent code clauses, engineering capacities, compliance decisions or market prices. When a rule needs licensed-standard interpretation, authority confirmation or professional design, route to a human reviewer and preserve the source trail.
