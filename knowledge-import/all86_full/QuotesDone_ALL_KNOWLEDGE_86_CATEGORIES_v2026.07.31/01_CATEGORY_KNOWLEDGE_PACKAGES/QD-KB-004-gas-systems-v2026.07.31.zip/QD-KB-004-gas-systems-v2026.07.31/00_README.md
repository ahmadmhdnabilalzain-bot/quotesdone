# QuotesDone Category 04 Knowledge Package

**Category:** Gas Systems  
**Version:** 2026.07.31  
**Subcategories:** 5  
**Status:** Production draft; schema-valid; requires specialist and legal/authority certification before unrestricted automated use.

## Runtime design

Do not load `02_category_master.md` into every AI request. Claude should ingest the atomic JSONL records and deterministic rules into Supabase, then retrieve only the records relevant to the current subcategory, jurisdiction, product, document and inquiry state.

## Priority files

1. `24_Claude_ingestion_instructions.md`
2. `21_ingestion_manifest.json`
3. `03_taxonomy.json`
4. `19_source_registry.csv`
5. Atomic JSONL files 04–18
6. `22_QA_report.md`
7. `20_gap_register.csv`

## Safety

- This corpus is not a substitute for a licensed engineer, authority, accredited laboratory, lawyer or project consultant.
- Government and manufacturer references must be checked for current applicability.
- Paid standards are referenced but not reproduced.
- Records marked `draft` or rules marked `requires_human_review` cannot be activated automatically without review.
- Exact product certificates, registrations and authority approvals must be validated at quotation time.
